using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Core.Utilities;
using Rexon_Menu.Interface;
using UnityEngine;

internal static class Class10
{
	private static string string_0;

	private static bool bool_0;

	private static bool bool_1;

	private static HashSet<string> hashSet_0;

	private static double double_0;

	private static int int_0;

	private static int int_1;

	private static double double_1;

	private static double double_2;

	private static IntPtr[] ModuleAsync;

	private static IntPtr[] NoPromptWednesday;

	private static IntPtr[] getAccountDomainSidCreateText;

	private static IntPtr[] IgnorePortablePDBsInStackTracesILGenerator;

	private static IntPtr[] getTransformNamesGetRuntimeInterfaceAsObject;

	private static IntPtr[] AddPathListRightToLeftArabic;

	private static IntPtr[] KeepAliveFormatPtr;

	private static IntPtr[] AccountCertAdminsSidTypeConstructorName;

	private static IntPtr[] FailureCustomConstantAttribute;

	private static IntPtr[] BinaryAssemblyInfoGetExceptionPointers;

	private static IntPtr[] SecurityPermissionSecurityLogonType;

	public unsafe static bool AutoLoadEnabled
	{
		get
		{
			int num = 17;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				num = 16;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							IL_09b1:
							byte[] array = new byte[3];
							while (true)
							{
								IL_09a1:
								object[] array2 = new object[3];
								while (true)
								{
									IL_0991:
									int[] array3 = new int[6];
									while (true)
									{
										IL_0981:
										long[] array4 = new long[3];
										while (true)
										{
											IL_0976:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setDynamicBasegetDirectorySection.MoveBufferAreaNumberFormat);
											while (true)
											{
												IL_096c:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0959:
													if (num5 != 1)
													{
														while (true)
														{
															IL_0395:
															byte b = *ptr2;
															while (true)
															{
																IL_037c:
																ptr2++;
																num = 102;
																while (true)
																{
																	IL_036c:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_034f:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_033f:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_032f:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_031f:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_030f:
																												if (6 <= b)
																												{
																													while (true)
																													{
																														IL_02cd:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														while (true)
																														{
																															IL_02ae:
																															array[num6 - 2] = 0;
																															num = 163;
																															while (true)
																															{
																																if (num != 163)
																																{
																																	if (num != 1144)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 9:
																																		goto IL_02ae;
																																	case 39:
																																	case 95:
																																		goto IL_02cd;
																																	case 92:
																																		goto IL_030f;
																																	case 67:
																																	case 129:
																																		goto IL_031f;
																																	case 8:
																																	case 49:
																																		goto IL_032f;
																																	case 70:
																																		goto IL_033f;
																																	case 69:
																																		goto IL_034f;
																																	case 127:
																																		goto IL_035c;
																																	case 102:
																																		goto IL_036c;
																																	case 41:
																																		goto IL_037c;
																																	case 5:
																																	case 114:
																																		goto IL_0395;
																																	case 79:
																																		goto IL_03a0;
																																	case 24:
																																		goto IL_03ab;
																																	case 65:
																																		goto IL_03b6;
																																	case 35:
																																		goto IL_03c1;
																																	case 61:
																																		goto IL_03cf;
																																	case 66:
																																		goto IL_03e2;
																																	case 103:
																																		goto IL_03f0;
																																	case 80:
																																	case 106:
																																		goto IL_0400;
																																	case 44:
																																		goto IL_0415;
																																	case 109:
																																		goto IL_0428;
																																	case 31:
																																	case 113:
																																		goto IL_0441;
																																	case 76:
																																	case 116:
																																		goto IL_0467;
																																	case 72:
																																	case 123:
																																		goto IL_047f;
																																	case 90:
																																		goto IL_0498;
																																	case 15:
																																	case 143:
																																		goto IL_04ab;
																																	case 45:
																																		goto IL_04b9;
																																	case 12:
																																	case 57:
																																		goto IL_04c7;
																																	case 147:
																																		goto IL_04e3;
																																	case 4:
																																		goto IL_04f1;
																																	case 108:
																																		goto IL_04ff;
																																	case 107:
																																	case 153:
																																		goto IL_0512;
																																	case 105:
																																		goto IL_0520;
																																	case 1:
																																	case 152:
																																		goto IL_052b;
																																	case 132:
																																		goto IL_058d;
																																	case 97:
																																		goto IL_05a0;
																																	case 23:
																																		goto IL_05ae;
																																	case 50:
																																	case 101:
																																		goto IL_05bc;
																																	case 81:
																																		goto IL_05fc;
																																	case 27:
																																		goto IL_0610;
																																	case 154:
																																		goto IL_0623;
																																	case 120:
																																		goto IL_062e;
																																	case 156:
																																		goto IL_064f;
																																	case 47:
																																		goto IL_065d;
																																	case 128:
																																		goto IL_0683;
																																	case 54:
																																		goto IL_0691;
																																	case 7:
																																	case 74:
																																		goto IL_069f;
																																	case 32:
																																		goto IL_06df;
																																	case 133:
																																		goto IL_06f3;
																																	case 2:
																																		goto IL_070f;
																																	case 145:
																																		goto IL_071d;
																																	case 40:
																																	case 78:
																																		goto IL_0734;
																																	case 42:
																																		goto IL_0774;
																																	case 141:
																																		goto IL_0788;
																																	case 62:
																																		goto IL_079b;
																																	case 55:
																																		goto IL_07a9;
																																	case 115:
																																	case 136:
																																		goto IL_07b4;
																																	case 83:
																																		goto IL_07c2;
																																	case 51:
																																	case 99:
																																		goto IL_07d0;
																																	case 82:
																																		goto IL_07f9;
																																	case 117:
																																		goto IL_0807;
																																	case 75:
																																		goto IL_081a;
																																	case 121:
																																	case 124:
																																		goto IL_0825;
																																	case 98:
																																		goto IL_0865;
																																	case 34:
																																		goto IL_0879;
																																	case 86:
																																		goto IL_088c;
																																	case 142:
																																		goto IL_0897;
																																	case 37:
																																	case 139:
																																		goto IL_08ad;
																																	case 60:
																																		goto IL_08bb;
																																	case 91:
																																		goto IL_08de;
																																	case 13:
																																		goto IL_08e8;
																																	case 6:
																																		goto IL_08f6;
																																	case 77:
																																	case 110:
																																		goto IL_0906;
																																	case 3:
																																	case 10:
																																	case 11:
																																	case 18:
																																	case 19:
																																	case 20:
																																	case 21:
																																	case 28:
																																	case 29:
																																	case 30:
																																	case 46:
																																	case 48:
																																	case 52:
																																	case 68:
																																	case 71:
																																	case 73:
																																	case 84:
																																	case 87:
																																	case 93:
																																	case 94:
																																	case 96:
																																	case 104:
																																	case 112:
																																	case 122:
																																	case 126:
																																	case 131:
																																	case 135:
																																	case 137:
																																	case 144:
																																	case 155:
																																		goto end_IL_035c;
																																	case 125:
																																		goto IL_092f;
																																	case 138:
																																		goto IL_093d;
																																	case 118:
																																		goto IL_094b;
																																	case 14:
																																	case 26:
																																	case 36:
																																	case 38:
																																	case 53:
																																	case 56:
																																	case 58:
																																	case 63:
																																	case 64:
																																	case 85:
																																	case 88:
																																	case 89:
																																	case 119:
																																	case 134:
																																	case 146:
																																	case 148:
																																	case 149:
																																	case 150:
																																	case 151:
																																		goto IL_0959;
																																	case 59:
																																		goto IL_096c;
																																	case 22:
																																		goto IL_0976;
																																	case 130:
																																		goto IL_0981;
																																	case 100:
																																	case 111:
																																		goto IL_0991;
																																	case 25:
																																		goto IL_09a1;
																																	case 0:
																																		goto IL_09b1;
																																	case 33:
																																		goto end_IL_029b;
																																	case 16:
																																		goto end_IL_09c1;
																																	case 17:
																																		goto end_IL_09d1;
																																	case 43:
																																	case 140:
																																		goto IL_09f5;
																																	}
																																	continue;
																																}
																																num6--;
																																goto IL_0959;
																																continue;
																																end_IL_029b:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0683;
																												IL_06f3:
																												num6--;
																												num = 14;
																												goto IL_0959;
																												IL_0683:
																												if (5 < b)
																												{
																													goto end_IL_035c;
																												}
																												goto IL_0691;
																												IL_0691:
																												if (5 > b)
																												{
																													goto end_IL_035c;
																												}
																												goto IL_069f;
																												IL_069f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_06df;
																												IL_06df:
																												array[num6 - 2] = 0;
																												goto IL_06f3;
																											}
																											break;
																										}
																										goto IL_070f;
																										IL_0774:
																										array[num6 - 2] = 0;
																										goto IL_0788;
																										IL_070f:
																										if (7 < b)
																										{
																											goto end_IL_035c;
																										}
																										goto IL_071d;
																										IL_071d:
																										if (7 > b)
																										{
																											goto end_IL_035c;
																										}
																										num = 78;
																										goto IL_0734;
																										IL_0788:
																										num6--;
																										goto IL_0959;
																										IL_0734:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0774;
																									}
																									break;
																								}
																								goto IL_079b;
																								IL_08e8:
																								num6++;
																								goto IL_08f6;
																								IL_079b:
																								if (4 > b)
																								{
																									goto IL_07a9;
																								}
																								num = 139;
																								goto IL_08ad;
																								IL_07a9:
																								if (2 < b)
																								{
																									goto IL_07b4;
																								}
																								goto IL_081a;
																								IL_07b4:
																								if (3 < b)
																								{
																									goto end_IL_035c;
																								}
																								goto IL_07c2;
																								IL_07c2:
																								if (3 > b)
																								{
																									goto end_IL_035c;
																								}
																								goto IL_07d0;
																								IL_07d0:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_07f9;
																								IL_07f9:
																								ptr2 += 8;
																								goto IL_0807;
																								IL_0807:
																								num6--;
																								goto IL_0959;
																								IL_081a:
																								if (2 <= b)
																								{
																									goto IL_0825;
																								}
																								goto IL_088c;
																								IL_0825:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0865;
																								IL_0865:
																								array[num6 - 2] = 0;
																								goto IL_0879;
																								IL_0879:
																								num6--;
																								goto IL_0959;
																								IL_088c:
																								if (1 < b)
																								{
																									goto end_IL_035c;
																								}
																								goto IL_0897;
																								IL_0897:
																								if (1 > b)
																								{
																								}
																								goto end_IL_035c;
																								IL_08f6:
																								ptr2 += 8;
																								goto IL_0959;
																								IL_08ad:
																								array[num6] = 0;
																								goto IL_08bb;
																								IL_08bb:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_08de;
																								IL_08de:
																								array2[num6] = null;
																								goto IL_08e8;
																							}
																							break;
																						}
																						goto IL_0906;
																						IL_0906:
																						num6--;
																						goto IL_0959;
																					}
																					break;
																				}
																				goto IL_03a0;
																				IL_0498:
																				array[num6] = 1;
																				goto IL_064f;
																				IL_03a0:
																				if (12 < b)
																				{
																					goto IL_03ab;
																				}
																				goto IL_0428;
																				IL_03ab:
																				if (14 >= b)
																				{
																					goto IL_03b6;
																				}
																				goto IL_03e2;
																				IL_03b6:
																				if (14 > b)
																				{
																					goto IL_03c1;
																				}
																				goto IL_0400;
																				IL_03c1:
																				if (13 < b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_03cf;
																				IL_03cf:
																				if (13 > b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_0467;
																				IL_0467:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_0959;
																				IL_0400:
																				((delegate*<void>)ModuleAsync[*(int*)(ptr2 + num3)])();
																				goto IL_0415;
																				IL_0415:
																				ptr2 += 8;
																				goto IL_0959;
																				IL_03e2:
																				if (15 >= b)
																				{
																					goto IL_03f0;
																				}
																				goto IL_04ab;
																				IL_03f0:
																				if (15 > b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_0441;
																				IL_0441:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)ModuleAsync[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_04e3;
																				IL_04e3:
																				array[num6] = 0;
																				goto IL_04f1;
																				IL_04f1:
																				num6++;
																				goto IL_04ff;
																				IL_04ff:
																				ptr2 += 8;
																				goto IL_0959;
																				IL_04ab:
																				if (16 < b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_04b9;
																				IL_04b9:
																				if (16 > b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_04c7;
																				IL_04c7:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto IL_0959;
																				IL_0428:
																				if (12 <= b)
																				{
																					goto IL_047f;
																				}
																				num = 107;
																				goto IL_0512;
																				IL_064f:
																				num6++;
																				goto IL_065d;
																				IL_0512:
																				if (10 >= b)
																				{
																					goto IL_0520;
																				}
																				goto IL_0623;
																				IL_0520:
																				if (10 <= b)
																				{
																					goto IL_052b;
																				}
																				goto IL_05a0;
																				IL_052b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_058d;
																				IL_058d:
																				num6 -= 2;
																				goto IL_0959;
																				IL_05a0:
																				if (9 < b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_05ae;
																				IL_05ae:
																				if (9 > b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_05bc;
																				IL_05bc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_05fc;
																				IL_05fc:
																				array[num6 - 2] = 0;
																				goto IL_0610;
																				IL_0610:
																				num6--;
																				goto IL_0959;
																				IL_0623:
																				if (11 < b)
																				{
																					num = 28;
																					goto end_IL_035c;
																				}
																				goto IL_062e;
																				IL_062e:
																				if (11 > b)
																				{
																					goto end_IL_035c;
																				}
																				goto IL_0959;
																				IL_065d:
																				ptr2 += 16;
																				goto IL_0959;
																				IL_047f:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0498;
																			}
																			goto end_IL_036c;
																			continue;
																			end_IL_035c:
																			break;
																			IL_035c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_092f;
																	IL_094b:
																	ptr2 += 8;
																	goto IL_0959;
																	IL_093d:
																	num6++;
																	goto IL_094b;
																	IL_092f:
																	array[num6] = 0;
																	goto IL_093d;
																	continue;
																	end_IL_036c:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_09f5;
													IL_09f5:
													return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_09c1:
						break;
					}
					continue;
					end_IL_09d1:
					break;
				}
			}
		}
		set
		{
			int num = 163;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									sbyte[] array3 = new sbyte[1];
									while (true)
									{
										int[] array4 = new int[6];
										while (true)
										{
											long[] array5 = new long[3];
											while (true)
											{
												array3[0] = (value ? ((sbyte)1) : ((sbyte)0));
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsDynamicsetFrameworkDisplayName.SetTypedReferenceCodebase);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0370:
																		if (b >= 1)
																		{
																			while (b <= 17)
																			{
																				while (true)
																				{
																					IL_0350:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_0340:
																							if (13 >= b)
																							{
																								while (true)
																								{
																									IL_0330:
																									if (13 > b)
																									{
																										while (true)
																										{
																											IL_0323:
																											if (11 >= b)
																											{
																												while (true)
																												{
																													IL_0313:
																													if (11 > b)
																													{
																														while (10 >= b)
																														{
																															while (true)
																															{
																																IL_02f0:
																																if (10 > b)
																																{
																																	num = 176;
																																	while (num != 176)
																																	{
																																		if (num != 1157)
																																		{
																																			goto IL_072d;
																																		}
																																		switch (num)
																																		{
																																		case 127:
																																			goto IL_02f0;
																																		case 155:
																																		case 156:
																																			goto IL_0303;
																																		case 146:
																																			goto IL_0313;
																																		case 41:
																																		case 80:
																																			goto IL_0323;
																																		case 154:
																																			goto IL_0330;
																																		case 86:
																																		case 121:
																																			goto IL_0340;
																																		case 82:
																																			goto IL_0350;
																																		case 29:
																																			goto IL_0360;
																																		case 61:
																																			goto IL_0370;
																																		case 54:
																																			goto end_IL_0370;
																																		case 35:
																																		case 122:
																																			goto end_IL_0380;
																																		case 76:
																																		case 83:
																																			goto IL_039b;
																																		case 39:
																																			goto IL_03a9;
																																		case 43:
																																		case 118:
																																			goto IL_03bc;
																																		case 5:
																																			goto IL_041e;
																																		case 46:
																																		case 73:
																																			goto IL_0431;
																																		case 109:
																																			goto IL_044e;
																																		case 11:
																																			goto IL_048d;
																																		case 37:
																																		case 40:
																																			goto IL_04a0;
																																		case 13:
																																			goto IL_04b9;
																																		case 157:
																																			goto IL_04c7;
																																		case 141:
																																			goto IL_04d5;
																																		case 166:
																																			goto IL_04e8;
																																		case 33:
																																		case 65:
																																			goto IL_04f3;
																																		case 102:
																																		case 115:
																																			goto IL_04fe;
																																		case 133:
																																			goto IL_050c;
																																		case 32:
																																		case 34:
																																			goto IL_051a;
																																		case 6:
																																			goto IL_0536;
																																		case 20:
																																		case 26:
																																			goto IL_0544;
																																		case 135:
																																			goto IL_055e;
																																		case 108:
																																			goto IL_0571;
																																		case 25:
																																		case 59:
																																			goto IL_057c;
																																		case 143:
																																			goto IL_058a;
																																		case 50:
																																		case 137:
																																			goto IL_0598;
																																		case 55:
																																		case 106:
																																			goto IL_05b0;
																																		case 38:
																																			goto IL_05d3;
																																		case 107:
																																			goto IL_05e1;
																																		case 105:
																																			goto IL_05ef;
																																		case 94:
																																			goto IL_060b;
																																		case 69:
																																			goto IL_0619;
																																		case 60:
																																			goto IL_0627;
																																		case 67:
																																			goto IL_0635;
																																		case 1:
																																		case 112:
																																			goto IL_0643;
																																		case 84:
																																			goto IL_0651;
																																		case 93:
																																		case 114:
																																			goto IL_065f;
																																		case 160:
																																			goto IL_069f;
																																		case 139:
																																			goto IL_06b3;
																																		case 51:
																																		case 96:
																																			goto IL_06c6;
																																		case 145:
																																			goto IL_0706;
																																		case 12:
																																			goto IL_071a;
																																		case 90:
																																		case 149:
																																			goto IL_072d;
																																		case 78:
																																			goto IL_0738;
																																		case 24:
																																		case 98:
																																			goto IL_0746;
																																		case 159:
																																			goto IL_0786;
																																		case 31:
																																			goto IL_079a;
																																		case 92:
																																		case 99:
																																			goto IL_07ad;
																																		case 161:
																																			goto IL_07bb;
																																		case 36:
																																		case 45:
																																			goto IL_07d2;
																																		case 110:
																																			goto IL_07e5;
																																		case 140:
																																		case 158:
																																			goto IL_07f3;
																																		case 64:
																																			goto IL_0801;
																																		case 74:
																																		case 75:
																																			goto IL_080c;
																																		case 153:
																																			goto IL_084c;
																																		case 19:
																																			goto IL_0860;
																																		case 164:
																																			goto IL_0873;
																																		case 134:
																																			goto IL_0881;
																																		case 100:
																																			goto IL_0894;
																																		case 18:
																																			goto IL_08a2;
																																		case 0:
																																		case 71:
																																			goto IL_08b0;
																																		case 129:
																																			goto IL_08d9;
																																		case 8:
																																			goto IL_08e7;
																																		case 148:
																																		case 165:
																																			goto IL_08fa;
																																		case 91:
																																			goto IL_0908;
																																		case 72:
																																			goto IL_092b;
																																		case 15:
																																			goto IL_0935;
																																		case 125:
																																			goto IL_094c;
																																		case 103:
																																		case 150:
																																			goto IL_0968;
																																		case 101:
																																			goto IL_09a8;
																																		case 58:
																																			goto IL_09bc;
																																		case 2:
																																		case 4:
																																		case 7:
																																		case 9:
																																		case 14:
																																		case 21:
																																		case 28:
																																		case 44:
																																		case 52:
																																		case 62:
																																		case 68:
																																		case 79:
																																		case 81:
																																		case 89:
																																		case 97:
																																		case 113:
																																		case 116:
																																		case 117:
																																		case 126:
																																		case 128:
																																		case 130:
																																		case 131:
																																		case 138:
																																		case 142:
																																		case 144:
																																		case 167:
																																		case 169:
																																			goto end_IL_02dd;
																																		case 16:
																																			goto IL_09e5;
																																		case 27:
																																			goto IL_09f3;
																																		case 151:
																																			goto IL_0a01;
																																		case 10:
																																		case 22:
																																		case 23:
																																		case 30:
																																		case 42:
																																		case 48:
																																		case 49:
																																		case 56:
																																		case 57:
																																		case 66:
																																		case 70:
																																		case 77:
																																		case 85:
																																		case 88:
																																		case 111:
																																		case 119:
																																		case 120:
																																		case 124:
																																		case 132:
																																		case 152:
																																			goto end_IL_0390;
																																		case 168:
																																			goto end_IL_0a0f;
																																		case 147:
																																			goto end_IL_0a22;
																																		case 123:
																																			goto end_IL_0a2c;
																																		case 87:
																																			goto end_IL_0a37;
																																		case 104:
																																			goto end_IL_0a4c;
																																		case 47:
																																		case 95:
																																			goto end_IL_0a5c;
																																		case 63:
																																			goto end_IL_0a6c;
																																		case 3:
																																			goto end_IL_0a7c;
																																		case 53:
																																			goto end_IL_0a8c;
																																		case 162:
																																			goto end_IL_0a9c;
																																		case 163:
																																			goto end_IL_0aac;
																																		case 17:
																																		case 136:
																																			return;
																																		}
																																		continue;
																																		end_IL_02dd:
																																		break;
																																	}
																																	break;
																																}
																																goto IL_03bc;
																																IL_03bc:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																goto IL_041e;
																																IL_041e:
																																num6 -= 2;
																																goto end_IL_0390;
																															}
																															break;
																															IL_0303:;
																														}
																														break;
																													}
																													goto IL_0431;
																													IL_048d:
																													ptr2 += 8;
																													goto end_IL_0390;
																													IL_0431:
																													array[num6 - 1] = 0;
																													num = 109;
																													goto IL_044e;
																													IL_044e:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<int, int>)NoPromptWednesday[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																													goto IL_048d;
																												}
																												break;
																											}
																											goto IL_039b;
																											IL_03a9:
																											if (12 > b)
																											{
																												break;
																											}
																											goto end_IL_0390;
																											IL_039b:
																											if (12 < b)
																											{
																												break;
																											}
																											goto IL_03a9;
																										}
																										break;
																									}
																									goto IL_04a0;
																									IL_04d5:
																									ptr2 += 16;
																									goto end_IL_0390;
																									IL_04a0:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																									goto IL_04b9;
																									IL_04b9:
																									array[num6] = 1;
																									goto IL_04c7;
																									IL_04c7:
																									num6++;
																									goto IL_04d5;
																								}
																								break;
																							}
																							goto IL_04e8;
																							IL_05ef:
																							ptr2 += 8;
																							num = 42;
																							goto end_IL_0390;
																							IL_04e8:
																							if (15 < b)
																							{
																								goto IL_04f3;
																							}
																							goto IL_0571;
																							IL_04f3:
																							if (16 < b)
																							{
																								goto IL_04fe;
																							}
																							goto IL_0536;
																							IL_04fe:
																							if (17 < b)
																							{
																								break;
																							}
																							goto IL_050c;
																							IL_050c:
																							if (17 > b)
																							{
																								break;
																							}
																							goto IL_051a;
																							IL_051a:
																							byte* num7 = ptr2;
																							num5 = 1;
																							ptr2 = num7 + -200;
																							goto end_IL_0390;
																							IL_0536:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_0544;
																							IL_0544:
																							bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0;
																							goto IL_055e;
																							IL_055e:
																							num6--;
																							goto end_IL_0390;
																							IL_0571:
																							if (15 > b)
																							{
																								goto IL_057c;
																							}
																							goto IL_05b0;
																							IL_057c:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_058a;
																							IL_058a:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_0598;
																							IL_0598:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0390;
																							IL_05b0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05d3;
																							IL_05d3:
																							array[num6] = 0;
																							goto IL_05e1;
																							IL_05e1:
																							num6++;
																							goto IL_05ef;
																						}
																						break;
																					}
																					goto IL_060b;
																					IL_0968:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_09a8;
																					IL_060b:
																					if (9 > b)
																					{
																						goto IL_0619;
																					}
																					num = 150;
																					goto IL_0968;
																					IL_0619:
																					if (4 < b)
																					{
																						goto IL_0627;
																					}
																					goto IL_07e5;
																					IL_0627:
																					if (6 >= b)
																					{
																						goto IL_0635;
																					}
																					goto IL_072d;
																					IL_0635:
																					if (6 > b)
																					{
																						goto IL_0643;
																					}
																					goto IL_06c6;
																					IL_0643:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_0651;
																					IL_0651:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_065f;
																					IL_065f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_069f;
																					IL_069f:
																					array[num6 - 2] = 0;
																					goto IL_06b3;
																					IL_06b3:
																					num6--;
																					goto end_IL_0390;
																					IL_06c6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0706;
																					IL_0706:
																					array[num6 - 2] = 0;
																					goto IL_071a;
																					IL_071a:
																					num6--;
																					goto end_IL_0390;
																					IL_072d:
																					if (7 >= b)
																					{
																						goto IL_0738;
																					}
																					goto IL_07ad;
																					IL_0738:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0746;
																					IL_0746:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0786;
																					IL_0786:
																					array[num6 - 2] = 0;
																					goto IL_079a;
																					IL_079a:
																					num6--;
																					goto end_IL_0390;
																					IL_07ad:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_07bb;
																					IL_07bb:
																					if (8 > b)
																					{
																						break;
																					}
																					num = 36;
																					goto IL_07d2;
																					IL_09bc:
																					num6--;
																					goto end_IL_0390;
																					IL_07d2:
																					num6--;
																					goto end_IL_0390;
																					IL_07e5:
																					if (4 > b)
																					{
																						goto IL_07f3;
																					}
																					goto IL_08fa;
																					IL_07f3:
																					if (2 >= b)
																					{
																						goto IL_0801;
																					}
																					goto IL_0894;
																					IL_0801:
																					if (2 <= b)
																					{
																						goto IL_080c;
																					}
																					goto IL_0873;
																					IL_080c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_084c;
																					IL_084c:
																					array[num6 - 2] = 0;
																					goto IL_0860;
																					IL_0860:
																					num6--;
																					goto end_IL_0390;
																					IL_0873:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0881;
																					IL_0881:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_0894:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_08a2;
																					IL_08a2:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_08b0;
																					IL_08b0:
																					ref int reference = ref array4[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_08d9;
																					IL_08d9:
																					ptr2 += 8;
																					goto IL_08e7;
																					IL_08e7:
																					num6--;
																					goto end_IL_0390;
																					IL_08fa:
																					array[num6] = 0;
																					goto IL_0908;
																					IL_0908:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																					goto IL_092b;
																					IL_092b:
																					array2[num6] = null;
																					goto IL_0935;
																					IL_0935:
																					num6++;
																					num = 125;
																					goto IL_094c;
																					IL_094c:
																					ptr2 += 8;
																					goto end_IL_0390;
																					IL_09a8:
																					array[num6 - 2] = 0;
																					goto IL_09bc;
																				}
																				break;
																				IL_0360:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																		goto IL_09e5;
																		IL_0a01:
																		ptr2 += 8;
																		goto end_IL_0390;
																		IL_09f3:
																		num6++;
																		goto IL_0a01;
																		IL_09e5:
																		array[num6] = 0;
																		goto IL_09f3;
																		continue;
																		end_IL_0370:
																		break;
																	}
																	continue;
																	end_IL_0380:
																	break;
																}
																continue;
																end_IL_0390:
																break;
															}
															continue;
															end_IL_0a0f:
															break;
														}
														continue;
														end_IL_0a22:
														break;
													}
													continue;
													end_IL_0a2c:
													break;
												}
												continue;
												end_IL_0a37:
												break;
											}
											continue;
											end_IL_0a4c:
											break;
										}
										continue;
										end_IL_0a5c:
										break;
									}
									continue;
									end_IL_0a6c:
									break;
								}
								continue;
								end_IL_0a7c:
								break;
							}
							continue;
							end_IL_0a8c:
							break;
						}
						continue;
						end_IL_0a9c:
						break;
					}
					continue;
					end_IL_0aac:
					break;
				}
			}
		}
	}

	private unsafe static string smethod_0()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_04b1, IL_04c4, IL_04d7, IL_04e7, IL_04f7, IL_0504, IL_0511, IL_0521, IL_0531, IL_0541, IL_054c, IL_055f, IL_056d, IL_0578, IL_058b, IL_0599, IL_05a7, IL_05c4, IL_0613, IL_061d, IL_064a, IL_0660, IL_066b, IL_067e, IL_068c, IL_069f, IL_06aa, IL_06bd, IL_071f, IL_0732, IL_0745, IL_075e, IL_076c, IL_077f, IL_078d, IL_079b, IL_07a9, IL_07b4, IL_07f4, IL_0811, IL_0824, IL_0832, IL_0845, IL_0853, IL_0866, IL_0879, IL_0887, IL_089a, IL_08ad, IL_08eb, IL_08fe, IL_090c, IL_094c, IL_096e, IL_097c, IL_098a, IL_0998, IL_09ab, IL_09be, IL_09cc, IL_09fa, IL_0a05, IL_0a45, IL_0a5e, IL_0a6c, IL_0a75, IL_0a83, IL_0ac8, IL_0ad6, IL_0af9, IL_0b03, IL_0b16, IL_0b24, IL_0b41, IL_0b4c, IL_0b65, IL_0b73, IL_0b81, IL_0b94, IL_0ba2, IL_0bb0, IL_0bc6, IL_0bd9, IL_0c11, IL_0c24, IL_0c32, IL_0c40, IL_0c4e, IL_0c66, IL_0c74, IL_0c90, IL_0ca3, IL_0ce4, IL_0cfd, IL_0d15, IL_0d3c, IL_0d60, IL_0d78, IL_0d8b, IL_0d99, IL_0dd9, IL_0ded, IL_0e00, IL_0e3f, IL_0e5b, IL_0e84, IL_0e9d, IL_0eb0, IL_0ec3, IL_0edc, IL_0eea, IL_0ef8, IL_0f0b, IL_0f29, IL_0f37, IL_0f4a, IL_0f61, IL_0f74, IL_0f88, IL_0f9b, IL_0fa9, IL_0fb4, IL_0fc2, IL_1016, IL_1029, IL_1037, IL_1045, IL_105e, IL_106c, IL_107a, IL_108d, IL_10a0, IL_10ae, IL_10bc, IL_10ca, IL_111c, IL_112f, IL_1138, IL_1156, IL_1164, IL_1172, IL_118e, IL_1199, IL_11ad, IL_11ec, IL_11ff, IL_120d, IL_121b, IL_125b, IL_126f, IL_1282, IL_1290, IL_129e, IL_12ac, IL_12d3, IL_12e1, IL_12f4, IL_12fd, IL_1311, IL_135d, IL_136b, IL_137e, IL_138c, IL_1397, IL_13a5, IL_13b3, IL_13cc, IL_13df, IL_141f, IL_143c, IL_144c, IL_1457, IL_1462, IL_147b, IL_1486, IL_148f, IL_149a, IL_14b6, IL_14c9, IL_14d3, IL_14de, IL_14ee, IL_14fe, IL_150e, IL_151e, IL_152e, IL_153e, IL_154e, IL_155e, IL_1579, IL_1582 are reachable both inside and outside the pinned region starting at IL_1573. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 113;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef1 = default(int);
			ref int reference = ref __rxRef1;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_155e:
					num2 = 1;
					while (true)
					{
						IL_154e:
						num3 = num2 * 4;
						while (true)
						{
							IL_153e:
							num4 = num2 * 8;
							while (true)
							{
								IL_152e:
								array2 = new byte[4];
								while (true)
								{
									IL_151e:
									array3 = new object[4];
									while (true)
									{
										IL_150e:
										array4 = new int[4];
										while (true)
										{
											IL_14fe:
											array5 = new int[7];
											while (true)
											{
												IL_14ee:
												array6 = new long[4];
												while (true)
												{
													IL_14de:
													array7 = new object[11];
													while (true)
													{
														IL_14d3:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemRevisionVersion.OSArchitectureDestination);
														while (true)
														{
															IL_14c9:
															ptr2 = ptr;
															while (true)
															{
																IL_14b6:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_0541:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0531:
																			ptr2++;
																			while (true)
																			{
																				IL_0521:
																				if (b >= 1)
																				{
																					while (b <= 34)
																					{
																						while (true)
																						{
																							IL_0504:
																							if (17 < b)
																							{
																								while (true)
																								{
																									IL_04f7:
																									if (26 < b)
																									{
																										while (true)
																										{
																											IL_04e7:
																											if (30 >= b)
																											{
																												while (true)
																												{
																													IL_04d7:
																													if (30 > b)
																													{
																														while (true)
																														{
																															IL_04c4:
																															if (28 >= b)
																															{
																																num = 293;
																																while (true)
																																{
																																	if (num != 293)
																																	{
																																		if (num != 1274)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 113:
																																			break;
																																		default:
																																			continue;
																																		case 38:
																																			goto IL_04c4;
																																		case 129:
																																			goto IL_04d7;
																																		case 206:
																																			goto IL_04e7;
																																		case 87:
																																			goto IL_04f7;
																																		case 35:
																																			goto IL_0504;
																																		case 78:
																																			goto IL_0511;
																																		case 210:
																																			goto IL_0521;
																																		case 69:
																																			goto IL_0531;
																																		case 49:
																																		case 182:
																																			goto IL_0541;
																																		case 123:
																																			goto IL_054c;
																																		case 137:
																																			goto IL_055f;
																																		case 20:
																																			goto IL_056d;
																																		case 119:
																																			goto IL_0578;
																																		case 81:
																																			goto IL_058b;
																																		case 72:
																																			goto IL_0599;
																																		case 28:
																																		case 76:
																																			goto IL_05a7;
																																		case 141:
																																			goto IL_0660;
																																		case 128:
																																			goto IL_066b;
																																		case 147:
																																			goto IL_067e;
																																		case 138:
																																			goto IL_068c;
																																		case 148:
																																			goto IL_069f;
																																		case 0:
																																			goto IL_06aa;
																																		case 7:
																																		case 153:
																																			goto IL_06bd;
																																		case 86:
																																			goto IL_071f;
																																		case 48:
																																		case 155:
																																			goto IL_0732;
																																		case 3:
																																		case 156:
																																			goto IL_0745;
																																		case 168:
																																			goto IL_075e;
																																		case 34:
																																			goto IL_076c;
																																		case 179:
																																			goto IL_077f;
																																		case 140:
																																			goto IL_078d;
																																		case 102:
																																			goto IL_079b;
																																		case 62:
																																			goto IL_07a9;
																																		case 45:
																																		case 132:
																																			goto IL_07b4;
																																		case 96:
																																			goto IL_07f4;
																																		case 17:
																																			goto IL_0811;
																																		case 89:
																																			goto IL_0824;
																																		case 60:
																																			goto IL_0832;
																																		case 109:
																																			goto IL_0845;
																																		case 19:
																																			goto IL_0853;
																																		case 181:
																																			goto IL_0866;
																																		case 209:
																																			goto IL_0879;
																																		case 180:
																																			goto IL_0887;
																																		case 212:
																																			goto IL_089a;
																																		case 99:
																																		case 214:
																																			goto IL_08ad;
																																		case 189:
																																			goto IL_08eb;
																																		case 215:
																																			goto IL_08fe;
																																		case 149:
																																		case 152:
																																			goto IL_090c;
																																		case 216:
																																			goto IL_094c;
																																		case 228:
																																			goto IL_096e;
																																		case 197:
																																			goto IL_097c;
																																		case 92:
																																			goto IL_098a;
																																		case 220:
																																			goto IL_0998;
																																		case 230:
																																			goto IL_09ab;
																																		case 243:
																																			goto IL_09be;
																																		case 11:
																																		case 170:
																																			goto IL_09cc;
																																		case 245:
																																			goto IL_09fa;
																																		case 14:
																																		case 51:
																																			goto IL_0a05;
																																		case 118:
																																			goto IL_0a45;
																																		case 46:
																																			goto IL_0a5e;
																																		case 213:
																																			goto IL_0a75;
																																		case 88:
																																		case 174:
																																			goto IL_0a83;
																																		case 171:
																																		case 246:
																																			goto IL_0ac8;
																																		case 134:
																																			goto IL_0ad6;
																																		case 53:
																																			goto IL_0af9;
																																		case 103:
																																			goto IL_0b03;
																																		case 247:
																																			goto IL_0b16;
																																		case 130:
																																		case 203:
																																			goto IL_0b24;
																																		case 248:
																																			goto IL_0b41;
																																		case 39:
																																		case 139:
																																			goto IL_0b4c;
																																		case 222:
																																			goto IL_0b65;
																																		case 192:
																																			goto IL_0b73;
																																		case 233:
																																			goto IL_0b81;
																																		case 136:
																																			goto IL_0b94;
																																		case 236:
																																			goto IL_0ba2;
																																		case 57:
																																		case 161:
																																			goto IL_0bb0;
																																		case 250:
																																			goto IL_0bc6;
																																		case 251:
																																			goto IL_0bd9;
																																		case 193:
																																			goto IL_0c11;
																																		case 253:
																																			goto IL_0c24;
																																		case 30:
																																			goto IL_0c32;
																																		case 47:
																																		case 159:
																																			goto IL_0c40;
																																		case 1:
																																			goto IL_0c4e;
																																		case 244:
																																			goto IL_0c66;
																																		case 125:
																																			goto IL_0c74;
																																		case 255:
																																			goto IL_0c90;
																																		case 84:
																																		case 256:
																																			goto IL_0ca3;
																																		case 237:
																																			goto IL_0ce4;
																																		case 25:
																																		case 257:
																																			goto end_IL_04b1;
																																		case 258:
																																			goto IL_0d15;
																																		case 178:
																																			goto IL_0d3c;
																																		case 15:
																																			goto IL_0d60;
																																		case 65:
																																			goto IL_0d78;
																																		case 259:
																																			goto IL_0d8b;
																																		case 59:
																																		case 133:
																																			goto IL_0d99;
																																		case 54:
																																			goto IL_0dd9;
																																		case 56:
																																			goto IL_0ded;
																																		case 260:
																																			goto IL_0e00;
																																		case 107:
																																			goto IL_0e3f;
																																		case 151:
																																		case 262:
																																			goto IL_0e5b;
																																		case 229:
																																			goto IL_0e84;
																																		case 264:
																																			goto IL_0e9d;
																																		case 265:
																																			goto IL_0eb0;
																																		case 77:
																																		case 266:
																																			goto IL_0ec3;
																																		case 106:
																																			goto IL_0edc;
																																		case 207:
																																			goto IL_0eea;
																																		case 44:
																																			goto IL_0ef8;
																																		case 82:
																																		case 267:
																																			goto IL_0f0b;
																																		case 98:
																																			goto IL_0f29;
																																		case 200:
																																			goto IL_0f37;
																																		case 271:
																																			goto IL_0f4a;
																																		case 261:
																																			goto IL_0f61;
																																		case 272:
																																			goto IL_0f74;
																																		case 124:
																																			goto IL_0f88;
																																		case 281:
																																			goto IL_0f9b;
																																		case 9:
																																			goto IL_0fa9;
																																		case 91:
																																			goto IL_0fb4;
																																		case 5:
																																		case 204:
																																			goto IL_0fc2;
																																		case 165:
																																			goto IL_1016;
																																		case 177:
																																			goto IL_1029;
																																		case 100:
																																			goto IL_1037;
																																		case 68:
																																		case 231:
																																			goto IL_1045;
																																		case 273:
																																			goto IL_105e;
																																		case 227:
																																			goto IL_106c;
																																		case 166:
																																			goto IL_107a;
																																		case 284:
																																			goto IL_108d;
																																		case 285:
																																			goto IL_10a0;
																																		case 104:
																																			goto IL_10ae;
																																		case 24:
																																			goto IL_10bc;
																																		case 121:
																																		case 232:
																																			goto IL_10ca;
																																		case 240:
																																			goto IL_111c;
																																		case 36:
																																		case 275:
																																			goto IL_1138;
																																		case 146:
																																			goto IL_1156;
																																		case 2:
																																			goto IL_1164;
																																		case 31:
																																			goto IL_1172;
																																		case 29:
																																		case 211:
																																			goto IL_1199;
																																		case 21:
																																			goto IL_11ad;
																																		case 127:
																																			goto IL_11ec;
																																		case 75:
																																			goto IL_11ff;
																																		case 224:
																																			goto IL_120d;
																																		case 32:
																																		case 219:
																																			goto IL_121b;
																																		case 135:
																																			goto IL_125b;
																																		case 279:
																																			goto IL_126f;
																																		case 183:
																																			goto IL_1282;
																																		case 67:
																																			goto IL_1290;
																																		case 163:
																																		case 278:
																																			goto IL_129e;
																																		case 277:
																																			goto IL_12ac;
																																		case 16:
																																			goto IL_12d3;
																																		case 37:
																																			goto IL_12e1;
																																		case 234:
																																		case 239:
																																			goto IL_12fd;
																																		case 283:
																																			goto IL_1311;
																																		case 80:
																																			goto IL_135d;
																																		case 242:
																																			goto IL_136b;
																																		case 94:
																																			goto IL_137e;
																																		case 97:
																																			goto IL_138c;
																																		case 71:
																																			goto IL_1397;
																																		case 223:
																																			goto IL_13a5;
																																		case 6:
																																		case 52:
																																			goto IL_13b3;
																																		case 22:
																																			goto IL_13cc;
																																		case 142:
																																		case 173:
																																			goto IL_13df;
																																		case 172:
																																			goto IL_141f;
																																		case 83:
																																			goto IL_143c;
																																		case 254:
																																			goto IL_144c;
																																		case 169:
																																			goto IL_1457;
																																		case 12:
																																		case 191:
																																			goto IL_1462;
																																		case 157:
																																			goto IL_147b;
																																		case 150:
																																			goto IL_148f;
																																		case 4:
																																		case 10:
																																		case 23:
																																		case 33:
																																		case 40:
																																		case 41:
																																		case 42:
																																		case 58:
																																		case 61:
																																		case 73:
																																		case 74:
																																		case 93:
																																		case 108:
																																		case 110:
																																		case 115:
																																		case 117:
																																		case 122:
																																		case 126:
																																		case 143:
																																		case 145:
																																		case 154:
																																		case 158:
																																		case 162:
																																		case 176:
																																		case 184:
																																		case 187:
																																		case 188:
																																		case 195:
																																		case 196:
																																		case 201:
																																		case 202:
																																		case 208:
																																		case 217:
																																		case 226:
																																		case 241:
																																		case 263:
																																		case 270:
																																			goto end_IL_0511;
																																		case 8:
																																		case 13:
																																		case 18:
																																		case 26:
																																		case 43:
																																		case 50:
																																		case 55:
																																		case 63:
																																		case 64:
																																		case 66:
																																		case 79:
																																		case 85:
																																		case 90:
																																		case 111:
																																		case 114:
																																		case 116:
																																		case 120:
																																		case 131:
																																		case 144:
																																		case 164:
																																		case 175:
																																		case 185:
																																		case 186:
																																		case 190:
																																		case 194:
																																		case 198:
																																		case 199:
																																		case 205:
																																		case 221:
																																		case 235:
																																		case 238:
																																		case 268:
																																		case 269:
																																		case 274:
																																		case 276:
																																		case 282:
																																		case 286:
																																			goto IL_14b6;
																																		case 101:
																																			goto IL_14c9;
																																		case 105:
																																			goto IL_14d3;
																																		case 218:
																																			goto IL_14de;
																																		case 167:
																																			goto IL_14ee;
																																		case 70:
																																			goto IL_14fe;
																																		case 27:
																																			goto IL_150e;
																																		case 252:
																																			goto IL_151e;
																																		case 160:
																																			goto IL_152e;
																																		case 249:
																																			goto IL_153e;
																																		case 95:
																																			goto IL_154e;
																																		case 112:
																																			goto IL_155e;
																																		case 225:
																																		case 280:
																																			goto IL_1582;
																																		}
																																		goto end_IL_04f7;
																																	}
																																	if (28 <= b)
																																	{
																																		goto IL_1199;
																																	}
																																	goto IL_11ff;
																																	IL_121b:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	goto IL_125b;
																																	IL_126f:
																																	num6--;
																																	goto IL_14b6;
																																	IL_125b:
																																	array2[num6 - 2] = 3;
																																	goto IL_126f;
																																	IL_1199:
																																	array2[num6 - 1] = 0;
																																	goto IL_11ad;
																																	IL_11ad:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																	goto IL_11ec;
																																	IL_11ec:
																																	ptr2 += 8;
																																	goto IL_14b6;
																																	IL_11ff:
																																	if (27 < b)
																																	{
																																		goto end_IL_0511;
																																	}
																																	goto IL_120d;
																																	IL_120d:
																																	if (27 > b)
																																	{
																																		goto end_IL_0511;
																																	}
																																	goto IL_121b;
																																	continue;
																																	end_IL_04b1:
																																	break;
																																}
																																break;
																															}
																															goto IL_1282;
																															IL_12d3:
																															num6++;
																															goto IL_12e1;
																															IL_12e1:
																															ptr2 += 8;
																															goto IL_14b6;
																															IL_1282:
																															if (29 < b)
																															{
																																goto end_IL_0511;
																															}
																															goto IL_1290;
																															IL_1290:
																															if (29 > b)
																															{
																																goto end_IL_0511;
																															}
																															goto IL_129e;
																															IL_129e:
																															array2[num6] = 5;
																															goto IL_12ac;
																															IL_12ac:
																															array3[num6] = ((delegate*<string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])();
																															num = 16;
																															goto IL_12d3;
																														}
																														break;
																													}
																													num = 239;
																													goto IL_12fd;
																													IL_135d:
																													num6--;
																													goto IL_136b;
																													IL_136b:
																													ptr2 += 8;
																													goto IL_14b6;
																													IL_12fd:
																													array2[num6 - 2] = 5;
																													goto IL_1311;
																													IL_1311:
																													array3[num6 - 2] = ((delegate*<string, string, string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																													goto IL_135d;
																												}
																												break;
																											}
																											goto IL_137e;
																											IL_148f:
																											if (34 <= b)
																											{
																											}
																											goto end_IL_0511;
																											IL_137e:
																											if (32 >= b)
																											{
																												goto IL_138c;
																											}
																											goto IL_144c;
																											IL_138c:
																											if (32 > b)
																											{
																												goto IL_1397;
																											}
																											goto IL_13df;
																											IL_1397:
																											if (31 < b)
																											{
																												goto end_IL_0511;
																											}
																											goto IL_13a5;
																											IL_13a5:
																											if (31 > b)
																											{
																												goto end_IL_0511;
																											}
																											goto IL_13b3;
																											IL_13b3:
																											string_0 = (string)array3[num6 - 1];
																											goto IL_13cc;
																											IL_13cc:
																											num6--;
																											goto IL_14b6;
																											IL_13df:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_141f;
																											IL_141f:
																											array2[num6 - 2] = 3;
																											num = 83;
																											goto IL_143c;
																											IL_143c:
																											num6--;
																											goto IL_14b6;
																											IL_144c:
																											if (33 >= b)
																											{
																												goto IL_1457;
																											}
																											goto IL_147b;
																											IL_1457:
																											if (33 > b)
																											{
																												goto end_IL_0511;
																											}
																											goto IL_1462;
																											IL_1462:
																											num7 = ptr2;
																											num8 = -200;
																											num5 = 1;
																											ptr2 = num7 + num8;
																											goto IL_14b6;
																											IL_147b:
																											if (34 < b)
																											{
																												goto end_IL_0511;
																											}
																											num = 150;
																											goto IL_148f;
																										}
																										goto IL_0cfd;
																									}
																									goto IL_054c;
																									IL_1164:
																									num6++;
																									goto IL_1172;
																									IL_054c:
																									if (26 <= b)
																									{
																										goto IL_0745;
																									}
																									goto IL_089a;
																									IL_0745:
																									array2[num6 - 1] = 3;
																									goto IL_0e00;
																									IL_0e00:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_0e3f;
																									IL_0e3f:
																									ptr2 += 8;
																									num = 63;
																									goto IL_14b6;
																									IL_089a:
																									if (21 >= b)
																									{
																										goto IL_096e;
																									}
																									goto IL_0f9b;
																									IL_096e:
																									if (21 > b)
																									{
																										goto IL_097c;
																									}
																									goto IL_0ca3;
																									IL_097c:
																									if (19 < b)
																									{
																										goto IL_098a;
																									}
																									goto IL_0b41;
																									IL_098a:
																									if (20 < b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_0998;
																									IL_0998:
																									if (20 > b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_0cfd;
																									IL_0cfd:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_14b6;
																									IL_0b41:
																									if (19 <= b)
																									{
																										goto IL_0b4c;
																									}
																									goto IL_0b94;
																									IL_0b4c:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0b65;
																									IL_0b65:
																									array2[num6] = 1;
																									goto IL_0b73;
																									IL_0b73:
																									num6++;
																									goto IL_0b81;
																									IL_0b81:
																									ptr2 += 16;
																									goto IL_14b6;
																									IL_0b94:
																									if (18 < b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_0ba2;
																									IL_0ba2:
																									if (18 > b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_0bb0;
																									IL_0bb0:
																									array2[num6 - 1] = 5;
																									goto IL_0bd9;
																									IL_0bd9:
																									array3[num6 - 1] = ((delegate*<string[], string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_0c11;
																									IL_0c11:
																									ptr2 += 8;
																									goto IL_14b6;
																									IL_0ca3:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																									goto IL_0ce4;
																									IL_0ce4:
																									array2[num6 - 2] = 0;
																									goto IL_0eb0;
																									IL_0eb0:
																									num6--;
																									goto IL_14b6;
																									IL_0f9b:
																									if (23 < b)
																									{
																										goto IL_0fa9;
																									}
																									goto IL_10a0;
																									IL_0fa9:
																									if (24 >= b)
																									{
																										goto IL_0fb4;
																									}
																									goto IL_1029;
																									IL_0fb4:
																									if (24 > b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_0fc2;
																									IL_0fc2:
																									ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_1016;
																									IL_1016:
																									num6--;
																									goto IL_14b6;
																									IL_1029:
																									if (25 < b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_1037;
																									IL_1037:
																									if (25 > b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_1045;
																									IL_1045:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																									goto IL_105e;
																									IL_105e:
																									array2[num6] = 3;
																									goto IL_106c;
																									IL_106c:
																									num6++;
																									goto IL_107a;
																									IL_107a:
																									ptr2 += 16;
																									goto IL_14b6;
																									IL_10a0:
																									if (23 > b)
																									{
																										goto IL_10ae;
																									}
																									num = 275;
																									goto IL_1138;
																									IL_10ae:
																									if (22 < b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_10bc;
																									IL_10bc:
																									if (22 > b)
																									{
																										goto end_IL_0511;
																									}
																									goto IL_10ca;
																									IL_10ca:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_111c;
																									IL_111c:
																									num6--;
																									goto IL_14b6;
																									IL_1172:
																									ptr2 += 8;
																									num = 55;
																									goto IL_14b6;
																									IL_1138:
																									array3[num6] = ((delegate*<string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])();
																									goto IL_1156;
																									IL_1156:
																									array2[num6] = 5;
																									goto IL_1164;
																									continue;
																									end_IL_04f7:
																									break;
																								}
																								break;
																							}
																							goto IL_055f;
																							IL_0d3c:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0d60;
																							IL_055f:
																							if (17 > b)
																							{
																								goto IL_056d;
																							}
																							goto IL_08ad;
																							IL_056d:
																							if (8 >= b)
																							{
																								goto IL_0578;
																							}
																							goto IL_058b;
																							IL_0578:
																							if (8 <= b)
																							{
																								goto IL_0732;
																							}
																							goto IL_077f;
																							IL_0732:
																							num6--;
																							goto IL_14b6;
																							IL_077f:
																							if (4 >= b)
																							{
																								goto IL_078d;
																							}
																							goto IL_0845;
																							IL_078d:
																							if (4 > b)
																							{
																								goto IL_079b;
																							}
																							goto IL_0ac8;
																							IL_079b:
																							if (2 >= b)
																							{
																								goto IL_07a9;
																							}
																							goto IL_0866;
																							IL_07a9:
																							if (2 <= b)
																							{
																								goto IL_07b4;
																							}
																							goto IL_0824;
																							IL_07b4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_07f4;
																							IL_07f4:
																							array2[num6 - 2] = 0;
																							num = 17;
																							goto IL_0811;
																							IL_0811:
																							num6--;
																							goto IL_14b6;
																							IL_0824:
																							if (1 < b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0832;
																							IL_0832:
																							if (1 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0ec3;
																							IL_0ec3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_0edc;
																							IL_0edc:
																							array2[num6] = 0;
																							goto IL_0eea;
																							IL_0eea:
																							num6++;
																							goto IL_0ef8;
																							IL_0ef8:
																							ptr2 += 8;
																							goto IL_14b6;
																							IL_0866:
																							if (3 < b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_09be;
																							IL_09be:
																							if (3 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_09cc;
																							IL_09cc:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0f4a;
																							IL_0f4a:
																							ptr2 += 8;
																							num = 261;
																							goto IL_0f61;
																							IL_0f61:
																							num6--;
																							goto IL_14b6;
																							IL_0ac8:
																							array2[num6] = 0;
																							goto IL_0ad6;
																							IL_0ad6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0af9;
																							IL_0af9:
																							array3[num6] = null;
																							goto IL_0b03;
																							IL_0b03:
																							num6++;
																							goto IL_0bc6;
																							IL_0bc6:
																							ptr2 += 8;
																							goto IL_14b6;
																							IL_0845:
																							if (6 < b)
																							{
																								goto IL_0853;
																							}
																							goto IL_09fa;
																							IL_0853:
																							if (7 < b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_08fe;
																							IL_08fe:
																							if (7 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_090c;
																							IL_090c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_094c;
																							IL_094c:
																							array2[num6 - 2] = 0;
																							num = 264;
																							goto IL_0e9d;
																							IL_0e9d:
																							num6--;
																							goto IL_14b6;
																							IL_09fa:
																							if (6 <= b)
																							{
																								goto IL_0a05;
																							}
																							goto IL_0a5e;
																							IL_0a05:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0a45;
																							IL_0a45:
																							array2[num6 - 2] = 0;
																							goto IL_0c90;
																							IL_0c90:
																							num6--;
																							goto IL_14b6;
																							IL_0a5e:
																							if (5 < b)
																							{
																								goto end_IL_0511;
																							}
																							num = 213;
																							goto IL_0a75;
																							IL_0d60:
																							array3[num6] = array3[num6 - 1];
																							goto IL_0d78;
																							IL_0a75:
																							if (5 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0a83;
																							IL_0a83:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0f74;
																							IL_0f74:
																							array2[num6 - 2] = 0;
																							goto IL_0f88;
																							IL_0f88:
																							num6--;
																							goto IL_14b6;
																							IL_058b:
																							if (12 >= b)
																							{
																								goto IL_0599;
																							}
																							goto IL_075e;
																							IL_0599:
																							if (12 <= b)
																							{
																								goto IL_05a7;
																							}
																							goto IL_0660;
																							IL_05a7:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_05b6;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_067e;
																							IL_0d78:
																							num6++;
																							goto IL_14b6;
																							IL_08ad:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_08eb;
																							IL_08eb:
																							num6 -= 3;
																							goto IL_14b6;
																							IL_067e:
																							array2[num6] = 5;
																							goto IL_068c;
																							IL_068c:
																							num6++;
																							goto IL_14b6;
																							IL_0660:
																							if (10 < b)
																							{
																								goto IL_066b;
																							}
																							goto IL_069f;
																							IL_066b:
																							if (11 < b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_108d;
																							IL_108d:
																							if (11 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_14b6;
																							IL_069f:
																							if (10 > b)
																							{
																								goto IL_06aa;
																							}
																							goto IL_06bd;
																							IL_06aa:
																							if (9 < b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0d8b;
																							IL_0d8b:
																							if (9 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0d99;
																							IL_0d99:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0dd9;
																							IL_0dd9:
																							array2[num6 - 2] = 0;
																							goto IL_0ded;
																							IL_0ded:
																							num6--;
																							goto IL_14b6;
																							IL_06bd:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_071f;
																							IL_071f:
																							num6 -= 2;
																							goto IL_14b6;
																							IL_075e:
																							if (14 >= b)
																							{
																								goto IL_076c;
																							}
																							goto IL_09ab;
																							IL_076c:
																							if (14 > b)
																							{
																								goto IL_0879;
																							}
																							goto IL_0e5b;
																							IL_0e5b:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_0e84;
																							IL_0e84:
																							array2[num6 - 1] = 5;
																							goto IL_14b6;
																							IL_0879:
																							if (13 < b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0887;
																							IL_0887:
																							if (13 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0f0b;
																							IL_0f0b:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_0f29;
																							IL_0f29:
																							ptr2 += 8;
																							goto IL_0f37;
																							IL_0f37:
																							num6--;
																							goto IL_14b6;
																							IL_09ab:
																							if (15 >= b)
																							{
																								goto IL_0b16;
																							}
																							goto IL_0c24;
																							IL_0c24:
																							if (16 < b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0c32;
																							IL_0c32:
																							if (16 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0c40;
																							IL_0c40:
																							array2[num6] = 5;
																							goto IL_0c4e;
																							IL_0c4e:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_0c66;
																							IL_0c66:
																							num6++;
																							goto IL_0c74;
																							IL_0c74:
																							ptr2 += 8;
																							num = 268;
																							goto IL_14b6;
																							IL_0b16:
																							if (15 > b)
																							{
																								goto end_IL_0511;
																							}
																							goto IL_0b24;
																							IL_0b24:
																							array2[num6] = array2[num6 - 1];
																							goto IL_0d15;
																							IL_0d15:
																							array4[num6 - 0] = array4[num6 - 1];
																							num = 178;
																							goto IL_0d3c;
																						}
																						goto end_IL_0521;
																						continue;
																						end_IL_0511:
																						break;
																						IL_0511:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 26;
																				goto IL_14b6;
																				continue;
																				end_IL_0521:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																num = 225;
																goto IL_1582;
																IL_1582:
																return (string)array3[num6 - 1];
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_05b6:
			while (true)
			{
				IL_05b6_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_067e_2:
						array2[num6] = 5;
						while (true)
						{
							IL_068c_2:
							num6++;
							while (true)
							{
								IL_14b6_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_0521_2:
												if (b >= 1)
												{
													while (b <= 34)
													{
														while (true)
														{
															if (17 < b)
															{
																while (true)
																{
																	IL_04f7_2:
																	if (26 < b)
																	{
																		while (true)
																		{
																			IL_04e7_2:
																			if (30 >= b)
																			{
																				while (true)
																				{
																					IL_04d7_2:
																					if (30 > b)
																					{
																						while (true)
																						{
																							IL_04c4_2:
																							if (28 >= b)
																							{
																								num = 293;
																								while (true)
																								{
																									if (num != 293)
																									{
																										if (num != 1274)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 38:
																											goto IL_04c4_2;
																										case 129:
																											goto IL_04d7_2;
																										case 206:
																											goto IL_04e7_2;
																										case 87:
																											goto IL_04f7_2;
																										case 35:
																											goto end_IL_04f7_2;
																										case 78:
																											goto end_IL_0504;
																										case 210:
																											goto IL_0521_2;
																										case 69:
																											goto end_IL_0521_2;
																										case 49:
																										case 182:
																											goto end_IL_0531;
																										case 123:
																											goto IL_054c_2;
																										case 137:
																											goto IL_055f_2;
																										case 20:
																											goto IL_056d_2;
																										case 119:
																											goto IL_0578_2;
																										case 81:
																											goto IL_058b_2;
																										case 72:
																											goto IL_0599_2;
																										case 28:
																										case 76:
																											goto end_IL_0541;
																										case 141:
																											goto IL_0660_2;
																										case 128:
																											goto IL_066b_2;
																										case 147:
																											goto IL_067e_2;
																										case 138:
																											goto IL_068c_2;
																										case 148:
																											goto IL_069f_2;
																										case 0:
																											goto IL_06aa_2;
																										case 7:
																										case 153:
																											goto IL_06bd_2;
																										case 86:
																											goto IL_071f_2;
																										case 48:
																										case 155:
																											goto IL_0732_2;
																										case 3:
																										case 156:
																											goto IL_0745_2;
																										case 168:
																											goto IL_075e_2;
																										case 34:
																											goto IL_076c_2;
																										case 179:
																											goto IL_077f_2;
																										case 140:
																											goto IL_078d_2;
																										case 102:
																											goto IL_079b_2;
																										case 62:
																											goto IL_07a9_2;
																										case 45:
																										case 132:
																											goto IL_07b4_2;
																										case 96:
																											goto IL_07f4_2;
																										case 17:
																											goto IL_0811_2;
																										case 89:
																											goto IL_0824_2;
																										case 60:
																											goto IL_0832_2;
																										case 109:
																											goto IL_0845_2;
																										case 19:
																											goto IL_0853_2;
																										case 181:
																											goto IL_0866_2;
																										case 209:
																											goto IL_0879_2;
																										case 180:
																											goto IL_0887_2;
																										case 212:
																											goto IL_089a_2;
																										case 99:
																										case 214:
																											goto IL_08ad_2;
																										case 189:
																											goto IL_08eb_2;
																										case 215:
																											goto IL_08fe_2;
																										case 149:
																										case 152:
																											goto IL_090c_2;
																										case 216:
																											goto IL_094c_2;
																										case 228:
																											goto IL_096e_2;
																										case 197:
																											goto IL_097c_2;
																										case 92:
																											goto IL_098a_2;
																										case 220:
																											goto IL_0998_2;
																										case 230:
																											goto IL_09ab_2;
																										case 243:
																											goto IL_09be_2;
																										case 11:
																										case 170:
																											goto IL_09cc_2;
																										case 245:
																											goto IL_09fa_2;
																										case 14:
																										case 51:
																											goto IL_0a05_2;
																										case 118:
																											goto IL_0a45_2;
																										case 46:
																											goto IL_0a5e_2;
																										case 213:
																											goto IL_0a75_2;
																										case 88:
																										case 174:
																											goto IL_0a83_2;
																										case 171:
																										case 246:
																											goto IL_0ac8_2;
																										case 134:
																											goto IL_0ad6_2;
																										case 53:
																											goto IL_0af9_2;
																										case 103:
																											goto IL_0b03_2;
																										case 247:
																											goto IL_0b16_2;
																										case 130:
																										case 203:
																											goto IL_0b24_2;
																										case 248:
																											goto IL_0b41_2;
																										case 39:
																										case 139:
																											goto IL_0b4c_2;
																										case 222:
																											goto IL_0b65_2;
																										case 192:
																											goto IL_0b73_2;
																										case 233:
																											goto IL_0b81_2;
																										case 136:
																											goto IL_0b94_2;
																										case 236:
																											goto IL_0ba2_2;
																										case 57:
																										case 161:
																											goto IL_0bb0_2;
																										case 250:
																											goto IL_0bc6_2;
																										case 251:
																											goto IL_0bd9_2;
																										case 193:
																											goto IL_0c11_2;
																										case 253:
																											goto IL_0c24_2;
																										case 30:
																											goto IL_0c32_2;
																										case 47:
																										case 159:
																											goto IL_0c40_2;
																										case 1:
																											goto IL_0c4e_2;
																										case 244:
																											goto IL_0c66_2;
																										case 125:
																											goto IL_0c74_2;
																										case 255:
																											goto IL_0c90_2;
																										case 84:
																										case 256:
																											goto IL_0ca3_2;
																										case 237:
																											goto IL_0ce4_2;
																										case 25:
																										case 257:
																											goto end_IL_04b1_2;
																										case 258:
																											goto IL_0d15_2;
																										case 178:
																											goto IL_0d3c_2;
																										case 15:
																											goto IL_0d60_2;
																										case 65:
																											goto IL_0d78_2;
																										case 259:
																											goto IL_0d8b_2;
																										case 59:
																										case 133:
																											goto IL_0d99_2;
																										case 54:
																											goto IL_0dd9_2;
																										case 56:
																											goto IL_0ded_2;
																										case 260:
																											goto IL_0e00_2;
																										case 107:
																											goto IL_0e3f_2;
																										case 151:
																										case 262:
																											goto IL_0e5b_2;
																										case 229:
																											goto IL_0e84_2;
																										case 264:
																											goto IL_0e9d_2;
																										case 265:
																											goto IL_0eb0_2;
																										case 77:
																										case 266:
																											goto IL_0ec3_2;
																										case 106:
																											goto IL_0edc_2;
																										case 207:
																											goto IL_0eea_2;
																										case 44:
																											goto IL_0ef8_2;
																										case 82:
																										case 267:
																											goto IL_0f0b_2;
																										case 98:
																											goto IL_0f29_2;
																										case 200:
																											goto IL_0f37_2;
																										case 271:
																											goto IL_0f4a_2;
																										case 261:
																											goto IL_0f61_2;
																										case 272:
																											goto IL_0f74_2;
																										case 124:
																											goto IL_0f88_2;
																										case 281:
																											goto IL_0f9b_2;
																										case 9:
																											goto IL_0fa9_2;
																										case 91:
																											goto IL_0fb4_2;
																										case 5:
																										case 204:
																											goto IL_0fc2_2;
																										case 165:
																											goto IL_1016_2;
																										case 177:
																											goto IL_1029_2;
																										case 100:
																											goto IL_1037_2;
																										case 68:
																										case 231:
																											goto IL_1045_2;
																										case 273:
																											goto IL_105e_2;
																										case 227:
																											goto IL_106c_2;
																										case 166:
																											goto IL_107a_2;
																										case 284:
																											goto IL_108d_2;
																										case 285:
																											goto IL_10a0_2;
																										case 104:
																											goto IL_10ae_2;
																										case 24:
																											goto IL_10bc_2;
																										case 121:
																										case 232:
																											goto IL_10ca_2;
																										case 240:
																											goto IL_111c_2;
																										case 36:
																										case 275:
																											goto IL_1138_2;
																										case 146:
																											goto IL_1156_2;
																										case 2:
																											goto IL_1164_2;
																										case 31:
																											goto IL_1172_2;
																										case 29:
																										case 211:
																											goto IL_1199_2;
																										case 21:
																											goto IL_11ad_2;
																										case 127:
																											goto IL_11ec_2;
																										case 75:
																											goto IL_11ff_2;
																										case 224:
																											goto IL_120d_2;
																										case 32:
																										case 219:
																											goto IL_121b_2;
																										case 135:
																											goto IL_125b_2;
																										case 279:
																											goto IL_126f_2;
																										case 183:
																											goto IL_1282_2;
																										case 67:
																											goto IL_1290_2;
																										case 163:
																										case 278:
																											goto IL_129e_2;
																										case 277:
																											goto IL_12ac_2;
																										case 16:
																											goto IL_12d3_2;
																										case 37:
																											goto IL_12e1_2;
																										case 234:
																										case 239:
																											goto IL_12fd_2;
																										case 283:
																											goto IL_1311_2;
																										case 80:
																											goto IL_135d_2;
																										case 242:
																											goto IL_136b_2;
																										case 94:
																											goto IL_137e_2;
																										case 97:
																											goto IL_138c_2;
																										case 71:
																											goto IL_1397_2;
																										case 223:
																											goto IL_13a5_2;
																										case 6:
																										case 52:
																											goto IL_13b3_2;
																										case 22:
																											goto IL_13cc_2;
																										case 142:
																										case 173:
																											goto IL_13df_2;
																										case 172:
																											goto IL_141f_2;
																										case 83:
																											goto IL_143c_2;
																										case 254:
																											goto IL_144c_2;
																										case 169:
																											goto IL_1457_2;
																										case 12:
																										case 191:
																											goto IL_1462_2;
																										case 157:
																											goto IL_147b_2;
																										case 150:
																											goto IL_148f_2;
																										case 4:
																										case 10:
																										case 23:
																										case 33:
																										case 40:
																										case 41:
																										case 42:
																										case 58:
																										case 61:
																										case 73:
																										case 74:
																										case 93:
																										case 108:
																										case 110:
																										case 115:
																										case 117:
																										case 122:
																										case 126:
																										case 143:
																										case 145:
																										case 154:
																										case 158:
																										case 162:
																										case 176:
																										case 184:
																										case 187:
																										case 188:
																										case 195:
																										case 196:
																										case 201:
																										case 202:
																										case 208:
																										case 217:
																										case 226:
																										case 241:
																										case 263:
																										case 270:
																											goto end_IL_0511_2;
																										case 8:
																										case 13:
																										case 18:
																										case 26:
																										case 43:
																										case 50:
																										case 55:
																										case 63:
																										case 64:
																										case 66:
																										case 79:
																										case 85:
																										case 90:
																										case 111:
																										case 114:
																										case 116:
																										case 120:
																										case 131:
																										case 144:
																										case 164:
																										case 175:
																										case 185:
																										case 186:
																										case 190:
																										case 194:
																										case 198:
																										case 199:
																										case 205:
																										case 221:
																										case 235:
																										case 238:
																										case 268:
																										case 269:
																										case 274:
																										case 276:
																										case 282:
																										case 286:
																											goto IL_14b6_2;
																										case 101:
																											ptr2 = ptr;
																											goto IL_14b6_2;
																										case 105:
																											ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemRevisionVersion.OSArchitectureDestination);
																											goto case 101;
																										case 218:
																											array7 = new object[11];
																											goto case 105;
																										case 167:
																											array6 = new long[4];
																											goto case 218;
																										case 70:
																											array5 = new int[7];
																											goto case 167;
																										case 27:
																											array4 = new int[4];
																											goto case 70;
																										case 252:
																											array3 = new object[4];
																											goto case 27;
																										case 160:
																											array2 = new byte[4];
																											goto case 252;
																										case 249:
																											num4 = num2 * 8;
																											goto case 160;
																										case 95:
																											num3 = num2 * 4;
																											goto case 249;
																										case 112:
																											num2 = 1;
																											goto case 95;
																										case 113:
																											goto end_IL_05c4;
																										case 225:
																										case 280:
																											goto IL_1582_2;
																										}
																										continue;
																									}
																									if (28 <= b)
																									{
																										goto IL_1199_2;
																									}
																									goto IL_11ff_2;
																									IL_121b_2:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_125b_2;
																									IL_126f_2:
																									num6--;
																									goto IL_14b6_2;
																									IL_125b_2:
																									array2[num6 - 2] = 3;
																									goto IL_126f_2;
																									IL_1199_2:
																									array2[num6 - 1] = 0;
																									goto IL_11ad_2;
																									IL_11ad_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_11ec_2;
																									IL_11ec_2:
																									ptr2 += 8;
																									goto IL_14b6_2;
																									IL_11ff_2:
																									if (27 < b)
																									{
																										goto end_IL_0511_2;
																									}
																									goto IL_120d_2;
																									IL_120d_2:
																									if (27 > b)
																									{
																										goto end_IL_0511_2;
																									}
																									goto IL_121b_2;
																									continue;
																									end_IL_04b1_2:
																									break;
																								}
																								break;
																							}
																							goto IL_1282_2;
																							IL_12d3_2:
																							num6++;
																							goto IL_12e1_2;
																							IL_12e1_2:
																							ptr2 += 8;
																							goto IL_14b6_2;
																							IL_1282_2:
																							if (29 < b)
																							{
																								goto end_IL_0511_2;
																							}
																							goto IL_1290_2;
																							IL_1290_2:
																							if (29 > b)
																							{
																								goto end_IL_0511_2;
																							}
																							goto IL_129e_2;
																							IL_129e_2:
																							array2[num6] = 5;
																							goto IL_12ac_2;
																							IL_12ac_2:
																							array3[num6] = ((delegate*<string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])();
																							num = 16;
																							goto IL_12d3_2;
																						}
																						break;
																					}
																					num = 239;
																					goto IL_12fd_2;
																					IL_135d_2:
																					num6--;
																					goto IL_136b_2;
																					IL_136b_2:
																					ptr2 += 8;
																					goto IL_14b6_2;
																					IL_12fd_2:
																					array2[num6 - 2] = 5;
																					goto IL_1311_2;
																					IL_1311_2:
																					array3[num6 - 2] = ((delegate*<string, string, string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																					goto IL_135d_2;
																				}
																				break;
																			}
																			goto IL_137e_2;
																			IL_148f_2:
																			if (34 <= b)
																			{
																			}
																			goto end_IL_0511_2;
																			IL_137e_2:
																			if (32 >= b)
																			{
																				goto IL_138c_2;
																			}
																			goto IL_144c_2;
																			IL_138c_2:
																			if (32 > b)
																			{
																				goto IL_1397_2;
																			}
																			goto IL_13df_2;
																			IL_1397_2:
																			if (31 < b)
																			{
																				goto end_IL_0511_2;
																			}
																			goto IL_13a5_2;
																			IL_13a5_2:
																			if (31 > b)
																			{
																				goto end_IL_0511_2;
																			}
																			goto IL_13b3_2;
																			IL_13b3_2:
																			string_0 = (string)array3[num6 - 1];
																			goto IL_13cc_2;
																			IL_13cc_2:
																			num6--;
																			goto IL_14b6_2;
																			IL_13df_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_141f_2;
																			IL_141f_2:
																			array2[num6 - 2] = 3;
																			num = 83;
																			goto IL_143c_2;
																			IL_143c_2:
																			num6--;
																			goto IL_14b6_2;
																			IL_144c_2:
																			if (33 >= b)
																			{
																				goto IL_1457_2;
																			}
																			goto IL_147b_2;
																			IL_1457_2:
																			if (33 > b)
																			{
																				goto end_IL_0511_2;
																			}
																			goto IL_1462_2;
																			IL_1462_2:
																			num7 = ptr2;
																			num8 = -200;
																			num5 = 1;
																			ptr2 = num7 + num8;
																			goto IL_14b6_2;
																			IL_147b_2:
																			if (34 < b)
																			{
																				goto end_IL_0511_2;
																			}
																			num = 150;
																			goto IL_148f_2;
																		}
																		goto IL_0cfd_2;
																	}
																	goto IL_054c_2;
																	IL_1164_2:
																	num6++;
																	goto IL_1172_2;
																	IL_054c_2:
																	if (26 <= b)
																	{
																		goto IL_0745_2;
																	}
																	goto IL_089a_2;
																	IL_0745_2:
																	array2[num6 - 1] = 3;
																	goto IL_0e00_2;
																	IL_0e00_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_0e3f_2;
																	IL_0e3f_2:
																	ptr2 += 8;
																	num = 63;
																	goto IL_14b6_2;
																	IL_089a_2:
																	if (21 >= b)
																	{
																		goto IL_096e_2;
																	}
																	goto IL_0f9b_2;
																	IL_096e_2:
																	if (21 > b)
																	{
																		goto IL_097c_2;
																	}
																	goto IL_0ca3_2;
																	IL_097c_2:
																	if (19 < b)
																	{
																		goto IL_098a_2;
																	}
																	goto IL_0b41_2;
																	IL_098a_2:
																	if (20 < b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_0998_2;
																	IL_0998_2:
																	if (20 > b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_0cfd_2;
																	IL_0cfd_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_14b6_2;
																	IL_0b41_2:
																	if (19 <= b)
																	{
																		goto IL_0b4c_2;
																	}
																	goto IL_0b94_2;
																	IL_0b4c_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																	goto IL_0b65_2;
																	IL_0b65_2:
																	array2[num6] = 1;
																	goto IL_0b73_2;
																	IL_0b73_2:
																	num6++;
																	goto IL_0b81_2;
																	IL_0b81_2:
																	ptr2 += 16;
																	goto IL_14b6_2;
																	IL_0b94_2:
																	if (18 < b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_0ba2_2;
																	IL_0ba2_2:
																	if (18 > b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_0bb0_2;
																	IL_0bb0_2:
																	array2[num6 - 1] = 5;
																	goto IL_0bd9_2;
																	IL_0bd9_2:
																	array3[num6 - 1] = ((delegate*<string[], string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																	goto IL_0c11_2;
																	IL_0c11_2:
																	ptr2 += 8;
																	goto IL_14b6_2;
																	IL_0ca3_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																	goto IL_0ce4_2;
																	IL_0ce4_2:
																	array2[num6 - 2] = 0;
																	goto IL_0eb0_2;
																	IL_0eb0_2:
																	num6--;
																	goto IL_14b6_2;
																	IL_0f9b_2:
																	if (23 < b)
																	{
																		goto IL_0fa9_2;
																	}
																	goto IL_10a0_2;
																	IL_0fa9_2:
																	if (24 >= b)
																	{
																		goto IL_0fb4_2;
																	}
																	goto IL_1029_2;
																	IL_0fb4_2:
																	if (24 > b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_0fc2_2;
																	IL_0fc2_2:
																	ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_1016_2;
																	IL_1016_2:
																	num6--;
																	goto IL_14b6_2;
																	IL_1029_2:
																	if (25 < b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_1037_2;
																	IL_1037_2:
																	if (25 > b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_1045_2;
																	IL_1045_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																	goto IL_105e_2;
																	IL_105e_2:
																	array2[num6] = 3;
																	goto IL_106c_2;
																	IL_106c_2:
																	num6++;
																	goto IL_107a_2;
																	IL_107a_2:
																	ptr2 += 16;
																	goto IL_14b6_2;
																	IL_10a0_2:
																	if (23 > b)
																	{
																		goto IL_10ae_2;
																	}
																	num = 275;
																	goto IL_1138_2;
																	IL_10ae_2:
																	if (22 < b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_10bc_2;
																	IL_10bc_2:
																	if (22 > b)
																	{
																		goto end_IL_0511_2;
																	}
																	goto IL_10ca_2;
																	IL_10ca_2:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_111c_2;
																	IL_111c_2:
																	num6--;
																	goto IL_14b6_2;
																	IL_1172_2:
																	ptr2 += 8;
																	num = 55;
																	goto IL_14b6_2;
																	IL_1138_2:
																	array3[num6] = ((delegate*<string>)getAccountDomainSidCreateText[*(int*)(ptr2 + num3)])();
																	goto IL_1156_2;
																	IL_1156_2:
																	array2[num6] = 5;
																	goto IL_1164_2;
																	continue;
																	end_IL_04f7_2:
																	break;
																}
																continue;
															}
															goto IL_055f_2;
															IL_08ad_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															goto IL_08eb_2;
															IL_055f_2:
															if (17 > b)
															{
																goto IL_056d_2;
															}
															goto IL_08ad_2;
															IL_056d_2:
															if (8 >= b)
															{
																goto IL_0578_2;
															}
															goto IL_058b_2;
															IL_0578_2:
															if (8 <= b)
															{
																goto IL_0732_2;
															}
															goto IL_077f_2;
															IL_0732_2:
															num6--;
															goto IL_14b6_2;
															IL_077f_2:
															if (4 >= b)
															{
																goto IL_078d_2;
															}
															goto IL_0845_2;
															IL_078d_2:
															if (4 > b)
															{
																goto IL_079b_2;
															}
															goto IL_0ac8_2;
															IL_079b_2:
															if (2 >= b)
															{
																goto IL_07a9_2;
															}
															goto IL_0866_2;
															IL_07a9_2:
															if (2 <= b)
															{
																goto IL_07b4_2;
															}
															goto IL_0824_2;
															IL_07b4_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_07f4_2;
															IL_07f4_2:
															array2[num6 - 2] = 0;
															num = 17;
															goto IL_0811_2;
															IL_0811_2:
															num6--;
															goto IL_14b6_2;
															IL_0824_2:
															if (1 < b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0832_2;
															IL_0832_2:
															if (1 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0ec3_2;
															IL_0ec3_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_0edc_2;
															IL_0edc_2:
															array2[num6] = 0;
															goto IL_0eea_2;
															IL_0eea_2:
															num6++;
															goto IL_0ef8_2;
															IL_0ef8_2:
															ptr2 += 8;
															goto IL_14b6_2;
															IL_0866_2:
															if (3 < b)
															{
																goto end_IL_0511_2;
															}
															goto IL_09be_2;
															IL_09be_2:
															if (3 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_09cc_2;
															IL_09cc_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0f4a_2;
															IL_0f4a_2:
															ptr2 += 8;
															num = 261;
															goto IL_0f61_2;
															IL_0f61_2:
															num6--;
															goto IL_14b6_2;
															IL_0ac8_2:
															array2[num6] = 0;
															goto IL_0ad6_2;
															IL_0ad6_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0af9_2;
															IL_0af9_2:
															array3[num6] = null;
															goto IL_0b03_2;
															IL_0b03_2:
															num6++;
															goto IL_0bc6_2;
															IL_0bc6_2:
															ptr2 += 8;
															goto IL_14b6_2;
															IL_0845_2:
															if (6 < b)
															{
																goto IL_0853_2;
															}
															goto IL_09fa_2;
															IL_0853_2:
															if (7 < b)
															{
																goto end_IL_0511_2;
															}
															goto IL_08fe_2;
															IL_08fe_2:
															if (7 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_090c_2;
															IL_090c_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_094c_2;
															IL_094c_2:
															array2[num6 - 2] = 0;
															num = 264;
															goto IL_0e9d_2;
															IL_0e9d_2:
															num6--;
															goto IL_14b6_2;
															IL_09fa_2:
															if (6 <= b)
															{
																goto IL_0a05_2;
															}
															goto IL_0a5e_2;
															IL_0a05_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0a45_2;
															IL_0a45_2:
															array2[num6 - 2] = 0;
															goto IL_0c90_2;
															IL_0c90_2:
															num6--;
															goto IL_14b6_2;
															IL_0a5e_2:
															if (5 < b)
															{
																goto end_IL_0511_2;
															}
															num = 213;
															goto IL_0a75_2;
															IL_08eb_2:
															num6 -= 3;
															goto IL_14b6_2;
															IL_0a75_2:
															if (5 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0a83_2;
															IL_0a83_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0f74_2;
															IL_0f74_2:
															array2[num6 - 2] = 0;
															goto IL_0f88_2;
															IL_0f88_2:
															num6--;
															goto IL_14b6_2;
															IL_058b_2:
															if (12 >= b)
															{
																goto IL_0599_2;
															}
															goto IL_075e_2;
															IL_0599_2:
															if (12 <= b)
															{
																goto end_IL_0541;
															}
															goto IL_0660_2;
															IL_0660_2:
															if (10 < b)
															{
																goto IL_066b_2;
															}
															goto IL_069f_2;
															IL_066b_2:
															if (11 < b)
															{
																goto end_IL_0511_2;
															}
															goto IL_108d_2;
															IL_108d_2:
															if (11 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_14b6_2;
															IL_069f_2:
															if (10 > b)
															{
																goto IL_06aa_2;
															}
															goto IL_06bd_2;
															IL_06aa_2:
															if (9 < b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0d8b_2;
															IL_0d8b_2:
															if (9 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0d99_2;
															IL_0d99_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0dd9_2;
															IL_0dd9_2:
															array2[num6 - 2] = 0;
															goto IL_0ded_2;
															IL_0ded_2:
															num6--;
															goto IL_14b6_2;
															IL_06bd_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_071f_2;
															IL_071f_2:
															num6 -= 2;
															goto IL_14b6_2;
															IL_075e_2:
															if (14 >= b)
															{
																goto IL_076c_2;
															}
															goto IL_09ab_2;
															IL_076c_2:
															if (14 > b)
															{
																goto IL_0879_2;
															}
															goto IL_0e5b_2;
															IL_0e5b_2:
															array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_0e84_2;
															IL_0e84_2:
															array2[num6 - 1] = 5;
															goto IL_14b6_2;
															IL_0879_2:
															if (13 < b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0887_2;
															IL_0887_2:
															if (13 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0f0b_2;
															IL_0f0b_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_0f29_2;
															IL_0f29_2:
															ptr2 += 8;
															goto IL_0f37_2;
															IL_0f37_2:
															num6--;
															goto IL_14b6_2;
															IL_09ab_2:
															if (15 >= b)
															{
																goto IL_0b16_2;
															}
															goto IL_0c24_2;
															IL_0c24_2:
															if (16 < b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0c32_2;
															IL_0c32_2:
															if (16 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0c40_2;
															IL_0c40_2:
															array2[num6] = 5;
															goto IL_0c4e_2;
															IL_0c4e_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_0c66_2;
															IL_0c66_2:
															num6++;
															goto IL_0c74_2;
															IL_0c74_2:
															ptr2 += 8;
															num = 268;
															goto IL_14b6_2;
															IL_0b16_2:
															if (15 > b)
															{
																goto end_IL_0511_2;
															}
															goto IL_0b24_2;
															IL_0b24_2:
															array2[num6] = array2[num6 - 1];
															goto IL_0d15_2;
															IL_0d15_2:
															array4[num6 - 0] = array4[num6 - 1];
															num = 178;
															goto IL_0d3c_2;
															IL_0d3c_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0d60_2;
															IL_0d60_2:
															array3[num6] = array3[num6 - 1];
															goto IL_0d78_2;
															IL_0d78_2:
															num6++;
															goto IL_14b6_2;
															continue;
															end_IL_0504:
															break;
														}
														continue;
														end_IL_0511_2:
														break;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 26;
												goto IL_14b6_2;
												continue;
												end_IL_0521_2:
												break;
											}
											continue;
											end_IL_0531:
											break;
										}
										continue;
										end_IL_0541:
										break;
									}
									break;
								}
								num = 225;
								goto IL_1582_2;
								IL_1582_2:
								return (string)array3[num6 - 1];
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_05b6_2;
					}
					continue;
					end_IL_05c4:
					break;
				}
				break;
			}
		}
	}

	private static void smethod_1()
	{
		int num = 403;
		num = 31;
		num = 91;
		num = 13;
		num = 31;
		num = 18;
		num = 31;
		num = 31;
		num = 110;
		num = 22;
		num = 380;
		num = 76;
		num = 22;
		num = 98;
		num = 1770;
		num = 1770;
		num = 1801;
		num = 330;
		num = 110;
		if (bool_1)
		{
			return;
		}
		num = 1;
		bool_1 = true;
		try
		{
			string text = smethod_0();
			object obj = text;
			global::_003CModule_003E.string_12 = (string)obj;
			obj = global::_003CModule_003E.string_12;
			if (!File.Exists((string)obj))
			{
				return;
			}
			obj = global::_003CModule_003E.string_12;
			string[] array = File.ReadAllLines((string)obj);
			obj = array;
			global::_003CModule_003E.string_13 = (string[])obj;
			obj = global::_003CModule_003E.string_13;
			IntPtr intPtr = (nint)((string[])obj).LongLength;
			if (intPtr != (IntPtr)0)
			{
				obj = global::_003CModule_003E.string_13;
				obj = ((string[])obj)[0];
				if (bool.TryParse((string)obj, out global::_003CModule_003E.bool_20))
				{
					num = (global::_003CModule_003E.bool_20 ? 1 : 0);
					bool_0 = (byte)num != 0;
				}
			}
		}
		catch
		{
		}
	}

	public unsafe static void smethod_2()
	{
		int num = 218;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 123;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 160;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OverflowExceptionTrustedComputingBase.CMSHASHTRANSFORMMANIFESTINVARIANTTokenElevationType);
											num = 99;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 == 1)
													{
														return;
													}
													while (true)
													{
														IL_04fb:
														num = 113;
														while (true)
														{
															IL_04f0:
															byte b = *ptr2;
															while (true)
															{
																IL_04e0:
																ptr2++;
																while (true)
																{
																	IL_04d0:
																	if (b >= 1)
																	{
																		while (b <= 27)
																		{
																			num = 105;
																			while (true)
																			{
																				IL_04ad:
																				if (14 >= b)
																				{
																					while (true)
																					{
																						IL_049d:
																						if (14 > b)
																						{
																							while (true)
																							{
																								IL_048d:
																								if (7 < b)
																								{
																									while (true)
																									{
																										IL_047d:
																										if (10 >= b)
																										{
																											while (true)
																											{
																												IL_046d:
																												if (10 > b)
																												{
																													while (true)
																													{
																														IL_045d:
																														if (8 < b)
																														{
																															while (9 >= b)
																															{
																																while (9 <= b)
																																{
																																	while (true)
																																	{
																																		IL_03fb:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																		while (true)
																																		{
																																			IL_03e5:
																																			array[num6 - 2] = 0;
																																			while (true)
																																			{
																																				IL_03cc:
																																				num6--;
																																				num = 231;
																																				while (num != 231)
																																				{
																																					if (num != 1212)
																																					{
																																						goto end_IL_043d;
																																					}
																																					switch (num)
																																					{
																																					case 36:
																																						goto IL_03cc;
																																					case 204:
																																						goto IL_03e5;
																																					case 45:
																																					case 214:
																																						goto IL_03fb;
																																					case 119:
																																						goto IL_043d;
																																					case 139:
																																						goto IL_044d;
																																					case 60:
																																						goto IL_045d;
																																					case 178:
																																						goto IL_046d;
																																					case 2:
																																						goto IL_047d;
																																					case 162:
																																						goto IL_048d;
																																					case 206:
																																						goto IL_049d;
																																					case 105:
																																						goto IL_04ad;
																																					case 20:
																																						goto IL_04bd;
																																					case 66:
																																						goto IL_04d0;
																																					case 12:
																																						goto IL_04e0;
																																					case 113:
																																						goto IL_04f0;
																																					case 158:
																																						goto IL_04fb;
																																					case 91:
																																						goto IL_0506;
																																					case 82:
																																					case 149:
																																						goto IL_0516;
																																					case 49:
																																						goto IL_0578;
																																					case 69:
																																					case 152:
																																						goto IL_058b;
																																					case 182:
																																						goto IL_059e;
																																					case 61:
																																					case 153:
																																						goto IL_05a9;
																																					case 125:
																																						goto IL_05e9;
																																					case 73:
																																						goto IL_05fd;
																																					case 54:
																																						goto IL_0610;
																																					case 129:
																																						goto IL_061e;
																																					case 30:
																																					case 135:
																																						goto IL_0629;
																																					case 75:
																																						goto IL_0652;
																																					case 77:
																																						goto IL_0660;
																																					case 9:
																																						goto IL_0673;
																																					case 64:
																																						goto IL_067e;
																																					case 23:
																																					case 157:
																																						goto IL_068c;
																																					case 98:
																																						goto IL_06a5;
																																					case 145:
																																						goto IL_06b3;
																																					case 58:
																																						goto IL_06c1;
																																					case 144:
																																						goto IL_06d4;
																																					case 25:
																																						goto IL_06e2;
																																					case 57:
																																					case 101:
																																						goto IL_06f0;
																																					case 122:
																																						goto IL_0730;
																																					case 154:
																																						goto IL_0744;
																																					case 167:
																																						goto IL_0757;
																																					case 19:
																																						goto IL_0762;
																																					case 127:
																																					case 168:
																																						goto IL_0770;
																																					case 15:
																																						goto IL_07be;
																																					case 31:
																																						goto IL_07d5;
																																					case 177:
																																					case 197:
																																						goto IL_07e5;
																																					case 35:
																																						goto IL_0826;
																																					case 51:
																																						goto IL_083a;
																																					case 111:
																																					case 198:
																																						goto IL_084d;
																																					case 24:
																																						goto IL_088d;
																																					case 114:
																																						goto IL_08a1;
																																					case 210:
																																						goto IL_08b4;
																																					case 33:
																																						goto IL_08c8;
																																					case 220:
																																						goto IL_08db;
																																					case 13:
																																						goto IL_08f2;
																																					case 132:
																																					case 180:
																																						goto IL_0900;
																																					case 5:
																																						goto IL_090e;
																																					case 4:
																																						goto IL_0931;
																																					case 155:
																																						goto IL_093b;
																																					case 183:
																																						goto IL_0949;
																																					case 76:
																																						goto IL_095c;
																																					case 53:
																																						goto IL_0967;
																																					case 128:
																																						goto IL_0972;
																																					case 14:
																																						goto IL_0980;
																																					case 38:
																																					case 221:
																																						goto IL_0993;
																																					case 34:
																																						goto IL_09ac;
																																					case 39:
																																						goto IL_09ba;
																																					case 46:
																																						goto IL_09d1;
																																					case 219:
																																						goto IL_09e4;
																																					case 21:
																																						goto IL_09f2;
																																					case 141:
																																					case 199:
																																						goto IL_0a00;
																																					case 102:
																																						goto IL_0a18;
																																					case 90:
																																						goto IL_0a26;
																																					case 11:
																																						goto IL_0a34;
																																					case 0:
																																						goto IL_0a42;
																																					case 86:
																																					case 190:
																																						goto IL_0a4d;
																																					case 159:
																																						goto IL_0a66;
																																					case 118:
																																						goto IL_0a74;
																																					case 48:
																																						goto IL_0a82;
																																					case 133:
																																						goto IL_0a95;
																																					case 108:
																																						goto IL_0aa0;
																																					case 187:
																																					case 191:
																																						goto IL_0aae;
																																					case 184:
																																						goto IL_0b00;
																																					case 47:
																																						goto IL_0b13;
																																					case 85:
																																						goto IL_0b2a;
																																					case 110:
																																					case 202:
																																						goto IL_0b38;
																																					case 130:
																																						goto IL_0b4d;
																																					case 72:
																																						goto IL_0b60;
																																					case 193:
																																						goto IL_0b6e;
																																					case 156:
																																						goto IL_0b7c;
																																					case 140:
																																						goto IL_0b93;
																																					case 62:
																																					case 200:
																																						goto IL_0ba1;
																																					case 189:
																																						goto IL_0bb5;
																																					case 63:
																																						goto IL_0bf4;
																																					case 22:
																																					case 213:
																																						goto IL_0c07;
																																					case 171:
																																						goto IL_0c47;
																																					case 151:
																																						goto IL_0c5b;
																																					case 131:
																																						goto IL_0c6e;
																																					case 8:
																																						goto IL_0c7c;
																																					case 78:
																																					case 137:
																																						goto IL_0c8a;
																																					case 186:
																																						goto IL_0c9e;
																																					case 83:
																																						goto IL_0cdd;
																																					case 80:
																																					case 161:
																																						goto IL_0cf0;
																																					case 222:
																																						goto IL_0d05;
																																					case 89:
																																						goto IL_0d18;
																																					case 1:
																																						goto IL_0d26;
																																					case 10:
																																					case 181:
																																						goto IL_0d31;
																																					case 68:
																																						goto IL_0d4b;
																																					case 194:
																																						goto IL_0d67;
																																					case 169:
																																						goto IL_0d72;
																																					case 165:
																																					case 223:
																																						goto IL_0d80;
																																					case 115:
																																						goto IL_0d94;
																																					case 208:
																																						goto IL_0dd3;
																																					case 96:
																																						goto IL_0de6;
																																					case 106:
																																						goto IL_0df4;
																																					case 44:
																																					case 112:
																																						goto IL_0e02;
																																					case 92:
																																						goto IL_0e26;
																																					case 136:
																																						goto IL_0e34;
																																					case 74:
																																						goto IL_0e42;
																																					case 175:
																																						goto IL_0e55;
																																					case 87:
																																						goto IL_0e63;
																																					case 134:
																																					case 192:
																																						goto IL_0e6e;
																																					case 28:
																																						goto IL_0e8a;
																																					case 126:
																																						goto IL_0e98;
																																					case 79:
																																					case 109:
																																						goto IL_0ea3;
																																					case 16:
																																						goto IL_0ee3;
																																					case 42:
																																						goto IL_0ef7;
																																					case 40:
																																						goto IL_0f07;
																																					case 103:
																																						goto IL_0f12;
																																					case 6:
																																					case 7:
																																					case 18:
																																					case 26:
																																					case 27:
																																					case 29:
																																					case 37:
																																					case 50:
																																					case 52:
																																					case 56:
																																					case 67:
																																					case 81:
																																					case 94:
																																					case 95:
																																					case 120:
																																					case 124:
																																					case 142:
																																					case 147:
																																					case 150:
																																					case 170:
																																					case 176:
																																					case 185:
																																					case 188:
																																					case 201:
																																					case 203:
																																					case 207:
																																					case 211:
																																					case 212:
																																					case 215:
																																					case 216:
																																						goto end_IL_043d;
																																					case 3:
																																					case 32:
																																					case 41:
																																					case 43:
																																					case 55:
																																					case 59:
																																					case 65:
																																					case 70:
																																					case 71:
																																					case 88:
																																					case 93:
																																					case 97:
																																					case 100:
																																					case 107:
																																					case 116:
																																					case 117:
																																					case 138:
																																					case 143:
																																					case 146:
																																					case 148:
																																					case 163:
																																					case 166:
																																					case 172:
																																					case 173:
																																					case 195:
																																					case 196:
																																					case 205:
																																					case 209:
																																					case 224:
																																						goto end_IL_03b9;
																																					case 99:
																																						goto end_IL_0f30;
																																					case 179:
																																						goto end_IL_0f43;
																																					case 164:
																																						goto end_IL_0f4d;
																																					case 160:
																																						goto end_IL_0f61;
																																					case 84:
																																						goto end_IL_0f71;
																																					case 121:
																																						goto end_IL_0f81;
																																					case 174:
																																						goto end_IL_0f8c;
																																					case 123:
																																						goto end_IL_0f9c;
																																					case 217:
																																						goto end_IL_0fac;
																																					case 218:
																																						goto end_IL_0fbc;
																																					case 17:
																																					case 104:
																																						return;
																																					}
																																					continue;
																																					end_IL_03b9:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	goto end_IL_04d0;
																																	continue;
																																	end_IL_043d:
																																	break;
																																	IL_043d:;
																																}
																																break;
																																IL_044d:;
																															}
																															break;
																														}
																														goto IL_0506;
																														IL_058b:
																														num6--;
																														goto end_IL_04d0;
																														IL_0506:
																														if (8 > b)
																														{
																															break;
																														}
																														goto IL_058b;
																													}
																													break;
																												}
																												goto IL_0516;
																												IL_0578:
																												num6 -= 2;
																												goto end_IL_04d0;
																												IL_0516:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0578;
																											}
																											break;
																										}
																										goto IL_095c;
																										IL_0a00:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_04d0;
																										IL_095c:
																										if (12 >= b)
																										{
																											goto IL_0967;
																										}
																										goto IL_09e4;
																										IL_0967:
																										if (12 > b)
																										{
																											goto IL_0972;
																										}
																										goto IL_0993;
																										IL_0972:
																										if (11 < b)
																										{
																											break;
																										}
																										goto IL_0980;
																										IL_0980:
																										if (11 > b)
																										{
																											break;
																										}
																										goto end_IL_04d0;
																										IL_0993:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																										goto IL_09ac;
																										IL_09ac:
																										array[num6] = 1;
																										goto IL_09ba;
																										IL_09ba:
																										num6++;
																										num = 46;
																										goto IL_09d1;
																										IL_09d1:
																										ptr2 += 16;
																										goto end_IL_04d0;
																										IL_09e4:
																										if (13 < b)
																										{
																											break;
																										}
																										goto IL_09f2;
																										IL_09f2:
																										if (13 > b)
																										{
																											break;
																										}
																										goto IL_0a00;
																									}
																									break;
																								}
																								goto IL_059e;
																								IL_084d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_088d;
																								IL_059e:
																								if (7 <= b)
																								{
																									goto IL_05a9;
																								}
																								goto IL_0610;
																								IL_05a9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_05e9;
																								IL_05e9:
																								array[num6 - 2] = 0;
																								goto IL_05fd;
																								IL_05fd:
																								num6--;
																								goto end_IL_04d0;
																								IL_0610:
																								if (3 >= b)
																								{
																									goto IL_061e;
																								}
																								goto IL_0757;
																								IL_061e:
																								if (3 <= b)
																								{
																									goto IL_0629;
																								}
																								goto IL_0673;
																								IL_0629:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0652;
																								IL_0652:
																								ptr2 += 8;
																								goto IL_0660;
																								IL_0660:
																								num6--;
																								goto end_IL_04d0;
																								IL_0673:
																								if (1 >= b)
																								{
																									goto IL_067e;
																								}
																								goto IL_06d4;
																								IL_067e:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_068c;
																								IL_068c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																								goto IL_06a5;
																								IL_06a5:
																								array[num6] = 0;
																								goto IL_06b3;
																								IL_06b3:
																								num6++;
																								goto IL_06c1;
																								IL_06c1:
																								ptr2 += 8;
																								goto end_IL_04d0;
																								IL_06d4:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_06e2;
																								IL_06e2:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_06f0;
																								IL_06f0:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0730;
																								IL_0730:
																								array[num6 - 2] = 0;
																								goto IL_0744;
																								IL_0744:
																								num6--;
																								goto end_IL_04d0;
																								IL_0757:
																								if (5 >= b)
																								{
																									goto IL_0762;
																								}
																								goto IL_07be;
																								IL_0762:
																								if (5 <= b)
																								{
																									goto IL_0770;
																								}
																								goto IL_08db;
																								IL_0770:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								num = 210;
																								goto IL_08b4;
																								IL_08b4:
																								array[num6 - 2] = 0;
																								goto IL_08c8;
																								IL_08c8:
																								num6--;
																								goto end_IL_04d0;
																								IL_08db:
																								if (4 < b)
																								{
																									break;
																								}
																								num = 13;
																								goto IL_08f2;
																								IL_088d:
																								array[num6 - 2] = 0;
																								goto IL_08a1;
																								IL_08f2:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0900;
																								IL_0900:
																								array[num6] = 0;
																								goto IL_090e;
																								IL_090e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0931;
																								IL_0931:
																								array2[num6] = null;
																								goto IL_093b;
																								IL_093b:
																								num6++;
																								goto IL_0949;
																								IL_0949:
																								ptr2 += 8;
																								goto end_IL_04d0;
																								IL_07be:
																								if (6 < b)
																								{
																									break;
																								}
																								num = 31;
																								goto IL_07d5;
																								IL_08a1:
																								num6--;
																								goto end_IL_04d0;
																								IL_07d5:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_084d;
																							}
																							break;
																						}
																						goto IL_07e5;
																						IL_083a:
																						num6--;
																						goto end_IL_04d0;
																						IL_07e5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_0826;
																						IL_0826:
																						array[num6 - 2] = 0;
																						goto IL_083a;
																					}
																					break;
																				}
																				goto IL_0a18;
																				IL_0ef7:
																				num6--;
																				goto end_IL_04d0;
																				IL_0a18:
																				if (21 >= b)
																				{
																					goto IL_0a26;
																				}
																				goto IL_0d18;
																				IL_0a26:
																				if (21 > b)
																				{
																					goto IL_0a34;
																				}
																				goto IL_0cf0;
																				IL_0a34:
																				if (17 >= b)
																				{
																					goto IL_0a42;
																				}
																				goto IL_0b60;
																				IL_0a42:
																				if (17 <= b)
																				{
																					goto IL_0a4d;
																				}
																				goto IL_0a95;
																				IL_0a4d:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_0a66;
																				IL_0a66:
																				array[num6] = 3;
																				goto IL_0a74;
																				IL_0a74:
																				num6++;
																				goto IL_0a82;
																				IL_0a82:
																				ptr2 += 16;
																				goto end_IL_04d0;
																				IL_0a95:
																				if (15 >= b)
																				{
																					goto IL_0aa0;
																				}
																				goto IL_0b13;
																				IL_0aa0:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_0aae;
																				IL_0aae:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0b00;
																				IL_0b00:
																				num6--;
																				goto end_IL_04d0;
																				IL_0b13:
																				if (16 < b)
																				{
																					break;
																				}
																				num = 85;
																				goto IL_0b2a;
																				IL_0f07:
																				if (27 < b)
																				{
																					break;
																				}
																				goto IL_0f12;
																				IL_0b2a:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_0b38;
																				IL_0b38:
																				((delegate*<void>)IgnorePortablePDBsInStackTracesILGenerator[*(int*)(ptr2 + num3)])();
																				goto IL_0b4d;
																				IL_0b4d:
																				ptr2 += 8;
																				goto end_IL_04d0;
																				IL_0b60:
																				if (19 >= b)
																				{
																					goto IL_0b6e;
																				}
																				goto IL_0c6e;
																				IL_0b6e:
																				if (19 > b)
																				{
																					goto IL_0b7c;
																				}
																				goto IL_0c07;
																				IL_0b7c:
																				if (18 < b)
																				{
																					break;
																				}
																				num = 140;
																				goto IL_0b93;
																				IL_0f12:
																				if (27 <= b)
																				{
																				}
																				break;
																				IL_0b93:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_0ba1;
																				IL_0ba1:
																				array[num6 - 1] = 3;
																				goto IL_0bb5;
																				IL_0bb5:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)IgnorePortablePDBsInStackTracesILGenerator[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0bf4;
																				IL_0bf4:
																				ptr2 += 8;
																				goto end_IL_04d0;
																				IL_0c07:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0c47;
																				IL_0c47:
																				array[num6 - 2] = 3;
																				goto IL_0c5b;
																				IL_0c5b:
																				num6--;
																				goto end_IL_04d0;
																				IL_0c6e:
																				if (20 < b)
																				{
																					break;
																				}
																				goto IL_0c7c;
																				IL_0c7c:
																				if (20 > b)
																				{
																					break;
																				}
																				goto IL_0c8a;
																				IL_0c8a:
																				array[num6 - 1] = 0;
																				goto IL_0c9e;
																				IL_0c9e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)IgnorePortablePDBsInStackTracesILGenerator[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0cdd;
																				IL_0cdd:
																				ptr2 += 8;
																				goto end_IL_04d0;
																				IL_0cf0:
																				((delegate*<void>)IgnorePortablePDBsInStackTracesILGenerator[*(int*)(ptr2 + num3)])();
																				goto IL_0d05;
																				IL_0d05:
																				ptr2 += 8;
																				goto end_IL_04d0;
																				IL_0d18:
																				if (24 >= b)
																				{
																					goto IL_0d26;
																				}
																				goto IL_0e55;
																				IL_0d26:
																				if (24 <= b)
																				{
																					goto IL_0d31;
																				}
																				goto IL_0d67;
																				IL_0d31:
																				bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																				goto IL_0d4b;
																				IL_0d4b:
																				num6--;
																				num = 59;
																				goto end_IL_04d0;
																				IL_0d67:
																				if (22 >= b)
																				{
																					goto IL_0d72;
																				}
																				goto IL_0de6;
																				IL_0d72:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_0d80;
																				IL_0d80:
																				array[num6 - 1] = 3;
																				goto IL_0d94;
																				IL_0d94:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)IgnorePortablePDBsInStackTracesILGenerator[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0dd3;
																				IL_0dd3:
																				ptr2 += 8;
																				goto end_IL_04d0;
																				IL_0de6:
																				if (23 < b)
																				{
																					break;
																				}
																				goto IL_0df4;
																				IL_0df4:
																				if (23 > b)
																				{
																					break;
																				}
																				goto IL_0e02;
																				IL_0e02:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)IgnorePortablePDBsInStackTracesILGenerator[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_0e26;
																				IL_0e26:
																				array[num6] = 0;
																				goto IL_0e34;
																				IL_0e34:
																				num6++;
																				goto IL_0e42;
																				IL_0e42:
																				ptr2 += 8;
																				goto end_IL_04d0;
																				IL_0e55:
																				if (26 >= b)
																				{
																					goto IL_0e63;
																				}
																				goto IL_0f07;
																				IL_0e63:
																				if (26 <= b)
																				{
																					goto IL_0e6e;
																				}
																				goto IL_0e8a;
																				IL_0e6e:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_04d0;
																				IL_0e8a:
																				if (25 < b)
																				{
																					break;
																				}
																				goto IL_0e98;
																				IL_0e98:
																				if (25 > b)
																				{
																					break;
																				}
																				goto IL_0ea3;
																				IL_0ea3:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0ee3;
																				IL_0ee3:
																				array[num6 - 2] = 3;
																				goto IL_0ef7;
																			}
																			break;
																			IL_04bd:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_04d0:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_0f30:
													break;
												}
												continue;
												end_IL_0f43:
												break;
											}
											continue;
											end_IL_0f4d:
											break;
										}
										continue;
										end_IL_0f61:
										break;
									}
									continue;
									end_IL_0f71:
									break;
								}
								continue;
								end_IL_0f81:
								break;
							}
							continue;
							end_IL_0f8c:
							break;
						}
						continue;
						end_IL_0f9c:
						break;
					}
					continue;
					end_IL_0fac:
					break;
				}
				continue;
				end_IL_0fbc:
				break;
			}
		}
	}

	public unsafe static void smethod_3(string string_1)
	{
		int num = 43;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								num = 108;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = string_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HijriAdjustmentgetBigEndianUnicode.IObservablegetSandboxInterop);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 215;
																while (true)
																{
																	if (num != 215)
																	{
																		if (num == 1196)
																		{
																			switch (num)
																			{
																			case 144:
																				goto end_IL_036b;
																			case 142:
																			case 151:
																				goto end_IL_037b;
																			case 29:
																				goto IL_03ad;
																			case 95:
																				goto IL_03c4;
																			case 8:
																				goto IL_03d2;
																			case 123:
																				goto IL_03e0;
																			case 133:
																				goto IL_03ee;
																			case 148:
																			case 170:
																				goto IL_03f9;
																			case 11:
																				goto IL_0439;
																			case 55:
																				goto IL_044d;
																			case 64:
																				goto IL_0460;
																			case 32:
																				goto IL_046e;
																			case 62:
																			case 115:
																				goto IL_0479;
																			case 158:
																				goto IL_04ab;
																			case 130:
																				goto IL_04c2;
																			case 191:
																				goto IL_04d5;
																			case 177:
																				goto IL_04e0;
																			case 31:
																			case 159:
																				goto IL_04ee;
																			case 19:
																				goto IL_0507;
																			case 161:
																				goto IL_0515;
																			case 102:
																				goto IL_0523;
																			case 26:
																				goto IL_053f;
																			case 150:
																				goto IL_054d;
																			case 80:
																			case 192:
																				goto IL_055b;
																			case 205:
																				goto IL_059b;
																			case 180:
																				goto IL_05b8;
																			case 155:
																				goto IL_05cb;
																			case 100:
																				goto IL_05d6;
																			case 47:
																			case 98:
																				goto IL_05e4;
																			case 68:
																				goto IL_05f2;
																			case 122:
																				goto IL_0615;
																			case 176:
																				goto IL_061f;
																			case 75:
																				goto IL_062d;
																			case 94:
																				goto IL_0640;
																			case 54:
																				goto IL_064e;
																			case 2:
																			case 190:
																				goto IL_065c;
																			case 107:
																				goto IL_06a5;
																			case 128:
																				goto IL_06b9;
																			case 12:
																				goto IL_06cc;
																			case 162:
																				goto IL_06da;
																			case 25:
																			case 27:
																				goto IL_06e5;
																			case 38:
																				goto IL_0725;
																			case 167:
																				goto IL_0739;
																			case 111:
																				goto IL_074c;
																			case 66:
																				goto IL_0757;
																			case 30:
																			case 196:
																				goto IL_0765;
																			case 60:
																				goto IL_07a5;
																			case 187:
																				goto IL_07b9;
																			case 53:
																				goto IL_07cc;
																			case 92:
																				goto IL_07da;
																			case 109:
																			case 183:
																				goto IL_07e8;
																			case 18:
																				goto IL_07fb;
																			case 145:
																				goto IL_0809;
																			case 59:
																			case 160:
																				goto IL_0817;
																			case 186:
																				goto IL_0879;
																			case 45:
																				goto IL_088c;
																			case 110:
																				goto IL_089a;
																			case 13:
																			case 201:
																				goto IL_08a8;
																			case 10:
																				goto IL_08bc;
																			case 195:
																				goto IL_0910;
																			case 88:
																				goto IL_091e;
																			case 104:
																				goto IL_0931;
																			case 134:
																				goto IL_0948;
																			case 3:
																			case 154:
																				goto IL_0953;
																			case 153:
																				goto IL_096b;
																			case 65:
																				goto IL_0979;
																			case 117:
																				goto IL_0987;
																			case 188:
																				goto IL_09a3;
																			case 77:
																				goto IL_09b1;
																			case 138:
																			case 140:
																				goto IL_09bc;
																			case 116:
																				goto IL_09fd;
																			case 50:
																				goto IL_0a11;
																			case 129:
																				goto IL_0a24;
																			case 57:
																				goto IL_0a2f;
																			case 135:
																				goto IL_0a3d;
																			case 86:
																			case 93:
																				goto IL_0a4b;
																			case 163:
																				goto IL_0a63;
																			case 4:
																			case 82:
																				goto IL_0a71;
																			case 46:
																				goto IL_0a8a;
																			case 106:
																				goto IL_0a98;
																			case 72:
																				goto IL_0aa6;
																			case 0:
																				goto IL_0ab9;
																			case 137:
																				goto IL_0acd;
																			case 41:
																			case 152:
																				goto IL_0adb;
																			case 22:
																				goto IL_0b2d;
																			case 193:
																				goto IL_0b40;
																			case 199:
																				goto IL_0b4e;
																			case 79:
																			case 202:
																				goto IL_0b5c;
																			case 194:
																				goto IL_0b7a;
																			case 5:
																				goto IL_0b88;
																			case 136:
																				goto IL_0b96;
																			case 168:
																				goto IL_0ba9;
																			case 73:
																				goto IL_0bb7;
																			case 206:
																				goto IL_0bc5;
																			case 121:
																				goto IL_0bd3;
																			case 17:
																				goto IL_0be1;
																			case 28:
																			case 149:
																				goto IL_0bef;
																			case 99:
																				goto IL_0c03;
																			case 87:
																				goto IL_0c42;
																			case 58:
																			case 78:
																				goto IL_0c55;
																			case 169:
																				goto IL_0c7a;
																			case 105:
																				goto IL_0c88;
																			case 131:
																				goto IL_0cad;
																			case 139:
																			case 185:
																				goto IL_0cb8;
																			case 125:
																				goto IL_0cf8;
																			case 21:
																				goto IL_0d0c;
																			case 189:
																				goto IL_0d1f;
																			case 39:
																				goto IL_0d2d;
																			case 120:
																			case 143:
																				goto IL_0d3b;
																			case 165:
																				goto IL_0d4f;
																			case 174:
																				goto IL_0da1;
																			case 49:
																				goto IL_0daf;
																			case 9:
																				goto IL_0dbf;
																			case 63:
																				goto IL_0dca;
																			case 15:
																			case 85:
																				goto IL_0dd5;
																			case 124:
																				goto IL_0dee;
																			case 7:
																				goto IL_0dfc;
																			case 113:
																				goto IL_0e0a;
																			case 6:
																			case 14:
																			case 24:
																			case 33:
																			case 34:
																			case 35:
																			case 36:
																			case 37:
																			case 44:
																			case 69:
																			case 70:
																			case 71:
																			case 74:
																			case 76:
																			case 83:
																			case 112:
																			case 147:
																			case 156:
																			case 157:
																			case 164:
																			case 172:
																			case 173:
																			case 184:
																			case 198:
																			case 203:
																			case 204:
																			case 207:
																				goto IL_0e1a;
																			case 1:
																			case 20:
																			case 23:
																			case 40:
																			case 48:
																			case 51:
																			case 52:
																			case 56:
																			case 61:
																			case 84:
																			case 90:
																			case 91:
																			case 96:
																			case 97:
																			case 103:
																			case 114:
																			case 119:
																			case 126:
																			case 132:
																			case 141:
																			case 171:
																			case 175:
																			case 178:
																			case 179:
																			case 181:
																			case 197:
																			case 208:
																				goto end_IL_0394;
																			case 101:
																				goto end_IL_0e2d;
																			case 182:
																				goto end_IL_0e40;
																			case 89:
																				goto end_IL_0e4a;
																			case 16:
																				goto end_IL_0e55;
																			case 108:
																				goto end_IL_0e65;
																			case 67:
																			case 200:
																				goto end_IL_0e75;
																			case 118:
																				goto end_IL_0e85;
																			case 81:
																				goto end_IL_0e9e;
																			case 146:
																				goto end_IL_0eae;
																			case 42:
																				goto end_IL_0ebe;
																			case 43:
																				goto end_IL_0ece;
																			case 127:
																			case 166:
																				return;
																			}
																			continue;
																		}
																	}
																	else if (b >= 1)
																	{
																		goto IL_03ad;
																	}
																	goto IL_0e1a;
																	IL_0daf:
																	ptr2 += 8;
																	goto end_IL_0394;
																	IL_0dca:
																	if (20 <= b)
																	{
																		goto IL_0dd5;
																	}
																	goto IL_0e1a;
																	IL_0dbf:
																	if (20 >= b)
																	{
																		goto IL_0dca;
																	}
																	goto IL_0e1a;
																	IL_03ad:
																	if (b <= 24)
																	{
																		num = 95;
																		goto IL_03c4;
																	}
																	goto IL_0e1a;
																	IL_0dd5:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																	goto IL_0dee;
																	IL_03c4:
																	if (12 >= b)
																	{
																		goto IL_03d2;
																	}
																	goto IL_0931;
																	IL_03d2:
																	if (12 <= b)
																	{
																		goto end_IL_0394;
																	}
																	goto IL_03e0;
																	IL_03e0:
																	if (6 >= b)
																	{
																		goto IL_03ee;
																	}
																	goto IL_06cc;
																	IL_03ee:
																	if (6 <= b)
																	{
																		goto IL_03f9;
																	}
																	goto IL_0460;
																	IL_03f9:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0439;
																	IL_0439:
																	array[num6 - 2] = 0;
																	goto IL_044d;
																	IL_044d:
																	num6--;
																	goto end_IL_0394;
																	IL_0460:
																	if (3 >= b)
																	{
																		goto IL_046e;
																	}
																	goto IL_05cb;
																	IL_046e:
																	if (3 <= b)
																	{
																		goto IL_0479;
																	}
																	goto IL_04d5;
																	IL_0479:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	num = 158;
																	goto IL_04ab;
																	IL_04ab:
																	ptr2 += 8;
																	num = 130;
																	goto IL_04c2;
																	IL_04c2:
																	num6--;
																	goto end_IL_0394;
																	IL_04d5:
																	if (1 >= b)
																	{
																		goto IL_04e0;
																	}
																	goto IL_053f;
																	IL_04e0:
																	if (1 <= b)
																	{
																		goto IL_04ee;
																	}
																	goto IL_0e1a;
																	IL_04ee:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_0507;
																	IL_0507:
																	array[num6] = 0;
																	goto IL_0515;
																	IL_0515:
																	num6++;
																	goto IL_0523;
																	IL_0523:
																	ptr2 += 8;
																	num = 20;
																	goto end_IL_0394;
																	IL_053f:
																	if (2 >= b)
																	{
																		goto IL_054d;
																	}
																	goto IL_0e1a;
																	IL_054d:
																	if (2 <= b)
																	{
																		goto IL_055b;
																	}
																	goto IL_0e1a;
																	IL_055b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_059b;
																	IL_059b:
																	array[num6 - 2] = 0;
																	num = 180;
																	goto IL_05b8;
																	IL_05b8:
																	num6--;
																	goto end_IL_0394;
																	IL_05cb:
																	if (4 >= b)
																	{
																		goto IL_05d6;
																	}
																	goto IL_0640;
																	IL_05d6:
																	if (4 <= b)
																	{
																		goto IL_05e4;
																	}
																	goto IL_0e1a;
																	IL_05e4:
																	array[num6] = 0;
																	goto IL_05f2;
																	IL_05f2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0615;
																	IL_0615:
																	array2[num6] = null;
																	goto IL_061f;
																	IL_061f:
																	num6++;
																	goto IL_062d;
																	IL_062d:
																	ptr2 += 8;
																	goto end_IL_0394;
																	IL_0640:
																	if (5 >= b)
																	{
																		goto IL_064e;
																	}
																	goto IL_0e1a;
																	IL_064e:
																	if (5 <= b)
																	{
																		goto IL_065c;
																	}
																	goto IL_0e1a;
																	IL_065c:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	num = 107;
																	goto IL_06a5;
																	IL_06a5:
																	array[num6 - 2] = 0;
																	goto IL_06b9;
																	IL_06b9:
																	num6--;
																	goto end_IL_0394;
																	IL_06cc:
																	if (9 >= b)
																	{
																		goto IL_06da;
																	}
																	goto IL_07fb;
																	IL_06da:
																	if (9 <= b)
																	{
																		goto IL_06e5;
																	}
																	goto IL_074c;
																	IL_06e5:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0725;
																	IL_0725:
																	array[num6 - 2] = 0;
																	goto IL_0739;
																	IL_0739:
																	num6--;
																	goto end_IL_0394;
																	IL_074c:
																	if (7 >= b)
																	{
																		goto IL_0757;
																	}
																	goto IL_07cc;
																	IL_0757:
																	if (7 <= b)
																	{
																		goto IL_0765;
																	}
																	goto IL_0e1a;
																	IL_0765:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_07a5;
																	IL_07a5:
																	array[num6 - 2] = 0;
																	goto IL_07b9;
																	IL_07b9:
																	num6--;
																	goto end_IL_0394;
																	IL_07cc:
																	if (8 >= b)
																	{
																		goto IL_07da;
																	}
																	goto IL_0e1a;
																	IL_07da:
																	if (8 <= b)
																	{
																		goto IL_07e8;
																	}
																	goto IL_0e1a;
																	IL_07e8:
																	num6--;
																	goto end_IL_0394;
																	IL_07fb:
																	if (10 >= b)
																	{
																		goto IL_0809;
																	}
																	goto IL_088c;
																	IL_0809:
																	if (10 <= b)
																	{
																		goto IL_0817;
																	}
																	goto IL_0e1a;
																	IL_0817:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0879;
																	IL_0879:
																	num6 -= 2;
																	goto end_IL_0394;
																	IL_088c:
																	if (11 >= b)
																	{
																		goto IL_089a;
																	}
																	goto IL_0e1a;
																	IL_089a:
																	if (11 <= b)
																	{
																		goto IL_08a8;
																	}
																	goto IL_0e1a;
																	IL_08a8:
																	array[num6 - 2] = 0;
																	goto IL_08bc;
																	IL_08bc:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)getTransformNamesGetRuntimeInterfaceAsObject[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																	goto IL_0910;
																	IL_0910:
																	num6--;
																	goto IL_091e;
																	IL_091e:
																	ptr2 += 8;
																	goto end_IL_0394;
																	IL_0931:
																	if (18 >= b)
																	{
																		num = 134;
																		goto IL_0948;
																	}
																	goto IL_0ba9;
																	IL_0dee:
																	array[num6] = 3;
																	goto IL_0dfc;
																	IL_0948:
																	if (18 <= b)
																	{
																		goto IL_0953;
																	}
																	goto IL_09a3;
																	IL_0953:
																	array2[num6] = array5[*(int*)(ptr2 + num3)];
																	goto IL_096b;
																	IL_096b:
																	array[num6] = 5;
																	goto IL_0979;
																	IL_0979:
																	num6++;
																	goto IL_0987;
																	IL_0987:
																	ptr2 += 8;
																	num = 40;
																	goto end_IL_0394;
																	IL_09a3:
																	if (15 >= b)
																	{
																		goto IL_09b1;
																	}
																	goto IL_0ab9;
																	IL_09b1:
																	if (15 <= b)
																	{
																		goto IL_09bc;
																	}
																	goto IL_0a24;
																	IL_09bc:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																	goto IL_09fd;
																	IL_09fd:
																	array[num6 - 2] = 0;
																	goto IL_0a11;
																	IL_0a11:
																	num6--;
																	goto end_IL_0394;
																	IL_0a24:
																	if (13 < b)
																	{
																		goto IL_0a2f;
																	}
																	goto IL_0a63;
																	IL_0a2f:
																	if (14 >= b)
																	{
																		goto IL_0a3d;
																	}
																	goto IL_0e1a;
																	IL_0a3d:
																	if (14 <= b)
																	{
																		goto IL_0a4b;
																	}
																	goto IL_0e1a;
																	IL_0a4b:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0394;
																	IL_0a63:
																	if (13 <= b)
																	{
																		goto IL_0a71;
																	}
																	goto IL_0e1a;
																	IL_0a71:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																	goto IL_0a8a;
																	IL_0a8a:
																	array[num6] = 1;
																	goto IL_0a98;
																	IL_0a98:
																	num6++;
																	goto IL_0aa6;
																	IL_0aa6:
																	ptr2 += 16;
																	goto end_IL_0394;
																	IL_0ab9:
																	if (16 >= b)
																	{
																		num = 137;
																		goto IL_0acd;
																	}
																	goto IL_0b40;
																	IL_0dfc:
																	num6++;
																	goto IL_0e0a;
																	IL_0acd:
																	if (16 <= b)
																	{
																		goto IL_0adb;
																	}
																	goto IL_0e1a;
																	IL_0adb:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0b2d;
																	IL_0b2d:
																	num6--;
																	goto end_IL_0394;
																	IL_0b40:
																	if (17 >= b)
																	{
																		goto IL_0b4e;
																	}
																	goto IL_0e1a;
																	IL_0b4e:
																	if (17 <= b)
																	{
																		goto IL_0b5c;
																	}
																	goto IL_0e1a;
																	IL_0b5c:
																	array2[num6] = ((delegate*<HashSet<string>>)getTransformNamesGetRuntimeInterfaceAsObject[*(int*)(ptr2 + num3)])();
																	goto IL_0b7a;
																	IL_0b7a:
																	array[num6] = 5;
																	goto IL_0b88;
																	IL_0b88:
																	num6++;
																	goto IL_0b96;
																	IL_0b96:
																	ptr2 += 8;
																	goto end_IL_0394;
																	IL_0ba9:
																	if (21 < b)
																	{
																		goto IL_0bb7;
																	}
																	num = 131;
																	goto IL_0cad;
																	IL_0bb7:
																	if (23 >= b)
																	{
																		goto IL_0bc5;
																	}
																	goto IL_0c7a;
																	IL_0bc5:
																	if (23 > b)
																	{
																		goto IL_0bd3;
																	}
																	goto IL_0c55;
																	IL_0bd3:
																	if (22 >= b)
																	{
																		goto IL_0be1;
																	}
																	goto IL_0e1a;
																	IL_0be1:
																	if (22 <= b)
																	{
																		goto IL_0bef;
																	}
																	goto IL_0e1a;
																	IL_0bef:
																	array[num6 - 1] = 0;
																	goto IL_0c03;
																	IL_0c03:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)getTransformNamesGetRuntimeInterfaceAsObject[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																	goto IL_0c42;
																	IL_0c42:
																	ptr2 += 8;
																	goto end_IL_0394;
																	IL_0c55:
																	byte* num7 = ptr2;
																	num5 = 1;
																	ptr2 = num7 + -200;
																	num = 197;
																	goto end_IL_0394;
																	IL_0c7a:
																	if (24 >= b)
																	{
																		goto IL_0c88;
																	}
																	goto IL_0e1a;
																	IL_0c88:
																	if (24 <= b)
																	{
																		num = 172;
																	}
																	goto IL_0e1a;
																	IL_0e1a:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0394;
																	IL_0e0a:
																	ptr2 += 16;
																	goto end_IL_0394;
																	IL_0cad:
																	if (21 <= b)
																	{
																		goto IL_0cb8;
																	}
																	goto IL_0d1f;
																	IL_0cb8:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0cf8;
																	IL_0cf8:
																	array[num6 - 2] = 3;
																	goto IL_0d0c;
																	IL_0d0c:
																	num6--;
																	goto end_IL_0394;
																	IL_0d1f:
																	if (19 >= b)
																	{
																		goto IL_0d2d;
																	}
																	goto IL_0dbf;
																	IL_0d2d:
																	if (19 <= b)
																	{
																		goto IL_0d3b;
																	}
																	goto IL_0e1a;
																	IL_0d3b:
																	array[num6 - 2] = 0;
																	goto IL_0d4f;
																	IL_0d4f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<HashSet<string>, string, bool>)getTransformNamesGetRuntimeInterfaceAsObject[*(int*)(ptr2 + num3)])((HashSet<string>)array2[num6 - 2], (string)array2[num6 - 1]) ? 1 : 0);
																	goto IL_0da1;
																	IL_0da1:
																	num6--;
																	goto IL_0daf;
																	continue;
																	end_IL_036b:
																	break;
																}
																continue;
																end_IL_037b:
																break;
															}
															continue;
															end_IL_0394:
															break;
														}
														continue;
														end_IL_0e2d:
														break;
													}
													continue;
													end_IL_0e40:
													break;
												}
												continue;
												end_IL_0e4a:
												break;
											}
											continue;
											end_IL_0e55:
											break;
										}
										continue;
										end_IL_0e65:
										break;
									}
									continue;
									end_IL_0e75:
									break;
								}
								continue;
								end_IL_0e85:
								break;
							}
							continue;
							end_IL_0e9e:
							break;
						}
						continue;
						end_IL_0eae:
						break;
					}
					continue;
					end_IL_0ebe:
					break;
				}
				continue;
				end_IL_0ece:
				break;
			}
		}
	}

	public unsafe static void smethod_4(string string_1)
	{
		int num = 37;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 82;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											object[] array5 = new object[1];
											while (true)
											{
												array5[0] = string_1;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TYPEATTRsetResourceManagerControl.MakeByRefTypeRuntimeVersion);
													num = 29;
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_0415:
																			if (b >= 1)
																			{
																				while (b <= 25)
																				{
																					while (true)
																					{
																						IL_03f8:
																						if (13 < b)
																						{
																							while (true)
																							{
																								IL_03e8:
																								if (19 < b)
																								{
																									while (true)
																									{
																										IL_03d8:
																										if (22 < b)
																										{
																											while (true)
																											{
																												IL_03cb:
																												if (24 >= b)
																												{
																													while (true)
																													{
																														IL_03bb:
																														if (24 > b)
																														{
																															while (23 >= b)
																															{
																																num = 222;
																																while (true)
																																{
																																	if (num != 222)
																																	{
																																		if (num != 1203)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 197:
																																			goto IL_03a8;
																																		case 78:
																																			goto IL_03bb;
																																		case 190:
																																			goto IL_03cb;
																																		case 47:
																																			goto IL_03d8;
																																		case 188:
																																			goto IL_03e8;
																																		case 185:
																																			goto IL_03f8;
																																		case 68:
																																			goto IL_0405;
																																		case 61:
																																			goto IL_0415;
																																		case 5:
																																			goto end_IL_0415;
																																		case 180:
																																		case 191:
																																			goto end_IL_0425;
																																		case 34:
																																			goto IL_0440;
																																		case 32:
																																			goto IL_044e;
																																		case 85:
																																			goto IL_0461;
																																		case 22:
																																			goto IL_047a;
																																		case 99:
																																			goto IL_048a;
																																		case 53:
																																			goto IL_0498;
																																		case 8:
																																			goto IL_04a6;
																																		case 101:
																																			goto IL_04b6;
																																		case 80:
																																		case 116:
																																			goto IL_04c4;
																																		case 138:
																																		case 144:
																																			goto IL_0509;
																																		case 145:
																																			goto IL_0560;
																																		case 39:
																																			goto IL_056b;
																																		case 0:
																																		case 126:
																																			goto IL_0579;
																																		case 91:
																																			goto IL_05b9;
																																		case 66:
																																			goto IL_05cd;
																																		case 43:
																																			goto IL_05e0;
																																		case 109:
																																			goto IL_05ee;
																																		case 64:
																																		case 132:
																																			goto IL_05f9;
																																		case 52:
																																			goto IL_060d;
																																		case 98:
																																			goto IL_064c;
																																		case 30:
																																			goto IL_065f;
																																		case 51:
																																			goto IL_066d;
																																		case 73:
																																			goto IL_0680;
																																		case 152:
																																			goto IL_0693;
																																		case 12:
																																			goto IL_069e;
																																		case 60:
																																			goto IL_06ac;
																																		case 100:
																																			goto IL_06bf;
																																		case 42:
																																		case 77:
																																			goto IL_06ca;
																																		case 163:
																																			goto IL_0701;
																																		case 17:
																																			goto IL_070c;
																																		case 45:
																																			goto IL_071f;
																																		case 74:
																																			goto IL_072d;
																																		case 165:
																																			goto IL_0740;
																																		case 79:
																																			goto IL_074b;
																																		case 31:
																																			goto IL_075e;
																																		case 26:
																																			goto IL_076c;
																																		case 166:
																																			goto IL_077f;
																																		case 117:
																																			goto IL_078a;
																																		case 9:
																																			goto IL_07a6;
																																		case 121:
																																		case 171:
																																			goto IL_07c2;
																																		case 150:
																																		case 175:
																																			goto IL_0829;
																																		case 65:
																																			goto IL_0847;
																																		case 81:
																																			goto IL_085e;
																																		case 133:
																																			goto IL_086c;
																																		case 62:
																																		case 178:
																																			goto IL_087f;
																																		case 19:
																																		case 179:
																																			goto IL_089b;
																																		case 41:
																																		case 181:
																																			goto IL_08b3;
																																		case 48:
																																			goto IL_08fc;
																																		case 21:
																																			goto IL_0910;
																																		case 96:
																																		case 182:
																																			goto IL_0923;
																																		case 1:
																																			goto IL_0931;
																																		case 59:
																																			goto IL_0954;
																																		case 84:
																																			goto IL_095e;
																																		case 119:
																																			goto IL_0975;
																																		case 189:
																																			goto IL_0988;
																																		case 192:
																																			goto IL_099b;
																																		case 114:
																																		case 172:
																																			goto IL_09a6;
																																		case 56:
																																			goto IL_09e6;
																																		case 89:
																																			goto IL_09fa;
																																		case 15:
																																			goto IL_0a0d;
																																		case 20:
																																			goto IL_0a18;
																																		case 25:
																																		case 136:
																																			goto IL_0a26;
																																		case 38:
																																			goto IL_0a41;
																																		case 195:
																																			goto IL_0a54;
																																		case 157:
																																			goto IL_0a68;
																																		case 198:
																																			goto IL_0a84;
																																		case 4:
																																			goto IL_0a92;
																																		case 134:
																																			goto IL_0aa0;
																																		case 199:
																																			goto IL_0abc;
																																		case 58:
																																			goto IL_0ac7;
																																		case 154:
																																		case 196:
																																			goto IL_0ad5;
																																		case 170:
																																			goto IL_0b15;
																																		case 149:
																																			goto IL_0b29;
																																		case 177:
																																			goto IL_0b45;
																																		case 107:
																																			goto IL_0b53;
																																		case 63:
																																		case 86:
																																			goto IL_0b61;
																																		case 201:
																																			goto IL_0b74;
																																		case 7:
																																		case 202:
																																			goto IL_0b87;
																																		case 55:
																																			goto IL_0ba0;
																																		case 75:
																																			goto IL_0bae;
																																		case 44:
																																			goto IL_0bbc;
																																		case 203:
																																			goto IL_0bcf;
																																		case 205:
																																			goto IL_0be2;
																																		case 186:
																																			goto IL_0bf0;
																																		case 87:
																																		case 206:
																																			goto IL_0c03;
																																		case 148:
																																			goto IL_0c17;
																																		case 128:
																																			goto IL_0c69;
																																		case 115:
																																			goto IL_0c77;
																																		case 113:
																																		case 208:
																																			goto IL_0c8a;
																																		case 28:
																																			goto IL_0ca2;
																																		case 183:
																																			goto IL_0cb0;
																																		case 50:
																																			goto IL_0cbe;
																																		case 210:
																																			goto IL_0cd1;
																																		case 105:
																																		case 141:
																																			goto IL_0cdf;
																																		case 160:
																																			goto IL_0cf3;
																																		case 155:
																																			goto IL_0d32;
																																		case 213:
																																			goto IL_0d45;
																																		case 49:
																																		case 153:
																																			goto IL_0d53;
																																		case 164:
																																			goto IL_0d94;
																																		case 2:
																																			goto IL_0da8;
																																		case 214:
																																			goto IL_0dbb;
																																		case 24:
																																			goto IL_0dc9;
																																		case 92:
																																		case 156:
																																			goto IL_0dd7;
																																		case 147:
																																			goto IL_0e17;
																																		case 212:
																																			goto IL_0e34;
																																		case 83:
																																		case 215:
																																			goto IL_0e47;
																																		case 187:
																																			goto IL_0e60;
																																		case 14:
																																			goto IL_0e6e;
																																		case 207:
																																			goto IL_0e7c;
																																		case 112:
																																		case 143:
																																			goto IL_0e9a;
																																		case 95:
																																			goto IL_0eae;
																																		case 158:
																																			goto IL_0eed;
																																		case 3:
																																		case 10:
																																		case 13:
																																		case 16:
																																		case 18:
																																		case 27:
																																		case 69:
																																		case 70:
																																		case 71:
																																		case 72:
																																		case 76:
																																		case 90:
																																		case 93:
																																		case 94:
																																		case 104:
																																		case 106:
																																		case 108:
																																		case 124:
																																		case 129:
																																		case 130:
																																		case 140:
																																		case 168:
																																		case 173:
																																		case 176:
																																		case 184:
																																		case 193:
																																		case 194:
																																		case 209:
																																			goto end_IL_0395;
																																		case 6:
																																		case 23:
																																		case 33:
																																		case 35:
																																		case 46:
																																		case 54:
																																		case 57:
																																		case 67:
																																		case 102:
																																		case 103:
																																		case 111:
																																		case 118:
																																		case 122:
																																		case 123:
																																		case 127:
																																		case 131:
																																		case 135:
																																		case 137:
																																		case 139:
																																		case 142:
																																		case 151:
																																		case 159:
																																		case 161:
																																		case 162:
																																		case 167:
																																		case 169:
																																		case 200:
																																		case 204:
																																			goto end_IL_0435;
																																		case 29:
																																			goto end_IL_0f10;
																																		case 40:
																																			goto end_IL_0f23;
																																		case 120:
																																			goto end_IL_0f2d;
																																		case 174:
																																			goto end_IL_0f41;
																																		case 11:
																																			goto end_IL_0f51;
																																		case 82:
																																			goto end_IL_0f61;
																																		case 97:
																																			goto end_IL_0f71;
																																		case 88:
																																			goto end_IL_0f81;
																																		case 211:
																																			goto end_IL_0f8c;
																																		case 146:
																																			goto end_IL_0f9c;
																																		case 36:
																																			goto end_IL_0fac;
																																		case 37:
																																			goto end_IL_0fbc;
																																		case 110:
																																		case 125:
																																			return;
																																		}
																																		continue;
																																	}
																																	if (23 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0e9a;
																																	IL_0e9a:
																																	array[num6 - 1] = 0;
																																	goto IL_0eae;
																																	IL_0eed:
																																	ptr2 += 8;
																																	goto end_IL_0435;
																																	IL_0eae:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)AddPathListRightToLeftArabic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																																	goto IL_0eed;
																																	continue;
																																	end_IL_0395:
																																	break;
																																}
																																break;
																																IL_03a8:;
																															}
																															break;
																														}
																														goto IL_087f;
																														IL_087f:
																														byte* num7 = ptr2;
																														num5 = 1;
																														ptr2 = num7 + -200;
																														goto end_IL_0435;
																													}
																													break;
																												}
																												goto IL_0440;
																												IL_044e:
																												if (25 > b)
																												{
																												}
																												break;
																												IL_0440:
																												if (25 < b)
																												{
																													break;
																												}
																												goto IL_044e;
																											}
																											break;
																										}
																										goto IL_099b;
																										IL_0d32:
																										ptr2 += 8;
																										goto end_IL_0435;
																										IL_099b:
																										if (22 <= b)
																										{
																											goto IL_09a6;
																										}
																										goto IL_0a0d;
																										IL_09a6:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_09e6;
																										IL_09e6:
																										array[num6 - 2] = 3;
																										goto IL_09fa;
																										IL_09fa:
																										num6--;
																										goto end_IL_0435;
																										IL_0a0d:
																										if (20 >= b)
																										{
																											goto IL_0a18;
																										}
																										goto IL_0a41;
																										IL_0a18:
																										if (20 > b)
																										{
																											break;
																										}
																										goto IL_0a26;
																										IL_0a26:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_0a84;
																										IL_0a84:
																										array[num6] = 3;
																										goto IL_0a92;
																										IL_0a92:
																										num6++;
																										goto IL_0aa0;
																										IL_0aa0:
																										ptr2 += 16;
																										num = 57;
																										goto end_IL_0435;
																										IL_0a41:
																										if (21 < b)
																										{
																											break;
																										}
																										goto IL_0cd1;
																										IL_0cd1:
																										if (21 > b)
																										{
																											break;
																										}
																										goto IL_0cdf;
																										IL_0cdf:
																										array[num6 - 1] = 3;
																										goto IL_0cf3;
																										IL_0cf3:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)AddPathListRightToLeftArabic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_0d32;
																									}
																									break;
																								}
																								goto IL_048a;
																								IL_0c17:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<HashSet<string>, string, bool>)AddPathListRightToLeftArabic[*(int*)(ptr2 + num3)])((HashSet<string>)array2[num6 - 2], (string)array2[num6 - 1]) ? 1 : 0);
																								goto IL_0c69;
																								IL_048a:
																								if (19 > b)
																								{
																									goto IL_0498;
																								}
																								goto IL_0c03;
																								IL_0498:
																								if (16 >= b)
																								{
																									goto IL_04a6;
																								}
																								goto IL_0701;
																								IL_04a6:
																								if (16 <= b)
																								{
																									goto IL_0509;
																								}
																								goto IL_077f;
																								IL_0509:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0b74;
																								IL_0b74:
																								num6--;
																								goto end_IL_0435;
																								IL_077f:
																								if (14 >= b)
																								{
																									goto IL_078a;
																								}
																								goto IL_07a6;
																								IL_078a:
																								if (14 > b)
																								{
																									break;
																								}
																								num = 19;
																								goto IL_089b;
																								IL_0c69:
																								num6--;
																								goto IL_0c77;
																								IL_089b:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0435;
																								IL_07a6:
																								if (15 < b)
																								{
																									break;
																								}
																								num = 213;
																								goto IL_0d45;
																								IL_0c77:
																								ptr2 += 8;
																								goto end_IL_0435;
																								IL_0d45:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_0d53;
																								IL_0d53:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																								goto IL_0d94;
																								IL_0d94:
																								array[num6 - 2] = 0;
																								goto IL_0da8;
																								IL_0da8:
																								num6--;
																								goto end_IL_0435;
																								IL_0701:
																								if (17 >= b)
																								{
																									goto IL_070c;
																								}
																								goto IL_071f;
																								IL_070c:
																								if (17 > b)
																								{
																									break;
																								}
																								goto IL_0829;
																								IL_0829:
																								array2[num6] = ((delegate*<HashSet<string>>)AddPathListRightToLeftArabic[*(int*)(ptr2 + num3)])();
																								goto IL_0847;
																								IL_0847:
																								array[num6] = 5;
																								num = 81;
																								goto IL_085e;
																								IL_085e:
																								num6++;
																								goto IL_086c;
																								IL_086c:
																								ptr2 += 8;
																								goto end_IL_0435;
																								IL_071f:
																								if (18 < b)
																								{
																									break;
																								}
																								goto IL_072d;
																								IL_072d:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_0c8a;
																								IL_0c8a:
																								array2[num6] = array5[*(int*)(ptr2 + num3)];
																								goto IL_0ca2;
																								IL_0ca2:
																								array[num6] = 5;
																								goto IL_0cb0;
																								IL_0cb0:
																								num6++;
																								goto IL_0cbe;
																								IL_0cbe:
																								ptr2 += 8;
																								goto end_IL_0435;
																								IL_0c03:
																								array[num6 - 2] = 0;
																								goto IL_0c17;
																							}
																							break;
																						}
																						goto IL_0461;
																						IL_0680:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0988;
																						IL_0461:
																						if (13 > b)
																						{
																							goto IL_047a;
																						}
																						num = 83;
																						goto IL_0e47;
																						IL_0988:
																						if (12 > b)
																						{
																							break;
																						}
																						goto end_IL_0435;
																						IL_0e47:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0e60;
																						IL_0e60:
																						array[num6] = 1;
																						goto IL_0e6e;
																						IL_0e6e:
																						num6++;
																						goto IL_0e7c;
																						IL_0e7c:
																						ptr2 += 16;
																						goto end_IL_0435;
																						IL_047a:
																						if (6 >= b)
																						{
																							goto IL_04b6;
																						}
																						goto IL_0560;
																						IL_04b6:
																						if (6 <= b)
																						{
																							goto IL_04c4;
																						}
																						goto IL_0693;
																						IL_04c4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0a54;
																						IL_0a54:
																						array[num6 - 2] = 0;
																						goto IL_0a68;
																						IL_0a68:
																						num6--;
																						num = 118;
																						goto end_IL_0435;
																						IL_0693:
																						if (3 < b)
																						{
																							goto IL_069e;
																						}
																						goto IL_06bf;
																						IL_069e:
																						if (4 >= b)
																						{
																							goto IL_06ac;
																						}
																						goto IL_0dbb;
																						IL_06ac:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_0923;
																						IL_0923:
																						array[num6] = 0;
																						goto IL_0931;
																						IL_0931:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0954;
																						IL_0954:
																						array2[num6] = null;
																						goto IL_095e;
																						IL_095e:
																						num6++;
																						num = 119;
																						goto IL_0975;
																						IL_0975:
																						ptr2 += 8;
																						goto end_IL_0435;
																						IL_0dbb:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_0dc9;
																						IL_0dc9:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0dd7;
																						IL_0dd7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0e17;
																						IL_0e17:
																						array[num6 - 2] = 0;
																						num = 212;
																						goto IL_0e34;
																						IL_0e34:
																						num6--;
																						goto end_IL_0435;
																						IL_06bf:
																						if (3 <= b)
																						{
																							goto IL_06ca;
																						}
																						goto IL_0740;
																						IL_06ca:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						num = 205;
																						goto IL_0be2;
																						IL_0be2:
																						ptr2 += 8;
																						goto IL_0bf0;
																						IL_0bf0:
																						num6--;
																						goto end_IL_0435;
																						IL_0740:
																						if (1 >= b)
																						{
																							goto IL_074b;
																						}
																						goto IL_075e;
																						IL_074b:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_0b87;
																						IL_0b87:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0ba0;
																						IL_0ba0:
																						array[num6] = 0;
																						goto IL_0bae;
																						IL_0bae:
																						num6++;
																						goto IL_0bbc;
																						IL_0bbc:
																						ptr2 += 8;
																						goto end_IL_0435;
																						IL_075e:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_076c;
																						IL_076c:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_08b3;
																						IL_08b3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						num = 48;
																						goto IL_08fc;
																						IL_08fc:
																						array[num6 - 2] = 0;
																						goto IL_0910;
																						IL_0910:
																						num6--;
																						goto end_IL_0435;
																						IL_0560:
																						if (9 >= b)
																						{
																							goto IL_056b;
																						}
																						goto IL_05e0;
																						IL_056b:
																						if (9 <= b)
																						{
																							goto IL_0579;
																						}
																						goto IL_0abc;
																						IL_0579:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_05b9;
																						IL_05b9:
																						array[num6 - 2] = 0;
																						goto IL_05cd;
																						IL_05cd:
																						num6--;
																						goto end_IL_0435;
																						IL_0abc:
																						if (7 >= b)
																						{
																							goto IL_0ac7;
																						}
																						goto IL_0b45;
																						IL_0ac7:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0ad5;
																						IL_0ad5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0b15;
																						IL_0b15:
																						array[num6 - 2] = 0;
																						goto IL_0b29;
																						IL_0b29:
																						num6--;
																						num = 127;
																						goto end_IL_0435;
																						IL_0b45:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_0b53;
																						IL_0b53:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0b61;
																						IL_0b61:
																						num6--;
																						goto end_IL_0435;
																						IL_05e0:
																						if (11 >= b)
																						{
																							goto IL_05ee;
																						}
																						goto IL_0680;
																						IL_05ee:
																						if (11 <= b)
																						{
																							goto IL_05f9;
																						}
																						goto IL_065f;
																						IL_05f9:
																						array[num6 - 1] = 0;
																						goto IL_060d;
																						IL_060d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)AddPathListRightToLeftArabic[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_064c;
																						IL_064c:
																						ptr2 += 8;
																						goto end_IL_0435;
																						IL_065f:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_066d;
																						IL_066d:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_07c2;
																						IL_07c2:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0bcf;
																						IL_0bcf:
																						num6 -= 2;
																						goto end_IL_0435;
																					}
																					break;
																					IL_0405:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0435;
																			continue;
																			end_IL_0415:
																			break;
																		}
																		continue;
																		end_IL_0425:
																		break;
																	}
																	continue;
																	end_IL_0435:
																	break;
																}
																continue;
															}
															num = 125;
															return;
															continue;
															end_IL_0f10:
															break;
														}
														continue;
														end_IL_0f23:
														break;
													}
													continue;
													end_IL_0f2d:
													break;
												}
												continue;
												end_IL_0f41:
												break;
											}
											continue;
											end_IL_0f51:
											break;
										}
										continue;
										end_IL_0f61:
										break;
									}
									continue;
									end_IL_0f71:
									break;
								}
								continue;
								end_IL_0f81:
								break;
							}
							continue;
							end_IL_0f8c:
							break;
						}
						continue;
						end_IL_0f9c:
						break;
					}
					continue;
					end_IL_0fac:
					break;
				}
				continue;
				end_IL_0fbc:
				break;
			}
		}
	}

	private static void smethod_5()
	{
		int num = 68;
		int num2 = 2;
		num = 34;
		num = 94;
		num2 = 2;
		num = 47;
		num = 34;
		num2 = 47;
		num = 13;
		num2 = 34;
		int num3 = 47;
		num2 = 34;
		num = 47;
		num = 47;
		num = 689;
		num2 = 13;
		num = 53;
		num = 222;
		num2 = 3;
		num = 74;
		num = 53;
		num2 = 74;
		num = 127;
		num2 = 53;
		num3 = 74;
		num2 = 3922;
		num = 3885;
		num = 3885;
		num2 = 47;
		num = 3932;
		num = 640;
		num2 = 4;
		num = 160;
		num2 = 1116;
		num3 = 4;
		num2 = 279;
		object obj = "u";
		object obj2 = obj;
		obj = "g";
		object obj3 = obj;
		obj = "N";
		object obj4 = obj;
		obj = "e";
		object obj5 = obj;
		obj = "F";
		object obj6 = obj;
		obj = "j";
		object obj7 = obj;
		obj = "L";
		object obj8 = obj;
		obj = "2";
		object obj9 = obj;
		obj = "b";
		object obj10 = obj;
		obj = "M";
		object obj11 = obj;
		obj = "o";
		object obj12 = obj;
		obj = "s";
		object obj13 = obj;
		obj = "H";
		object obj14 = obj;
		obj = "x";
		object obj15 = obj;
		obj = "=";
		object obj16 = obj;
		obj = "A";
		object obj17 = obj;
		obj = "l";
		object obj18 = obj;
		obj = "n";
		object obj19 = obj;
		obj = "v";
		object obj20 = obj;
		obj = "r";
		object obj21 = obj;
		obj = "[";
		object obj22 = obj;
		obj = "m";
		object obj23 = obj;
		obj = "V";
		object obj24 = obj;
		obj = "D";
		object obj25 = obj;
		obj = "I";
		object obj26 = obj;
		obj = "B";
		object obj27 = obj;
		obj = "S";
		object obj28 = obj;
		obj = "p";
		object obj29 = obj;
		obj = "G";
		object obj30 = obj;
		obj = "f";
		object obj31 = obj;
		obj = "O";
		object obj32 = obj;
		obj = "T";
		object obj33 = obj;
		obj = "R";
		object obj34 = obj;
		obj = "E";
		object obj35 = obj;
		obj = "h";
		object obj36 = obj;
		obj = "c";
		object obj37 = obj;
		obj = "d";
		object obj38 = obj;
		obj = "y";
		object obj39 = obj;
		obj = " ";
		object obj40 = obj;
		obj = "w";
		object obj41 = obj;
		obj = "t";
		object obj42 = obj;
		obj = "]";
		object obj43 = obj;
		obj = "i";
		object obj44 = obj;
		obj = "a";
		object obj45 = obj;
		obj = "C";
		object obj46 = obj;
		obj = "P";
		object obj47 = obj;
		num = 247;
		num2 = 13;
		num = 19;
		obj = new string[19];
		object obj48 = obj;
		num3 = 0;
		object obj49 = obj28;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj12;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 4;
		num3 = 2;
		obj49 = obj2;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 9;
		num3 = 3;
		obj49 = obj19;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 16;
		num3 = 4;
		obj49 = obj38;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 65;
		num3 = 5;
		obj49 = obj10;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 6;
		obj49 = obj12;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 7;
		obj49 = obj45;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 104;
		num3 = 8;
		obj49 = obj21;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 45;
		num3 = 9;
		obj49 = obj38;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 30;
		num3 = 10;
		obj49 = obj14;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 121;
		num3 = 11;
		obj49 = obj5;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 156;
		num3 = 12;
		obj49 = obj45;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 13;
		obj49 = obj21;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 154;
		num3 = 14;
		obj49 = obj28;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 105;
		num3 = 15;
		obj49 = obj5;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 48;
		num3 = 16;
		obj49 = obj18;
		((string[])obj48)[16] = (string)obj49;
		obj48 = obj;
		num3 = 51;
		num3 = 17;
		obj49 = obj31;
		((string[])obj48)[17] = (string)obj49;
		obj48 = obj;
		num3 = 36;
		num3 = 18;
		obj49 = obj16;
		((string[])obj48)[18] = (string)obj49;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj50 = obj;
		num = 60;
		num2 = 3;
		num = 20;
		obj = new string[20];
		obj48 = obj;
		num3 = 0;
		obj49 = obj17;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj19;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 22;
		num3 = 2;
		obj49 = obj42;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 6;
		num3 = 3;
		obj49 = obj44;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 20;
		num3 = 4;
		obj49 = obj34;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 5;
		obj49 = obj5;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 42;
		num3 = 6;
		obj49 = obj29;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 7;
		obj49 = obj12;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 104;
		num3 = 8;
		obj49 = obj21;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 99;
		num3 = 9;
		obj49 = obj42;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 50;
		num3 = 10;
		obj49 = obj33;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 143;
		num3 = 11;
		obj49 = obj39;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 24;
		num3 = 12;
		obj49 = obj29;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 52;
		num3 = 13;
		obj49 = obj5;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 70;
		num3 = 14;
		obj49 = obj26;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 75;
		num3 = 15;
		obj49 = obj19;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 176;
		num3 = 16;
		obj49 = obj38;
		((string[])obj48)[16] = (string)obj49;
		obj48 = obj;
		num3 = 85;
		num3 = 17;
		obj49 = obj5;
		((string[])obj48)[17] = (string)obj49;
		obj48 = obj;
		num3 = 90;
		num3 = 18;
		obj49 = obj15;
		((string[])obj48)[18] = (string)obj49;
		obj48 = obj;
		num3 = 247;
		num3 = 19;
		obj49 = obj16;
		((string[])obj48)[19] = (string)obj49;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj51 = obj;
		num = 42;
		num2 = 3;
		num = 14;
		obj = new string[14];
		obj48 = obj;
		num3 = 0;
		obj49 = obj30;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj2;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 22;
		num3 = 2;
		obj49 = obj19;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 21;
		num3 = 3;
		obj49 = obj46;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 16;
		num3 = 4;
		obj49 = obj12;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 35;
		num3 = 5;
		obj49 = obj18;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 42;
		num3 = 6;
		obj49 = obj12;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 49;
		num3 = 7;
		obj49 = obj21;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 32;
		num3 = 8;
		obj49 = obj26;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 99;
		num3 = 9;
		obj49 = obj19;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 130;
		num3 = 10;
		obj49 = obj38;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 11;
		obj49 = obj5;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 60;
		num3 = 12;
		obj49 = obj15;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 13;
		obj49 = obj16;
		((string[])obj48)[13] = (string)obj49;
		string text3 = string.Concat((string[])obj);
		obj = text3;
		object obj52 = obj;
		num = 85;
		num2 = 5;
		num = 17;
		obj = new string[17];
		obj48 = obj;
		num3 = 0;
		obj49 = obj24;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj44;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 22;
		num3 = 2;
		obj49 = obj13;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 3;
		obj49 = obj2;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 52;
		num3 = 4;
		obj49 = obj45;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 35;
		num3 = 5;
		obj49 = obj18;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 66;
		num3 = 6;
		obj49 = obj33;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 49;
		num3 = 7;
		obj49 = obj36;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 40;
		num3 = 8;
		obj49 = obj5;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 63;
		num3 = 9;
		obj49 = obj23;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 20;
		num3 = 10;
		obj49 = obj5;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 143;
		num3 = 11;
		obj49 = obj26;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 60;
		num3 = 12;
		obj49 = obj19;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 52;
		num3 = 13;
		obj49 = obj38;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 182;
		num3 = 14;
		obj49 = obj5;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 60;
		num3 = 15;
		obj49 = obj15;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 80;
		num3 = 16;
		obj49 = obj16;
		((string[])obj48)[16] = (string)obj49;
		string text4 = string.Concat((string[])obj);
		obj = text4;
		object obj53 = obj;
		num = 208;
		num2 = 13;
		num = 16;
		obj = new string[16];
		obj48 = obj;
		num3 = 0;
		obj49 = obj30;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj2;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 10;
		num3 = 2;
		obj49 = obj19;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 3;
		obj49 = obj28;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 4;
		obj49 = obj12;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 25;
		num3 = 5;
		obj49 = obj2;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 30;
		num3 = 6;
		obj49 = obj19;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 49;
		num3 = 7;
		obj49 = obj38;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 104;
		num3 = 8;
		obj49 = obj35;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 45;
		num3 = 9;
		obj49 = obj19;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 110;
		num3 = 10;
		obj49 = obj45;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 11;
		obj49 = obj10;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 48;
		num3 = 12;
		obj49 = obj18;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 52;
		num3 = 13;
		obj49 = obj5;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 70;
		num3 = 14;
		obj49 = obj38;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 195;
		num3 = 15;
		obj49 = obj16;
		((string[])obj48)[15] = (string)obj49;
		string text5 = string.Concat((string[])obj);
		obj = text5;
		object obj54 = obj;
		num = 133;
		num2 = 7;
		num = 19;
		obj = new string[19];
		obj48 = obj;
		num3 = 0;
		obj49 = obj47;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj18;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 2;
		obj49 = obj45;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 39;
		num3 = 3;
		obj49 = obj42;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 4;
		obj49 = obj31;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 10;
		num3 = 5;
		obj49 = obj12;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 18;
		num3 = 6;
		obj49 = obj21;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 14;
		num3 = 7;
		obj49 = obj23;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 32;
		num3 = 8;
		obj49 = obj46;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 27;
		num3 = 9;
		obj49 = obj12;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 130;
		num3 = 10;
		obj49 = obj18;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 11;
		obj49 = obj12;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 156;
		num3 = 12;
		obj49 = obj21;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 13;
		obj49 = obj26;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 154;
		num3 = 14;
		obj49 = obj19;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 60;
		num3 = 15;
		obj49 = obj38;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 32;
		num3 = 16;
		obj49 = obj5;
		((string[])obj48)[16] = (string)obj49;
		obj48 = obj;
		num3 = 51;
		num3 = 17;
		obj49 = obj15;
		((string[])obj48)[17] = (string)obj49;
		obj48 = obj;
		num3 = 126;
		num3 = 18;
		obj49 = obj16;
		((string[])obj48)[18] = (string)obj49;
		string text6 = string.Concat((string[])obj);
		obj = text6;
		object obj55 = obj;
		num = 55;
		num2 = 5;
		num = 11;
		obj = new string[11];
		obj48 = obj;
		num3 = 0;
		obj49 = obj33;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj36;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 2;
		obj49 = obj5;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 3;
		obj49 = obj23;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 4;
		obj49 = obj5;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 25;
		num3 = 5;
		obj49 = obj26;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 30;
		num3 = 6;
		obj49 = obj19;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 21;
		num3 = 7;
		obj49 = obj38;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 40;
		num3 = 8;
		obj49 = obj5;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 18;
		num3 = 9;
		obj49 = obj15;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 50;
		num3 = 10;
		obj49 = obj16;
		((string[])obj48)[10] = (string)obj49;
		string text7 = string.Concat((string[])obj);
		obj = text7;
		object obj56 = obj;
		num = 195;
		num2 = 13;
		num = 15;
		obj = new string[15];
		obj48 = obj;
		num3 = 0;
		obj49 = obj11;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj5;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 8;
		num3 = 2;
		obj49 = obj19;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 9;
		num3 = 3;
		obj49 = obj2;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 16;
		num3 = 4;
		obj49 = obj14;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 65;
		num3 = 5;
		obj49 = obj45;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 18;
		num3 = 6;
		obj49 = obj19;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 7;
		obj49 = obj38;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 16;
		num3 = 8;
		obj49 = obj26;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 99;
		num3 = 9;
		obj49 = obj13;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 130;
		num3 = 10;
		obj49 = obj8;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 11;
		obj49 = obj5;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 36;
		num3 = 12;
		obj49 = obj31;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 143;
		num3 = 13;
		obj49 = obj42;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 182;
		num3 = 14;
		obj49 = obj16;
		((string[])obj48)[14] = (string)obj49;
		string text8 = string.Concat((string[])obj);
		obj = text8;
		object obj57 = obj;
		num = 91;
		num2 = 7;
		num = 13;
		obj = new string[13];
		obj48 = obj;
		num3 = 0;
		obj49 = obj30;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj21;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 14;
		num3 = 2;
		obj49 = obj45;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 9;
		num3 = 3;
		obj49 = obj20;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 4;
		obj49 = obj44;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 5;
		obj49 = obj42;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 66;
		num3 = 6;
		obj49 = obj39;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 7;
		obj49 = obj24;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 88;
		num3 = 8;
		obj49 = obj45;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 45;
		num3 = 9;
		obj49 = obj18;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 110;
		num3 = 10;
		obj49 = obj2;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 11;
		obj49 = obj5;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 60;
		num3 = 12;
		obj49 = obj16;
		((string[])obj48)[12] = (string)obj49;
		string text9 = string.Concat((string[])obj);
		obj = text9;
		object obj58 = obj;
		num = 105;
		num2 = 5;
		num = 21;
		obj = new string[21];
		obj48 = obj;
		num3 = 0;
		obj49 = obj47;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj21;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 4;
		num3 = 2;
		obj49 = obj12;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 3;
		obj49 = obj7;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 16;
		num3 = 4;
		obj49 = obj5;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 10;
		num3 = 5;
		obj49 = obj37;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 66;
		num3 = 6;
		obj49 = obj42;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 14;
		num3 = 7;
		obj49 = obj44;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 56;
		num3 = 8;
		obj49 = obj18;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 27;
		num3 = 9;
		obj49 = obj5;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 130;
		num3 = 10;
		obj49 = obj46;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 55;
		num3 = 11;
		obj49 = obj12;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 24;
		num3 = 12;
		obj49 = obj18;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 13;
		obj49 = obj12;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 154;
		num3 = 14;
		obj49 = obj21;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 75;
		num3 = 15;
		obj49 = obj26;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 32;
		num3 = 16;
		obj49 = obj19;
		((string[])obj48)[16] = (string)obj49;
		obj48 = obj;
		num3 = 34;
		num3 = 17;
		obj49 = obj38;
		((string[])obj48)[17] = (string)obj49;
		obj48 = obj;
		num3 = 36;
		num3 = 18;
		obj49 = obj5;
		((string[])obj48)[18] = (string)obj49;
		obj48 = obj;
		num3 = 76;
		num3 = 19;
		obj49 = obj15;
		((string[])obj48)[19] = (string)obj49;
		obj48 = obj;
		num3 = 80;
		num3 = 20;
		obj49 = obj16;
		((string[])obj48)[20] = (string)obj49;
		string text10 = string.Concat((string[])obj);
		obj = text10;
		object obj59 = obj;
		num = 64;
		num2 = 4;
		num = 16;
		obj = new string[16];
		obj48 = obj;
		num3 = 0;
		obj49 = obj28;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj29;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 6;
		num3 = 2;
		obj49 = obj5;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 33;
		num3 = 3;
		obj49 = obj5;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 52;
		num3 = 4;
		obj49 = obj38;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 10;
		num3 = 5;
		obj49 = obj27;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 78;
		num3 = 6;
		obj49 = obj12;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 21;
		num3 = 7;
		obj49 = obj12;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 104;
		num3 = 8;
		obj49 = obj13;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 99;
		num3 = 9;
		obj49 = obj42;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 50;
		num3 = 10;
		obj49 = obj8;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 143;
		num3 = 11;
		obj49 = obj5;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 84;
		num3 = 12;
		obj49 = obj20;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 13;
		obj49 = obj5;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 14;
		obj49 = obj18;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 45;
		num3 = 15;
		obj49 = obj16;
		((string[])obj48)[15] = (string)obj49;
		string text11 = string.Concat((string[])obj);
		obj = text11;
		object obj60 = obj;
		num = 26;
		num2 = 13;
		num = 2;
		obj = new string[2];
		obj48 = obj;
		num3 = 0;
		obj49 = obj6;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj9;
		((string[])obj48)[1] = (string)obj49;
		string text12 = string.Concat((string[])obj);
		obj = text12;
		object obj61 = obj;
		num = 42;
		num2 = 2;
		num = 21;
		obj = new string[21];
		obj48 = obj;
		num3 = 0;
		obj49 = obj47;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj21;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 22;
		num3 = 2;
		obj49 = obj12;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 3;
		obj49 = obj7;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 4;
		obj49 = obj5;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 20;
		num3 = 5;
		obj49 = obj37;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 42;
		num3 = 6;
		obj49 = obj42;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 7;
		obj49 = obj44;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 104;
		num3 = 8;
		obj49 = obj18;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 36;
		num3 = 9;
		obj49 = obj5;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 40;
		num3 = 10;
		obj49 = obj28;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 33;
		num3 = 11;
		obj49 = obj29;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 36;
		num3 = 12;
		obj49 = obj5;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 13;
		obj49 = obj5;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 56;
		num3 = 14;
		obj49 = obj38;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 45;
		num3 = 15;
		obj49 = obj26;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 176;
		num3 = 16;
		obj49 = obj19;
		((string[])obj48)[16] = (string)obj49;
		obj48 = obj;
		num3 = 34;
		num3 = 17;
		obj49 = obj38;
		((string[])obj48)[17] = (string)obj49;
		obj48 = obj;
		num3 = 198;
		num3 = 18;
		obj49 = obj5;
		((string[])obj48)[18] = (string)obj49;
		obj48 = obj;
		num3 = 133;
		num3 = 19;
		obj49 = obj15;
		((string[])obj48)[19] = (string)obj49;
		obj48 = obj;
		num3 = 260;
		num3 = 20;
		obj49 = obj16;
		((string[])obj48)[20] = (string)obj49;
		string text13 = string.Concat((string[])obj);
		obj = text13;
		object obj62 = obj;
		num = 42;
		num2 = 7;
		num = 6;
		obj = new string[6];
		obj48 = obj;
		num3 = 0;
		obj49 = obj22;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj11;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 2;
		obj49 = obj32;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 33;
		num3 = 3;
		obj49 = obj25;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 4;
		obj49 = obj28;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 5;
		obj49 = obj43;
		((string[])obj48)[5] = (string)obj49;
		string text14 = string.Concat((string[])obj);
		obj = text14;
		object obj63 = obj;
		num = 60;
		num2 = 4;
		num = 15;
		obj = new string[15];
		obj48 = obj;
		num3 = 0;
		obj49 = obj30;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj2;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 22;
		num3 = 2;
		obj49 = obj19;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 9;
		num3 = 3;
		obj49 = obj33;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 4;
		obj49 = obj21;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 10;
		num3 = 5;
		obj49 = obj45;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 66;
		num3 = 6;
		obj49 = obj37;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 7;
		obj49 = obj5;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 88;
		num3 = 8;
		obj49 = obj21;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 18;
		num3 = 9;
		obj49 = obj26;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 20;
		num3 = 10;
		obj49 = obj19;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 22;
		num3 = 11;
		obj49 = obj38;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 132;
		num3 = 12;
		obj49 = obj5;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 52;
		num3 = 13;
		obj49 = obj15;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 70;
		num3 = 14;
		obj49 = obj16;
		((string[])obj48)[14] = (string)obj49;
		string text15 = string.Concat((string[])obj);
		obj = text15;
		object obj64 = obj;
		num = 30;
		num2 = 3;
		num = 10;
		obj = new string[10];
		obj48 = obj;
		num3 = 0;
		obj49 = obj22;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj28;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 8;
		num3 = 2;
		obj49 = obj35;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 21;
		num3 = 3;
		obj49 = obj33;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 4;
		obj49 = obj33;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 5;
		obj49 = obj26;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 42;
		num3 = 6;
		obj49 = obj4;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 7;
		obj49 = obj30;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 32;
		num3 = 8;
		obj49 = obj28;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 27;
		num3 = 9;
		obj49 = obj43;
		((string[])obj48)[9] = (string)obj49;
		string text16 = string.Concat((string[])obj);
		obj = text16;
		object obj65 = obj;
		num = 27;
		num2 = 3;
		num = 9;
		obj = new string[9];
		obj48 = obj;
		num3 = 0;
		obj49 = obj8;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj45;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 10;
		num3 = 2;
		obj49 = obj3;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 9;
		num3 = 3;
		obj49 = obj47;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 4;
		obj49 = obj12;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 35;
		num3 = 5;
		obj49 = obj41;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 6;
		obj49 = obj5;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 49;
		num3 = 7;
		obj49 = obj21;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 16;
		num3 = 8;
		obj49 = obj16;
		((string[])obj48)[8] = (string)obj49;
		string text17 = string.Concat((string[])obj);
		obj = text17;
		object obj66 = obj;
		num = 77;
		num2 = 7;
		num = 11;
		obj = new string[11];
		obj48 = obj;
		num3 = 0;
		obj49 = obj17;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj2;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 14;
		num3 = 2;
		obj49 = obj38;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 3;
		obj49 = obj44;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 4;
		obj49 = obj12;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 65;
		num3 = 5;
		obj49 = obj26;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 18;
		num3 = 6;
		obj49 = obj19;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 14;
		num3 = 7;
		obj49 = obj38;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 32;
		num3 = 8;
		obj49 = obj5;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 99;
		num3 = 9;
		obj49 = obj15;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 110;
		num3 = 10;
		obj49 = obj16;
		((string[])obj48)[10] = (string)obj49;
		string text18 = string.Concat((string[])obj);
		obj = text18;
		object obj67 = obj;
		num = 221;
		num2 = 13;
		num = 17;
		obj = new string[17];
		obj48 = obj;
		num3 = 0;
		obj49 = obj26;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj23;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 4;
		num3 = 2;
		obj49 = obj29;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 6;
		num3 = 3;
		obj49 = obj45;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 52;
		num3 = 4;
		obj49 = obj37;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 20;
		num3 = 5;
		obj49 = obj42;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 66;
		num3 = 6;
		obj49 = obj46;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 7;
		obj49 = obj12;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 104;
		num3 = 8;
		obj49 = obj18;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 63;
		num3 = 9;
		obj49 = obj12;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 50;
		num3 = 10;
		obj49 = obj21;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 55;
		num3 = 11;
		obj49 = obj26;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 48;
		num3 = 12;
		obj49 = obj19;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 13;
		obj49 = obj38;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 182;
		num3 = 14;
		obj49 = obj5;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 165;
		num3 = 15;
		obj49 = obj15;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 48;
		num3 = 16;
		obj49 = obj16;
		((string[])obj48)[16] = (string)obj49;
		string text19 = string.Concat((string[])obj);
		obj = text19;
		object obj68 = obj;
		num = 48;
		num2 = 3;
		num = 16;
		obj = new string[16];
		obj48 = obj;
		num3 = 0;
		obj49 = obj28;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj42;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 8;
		num3 = 2;
		obj49 = obj5;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 39;
		num3 = 3;
		obj49 = obj45;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 16;
		num3 = 4;
		obj49 = obj23;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 10;
		num3 = 5;
		obj49 = obj17;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 66;
		num3 = 6;
		obj49 = obj21;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 21;
		num3 = 7;
		obj49 = obj23;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 56;
		num3 = 8;
		obj49 = obj13;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 99;
		num3 = 9;
		obj49 = obj8;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 50;
		num3 = 10;
		obj49 = obj5;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 143;
		num3 = 11;
		obj49 = obj19;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 48;
		num3 = 12;
		obj49 = obj3;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 169;
		num3 = 13;
		obj49 = obj42;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 70;
		num3 = 14;
		obj49 = obj36;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 60;
		num3 = 15;
		obj49 = obj16;
		((string[])obj48)[15] = (string)obj49;
		string text20 = string.Concat((string[])obj);
		obj = text20;
		object obj69 = obj;
		num = 36;
		num2 = 4;
		num = 9;
		obj = new string[9];
		obj48 = obj;
		num3 = 0;
		obj49 = obj17;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj2;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 26;
		num3 = 2;
		obj49 = obj42;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 15;
		num3 = 3;
		obj49 = obj12;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 4;
		obj49 = obj40;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 20;
		num3 = 5;
		obj49 = obj8;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 66;
		num3 = 6;
		obj49 = obj12;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 14;
		num3 = 7;
		obj49 = obj45;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 24;
		num3 = 8;
		obj49 = obj38;
		((string[])obj48)[8] = (string)obj49;
		string text21 = string.Concat((string[])obj);
		obj = text21;
		object obj70 = obj;
		num = 133;
		num2 = 7;
		num = 19;
		obj = new string[19];
		obj48 = obj;
		num3 = 0;
		obj49 = obj17;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj19;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 14;
		num3 = 2;
		obj49 = obj42;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 6;
		num3 = 3;
		obj49 = obj44;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 12;
		num3 = 4;
		obj49 = obj34;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 25;
		num3 = 5;
		obj49 = obj5;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 24;
		num3 = 6;
		obj49 = obj29;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 77;
		num3 = 7;
		obj49 = obj12;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 88;
		num3 = 8;
		obj49 = obj21;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 117;
		num3 = 9;
		obj49 = obj42;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 40;
		num3 = 10;
		obj49 = obj25;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 22;
		num3 = 11;
		obj49 = obj44;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 48;
		num3 = 12;
		obj49 = obj13;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 13;
		obj49 = obj42;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 14;
		obj49 = obj45;
		((string[])obj48)[14] = (string)obj49;
		obj48 = obj;
		num3 = 105;
		num3 = 15;
		obj49 = obj19;
		((string[])obj48)[15] = (string)obj49;
		obj48 = obj;
		num3 = 32;
		num3 = 16;
		obj49 = obj37;
		((string[])obj48)[16] = (string)obj49;
		obj48 = obj;
		num3 = 187;
		num3 = 17;
		obj49 = obj5;
		((string[])obj48)[17] = (string)obj49;
		obj48 = obj;
		num3 = 126;
		num3 = 18;
		obj49 = obj16;
		((string[])obj48)[18] = (string)obj49;
		string text22 = string.Concat((string[])obj);
		obj = text22;
		object obj71 = obj;
		num = 105;
		num2 = 7;
		num = 15;
		obj = new string[15];
		obj48 = obj;
		num3 = 0;
		obj49 = obj11;
		((string[])obj48)[0] = (string)obj49;
		obj48 = obj;
		num3 = 1;
		obj49 = obj5;
		((string[])obj48)[1] = (string)obj49;
		obj48 = obj;
		num3 = 6;
		num3 = 2;
		obj49 = obj19;
		((string[])obj48)[2] = (string)obj49;
		obj48 = obj;
		num3 = 33;
		num3 = 3;
		obj49 = obj2;
		((string[])obj48)[3] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 4;
		obj49 = obj28;
		((string[])obj48)[4] = (string)obj49;
		obj48 = obj;
		num3 = 25;
		num3 = 5;
		obj49 = obj42;
		((string[])obj48)[5] = (string)obj49;
		obj48 = obj;
		num3 = 18;
		num3 = 6;
		obj49 = obj39;
		((string[])obj48)[6] = (string)obj49;
		obj48 = obj;
		num3 = 28;
		num3 = 7;
		obj49 = obj18;
		((string[])obj48)[7] = (string)obj49;
		obj48 = obj;
		num3 = 40;
		num3 = 8;
		obj49 = obj5;
		((string[])obj48)[8] = (string)obj49;
		obj48 = obj;
		num3 = 45;
		num3 = 9;
		obj49 = obj26;
		((string[])obj48)[9] = (string)obj49;
		obj48 = obj;
		num3 = 50;
		num3 = 10;
		obj49 = obj19;
		((string[])obj48)[10] = (string)obj49;
		obj48 = obj;
		num3 = 44;
		num3 = 11;
		obj49 = obj38;
		((string[])obj48)[11] = (string)obj49;
		obj48 = obj;
		num3 = 24;
		num3 = 12;
		obj49 = obj5;
		((string[])obj48)[12] = (string)obj49;
		obj48 = obj;
		num3 = 91;
		num3 = 13;
		obj49 = obj15;
		((string[])obj48)[13] = (string)obj49;
		obj48 = obj;
		num3 = 56;
		num3 = 14;
		obj49 = obj16;
		((string[])obj48)[14] = (string)obj49;
		string text23 = string.Concat((string[])obj);
		obj = text23;
		object obj72 = obj;
		try
		{
			string text24 = smethod_0();
			obj = text24;
			num2 = 0;
			StreamWriter streamWriter = new StreamWriter((string)obj, append: false);
			obj = streamWriter;
			global::_003CModule_003E.streamWriter_0 = (StreamWriter)obj;
			try
			{
				obj = global::_003CModule_003E.streamWriter_0;
				string text25 = bool_0.ToString();
				obj48 = text25;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj65;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj71;
				obj49 = obj61;
				string text26 = Class147.float_0.ToString((string)obj49);
				object obj73 = text26;
				string text27 = (string)obj48 + (string)obj73;
				obj48 = text27;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj51;
				string text28 = Class147.int_0.ToString();
				obj73 = text28;
				string text29 = (string)obj48 + (string)obj73;
				obj48 = text29;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj56;
				int currentIndex = Class139.CurrentIndex;
				num3 = currentIndex;
				global::_003CModule_003E.int_41 = num3;
				string text30 = global::_003CModule_003E.int_41.ToString();
				obj73 = text30;
				string text31 = (string)obj48 + (string)obj73;
				obj48 = text31;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj55;
				int currentIndex2 = Class135.CurrentIndex;
				num3 = currentIndex2;
				global::_003CModule_003E.int_41 = num3;
				string text32 = global::_003CModule_003E.int_41.ToString();
				obj73 = text32;
				string text33 = (string)obj48 + (string)obj73;
				obj48 = text33;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj64;
				int currentIndex3 = Class131.CurrentIndex;
				num3 = currentIndex3;
				global::_003CModule_003E.int_41 = num3;
				string text34 = global::_003CModule_003E.int_41.ToString();
				obj73 = text34;
				string text35 = (string)obj48 + (string)obj73;
				obj48 = text35;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj52;
				int currentIndex4 = Class129.CurrentIndex;
				num3 = currentIndex4;
				global::_003CModule_003E.int_41 = num3;
				string text36 = global::_003CModule_003E.int_41.ToString();
				obj73 = text36;
				string text37 = (string)obj48 + (string)obj73;
				obj48 = text37;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj54;
				num3 = (Class130.SoundEnabled ? 1 : 0);
				global::_003CModule_003E.bool_21 = (byte)num3 != 0;
				string text38 = global::_003CModule_003E.bool_21.ToString();
				obj73 = text38;
				string text39 = (string)obj48 + (string)obj73;
				obj48 = text39;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj53;
				int currentIndex5 = Class140.CurrentIndex;
				num3 = currentIndex5;
				global::_003CModule_003E.int_41 = num3;
				string text40 = global::_003CModule_003E.int_41.ToString();
				obj73 = text40;
				string text41 = (string)obj48 + (string)obj73;
				obj48 = text41;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj59;
				string text42 = Class9.int_1.ToString();
				obj73 = text42;
				string text43 = (string)obj48 + (string)obj73;
				obj48 = text43;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj62;
				string text44 = Class9.int_2.ToString();
				obj73 = text44;
				string text45 = (string)obj48 + (string)obj73;
				obj48 = text45;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj68;
				string text46 = Class9.int_3.ToString();
				obj73 = text46;
				string text47 = (string)obj48 + (string)obj73;
				obj48 = text47;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj66;
				string text48 = Class132.int_0.ToString();
				obj73 = text48;
				string text49 = (string)obj48 + (string)obj73;
				obj48 = text49;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj67;
				string text50 = Class223.int_0.ToString();
				obj73 = text50;
				string text51 = (string)obj48 + (string)obj73;
				obj48 = text51;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj69;
				obj49 = obj61;
				string text52 = Class207.float_0.ToString((string)obj49);
				obj73 = text52;
				string text53 = (string)obj48 + (string)obj73;
				obj48 = text53;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj60;
				obj49 = obj61;
				string text54 = Class253.float_0.ToString((string)obj49);
				obj73 = text54;
				string text55 = (string)obj48 + (string)obj73;
				obj48 = text55;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj58;
				obj49 = obj61;
				string text56 = Class13.float_0.ToString((string)obj49);
				obj73 = text56;
				string text57 = (string)obj48 + (string)obj73;
				obj48 = text57;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj50;
				string text58 = string.Concat(str1: (!Class11.HearSelf) ? "0" : "1", str0: (string)obj48);
				obj48 = text58;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj57;
				string text59 = string.Concat(str1: (!Class133.bool_0) ? "0" : "1", str0: (string)obj48);
				obj48 = text59;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj72;
				int currentStyle = Class134.CurrentStyle;
				num3 = currentStyle;
				global::_003CModule_003E.int_41 = num3;
				string text60 = global::_003CModule_003E.int_41.ToString();
				obj73 = text60;
				string text61 = (string)obj48 + (string)obj73;
				obj48 = text61;
				((StreamWriter)obj).WriteLine((string)obj48);
				obj = global::_003CModule_003E.streamWriter_0;
				obj48 = obj63;
				((StreamWriter)obj).WriteLine((string)obj48);
				if (bool_0)
				{
					obj = ModManager.Instance;
					obj48 = null;
					if ((ModManager)obj != (UnityEngine.Object)obj48)
					{
						obj = ModManager.Instance;
						GameObject gameObject = ((ModManager)obj).gameObject;
						obj = gameObject;
						Component[] components = ((GameObject)obj).GetComponents<Component>();
						obj = components;
						global::_003CModule_003E.component_2 = (Component[])obj;
						num = 0;
						global::_003CModule_003E.int_42 = 0;
						while (true)
						{
							num = global::_003CModule_003E.int_42;
							obj48 = global::_003CModule_003E.component_2;
							IntPtr intPtr = (nint)((Component[])obj48).LongLength;
							num2 = (int)(nint)intPtr;
							if (num >= num2)
							{
								break;
							}
							obj = global::_003CModule_003E.component_2;
							num2 = global::_003CModule_003E.int_42;
							obj = ((Component[])obj)[num2];
							global::_003CModule_003E.component_3 = (Component)obj;
							obj = global::_003CModule_003E.component_3;
							obj48 = null;
							if (!((Component)obj == (UnityEngine.Object)obj48))
							{
								obj = global::_003CModule_003E.component_3;
								Type type = ((Component)obj).GetType();
								obj = type;
								Mod customAttribute = ((Type)obj).GetCustomAttribute<Mod>();
								obj = customAttribute;
								global::_003CModule_003E.mod_0 = (Mod)obj;
								obj = global::_003CModule_003E.mod_0;
								if (obj != null)
								{
									obj = global::_003CModule_003E.mod_0;
									string name = ((Mod)obj).Name;
									obj = name;
									obj48 = obj70;
									int num4 = ((string)obj).IndexOf((string)obj48);
									num = num4;
									num2 = -1;
									if (num == -1)
									{
										obj = hashSet_0;
										obj48 = global::_003CModule_003E.mod_0;
										string name2 = ((Mod)obj48).Name;
										obj48 = name2;
										if (!((HashSet<string>)obj).Contains((string)obj48))
										{
											obj = global::_003CModule_003E.streamWriter_0;
											obj48 = global::_003CModule_003E.mod_0;
											string name3 = ((Mod)obj48).Name;
											obj48 = name3;
											((StreamWriter)obj).WriteLine((string)obj48);
										}
									}
								}
							}
							num = global::_003CModule_003E.int_42;
							num2 = 1;
							num++;
							global::_003CModule_003E.int_42 = num;
						}
					}
				}
				obj = global::_003CModule_003E.streamWriter_0;
				((StreamWriter)obj).Flush();
			}
			finally
			{
				obj = global::_003CModule_003E.streamWriter_0;
				if (obj != null)
				{
					obj = global::_003CModule_003E.streamWriter_0;
					((IDisposable)(StreamWriter)obj).Dispose();
				}
			}
			obj = hashSet_0;
			((HashSet<string>)obj).Clear();
		}
		catch
		{
		}
	}

	public unsafe static void smethod_6()
	{
		int num = 172;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AsyncCausalitySynchronousWorkConvertHexDigit.IsClassGenericPar);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													num = 223;
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_04ee:
																if (b >= 1)
																{
																	num = 99;
																	while (b <= 28)
																	{
																		while (true)
																		{
																			IL_04ce:
																			if (14 >= b)
																			{
																				while (true)
																				{
																					IL_04c1:
																					if (14 > b)
																					{
																						while (true)
																						{
																							IL_04b1:
																							if (7 >= b)
																							{
																								while (true)
																								{
																									IL_04a1:
																									if (7 > b)
																									{
																										while (true)
																										{
																											IL_0491:
																											if (3 >= b)
																											{
																												while (true)
																												{
																													IL_0481:
																													if (3 > b)
																													{
																														while (true)
																														{
																															IL_0471:
																															if (1 < b)
																															{
																																while (2 >= b)
																																{
																																	while (2 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_040f:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																			while (true)
																																			{
																																				IL_03f0:
																																				array[num6 - 2] = 0;
																																				num = 240;
																																				while (true)
																																				{
																																					if (num != 240)
																																					{
																																						if (num != 1221)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 18:
																																							goto IL_03f0;
																																						case 34:
																																						case 122:
																																							goto IL_040f;
																																						case 130:
																																							goto IL_0451;
																																						case 121:
																																							goto IL_0461;
																																						case 43:
																																							goto IL_0471;
																																						case 93:
																																							goto IL_0481;
																																						case 80:
																																							goto IL_0491;
																																						case 57:
																																							goto IL_04a1;
																																						case 182:
																																							goto IL_04b1;
																																						case 117:
																																							goto IL_04c1;
																																						case 96:
																																							goto IL_04ce;
																																						case 99:
																																							goto IL_04de;
																																						case 107:
																																							goto IL_04ee;
																																						case 175:
																																							goto end_IL_04ee;
																																						case 223:
																																							goto end_IL_0501;
																																						case 200:
																																							goto end_IL_0511;
																																						case 1:
																																						case 70:
																																							goto IL_0535;
																																						case 39:
																																						case 86:
																																							goto IL_0560;
																																						case 90:
																																							goto IL_05a2;
																																						case 60:
																																							goto IL_05b0;
																																						case 119:
																																							goto IL_05c3;
																																						case 187:
																																							goto IL_05d9;
																																						case 48:
																																						case 185:
																																							goto IL_05e7;
																																						case 37:
																																							goto IL_0600;
																																						case 53:
																																							goto IL_060e;
																																						case 46:
																																							goto IL_061c;
																																						case 189:
																																							goto IL_062f;
																																						case 170:
																																						case 193:
																																							goto IL_0642;
																																						case 133:
																																							goto IL_066d;
																																						case 207:
																																							goto IL_067b;
																																						case 214:
																																							goto IL_0686;
																																						case 29:
																																							goto IL_0694;
																																						case 50:
																																						case 153:
																																							goto IL_06a2;
																																						case 52:
																																							goto IL_06b0;
																																						case 106:
																																							goto IL_06d3;
																																						case 26:
																																							goto IL_06dd;
																																						case 126:
																																							goto IL_06eb;
																																						case 136:
																																						case 139:
																																							goto IL_06fe;
																																						case 145:
																																							goto IL_073e;
																																						case 134:
																																							goto IL_075b;
																																						case 21:
																																							goto IL_076e;
																																						case 140:
																																							goto IL_077c;
																																						case 22:
																																						case 229:
																																							goto IL_078a;
																																						case 228:
																																							goto IL_07ca;
																																						case 24:
																																							goto IL_07de;
																																						case 142:
																																							goto IL_07f1;
																																						case 15:
																																							goto IL_07ff;
																																						case 25:
																																						case 81:
																																							goto IL_080a;
																																						case 79:
																																							goto IL_086c;
																																						case 202:
																																							goto IL_087f;
																																						case 20:
																																							goto IL_088a;
																																						case 92:
																																						case 197:
																																							goto IL_0898;
																																						case 19:
																																							goto IL_08ab;
																																						case 152:
																																							goto IL_08b9;
																																						case 66:
																																						case 110:
																																							goto IL_08c7;
																																						case 49:
																																							goto IL_0907;
																																						case 211:
																																							goto IL_091b;
																																						case 78:
																																							goto IL_092e;
																																						case 143:
																																							goto IL_0945;
																																						case 221:
																																							goto IL_0953;
																																						case 91:
																																							goto IL_0961;
																																						case 23:
																																						case 68:
																																							goto IL_096f;
																																						case 184:
																																							goto IL_0983;
																																						case 137:
																																							goto IL_09c2;
																																						case 127:
																																							goto IL_09d5;
																																						case 113:
																																							goto IL_09e3;
																																						case 32:
																																						case 190:
																																							goto IL_09f1;
																																						case 36:
																																							goto IL_0a0a;
																																						case 225:
																																							goto IL_0a18;
																																						case 64:
																																							goto IL_0a26;
																																						case 135:
																																							goto IL_0a39;
																																						case 155:
																																							goto IL_0a47;
																																						case 5:
																																						case 84:
																																							goto IL_0a5b;
																																						case 98:
																																							goto IL_0a6f;
																																						case 114:
																																							goto IL_0aae;
																																						case 222:
																																							goto IL_0aca;
																																						case 100:
																																							goto IL_0ad8;
																																						case 63:
																																							goto IL_0ae6;
																																						case 150:
																																							goto IL_0af1;
																																						case 87:
																																						case 201:
																																							goto IL_0aff;
																																						case 61:
																																							goto IL_0b40;
																																						case 224:
																																							goto IL_0b54;
																																						case 94:
																																							goto IL_0b67;
																																						case 54:
																																							goto IL_0b75;
																																						case 31:
																																						case 166:
																																							goto IL_0b83;
																																						case 180:
																																							goto IL_0bd5;
																																						case 10:
																																						case 220:
																																							goto IL_0be8;
																																						case 169:
																																							goto IL_0bfd;
																																						case 144:
																																							goto IL_0c19;
																																						case 7:
																																							goto IL_0c27;
																																						case 4:
																																						case 129:
																																							goto IL_0c32;
																																						case 161:
																																							goto IL_0c46;
																																						case 167:
																																							goto IL_0c85;
																																						case 194:
																																							goto IL_0c98;
																																						case 128:
																																							goto IL_0ca6;
																																						case 71:
																																						case 147:
																																							goto IL_0cb4;
																																						case 124:
																																							goto IL_0ccd;
																																						case 165:
																																							goto IL_0cdb;
																																						case 27:
																																							goto IL_0ce9;
																																						case 232:
																																							goto IL_0cfc;
																																						case 76:
																																							goto IL_0d0a;
																																						case 41:
																																						case 56:
																																							goto IL_0d18;
																																						case 157:
																																							goto IL_0d58;
																																						case 101:
																																							goto IL_0d6c;
																																						case 148:
																																							goto IL_0d7f;
																																						case 16:
																																							goto IL_0d8d;
																																						case 35:
																																							goto IL_0d9b;
																																						case 120:
																																						case 226:
																																							goto IL_0da6;
																																						case 88:
																																							goto IL_0dc2;
																																						case 160:
																																							goto IL_0dd0;
																																						case 55:
																																						case 213:
																																							goto IL_0dde;
																																						case 109:
																																							goto IL_0df2;
																																						case 44:
																																							goto IL_0e31;
																																						case 218:
																																							goto IL_0e44;
																																						case 3:
																																							goto IL_0e52;
																																						case 191:
																																							goto IL_0e65;
																																						case 0:
																																						case 208:
																																							goto IL_0e70;
																																						case 11:
																																							goto IL_0e85;
																																						case 188:
																																							goto IL_0e98;
																																						case 115:
																																							goto IL_0ea6;
																																						case 62:
																																							goto IL_0eb1;
																																						case 231:
																																							goto IL_0ebf;
																																						case 105:
																																						case 204:
																																							goto IL_0ecd;
																																						case 163:
																																							goto IL_0ef1;
																																						case 156:
																																							goto IL_0eff;
																																						case 227:
																																							goto IL_0f0d;
																																						case 77:
																																						case 198:
																																							goto IL_0f29;
																																						case 162:
																																							goto IL_0f3d;
																																						case 85:
																																							goto IL_0f7c;
																																						case 102:
																																							goto IL_0f8f;
																																						case 195:
																																							goto IL_0f9a;
																																						case 13:
																																						case 154:
																																							goto IL_0fa5;
																																						case 176:
																																							goto IL_0fe5;
																																						case 65:
																																							goto IL_0ff9;
																																						case 6:
																																						case 14:
																																						case 17:
																																						case 28:
																																						case 30:
																																						case 38:
																																						case 42:
																																						case 45:
																																						case 59:
																																						case 69:
																																						case 97:
																																						case 104:
																																						case 118:
																																						case 123:
																																						case 125:
																																						case 131:
																																						case 138:
																																						case 149:
																																						case 177:
																																						case 178:
																																						case 181:
																																						case 186:
																																						case 192:
																																						case 203:
																																						case 205:
																																						case 209:
																																						case 210:
																																						case 215:
																																						case 216:
																																						case 217:
																																						case 219:
																																							goto end_IL_03dd;
																																						case 2:
																																						case 8:
																																						case 12:
																																						case 33:
																																						case 40:
																																						case 47:
																																						case 51:
																																						case 67:
																																						case 73:
																																						case 74:
																																						case 75:
																																						case 82:
																																						case 83:
																																						case 95:
																																						case 108:
																																						case 111:
																																						case 112:
																																						case 132:
																																						case 141:
																																						case 146:
																																						case 164:
																																						case 168:
																																						case 173:
																																						case 174:
																																						case 183:
																																						case 196:
																																						case 199:
																																						case 206:
																																						case 212:
																																						case 230:
																																						case 233:
																																							goto end_IL_051c;
																																						case 72:
																																							goto end_IL_1025;
																																						case 9:
																																							goto end_IL_1038;
																																						case 151:
																																							goto end_IL_1042;
																																						case 58:
																																						case 89:
																																							goto end_IL_104d;
																																						case 158:
																																							goto end_IL_105d;
																																						case 179:
																																							goto end_IL_106d;
																																						case 159:
																																							goto end_IL_107d;
																																						case 171:
																																							goto end_IL_108d;
																																						case 172:
																																							goto end_IL_109d;
																																						case 103:
																																						case 116:
																																							return;
																																						}
																																						continue;
																																					}
																																					num6--;
																																					goto end_IL_051c;
																																					continue;
																																					end_IL_03dd:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																		IL_0451:;
																																	}
																																	break;
																																	IL_0461:;
																																}
																																break;
																															}
																															goto IL_05d9;
																															IL_061c:
																															ptr2 += 8;
																															goto end_IL_051c;
																															IL_05d9:
																															if (1 > b)
																															{
																																break;
																															}
																															goto IL_05e7;
																															IL_05e7:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																															goto IL_0600;
																															IL_0600:
																															array[num6] = 0;
																															goto IL_060e;
																															IL_060e:
																															num6++;
																															goto IL_061c;
																														}
																														break;
																													}
																													goto IL_0535;
																													IL_05b0:
																													num6--;
																													goto end_IL_051c;
																													IL_0535:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_05a2;
																													IL_05a2:
																													ptr2 += 8;
																													goto IL_05b0;
																												}
																												break;
																											}
																											goto IL_066d;
																											IL_07de:
																											num6--;
																											goto end_IL_051c;
																											IL_066d:
																											if (5 >= b)
																											{
																												goto IL_067b;
																											}
																											goto IL_076e;
																											IL_067b:
																											if (5 > b)
																											{
																												goto IL_0686;
																											}
																											goto IL_06fe;
																											IL_0686:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_0694;
																											IL_0694:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_06a2;
																											IL_06a2:
																											array[num6] = 0;
																											goto IL_06b0;
																											IL_06b0:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_06d3;
																											IL_06d3:
																											array2[num6] = null;
																											goto IL_06dd;
																											IL_06dd:
																											num6++;
																											goto IL_06eb;
																											IL_06eb:
																											ptr2 += 8;
																											goto end_IL_051c;
																											IL_06fe:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_073e;
																											IL_073e:
																											array[num6 - 2] = 0;
																											num = 134;
																											goto IL_075b;
																											IL_075b:
																											num6--;
																											goto end_IL_051c;
																											IL_076e:
																											if (6 < b)
																											{
																												break;
																											}
																											goto IL_077c;
																											IL_077c:
																											if (6 > b)
																											{
																												break;
																											}
																											goto IL_078a;
																											IL_078a:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_07ca;
																											IL_07ca:
																											array[num6 - 2] = 0;
																											goto IL_07de;
																										}
																										break;
																									}
																									goto IL_0560;
																									IL_062f:
																									num6--;
																									goto end_IL_051c;
																									IL_0560:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_05c3;
																									IL_05c3:
																									array[num6 - 2] = 0;
																									goto IL_062f;
																								}
																								break;
																							}
																							goto IL_07f1;
																							IL_0a18:
																							num6++;
																							goto IL_0a26;
																							IL_07f1:
																							if (10 >= b)
																							{
																								goto IL_07ff;
																							}
																							goto IL_092e;
																							IL_07ff:
																							if (10 <= b)
																							{
																								goto IL_080a;
																							}
																							goto IL_087f;
																							IL_080a:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_086c;
																							IL_086c:
																							num6 -= 2;
																							goto end_IL_051c;
																							IL_087f:
																							if (8 >= b)
																							{
																								goto IL_088a;
																							}
																							goto IL_08ab;
																							IL_088a:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0898;
																							IL_0898:
																							num6--;
																							goto end_IL_051c;
																							IL_08ab:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_08b9;
																							IL_08b9:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_08c7;
																							IL_08c7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0907;
																							IL_0907:
																							array[num6 - 2] = 0;
																							goto IL_091b;
																							IL_091b:
																							num6--;
																							goto end_IL_051c;
																							IL_092e:
																							if (12 >= b)
																							{
																								num = 143;
																								goto IL_0945;
																							}
																							goto IL_09d5;
																							IL_0a26:
																							ptr2 += 16;
																							goto end_IL_051c;
																							IL_0945:
																							if (12 <= b)
																							{
																								goto end_IL_051c;
																							}
																							goto IL_0953;
																							IL_0953:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_0961;
																							IL_0961:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_096f;
																							IL_096f:
																							array[num6 - 1] = 0;
																							goto IL_0983;
																							IL_0983:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_09c2;
																							IL_09c2:
																							ptr2 += 8;
																							goto end_IL_051c;
																							IL_09d5:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_09e3;
																							IL_09e3:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_09f1;
																							IL_09f1:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0a0a;
																							IL_0a0a:
																							array[num6] = 1;
																							goto IL_0a18;
																						}
																						break;
																					}
																					num = 170;
																					goto IL_0642;
																					IL_0642:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_051c;
																				}
																				break;
																			}
																			goto IL_0a39;
																			IL_0fa5:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0fe5;
																			IL_0a39:
																			if (21 >= b)
																			{
																				goto IL_0a47;
																			}
																			goto IL_0d7f;
																			IL_0a47:
																			if (21 <= b)
																			{
																				num = 5;
																				goto IL_0a5b;
																			}
																			goto IL_0aca;
																			IL_0fe5:
																			array[num6 - 2] = 3;
																			goto IL_0ff9;
																			IL_0a5b:
																			array[num6 - 1] = 0;
																			goto IL_0a6f;
																			IL_0a6f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0aae;
																			IL_0aae:
																			ptr2 += 8;
																			num = 230;
																			goto end_IL_051c;
																			IL_0aca:
																			if (17 >= b)
																			{
																				goto IL_0ad8;
																			}
																			goto IL_0c19;
																			IL_0ad8:
																			if (17 > b)
																			{
																				goto IL_0ae6;
																			}
																			goto IL_0be8;
																			IL_0ae6:
																			if (15 >= b)
																			{
																				goto IL_0af1;
																			}
																			goto IL_0b67;
																			IL_0af1:
																			if (15 > b)
																			{
																				break;
																			}
																			goto IL_0aff;
																			IL_0aff:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																			goto IL_0b40;
																			IL_0b40:
																			array[num6 - 2] = 0;
																			goto IL_0b54;
																			IL_0b54:
																			num6--;
																			goto end_IL_051c;
																			IL_0b67:
																			if (16 < b)
																			{
																				break;
																			}
																			goto IL_0b75;
																			IL_0b75:
																			if (16 > b)
																			{
																				break;
																			}
																			goto IL_0b83;
																			IL_0b83:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0bd5;
																			IL_0bd5:
																			num6--;
																			goto end_IL_051c;
																			IL_0be8:
																			((delegate*<void>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])();
																			goto IL_0bfd;
																			IL_0bfd:
																			ptr2 += 8;
																			num = 74;
																			goto end_IL_051c;
																			IL_0c19:
																			if (19 >= b)
																			{
																				goto IL_0c27;
																			}
																			goto IL_0cfc;
																			IL_0c27:
																			if (19 <= b)
																			{
																				goto IL_0c32;
																			}
																			goto IL_0c98;
																			IL_0c32:
																			array[num6 - 1] = 3;
																			goto IL_0c46;
																			IL_0c46:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0c85;
																			IL_0c85:
																			ptr2 += 8;
																			goto end_IL_051c;
																			IL_0c98:
																			if (18 < b)
																			{
																				break;
																			}
																			goto IL_0ca6;
																			IL_0ca6:
																			if (18 > b)
																			{
																				break;
																			}
																			goto IL_0cb4;
																			IL_0cb4:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																			goto IL_0ccd;
																			IL_0ccd:
																			array[num6] = 3;
																			goto IL_0cdb;
																			IL_0cdb:
																			num6++;
																			goto IL_0ce9;
																			IL_0ce9:
																			ptr2 += 16;
																			goto end_IL_051c;
																			IL_0cfc:
																			if (20 < b)
																			{
																				break;
																			}
																			goto IL_0d0a;
																			IL_0d0a:
																			if (20 > b)
																			{
																				break;
																			}
																			goto IL_0d18;
																			IL_0d18:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0d58;
																			IL_0d58:
																			array[num6 - 2] = 3;
																			goto IL_0d6c;
																			IL_0d6c:
																			num6--;
																			goto end_IL_051c;
																			IL_0d7f:
																			if (25 < b)
																			{
																				goto IL_0d8d;
																			}
																			goto IL_0e65;
																			IL_0d8d:
																			if (27 >= b)
																			{
																				goto IL_0d9b;
																			}
																			goto IL_0e44;
																			IL_0d9b:
																			if (27 <= b)
																			{
																				goto IL_0da6;
																			}
																			goto IL_0dc2;
																			IL_0da6:
																			byte* num7 = ptr2;
																			num5 = 1;
																			ptr2 = num7 + -200;
																			goto end_IL_051c;
																			IL_0dc2:
																			if (26 < b)
																			{
																				break;
																			}
																			goto IL_0dd0;
																			IL_0dd0:
																			if (26 > b)
																			{
																				break;
																			}
																			goto IL_0dde;
																			IL_0dde:
																			array[num6 - 1] = 3;
																			goto IL_0df2;
																			IL_0df2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0e31;
																			IL_0e31:
																			ptr2 += 8;
																			goto end_IL_051c;
																			IL_0e44:
																			if (28 < b)
																			{
																				break;
																			}
																			goto IL_0e52;
																			IL_0e52:
																			if (28 > b)
																			{
																			}
																			break;
																			IL_0e65:
																			if (25 <= b)
																			{
																				goto IL_0e70;
																			}
																			goto IL_0e98;
																			IL_0e70:
																			((delegate*<void>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])();
																			goto IL_0e85;
																			IL_0e85:
																			ptr2 += 8;
																			goto end_IL_051c;
																			IL_0e98:
																			if (23 >= b)
																			{
																				goto IL_0ea6;
																			}
																			goto IL_0f8f;
																			IL_0ea6:
																			if (23 > b)
																			{
																				goto IL_0eb1;
																			}
																			num = 198;
																			goto IL_0f29;
																			IL_0eb1:
																			if (22 < b)
																			{
																				break;
																			}
																			goto IL_0ebf;
																			IL_0ebf:
																			if (22 > b)
																			{
																				break;
																			}
																			goto IL_0ecd;
																			IL_0ecd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])() ? 1 : 0);
																			goto IL_0ef1;
																			IL_0ef1:
																			array[num6] = 0;
																			goto IL_0eff;
																			IL_0eff:
																			num6++;
																			goto IL_0f0d;
																			IL_0f0d:
																			ptr2 += 8;
																			goto end_IL_051c;
																			IL_0ff9:
																			num6--;
																			num = 233;
																			goto end_IL_051c;
																			IL_0f29:
																			array[num6 - 1] = 3;
																			goto IL_0f3d;
																			IL_0f3d:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)KeepAliveFormatPtr[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0f7c;
																			IL_0f7c:
																			ptr2 += 8;
																			goto end_IL_051c;
																			IL_0f8f:
																			if (24 < b)
																			{
																				break;
																			}
																			goto IL_0f9a;
																			IL_0f9a:
																			if (24 > b)
																			{
																				break;
																			}
																			goto IL_0fa5;
																		}
																		break;
																		IL_04de:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_051c;
																continue;
																end_IL_04ee:
																break;
															}
															continue;
															end_IL_0501:
															break;
														}
														continue;
														end_IL_0511:
														break;
													}
													continue;
													end_IL_051c:
													break;
												}
												continue;
												end_IL_1025:
												break;
											}
											continue;
											end_IL_1038:
											break;
										}
										continue;
										end_IL_1042:
										break;
									}
									continue;
									end_IL_104d:
									break;
								}
								continue;
								end_IL_105d:
								break;
							}
							continue;
							end_IL_106d:
							break;
						}
						continue;
						end_IL_107d:
						break;
					}
					continue;
					end_IL_108d:
					break;
				}
				continue;
				end_IL_109d:
				break;
			}
		}
	}

	public static List<string> smethod_7()
	{
		int num = 143;
		int num2 = 13;
		num = 11;
		num = 364;
		num2 = 13;
		num = 28;
		num = 11;
		num2 = 28;
		num = 23;
		num2 = 11;
		num2 = 8;
		num = 31;
		num = 31;
		num = 300;
		num2 = 5;
		num = 60;
		num = 770;
		num2 = 11;
		num = 70;
		num = 60;
		num2 = 70;
		num = 130;
		num2 = 60;
		num2 = 4200;
		num = 4330;
		num = 4330;
		num2 = 31;
		num = 4361;
		num = 935;
		num2 = 5;
		num = 187;
		num2 = 654;
		num2 = 327;
		object obj = "T";
		object obj2 = obj;
		obj = "[";
		object obj3 = obj;
		obj = "M";
		object obj4 = obj;
		obj = "O";
		object obj5 = obj;
		obj = "S";
		object obj6 = obj;
		obj = "E";
		object obj7 = obj;
		obj = "D";
		object obj8 = obj;
		obj = "]";
		object obj9 = obj;
		obj = "N";
		object obj10 = obj;
		obj = "I";
		object obj11 = obj;
		obj = "G";
		object obj12 = obj;
		num = 18;
		num2 = 3;
		num = 6;
		obj = new string[6];
		object obj13 = obj;
		object obj14 = obj3;
		((string[])obj13)[0] = (string)obj14;
		obj13 = obj;
		obj14 = obj4;
		((string[])obj13)[1] = (string)obj14;
		obj13 = obj;
		obj14 = obj5;
		((string[])obj13)[2] = (string)obj14;
		obj13 = obj;
		obj14 = obj8;
		((string[])obj13)[3] = (string)obj14;
		obj13 = obj;
		obj14 = obj6;
		((string[])obj13)[4] = (string)obj14;
		obj13 = obj;
		obj14 = obj9;
		((string[])obj13)[5] = (string)obj14;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj15 = obj;
		num = 130;
		num2 = 13;
		num = 10;
		obj = new string[10];
		obj13 = obj;
		obj14 = obj3;
		((string[])obj13)[0] = (string)obj14;
		obj13 = obj;
		obj14 = obj6;
		((string[])obj13)[1] = (string)obj14;
		obj13 = obj;
		obj14 = obj7;
		((string[])obj13)[2] = (string)obj14;
		obj13 = obj;
		obj14 = obj2;
		((string[])obj13)[3] = (string)obj14;
		obj13 = obj;
		obj14 = obj2;
		((string[])obj13)[4] = (string)obj14;
		obj13 = obj;
		obj14 = obj11;
		((string[])obj13)[5] = (string)obj14;
		obj13 = obj;
		obj14 = obj10;
		((string[])obj13)[6] = (string)obj14;
		obj13 = obj;
		obj14 = obj12;
		((string[])obj13)[7] = (string)obj14;
		obj13 = obj;
		obj14 = obj6;
		((string[])obj13)[8] = (string)obj14;
		obj13 = obj;
		obj14 = obj9;
		((string[])obj13)[9] = (string)obj14;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj16 = obj;
		smethod_1();
		List<string> list = new List<string>();
		obj = list;
		global::_003CModule_003E.list_4 = (List<string>)obj;
		if (bool_0)
		{
			try
			{
				string text3 = smethod_0();
				obj = text3;
				global::_003CModule_003E.string_14 = (string)obj;
				obj = global::_003CModule_003E.string_14;
				if (File.Exists((string)obj))
				{
					obj = global::_003CModule_003E.string_14;
					string[] array = File.ReadAllLines((string)obj);
					obj = array;
					global::_003CModule_003E.string_15 = (string[])obj;
					num = 0;
					global::_003CModule_003E.bool_22 = false;
					num = 1;
					global::_003CModule_003E._0024o_007BlF_007DGg_003Cs = 1;
					while (true)
					{
						num = global::_003CModule_003E._0024o_007BlF_007DGg_003Cs;
						obj13 = global::_003CModule_003E.string_15;
						IntPtr intPtr = (nint)((string[])obj13).LongLength;
						num2 = (int)(nint)intPtr;
						if (num >= num2)
						{
							break;
						}
						obj = global::_003CModule_003E.string_15;
						num2 = global::_003CModule_003E._0024o_007BlF_007DGg_003Cs;
						obj = ((string[])obj)[num2];
						global::_003CModule_003E.string_16 = (string)obj;
						obj = global::_003CModule_003E.string_16;
						if (obj != null)
						{
							obj = global::_003CModule_003E.string_16;
							if (((string)obj).Length != 0)
							{
								obj = global::_003CModule_003E.string_16;
								string text4 = ((string)obj).Trim();
								obj = text4;
								global::_003CModule_003E.string_16 = (string)obj;
								obj = global::_003CModule_003E.string_16;
								obj13 = obj15;
								if ((string)obj == (string)obj13)
								{
									num = 1;
									global::_003CModule_003E.bool_22 = true;
								}
								else
								{
									obj = global::_003CModule_003E.string_16;
									obj13 = obj16;
									if ((string)obj == (string)obj13)
									{
										num = 0;
										global::_003CModule_003E.bool_22 = false;
									}
									else if (global::_003CModule_003E.bool_22)
									{
										obj = global::_003CModule_003E.list_4;
										obj13 = global::_003CModule_003E.string_16;
										((List<string>)obj).Add((string)obj13);
									}
								}
							}
						}
						num = global::_003CModule_003E._0024o_007BlF_007DGg_003Cs;
						num2 = 1;
						num++;
						global::_003CModule_003E._0024o_007BlF_007DGg_003Cs = num;
					}
					goto IL_0504;
				}
				obj = global::_003CModule_003E.list_4;
				global::_003CModule_003E.list_5 = (List<string>)obj;
			}
			catch
			{
				goto IL_0504;
			}
			obj = global::_003CModule_003E.list_5;
			return (List<string>)obj;
		}
		obj = global::_003CModule_003E.list_4;
		return (List<string>)obj;
		IL_0504:
		obj = global::_003CModule_003E.list_4;
		return (List<string>)obj;
	}

	public static void smethod_8()
	{
		int num = 172;
		int num2 = 4;
		num = 43;
		num = 455;
		num2 = 13;
		num = 35;
		num = 43;
		num2 = 35;
		num = 8;
		num2 = 43;
		int num3 = 35;
		num2 = 35;
		num = 43;
		num = 43;
		num = 273;
		num2 = 7;
		num = 39;
		num = 205;
		num2 = 5;
		num = 41;
		num = 39;
		num2 = 41;
		num = 80;
		num2 = 39;
		num3 = 41;
		num2 = 1599;
		num = 1647;
		num = 1647;
		num2 = 43;
		num = 1690;
		num = 560;
		num2 = 4;
		num = 140;
		num2 = 948;
		num3 = 4;
		num2 = 237;
		object obj = "s";
		object obj2 = obj;
		obj = "M";
		object obj3 = obj;
		obj = "r";
		object obj4 = obj;
		obj = "]";
		object obj5 = obj;
		obj = "V";
		object obj6 = obj;
		obj = " ";
		object obj7 = obj;
		obj = "n";
		object obj8 = obj;
		obj = "L";
		object obj9 = obj;
		obj = "T";
		object obj10 = obj;
		obj = "[";
		object obj11 = obj;
		obj = "e";
		object obj12 = obj;
		obj = "p";
		object obj13 = obj;
		obj = "A";
		object obj14 = obj;
		obj = "f";
		object obj15 = obj;
		obj = "D";
		object obj16 = obj;
		obj = "v";
		object obj17 = obj;
		obj = "S";
		object obj18 = obj;
		obj = "a";
		object obj19 = obj;
		obj = "y";
		object obj20 = obj;
		obj = "x";
		object obj21 = obj;
		obj = ":";
		object obj22 = obj;
		obj = "O";
		object obj23 = obj;
		obj = "m";
		object obj24 = obj;
		obj = "t";
		object obj25 = obj;
		obj = "g";
		object obj26 = obj;
		obj = "H";
		object obj27 = obj;
		obj = "E";
		object obj28 = obj;
		obj = "h";
		object obj29 = obj;
		obj = "l";
		object obj30 = obj;
		obj = "j";
		object obj31 = obj;
		obj = "G";
		object obj32 = obj;
		obj = "C";
		object obj33 = obj;
		obj = "B";
		object obj34 = obj;
		obj = "i";
		object obj35 = obj;
		obj = "b";
		object obj36 = obj;
		obj = "w";
		object obj37 = obj;
		obj = "R";
		object obj38 = obj;
		obj = "o";
		object obj39 = obj;
		obj = "N";
		object obj40 = obj;
		obj = "c";
		object obj41 = obj;
		obj = "I";
		object obj42 = obj;
		obj = "u";
		object obj43 = obj;
		obj = "P";
		object obj44 = obj;
		obj = "d";
		object obj45 = obj;
		num = 28;
		num2 = 2;
		num = 14;
		obj = new string[14];
		object obj46 = obj;
		num3 = 0;
		object obj47 = obj32;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj43;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 2;
		obj47 = obj8;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 39;
		num3 = 3;
		obj47 = obj10;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 4;
		obj47 = obj4;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 65;
		num3 = 5;
		obj47 = obj19;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 6;
		obj47 = obj41;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 7;
		obj47 = obj12;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 40;
		num3 = 8;
		obj47 = obj4;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 27;
		num3 = 9;
		obj47 = obj42;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 30;
		num3 = 10;
		obj47 = obj8;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 33;
		num3 = 11;
		obj47 = obj45;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 60;
		num3 = 12;
		obj47 = obj12;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 13;
		obj47 = obj21;
		((string[])obj46)[13] = (string)obj47;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj48 = obj;
		num = 220;
		num2 = 11;
		num = 20;
		obj = new string[20];
		obj46 = obj;
		num3 = 0;
		obj47 = obj44;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj4;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 4;
		num3 = 2;
		obj47 = obj39;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 3;
		obj47 = obj31;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 52;
		num3 = 4;
		obj47 = obj12;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 65;
		num3 = 5;
		obj47 = obj41;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 6;
		obj47 = obj25;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 7;
		obj47 = obj35;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 8;
		obj47 = obj30;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 45;
		num3 = 9;
		obj47 = obj12;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 130;
		num3 = 10;
		obj47 = obj18;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 44;
		num3 = 11;
		obj47 = obj13;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 36;
		num3 = 12;
		obj47 = obj12;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 13;
		obj47 = obj12;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 98;
		num3 = 14;
		obj47 = obj45;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 105;
		num3 = 15;
		obj47 = obj42;
		((string[])obj46)[15] = (string)obj47;
		obj46 = obj;
		num3 = 112;
		num3 = 16;
		obj47 = obj8;
		((string[])obj46)[16] = (string)obj47;
		obj46 = obj;
		num3 = 85;
		num3 = 17;
		obj47 = obj45;
		((string[])obj46)[17] = (string)obj47;
		obj46 = obj;
		num3 = 54;
		num3 = 18;
		obj47 = obj12;
		((string[])obj46)[18] = (string)obj47;
		obj46 = obj;
		num3 = 209;
		num3 = 19;
		obj47 = obj21;
		((string[])obj46)[19] = (string)obj47;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj49 = obj;
		num = 42;
		num2 = 7;
		num = 6;
		obj = new string[6];
		obj46 = obj;
		num3 = 0;
		obj47 = obj11;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj3;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 6;
		num3 = 2;
		obj47 = obj23;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 15;
		num3 = 3;
		obj47 = obj16;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 4;
		obj47 = obj18;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 25;
		num3 = 5;
		obj47 = obj5;
		((string[])obj46)[5] = (string)obj47;
		string text3 = string.Concat((string[])obj);
		obj = text3;
		object obj50 = obj;
		num = 52;
		num2 = 13;
		num = 4;
		obj = new string[4];
		obj46 = obj;
		num3 = 0;
		obj47 = obj9;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj12;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 22;
		num3 = 2;
		obj47 = obj15;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 39;
		num3 = 3;
		obj47 = obj25;
		((string[])obj46)[3] = (string)obj47;
		string text4 = string.Concat((string[])obj);
		obj = text4;
		object obj51 = obj;
		num = 57;
		num2 = 3;
		num = 19;
		obj = new string[19];
		obj46 = obj;
		num3 = 0;
		obj47 = obj14;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj8;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 2;
		obj47 = obj25;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 9;
		num3 = 3;
		obj47 = obj35;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 4;
		obj47 = obj38;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 65;
		num3 = 5;
		obj47 = obj12;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 6;
		obj47 = obj13;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 7;
		obj47 = obj39;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 16;
		num3 = 8;
		obj47 = obj4;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 63;
		num3 = 9;
		obj47 = obj25;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 130;
		num3 = 10;
		obj47 = obj10;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 44;
		num3 = 11;
		obj47 = obj20;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 156;
		num3 = 12;
		obj47 = obj13;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 143;
		num3 = 13;
		obj47 = obj12;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 182;
		num3 = 14;
		obj47 = obj42;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 165;
		num3 = 15;
		obj47 = obj8;
		((string[])obj46)[15] = (string)obj47;
		obj46 = obj;
		num3 = 208;
		num3 = 16;
		obj47 = obj45;
		((string[])obj46)[16] = (string)obj47;
		obj46 = obj;
		num3 = 119;
		num3 = 17;
		obj47 = obj12;
		((string[])obj46)[17] = (string)obj47;
		obj46 = obj;
		num3 = 234;
		num3 = 18;
		obj47 = obj21;
		((string[])obj46)[18] = (string)obj47;
		string text5 = string.Concat((string[])obj);
		obj = text5;
		object obj52 = obj;
		num = 126;
		num2 = 7;
		num = 18;
		obj = new string[18];
		obj46 = obj;
		num3 = 0;
		obj47 = obj14;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj8;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 22;
		num3 = 2;
		obj47 = obj25;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 3;
		obj47 = obj35;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 52;
		num3 = 4;
		obj47 = obj38;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 5;
		obj47 = obj12;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 30;
		num3 = 6;
		obj47 = obj13;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 35;
		num3 = 7;
		obj47 = obj39;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 88;
		num3 = 8;
		obj47 = obj4;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 36;
		num3 = 9;
		obj47 = obj25;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 110;
		num3 = 10;
		obj47 = obj16;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 77;
		num3 = 11;
		obj47 = obj35;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 60;
		num3 = 12;
		obj47 = obj2;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 39;
		num3 = 13;
		obj47 = obj25;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 42;
		num3 = 14;
		obj47 = obj19;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 45;
		num3 = 15;
		obj47 = obj8;
		((string[])obj46)[15] = (string)obj47;
		obj46 = obj;
		num3 = 48;
		num3 = 16;
		obj47 = obj41;
		((string[])obj46)[16] = (string)obj47;
		obj46 = obj;
		num3 = 119;
		num3 = 17;
		obj47 = obj12;
		((string[])obj46)[17] = (string)obj47;
		string text6 = string.Concat((string[])obj);
		obj = text6;
		object obj53 = obj;
		num = 110;
		num2 = 11;
		num = 10;
		obj = new string[10];
		obj46 = obj;
		num3 = 0;
		obj47 = obj14;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj43;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 22;
		num3 = 2;
		obj47 = obj45;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 9;
		num3 = 3;
		obj47 = obj35;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 4;
		obj47 = obj39;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 25;
		num3 = 5;
		obj47 = obj42;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 66;
		num3 = 6;
		obj47 = obj8;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 7;
		obj47 = obj45;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 40;
		num3 = 8;
		obj47 = obj12;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 117;
		num3 = 9;
		obj47 = obj21;
		((string[])obj46)[9] = (string)obj47;
		string text7 = string.Concat((string[])obj);
		obj = text7;
		object obj54 = obj;
		num = 70;
		num2 = 5;
		num = 14;
		obj = new string[14];
		obj46 = obj;
		num3 = 0;
		obj47 = obj3;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj12;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 6;
		num3 = 2;
		obj47 = obj8;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 3;
		obj47 = obj43;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 4;
		obj47 = obj18;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 5;
		obj47 = obj25;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 6;
		obj47 = obj20;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 49;
		num3 = 7;
		obj47 = obj30;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 8;
		obj47 = obj12;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 99;
		num3 = 9;
		obj47 = obj42;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 50;
		num3 = 10;
		obj47 = obj8;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 22;
		num3 = 11;
		obj47 = obj45;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 156;
		num3 = 12;
		obj47 = obj12;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 65;
		num3 = 13;
		obj47 = obj21;
		((string[])obj46)[13] = (string)obj47;
		string text8 = string.Concat((string[])obj);
		obj = text8;
		object obj55 = obj;
		num = 208;
		num2 = 13;
		num = 16;
		obj = new string[16];
		obj46 = obj;
		num3 = 0;
		obj47 = obj42;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj24;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 2;
		obj47 = obj13;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 6;
		num3 = 3;
		obj47 = obj19;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 16;
		num3 = 4;
		obj47 = obj41;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 5;
		obj47 = obj25;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 66;
		num3 = 6;
		obj47 = obj33;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 7;
		obj47 = obj39;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 8;
		obj47 = obj30;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 36;
		num3 = 9;
		obj47 = obj39;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 110;
		num3 = 10;
		obj47 = obj4;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 77;
		num3 = 11;
		obj47 = obj42;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 12;
		obj47 = obj8;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 143;
		num3 = 13;
		obj47 = obj45;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 56;
		num3 = 14;
		obj47 = obj12;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 165;
		num3 = 15;
		obj47 = obj21;
		((string[])obj46)[15] = (string)obj47;
		string text9 = string.Concat((string[])obj);
		obj = text9;
		object obj56 = obj;
		num = 75;
		num2 = 5;
		num = 15;
		obj = new string[15];
		obj46 = obj;
		num3 = 0;
		obj47 = obj18;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj13;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 4;
		num3 = 2;
		obj47 = obj12;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 6;
		num3 = 3;
		obj47 = obj12;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 4;
		obj47 = obj45;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 25;
		num3 = 5;
		obj47 = obj34;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 30;
		num3 = 6;
		obj47 = obj39;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 7;
		obj47 = obj39;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 8;
		obj47 = obj2;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 63;
		num3 = 9;
		obj47 = obj25;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 50;
		num3 = 10;
		obj47 = obj9;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 44;
		num3 = 11;
		obj47 = obj12;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 12;
		obj47 = obj17;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 143;
		num3 = 13;
		obj47 = obj12;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 14;
		obj47 = obj30;
		((string[])obj46)[14] = (string)obj47;
		string text10 = string.Concat((string[])obj);
		obj = text10;
		object obj57 = obj;
		num = 24;
		num2 = 3;
		num = 8;
		obj = new string[8];
		obj46 = obj;
		num3 = 0;
		obj47 = obj9;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj19;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 2;
		obj47 = obj26;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 3;
		obj47 = obj44;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 4;
		obj47 = obj39;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 55;
		num3 = 5;
		obj47 = obj37;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 30;
		num3 = 6;
		obj47 = obj12;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 7;
		obj47 = obj4;
		((string[])obj46)[7] = (string)obj47;
		string text11 = string.Concat((string[])obj);
		obj = text11;
		object obj58 = obj;
		num = 195;
		num2 = 13;
		num = 15;
		obj = new string[15];
		obj46 = obj;
		num3 = 0;
		obj47 = obj32;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj43;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 2;
		obj47 = obj8;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 9;
		num3 = 3;
		obj47 = obj18;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 16;
		num3 = 4;
		obj47 = obj39;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 5;
		obj47 = obj43;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 66;
		num3 = 6;
		obj47 = obj8;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 7;
		obj47 = obj45;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 88;
		num3 = 8;
		obj47 = obj28;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 117;
		num3 = 9;
		obj47 = obj8;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 10;
		obj47 = obj19;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 77;
		num3 = 11;
		obj47 = obj36;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 132;
		num3 = 12;
		obj47 = obj30;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 169;
		num3 = 13;
		obj47 = obj12;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 14;
		obj47 = obj45;
		((string[])obj46)[14] = (string)obj47;
		string text12 = string.Concat((string[])obj);
		obj = text12;
		object obj59 = obj;
		num = 143;
		num2 = 11;
		num = 13;
		obj = new string[13];
		obj46 = obj;
		num3 = 0;
		obj47 = obj14;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj43;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 2;
		obj47 = obj45;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 15;
		num3 = 3;
		obj47 = obj35;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 52;
		num3 = 4;
		obj47 = obj39;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 15;
		num3 = 5;
		obj47 = obj7;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 42;
		num3 = 6;
		obj47 = obj42;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 7;
		obj47 = obj8;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 8;
		obj47 = obj45;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 36;
		num3 = 9;
		obj47 = obj12;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 70;
		num3 = 10;
		obj47 = obj21;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 77;
		num3 = 11;
		obj47 = obj22;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 132;
		num3 = 12;
		obj47 = obj7;
		((string[])obj46)[12] = (string)obj47;
		string text13 = string.Concat((string[])obj);
		obj = text13;
		object obj60 = obj;
		num = 198;
		num2 = 11;
		num = 18;
		obj = new string[18];
		obj46 = obj;
		num3 = 0;
		obj47 = obj18;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj39;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 2;
		obj47 = obj43;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 15;
		num3 = 3;
		obj47 = obj8;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 52;
		num3 = 4;
		obj47 = obj45;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 65;
		num3 = 5;
		obj47 = obj36;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 42;
		num3 = 6;
		obj47 = obj39;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 7;
		obj47 = obj19;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 88;
		num3 = 8;
		obj47 = obj4;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 36;
		num3 = 9;
		obj47 = obj45;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 70;
		num3 = 10;
		obj47 = obj27;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 55;
		num3 = 11;
		obj47 = obj12;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 84;
		num3 = 12;
		obj47 = obj19;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 52;
		num3 = 13;
		obj47 = obj4;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 70;
		num3 = 14;
		obj47 = obj18;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 75;
		num3 = 15;
		obj47 = obj12;
		((string[])obj46)[15] = (string)obj47;
		obj46 = obj;
		num3 = 32;
		num3 = 16;
		obj47 = obj30;
		((string[])obj46)[16] = (string)obj47;
		obj46 = obj;
		num3 = 34;
		num3 = 17;
		obj47 = obj15;
		((string[])obj46)[17] = (string)obj47;
		string text14 = string.Concat((string[])obj);
		obj = text14;
		object obj61 = obj;
		num = 154;
		num2 = 11;
		num = 14;
		obj = new string[14];
		obj46 = obj;
		num3 = 0;
		obj47 = obj27;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj12;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 2;
		obj47 = obj19;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 3;
		obj47 = obj4;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 52;
		num3 = 4;
		obj47 = obj7;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 25;
		num3 = 5;
		obj47 = obj18;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 6;
		obj47 = obj12;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 7;
		obj47 = obj30;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 16;
		num3 = 8;
		obj47 = obj15;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 27;
		num3 = 9;
		obj47 = obj22;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 70;
		num3 = 10;
		obj47 = obj7;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 121;
		num3 = 11;
		obj47 = obj23;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 12;
		obj47 = obj15;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 13;
		obj47 = obj15;
		((string[])obj46)[13] = (string)obj47;
		string text15 = string.Concat((string[])obj);
		obj = text15;
		object obj62 = obj;
		num = 48;
		num2 = 4;
		num = 12;
		obj = new string[12];
		obj46 = obj;
		num3 = 0;
		obj47 = obj32;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj4;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 2;
		obj47 = obj19;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 33;
		num3 = 3;
		obj47 = obj17;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 4;
		obj47 = obj35;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 55;
		num3 = 5;
		obj47 = obj25;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 78;
		num3 = 6;
		obj47 = obj20;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 49;
		num3 = 7;
		obj47 = obj6;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 88;
		num3 = 8;
		obj47 = obj19;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 63;
		num3 = 9;
		obj47 = obj30;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 70;
		num3 = 10;
		obj47 = obj43;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 22;
		num3 = 11;
		obj47 = obj12;
		((string[])obj46)[11] = (string)obj47;
		string text16 = string.Concat((string[])obj);
		obj = text16;
		object obj63 = obj;
		num = 70;
		num2 = 7;
		num = 10;
		obj = new string[10];
		obj46 = obj;
		num3 = 0;
		obj47 = obj10;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj29;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 14;
		num3 = 2;
		obj47 = obj12;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 3;
		obj47 = obj24;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 4;
		obj47 = obj12;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 65;
		num3 = 5;
		obj47 = obj42;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 78;
		num3 = 6;
		obj47 = obj8;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 35;
		num3 = 7;
		obj47 = obj45;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 32;
		num3 = 8;
		obj47 = obj12;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 45;
		num3 = 9;
		obj47 = obj21;
		((string[])obj46)[9] = (string)obj47;
		string text17 = string.Concat((string[])obj);
		obj = text17;
		object obj64 = obj;
		num = 64;
		num2 = 4;
		num = 16;
		obj = new string[16];
		obj46 = obj;
		num3 = 0;
		obj47 = obj6;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj35;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 2;
		obj47 = obj2;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 33;
		num3 = 3;
		obj47 = obj43;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 4;
		obj47 = obj19;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 15;
		num3 = 5;
		obj47 = obj30;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 6;
		obj47 = obj10;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 49;
		num3 = 7;
		obj47 = obj29;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 32;
		num3 = 8;
		obj47 = obj12;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 117;
		num3 = 9;
		obj47 = obj24;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 30;
		num3 = 10;
		obj47 = obj12;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 33;
		num3 = 11;
		obj47 = obj42;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 156;
		num3 = 12;
		obj47 = obj8;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 39;
		num3 = 13;
		obj47 = obj45;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 182;
		num3 = 14;
		obj47 = obj12;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 165;
		num3 = 15;
		obj47 = obj21;
		((string[])obj46)[15] = (string)obj47;
		string text18 = string.Concat((string[])obj);
		obj = text18;
		object obj65 = obj;
		num = 52;
		num2 = 4;
		num = 13;
		obj = new string[13];
		obj46 = obj;
		num3 = 0;
		obj47 = obj27;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj12;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 4;
		num3 = 2;
		obj47 = obj19;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 6;
		num3 = 3;
		obj47 = obj4;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 52;
		num3 = 4;
		obj47 = obj7;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 5;
		obj47 = obj18;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 6;
		obj47 = obj12;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 7;
		obj47 = obj30;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 56;
		num3 = 8;
		obj47 = obj15;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 36;
		num3 = 9;
		obj47 = obj22;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 50;
		num3 = 10;
		obj47 = obj7;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 77;
		num3 = 11;
		obj47 = obj23;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 156;
		num3 = 12;
		obj47 = obj8;
		((string[])obj46)[12] = (string)obj47;
		string text19 = string.Concat((string[])obj);
		obj = text19;
		object obj66 = obj;
		num = 195;
		num2 = 13;
		num = 15;
		obj = new string[15];
		obj46 = obj;
		num3 = 0;
		obj47 = obj18;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj25;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 2;
		obj47 = obj12;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 3;
		obj47 = obj19;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 28;
		num3 = 4;
		obj47 = obj24;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 25;
		num3 = 5;
		obj47 = obj14;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 42;
		num3 = 6;
		obj47 = obj4;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 7;
		obj47 = obj24;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 8;
		obj47 = obj2;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 27;
		num3 = 9;
		obj47 = obj9;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 50;
		num3 = 10;
		obj47 = obj12;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 33;
		num3 = 11;
		obj47 = obj8;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 156;
		num3 = 12;
		obj47 = obj26;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 169;
		num3 = 13;
		obj47 = obj25;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 182;
		num3 = 14;
		obj47 = obj29;
		((string[])obj46)[14] = (string)obj47;
		string text20 = string.Concat((string[])obj);
		obj = text20;
		object obj67 = obj;
		num = 35;
		num2 = 7;
		num = 5;
		obj = new string[5];
		obj46 = obj;
		num3 = 0;
		obj47 = obj38;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj35;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 22;
		num3 = 2;
		obj47 = obj26;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 33;
		num3 = 3;
		obj47 = obj29;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 4;
		obj47 = obj25;
		((string[])obj46)[4] = (string)obj47;
		string text21 = string.Concat((string[])obj);
		obj = text21;
		object obj68 = obj;
		num = 91;
		num2 = 7;
		num = 13;
		obj = new string[13];
		obj46 = obj;
		num3 = 0;
		obj47 = obj32;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj43;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 4;
		num3 = 2;
		obj47 = obj8;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 15;
		num3 = 3;
		obj47 = obj33;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 4;
		obj47 = obj39;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 5;
		obj47 = obj30;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 6;
		obj47 = obj39;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 49;
		num3 = 7;
		obj47 = obj4;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 56;
		num3 = 8;
		obj47 = obj42;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 99;
		num3 = 9;
		obj47 = obj8;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 40;
		num3 = 10;
		obj47 = obj45;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 77;
		num3 = 11;
		obj47 = obj12;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 48;
		num3 = 12;
		obj47 = obj21;
		((string[])obj46)[12] = (string)obj47;
		string text22 = string.Concat((string[])obj);
		obj = text22;
		object obj69 = obj;
		num = 198;
		num2 = 11;
		num = 18;
		obj = new string[18];
		obj46 = obj;
		num3 = 0;
		obj47 = obj44;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj30;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 2;
		obj47 = obj19;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 9;
		num3 = 3;
		obj47 = obj25;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 4;
		obj47 = obj15;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 65;
		num3 = 5;
		obj47 = obj39;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 6;
		obj47 = obj4;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 7;
		obj47 = obj24;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 32;
		num3 = 8;
		obj47 = obj33;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 9;
		obj47 = obj39;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 10;
		obj47 = obj30;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 33;
		num3 = 11;
		obj47 = obj39;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 36;
		num3 = 12;
		obj47 = obj4;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 169;
		num3 = 13;
		obj47 = obj42;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 56;
		num3 = 14;
		obj47 = obj8;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 30;
		num3 = 15;
		obj47 = obj45;
		((string[])obj46)[15] = (string)obj47;
		obj46 = obj;
		num3 = 64;
		num3 = 16;
		obj47 = obj12;
		((string[])obj46)[16] = (string)obj47;
		obj46 = obj;
		num3 = 68;
		num3 = 17;
		obj47 = obj21;
		((string[])obj46)[17] = (string)obj47;
		string text23 = string.Concat((string[])obj);
		obj = text23;
		object obj70 = obj;
		num = 44;
		num2 = 4;
		num = 11;
		obj = new string[11];
		obj46 = obj;
		num3 = 0;
		obj47 = obj3;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj12;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 2;
		obj47 = obj8;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 3;
		obj47 = obj43;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 16;
		num3 = 4;
		obj47 = obj7;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 5;
		obj47 = obj27;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 6;
		obj47 = obj19;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 7;
		obj47 = obj8;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 32;
		num3 = 8;
		obj47 = obj45;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 9;
		obj47 = obj22;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 130;
		num3 = 10;
		obj47 = obj7;
		((string[])obj46)[10] = (string)obj47;
		string text24 = string.Concat((string[])obj);
		obj = text24;
		object obj71 = obj;
		num = 30;
		num2 = 3;
		num = 10;
		obj = new string[10];
		obj46 = obj;
		num3 = 0;
		obj47 = obj11;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj18;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 4;
		num3 = 2;
		obj47 = obj28;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 21;
		num3 = 3;
		obj47 = obj10;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 8;
		num3 = 4;
		obj47 = obj10;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 25;
		num3 = 5;
		obj47 = obj42;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 42;
		num3 = 6;
		obj47 = obj40;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 7;
		obj47 = obj32;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 40;
		num3 = 8;
		obj47 = obj18;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 117;
		num3 = 9;
		obj47 = obj5;
		((string[])obj46)[9] = (string)obj47;
		string text25 = string.Concat((string[])obj);
		obj = text25;
		object obj72 = obj;
		num = 100;
		num2 = 5;
		num = 20;
		obj = new string[20];
		obj46 = obj;
		num3 = 0;
		obj47 = obj44;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj4;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 2;
		obj47 = obj39;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 6;
		num3 = 3;
		obj47 = obj31;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 12;
		num3 = 4;
		obj47 = obj12;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 5;
		obj47 = obj41;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 42;
		num3 = 6;
		obj47 = obj25;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 35;
		num3 = 7;
		obj47 = obj35;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 56;
		num3 = 8;
		obj47 = obj30;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 63;
		num3 = 9;
		obj47 = obj12;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 130;
		num3 = 10;
		obj47 = obj33;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 121;
		num3 = 11;
		obj47 = obj39;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 12;
		obj47 = obj30;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 26;
		num3 = 13;
		obj47 = obj39;
		((string[])obj46)[13] = (string)obj47;
		obj46 = obj;
		num3 = 182;
		num3 = 14;
		obj47 = obj4;
		((string[])obj46)[14] = (string)obj47;
		obj46 = obj;
		num3 = 60;
		num3 = 15;
		obj47 = obj42;
		((string[])obj46)[15] = (string)obj47;
		obj46 = obj;
		num3 = 176;
		num3 = 16;
		obj47 = obj8;
		((string[])obj46)[16] = (string)obj47;
		obj46 = obj;
		num3 = 85;
		num3 = 17;
		obj47 = obj45;
		((string[])obj46)[17] = (string)obj47;
		obj46 = obj;
		num3 = 126;
		num3 = 18;
		obj47 = obj12;
		((string[])obj46)[18] = (string)obj47;
		obj46 = obj;
		num3 = 57;
		num3 = 19;
		obj47 = obj21;
		((string[])obj46)[19] = (string)obj47;
		string text26 = string.Concat((string[])obj);
		obj = text26;
		object obj73 = obj;
		num = 154;
		num2 = 11;
		num = 14;
		obj = new string[14];
		obj46 = obj;
		num3 = 0;
		obj47 = obj3;
		((string[])obj46)[0] = (string)obj47;
		obj46 = obj;
		num3 = 1;
		obj47 = obj12;
		((string[])obj46)[1] = (string)obj47;
		obj46 = obj;
		num3 = 10;
		num3 = 2;
		obj47 = obj8;
		((string[])obj46)[2] = (string)obj47;
		obj46 = obj;
		num3 = 9;
		num3 = 3;
		obj47 = obj43;
		((string[])obj46)[3] = (string)obj47;
		obj46 = obj;
		num3 = 16;
		num3 = 4;
		obj47 = obj27;
		((string[])obj46)[4] = (string)obj47;
		obj46 = obj;
		num3 = 25;
		num3 = 5;
		obj47 = obj19;
		((string[])obj46)[5] = (string)obj47;
		obj46 = obj;
		num3 = 18;
		num3 = 6;
		obj47 = obj8;
		((string[])obj46)[6] = (string)obj47;
		obj46 = obj;
		num3 = 49;
		num3 = 7;
		obj47 = obj45;
		((string[])obj46)[7] = (string)obj47;
		obj46 = obj;
		num3 = 24;
		num3 = 8;
		obj47 = obj42;
		((string[])obj46)[8] = (string)obj47;
		obj46 = obj;
		num3 = 45;
		num3 = 9;
		obj47 = obj2;
		((string[])obj46)[9] = (string)obj47;
		obj46 = obj;
		num3 = 20;
		num3 = 10;
		obj47 = obj9;
		((string[])obj46)[10] = (string)obj47;
		obj46 = obj;
		num3 = 143;
		num3 = 11;
		obj47 = obj12;
		((string[])obj46)[11] = (string)obj47;
		obj46 = obj;
		num3 = 60;
		num3 = 12;
		obj47 = obj15;
		((string[])obj46)[12] = (string)obj47;
		obj46 = obj;
		num3 = 91;
		num3 = 13;
		obj47 = obj25;
		((string[])obj46)[13] = (string)obj47;
		string text27 = string.Concat((string[])obj);
		obj = text27;
		object obj74 = obj;
		smethod_1();
		if (!bool_0)
		{
			return;
		}
		try
		{
			string text28 = smethod_0();
			obj = text28;
			global::_003CModule_003E.string_17 = (string)obj;
			obj = global::_003CModule_003E.string_17;
			if (!File.Exists((string)obj))
			{
				return;
			}
			obj = global::_003CModule_003E.string_17;
			string[] array = File.ReadAllLines((string)obj);
			obj = array;
			global::_003CModule_003E.string_18 = (string[])obj;
			num = 0;
			global::_003CModule_003E.bool_23 = false;
			num = 1;
			global::_003CModule_003E.int_43 = 1;
			while (true)
			{
				num = global::_003CModule_003E.int_43;
				obj46 = global::_003CModule_003E.string_18;
				IntPtr intPtr = (nint)((string[])obj46).LongLength;
				num2 = (int)(nint)intPtr;
				if (num >= num2)
				{
					break;
				}
				obj = global::_003CModule_003E.string_18;
				num2 = global::_003CModule_003E.int_43;
				obj = ((string[])obj)[num2];
				global::_003CModule_003E.string_19 = (string)obj;
				obj = global::_003CModule_003E.string_19;
				if (obj != null)
				{
					obj = global::_003CModule_003E.string_19;
					if (((string)obj).Length != 0)
					{
						obj = global::_003CModule_003E.string_19;
						string text29 = ((string)obj).Trim();
						obj = text29;
						global::_003CModule_003E.string_19 = (string)obj;
						obj = global::_003CModule_003E.string_19;
						obj46 = obj72;
						if ((string)obj == (string)obj46)
						{
							num = 1;
							global::_003CModule_003E.bool_23 = true;
						}
						else
						{
							obj = global::_003CModule_003E.string_19;
							obj46 = obj50;
							if ((string)obj == (string)obj46)
							{
								num = 0;
								global::_003CModule_003E.bool_23 = false;
							}
							else if (global::_003CModule_003E.bool_23)
							{
								obj = global::_003CModule_003E.string_19;
								double num4 = 30.5;
								double num5 = 30.5;
								num4 = 61.0;
								int num6 = Convert.ToInt32(num4);
								num2 = num6;
								int num7 = ((string)obj).IndexOf((char)num2);
								num = num7;
								global::_003CModule_003E.int_44 = num;
								num = global::_003CModule_003E.int_44;
								num2 = -1;
								if (num != -1)
								{
									obj = global::_003CModule_003E.string_19;
									num2 = 0;
									num3 = global::_003CModule_003E.int_44;
									string text30 = ((string)obj).Substring(0, num3);
									obj = text30;
									global::_003CModule_003E.string_20 = (string)obj;
									obj = global::_003CModule_003E.string_19;
									num2 = global::_003CModule_003E.int_44;
									num3 = 1;
									num2++;
									string text31 = ((string)obj).Substring(num2);
									obj = text31;
									global::_003CModule_003E.string_21 = (string)obj;
									obj = global::_003CModule_003E.string_20;
									if (obj != null)
									{
										obj = global::_003CModule_003E.string_20;
										int length = ((string)obj).Length;
										num = length;
										global::_003CModule_003E.int_45 = num;
										num = global::_003CModule_003E.int_45;
										num4 = 12.0;
										num5 = 4.0;
										double num8 = Math.Round(num5);
										num5 = num8;
										num4 -= num5;
										int num9 = Convert.ToInt32(num4);
										num2 = num9;
										switch (num - num2)
										{
										default:
											obj = global::_003CModule_003E.string_20;
											obj46 = obj58;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (int.TryParse((string)obj, out global::_003CModule_003E.int_53))
												{
													num = global::_003CModule_003E.int_53;
													num4 = 201.0;
													num5 = 100.0;
													double num20 = Math.Tanh(num5);
													num5 = num20;
													num4 -= num5;
													int num21 = Convert.ToInt32(num4);
													num2 = num21;
													num5 = 2.0;
													double d = 500.0;
													num5 = 1000.0;
													int num22 = Convert.ToInt32(num5);
													num3 = num22;
													int num23 = Mathf.Clamp(num, num2, num3);
													num = num23;
													Class132.int_0 = num;
												}
											}
											break;
										case 1:
										{
											obj = global::_003CModule_003E.string_20;
											num2 = 0;
											char c3 = ((string)obj)[0];
											num = c3;
											global::_003CModule_003E.char_3 = (char)num;
											num = global::_003CModule_003E.char_3;
											num2 = 130;
											num3 = 2;
											num2 = 65;
											if (num != 65)
											{
												num = global::_003CModule_003E.char_3;
												num2 = 1092;
												num3 = 13;
												num2 = 84;
												if (num != 84)
												{
													break;
												}
												obj = global::_003CModule_003E.string_20;
												obj46 = obj64;
												if ((string)obj == (string)obj46)
												{
													obj = global::_003CModule_003E.string_21;
													if (int.TryParse((string)obj, out global::_003CModule_003E.int_47))
													{
														num = global::_003CModule_003E.int_47;
														Class139.CurrentIndex = num;
													}
												}
												break;
											}
											obj = global::_003CModule_003E.string_20;
											obj46 = obj54;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (int.TryParse((string)obj, out global::_003CModule_003E.int_54))
												{
													num = global::_003CModule_003E.int_54;
													num2 = 0;
													num5 = 150.0;
													double d = 150.0;
													double num12 = Math.Floor(d);
													d = num12;
													num5 += d;
													int num13 = Convert.ToInt32(num5);
													num3 = num13;
													int num14 = Mathf.Clamp(num, 0, num3);
													num = num14;
													Class223.int_0 = num;
													obj = obj60;
													string text32 = Class223.int_0.ToString();
													obj46 = text32;
													string text33 = (string)obj + (string)obj46;
													obj = text33;
													BundleManager.smethod_59((string)obj);
												}
											}
											break;
										}
										case 3:
											obj = global::_003CModule_003E.string_20;
											obj46 = obj63;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (float.TryParse((string)obj, out global::_003CModule_003E.float_26))
												{
													double num11 = global::_003CModule_003E.float_26;
													Class13.float_0 = (float)num11;
												}
											}
											break;
										case 4:
											obj = global::_003CModule_003E.string_20;
											obj46 = obj69;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (int.TryParse((string)obj, out global::_003CModule_003E.int_49))
												{
													num = global::_003CModule_003E.int_49;
													Class129.CurrentIndex = num;
												}
											}
											break;
										case 5:
										{
											obj = global::_003CModule_003E.string_20;
											num4 = 6.185039863261519;
											num5 = 2.0;
											double num17 = Math.Tan(num5);
											num5 = num17;
											num4 += num5;
											int num18 = Convert.ToInt32(num4);
											num2 = num18;
											char c6 = ((string)obj)[num2];
											num = c6;
											global::_003CModule_003E.char_3 = (char)num;
											num = global::_003CModule_003E.char_3;
											num2 = 288;
											num3 = 4;
											num2 = 72;
											if (num != 72)
											{
												num = global::_003CModule_003E.char_3;
												num2 = 581;
												num3 = 7;
												num2 = 83;
												if (num != 83)
												{
													num = global::_003CModule_003E.char_3;
													num2 = 342;
													num3 = 3;
													num2 = 114;
													if (num != 114)
													{
														break;
													}
													obj = global::_003CModule_003E.string_20;
													obj46 = obj48;
													if ((string)obj == (string)obj46)
													{
														obj = global::_003CModule_003E.string_21;
														if (int.TryParse((string)obj, out global::_003CModule_003E.int_48))
														{
															num = global::_003CModule_003E.int_48;
															Class131.CurrentIndex = num;
														}
													}
													break;
												}
												obj = global::_003CModule_003E.string_20;
												obj46 = obj55;
												if ((string)obj == (string)obj46)
												{
													obj = global::_003CModule_003E.string_21;
													if (int.TryParse((string)obj, out global::_003CModule_003E.int_55))
													{
														num = global::_003CModule_003E.int_55;
														Class134.CurrentStyle = num;
													}
												}
											}
											else
											{
												obj = global::_003CModule_003E.string_20;
												obj46 = obj74;
												if ((string)obj == (string)obj46)
												{
													obj = global::_003CModule_003E.string_21;
													obj46 = "1";
													num = (((string)obj == (string)obj46) ? 1 : 0);
													Class133.bool_0 = (byte)num != 0;
													obj = obj71;
													string text34 = string.Concat(str1: (string)((!Class133.bool_0) ? obj68 : obj51), str0: (string)obj);
													obj = text34;
													BundleManager.smethod_18((string)obj);
												}
											}
											break;
										}
										case 6:
										{
											obj = global::_003CModule_003E.string_20;
											num2 = 1;
											char c4 = ((string)obj)[1];
											num = c4;
											global::_003CModule_003E.char_3 = (char)num;
											num = global::_003CModule_003E.char_3;
											num2 = 784;
											num3 = 7;
											num2 = 112;
											if (num != 112)
											{
												num = global::_003CModule_003E.char_3;
												num2 = 1276;
												num3 = 11;
												num2 = 116;
												if (num != 116)
												{
													num = global::_003CModule_003E.char_3;
													num2 = 1287;
													num3 = 11;
													num2 = 117;
													if (num != 117)
													{
														break;
													}
													obj = global::_003CModule_003E.string_20;
													obj46 = obj59;
													if ((string)obj == (string)obj46)
													{
														obj = global::_003CModule_003E.string_21;
														if (bool.TryParse((string)obj, out global::_003CModule_003E.bool_24))
														{
															num = (global::_003CModule_003E.bool_24 ? 1 : 0);
															Class130.SoundEnabled = (byte)num != 0;
														}
													}
													break;
												}
												obj = global::_003CModule_003E.string_20;
												obj46 = obj67;
												if ((string)obj == (string)obj46)
												{
													obj = global::_003CModule_003E.string_21;
													if (float.TryParse((string)obj, out global::_003CModule_003E.float_24))
													{
														double num11 = global::_003CModule_003E.float_24;
														num4 = 0.5;
														num5 = 3.0;
														float num15 = Mathf.Clamp((float)num11, (float)num4, (float)num5);
														num11 = num15;
														Class207.float_0 = (float)num11;
													}
												}
												break;
											}
											obj = global::_003CModule_003E.string_20;
											obj46 = obj57;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (float.TryParse((string)obj, out global::_003CModule_003E.float_25))
												{
													double num11 = global::_003CModule_003E.float_25;
													num4 = 1.0;
													num5 = 20.0;
													float num16 = Mathf.Clamp((float)num11, (float)num4, (float)num5);
													num11 = num16;
													Class253.float_0 = (float)num11;
												}
											}
											break;
										}
										case 7:
										{
											obj = global::_003CModule_003E.string_20;
											num2 = 0;
											char c2 = ((string)obj)[0];
											num = c2;
											global::_003CModule_003E.char_3 = (char)num;
											num = global::_003CModule_003E.char_3;
											num2 = 365;
											num3 = 5;
											num2 = 73;
											if (num != 73)
											{
												num = global::_003CModule_003E.char_3;
												num2 = 430;
												num3 = 5;
												num2 = 86;
												if (num != 86)
												{
													break;
												}
												obj = global::_003CModule_003E.string_20;
												obj46 = obj65;
												if ((string)obj == (string)obj46)
												{
													obj = global::_003CModule_003E.string_21;
													if (int.TryParse((string)obj, out global::_003CModule_003E.int_50))
													{
														num = global::_003CModule_003E.int_50;
														Class140.CurrentIndex = num;
													}
												}
												break;
											}
											obj = global::_003CModule_003E.string_20;
											obj46 = obj56;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (int.TryParse((string)obj, out global::_003CModule_003E.int_52))
												{
													num = global::_003CModule_003E.int_52;
													Class9.int_3 = num;
												}
											}
											break;
										}
										case 9:
										{
											obj = global::_003CModule_003E.string_20;
											num2 = 0;
											char c5 = ((string)obj)[0];
											num = c5;
											global::_003CModule_003E.char_3 = (char)num;
											num = global::_003CModule_003E.char_3;
											num2 = 455;
											num3 = 7;
											num2 = 65;
											if (num != 65)
											{
												num = global::_003CModule_003E.char_3;
												num2 = 880;
												num3 = 11;
												num2 = 80;
												if (num != 80)
												{
													num = global::_003CModule_003E.char_3;
													num2 = 1079;
													num3 = 13;
													num2 = 83;
													if (num == 83)
													{
														obj = global::_003CModule_003E.string_20;
														obj46 = obj61;
														if ((string)obj == (string)obj46)
														{
															obj = global::_003CModule_003E.string_21;
															obj46 = "1";
															num = (((string)obj == (string)obj46) ? 1 : 0);
															Class11.HearSelf = (byte)num != 0;
															obj = ((!Class11.HearSelf) ? obj62 : obj66);
															BundleManager.smethod_13((string)obj);
														}
													}
													break;
												}
												obj = global::_003CModule_003E.string_20;
												obj46 = obj70;
												if ((string)obj == (string)obj46)
												{
													obj = global::_003CModule_003E.string_21;
													int __rxParse2;
													if (int.TryParse((string)obj, out __rxParse2))
													{
														global::_003CModule_003E.OaEST_003CmJfB = __rxParse2;
														num = global::_003CModule_003E.OaEST_003CmJfB;
														Class135.CurrentIndex = num;
													}
												}
												break;
											}
											obj = global::_003CModule_003E.string_20;
											obj46 = obj53;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (float.TryParse((string)obj, out global::_003CModule_003E.float_23))
												{
													double num11 = global::_003CModule_003E.float_23;
													Class147.float_0 = (float)num11;
												}
											}
											break;
										}
										case 10:
											obj = global::_003CModule_003E.string_20;
											obj46 = obj52;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (int.TryParse((string)obj, out global::_003CModule_003E.int_46))
												{
													num = global::_003CModule_003E.int_46;
													num2 = 0;
													object obj75 = Class147.string_0;
													IntPtr intPtr2 = (nint)((string[])obj75).LongLength;
													num3 = (int)(nint)intPtr2;
													num3--;
													int num19 = Mathf.Clamp(num, 0, num3);
													num = num19;
													Class147.int_0 = num;
												}
											}
											break;
										case 11:
										{
											obj = global::_003CModule_003E.string_20;
											num4 = 15.0;
											num5 = 5.0;
											num4 = 10.0;
											int num10 = Convert.ToInt32(num4);
											num2 = num10;
											char c = ((string)obj)[num2];
											num = c;
											global::_003CModule_003E.char_3 = (char)num;
											num = global::_003CModule_003E.char_3;
											num2 = 737;
											num3 = 11;
											num2 = 67;
											if (num != 67)
											{
												num = global::_003CModule_003E.char_3;
												num2 = 1079;
												num3 = 13;
												num2 = 83;
												if (num != 83)
												{
													break;
												}
												obj = global::_003CModule_003E.string_20;
												obj46 = obj49;
												if ((string)obj == (string)obj46)
												{
													obj = global::_003CModule_003E.string_21;
													int __rxParse;
													if (int.TryParse((string)obj, out __rxParse))
													{
														global::_003CModule_003E.pahL_002DKHvML = __rxParse;
														num = global::_003CModule_003E.pahL_002DKHvML;
														Class9.int_2 = num;
													}
												}
												break;
											}
											obj = global::_003CModule_003E.string_20;
											obj46 = obj73;
											if ((string)obj == (string)obj46)
											{
												obj = global::_003CModule_003E.string_21;
												if (int.TryParse((string)obj, out global::_003CModule_003E.int_51))
												{
													num = global::_003CModule_003E.int_51;
													Class9.int_1 = num;
												}
											}
											break;
										}
										case 0:
										case 2:
										case 8:
										case 12:
											break;
										}
									}
								}
							}
						}
					}
				}
				num = global::_003CModule_003E.int_43;
				num2 = 1;
				num++;
				global::_003CModule_003E.int_43 = num;
			}
			smethod_9();
		}
		catch
		{
		}
	}

	private unsafe static void smethod_9()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0859, IL_086c, IL_087f, IL_088f, IL_089f, IL_08af, IL_08bf, IL_08cf, IL_08df, IL_08ec, IL_08f9, IL_0909, IL_0919, IL_0929, IL_0934, IL_0947, IL_0955, IL_0960, IL_0970, IL_097e, IL_098e, IL_099c, IL_09a9, IL_09c2, IL_09d5, IL_09e3, IL_09f6, IL_0a12, IL_0a3b, IL_0a57, IL_0a65, IL_0a73, IL_0a81, IL_0a8f, IL_0a9d, IL_0aab, IL_0ab9, IL_0ae2, IL_0afb, IL_0b06, IL_0b14, IL_0b38, IL_0b48, IL_0b53, IL_0b66, IL_0b6f, IL_0b7d, IL_0b8b, IL_0b9b, IL_0bae, IL_0bd9, IL_0bed, IL_0c31, IL_0c44, IL_0c57, IL_0c65, IL_0c8d, IL_0caa, IL_0cc4, IL_0cd2, IL_0ce0, IL_0cf3, IL_0d01, IL_0d0c, IL_0d1a, IL_0d28, IL_0d3b, IL_0d49, IL_0d5c, IL_0d6a, IL_0d78, IL_0d86, IL_0d96, IL_0da4, IL_0db2, IL_0dc0, IL_0dce, IL_0de6, IL_0df4, IL_0e14, IL_0e37, IL_0e4a, IL_0e58, IL_0e75, IL_0e93, IL_0eb7, IL_0ecf, IL_0ee2, IL_0ef5, IL_0f09, IL_0f56, IL_0f64, IL_0f8d, IL_0fa4, IL_0fb7, IL_0fca, IL_1009, IL_101c, IL_102b, IL_1039, IL_1044, IL_1052, IL_1092, IL_10a6, IL_10b9, IL_10c7, IL_10d5, IL_10e3, IL_10ff, IL_111b, IL_112e, IL_1142, IL_1181, IL_1194, IL_11a7, IL_11ba, IL_11c5, IL_11e9, IL_11f7, IL_1205, IL_1218, IL_1226, IL_1231, IL_1271, IL_1285, IL_1298, IL_12a6, IL_12b4, IL_12bd, IL_12d1, IL_1310, IL_1323, IL_1331, IL_133f, IL_134d, IL_135b, IL_136e, IL_1392, IL_13a0, IL_13ae, IL_13c1, IL_13cf, IL_13dd, IL_13e8, IL_144a, IL_145d, IL_146b, IL_1479, IL_14be, IL_14cc, IL_14da, IL_14f7, IL_153b, IL_1549, IL_155c, IL_1579, IL_15c0, IL_15ce, IL_15e1, IL_15ef, IL_15fd, IL_1610, IL_161e, IL_1633, IL_1646, IL_1654, IL_167d, IL_1696, IL_16b8, IL_16cf, IL_16dd, IL_16f0, IL_16fe, IL_170c, IL_171a, IL_1728, IL_1768, IL_177c, IL_178f, IL_179d, IL_17ab, IL_17eb, IL_17ff, IL_1812, IL_1825, IL_1839, IL_184c, IL_1861, IL_1874, IL_1882, IL_188d, IL_189b, IL_18a9, IL_18b7, IL_18d0, IL_18f7, IL_1905, IL_1913, IL_1926, IL_1934, IL_193f, IL_1978, IL_198c, IL_199f, IL_19ad, IL_19bb, IL_19df, IL_19ed, IL_19fb, IL_1a0e, IL_1a1c, IL_1a2a, IL_1a3e, IL_1a8a, IL_1a98, IL_1aab, IL_1abf, IL_1af7, IL_1b13, IL_1b3c, IL_1b4a, IL_1b5d, IL_1b6b, IL_1b7e, IL_1b8c, IL_1b9a, IL_1bec, IL_1c08, IL_1c16, IL_1c24, IL_1c2d, IL_1c4a, IL_1c99, IL_1ca3, IL_1cd0, IL_1ce4, IL_1cf2, IL_1d05, IL_1d46, IL_1d5a, IL_1d6d, IL_1d89, IL_1d9c, IL_1daf, IL_1dee, IL_1e01, IL_1e3f, IL_1e52, IL_1e60, IL_1e6e, IL_1e97, IL_1eae, IL_1ec1, IL_1ed5, IL_1f3f, IL_1f52, IL_1f5d, IL_1f9d, IL_1fb1, IL_1fc4, IL_1fd2, IL_1fe0, IL_1ff9, IL_2010, IL_201e, IL_2031, IL_203c, IL_204a, IL_2058, IL_207a, IL_2088, IL_2096, IL_20a9, IL_20e9, IL_2106, IL_2119, IL_212e, IL_2141, IL_2154, IL_2194, IL_21a8, IL_21bb, IL_21c9, IL_21d7, IL_21eb, IL_222a, IL_223d, IL_2266, IL_2274, IL_2287, IL_2295, IL_22a3, IL_22b8, IL_22cb, IL_22d9, IL_22e4, IL_2308, IL_2316, IL_2324, IL_2337, IL_2342, IL_2350, IL_2359, IL_2367, IL_2385, IL_239c, IL_23aa, IL_23bd, IL_23c8, IL_23dd, IL_23f0, IL_23fe, IL_2407, IL_2415, IL_241e, IL_2433, IL_2446, IL_2451, IL_245f, IL_2472, IL_247d, IL_2488, IL_2493, IL_24c5, IL_24d3, IL_24e3, IL_2505, IL_2518, IL_252b, IL_2535, IL_2540, IL_2550, IL_2560, IL_2570, IL_2589, IL_2599, IL_25a9, IL_25b9, IL_25c9 are reachable both inside and outside the pinned region starting at IL_25de. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 397;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef2 = default(int);
			ref int reference = ref __rxRef2;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_25c9:
					num2 = 1;
					while (true)
					{
						IL_25b9:
						num3 = num2 * 4;
						while (true)
						{
							IL_25a9:
							num4 = num2 * 8;
							while (true)
							{
								IL_2599:
								array2 = new byte[4];
								while (true)
								{
									IL_2589:
									array3 = new object[4];
									while (true)
									{
										IL_2570:
										array4 = new int[4];
										num = 194;
										while (true)
										{
											IL_2560:
											array5 = new int[7];
											while (true)
											{
												IL_2550:
												array6 = new long[4];
												while (true)
												{
													IL_2540:
													array7 = new object[38];
													while (true)
													{
														IL_2535:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VTVOIDUnix.IEnumSTOREDEPLOYMENTMETADATAid);
														while (true)
														{
															IL_252b:
															ptr2 = ptr;
															while (true)
															{
																IL_2518:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0929:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0919:
																		ptr2++;
																		while (true)
																		{
																			IL_0909:
																			if (b >= 1)
																			{
																				while (b <= 63)
																				{
																					while (true)
																					{
																						IL_08ec:
																						if (32 < b)
																						{
																							while (true)
																							{
																								IL_08df:
																								if (48 < b)
																								{
																									while (true)
																									{
																										IL_08cf:
																										if (56 >= b)
																										{
																											while (true)
																											{
																												IL_08bf:
																												if (56 > b)
																												{
																													while (true)
																													{
																														IL_08af:
																														if (52 < b)
																														{
																															while (true)
																															{
																																IL_089f:
																																if (54 >= b)
																																{
																																	while (true)
																																	{
																																		IL_088f:
																																		if (54 > b)
																																		{
																																			while (53 >= b)
																																			{
																																				while (53 <= b)
																																				{
																																					num = 527;
																																					while (true)
																																					{
																																						if (num != 527)
																																						{
																																							if (num != 1508)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 397:
																																								break;
																																							default:
																																								continue;
																																							case 500:
																																								goto IL_086c;
																																							case 400:
																																								goto IL_087f;
																																							case 493:
																																								goto IL_088f;
																																							case 503:
																																								goto IL_089f;
																																							case 39:
																																								goto IL_08af;
																																							case 54:
																																								goto IL_08bf;
																																							case 373:
																																								goto IL_08cf;
																																							case 275:
																																								goto IL_08df;
																																							case 438:
																																								goto IL_08ec;
																																							case 401:
																																								goto IL_08f9;
																																							case 200:
																																								goto IL_0909;
																																							case 101:
																																								goto IL_0919;
																																							case 207:
																																							case 231:
																																								goto IL_0929;
																																							case 144:
																																								goto IL_0934;
																																							case 197:
																																								goto IL_0947;
																																							case 61:
																																								goto IL_0955;
																																							case 50:
																																								goto IL_0960;
																																							case 202:
																																								goto IL_0970;
																																							case 22:
																																								goto IL_097e;
																																							case 212:
																																								goto IL_098e;
																																							case 199:
																																								goto IL_099c;
																																							case 75:
																																							case 228:
																																								goto IL_09a9;
																																							case 250:
																																								goto IL_09c2;
																																							case 254:
																																								goto IL_09d5;
																																							case 53:
																																								goto IL_09e3;
																																							case 157:
																																							case 255:
																																								goto IL_09f6;
																																							case 141:
																																							case 274:
																																								goto IL_0a12;
																																							case 107:
																																								goto IL_0a3b;
																																							case 285:
																																								goto IL_0a57;
																																							case 149:
																																								goto IL_0a65;
																																							case 122:
																																								goto IL_0a73;
																																							case 40:
																																								goto IL_0a81;
																																							case 3:
																																								goto IL_0a8f;
																																							case 90:
																																								goto IL_0a9d;
																																							case 21:
																																								goto IL_0aab;
																																							case 37:
																																							case 282:
																																								goto IL_0ab9;
																																							case 56:
																																								goto IL_0ae2;
																																							case 158:
																																								goto IL_0afb;
																																							case 132:
																																								goto IL_0b06;
																																							case 172:
																																							case 244:
																																								goto IL_0b14;
																																							case 1:
																																								goto IL_0b38;
																																							case 17:
																																								goto IL_0b48;
																																							case 237:
																																								goto IL_0b53;
																																							case 102:
																																								goto IL_0b6f;
																																							case 201:
																																								goto IL_0b7d;
																																							case 36:
																																								goto IL_0b8b;
																																							case 289:
																																								goto IL_0b9b;
																																							case 204:
																																							case 297:
																																								goto IL_0bae;
																																							case 287:
																																							case 298:
																																								goto IL_0bd9;
																																							case 44:
																																								goto IL_0bed;
																																							case 299:
																																								goto IL_0c31;
																																							case 304:
																																								goto IL_0c44;
																																							case 19:
																																							case 309:
																																								goto IL_0c57;
																																							case 262:
																																								goto IL_0c65;
																																							case 105:
																																							case 317:
																																								goto IL_0c8d;
																																							case 48:
																																							case 320:
																																								goto IL_0caa;
																																							case 322:
																																								goto IL_0cc4;
																																							case 191:
																																								goto IL_0cd2;
																																							case 82:
																																								goto IL_0ce0;
																																							case 327:
																																								goto IL_0cf3;
																																							case 206:
																																								goto IL_0d01;
																																							case 106:
																																								goto IL_0d0c;
																																							case 4:
																																								goto IL_0d1a;
																																							case 97:
																																								goto IL_0d28;
																																							case 258:
																																								goto IL_0d3b;
																																							case 89:
																																								goto IL_0d49;
																																							case 329:
																																								goto IL_0d5c;
																																							case 142:
																																								goto IL_0d6a;
																																							case 179:
																																								goto IL_0d78;
																																							case 161:
																																								goto IL_0d86;
																																							case 330:
																																								goto IL_0d96;
																																							case 278:
																																								goto IL_0da4;
																																							case 11:
																																								goto IL_0db2;
																																							case 183:
																																								goto IL_0dc0;
																																							case 170:
																																							case 245:
																																								goto IL_0dce;
																																							case 331:
																																								goto IL_0de6;
																																							case 153:
																																							case 156:
																																								goto IL_0df4;
																																							case 224:
																																							case 334:
																																								goto IL_0e14;
																																							case 357:
																																								goto IL_0e37;
																																							case 159:
																																							case 364:
																																								goto IL_0e4a;
																																							case 164:
																																								goto IL_0e58;
																																							case 367:
																																								goto IL_0e75;
																																							case 166:
																																								goto IL_0e93;
																																							case 151:
																																								goto IL_0eb7;
																																							case 313:
																																								goto IL_0ecf;
																																							case 376:
																																								goto IL_0ee2;
																																							case 193:
																																							case 384:
																																								goto IL_0ef5;
																																							case 210:
																																								goto IL_0f09;
																																							case 395:
																																								goto IL_0f56;
																																							case 42:
																																							case 387:
																																								goto IL_0f64;
																																							case 293:
																																								goto IL_0f8d;
																																							case 28:
																																								goto IL_0fa4;
																																							case 402:
																																								goto IL_0fb7;
																																							case 403:
																																								goto IL_0fca;
																																							case 41:
																																								goto IL_1009;
																																							case 409:
																																								goto IL_101c;
																																							case 414:
																																								goto IL_102b;
																																							case 388:
																																								goto IL_1039;
																																							case 133:
																																								goto IL_1044;
																																							case 30:
																																							case 32:
																																								goto IL_1052;
																																							case 315:
																																								goto IL_1092;
																																							case 362:
																																								goto IL_10a6;
																																							case 328:
																																								goto IL_10b9;
																																							case 310:
																																								goto IL_10c7;
																																							case 67:
																																							case 242:
																																								goto IL_10d5;
																																							case 25:
																																								goto IL_10e3;
																																							case 209:
																																								goto IL_10ff;
																																							case 416:
																																								goto IL_111b;
																																							case 126:
																																							case 420:
																																								goto IL_112e;
																																							case 186:
																																								goto IL_1142;
																																							case 358:
																																								goto IL_1181;
																																							case 430:
																																								goto IL_1194;
																																							case 441:
																																								goto IL_11a7;
																																							case 443:
																																								goto IL_11ba;
																																							case 81:
																																							case 248:
																																								goto IL_11c5;
																																							case 291:
																																								goto IL_11e9;
																																							case 251:
																																								goto IL_11f7;
																																							case 181:
																																								goto IL_1205;
																																							case 300:
																																								goto IL_1218;
																																							case 63:
																																								goto IL_1226;
																																							case 155:
																																							case 265:
																																								goto IL_1231;
																																							case 136:
																																								goto IL_1271;
																																							case 426:
																																								goto IL_1285;
																																							case 365:
																																								goto IL_1298;
																																							case 162:
																																								goto IL_12a6;
																																							case 93:
																																							case 410:
																																								goto IL_12bd;
																																							case 427:
																																								goto IL_12d1;
																																							case 0:
																																								goto IL_1310;
																																							case 8:
																																								goto IL_1323;
																																							case 184:
																																								goto IL_1331;
																																							case 444:
																																								goto IL_134d;
																																							case 348:
																																								goto IL_135b;
																																							case 314:
																																							case 445:
																																								goto IL_136e;
																																							case 280:
																																								goto IL_1392;
																																							case 137:
																																								goto IL_13a0;
																																							case 394:
																																								goto IL_13ae;
																																							case 454:
																																								goto IL_13c1;
																																							case 343:
																																								goto IL_13cf;
																																							case 256:
																																								goto IL_13dd;
																																							case 382:
																																							case 386:
																																								goto IL_13e8;
																																							case 208:
																																								goto IL_144a;
																																							case 412:
																																								goto IL_145d;
																																							case 38:
																																								goto IL_146b;
																																							case 71:
																																							case 148:
																																								goto IL_1479;
																																							case 117:
																																								goto IL_14be;
																																							case 62:
																																								goto IL_14cc;
																																							case 130:
																																							case 180:
																																								goto IL_14da;
																																							case 104:
																																								goto IL_14f7;
																																							case 458:
																																								goto IL_153b;
																																							case 160:
																																								goto IL_1549;
																																							case 5:
																																							case 460:
																																								goto IL_155c;
																																							case 84:
																																								goto IL_1579;
																																							case 355:
																																								goto IL_15c0;
																																							case 68:
																																								goto IL_15ce;
																																							case 466:
																																								goto IL_15e1;
																																							case 377:
																																								goto IL_15ef;
																																							case 379:
																																								goto IL_15fd;
																																							case 467:
																																								goto IL_1610;
																																							case 127:
																																							case 352:
																																								goto IL_161e;
																																							case 239:
																																								goto IL_1633;
																																							case 468:
																																								goto IL_1646;
																																							case 261:
																																							case 318:
																																								goto IL_1654;
																																							case 176:
																																								goto IL_167d;
																																							case 234:
																																							case 471:
																																								goto IL_1696;
																																							case 391:
																																								goto IL_16b8;
																																							case 216:
																																								goto IL_16cf;
																																							case 188:
																																								goto IL_16dd;
																																							case 472:
																																								goto IL_16f0;
																																							case 453:
																																								goto IL_16fe;
																																							case 302:
																																								goto IL_170c;
																																							case 205:
																																								goto IL_171a;
																																							case 16:
																																							case 222:
																																								goto IL_1728;
																																							case 449:
																																								goto IL_1768;
																																							case 138:
																																								goto IL_177c;
																																							case 253:
																																								goto IL_178f;
																																							case 363:
																																								goto IL_179d;
																																							case 74:
																																							case 232:
																																								goto IL_17ab;
																																							case 247:
																																								goto IL_17eb;
																																							case 417:
																																								goto IL_17ff;
																																							case 473:
																																								goto IL_1812;
																																							case 475:
																																								goto IL_1825;
																																							case 198:
																																								goto IL_1839;
																																							case 15:
																																							case 477:
																																								goto IL_184c;
																																							case 185:
																																								goto IL_1861;
																																							case 482:
																																								goto IL_1874;
																																							case 340:
																																								goto IL_1882;
																																							case 221:
																																								goto IL_188d;
																																							case 18:
																																								goto IL_189b;
																																							case 83:
																																								goto IL_18a9;
																																							case 241:
																																							case 462:
																																								goto IL_18b7;
																																							case 175:
																																							case 398:
																																								goto IL_18d0;
																																							case 45:
																																								goto IL_18f7;
																																							case 218:
																																								goto IL_1905;
																																							case 436:
																																								goto IL_1913;
																																							case 145:
																																								goto IL_1926;
																																							case 270:
																																								goto IL_1934;
																																							case 87:
																																							case 150:
																																								goto IL_193f;
																																							case 354:
																																								goto IL_1978;
																																							case 173:
																																								goto IL_198c;
																																							case 479:
																																								goto IL_199f;
																																							case 378:
																																								goto IL_19ad;
																																							case 360:
																																							case 452:
																																								goto IL_19bb;
																																							case 243:
																																								goto IL_19df;
																																							case 147:
																																								goto IL_19ed;
																																							case 29:
																																								goto IL_19fb;
																																							case 66:
																																								goto IL_1a0e;
																																							case 46:
																																								goto IL_1a1c;
																																							case 421:
																																							case 424:
																																								goto IL_1a2a;
																																							case 461:
																																								goto IL_1a3e;
																																							case 356:
																																								goto IL_1a8a;
																																							case 259:
																																								goto IL_1a98;
																																							case 407:
																																							case 489:
																																								goto IL_1aab;
																																							case 26:
																																								goto IL_1abf;
																																							case 79:
																																								goto IL_1af7;
																																							case 393:
																																							case 491:
																																								goto IL_1b13;
																																							case 34:
																																								goto IL_1b3c;
																																							case 268:
																																								goto IL_1b4a;
																																							case 492:
																																								goto IL_1b5d;
																																							case 168:
																																								goto IL_1b6b;
																																							case 496:
																																								goto IL_1b7e;
																																							case 459:
																																								goto IL_1b8c;
																																							case 118:
																																							case 195:
																																								goto IL_1b9a;
																																							case 344:
																																								goto IL_1bec;
																																							case 498:
																																								goto IL_1c08;
																																							case 434:
																																								goto IL_1c16;
																																							case 455:
																																							case 457:
																																								goto IL_1c2d;
																																							case 57:
																																								goto IL_1ce4;
																																							case 49:
																																								goto IL_1cf2;
																																							case 435:
																																							case 499:
																																								goto IL_1d05;
																																							case 295:
																																								goto IL_1d46;
																																							case 413:
																																								goto IL_1d5a;
																																							case 504:
																																								goto IL_1d6d;
																																							case 506:
																																								goto IL_1d89;
																																							case 508:
																																								goto IL_1d9c;
																																							case 509:
																																								goto IL_1daf;
																																							case 374:
																																								goto IL_1dee;
																																							case 134:
																																							case 510:
																																								goto IL_1e01;
																																							case 33:
																																								goto IL_1e3f;
																																							case 511:
																																								goto IL_1e52;
																																							case 463:
																																								goto IL_1e60;
																																							case 99:
																																							case 123:
																																								goto IL_1e6e;
																																							case 152:
																																								goto IL_1e97;
																																							case 98:
																																								goto IL_1eae;
																																							case 305:
																																							case 512:
																																								goto IL_1ec1;
																																							case 190:
																																								goto IL_1ed5;
																																							case 47:
																																								goto IL_1f3f;
																																							case 513:
																																								goto IL_1f52;
																																							case 139:
																																							case 431:
																																								goto IL_1f5d;
																																							case 86:
																																								goto IL_1f9d;
																																							case 359:
																																								goto IL_1fb1;
																																							case 383:
																																								goto IL_1fc4;
																																							case 109:
																																								goto IL_1fd2;
																																							case 60:
																																							case 341:
																																								goto IL_1fe0;
																																							case 267:
																																								goto IL_1ff9;
																																							case 339:
																																								goto IL_2010;
																																							case 12:
																																								goto IL_201e;
																																							case 514:
																																								goto IL_2031;
																																							case 442:
																																								goto IL_203c;
																																							case 433:
																																								goto IL_204a;
																																							case 125:
																																							case 349:
																																								goto IL_2058;
																																							case 296:
																																								goto IL_207a;
																																							case 485:
																																								goto IL_2088;
																																							case 389:
																																								goto IL_2096;
																																							case 154:
																																							case 211:
																																								goto IL_20a9;
																																							case 55:
																																								goto IL_20e9;
																																							case 451:
																																								goto IL_2106;
																																							case 52:
																																							case 515:
																																								goto IL_2119;
																																							case 428:
																																								goto IL_212e;
																																							case 516:
																																								goto IL_2141;
																																							case 167:
																																							case 517:
																																								goto IL_2154;
																																							case 72:
																																								goto IL_2194;
																																							case 23:
																																								goto IL_21a8;
																																							case 520:
																																								goto IL_21bb;
																																							case 213:
																																								goto IL_21c9;
																																							case 20:
																																							case 76:
																																								goto IL_21d7;
																																							case 165:
																																								goto IL_21eb;
																																							case 483:
																																								goto IL_222a;
																																							case 487:
																																								goto IL_223d;
																																							case 119:
																																								goto IL_2266;
																																							case 203:
																																								goto IL_2274;
																																							case 14:
																																								goto end_IL_0859;
																																							case 470:
																																								goto IL_2295;
																																							case 7:
																																							case 480:
																																								goto IL_22a3;
																																							case 135:
																																								goto IL_22b8;
																																							case 333:
																																								goto IL_22cb;
																																							case 143:
																																								goto IL_22d9;
																																							case 121:
																																							case 312:
																																								goto IL_22e4;
																																							case 283:
																																								goto IL_2308;
																																							case 494:
																																								goto IL_2316;
																																							case 486:
																																								goto IL_2324;
																																							case 450:
																																								goto IL_2337;
																																							case 192:
																																								goto IL_2342;
																																							case 129:
																																								goto IL_2359;
																																							case 273:
																																							case 323:
																																								goto IL_2367;
																																							case 171:
																																								goto IL_2385;
																																							case 223:
																																								goto IL_239c;
																																							case 465:
																																								goto IL_23aa;
																																							case 484:
																																								goto IL_23bd;
																																							case 59:
																																							case 366:
																																								goto IL_23c8;
																																							case 437:
																																								goto IL_23dd;
																																							case 113:
																																								goto IL_23f0;
																																							case 321:
																																								goto IL_2407;
																																							case 85:
																																							case 146:
																																								goto IL_241e;
																																							case 235:
																																								goto IL_2433;
																																							case 425:
																																								goto IL_2446;
																																							case 236:
																																								goto IL_2451;
																																							case 35:
																																								goto IL_245f;
																																							case 177:
																																								goto IL_2472;
																																							case 124:
																																								goto IL_247d;
																																							case 260:
																																								goto IL_2488;
																																							case 70:
																																							case 380:
																																								goto IL_2493;
																																							case 178:
																																								goto IL_24c5;
																																							case 140:
																																								goto IL_24d3;
																																							case 288:
																																							case 518:
																																								goto IL_24e3;
																																							case 2:
																																							case 24:
																																							case 27:
																																							case 31:
																																							case 51:
																																							case 58:
																																							case 64:
																																							case 65:
																																							case 69:
																																							case 73:
																																							case 77:
																																							case 92:
																																							case 96:
																																							case 100:
																																							case 112:
																																							case 131:
																																							case 174:
																																							case 182:
																																							case 187:
																																							case 214:
																																							case 215:
																																							case 217:
																																							case 219:
																																							case 220:
																																							case 227:
																																							case 230:
																																							case 233:
																																							case 238:
																																							case 240:
																																							case 249:
																																							case 263:
																																							case 264:
																																							case 269:
																																							case 271:
																																							case 277:
																																							case 281:
																																							case 286:
																																							case 294:
																																							case 303:
																																							case 311:
																																							case 324:
																																							case 342:
																																							case 346:
																																							case 347:
																																							case 351:
																																							case 353:
																																							case 372:
																																							case 375:
																																							case 381:
																																							case 399:
																																							case 404:
																																							case 405:
																																							case 406:
																																							case 415:
																																							case 419:
																																							case 429:
																																							case 448:
																																							case 456:
																																							case 481:
																																							case 488:
																																							case 495:
																																							case 497:
																																							case 501:
																																							case 502:
																																							case 507:
																																							case 519:
																																								goto end_IL_086c;
																																							case 6:
																																							case 9:
																																							case 10:
																																							case 43:
																																							case 78:
																																							case 80:
																																							case 88:
																																							case 94:
																																							case 95:
																																							case 103:
																																							case 108:
																																							case 111:
																																							case 114:
																																							case 115:
																																							case 120:
																																							case 128:
																																							case 163:
																																							case 169:
																																							case 189:
																																							case 196:
																																							case 225:
																																							case 226:
																																							case 229:
																																							case 246:
																																							case 252:
																																							case 257:
																																							case 272:
																																							case 276:
																																							case 279:
																																							case 284:
																																							case 290:
																																							case 301:
																																							case 306:
																																							case 307:
																																							case 316:
																																							case 319:
																																							case 325:
																																							case 326:
																																							case 332:
																																							case 335:
																																							case 336:
																																							case 337:
																																							case 338:
																																							case 345:
																																							case 350:
																																							case 361:
																																							case 369:
																																							case 370:
																																							case 371:
																																							case 385:
																																							case 390:
																																							case 392:
																																							case 408:
																																							case 418:
																																							case 422:
																																							case 423:
																																							case 432:
																																							case 440:
																																							case 446:
																																							case 464:
																																							case 469:
																																							case 474:
																																							case 476:
																																							case 478:
																																							case 490:
																																							case 505:
																																								goto IL_2518;
																																							case 13:
																																								goto IL_252b;
																																							case 116:
																																								goto IL_2535;
																																							case 308:
																																								goto IL_2540;
																																							case 110:
																																								goto IL_2550;
																																							case 194:
																																								goto IL_2560;
																																							case 368:
																																								goto IL_2570;
																																							case 411:
																																								goto IL_2589;
																																							case 447:
																																								goto IL_2599;
																																							case 91:
																																								goto IL_25a9;
																																							case 292:
																																								goto IL_25b9;
																																							case 396:
																																								goto IL_25c9;
																																							case 266:
																																							case 439:
																																								return;
																																							}
																																							goto end_IL_0909;
																																						}
																																						goto IL_223d;
																																						IL_2266:
																																						num6--;
																																						goto IL_2274;
																																						IL_2274:
																																						ptr2 += 8;
																																						goto IL_2518;
																																						IL_223d:
																																						((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																																						goto IL_2266;
																																						continue;
																																						end_IL_0859:
																																						break;
																																					}
																																					goto IL_2287;
																																					continue;
																																					end_IL_086c:
																																					break;
																																					IL_086c:;
																																				}
																																				break;
																																				IL_087f:;
																																			}
																																			break;
																																		}
																																		goto IL_09a9;
																																		IL_1009:
																																		ptr2 += 8;
																																		goto IL_2518;
																																		IL_09a9:
																																		array2[num6 - 1] = 3;
																																		goto IL_0fca;
																																		IL_0fca:
																																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																		goto IL_1009;
																																	}
																																	break;
																																}
																																goto IL_2287;
																																IL_22b8:
																																ptr2 += 8;
																																goto IL_2518;
																																IL_2287:
																																if (55 < b)
																																{
																																	break;
																																}
																																goto IL_2295;
																																IL_2295:
																																if (55 > b)
																																{
																																	break;
																																}
																																goto IL_22a3;
																																IL_22a3:
																																((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																																goto IL_22b8;
																															}
																															break;
																														}
																														goto IL_102b;
																														IL_1f3f:
																														ptr2 += 8;
																														goto IL_2518;
																														IL_102b:
																														if (52 > b)
																														{
																															goto IL_1039;
																														}
																														goto IL_1ec1;
																														IL_1039:
																														if (50 >= b)
																														{
																															goto IL_1044;
																														}
																														goto IL_10b9;
																														IL_1044:
																														if (50 <= b)
																														{
																															goto IL_1052;
																														}
																														goto IL_21bb;
																														IL_1052:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_1092;
																														IL_1092:
																														array2[num6 - 2] = 3;
																														goto IL_10a6;
																														IL_10a6:
																														num6--;
																														goto IL_2518;
																														IL_21bb:
																														if (49 < b)
																														{
																															break;
																														}
																														goto IL_21c9;
																														IL_21c9:
																														if (49 > b)
																														{
																															break;
																														}
																														goto IL_21d7;
																														IL_21d7:
																														array2[num6 - 1] = 3;
																														goto IL_21eb;
																														IL_21eb:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_222a;
																														IL_222a:
																														ptr2 += 8;
																														goto IL_2518;
																														IL_10b9:
																														if (51 < b)
																														{
																															break;
																														}
																														goto IL_10c7;
																														IL_10c7:
																														if (51 > b)
																														{
																															break;
																														}
																														goto IL_10d5;
																														IL_10d5:
																														array2[num6] = 15;
																														goto IL_10e3;
																														IL_10e3:
																														array4[num6] = *(int*)(ptr2 + num3);
																														num = 209;
																														goto IL_10ff;
																														IL_10ff:
																														ptr2 += 8;
																														num = 441;
																														goto IL_11a7;
																														IL_11a7:
																														num6++;
																														goto IL_2518;
																														IL_1ec1:
																														array2[num6 - 1] = 5;
																														goto IL_1ed5;
																														IL_1ed5:
																														array3[num6 - 1] = ((delegate*<ref int, string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref int>)AccountCertAdminsSidTypeConstructorName[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																														goto IL_1f3f;
																													}
																													break;
																												}
																												goto IL_0bd9;
																												IL_0fb7:
																												ptr2 += 8;
																												goto IL_2518;
																												IL_0bd9:
																												array2[num6 - 1] = 3;
																												goto IL_0bed;
																												IL_0bed:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_0fb7;
																											}
																											break;
																										}
																										goto IL_22cb;
																										IL_2493:
																										((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																										num = 178;
																										goto IL_24c5;
																										IL_22cb:
																										if (60 >= b)
																										{
																											goto IL_22d9;
																										}
																										goto IL_2446;
																										IL_22d9:
																										if (60 <= b)
																										{
																											goto IL_22e4;
																										}
																										goto IL_2337;
																										IL_22e4:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																										goto IL_2308;
																										IL_2308:
																										array2[num6] = 0;
																										goto IL_2316;
																										IL_2316:
																										num6++;
																										goto IL_2324;
																										IL_2324:
																										ptr2 += 8;
																										goto IL_2518;
																										IL_2337:
																										if (58 < b)
																										{
																											goto IL_2342;
																										}
																										goto IL_23bd;
																										IL_2342:
																										if (59 < b)
																										{
																											break;
																										}
																										num = 129;
																										goto IL_2359;
																										IL_24c5:
																										num6--;
																										goto IL_24d3;
																										IL_2359:
																										if (59 > b)
																										{
																											break;
																										}
																										goto IL_2367;
																										IL_2367:
																										array3[num6] = ((delegate*<string[]>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																										goto IL_2385;
																										IL_2385:
																										array2[num6] = 5;
																										num = 223;
																										goto IL_239c;
																										IL_239c:
																										num6++;
																										goto IL_23aa;
																										IL_23aa:
																										ptr2 += 8;
																										goto IL_2518;
																										IL_23bd:
																										if (58 <= b)
																										{
																											goto IL_23c8;
																										}
																										goto IL_23f0;
																										IL_23c8:
																										((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																										goto IL_23dd;
																										IL_23dd:
																										ptr2 += 8;
																										goto IL_2518;
																										IL_23f0:
																										if (57 < b)
																										{
																											break;
																										}
																										num = 321;
																										goto IL_2407;
																										IL_24d3:
																										ptr2 += 8;
																										goto IL_2518;
																										IL_2407:
																										if (57 > b)
																										{
																											break;
																										}
																										num = 146;
																										goto IL_241e;
																										IL_24e3:
																										num7 = ptr2;
																										num8 = -200;
																										num5 = 1;
																										ptr2 = num7 + num8;
																										num = 9;
																										goto IL_2518;
																										IL_241e:
																										((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																										goto IL_2433;
																										IL_2433:
																										ptr2 += 8;
																										goto IL_2518;
																										IL_2446:
																										if (62 < b)
																										{
																											goto IL_2451;
																										}
																										goto IL_2472;
																										IL_2451:
																										if (63 < b)
																										{
																											break;
																										}
																										goto IL_245f;
																										IL_245f:
																										if (63 > b)
																										{
																										}
																										break;
																										IL_2472:
																										if (62 > b)
																										{
																											goto IL_247d;
																										}
																										goto IL_24e3;
																										IL_247d:
																										if (61 < b)
																										{
																											break;
																										}
																										goto IL_2488;
																										IL_2488:
																										if (61 > b)
																										{
																											break;
																										}
																										goto IL_2493;
																									}
																									break;
																								}
																								goto IL_0934;
																								IL_1142:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1181;
																								IL_0934:
																								if (48 > b)
																								{
																									goto IL_0a57;
																								}
																								goto IL_2119;
																								IL_0a57:
																								if (40 >= b)
																								{
																									goto IL_0a65;
																								}
																								goto IL_0afb;
																								IL_0a65:
																								if (40 > b)
																								{
																									goto IL_0a73;
																								}
																								goto IL_0ef5;
																								IL_0a73:
																								if (36 < b)
																								{
																									goto IL_0a81;
																								}
																								goto IL_11ba;
																								IL_0a81:
																								if (38 >= b)
																								{
																									goto IL_0a8f;
																								}
																								goto IL_0c44;
																								IL_0a8f:
																								if (38 > b)
																								{
																									goto IL_0a9d;
																								}
																								goto IL_155c;
																								IL_0a9d:
																								if (37 < b)
																								{
																									break;
																								}
																								goto IL_0aab;
																								IL_0aab:
																								if (37 > b)
																								{
																									break;
																								}
																								goto IL_0ab9;
																								IL_0ab9:
																								array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_0ae2;
																								IL_0ae2:
																								array2[num6 - 1] = 5;
																								goto IL_2518;
																								IL_155c:
																								array2[num6 - 2] = 5;
																								num = 84;
																								goto IL_1579;
																								IL_1579:
																								array3[num6 - 2] = ((delegate*<string, object, string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], array3[num6 - 1]);
																								goto IL_15c0;
																								IL_15c0:
																								num6--;
																								goto IL_15ce;
																								IL_15ce:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_0c44:
																								if (39 < b)
																								{
																									break;
																								}
																								goto IL_0f56;
																								IL_0f56:
																								if (39 > b)
																								{
																									break;
																								}
																								goto IL_0f64;
																								IL_0f64:
																								((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_0f8d;
																								IL_0f8d:
																								num6--;
																								num = 28;
																								goto IL_0fa4;
																								IL_0fa4:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_11ba:
																								if (36 <= b)
																								{
																									goto IL_11c5;
																								}
																								goto IL_1218;
																								IL_11c5:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_11e9;
																								IL_11e9:
																								array2[num6] = 3;
																								goto IL_11f7;
																								IL_11f7:
																								num6++;
																								goto IL_1205;
																								IL_1205:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_1218:
																								if (34 >= b)
																								{
																									goto IL_1226;
																								}
																								goto IL_1323;
																								IL_1226:
																								if (34 <= b)
																								{
																									goto IL_1231;
																								}
																								goto IL_1298;
																								IL_1231:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1271;
																								IL_1271:
																								array2[num6 - 2] = 3;
																								goto IL_1285;
																								IL_1285:
																								num6--;
																								goto IL_2518;
																								IL_1298:
																								if (33 < b)
																								{
																									break;
																								}
																								goto IL_12a6;
																								IL_12a6:
																								if (33 > b)
																								{
																									break;
																								}
																								num = 410;
																								goto IL_12bd;
																								IL_1181:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_12bd:
																								array2[num6 - 1] = 3;
																								goto IL_12d1;
																								IL_12d1:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1310;
																								IL_1310:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_1323:
																								if (35 < b)
																								{
																									break;
																								}
																								goto IL_1331;
																								IL_1331:
																								if (35 > b)
																								{
																									break;
																								}
																								num = 15;
																								goto IL_184c;
																								IL_2119:
																								((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_212e;
																								IL_184c:
																								((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_1861;
																								IL_1861:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_0ef5:
																								array2[num6 - 1] = 3;
																								goto IL_0f09;
																								IL_0f09:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								num = 473;
																								goto IL_1812;
																								IL_1812:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_0afb:
																								if (44 >= b)
																								{
																									goto IL_0b06;
																								}
																								goto IL_0b48;
																								IL_0b06:
																								if (44 <= b)
																								{
																									goto IL_0b14;
																								}
																								goto IL_0d5c;
																								IL_0b14:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_0b38;
																								IL_0b38:
																								array2[num6] = 3;
																								goto IL_0b9b;
																								IL_0b9b:
																								num6++;
																								goto IL_2141;
																								IL_2141:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_0d5c:
																								if (42 >= b)
																								{
																									goto IL_0d6a;
																								}
																								goto IL_1e52;
																								IL_0d6a:
																								if (42 > b)
																								{
																									goto IL_0d78;
																								}
																								goto IL_136e;
																								IL_0d78:
																								if (41 < b)
																								{
																									break;
																								}
																								goto IL_0d86;
																								IL_0d86:
																								if (41 > b)
																								{
																									break;
																								}
																								goto IL_0e14;
																								IL_0e14:
																								array3[num6] = ((delegate*<string[]>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_1194;
																								IL_1194:
																								array2[num6] = 5;
																								goto IL_134d;
																								IL_134d:
																								num6++;
																								goto IL_135b;
																								IL_135b:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_136e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_1392;
																								IL_1392:
																								array2[num6] = 0;
																								goto IL_13a0;
																								IL_13a0:
																								num6++;
																								goto IL_13ae;
																								IL_13ae:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_1e52:
																								if (43 < b)
																								{
																									break;
																								}
																								goto IL_1e60;
																								IL_1e60:
																								if (43 > b)
																								{
																									break;
																								}
																								goto IL_1e6e;
																								IL_1e6e:
																								((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_1e97;
																								IL_1e97:
																								num6--;
																								num = 98;
																								goto IL_1eae;
																								IL_1eae:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_0b48:
																								if (46 < b)
																								{
																									goto IL_0b53;
																								}
																								num = 102;
																								goto IL_0b6f;
																								IL_0b53:
																								if (47 < b)
																								{
																									break;
																								}
																								goto IL_1610;
																								IL_1610:
																								if (47 > b)
																								{
																									break;
																								}
																								goto IL_161e;
																								IL_161e:
																								((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_1633;
																								IL_1633:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_212e:
																								ptr2 += 8;
																								goto IL_2518;
																								IL_0b6f:
																								if (46 > b)
																								{
																									goto IL_0b7d;
																								}
																								goto IL_112e;
																								IL_0b7d:
																								if (45 < b)
																								{
																									break;
																								}
																								goto IL_0b8b;
																								IL_0b8b:
																								if (45 > b)
																								{
																									break;
																								}
																								goto IL_0bae;
																								IL_0bae:
																								((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_0c31;
																								IL_0c31:
																								num6--;
																								goto IL_1d6d;
																								IL_1d6d:
																								ptr2 += 8;
																								num = 189;
																								goto IL_2518;
																								IL_112e:
																								array2[num6 - 1] = 3;
																								goto IL_1142;
																							}
																							break;
																						}
																						goto IL_0947;
																						IL_1a8a:
																						num6--;
																						goto IL_1a98;
																						IL_0947:
																						if (32 > b)
																						{
																							goto IL_0955;
																						}
																						goto IL_0a12;
																						IL_0955:
																						if (16 >= b)
																						{
																							goto IL_0960;
																						}
																						goto IL_0970;
																						IL_0960:
																						if (16 > b)
																						{
																							goto IL_098e;
																						}
																						goto IL_0c8d;
																						IL_098e:
																						if (8 >= b)
																						{
																							goto IL_099c;
																						}
																						goto IL_0cc4;
																						IL_099c:
																						if (8 > b)
																						{
																							goto IL_09d5;
																						}
																						goto IL_09f6;
																						IL_09f6:
																						num6--;
																						num = 325;
																						goto IL_2518;
																						IL_09d5:
																						if (4 >= b)
																						{
																							goto IL_09e3;
																						}
																						goto IL_16f0;
																						IL_09e3:
																						if (4 <= b)
																						{
																							goto IL_0c57;
																						}
																						goto IL_15e1;
																						IL_0c57:
																						array2[num6] = 0;
																						goto IL_0c65;
																						IL_0c65:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_101c;
																						IL_101c:
																						array3[num6] = null;
																						goto IL_153b;
																						IL_153b:
																						num6++;
																						goto IL_1549;
																						IL_1549:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_15e1:
																						if (2 < b)
																						{
																							goto IL_15ef;
																						}
																						goto IL_1f52;
																						IL_15ef:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_15fd;
																						IL_15fd:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_1b13;
																						IL_1b13:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1b3c;
																						IL_1b3c:
																						ptr2 += 8;
																						goto IL_1b4a;
																						IL_1b4a:
																						num6--;
																						goto IL_2518;
																						IL_1f52:
																						if (2 <= b)
																						{
																							goto IL_1f5d;
																						}
																						goto IL_1fc4;
																						IL_1f5d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1f9d;
																						IL_1f9d:
																						array2[num6 - 2] = 0;
																						goto IL_1fb1;
																						IL_1fb1:
																						num6--;
																						goto IL_2518;
																						IL_1fc4:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_1fd2;
																						IL_1fd2:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_1fe0;
																						IL_1fe0:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_1ff9;
																						IL_1ff9:
																						array2[num6] = 0;
																						num = 339;
																						goto IL_2010;
																						IL_2010:
																						num6++;
																						goto IL_201e;
																						IL_201e:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_16f0:
																						if (6 >= b)
																						{
																							goto IL_16fe;
																						}
																						goto IL_178f;
																						IL_16fe:
																						if (6 > b)
																						{
																							goto IL_170c;
																						}
																						goto IL_2154;
																						IL_170c:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_171a;
																						IL_171a:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_1728;
																						IL_1728:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1768;
																						IL_1768:
																						array2[num6 - 2] = 0;
																						goto IL_177c;
																						IL_177c:
																						num6--;
																						goto IL_2518;
																						IL_2154:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_2194;
																						IL_2194:
																						array2[num6 - 2] = 0;
																						goto IL_21a8;
																						IL_21a8:
																						num6--;
																						goto IL_2518;
																						IL_178f:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_179d;
																						IL_179d:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_17ab;
																						IL_17ab:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_17eb;
																						IL_17eb:
																						array2[num6 - 2] = 0;
																						goto IL_17ff;
																						IL_17ff:
																						num6--;
																						goto IL_2518;
																						IL_0cc4:
																						if (12 < b)
																						{
																							goto IL_0cd2;
																						}
																						goto IL_13c1;
																						IL_0cd2:
																						if (14 < b)
																						{
																							goto IL_0ce0;
																						}
																						goto IL_0de6;
																						IL_0ce0:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_1646;
																						IL_1646:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_1654;
																						IL_1654:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_167d;
																						IL_167d:
																						array2[num6 - 1] = 5;
																						goto IL_2518;
																						IL_0de6:
																						if (14 <= b)
																						{
																							goto IL_0df4;
																						}
																						goto IL_1c08;
																						IL_0df4:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_0e37;
																						IL_0e37:
																						ptr2 += 8;
																						goto IL_1d89;
																						IL_1d89:
																						num6--;
																						goto IL_2518;
																						IL_1c08:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_1c16;
																						IL_1c16:
																						if (13 > b)
																						{
																							break;
																						}
																						num = 455;
																						goto IL_1c2d;
																						IL_1a98:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_1c2d:
																						array8 = array3;
																						num9 = num6;
																						if (array == null)
																						{
																							goto IL_1c3c;
																						}
																						num10 = ptr2;
																						byte b2 = *num10;
																						ptr2 = num10 + 4;
																						int num11 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num11;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_1ce4;
																						IL_0a12:
																						((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																						goto IL_0a3b;
																						IL_0a3b:
																						num6--;
																						num = 376;
																						goto IL_0ee2;
																						IL_0ee2:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_1ce4:
																						array2[num6] = 5;
																						goto IL_1cf2;
																						IL_1cf2:
																						num6++;
																						goto IL_2518;
																						IL_13c1:
																						if (12 <= b)
																						{
																							goto IL_2518;
																						}
																						goto IL_13cf;
																						IL_13cf:
																						if (10 >= b)
																						{
																							goto IL_13dd;
																						}
																						goto IL_14be;
																						IL_13dd:
																						if (10 <= b)
																						{
																							goto IL_13e8;
																						}
																						goto IL_145d;
																						IL_13e8:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_144a;
																						IL_144a:
																						num6 -= 2;
																						goto IL_2518;
																						IL_145d:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_146b;
																						IL_146b:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_1479;
																						IL_1479:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1825;
																						IL_1825:
																						array2[num6 - 2] = 0;
																						goto IL_1839;
																						IL_1839:
																						num6--;
																						goto IL_2518;
																						IL_14be:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_14cc;
																						IL_14cc:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_14da;
																						IL_14da:
																						array2[num6 - 1] = 0;
																						num = 104;
																						goto IL_14f7;
																						IL_14f7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_1d9c;
																						IL_1d9c:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_0c8d:
																						array2[num6] = array2[num6 - 1];
																						goto IL_0e75;
																						IL_0e75:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_0e93;
																						IL_0e93:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0eb7;
																						IL_0eb7:
																						array3[num6] = array3[num6 - 1];
																						goto IL_0ecf;
																						IL_0ecf:
																						num6++;
																						goto IL_2518;
																						IL_0970:
																						if (24 >= b)
																						{
																							goto IL_097e;
																						}
																						goto IL_1874;
																						IL_097e:
																						if (24 > b)
																						{
																							goto IL_09c2;
																						}
																						goto IL_0caa;
																						IL_0caa:
																						((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																						goto IL_111b;
																						IL_111b:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_09c2:
																						if (20 >= b)
																						{
																							goto IL_0cf3;
																						}
																						goto IL_0d96;
																						IL_0cf3:
																						if (20 > b)
																						{
																							goto IL_0d01;
																						}
																						goto IL_1696;
																						IL_0d01:
																						if (18 >= b)
																						{
																							goto IL_0d0c;
																						}
																						goto IL_0d3b;
																						IL_0d0c:
																						if (18 > b)
																						{
																							goto IL_0d1a;
																						}
																						goto IL_1e01;
																						IL_0d1a:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0d28;
																						IL_0d28:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0e4a;
																						IL_0e4a:
																						array2[num6] = 5;
																						goto IL_0e58;
																						IL_0e58:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_1b5d;
																						IL_1b5d:
																						num6++;
																						goto IL_1b6b;
																						IL_1b6b:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_1e01:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_1e3f;
																						IL_1e3f:
																						num6 -= 3;
																						goto IL_2518;
																						IL_0d3b:
																						if (19 < b)
																						{
																							break;
																						}
																						goto IL_0d49;
																						IL_0d49:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_1aab;
																						IL_1aab:
																						array2[num6 - 1] = 5;
																						goto IL_1abf;
																						IL_1abf:
																						array3[num6 - 1] = ((delegate*<string[], string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_1af7;
																						IL_1af7:
																						ptr2 += 8;
																						num = 490;
																						goto IL_2518;
																						IL_1696:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						num = 391;
																						goto IL_16b8;
																						IL_16b8:
																						array2[num6] = 1;
																						num = 216;
																						goto IL_16cf;
																						IL_16cf:
																						num6++;
																						goto IL_16dd;
																						IL_16dd:
																						ptr2 += 16;
																						goto IL_2518;
																						IL_0d96:
																						if (22 >= b)
																						{
																							goto IL_0da4;
																						}
																						goto IL_1b7e;
																						IL_0da4:
																						if (22 > b)
																						{
																							goto IL_0db2;
																						}
																						goto IL_1d05;
																						IL_0db2:
																						if (21 < b)
																						{
																							break;
																						}
																						goto IL_0dc0;
																						IL_0dc0:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_0dce;
																						IL_0dce:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_2518;
																						IL_1d05:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_1d46;
																						IL_1d46:
																						array2[num6 - 2] = 0;
																						goto IL_1d5a;
																						IL_1d5a:
																						num6--;
																						goto IL_2518;
																						IL_1b7e:
																						if (23 < b)
																						{
																							break;
																						}
																						goto IL_1b8c;
																						IL_1b8c:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_1b9a;
																						IL_1b9a:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1bec;
																						IL_1bec:
																						num6--;
																						num = 392;
																						goto IL_2518;
																						IL_1874:
																						if (28 >= b)
																						{
																							goto IL_1882;
																						}
																						goto IL_1926;
																						IL_1882:
																						if (28 > b)
																						{
																							goto IL_188d;
																						}
																						goto IL_18d0;
																						IL_188d:
																						if (26 < b)
																						{
																							goto IL_189b;
																						}
																						goto IL_2031;
																						IL_189b:
																						if (27 < b)
																						{
																							break;
																						}
																						goto IL_18a9;
																						IL_18a9:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_18b7;
																						IL_18b7:
																						array2[num6 - 1] = 0;
																						goto IL_1daf;
																						IL_1daf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_1dee;
																						IL_1dee:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_2031:
																						if (26 > b)
																						{
																							goto IL_203c;
																						}
																						goto IL_20a9;
																						IL_203c:
																						if (25 < b)
																						{
																							break;
																						}
																						goto IL_204a;
																						IL_204a:
																						if (25 > b)
																						{
																							break;
																						}
																						goto IL_2058;
																						IL_2058:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						num = 296;
																						goto IL_207a;
																						IL_207a:
																						array2[num6] = 3;
																						goto IL_2088;
																						IL_2088:
																						num6++;
																						goto IL_2096;
																						IL_2096:
																						ptr2 += 16;
																						goto IL_2518;
																						IL_20a9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_20e9;
																						IL_20e9:
																						array2[num6 - 2] = 3;
																						num = 451;
																						goto IL_2106;
																						IL_2106:
																						num6--;
																						goto IL_2518;
																						IL_18d0:
																						array3[num6] = ((delegate*<string[]>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																						num = 45;
																						goto IL_18f7;
																						IL_18f7:
																						array2[num6] = 5;
																						goto IL_1905;
																						IL_1905:
																						num6++;
																						goto IL_1913;
																						IL_1913:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_1926:
																						if (30 >= b)
																						{
																							goto IL_1934;
																						}
																						goto IL_1a0e;
																						IL_1934:
																						if (30 <= b)
																						{
																							goto IL_193f;
																						}
																						goto IL_199f;
																						IL_193f:
																						array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_1978;
																						IL_1978:
																						array2[num6 - 2] = 5;
																						goto IL_198c;
																						IL_198c:
																						num6--;
																						goto IL_2518;
																						IL_199f:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_19ad;
																						IL_19ad:
																						if (29 > b)
																						{
																							break;
																						}
																						goto IL_19bb;
																						IL_19bb:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																						goto IL_19df;
																						IL_19df:
																						array2[num6] = 0;
																						goto IL_19ed;
																						IL_19ed:
																						num6++;
																						goto IL_19fb;
																						IL_19fb:
																						ptr2 += 8;
																						goto IL_2518;
																						IL_1a0e:
																						if (31 < b)
																						{
																							break;
																						}
																						goto IL_1a1c;
																						IL_1a1c:
																						if (31 > b)
																						{
																							break;
																						}
																						goto IL_1a2a;
																						IL_1a2a:
																						array2[num6 - 2] = 5;
																						goto IL_1a3e;
																						IL_1a3e:
																						array3[num6 - 2] = ((delegate*<string, string, string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																						goto IL_1a8a;
																					}
																					break;
																					IL_08f9:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_2518;
																			continue;
																			end_IL_0909:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1c3c:
			while (true)
			{
				IL_1c3c_2:
				array = new byte[4];
				while (true)
				{
					IL_1c4a:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_1cf2_2:
							num6++;
							while (true)
							{
								IL_2518_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0909_2:
											if (b >= 1)
											{
												while (b <= 63)
												{
													while (true)
													{
														IL_08ec_2:
														if (32 < b)
														{
															while (true)
															{
																IL_08df_2:
																if (48 < b)
																{
																	while (true)
																	{
																		IL_08cf_2:
																		if (56 >= b)
																		{
																			while (true)
																			{
																				IL_08bf_2:
																				if (56 > b)
																				{
																					while (true)
																					{
																						IL_08af_2:
																						if (52 < b)
																						{
																							while (true)
																							{
																								IL_089f_2:
																								if (54 >= b)
																								{
																									while (true)
																									{
																										IL_088f_2:
																										if (54 > b)
																										{
																											while (53 >= b)
																											{
																												while (53 <= b)
																												{
																													num = 527;
																													while (true)
																													{
																														if (num != 527)
																														{
																															if (num != 1508)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 500:
																																goto IL_086c_2;
																															case 400:
																																goto IL_087f_2;
																															case 493:
																																goto IL_088f_2;
																															case 503:
																																goto IL_089f_2;
																															case 39:
																																goto IL_08af_2;
																															case 54:
																																goto IL_08bf_2;
																															case 373:
																																goto IL_08cf_2;
																															case 275:
																																goto IL_08df_2;
																															case 438:
																																goto IL_08ec_2;
																															case 401:
																																goto IL_08f9_2;
																															case 200:
																																goto IL_0909_2;
																															case 101:
																																goto end_IL_0909_2;
																															case 207:
																															case 231:
																																goto end_IL_0919;
																															case 144:
																																goto IL_0934_2;
																															case 197:
																																goto IL_0947_2;
																															case 61:
																																goto IL_0955_2;
																															case 50:
																																goto IL_0960_2;
																															case 202:
																																goto IL_0970_2;
																															case 22:
																																goto IL_097e_2;
																															case 212:
																																goto IL_098e_2;
																															case 199:
																																goto IL_099c_2;
																															case 75:
																															case 228:
																																goto IL_09a9_2;
																															case 250:
																																goto IL_09c2_2;
																															case 254:
																																goto IL_09d5_2;
																															case 53:
																																goto IL_09e3_2;
																															case 157:
																															case 255:
																																goto IL_09f6_2;
																															case 141:
																															case 274:
																																goto IL_0a12_2;
																															case 107:
																																goto IL_0a3b_2;
																															case 285:
																																goto IL_0a57_2;
																															case 149:
																																goto IL_0a65_2;
																															case 122:
																																goto IL_0a73_2;
																															case 40:
																																goto IL_0a81_2;
																															case 3:
																																goto IL_0a8f_2;
																															case 90:
																																goto IL_0a9d_2;
																															case 21:
																																goto IL_0aab_2;
																															case 37:
																															case 282:
																																goto IL_0ab9_2;
																															case 56:
																																goto IL_0ae2_2;
																															case 158:
																																goto IL_0afb_2;
																															case 132:
																																goto IL_0b06_2;
																															case 172:
																															case 244:
																																goto IL_0b14_2;
																															case 1:
																																goto IL_0b38_2;
																															case 17:
																																goto IL_0b48_2;
																															case 237:
																																goto IL_0b53_2;
																															case 102:
																																goto IL_0b6f_2;
																															case 201:
																																goto IL_0b7d_2;
																															case 36:
																																goto IL_0b8b_2;
																															case 289:
																																goto IL_0b9b_2;
																															case 204:
																															case 297:
																																goto IL_0bae_2;
																															case 287:
																															case 298:
																																goto IL_0bd9_2;
																															case 44:
																																goto IL_0bed_2;
																															case 299:
																																goto IL_0c31_2;
																															case 304:
																																goto IL_0c44_2;
																															case 19:
																															case 309:
																																goto IL_0c57_2;
																															case 262:
																																goto IL_0c65_2;
																															case 105:
																															case 317:
																																goto IL_0c8d_2;
																															case 48:
																															case 320:
																																goto IL_0caa_2;
																															case 322:
																																goto IL_0cc4_2;
																															case 191:
																																goto IL_0cd2_2;
																															case 82:
																																goto IL_0ce0_2;
																															case 327:
																																goto IL_0cf3_2;
																															case 206:
																																goto IL_0d01_2;
																															case 106:
																																goto IL_0d0c_2;
																															case 4:
																																goto IL_0d1a_2;
																															case 97:
																																goto IL_0d28_2;
																															case 258:
																																goto IL_0d3b_2;
																															case 89:
																																goto IL_0d49_2;
																															case 329:
																																goto IL_0d5c_2;
																															case 142:
																																goto IL_0d6a_2;
																															case 179:
																																goto IL_0d78_2;
																															case 161:
																																goto IL_0d86_2;
																															case 330:
																																goto IL_0d96_2;
																															case 278:
																																goto IL_0da4_2;
																															case 11:
																																goto IL_0db2_2;
																															case 183:
																																goto IL_0dc0_2;
																															case 170:
																															case 245:
																																goto IL_0dce_2;
																															case 331:
																																goto IL_0de6_2;
																															case 153:
																															case 156:
																																goto IL_0df4_2;
																															case 224:
																															case 334:
																																goto IL_0e14_2;
																															case 357:
																																goto IL_0e37_2;
																															case 159:
																															case 364:
																																goto IL_0e4a_2;
																															case 164:
																																goto IL_0e58_2;
																															case 367:
																																goto IL_0e75_2;
																															case 166:
																																goto IL_0e93_2;
																															case 151:
																																goto IL_0eb7_2;
																															case 313:
																																goto IL_0ecf_2;
																															case 376:
																																goto IL_0ee2_2;
																															case 193:
																															case 384:
																																goto IL_0ef5_2;
																															case 210:
																																goto IL_0f09_2;
																															case 395:
																																goto IL_0f56_2;
																															case 42:
																															case 387:
																																goto IL_0f64_2;
																															case 293:
																																goto IL_0f8d_2;
																															case 28:
																																goto IL_0fa4_2;
																															case 402:
																																goto IL_0fb7_2;
																															case 403:
																																goto IL_0fca_2;
																															case 41:
																																goto IL_1009_2;
																															case 409:
																																goto IL_101c_2;
																															case 414:
																																goto IL_102b_2;
																															case 388:
																																goto IL_1039_2;
																															case 133:
																																goto IL_1044_2;
																															case 30:
																															case 32:
																																goto IL_1052_2;
																															case 315:
																																goto IL_1092_2;
																															case 362:
																																goto IL_10a6_2;
																															case 328:
																																goto IL_10b9_2;
																															case 310:
																																goto IL_10c7_2;
																															case 67:
																															case 242:
																																goto IL_10d5_2;
																															case 25:
																																goto IL_10e3_2;
																															case 209:
																																goto IL_10ff_2;
																															case 416:
																																goto IL_111b_2;
																															case 126:
																															case 420:
																																goto IL_112e_2;
																															case 186:
																																goto IL_1142_2;
																															case 358:
																																goto IL_1181_2;
																															case 430:
																																goto IL_1194_2;
																															case 441:
																																goto IL_11a7_2;
																															case 443:
																																goto IL_11ba_2;
																															case 81:
																															case 248:
																																goto IL_11c5_2;
																															case 291:
																																goto IL_11e9_2;
																															case 251:
																																goto IL_11f7_2;
																															case 181:
																																goto IL_1205_2;
																															case 300:
																																goto IL_1218_2;
																															case 63:
																																goto IL_1226_2;
																															case 155:
																															case 265:
																																goto IL_1231_2;
																															case 136:
																																goto IL_1271_2;
																															case 426:
																																goto IL_1285_2;
																															case 365:
																																goto IL_1298_2;
																															case 162:
																																goto IL_12a6_2;
																															case 93:
																															case 410:
																																goto IL_12bd_2;
																															case 427:
																																goto IL_12d1_2;
																															case 0:
																																goto IL_1310_2;
																															case 8:
																																goto IL_1323_2;
																															case 184:
																																goto IL_1331_2;
																															case 444:
																																goto IL_134d_2;
																															case 348:
																																goto IL_135b_2;
																															case 314:
																															case 445:
																																goto IL_136e_2;
																															case 280:
																																goto IL_1392_2;
																															case 137:
																																goto IL_13a0_2;
																															case 394:
																																goto IL_13ae_2;
																															case 454:
																																goto IL_13c1_2;
																															case 343:
																																goto IL_13cf_2;
																															case 256:
																																goto IL_13dd_2;
																															case 382:
																															case 386:
																																goto IL_13e8_2;
																															case 208:
																																goto IL_144a_2;
																															case 412:
																																goto IL_145d_2;
																															case 38:
																																goto IL_146b_2;
																															case 71:
																															case 148:
																																goto IL_1479_2;
																															case 117:
																																goto IL_14be_2;
																															case 62:
																																goto IL_14cc_2;
																															case 130:
																															case 180:
																																goto IL_14da_2;
																															case 104:
																																goto IL_14f7_2;
																															case 458:
																																goto IL_153b_2;
																															case 160:
																																goto IL_1549_2;
																															case 5:
																															case 460:
																																goto IL_155c_2;
																															case 84:
																																goto IL_1579_2;
																															case 355:
																																goto IL_15c0_2;
																															case 68:
																																goto IL_15ce_2;
																															case 466:
																																goto IL_15e1_2;
																															case 377:
																																goto IL_15ef_2;
																															case 379:
																																goto IL_15fd_2;
																															case 467:
																																goto IL_1610_2;
																															case 127:
																															case 352:
																																goto IL_161e_2;
																															case 239:
																																goto IL_1633_2;
																															case 468:
																																goto IL_1646_2;
																															case 261:
																															case 318:
																																goto IL_1654_2;
																															case 176:
																																goto IL_167d_2;
																															case 234:
																															case 471:
																																goto IL_1696_2;
																															case 391:
																																goto IL_16b8_2;
																															case 216:
																																goto IL_16cf_2;
																															case 188:
																																goto IL_16dd_2;
																															case 472:
																																goto IL_16f0_2;
																															case 453:
																																goto IL_16fe_2;
																															case 302:
																																goto IL_170c_2;
																															case 205:
																																goto IL_171a_2;
																															case 16:
																															case 222:
																																goto IL_1728_2;
																															case 449:
																																goto IL_1768_2;
																															case 138:
																																goto IL_177c_2;
																															case 253:
																																goto IL_178f_2;
																															case 363:
																																goto IL_179d_2;
																															case 74:
																															case 232:
																																goto IL_17ab_2;
																															case 247:
																																goto IL_17eb_2;
																															case 417:
																																goto IL_17ff_2;
																															case 473:
																																goto IL_1812_2;
																															case 475:
																																goto IL_1825_2;
																															case 198:
																																goto IL_1839_2;
																															case 15:
																															case 477:
																																goto IL_184c_2;
																															case 185:
																																goto IL_1861_2;
																															case 482:
																																goto IL_1874_2;
																															case 340:
																																goto IL_1882_2;
																															case 221:
																																goto IL_188d_2;
																															case 18:
																																goto IL_189b_2;
																															case 83:
																																goto IL_18a9_2;
																															case 241:
																															case 462:
																																goto IL_18b7_2;
																															case 175:
																															case 398:
																																goto IL_18d0_2;
																															case 45:
																																goto IL_18f7_2;
																															case 218:
																																goto IL_1905_2;
																															case 436:
																																goto IL_1913_2;
																															case 145:
																																goto IL_1926_2;
																															case 270:
																																goto IL_1934_2;
																															case 87:
																															case 150:
																																goto IL_193f_2;
																															case 354:
																																goto IL_1978_2;
																															case 173:
																																goto IL_198c_2;
																															case 479:
																																goto IL_199f_2;
																															case 378:
																																goto IL_19ad_2;
																															case 360:
																															case 452:
																																goto IL_19bb_2;
																															case 243:
																																goto IL_19df_2;
																															case 147:
																																goto IL_19ed_2;
																															case 29:
																																goto IL_19fb_2;
																															case 66:
																																goto IL_1a0e_2;
																															case 46:
																																goto IL_1a1c_2;
																															case 421:
																															case 424:
																																goto IL_1a2a_2;
																															case 461:
																																goto IL_1a3e_2;
																															case 356:
																																goto IL_1a8a_2;
																															case 259:
																																goto IL_1a98_2;
																															case 407:
																															case 489:
																																goto IL_1aab_2;
																															case 26:
																																goto IL_1abf_2;
																															case 79:
																																goto IL_1af7_2;
																															case 393:
																															case 491:
																																goto IL_1b13_2;
																															case 34:
																																goto IL_1b3c_2;
																															case 268:
																																goto IL_1b4a_2;
																															case 492:
																																goto IL_1b5d_2;
																															case 168:
																																goto IL_1b6b_2;
																															case 496:
																																goto IL_1b7e_2;
																															case 459:
																																goto IL_1b8c_2;
																															case 118:
																															case 195:
																																goto IL_1b9a_2;
																															case 344:
																																goto IL_1bec_2;
																															case 498:
																																goto IL_1c08_2;
																															case 434:
																																goto IL_1c16_2;
																															case 455:
																															case 457:
																																goto IL_1c2d_2;
																															case 57:
																																goto end_IL_0929;
																															case 49:
																																goto IL_1cf2_2;
																															case 435:
																															case 499:
																																goto IL_1d05_2;
																															case 295:
																																goto IL_1d46_2;
																															case 413:
																																goto IL_1d5a_2;
																															case 504:
																																goto IL_1d6d_2;
																															case 506:
																																goto IL_1d89_2;
																															case 508:
																																goto IL_1d9c_2;
																															case 509:
																																goto IL_1daf_2;
																															case 374:
																																goto IL_1dee_2;
																															case 134:
																															case 510:
																																goto IL_1e01_2;
																															case 33:
																																goto IL_1e3f_2;
																															case 511:
																																goto IL_1e52_2;
																															case 463:
																																goto IL_1e60_2;
																															case 99:
																															case 123:
																																goto IL_1e6e_2;
																															case 152:
																																goto IL_1e97_2;
																															case 98:
																																goto IL_1eae_2;
																															case 305:
																															case 512:
																																goto IL_1ec1_2;
																															case 190:
																																goto IL_1ed5_2;
																															case 47:
																																goto IL_1f3f_2;
																															case 513:
																																goto IL_1f52_2;
																															case 139:
																															case 431:
																																goto IL_1f5d_2;
																															case 86:
																																goto IL_1f9d_2;
																															case 359:
																																goto IL_1fb1_2;
																															case 383:
																																goto IL_1fc4_2;
																															case 109:
																																goto IL_1fd2_2;
																															case 60:
																															case 341:
																																goto IL_1fe0_2;
																															case 267:
																																goto IL_1ff9_2;
																															case 339:
																																goto IL_2010_2;
																															case 12:
																																goto IL_201e_2;
																															case 514:
																																goto IL_2031_2;
																															case 442:
																																goto IL_203c_2;
																															case 433:
																																goto IL_204a_2;
																															case 125:
																															case 349:
																																goto IL_2058_2;
																															case 296:
																																goto IL_207a_2;
																															case 485:
																																goto IL_2088_2;
																															case 389:
																																goto IL_2096_2;
																															case 154:
																															case 211:
																																goto IL_20a9_2;
																															case 55:
																																goto IL_20e9_2;
																															case 451:
																																goto IL_2106_2;
																															case 52:
																															case 515:
																																goto IL_2119_2;
																															case 428:
																																goto IL_212e_2;
																															case 516:
																																goto IL_2141_2;
																															case 167:
																															case 517:
																																goto IL_2154_2;
																															case 72:
																																goto IL_2194_2;
																															case 23:
																																goto IL_21a8_2;
																															case 520:
																																goto IL_21bb_2;
																															case 213:
																																goto IL_21c9_2;
																															case 20:
																															case 76:
																																goto IL_21d7_2;
																															case 165:
																																goto IL_21eb_2;
																															case 483:
																																goto IL_222a_2;
																															case 487:
																																goto IL_223d_2;
																															case 119:
																																goto IL_2266_2;
																															case 203:
																																goto IL_2274_2;
																															case 14:
																																goto end_IL_0859_2;
																															case 470:
																																goto IL_2295_2;
																															case 7:
																															case 480:
																																goto IL_22a3_2;
																															case 135:
																																goto IL_22b8_2;
																															case 333:
																																goto IL_22cb_2;
																															case 143:
																																goto IL_22d9_2;
																															case 121:
																															case 312:
																																goto IL_22e4_2;
																															case 283:
																																goto IL_2308_2;
																															case 494:
																																goto IL_2316_2;
																															case 486:
																																goto IL_2324_2;
																															case 450:
																																goto IL_2337_2;
																															case 192:
																																goto IL_2342_2;
																															case 129:
																																goto IL_2359_2;
																															case 273:
																															case 323:
																																goto IL_2367_2;
																															case 171:
																																goto IL_2385_2;
																															case 223:
																																goto IL_239c_2;
																															case 465:
																																goto IL_23aa_2;
																															case 484:
																																goto IL_23bd_2;
																															case 59:
																															case 366:
																																goto IL_23c8_2;
																															case 437:
																																goto IL_23dd_2;
																															case 113:
																																goto IL_23f0_2;
																															case 321:
																																goto IL_2407_2;
																															case 85:
																															case 146:
																																goto IL_241e_2;
																															case 235:
																																goto IL_2433_2;
																															case 425:
																																goto IL_2446_2;
																															case 236:
																																goto IL_2451_2;
																															case 35:
																																goto IL_245f_2;
																															case 177:
																																goto IL_2472_2;
																															case 124:
																																goto IL_247d_2;
																															case 260:
																																goto IL_2488_2;
																															case 70:
																															case 380:
																																goto IL_2493_2;
																															case 178:
																																goto IL_24c5_2;
																															case 140:
																																goto IL_24d3_2;
																															case 288:
																															case 518:
																																goto IL_24e3_2;
																															case 2:
																															case 24:
																															case 27:
																															case 31:
																															case 51:
																															case 58:
																															case 64:
																															case 65:
																															case 69:
																															case 73:
																															case 77:
																															case 92:
																															case 96:
																															case 100:
																															case 112:
																															case 131:
																															case 174:
																															case 182:
																															case 187:
																															case 214:
																															case 215:
																															case 217:
																															case 219:
																															case 220:
																															case 227:
																															case 230:
																															case 233:
																															case 238:
																															case 240:
																															case 249:
																															case 263:
																															case 264:
																															case 269:
																															case 271:
																															case 277:
																															case 281:
																															case 286:
																															case 294:
																															case 303:
																															case 311:
																															case 324:
																															case 342:
																															case 346:
																															case 347:
																															case 351:
																															case 353:
																															case 372:
																															case 375:
																															case 381:
																															case 399:
																															case 404:
																															case 405:
																															case 406:
																															case 415:
																															case 419:
																															case 429:
																															case 448:
																															case 456:
																															case 481:
																															case 488:
																															case 495:
																															case 497:
																															case 501:
																															case 502:
																															case 507:
																															case 519:
																																goto end_IL_086c_2;
																															case 6:
																															case 9:
																															case 10:
																															case 43:
																															case 78:
																															case 80:
																															case 88:
																															case 94:
																															case 95:
																															case 103:
																															case 108:
																															case 111:
																															case 114:
																															case 115:
																															case 120:
																															case 128:
																															case 163:
																															case 169:
																															case 189:
																															case 196:
																															case 225:
																															case 226:
																															case 229:
																															case 246:
																															case 252:
																															case 257:
																															case 272:
																															case 276:
																															case 279:
																															case 284:
																															case 290:
																															case 301:
																															case 306:
																															case 307:
																															case 316:
																															case 319:
																															case 325:
																															case 326:
																															case 332:
																															case 335:
																															case 336:
																															case 337:
																															case 338:
																															case 345:
																															case 350:
																															case 361:
																															case 369:
																															case 370:
																															case 371:
																															case 385:
																															case 390:
																															case 392:
																															case 408:
																															case 418:
																															case 422:
																															case 423:
																															case 432:
																															case 440:
																															case 446:
																															case 464:
																															case 469:
																															case 474:
																															case 476:
																															case 478:
																															case 490:
																															case 505:
																																goto IL_2518_2;
																															case 13:
																																ptr2 = ptr;
																																goto IL_2518_2;
																															case 116:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VTVOIDUnix.IEnumSTOREDEPLOYMENTMETADATAid);
																																goto case 13;
																															case 308:
																																array7 = new object[38];
																																goto case 116;
																															case 110:
																																array6 = new long[4];
																																goto case 308;
																															case 194:
																																array5 = new int[7];
																																goto case 110;
																															case 368:
																																array4 = new int[4];
																																num = 194;
																																goto case 194;
																															case 411:
																																array3 = new object[4];
																																goto case 368;
																															case 447:
																																array2 = new byte[4];
																																goto case 411;
																															case 91:
																																num4 = num2 * 8;
																																goto case 447;
																															case 292:
																																num3 = num2 * 4;
																																goto case 91;
																															case 396:
																																num2 = 1;
																																goto case 292;
																															case 397:
																																goto end_IL_1ce4;
																															case 266:
																															case 439:
																																return;
																															}
																															continue;
																														}
																														goto IL_223d_2;
																														IL_2266_2:
																														num6--;
																														goto IL_2274_2;
																														IL_2274_2:
																														ptr2 += 8;
																														goto IL_2518_2;
																														IL_223d_2:
																														((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																														goto IL_2266_2;
																														continue;
																														end_IL_0859_2:
																														break;
																													}
																													goto IL_2287_2;
																													continue;
																													end_IL_086c_2:
																													break;
																													IL_086c_2:;
																												}
																												break;
																												IL_087f_2:;
																											}
																											break;
																										}
																										goto IL_09a9_2;
																										IL_1009_2:
																										ptr2 += 8;
																										goto IL_2518_2;
																										IL_09a9_2:
																										array2[num6 - 1] = 3;
																										goto IL_0fca_2;
																										IL_0fca_2:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_1009_2;
																									}
																									break;
																								}
																								goto IL_2287_2;
																								IL_22b8_2:
																								ptr2 += 8;
																								goto IL_2518_2;
																								IL_2287_2:
																								if (55 < b)
																								{
																									break;
																								}
																								goto IL_2295_2;
																								IL_2295_2:
																								if (55 > b)
																								{
																									break;
																								}
																								goto IL_22a3_2;
																								IL_22a3_2:
																								((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																								goto IL_22b8_2;
																							}
																							break;
																						}
																						goto IL_102b_2;
																						IL_1f3f_2:
																						ptr2 += 8;
																						goto IL_2518_2;
																						IL_102b_2:
																						if (52 > b)
																						{
																							goto IL_1039_2;
																						}
																						goto IL_1ec1_2;
																						IL_1039_2:
																						if (50 >= b)
																						{
																							goto IL_1044_2;
																						}
																						goto IL_10b9_2;
																						IL_1044_2:
																						if (50 <= b)
																						{
																							goto IL_1052_2;
																						}
																						goto IL_21bb_2;
																						IL_1052_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1092_2;
																						IL_1092_2:
																						array2[num6 - 2] = 3;
																						goto IL_10a6_2;
																						IL_10a6_2:
																						num6--;
																						goto IL_2518_2;
																						IL_21bb_2:
																						if (49 < b)
																						{
																							break;
																						}
																						goto IL_21c9_2;
																						IL_21c9_2:
																						if (49 > b)
																						{
																							break;
																						}
																						goto IL_21d7_2;
																						IL_21d7_2:
																						array2[num6 - 1] = 3;
																						goto IL_21eb_2;
																						IL_21eb_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_222a_2;
																						IL_222a_2:
																						ptr2 += 8;
																						goto IL_2518_2;
																						IL_10b9_2:
																						if (51 < b)
																						{
																							break;
																						}
																						goto IL_10c7_2;
																						IL_10c7_2:
																						if (51 > b)
																						{
																							break;
																						}
																						goto IL_10d5_2;
																						IL_10d5_2:
																						array2[num6] = 15;
																						goto IL_10e3_2;
																						IL_10e3_2:
																						array4[num6] = *(int*)(ptr2 + num3);
																						num = 209;
																						goto IL_10ff_2;
																						IL_10ff_2:
																						ptr2 += 8;
																						num = 441;
																						goto IL_11a7_2;
																						IL_11a7_2:
																						num6++;
																						goto IL_2518_2;
																						IL_1ec1_2:
																						array2[num6 - 1] = 5;
																						goto IL_1ed5_2;
																						IL_1ed5_2:
																						array3[num6 - 1] = ((delegate*<ref int, string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref int>)AccountCertAdminsSidTypeConstructorName[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																						goto IL_1f3f_2;
																					}
																					break;
																				}
																				goto IL_0bd9_2;
																				IL_0fb7_2:
																				ptr2 += 8;
																				goto IL_2518_2;
																				IL_0bd9_2:
																				array2[num6 - 1] = 3;
																				goto IL_0bed_2;
																				IL_0bed_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_0fb7_2;
																			}
																			break;
																		}
																		goto IL_22cb_2;
																		IL_2493_2:
																		((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																		num = 178;
																		goto IL_24c5_2;
																		IL_22cb_2:
																		if (60 >= b)
																		{
																			goto IL_22d9_2;
																		}
																		goto IL_2446_2;
																		IL_22d9_2:
																		if (60 <= b)
																		{
																			goto IL_22e4_2;
																		}
																		goto IL_2337_2;
																		IL_22e4_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																		goto IL_2308_2;
																		IL_2308_2:
																		array2[num6] = 0;
																		goto IL_2316_2;
																		IL_2316_2:
																		num6++;
																		goto IL_2324_2;
																		IL_2324_2:
																		ptr2 += 8;
																		goto IL_2518_2;
																		IL_2337_2:
																		if (58 < b)
																		{
																			goto IL_2342_2;
																		}
																		goto IL_23bd_2;
																		IL_2342_2:
																		if (59 < b)
																		{
																			break;
																		}
																		num = 129;
																		goto IL_2359_2;
																		IL_24c5_2:
																		num6--;
																		goto IL_24d3_2;
																		IL_2359_2:
																		if (59 > b)
																		{
																			break;
																		}
																		goto IL_2367_2;
																		IL_2367_2:
																		array3[num6] = ((delegate*<string[]>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																		goto IL_2385_2;
																		IL_2385_2:
																		array2[num6] = 5;
																		num = 223;
																		goto IL_239c_2;
																		IL_239c_2:
																		num6++;
																		goto IL_23aa_2;
																		IL_23aa_2:
																		ptr2 += 8;
																		goto IL_2518_2;
																		IL_23bd_2:
																		if (58 <= b)
																		{
																			goto IL_23c8_2;
																		}
																		goto IL_23f0_2;
																		IL_23c8_2:
																		((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																		goto IL_23dd_2;
																		IL_23dd_2:
																		ptr2 += 8;
																		goto IL_2518_2;
																		IL_23f0_2:
																		if (57 < b)
																		{
																			break;
																		}
																		num = 321;
																		goto IL_2407_2;
																		IL_24d3_2:
																		ptr2 += 8;
																		goto IL_2518_2;
																		IL_2407_2:
																		if (57 > b)
																		{
																			break;
																		}
																		num = 146;
																		goto IL_241e_2;
																		IL_24e3_2:
																		num7 = ptr2;
																		num8 = -200;
																		num5 = 1;
																		ptr2 = num7 + num8;
																		num = 9;
																		goto IL_2518_2;
																		IL_241e_2:
																		((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																		goto IL_2433_2;
																		IL_2433_2:
																		ptr2 += 8;
																		goto IL_2518_2;
																		IL_2446_2:
																		if (62 < b)
																		{
																			goto IL_2451_2;
																		}
																		goto IL_2472_2;
																		IL_2451_2:
																		if (63 < b)
																		{
																			break;
																		}
																		goto IL_245f_2;
																		IL_245f_2:
																		if (63 > b)
																		{
																		}
																		break;
																		IL_2472_2:
																		if (62 > b)
																		{
																			goto IL_247d_2;
																		}
																		goto IL_24e3_2;
																		IL_247d_2:
																		if (61 < b)
																		{
																			break;
																		}
																		goto IL_2488_2;
																		IL_2488_2:
																		if (61 > b)
																		{
																			break;
																		}
																		goto IL_2493_2;
																	}
																	break;
																}
																goto IL_0934_2;
																IL_1142_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1181_2;
																IL_0934_2:
																if (48 > b)
																{
																	goto IL_0a57_2;
																}
																goto IL_2119_2;
																IL_0a57_2:
																if (40 >= b)
																{
																	goto IL_0a65_2;
																}
																goto IL_0afb_2;
																IL_0a65_2:
																if (40 > b)
																{
																	goto IL_0a73_2;
																}
																goto IL_0ef5_2;
																IL_0a73_2:
																if (36 < b)
																{
																	goto IL_0a81_2;
																}
																goto IL_11ba_2;
																IL_0a81_2:
																if (38 >= b)
																{
																	goto IL_0a8f_2;
																}
																goto IL_0c44_2;
																IL_0a8f_2:
																if (38 > b)
																{
																	goto IL_0a9d_2;
																}
																goto IL_155c_2;
																IL_0a9d_2:
																if (37 < b)
																{
																	break;
																}
																goto IL_0aab_2;
																IL_0aab_2:
																if (37 > b)
																{
																	break;
																}
																goto IL_0ab9_2;
																IL_0ab9_2:
																array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_0ae2_2;
																IL_0ae2_2:
																array2[num6 - 1] = 5;
																goto IL_2518_2;
																IL_155c_2:
																array2[num6 - 2] = 5;
																num = 84;
																goto IL_1579_2;
																IL_1579_2:
																array3[num6 - 2] = ((delegate*<string, object, string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], array3[num6 - 1]);
																goto IL_15c0_2;
																IL_15c0_2:
																num6--;
																goto IL_15ce_2;
																IL_15ce_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_0c44_2:
																if (39 < b)
																{
																	break;
																}
																goto IL_0f56_2;
																IL_0f56_2:
																if (39 > b)
																{
																	break;
																}
																goto IL_0f64_2;
																IL_0f64_2:
																((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_0f8d_2;
																IL_0f8d_2:
																num6--;
																num = 28;
																goto IL_0fa4_2;
																IL_0fa4_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_11ba_2:
																if (36 <= b)
																{
																	goto IL_11c5_2;
																}
																goto IL_1218_2;
																IL_11c5_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																goto IL_11e9_2;
																IL_11e9_2:
																array2[num6] = 3;
																goto IL_11f7_2;
																IL_11f7_2:
																num6++;
																goto IL_1205_2;
																IL_1205_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_1218_2:
																if (34 >= b)
																{
																	goto IL_1226_2;
																}
																goto IL_1323_2;
																IL_1226_2:
																if (34 <= b)
																{
																	goto IL_1231_2;
																}
																goto IL_1298_2;
																IL_1231_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_1271_2;
																IL_1271_2:
																array2[num6 - 2] = 3;
																goto IL_1285_2;
																IL_1285_2:
																num6--;
																goto IL_2518_2;
																IL_1298_2:
																if (33 < b)
																{
																	break;
																}
																goto IL_12a6_2;
																IL_12a6_2:
																if (33 > b)
																{
																	break;
																}
																num = 410;
																goto IL_12bd_2;
																IL_1181_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_12bd_2:
																array2[num6 - 1] = 3;
																goto IL_12d1_2;
																IL_12d1_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1310_2;
																IL_1310_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_1323_2:
																if (35 < b)
																{
																	break;
																}
																goto IL_1331_2;
																IL_1331_2:
																if (35 > b)
																{
																	break;
																}
																num = 15;
																goto IL_184c_2;
																IL_2119_2:
																((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																goto IL_212e_2;
																IL_184c_2:
																((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																goto IL_1861_2;
																IL_1861_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_0ef5_2:
																array2[num6 - 1] = 3;
																goto IL_0f09_2;
																IL_0f09_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																num = 473;
																goto IL_1812_2;
																IL_1812_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_0afb_2:
																if (44 >= b)
																{
																	goto IL_0b06_2;
																}
																goto IL_0b48_2;
																IL_0b06_2:
																if (44 <= b)
																{
																	goto IL_0b14_2;
																}
																goto IL_0d5c_2;
																IL_0b14_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																goto IL_0b38_2;
																IL_0b38_2:
																array2[num6] = 3;
																goto IL_0b9b_2;
																IL_0b9b_2:
																num6++;
																goto IL_2141_2;
																IL_2141_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_0d5c_2:
																if (42 >= b)
																{
																	goto IL_0d6a_2;
																}
																goto IL_1e52_2;
																IL_0d6a_2:
																if (42 > b)
																{
																	goto IL_0d78_2;
																}
																goto IL_136e_2;
																IL_0d78_2:
																if (41 < b)
																{
																	break;
																}
																goto IL_0d86_2;
																IL_0d86_2:
																if (41 > b)
																{
																	break;
																}
																goto IL_0e14_2;
																IL_0e14_2:
																array3[num6] = ((delegate*<string[]>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																goto IL_1194_2;
																IL_1194_2:
																array2[num6] = 5;
																goto IL_134d_2;
																IL_134d_2:
																num6++;
																goto IL_135b_2;
																IL_135b_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_136e_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																goto IL_1392_2;
																IL_1392_2:
																array2[num6] = 0;
																goto IL_13a0_2;
																IL_13a0_2:
																num6++;
																goto IL_13ae_2;
																IL_13ae_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_1e52_2:
																if (43 < b)
																{
																	break;
																}
																goto IL_1e60_2;
																IL_1e60_2:
																if (43 > b)
																{
																	break;
																}
																goto IL_1e6e_2;
																IL_1e6e_2:
																((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_1e97_2;
																IL_1e97_2:
																num6--;
																num = 98;
																goto IL_1eae_2;
																IL_1eae_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_0b48_2:
																if (46 < b)
																{
																	goto IL_0b53_2;
																}
																num = 102;
																goto IL_0b6f_2;
																IL_0b53_2:
																if (47 < b)
																{
																	break;
																}
																goto IL_1610_2;
																IL_1610_2:
																if (47 > b)
																{
																	break;
																}
																goto IL_161e_2;
																IL_161e_2:
																((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
																goto IL_1633_2;
																IL_1633_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_212e_2:
																ptr2 += 8;
																goto IL_2518_2;
																IL_0b6f_2:
																if (46 > b)
																{
																	goto IL_0b7d_2;
																}
																goto IL_112e_2;
																IL_0b7d_2:
																if (45 < b)
																{
																	break;
																}
																goto IL_0b8b_2;
																IL_0b8b_2:
																if (45 > b)
																{
																	break;
																}
																goto IL_0bae_2;
																IL_0bae_2:
																((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_0c31_2;
																IL_0c31_2:
																num6--;
																goto IL_1d6d_2;
																IL_1d6d_2:
																ptr2 += 8;
																num = 189;
																goto IL_2518_2;
																IL_112e_2:
																array2[num6 - 1] = 3;
																goto IL_1142_2;
															}
															break;
														}
														goto IL_0947_2;
														IL_0a3b_2:
														num6--;
														num = 376;
														goto IL_0ee2_2;
														IL_0947_2:
														if (32 > b)
														{
															goto IL_0955_2;
														}
														goto IL_0a12_2;
														IL_0955_2:
														if (16 >= b)
														{
															goto IL_0960_2;
														}
														goto IL_0970_2;
														IL_0960_2:
														if (16 > b)
														{
															goto IL_098e_2;
														}
														goto IL_0c8d_2;
														IL_098e_2:
														if (8 >= b)
														{
															goto IL_099c_2;
														}
														goto IL_0cc4_2;
														IL_099c_2:
														if (8 > b)
														{
															goto IL_09d5_2;
														}
														goto IL_09f6_2;
														IL_09f6_2:
														num6--;
														num = 325;
														goto IL_2518_2;
														IL_09d5_2:
														if (4 >= b)
														{
															goto IL_09e3_2;
														}
														goto IL_16f0_2;
														IL_09e3_2:
														if (4 <= b)
														{
															goto IL_0c57_2;
														}
														goto IL_15e1_2;
														IL_0c57_2:
														array2[num6] = 0;
														goto IL_0c65_2;
														IL_0c65_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_101c_2;
														IL_101c_2:
														array3[num6] = null;
														goto IL_153b_2;
														IL_153b_2:
														num6++;
														goto IL_1549_2;
														IL_1549_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_15e1_2:
														if (2 < b)
														{
															goto IL_15ef_2;
														}
														goto IL_1f52_2;
														IL_15ef_2:
														if (3 < b)
														{
															break;
														}
														goto IL_15fd_2;
														IL_15fd_2:
														if (3 > b)
														{
															break;
														}
														goto IL_1b13_2;
														IL_1b13_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1b3c_2;
														IL_1b3c_2:
														ptr2 += 8;
														goto IL_1b4a_2;
														IL_1b4a_2:
														num6--;
														goto IL_2518_2;
														IL_1f52_2:
														if (2 <= b)
														{
															goto IL_1f5d_2;
														}
														goto IL_1fc4_2;
														IL_1f5d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1f9d_2;
														IL_1f9d_2:
														array2[num6 - 2] = 0;
														goto IL_1fb1_2;
														IL_1fb1_2:
														num6--;
														goto IL_2518_2;
														IL_1fc4_2:
														if (1 < b)
														{
															break;
														}
														goto IL_1fd2_2;
														IL_1fd2_2:
														if (1 > b)
														{
															break;
														}
														goto IL_1fe0_2;
														IL_1fe0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_1ff9_2;
														IL_1ff9_2:
														array2[num6] = 0;
														num = 339;
														goto IL_2010_2;
														IL_2010_2:
														num6++;
														goto IL_201e_2;
														IL_201e_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_16f0_2:
														if (6 >= b)
														{
															goto IL_16fe_2;
														}
														goto IL_178f_2;
														IL_16fe_2:
														if (6 > b)
														{
															goto IL_170c_2;
														}
														goto IL_2154_2;
														IL_170c_2:
														if (5 < b)
														{
															break;
														}
														goto IL_171a_2;
														IL_171a_2:
														if (5 > b)
														{
															break;
														}
														goto IL_1728_2;
														IL_1728_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1768_2;
														IL_1768_2:
														array2[num6 - 2] = 0;
														goto IL_177c_2;
														IL_177c_2:
														num6--;
														goto IL_2518_2;
														IL_2154_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2194_2;
														IL_2194_2:
														array2[num6 - 2] = 0;
														goto IL_21a8_2;
														IL_21a8_2:
														num6--;
														goto IL_2518_2;
														IL_178f_2:
														if (7 < b)
														{
															break;
														}
														goto IL_179d_2;
														IL_179d_2:
														if (7 > b)
														{
															break;
														}
														goto IL_17ab_2;
														IL_17ab_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_17eb_2;
														IL_17eb_2:
														array2[num6 - 2] = 0;
														goto IL_17ff_2;
														IL_17ff_2:
														num6--;
														goto IL_2518_2;
														IL_0cc4_2:
														if (12 < b)
														{
															goto IL_0cd2_2;
														}
														goto IL_13c1_2;
														IL_0cd2_2:
														if (14 < b)
														{
															goto IL_0ce0_2;
														}
														goto IL_0de6_2;
														IL_0ce0_2:
														if (15 < b)
														{
															break;
														}
														goto IL_1646_2;
														IL_1646_2:
														if (15 > b)
														{
															break;
														}
														goto IL_1654_2;
														IL_1654_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_167d_2;
														IL_167d_2:
														array2[num6 - 1] = 5;
														goto IL_2518_2;
														IL_0de6_2:
														if (14 <= b)
														{
															goto IL_0df4_2;
														}
														goto IL_1c08_2;
														IL_0df4_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_0e37_2;
														IL_0e37_2:
														ptr2 += 8;
														goto IL_1d89_2;
														IL_1d89_2:
														num6--;
														goto IL_2518_2;
														IL_1c08_2:
														if (13 < b)
														{
															break;
														}
														goto IL_1c16_2;
														IL_1c16_2:
														if (13 > b)
														{
															break;
														}
														num = 455;
														goto IL_1c2d_2;
														IL_0ee2_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_1c2d_2:
														array8 = array3;
														num9 = num6;
														if (array == null)
														{
															goto IL_1c3c_2;
														}
														goto IL_1c4a;
														IL_13c1_2:
														if (12 <= b)
														{
															goto IL_2518_2;
														}
														goto IL_13cf_2;
														IL_13cf_2:
														if (10 >= b)
														{
															goto IL_13dd_2;
														}
														goto IL_14be_2;
														IL_13dd_2:
														if (10 <= b)
														{
															goto IL_13e8_2;
														}
														goto IL_145d_2;
														IL_13e8_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_144a_2;
														IL_144a_2:
														num6 -= 2;
														goto IL_2518_2;
														IL_145d_2:
														if (9 < b)
														{
															break;
														}
														goto IL_146b_2;
														IL_146b_2:
														if (9 > b)
														{
															break;
														}
														goto IL_1479_2;
														IL_1479_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1825_2;
														IL_1825_2:
														array2[num6 - 2] = 0;
														goto IL_1839_2;
														IL_1839_2:
														num6--;
														goto IL_2518_2;
														IL_14be_2:
														if (11 < b)
														{
															break;
														}
														goto IL_14cc_2;
														IL_14cc_2:
														if (11 > b)
														{
															break;
														}
														goto IL_14da_2;
														IL_14da_2:
														array2[num6 - 1] = 0;
														num = 104;
														goto IL_14f7_2;
														IL_14f7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1d9c_2;
														IL_1d9c_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_0c8d_2:
														array2[num6] = array2[num6 - 1];
														goto IL_0e75_2;
														IL_0e75_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_0e93_2;
														IL_0e93_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0eb7_2;
														IL_0eb7_2:
														array3[num6] = array3[num6 - 1];
														goto IL_0ecf_2;
														IL_0ecf_2:
														num6++;
														goto IL_2518_2;
														IL_0970_2:
														if (24 >= b)
														{
															goto IL_097e_2;
														}
														goto IL_1874_2;
														IL_097e_2:
														if (24 > b)
														{
															goto IL_09c2_2;
														}
														goto IL_0caa_2;
														IL_0caa_2:
														((delegate*<void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
														goto IL_111b_2;
														IL_111b_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_09c2_2:
														if (20 >= b)
														{
															goto IL_0cf3_2;
														}
														goto IL_0d96_2;
														IL_0cf3_2:
														if (20 > b)
														{
															goto IL_0d01_2;
														}
														goto IL_1696_2;
														IL_0d01_2:
														if (18 >= b)
														{
															goto IL_0d0c_2;
														}
														goto IL_0d3b_2;
														IL_0d0c_2:
														if (18 > b)
														{
															goto IL_0d1a_2;
														}
														goto IL_1e01_2;
														IL_0d1a_2:
														if (17 < b)
														{
															break;
														}
														goto IL_0d28_2;
														IL_0d28_2:
														if (17 > b)
														{
															break;
														}
														goto IL_0e4a_2;
														IL_0e4a_2:
														array2[num6] = 5;
														goto IL_0e58_2;
														IL_0e58_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_1b5d_2;
														IL_1b5d_2:
														num6++;
														goto IL_1b6b_2;
														IL_1b6b_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_1e01_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_1e3f_2;
														IL_1e3f_2:
														num6 -= 3;
														goto IL_2518_2;
														IL_0d3b_2:
														if (19 < b)
														{
															break;
														}
														goto IL_0d49_2;
														IL_0d49_2:
														if (19 > b)
														{
															break;
														}
														goto IL_1aab_2;
														IL_1aab_2:
														array2[num6 - 1] = 5;
														goto IL_1abf_2;
														IL_1abf_2:
														array3[num6 - 1] = ((delegate*<string[], string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_1af7_2;
														IL_1af7_2:
														ptr2 += 8;
														num = 490;
														goto IL_2518_2;
														IL_1696_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														num = 391;
														goto IL_16b8_2;
														IL_16b8_2:
														array2[num6] = 1;
														num = 216;
														goto IL_16cf_2;
														IL_16cf_2:
														num6++;
														goto IL_16dd_2;
														IL_16dd_2:
														ptr2 += 16;
														goto IL_2518_2;
														IL_0d96_2:
														if (22 >= b)
														{
															goto IL_0da4_2;
														}
														goto IL_1b7e_2;
														IL_0da4_2:
														if (22 > b)
														{
															goto IL_0db2_2;
														}
														goto IL_1d05_2;
														IL_0db2_2:
														if (21 < b)
														{
															break;
														}
														goto IL_0dc0_2;
														IL_0dc0_2:
														if (21 > b)
														{
															break;
														}
														goto IL_0dce_2;
														IL_0dce_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_2518_2;
														IL_1d05_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1d46_2;
														IL_1d46_2:
														array2[num6 - 2] = 0;
														goto IL_1d5a_2;
														IL_1d5a_2:
														num6--;
														goto IL_2518_2;
														IL_1b7e_2:
														if (23 < b)
														{
															break;
														}
														goto IL_1b8c_2;
														IL_1b8c_2:
														if (23 > b)
														{
															break;
														}
														goto IL_1b9a_2;
														IL_1b9a_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1bec_2;
														IL_1bec_2:
														num6--;
														num = 392;
														goto IL_2518_2;
														IL_1874_2:
														if (28 >= b)
														{
															goto IL_1882_2;
														}
														goto IL_1926_2;
														IL_1882_2:
														if (28 > b)
														{
															goto IL_188d_2;
														}
														goto IL_18d0_2;
														IL_188d_2:
														if (26 < b)
														{
															goto IL_189b_2;
														}
														goto IL_2031_2;
														IL_189b_2:
														if (27 < b)
														{
															break;
														}
														goto IL_18a9_2;
														IL_18a9_2:
														if (27 > b)
														{
															break;
														}
														goto IL_18b7_2;
														IL_18b7_2:
														array2[num6 - 1] = 0;
														goto IL_1daf_2;
														IL_1daf_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1dee_2;
														IL_1dee_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_2031_2:
														if (26 > b)
														{
															goto IL_203c_2;
														}
														goto IL_20a9_2;
														IL_203c_2:
														if (25 < b)
														{
															break;
														}
														goto IL_204a_2;
														IL_204a_2:
														if (25 > b)
														{
															break;
														}
														goto IL_2058_2;
														IL_2058_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														num = 296;
														goto IL_207a_2;
														IL_207a_2:
														array2[num6] = 3;
														goto IL_2088_2;
														IL_2088_2:
														num6++;
														goto IL_2096_2;
														IL_2096_2:
														ptr2 += 16;
														goto IL_2518_2;
														IL_20a9_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_20e9_2;
														IL_20e9_2:
														array2[num6 - 2] = 3;
														num = 451;
														goto IL_2106_2;
														IL_2106_2:
														num6--;
														goto IL_2518_2;
														IL_18d0_2:
														array3[num6] = ((delegate*<string[]>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
														num = 45;
														goto IL_18f7_2;
														IL_18f7_2:
														array2[num6] = 5;
														goto IL_1905_2;
														IL_1905_2:
														num6++;
														goto IL_1913_2;
														IL_1913_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_1926_2:
														if (30 >= b)
														{
															goto IL_1934_2;
														}
														goto IL_1a0e_2;
														IL_1934_2:
														if (30 <= b)
														{
															goto IL_193f_2;
														}
														goto IL_199f_2;
														IL_193f_2:
														array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1978_2;
														IL_1978_2:
														array2[num6 - 2] = 5;
														goto IL_198c_2;
														IL_198c_2:
														num6--;
														goto IL_2518_2;
														IL_199f_2:
														if (29 < b)
														{
															break;
														}
														goto IL_19ad_2;
														IL_19ad_2:
														if (29 > b)
														{
															break;
														}
														goto IL_19bb_2;
														IL_19bb_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])();
														goto IL_19df_2;
														IL_19df_2:
														array2[num6] = 0;
														goto IL_19ed_2;
														IL_19ed_2:
														num6++;
														goto IL_19fb_2;
														IL_19fb_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_1a0e_2:
														if (31 < b)
														{
															break;
														}
														goto IL_1a1c_2;
														IL_1a1c_2:
														if (31 > b)
														{
															break;
														}
														goto IL_1a2a_2;
														IL_1a2a_2:
														array2[num6 - 2] = 5;
														goto IL_1a3e_2;
														IL_1a3e_2:
														array3[num6 - 2] = ((delegate*<string, string, string>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
														goto IL_1a8a_2;
														IL_1a8a_2:
														num6--;
														goto IL_1a98_2;
														IL_1a98_2:
														ptr2 += 8;
														goto IL_2518_2;
														IL_0a12_2:
														((delegate*<string, void>)AccountCertAdminsSidTypeConstructorName[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_0a3b_2;
													}
													break;
													IL_08f9_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_2518_2;
											continue;
											end_IL_0909_2:
											break;
										}
										continue;
										end_IL_0919:
										break;
									}
									continue;
									end_IL_0929:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_1ce4:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	unsafe static Class10()
	{
		int num = 35;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2 = 1;
					while (true)
					{
						int num3 = num2 * 4;
						num = 146;
						while (true)
						{
							byte[] array = new byte[1];
							while (true)
							{
								object[] array2 = new object[1];
								while (true)
								{
									long[] array3 = new long[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getControlEvidenceTBStr.TypeBuilderEnsuresOnThrow);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_0394:
															if (b >= 1)
															{
																num = 143;
																while (b <= 20)
																{
																	while (true)
																	{
																		IL_0374:
																		if (10 >= b)
																		{
																			num = 30;
																			while (true)
																			{
																				IL_0364:
																				if (10 <= b)
																				{
																					num = 107;
																					while (true)
																					{
																						IL_0344:
																						((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																						num = 190;
																						while (true)
																						{
																							if (num != 190)
																							{
																								if (num != 1171)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 72:
																								case 107:
																									goto IL_0344;
																								case 30:
																									goto IL_0364;
																								case 26:
																									goto IL_0374;
																								case 143:
																									goto IL_0384;
																								case 183:
																									goto IL_0394;
																								case 0:
																									goto end_IL_0394;
																								case 174:
																								case 180:
																									goto end_IL_03a7;
																								case 6:
																									goto IL_03c2;
																								case 40:
																									goto IL_03d2;
																								case 24:
																									goto IL_03dd;
																								case 43:
																									goto IL_03ed;
																								case 5:
																									goto IL_03f8;
																								case 55:
																								case 67:
																									goto IL_0413;
																								case 68:
																									goto IL_0426;
																								case 88:
																									goto IL_0433;
																								case 58:
																								case 93:
																									goto IL_0446;
																								case 98:
																									goto IL_0454;
																								case 103:
																									goto IL_0467;
																								case 100:
																									goto IL_0475;
																								case 28:
																									goto IL_0483;
																								case 50:
																								case 116:
																									goto IL_0496;
																								case 90:
																									goto IL_04a4;
																								case 76:
																									goto IL_04c2;
																								case 118:
																									goto IL_04d5;
																								case 29:
																								case 36:
																									goto IL_04e9;
																								case 16:
																									goto IL_04f4;
																								case 25:
																									goto IL_0507;
																								case 70:
																									goto IL_0515;
																								case 1:
																								case 23:
																									goto IL_0523;
																								case 11:
																									goto IL_0538;
																								case 123:
																									goto IL_054b;
																								case 53:
																								case 115:
																									goto IL_0556;
																								case 12:
																									goto IL_0564;
																								case 65:
																								case 83:
																									goto IL_0572;
																								case 60:
																								case 77:
																									goto IL_058c;
																								case 104:
																									goto IL_05a1;
																								case 49:
																								case 126:
																									goto IL_05b4;
																								case 14:
																								case 128:
																									goto IL_05cb;
																								case 69:
																									goto IL_05d9;
																								case 129:
																									goto IL_05f5;
																								case 7:
																								case 66:
																									goto IL_060c;
																								case 131:
																									goto IL_0616;
																								case 132:
																									goto IL_0629;
																								case 9:
																								case 134:
																									goto IL_063c;
																								case 136:
																									goto IL_0656;
																								case 145:
																									goto IL_0669;
																								case 51:
																								case 117:
																									goto IL_0674;
																								case 15:
																									goto IL_0682;
																								case 45:
																								case 61:
																									goto IL_0690;
																								case 63:
																									goto IL_06ac;
																								case 41:
																								case 78:
																									goto IL_06ba;
																								case 19:
																									goto IL_06d3;
																								case 154:
																									goto IL_06e6;
																								case 110:
																								case 155:
																									goto IL_06f9;
																								case 31:
																									goto IL_071c;
																								case 120:
																								case 159:
																									goto IL_072f;
																								case 10:
																									goto IL_0744;
																								case 161:
																									goto IL_0757;
																								case 140:
																								case 163:
																									goto IL_076a;
																								case 92:
																									goto IL_0783;
																								case 17:
																								case 168:
																									goto IL_0796;
																								case 18:
																									goto IL_07ab;
																								case 169:
																									goto IL_07be;
																								case 84:
																								case 170:
																									goto IL_07d1;
																								case 79:
																								case 96:
																									goto IL_07dc;
																								case 86:
																									goto IL_07e7;
																								case 141:
																								case 165:
																									goto IL_07f5;
																								case 3:
																									goto IL_080a;
																								case 22:
																									goto IL_081d;
																								case 101:
																									goto IL_082b;
																								case 87:
																									goto IL_083b;
																								case 144:
																									goto IL_0846;
																								case 139:
																									goto IL_0851;
																								case 102:
																								case 142:
																									goto IL_087b;
																								case 80:
																									goto IL_0890;
																								case 74:
																								case 173:
																									goto IL_08a3;
																								case 46:
																									goto IL_08b8;
																								case 176:
																									goto IL_08cb;
																								case 111:
																									goto IL_08d9;
																								case 133:
																								case 177:
																									goto IL_08ec;
																								case 149:
																									goto IL_0900;
																								case 32:
																								case 178:
																									goto IL_0910;
																								case 119:
																									goto IL_092a;
																								case 179:
																									goto IL_093a;
																								case 182:
																									goto IL_094a;
																								case 4:
																								case 8:
																								case 20:
																								case 21:
																								case 27:
																								case 44:
																								case 47:
																								case 62:
																								case 71:
																								case 73:
																								case 81:
																								case 89:
																								case 97:
																								case 106:
																								case 108:
																								case 112:
																								case 121:
																								case 125:
																								case 127:
																								case 130:
																								case 137:
																								case 138:
																								case 147:
																								case 148:
																								case 150:
																								case 153:
																								case 158:
																								case 162:
																								case 166:
																								case 167:
																								case 171:
																								case 172:
																									goto end_IL_0331;
																								case 151:
																									goto IL_097f;
																								case 2:
																								case 13:
																								case 38:
																								case 48:
																								case 52:
																								case 54:
																								case 57:
																								case 59:
																								case 64:
																								case 75:
																								case 82:
																								case 85:
																								case 94:
																								case 95:
																								case 99:
																								case 105:
																								case 122:
																								case 135:
																								case 152:
																								case 157:
																								case 164:
																								case 175:
																									goto end_IL_03b7;
																								case 91:
																									goto end_IL_098d;
																								case 56:
																									goto end_IL_09a0;
																								case 39:
																								case 160:
																									goto end_IL_09aa;
																								case 156:
																									goto end_IL_09b5;
																								case 42:
																								case 146:
																									goto end_IL_09c5;
																								case 114:
																									goto end_IL_09d5;
																								case 109:
																								case 113:
																								case 124:
																								case 181:
																									goto end_IL_09e5;
																								case 34:
																									goto end_IL_09fe;
																								case 35:
																									goto end_IL_0a12;
																								case 33:
																								case 37:
																									return;
																								}
																								continue;
																							}
																							ptr2 += 8;
																							goto end_IL_03b7;
																							continue;
																							end_IL_0331:
																							break;
																						}
																						break;
																					}
																					break;
																				}
																				goto IL_03c2;
																				IL_0564:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0572;
																				IL_0572:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_06e6;
																				IL_03c2:
																				if (5 >= b)
																				{
																					goto IL_0433;
																				}
																				goto IL_04d5;
																				IL_0433:
																				if (5 <= b)
																				{
																					goto IL_0796;
																				}
																				goto IL_07d1;
																				IL_07d1:
																				if (2 < b)
																				{
																					goto IL_07dc;
																				}
																				goto IL_083b;
																				IL_07dc:
																				if (3 >= b)
																				{
																					goto IL_07e7;
																				}
																				goto IL_081d;
																				IL_07e7:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_07f5;
																				IL_07f5:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_080a;
																				IL_080a:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_081d:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_082b;
																				IL_082b:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_08a3;
																				IL_08a3:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_08b8;
																				IL_08b8:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_083b:
																				if (2 > b)
																				{
																					goto IL_0846;
																				}
																				num = 102;
																				goto IL_087b;
																				IL_0846:
																				if (1 < b)
																				{
																					num = 148;
																					break;
																				}
																				goto IL_0851;
																				IL_0851:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_058c:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_05a1;
																				IL_06e6:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_087b:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_0890;
																				IL_0890:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_0796:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_07ab;
																				IL_07ab:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_04d5:
																				if (7 < b)
																				{
																					num = 29;
																					goto IL_04e9;
																				}
																				goto IL_054b;
																				IL_05a1:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_04e9:
																				if (8 >= b)
																				{
																					goto IL_04f4;
																				}
																				goto IL_0507;
																				IL_04f4:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_05b4;
																				IL_05b4:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_0629;
																				IL_0629:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_0507:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0515;
																				IL_0515:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0523;
																				IL_0523:
																				((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_0538;
																				IL_0538:
																				ptr2 += 8;
																				goto end_IL_03b7;
																				IL_054b:
																				if (7 > b)
																				{
																					goto IL_0556;
																				}
																				goto IL_058c;
																				IL_0556:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0564;
																			}
																			break;
																		}
																		goto IL_03d2;
																		IL_0783:
																		array[num5] = 0;
																		goto IL_08cb;
																		IL_076a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(int*)(ptr2 + num3);
																		goto IL_0783;
																		IL_03d2:
																		if (15 < b)
																		{
																			goto IL_03dd;
																		}
																		goto IL_03ed;
																		IL_03dd:
																		if (18 >= b)
																		{
																			goto IL_0426;
																		}
																		goto IL_0669;
																		IL_0426:
																		if (18 > b)
																		{
																			goto IL_0446;
																		}
																		goto IL_0496;
																		IL_0446:
																		if (16 >= b)
																		{
																			goto IL_0454;
																		}
																		goto IL_0656;
																		IL_0454:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_06f9;
																		IL_06f9:
																		bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1])) != 0;
																		num = 31;
																		goto IL_071c;
																		IL_071c:
																		num5--;
																		goto end_IL_03b7;
																		IL_0656:
																		if (17 < b)
																		{
																			break;
																		}
																		goto IL_0757;
																		IL_0757:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_0910;
																		IL_0910:
																		bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1])) != 0;
																		goto IL_092a;
																		IL_092a:
																		num5--;
																		goto end_IL_03b7;
																		IL_0496:
																		array[num5] = 5;
																		goto IL_04a4;
																		IL_04a4:
																		array2[num5] = ((delegate*<HashSet<string>>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																		goto IL_04c2;
																		IL_04c2:
																		num5++;
																		goto IL_07be;
																		IL_07be:
																		ptr2 += 8;
																		goto end_IL_03b7;
																		IL_0669:
																		if (19 < b)
																		{
																			goto IL_0674;
																		}
																		goto IL_06ac;
																		IL_0674:
																		if (20 < b)
																		{
																			break;
																		}
																		goto IL_0682;
																		IL_0682:
																		if (20 > b)
																		{
																			break;
																		}
																		goto IL_0690;
																		IL_0690:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_03b7;
																		IL_06ac:
																		if (19 > b)
																		{
																			break;
																		}
																		goto IL_06ba;
																		IL_06ba:
																		hashSet_0 = (HashSet<string>)array2[num5 - 1];
																		goto IL_06d3;
																		IL_06d3:
																		num5--;
																		goto end_IL_03b7;
																		IL_03ed:
																		if (15 > b)
																		{
																			goto IL_03f8;
																		}
																		num = 140;
																		goto IL_076a;
																		IL_03f8:
																		if (12 < b)
																		{
																			goto IL_0413;
																		}
																		goto IL_0467;
																		IL_0467:
																		if (12 > b)
																		{
																			goto IL_0475;
																		}
																		goto IL_072f;
																		IL_0475:
																		if (11 < b)
																		{
																			break;
																		}
																		goto IL_0483;
																		IL_0483:
																		if (11 > b)
																		{
																			break;
																		}
																		goto IL_063c;
																		IL_063c:
																		((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																		goto IL_093a;
																		IL_093a:
																		ptr2 += 8;
																		goto end_IL_03b7;
																		IL_072f:
																		((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
																		goto IL_0744;
																		IL_0744:
																		ptr2 += 8;
																		goto end_IL_03b7;
																		IL_0413:
																		if (13 < b)
																		{
																			goto IL_05cb;
																		}
																		goto IL_05f5;
																		IL_05cb:
																		if (14 < b)
																		{
																			break;
																		}
																		goto IL_05d9;
																		IL_05d9:
																		if (14 > b)
																		{
																			break;
																		}
																		num = 133;
																		goto IL_08ec;
																		IL_08cb:
																		num5++;
																		goto IL_08d9;
																		IL_08ec:
																		string_0 = (string)array2[num5 - 1];
																		goto IL_0900;
																		IL_0900:
																		num5--;
																		goto end_IL_03b7;
																		IL_05f5:
																		if (13 > b)
																		{
																			break;
																		}
																		num = 7;
																		goto IL_060c;
																		IL_08d9:
																		ptr2 += 8;
																		goto end_IL_03b7;
																		IL_060c:
																		array2[num5] = null;
																		goto IL_0616;
																		IL_0616:
																		array[num5] = 5;
																		goto IL_094a;
																		IL_094a:
																		num5++;
																		goto end_IL_03b7;
																	}
																	break;
																	IL_0384:;
																}
															}
															((delegate*<void>)FailureCustomConstantAttribute[*(int*)(ptr2 + num3)])();
															goto IL_097f;
															IL_097f:
															ptr2 += 8;
															goto end_IL_03b7;
															continue;
															end_IL_0394:
															break;
														}
														continue;
														end_IL_03a7:
														break;
													}
													continue;
													end_IL_03b7:
													break;
												}
												continue;
												end_IL_098d:
												break;
											}
											continue;
											end_IL_09a0:
											break;
										}
										continue;
										end_IL_09aa:
										break;
									}
									continue;
									end_IL_09b5:
									break;
								}
								continue;
								end_IL_09c5:
								break;
							}
							continue;
							end_IL_09d5:
							break;
						}
						continue;
						end_IL_09e5:
						break;
					}
					continue;
					end_IL_09fe:
					break;
				}
				continue;
				end_IL_0a12:
				break;
			}
		}
	}

	private unsafe static int smethod_10()
	{
		int num = 111;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 43;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getProtectedCMSASSEMBLYDEPLOYMENTFLAGDISALLOWURLACTIVATION.NumberopBitwiseOr);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 169;
															while (true)
															{
																if (num != 169)
																{
																	if (num != 1150)
																	{
																		goto IL_057e;
																	}
																	switch (num)
																	{
																	case 72:
																		goto end_IL_02b3;
																	case 42:
																	case 137:
																		goto end_IL_02c3;
																	case 80:
																		goto IL_02f5;
																	case 11:
																		goto IL_0303;
																	case 84:
																		goto IL_0311;
																	case 46:
																		goto IL_031f;
																	case 48:
																		goto IL_032d;
																	case 4:
																	case 64:
																		goto IL_033b;
																	case 102:
																		goto IL_0349;
																	case 95:
																	case 139:
																		goto IL_0354;
																	case 113:
																		goto IL_0394;
																	case 32:
																		goto IL_03a8;
																	case 157:
																		goto IL_03bb;
																	case 49:
																		goto IL_03c9;
																	case 20:
																	case 124:
																		goto IL_03d7;
																	case 44:
																		goto IL_03f0;
																	case 3:
																		goto IL_0407;
																	case 68:
																		goto IL_0415;
																	case 127:
																		goto IL_0428;
																	case 52:
																		goto IL_0436;
																	case 98:
																	case 140:
																		goto IL_0444;
																	case 151:
																		goto IL_046d;
																	case 9:
																	case 90:
																		goto IL_0486;
																	case 116:
																		goto IL_04a4;
																	case 101:
																		goto IL_04b2;
																	case 74:
																		goto IL_04c5;
																	case 62:
																	case 109:
																		goto IL_04d3;
																	case 15:
																		goto IL_04de;
																	case 63:
																	case 114:
																		goto IL_04ec;
																	case 160:
																		goto IL_0515;
																	case 141:
																		goto IL_0523;
																	case 8:
																		goto IL_0536;
																	case 37:
																		goto IL_054d;
																	case 55:
																	case 120:
																		goto IL_055b;
																	case 142:
																		goto IL_0573;
																	case 23:
																	case 108:
																		goto IL_057e;
																	case 28:
																		goto IL_05bd;
																	case 71:
																		goto IL_05d0;
																	case 105:
																		goto IL_05de;
																	case 34:
																	case 94:
																		goto IL_05ec;
																	case 112:
																		goto IL_0603;
																	case 65:
																		goto IL_061b;
																	case 159:
																		goto IL_0629;
																	case 115:
																		goto IL_063c;
																	case 155:
																		goto IL_064a;
																	case 13:
																	case 57:
																		goto IL_0655;
																	case 106:
																		goto IL_06b7;
																	case 21:
																		goto IL_06ca;
																	case 39:
																		goto IL_06d8;
																	case 10:
																	case 125:
																		goto IL_06e3;
																	case 129:
																		goto IL_06f1;
																	case 99:
																	case 103:
																		goto IL_06ff;
																	case 93:
																		goto IL_070d;
																	case 135:
																		goto IL_0730;
																	case 119:
																		goto IL_073a;
																	case 134:
																		goto IL_0748;
																	case 22:
																	case 41:
																		goto IL_075b;
																	case 130:
																		goto IL_079f;
																	case 12:
																		goto IL_07b3;
																	case 81:
																		goto IL_07c6;
																	case 56:
																		goto IL_07d4;
																	case 16:
																	case 100:
																		goto IL_07eb;
																	case 96:
																		goto IL_082b;
																	case 27:
																		goto IL_083f;
																	case 40:
																		goto IL_0852;
																	case 147:
																		goto IL_0860;
																	case 75:
																	case 117:
																		goto IL_086b;
																	case 36:
																		goto IL_087e;
																	case 146:
																		goto IL_088c;
																	case 19:
																	case 24:
																		goto IL_089a;
																	case 6:
																		goto IL_08b7;
																	case 143:
																		goto IL_090b;
																	case 2:
																		goto IL_0919;
																	case 121:
																	case 158:
																		goto IL_0929;
																	case 131:
																	case 152:
																		goto IL_0934;
																	case 61:
																		goto IL_093f;
																	case 149:
																		goto IL_094c;
																	case 18:
																	case 29:
																	case 31:
																	case 33:
																	case 35:
																	case 38:
																	case 45:
																	case 47:
																	case 50:
																	case 51:
																	case 54:
																	case 59:
																	case 66:
																	case 69:
																	case 76:
																	case 78:
																	case 79:
																	case 82:
																	case 85:
																	case 89:
																	case 91:
																	case 92:
																	case 118:
																	case 123:
																	case 126:
																	case 132:
																	case 145:
																	case 150:
																	case 153:
																	case 161:
																	case 162:
																		goto IL_0957;
																	case 88:
																	case 104:
																		goto IL_096c;
																	case 1:
																	case 5:
																	case 7:
																	case 25:
																	case 26:
																	case 53:
																	case 58:
																	case 60:
																	case 70:
																	case 73:
																	case 83:
																	case 86:
																	case 97:
																	case 107:
																	case 128:
																	case 133:
																	case 138:
																	case 144:
																	case 148:
																	case 154:
																		goto end_IL_02dc;
																	case 67:
																		goto end_IL_0983;
																	case 14:
																		goto end_IL_0996;
																	case 87:
																		goto end_IL_09a0;
																	case 43:
																		goto end_IL_09ab;
																	case 0:
																	case 17:
																		goto end_IL_09bb;
																	case 156:
																		goto end_IL_09cb;
																	case 77:
																	case 122:
																		goto end_IL_09e4;
																	case 110:
																		goto end_IL_09f4;
																	case 111:
																		goto end_IL_0a04;
																	case 30:
																	case 136:
																		goto IL_0a1f;
																	}
																	continue;
																}
																if (b >= 1)
																{
																	goto IL_02f5;
																}
																goto IL_0957;
																IL_0934:
																if (17 >= b)
																{
																	goto IL_093f;
																}
																goto IL_0957;
																IL_094c:
																if (16 > b)
																{
																	goto IL_0957;
																}
																goto IL_096c;
																IL_093f:
																if (17 > b)
																{
																}
																goto IL_0957;
																IL_02f5:
																if (b <= 17)
																{
																	goto IL_0303;
																}
																goto IL_0957;
																IL_0303:
																if (9 >= b)
																{
																	goto IL_0311;
																}
																goto IL_063c;
																IL_0311:
																if (9 <= b)
																{
																	goto end_IL_02dc;
																}
																goto IL_031f;
																IL_031f:
																if (4 >= b)
																{
																	goto IL_032d;
																}
																goto IL_04c5;
																IL_032d:
																if (4 > b)
																{
																	goto IL_033b;
																}
																goto IL_0486;
																IL_033b:
																if (2 >= b)
																{
																	goto IL_0349;
																}
																goto IL_0428;
																IL_0349:
																if (2 <= b)
																{
																	goto IL_0354;
																}
																goto IL_03bb;
																IL_0354:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0394;
																IL_0394:
																array[num5 - 2] = 0;
																goto IL_03a8;
																IL_03a8:
																num5--;
																goto end_IL_02dc;
																IL_03bb:
																if (1 >= b)
																{
																	goto IL_03c9;
																}
																goto IL_0957;
																IL_03c9:
																if (1 <= b)
																{
																	goto IL_03d7;
																}
																goto IL_0957;
																IL_03d7:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_03f0;
																IL_03f0:
																array[num5] = 0;
																num = 3;
																goto IL_0407;
																IL_0407:
																num5++;
																goto IL_0415;
																IL_0415:
																ptr2 += 8;
																goto end_IL_02dc;
																IL_0428:
																if (3 >= b)
																{
																	goto IL_0436;
																}
																goto IL_0957;
																IL_0436:
																if (3 <= b)
																{
																	goto IL_0444;
																}
																goto IL_0957;
																IL_0444:
																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_046d;
																IL_046d:
																array[num5 - 1] = 5;
																goto end_IL_02dc;
																IL_0486:
																array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																goto IL_04a4;
																IL_04a4:
																ptr2 += 8;
																goto IL_04b2;
																IL_04b2:
																num5--;
																goto end_IL_02dc;
																IL_04c5:
																if (6 < b)
																{
																	goto IL_04d3;
																}
																goto IL_0573;
																IL_04d3:
																if (7 >= b)
																{
																	goto IL_04de;
																}
																goto IL_0536;
																IL_04de:
																if (7 <= b)
																{
																	goto IL_04ec;
																}
																goto IL_0957;
																IL_04ec:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0515;
																IL_0515:
																ptr2 += 8;
																goto IL_0523;
																IL_0523:
																num5--;
																goto end_IL_02dc;
																IL_0536:
																if (8 >= b)
																{
																	num = 37;
																	goto IL_054d;
																}
																goto IL_0957;
																IL_096c:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_02dc;
																IL_054d:
																if (8 <= b)
																{
																	goto IL_055b;
																}
																goto IL_0957;
																IL_055b:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02dc;
																IL_0573:
																if (6 <= b)
																{
																	goto IL_057e;
																}
																goto IL_05d0;
																IL_057e:
																((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_05bd;
																IL_05bd:
																num5 -= 3;
																goto end_IL_02dc;
																IL_05d0:
																if (5 >= b)
																{
																	goto IL_05de;
																}
																goto IL_0957;
																IL_05de:
																if (5 <= b)
																{
																	goto IL_05ec;
																}
																goto IL_0957;
																IL_05ec:
																array[num5] = 5;
																num = 112;
																goto IL_0603;
																IL_0603:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																goto IL_061b;
																IL_061b:
																num5++;
																goto IL_0629;
																IL_0629:
																ptr2 += 8;
																goto end_IL_02dc;
																IL_063c:
																if (13 >= b)
																{
																	goto IL_064a;
																}
																goto IL_0852;
																IL_064a:
																if (13 <= b)
																{
																	goto IL_0655;
																}
																goto IL_06ca;
																IL_0655:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_06b7;
																IL_06b7:
																num5 -= 2;
																goto end_IL_02dc;
																IL_06ca:
																if (11 >= b)
																{
																	goto IL_06d8;
																}
																goto IL_07c6;
																IL_06d8:
																if (11 > b)
																{
																	goto IL_06e3;
																}
																goto IL_075b;
																IL_06e3:
																if (10 >= b)
																{
																	goto IL_06f1;
																}
																goto IL_0957;
																IL_06f1:
																if (10 <= b)
																{
																	goto IL_06ff;
																}
																goto IL_0957;
																IL_06ff:
																array[num5] = 0;
																goto IL_070d;
																IL_070d:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0730;
																IL_0730:
																array2[num5] = null;
																goto IL_073a;
																IL_073a:
																num5++;
																goto IL_0748;
																IL_0748:
																ptr2 += 8;
																goto end_IL_02dc;
																IL_075b:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_079f;
																IL_079f:
																array[num5 - 2] = 0;
																goto IL_07b3;
																IL_07b3:
																num5--;
																goto end_IL_02dc;
																IL_07c6:
																if (12 >= b)
																{
																	goto IL_07d4;
																}
																goto IL_0957;
																IL_07d4:
																if (12 <= b)
																{
																	num = 100;
																	goto IL_07eb;
																}
																goto IL_0957;
																IL_0957:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02dc;
																IL_07eb:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_082b;
																IL_082b:
																array[num5 - 2] = 0;
																goto IL_083f;
																IL_083f:
																num5--;
																goto end_IL_02dc;
																IL_0852:
																if (15 >= b)
																{
																	goto IL_0860;
																}
																goto IL_0929;
																IL_0860:
																if (15 <= b)
																{
																	goto IL_086b;
																}
																goto IL_087e;
																IL_086b:
																num5--;
																goto end_IL_02dc;
																IL_087e:
																if (14 >= b)
																{
																	goto IL_088c;
																}
																goto IL_0957;
																IL_088c:
																if (14 <= b)
																{
																	goto IL_089a;
																}
																goto IL_0957;
																IL_089a:
																array[num5 - 2] = 0;
																num = 6;
																goto IL_08b7;
																IL_08b7:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)BinaryAssemblyInfoGetExceptionPointers[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																goto IL_090b;
																IL_090b:
																num5--;
																goto IL_0919;
																IL_0919:
																ptr2 += 8;
																goto end_IL_02dc;
																IL_0929:
																if (16 < b)
																{
																	goto IL_0934;
																}
																goto IL_094c;
																continue;
																end_IL_02b3:
																break;
															}
															continue;
															end_IL_02c3:
															break;
														}
														continue;
														end_IL_02dc:
														break;
													}
													continue;
												}
												goto IL_0a1f;
												IL_0a1f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0983:
												break;
											}
											continue;
											end_IL_0996:
											break;
										}
										continue;
										end_IL_09a0:
										break;
									}
									continue;
									end_IL_09ab:
									break;
								}
								continue;
								end_IL_09bb:
								break;
							}
							continue;
							end_IL_09cb:
							break;
						}
						continue;
						end_IL_09e4:
						break;
					}
					continue;
					end_IL_09f4:
					break;
				}
				continue;
				end_IL_0a04:
				break;
			}
		}
	}

	private unsafe static int smethod_11(int int_2)
	{
		int num = 103;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setVersionAddedSecurityContext.GetLastWriteTimeUtcSharedBool);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_028b:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_027e:
																		if (b <= 11)
																		{
																			while (true)
																			{
																				IL_026e:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0261:
																						if (6 <= b)
																						{
																							while (true)
																							{
																								IL_0216:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 125;
																								while (true)
																								{
																									if (num != 125)
																									{
																										if (num != 1106)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 24:
																										case 97:
																											goto IL_0216;
																										case 34:
																											goto IL_0261;
																										case 55:
																											goto IL_026e;
																										case 98:
																											goto IL_027e;
																										case 4:
																											goto IL_028b;
																										case 90:
																											goto end_IL_028b;
																										case 77:
																										case 88:
																											goto end_IL_029b;
																										case 81:
																										case 96:
																											goto IL_02c4;
																										case 75:
																											goto IL_02d2;
																										case 61:
																											goto IL_02dd;
																										case 86:
																											goto IL_02eb;
																										case 33:
																											goto IL_02f9;
																										case 7:
																										case 71:
																											goto IL_0307;
																										case 72:
																											goto IL_0330;
																										case 76:
																											goto IL_033e;
																										case 17:
																										case 38:
																											goto IL_0351;
																										case 5:
																										case 22:
																											goto IL_0372;
																										case 1:
																											goto IL_037d;
																										case 2:
																										case 100:
																											goto IL_0399;
																										case 80:
																											goto IL_03a7;
																										case 15:
																										case 18:
																											goto IL_03b5;
																										case 65:
																										case 101:
																											goto IL_03d1;
																										case 0:
																											goto IL_03df;
																										case 11:
																										case 84:
																											goto IL_03ea;
																										case 10:
																											goto IL_03f8;
																										case 28:
																										case 49:
																											goto IL_040b;
																										case 39:
																											goto IL_0476;
																										case 85:
																											goto IL_0489;
																										case 19:
																											goto IL_0494;
																										case 40:
																										case 46:
																											goto IL_049f;
																										case 8:
																											goto IL_04c9;
																										case 42:
																											goto IL_04d4;
																										case 111:
																											goto IL_04f5;
																										case 53:
																											goto IL_0518;
																										case 20:
																											goto IL_0522;
																										case 37:
																											goto IL_0530;
																										case 113:
																											goto IL_054c;
																										case 47:
																										case 60:
																											goto IL_055a;
																										case 50:
																											goto IL_0573;
																										case 114:
																											goto IL_0581;
																										case 16:
																											goto IL_058f;
																										case 105:
																										case 115:
																											goto IL_05a2;
																										case 73:
																											goto IL_05e2;
																										case 74:
																											goto IL_05f6;
																										case 110:
																										case 117:
																											goto IL_0609;
																										case 59:
																											goto IL_0614;
																										case 26:
																										case 78:
																											goto IL_061f;
																										case 112:
																											goto IL_0642;
																										case 48:
																											goto IL_0650;
																										case 43:
																											goto IL_065e;
																										case 6:
																										case 13:
																										case 23:
																										case 25:
																										case 27:
																										case 30:
																										case 31:
																										case 32:
																										case 36:
																										case 44:
																										case 51:
																										case 52:
																										case 54:
																										case 57:
																										case 62:
																										case 63:
																										case 66:
																										case 79:
																										case 83:
																										case 89:
																										case 92:
																										case 93:
																										case 94:
																										case 99:
																										case 104:
																											goto end_IL_0203;
																										case 91:
																											goto IL_06a0;
																										case 9:
																										case 14:
																										case 29:
																										case 35:
																										case 45:
																										case 58:
																										case 64:
																										case 67:
																										case 69:
																										case 70:
																										case 106:
																										case 107:
																										case 109:
																										case 116:
																											goto end_IL_02ab;
																										case 12:
																											goto end_IL_06b7;
																										case 108:
																											goto end_IL_06ca;
																										case 41:
																											goto end_IL_06d4;
																										case 118:
																											goto end_IL_06df;
																										case 3:
																										case 21:
																											goto end_IL_06f4;
																										case 87:
																											goto end_IL_0704;
																										case 56:
																										case 95:
																											goto end_IL_0714;
																										case 102:
																											goto end_IL_0724;
																										case 103:
																											goto end_IL_0734;
																										case 68:
																										case 82:
																											goto IL_074f;
																										}
																										continue;
																									}
																									array[num5 - 2] = 0;
																									goto IL_06a0;
																									IL_06a0:
																									num5--;
																									num = 45;
																									goto end_IL_02ab;
																									continue;
																									end_IL_0203:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_02c4;
																						IL_0518:
																						array2[num5] = null;
																						goto IL_0522;
																						IL_02c4:
																						if (3 >= b)
																						{
																							goto IL_02d2;
																						}
																						num = 22;
																						goto IL_0372;
																						IL_02d2:
																						if (3 > b)
																						{
																							goto IL_02dd;
																						}
																						goto IL_0351;
																						IL_02dd:
																						if (1 < b)
																						{
																							goto IL_02eb;
																						}
																						goto IL_054c;
																						IL_02eb:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_02f9;
																						IL_02f9:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_0307;
																						IL_0307:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0330;
																						IL_0330:
																						ptr2 += 8;
																						goto IL_033e;
																						IL_033e:
																						num5--;
																						goto end_IL_02ab;
																						IL_054c:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_055a;
																						IL_055a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0573;
																						IL_0573:
																						array[num5] = 0;
																						goto IL_0581;
																						IL_0581:
																						num5++;
																						goto IL_058f;
																						IL_058f:
																						ptr2 += 8;
																						goto end_IL_02ab;
																						IL_0351:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_02ab;
																						IL_0522:
																						num5++;
																						goto IL_0530;
																						IL_0372:
																						if (4 >= b)
																						{
																							goto IL_037d;
																						}
																						goto IL_0399;
																						IL_037d:
																						if (4 > b)
																						{
																							break;
																						}
																						num = 64;
																						goto end_IL_02ab;
																						IL_0530:
																						ptr2 += 8;
																						num = 109;
																						goto end_IL_02ab;
																						IL_0399:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_03a7;
																						IL_03a7:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_03b5;
																						IL_03b5:
																						array[num5] = 0;
																						num = 111;
																						goto IL_04f5;
																						IL_04f5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0518;
																					}
																					break;
																				}
																				goto IL_03d1;
																				IL_04d4:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_03d1:
																				if (9 >= b)
																				{
																					goto IL_03df;
																				}
																				goto IL_0489;
																				IL_03df:
																				if (9 > b)
																				{
																					goto IL_03ea;
																				}
																				goto IL_040b;
																				IL_03ea:
																				if (7 >= b)
																				{
																					goto IL_03f8;
																				}
																				goto IL_0609;
																				IL_03f8:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05a2;
																				IL_05a2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05e2;
																				IL_05e2:
																				array[num5 - 2] = 0;
																				goto IL_05f6;
																				IL_05f6:
																				num5--;
																				goto end_IL_02ab;
																				IL_0609:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0614;
																				IL_0614:
																				if (8 > b)
																				{
																					num = 32;
																					break;
																				}
																				goto IL_061f;
																				IL_061f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0642;
																				IL_0642:
																				array[num5] = 0;
																				goto IL_0650;
																				IL_0650:
																				num5++;
																				goto IL_065e;
																				IL_065e:
																				ptr2 += 8;
																				goto end_IL_02ab;
																				IL_04c9:
																				if (11 < b)
																				{
																					num = 27;
																					break;
																				}
																				goto IL_04d4;
																				IL_040b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 39;
																				goto IL_0476;
																				IL_0476:
																				num5 -= 2;
																				goto end_IL_02ab;
																				IL_0489:
																				if (10 >= b)
																				{
																					goto IL_0494;
																				}
																				goto IL_04c9;
																				IL_0494:
																				if (10 > b)
																				{
																					num = 6;
																					break;
																				}
																				goto IL_049f;
																				IL_049f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02ab;
																			}
																		}
																		else
																		{
																			num = 89;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02ab;
																continue;
																end_IL_028b:
																break;
															}
															continue;
															end_IL_029b:
															break;
														}
														continue;
														end_IL_02ab:
														break;
													}
													continue;
												}
												goto IL_074f;
												IL_074f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06b7:
												break;
											}
											continue;
											end_IL_06ca:
											break;
										}
										continue;
										end_IL_06d4:
										break;
									}
									continue;
									end_IL_06df:
									break;
								}
								continue;
								end_IL_06f4:
								break;
							}
							continue;
							end_IL_0704:
							break;
						}
						continue;
						end_IL_0714:
						break;
					}
					continue;
					end_IL_0724:
					break;
				}
				continue;
				end_IL_0734:
				break;
			}
		}
	}

	private unsafe static int smethod_12(int int_2)
	{
		int num = 35;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InstanceTan.StringTypeAppendChar);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 30;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0229:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_020c:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_01ff:
																						if (8 < b)
																						{
																							while (true)
																							{
																								IL_01ef:
																								if (9 >= b)
																								{
																									while (true)
																									{
																										IL_01dc:
																										if (9 > b)
																										{
																											num = 107;
																											while (num != 107)
																											{
																												if (num != 1088)
																												{
																													goto IL_04b9;
																												}
																												switch (num)
																												{
																												case 98:
																													goto IL_01dc;
																												case 16:
																													goto IL_01ef;
																												case 96:
																													goto IL_01ff;
																												case 7:
																													goto IL_020c;
																												case 26:
																													goto IL_0219;
																												case 70:
																													goto IL_0229;
																												case 9:
																													goto end_IL_0229;
																												case 2:
																												case 54:
																													goto end_IL_0239;
																												case 24:
																													goto IL_0254;
																												case 31:
																													goto IL_0262;
																												case 27:
																													goto IL_0270;
																												case 55:
																													goto IL_0280;
																												case 53:
																													goto IL_028b;
																												case 41:
																												case 71:
																													goto IL_029b;
																												case 62:
																													goto IL_02a9;
																												case 37:
																												case 74:
																													goto IL_02bc;
																												case 12:
																												case 76:
																													goto IL_02cf;
																												case 46:
																													goto IL_0331;
																												case 19:
																												case 80:
																													goto IL_0344;
																												case 49:
																													goto IL_0352;
																												case 44:
																													goto IL_0375;
																												case 78:
																													goto IL_037f;
																												case 13:
																													goto IL_038d;
																												case 87:
																													goto IL_03a0;
																												case 58:
																												case 75:
																													goto IL_03ae;
																												case 69:
																													goto IL_03ee;
																												case 81:
																													goto IL_0402;
																												case 88:
																													goto IL_0415;
																												case 6:
																													goto IL_0420;
																												case 3:
																													goto IL_042e;
																												case 0:
																												case 21:
																													goto IL_044a;
																												case 4:
																												case 89:
																													goto IL_0478;
																												case 66:
																													goto IL_048f;
																												case 91:
																													goto IL_04a2;
																												case 36:
																												case 67:
																													goto IL_04b9;
																												case 86:
																												case 92:
																													goto IL_04d1;
																												case 8:
																												case 93:
																													goto IL_04ed;
																												case 63:
																													goto IL_0506;
																												case 11:
																													goto IL_0514;
																												case 15:
																													goto IL_0522;
																												case 94:
																													goto IL_0535;
																												case 77:
																													goto IL_0543;
																												case 95:
																													goto IL_0553;
																												case 14:
																												case 40:
																													goto IL_055e;
																												case 50:
																													goto IL_0581;
																												case 59:
																													goto IL_058f;
																												case 23:
																													goto IL_059d;
																												case 10:
																												case 20:
																												case 32:
																												case 38:
																												case 39:
																												case 42:
																												case 43:
																												case 45:
																												case 48:
																												case 56:
																												case 57:
																												case 60:
																												case 79:
																												case 82:
																												case 83:
																												case 100:
																													goto end_IL_01c9;
																												case 1:
																												case 22:
																												case 28:
																												case 30:
																												case 51:
																												case 64:
																												case 65:
																												case 72:
																												case 73:
																												case 84:
																												case 85:
																												case 99:
																													goto end_IL_0249;
																												case 17:
																													goto end_IL_05c0;
																												case 68:
																													goto end_IL_05d3;
																												case 52:
																													goto end_IL_05de;
																												case 5:
																													goto end_IL_05e8;
																												case 47:
																													goto end_IL_05f3;
																												case 25:
																												case 29:
																													goto end_IL_0608;
																												case 90:
																													goto end_IL_0618;
																												case 18:
																												case 97:
																													goto end_IL_0628;
																												case 34:
																													goto end_IL_0638;
																												case 35:
																													goto end_IL_0648;
																												case 33:
																												case 61:
																													goto IL_0663;
																												}
																												continue;
																												end_IL_01c9:
																												break;
																											}
																											break;
																										}
																										goto IL_04d1;
																										IL_04d1:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										goto end_IL_0249;
																									}
																									break;
																								}
																								goto IL_0478;
																								IL_048f:
																								if (10 > b)
																								{
																								}
																								break;
																								IL_0478:
																								if (10 < b)
																								{
																									break;
																								}
																								num = 66;
																								goto IL_048f;
																							}
																							break;
																						}
																						goto IL_0280;
																						IL_0331:
																						num6 -= 2;
																						goto end_IL_0249;
																						IL_0280:
																						if (8 > b)
																						{
																							goto IL_028b;
																						}
																						goto IL_02cf;
																						IL_028b:
																						if (6 < b)
																						{
																							goto IL_02bc;
																						}
																						goto IL_03a0;
																						IL_02bc:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0553;
																						IL_0553:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_055e;
																						IL_055e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0581;
																						IL_0581:
																						array[num6] = 0;
																						goto IL_058f;
																						IL_058f:
																						num6++;
																						goto IL_059d;
																						IL_059d:
																						ptr2 += 8;
																						goto end_IL_0249;
																						IL_03a0:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_03ae;
																						IL_03ae:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_03ee;
																						IL_03ee:
																						array[num6 - 2] = 0;
																						goto IL_0402;
																						IL_0402:
																						num6--;
																						goto end_IL_0249;
																						IL_02cf:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0331;
																					}
																					break;
																				}
																				goto IL_0254;
																				IL_0375:
																				array2[num6] = null;
																				goto IL_037f;
																				IL_0254:
																				if (5 > b)
																				{
																					goto IL_0262;
																				}
																				goto IL_0344;
																				IL_0262:
																				if (2 < b)
																				{
																					goto IL_0270;
																				}
																				goto IL_0415;
																				IL_0270:
																				if (3 < b)
																				{
																					goto IL_029b;
																				}
																				goto IL_04a2;
																				IL_029b:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_02a9;
																				IL_02a9:
																				if (4 <= b)
																				{
																					goto end_IL_0249;
																				}
																				break;
																				IL_04a2:
																				if (3 > b)
																				{
																					break;
																				}
																				num = 36;
																				goto IL_04b9;
																				IL_037f:
																				num6++;
																				goto IL_038d;
																				IL_04b9:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0249;
																				IL_0415:
																				if (2 > b)
																				{
																					goto IL_0420;
																				}
																				num = 21;
																				goto IL_044a;
																				IL_0420:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_042e;
																				IL_042e:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_04ed;
																				IL_04ed:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0506;
																				IL_0506:
																				array[num6] = 0;
																				goto IL_0514;
																				IL_0514:
																				num6++;
																				goto IL_0522;
																				IL_0522:
																				ptr2 += 8;
																				goto end_IL_0249;
																				IL_038d:
																				ptr2 += 8;
																				goto end_IL_0249;
																				IL_044a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0535;
																				IL_0535:
																				ptr2 += 8;
																				goto IL_0543;
																				IL_0543:
																				num6--;
																				goto end_IL_0249;
																				IL_0344:
																				array[num6] = 0;
																				goto IL_0352;
																				IL_0352:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0375;
																			}
																			break;
																			IL_0219:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0249;
																	continue;
																	end_IL_0229:
																	break;
																}
																continue;
																end_IL_0239:
																break;
															}
															continue;
															end_IL_0249:
															break;
														}
														continue;
													}
													goto IL_0663;
													IL_0663:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_05c0:
													break;
												}
												continue;
												end_IL_05d3:
												break;
											}
											continue;
											end_IL_05de:
											break;
										}
										continue;
										end_IL_05e8:
										break;
									}
									continue;
									end_IL_05f3:
									break;
								}
								continue;
								end_IL_0608:
								break;
							}
							continue;
							end_IL_0618:
							break;
						}
						continue;
						end_IL_0628:
						break;
					}
					continue;
					end_IL_0638:
					break;
				}
				continue;
				end_IL_0648:
				break;
			}
		}
	}

	private unsafe static int smethod_13(int int_2)
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ThrowExceptionApplicationSecurityInfo.wTypeFlagsgetBackgroundColor);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0274:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0254:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0244:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0234:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0224:
																									if (7 >= b)
																									{
																										while (true)
																										{
																											IL_0214:
																											if (7 > b)
																											{
																												num = 121;
																												while (num != 121)
																												{
																													if (num != 1102)
																													{
																														goto IL_04d1;
																													}
																													switch (num)
																													{
																													case 62:
																														goto IL_0214;
																													case 13:
																													case 109:
																														goto IL_0224;
																													case 29:
																														goto IL_0234;
																													case 95:
																													case 104:
																														goto IL_0244;
																													case 1:
																														goto IL_0254;
																													case 85:
																														goto IL_0264;
																													case 30:
																														goto IL_0274;
																													case 45:
																														goto end_IL_0274;
																													case 10:
																													case 23:
																														goto end_IL_0284;
																													case 36:
																													case 38:
																														goto IL_029f;
																													case 14:
																														goto IL_02df;
																													case 40:
																														goto IL_02f3;
																													case 41:
																														goto IL_0306;
																													case 52:
																														goto IL_0314;
																													case 68:
																													case 79:
																														goto IL_0322;
																													case 43:
																														goto IL_034e;
																													case 70:
																														goto IL_035c;
																													case 32:
																														goto IL_0373;
																													case 59:
																													case 88:
																														goto IL_0386;
																													case 12:
																														goto IL_03e8;
																													case 102:
																														goto IL_03fb;
																													case 93:
																														goto IL_0406;
																													case 69:
																													case 105:
																														goto IL_0414;
																													case 8:
																														goto IL_0430;
																													case 75:
																														goto IL_043e;
																													case 64:
																														goto IL_0451;
																													case 73:
																													case 106:
																														goto IL_045c;
																													case 67:
																														goto IL_049c;
																													case 55:
																														goto IL_04b0;
																													case 53:
																														goto IL_04c3;
																													case 4:
																														goto IL_04d1;
																													case 46:
																													case 63:
																														goto IL_04dc;
																													case 48:
																														goto IL_04ea;
																													case 37:
																													case 66:
																														goto IL_04f8;
																													case 21:
																														goto IL_0506;
																													case 61:
																														goto IL_0529;
																													case 49:
																														goto IL_0533;
																													case 78:
																														goto IL_0541;
																													case 44:
																														goto IL_0554;
																													case 76:
																														goto IL_0570;
																													case 87:
																														goto IL_057e;
																													case 99:
																													case 112:
																														goto IL_0589;
																													case 111:
																														goto IL_0597;
																													case 7:
																													case 84:
																														goto IL_05a5;
																													case 31:
																														goto IL_05d7;
																													case 0:
																														goto IL_05e5;
																													case 83:
																														goto IL_05f8;
																													case 9:
																													case 82:
																														goto IL_0603;
																													case 6:
																														goto IL_061c;
																													case 81:
																														goto IL_0633;
																													case 97:
																														goto IL_0641;
																													case 107:
																													case 113:
																														goto IL_065a;
																													case 3:
																													case 18:
																													case 24:
																													case 25:
																													case 28:
																													case 34:
																													case 35:
																													case 42:
																													case 47:
																													case 50:
																													case 56:
																													case 60:
																													case 74:
																													case 86:
																													case 90:
																													case 91:
																													case 92:
																													case 94:
																													case 96:
																													case 98:
																													case 100:
																													case 114:
																														goto end_IL_0201;
																													case 15:
																													case 16:
																													case 17:
																													case 27:
																													case 33:
																													case 58:
																													case 65:
																													case 71:
																													case 72:
																													case 77:
																													case 80:
																													case 101:
																													case 103:
																													case 108:
																														goto end_IL_0294;
																													case 11:
																														goto end_IL_0682;
																													case 22:
																														goto end_IL_0695;
																													case 51:
																														goto end_IL_069f;
																													case 54:
																														goto end_IL_06aa;
																													case 5:
																													case 39:
																														goto end_IL_06bf;
																													case 110:
																														goto end_IL_06cf;
																													case 57:
																													case 89:
																														goto end_IL_06df;
																													case 19:
																														goto end_IL_06ef;
																													case 20:
																														goto end_IL_06ff;
																													case 2:
																													case 26:
																														goto IL_071a;
																													}
																													continue;
																													end_IL_0201:
																													break;
																												}
																												break;
																											}
																											goto IL_029f;
																											IL_02df:
																											array[num5 - 2] = 0;
																											goto IL_02f3;
																											IL_02f3:
																											num5--;
																											goto end_IL_0294;
																											IL_029f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_02df;
																										}
																										break;
																									}
																									goto IL_0306;
																									IL_0373:
																									ptr2 += 8;
																									goto end_IL_0294;
																									IL_0306:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_0314;
																									IL_0314:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_0322;
																									IL_0322:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									num = 43;
																									goto IL_034e;
																									IL_034e:
																									array[num5] = 0;
																									goto IL_035c;
																									IL_035c:
																									num5++;
																									num = 32;
																									goto IL_0373;
																								}
																								break;
																							}
																							goto IL_0386;
																							IL_03e8:
																							num5 -= 2;
																							goto end_IL_0294;
																							IL_0386:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03e8;
																						}
																						break;
																					}
																					goto IL_03fb;
																					IL_043e:
																					if (11 > b)
																					{
																					}
																					break;
																					IL_03fb:
																					if (10 >= b)
																					{
																						goto IL_0406;
																					}
																					goto IL_0430;
																					IL_0406:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0414;
																					IL_0414:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0294;
																					IL_0430:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_043e;
																				}
																				break;
																			}
																			goto IL_0451;
																			IL_0641:
																			ptr2 += 8;
																			goto end_IL_0294;
																			IL_0451:
																			if (6 <= b)
																			{
																				goto IL_045c;
																			}
																			goto IL_04c3;
																			IL_045c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_049c;
																			IL_049c:
																			array[num5 - 2] = 0;
																			goto IL_04b0;
																			IL_04b0:
																			num5--;
																			goto end_IL_0294;
																			IL_04c3:
																			if (3 < b)
																			{
																				goto IL_04d1;
																			}
																			goto IL_0570;
																			IL_04d1:
																			if (4 < b)
																			{
																				goto IL_04dc;
																			}
																			goto IL_0554;
																			IL_04dc:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_04ea;
																			IL_04ea:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_04f8;
																			IL_04f8:
																			array[num5] = 0;
																			goto IL_0506;
																			IL_0506:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0529;
																			IL_0529:
																			array2[num5] = null;
																			goto IL_0533;
																			IL_0533:
																			num5++;
																			goto IL_0541;
																			IL_0541:
																			ptr2 += 8;
																			goto end_IL_0294;
																			IL_0554:
																			if (4 <= b)
																			{
																				goto end_IL_0294;
																			}
																			num = 90;
																			break;
																			IL_065a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0294;
																			IL_0570:
																			if (3 > b)
																			{
																				goto IL_057e;
																			}
																			num = 107;
																			goto IL_065a;
																			IL_057e:
																			if (1 < b)
																			{
																				goto IL_0589;
																			}
																			goto IL_05f8;
																			IL_0589:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0597;
																			IL_0597:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_05a5;
																			IL_05a5:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 31;
																			goto IL_05d7;
																			IL_05d7:
																			ptr2 += 8;
																			goto IL_05e5;
																			IL_05e5:
																			num5--;
																			goto end_IL_0294;
																			IL_05f8:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0603;
																			IL_0603:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_061c;
																			IL_061c:
																			array[num5] = 0;
																			num = 81;
																			goto IL_0633;
																			IL_0633:
																			num5++;
																			goto IL_0641;
																		}
																		break;
																		IL_0264:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0294;
																continue;
																end_IL_0274:
																break;
															}
															continue;
															end_IL_0284:
															break;
														}
														continue;
														end_IL_0294:
														break;
													}
													continue;
												}
												goto IL_071a;
												IL_071a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0682:
												break;
											}
											continue;
											end_IL_0695:
											break;
										}
										continue;
										end_IL_069f:
										break;
									}
									continue;
									end_IL_06aa:
									break;
								}
								continue;
								end_IL_06bf:
								break;
							}
							continue;
							end_IL_06cf:
							break;
						}
						continue;
						end_IL_06df:
						break;
					}
					continue;
					end_IL_06ef:
					break;
				}
				continue;
				end_IL_06ff:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_2, int int_3)
	{
		int num = 9;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 25;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 95;
								while (true)
								{
									int[] array3 = new int[5];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											IL_021f:
											array3[0] = int_2;
											while (true)
											{
												IL_020a:
												array3[1] = int_3;
												while (true)
												{
													IL_01ff:
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TaskStatusSpinLock.BuiltInPermissionSetsIEquatable);
													while (true)
													{
														IL_01f5:
														byte* ptr2 = ptr;
														while (true)
														{
															IL_01ea:
															num = 114;
															while (true)
															{
																if (num != 114)
																{
																	if (num != 1095)
																	{
																		break;
																	}
																	switch (num)
																	{
																	case 62:
																		goto IL_01ea;
																	case 74:
																		goto IL_01f5;
																	case 68:
																		goto IL_01ff;
																	case 99:
																		goto IL_020a;
																	case 22:
																		goto IL_021f;
																	case 52:
																		goto end_IL_01d7;
																	case 95:
																		goto end_IL_0234;
																	case 86:
																		goto end_IL_0244;
																	case 2:
																		goto end_IL_0254;
																	case 25:
																		goto end_IL_025f;
																	case 107:
																		goto end_IL_026f;
																	case 8:
																		goto end_IL_027f;
																	case 9:
																		goto end_IL_028a;
																	case 7:
																	case 15:
																	case 30:
																	case 31:
																	case 37:
																	case 45:
																	case 46:
																	case 82:
																	case 106:
																		goto IL_02a5;
																	case 21:
																	case 88:
																		goto IL_02b5;
																	case 105:
																		goto IL_02be;
																	case 1:
																		goto IL_02cc;
																	case 3:
																		goto IL_02da;
																	case 78:
																		goto IL_02f3;
																	case 19:
																		goto IL_0301;
																	case 23:
																	case 38:
																		goto IL_030c;
																	case 47:
																		goto IL_031a;
																	case 67:
																		goto IL_033d;
																	case 11:
																		goto IL_0347;
																	case 80:
																		goto IL_0355;
																	case 5:
																	case 104:
																		goto IL_0368;
																	case 28:
																	case 73:
																		goto IL_0376;
																	case 71:
																		goto IL_0381;
																	case 27:
																	case 34:
																		goto IL_038f;
																	case 89:
																		goto IL_03b8;
																	case 79:
																		goto IL_03cf;
																	case 44:
																		goto IL_03e2;
																	case 43:
																		goto IL_03f0;
																	case 0:
																	case 20:
																		goto IL_03fe;
																	case 93:
																		goto IL_043e;
																	case 18:
																		goto IL_0452;
																	case 77:
																		goto IL_0465;
																	case 41:
																	case 92:
																		goto IL_0470;
																	case 36:
																		goto IL_047e;
																	case 33:
																	case 55:
																		goto IL_0491;
																	case 98:
																		goto IL_04d1;
																	case 103:
																		goto IL_04e5;
																	case 42:
																		goto IL_04f8;
																	case 100:
																		goto IL_0506;
																	case 6:
																	case 13:
																		goto IL_0511;
																	case 85:
																		goto IL_052a;
																	case 53:
																		goto IL_0538;
																	case 26:
																		goto IL_0546;
																	case 83:
																		goto IL_0559;
																	case 97:
																		goto IL_0567;
																	case 56:
																	case 94:
																		goto IL_0575;
																	case 75:
																		goto IL_05b5;
																	case 69:
																		goto IL_05c9;
																	case 87:
																		goto IL_05dc;
																	case 24:
																	case 49:
																		goto IL_05e7;
																	case 90:
																		goto IL_05f5;
																	case 59:
																	case 61:
																		goto IL_0603;
																	case 39:
																		goto IL_061f;
																	case 54:
																	case 64:
																		goto IL_062d;
																	case 50:
																		goto IL_066d;
																	case 12:
																		goto IL_0681;
																	case 70:
																		goto IL_0694;
																	case 76:
																		goto IL_06a2;
																	case 81:
																		goto IL_06b0;
																	case 10:
																	case 14:
																	case 16:
																	case 17:
																	case 29:
																	case 32:
																	case 35:
																	case 40:
																	case 48:
																	case 51:
																	case 57:
																	case 58:
																	case 60:
																	case 63:
																	case 66:
																	case 72:
																	case 84:
																	case 91:
																	case 96:
																	case 101:
																	case 102:
																		goto IL_06c3;
																	case 4:
																	case 65:
																		goto IL_06e8;
																	}
																	continue;
																}
																goto IL_02a5;
																IL_0694:
																array[num4] = 0;
																goto IL_06a2;
																IL_06a2:
																num4++;
																goto IL_06b0;
																IL_02a5:
																if (num5 != 1)
																{
																	goto IL_02b5;
																}
																goto IL_06e8;
																IL_06e8:
																return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
																IL_02b5:
																b = *ptr2;
																goto IL_02be;
																IL_02be:
																ptr2++;
																goto IL_02cc;
																IL_02cc:
																if (b >= 1)
																{
																	goto IL_02da;
																}
																goto IL_06c3;
																IL_02da:
																if (b <= 9)
																{
																	goto IL_02f3;
																}
																num = 72;
																goto IL_06c3;
																IL_06b0:
																ptr2 += 8;
																goto IL_02a5;
																IL_02f3:
																if (5 >= b)
																{
																	goto IL_0301;
																}
																goto IL_04f8;
																IL_0301:
																if (5 <= b)
																{
																	goto IL_030c;
																}
																goto IL_0368;
																IL_030c:
																array[num4] = 0;
																goto IL_031a;
																IL_031a:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
																goto IL_033d;
																IL_033d:
																array2[num4] = null;
																goto IL_0347;
																IL_0347:
																num4++;
																goto IL_0355;
																IL_0355:
																ptr2 += 8;
																goto IL_02a5;
																IL_0368:
																if (2 < b)
																{
																	goto IL_0376;
																}
																goto IL_0465;
																IL_0376:
																if (3 >= b)
																{
																	goto IL_0381;
																}
																goto IL_03e2;
																IL_0381:
																if (3 <= b)
																{
																	goto IL_038f;
																}
																goto IL_06c3;
																IL_038f:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
																goto IL_03b8;
																IL_03b8:
																ptr2 += 8;
																num = 79;
																goto IL_03cf;
																IL_03cf:
																num4--;
																goto IL_02a5;
																IL_03e2:
																if (4 >= b)
																{
																	goto IL_03f0;
																}
																goto IL_06c3;
																IL_03f0:
																if (4 <= b)
																{
																	goto IL_03fe;
																}
																goto IL_06c3;
																IL_03fe:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
																goto IL_043e;
																IL_043e:
																array[num4 - 2] = 0;
																goto IL_0452;
																IL_0452:
																num4--;
																goto IL_02a5;
																IL_0465:
																if (2 > b)
																{
																	goto IL_0470;
																}
																goto IL_0491;
																IL_0470:
																if (1 >= b)
																{
																	goto IL_047e;
																}
																goto IL_06c3;
																IL_047e:
																if (1 <= b)
																{
																}
																goto IL_06c3;
																IL_0491:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
																goto IL_04d1;
																IL_04d1:
																array[num4 - 2] = 0;
																goto IL_04e5;
																IL_04e5:
																num4--;
																goto IL_02a5;
																IL_04f8:
																if (7 >= b)
																{
																	goto IL_0506;
																}
																goto IL_05dc;
																IL_0506:
																if (7 <= b)
																{
																	goto IL_0511;
																}
																goto IL_0559;
																IL_0511:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
																goto IL_052a;
																IL_052a:
																array[num4] = 0;
																goto IL_0538;
																IL_0538:
																num4++;
																goto IL_0546;
																IL_0546:
																ptr2 += 8;
																goto IL_02a5;
																IL_0559:
																if (6 >= b)
																{
																	goto IL_0567;
																}
																goto IL_06c3;
																IL_0567:
																if (6 <= b)
																{
																	goto IL_0575;
																}
																goto IL_06c3;
																IL_0575:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
																goto IL_05b5;
																IL_05b5:
																array[num4 - 2] = 0;
																goto IL_05c9;
																IL_05c9:
																num4--;
																goto IL_02a5;
																IL_05dc:
																if (8 < b)
																{
																	goto IL_05e7;
																}
																goto IL_061f;
																IL_05e7:
																if (9 >= b)
																{
																	goto IL_05f5;
																}
																goto IL_06c3;
																IL_05f5:
																if (9 <= b)
																{
																	goto IL_0603;
																}
																goto IL_06c3;
																IL_0603:
																byte* num6 = ptr2;
																num5 = 1;
																ptr2 = num6 + -200;
																goto IL_02a5;
																IL_061f:
																if (8 <= b)
																{
																	goto IL_062d;
																}
																goto IL_06c3;
																IL_062d:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
																goto IL_066d;
																IL_066d:
																array[num4 - 2] = 0;
																goto IL_0681;
																IL_0681:
																num4--;
																goto IL_02a5;
																IL_06c3:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0694;
																continue;
																end_IL_01d7:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										continue;
										end_IL_0234:
										break;
									}
									continue;
									end_IL_0244:
									break;
								}
								continue;
								end_IL_0254:
								break;
							}
							continue;
							end_IL_025f:
							break;
						}
						continue;
						end_IL_026f:
						break;
					}
					continue;
					end_IL_027f:
					break;
				}
				continue;
				end_IL_028a:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_2, int int_3)
	{
		int num = 110;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentEraGetValues.ThreadTransferEditAndContinueHelper);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0324:
															byte b = *ptr2;
															while (true)
															{
																IL_0314:
																ptr2++;
																while (true)
																{
																	IL_0304:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02e4:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02d4:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_02c7:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_02b7:
																										if (11 > b)
																										{
																											while (10 >= b)
																											{
																												while (10 <= b)
																												{
																													while (true)
																													{
																														IL_0281:
																														array[num5 - 1] = 0;
																														while (true)
																														{
																															IL_0237:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SecurityPermissionSecurityLogonType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																															num = 115;
																															while (true)
																															{
																																IL_021e:
																																ptr2 += 8;
																																num = 127;
																																while (num != 127)
																																{
																																	if (num != 1108)
																																	{
																																		goto end_IL_0297;
																																	}
																																	switch (num)
																																	{
																																	case 115:
																																		goto IL_021e;
																																	case 119:
																																		goto IL_0237;
																																	case 52:
																																	case 78:
																																		goto IL_0281;
																																	case 67:
																																		goto IL_0297;
																																	case 7:
																																		goto IL_02a7;
																																	case 45:
																																		goto IL_02b7;
																																	case 81:
																																	case 107:
																																		goto IL_02c7;
																																	case 6:
																																	case 48:
																																		goto IL_02d4;
																																	case 72:
																																		goto IL_02e4;
																																	case 4:
																																		goto IL_02f4;
																																	case 89:
																																		goto IL_0304;
																																	case 59:
																																		goto IL_0314;
																																	case 22:
																																	case 44:
																																		goto IL_0324;
																																	case 13:
																																	case 33:
																																		goto IL_032f;
																																	case 42:
																																	case 98:
																																		goto IL_0348;
																																	case 111:
																																		goto IL_035b;
																																	case 73:
																																	case 100:
																																		goto IL_0369;
																																	case 40:
																																		goto IL_0385;
																																	case 84:
																																		goto IL_0393;
																																	case 71:
																																		goto IL_039e;
																																	case 46:
																																	case 92:
																																		goto IL_03ac;
																																	case 56:
																																		goto IL_03ba;
																																	case 86:
																																		goto IL_03dd;
																																	case 32:
																																		goto IL_03e7;
																																	case 2:
																																		goto IL_03f5;
																																	case 95:
																																		goto IL_0408;
																																	case 30:
																																		goto IL_041f;
																																	case 62:
																																	case 79:
																																		goto IL_042d;
																																	case 87:
																																		goto IL_0446;
																																	case 36:
																																		goto IL_0454;
																																	case 20:
																																		goto IL_0462;
																																	case 49:
																																	case 113:
																																		goto IL_0475;
																																	case 96:
																																		goto IL_04b5;
																																	case 57:
																																		goto IL_04c9;
																																	case 80:
																																		goto IL_04dc;
																																	case 10:
																																		goto IL_04ea;
																																	case 37:
																																		goto IL_04f8;
																																	case 12:
																																		goto IL_0503;
																																	case 82:
																																		goto IL_0511;
																																	case 41:
																																	case 101:
																																		goto IL_051f;
																																	case 99:
																																		goto IL_0540;
																																	case 19:
																																	case 102:
																																		goto IL_054e;
																																	case 0:
																																		goto IL_0577;
																																	case 91:
																																		goto IL_0585;
																																	case 112:
																																		goto IL_0598;
																																	case 11:
																																	case 29:
																																		goto IL_05a3;
																																	case 21:
																																		goto IL_05e3;
																																	case 54:
																																		goto IL_05f7;
																																	case 5:
																																		goto IL_060a;
																																	case 47:
																																	case 90:
																																		goto IL_0618;
																																	case 120:
																																		goto IL_0626;
																																	case 60:
																																	case 74:
																																		goto IL_0634;
																																	case 64:
																																		goto IL_06a2;
																																	case 18:
																																		goto IL_06b2;
																																	case 3:
																																	case 15:
																																	case 17:
																																	case 24:
																																	case 28:
																																	case 31:
																																	case 34:
																																	case 35:
																																	case 50:
																																	case 51:
																																	case 55:
																																	case 61:
																																	case 65:
																																	case 75:
																																	case 77:
																																	case 85:
																																	case 88:
																																	case 93:
																																	case 104:
																																	case 105:
																																	case 106:
																																		goto end_IL_0297;
																																	case 83:
																																		goto IL_06e0;
																																	case 116:
																																		goto IL_06ee;
																																	case 70:
																																		goto IL_06fc;
																																	case 1:
																																	case 8:
																																	case 14:
																																	case 16:
																																	case 23:
																																	case 25:
																																	case 27:
																																	case 39:
																																	case 53:
																																	case 58:
																																	case 63:
																																	case 66:
																																	case 97:
																																	case 108:
																																		goto end_IL_020b;
																																	case 38:
																																		goto end_IL_070a;
																																	case 76:
																																		goto end_IL_071d;
																																	case 118:
																																		goto end_IL_0727;
																																	case 114:
																																		goto end_IL_0732;
																																	case 68:
																																		goto end_IL_0747;
																																	case 103:
																																	case 117:
																																		goto end_IL_075c;
																																	case 94:
																																		goto end_IL_076c;
																																	case 9:
																																	case 43:
																																		goto end_IL_077c;
																																	case 109:
																																		goto end_IL_078c;
																																	case 110:
																																		goto end_IL_079c;
																																	case 26:
																																	case 69:
																																		goto IL_07b7;
																																	}
																																	continue;
																																	end_IL_020b:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_0304;
																													continue;
																													end_IL_0297:
																													break;
																													IL_0297:;
																												}
																												break;
																												IL_02a7:;
																											}
																											break;
																										}
																										goto IL_0348;
																										IL_0348:
																										num5--;
																										goto end_IL_0304;
																									}
																									break;
																								}
																								goto IL_032f;
																								IL_035b:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_0369;
																								IL_032f:
																								if (12 < b)
																								{
																									num = 77;
																									break;
																								}
																								goto IL_035b;
																								IL_0369:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_0304;
																							}
																							break;
																						}
																						goto IL_0385;
																						IL_04b5:
																						array[num5 - 2] = 0;
																						goto IL_04c9;
																						IL_0385:
																						if (9 > b)
																						{
																							goto IL_0393;
																						}
																						goto IL_0475;
																						IL_0393:
																						if (7 >= b)
																						{
																							goto IL_039e;
																						}
																						goto IL_0408;
																						IL_039e:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_03ac;
																						IL_03ac:
																						array[num5] = 0;
																						goto IL_03ba;
																						IL_03ba:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03dd;
																						IL_03dd:
																						array2[num5] = null;
																						goto IL_03e7;
																						IL_03e7:
																						num5++;
																						goto IL_03f5;
																						IL_03f5:
																						ptr2 += 8;
																						goto end_IL_0304;
																						IL_0408:
																						if (8 < b)
																						{
																							break;
																						}
																						num = 30;
																						goto IL_041f;
																						IL_04c9:
																						num5--;
																						goto end_IL_0304;
																						IL_041f:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_042d;
																						IL_042d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0446;
																						IL_0446:
																						array[num5] = 0;
																						goto IL_0454;
																						IL_0454:
																						num5++;
																						goto IL_0462;
																						IL_0462:
																						ptr2 += 8;
																						goto end_IL_0304;
																						IL_0475:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04b5;
																					}
																					break;
																				}
																				goto IL_04dc;
																				IL_06b2:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_04dc:
																				if (6 <= b)
																				{
																					goto end_IL_0304;
																				}
																				goto IL_04ea;
																				IL_04ea:
																				if (3 < b)
																				{
																					goto IL_04f8;
																				}
																				goto IL_0598;
																				IL_04f8:
																				if (4 < b)
																				{
																					goto IL_0503;
																				}
																				goto IL_0540;
																				IL_0503:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0511;
																				IL_0511:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_051f;
																				IL_051f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 16;
																				goto end_IL_0304;
																				IL_0540:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_054e;
																				IL_054e:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0577;
																				IL_0577:
																				ptr2 += 8;
																				goto IL_0585;
																				IL_0585:
																				num5--;
																				goto end_IL_0304;
																				IL_0598:
																				if (3 <= b)
																				{
																					goto IL_05a3;
																				}
																				goto IL_060a;
																				IL_05a3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05e3;
																				IL_05e3:
																				array[num5 - 2] = 0;
																				goto IL_05f7;
																				IL_05f7:
																				num5--;
																				goto end_IL_0304;
																				IL_060a:
																				if (1 < b)
																				{
																					goto IL_0618;
																				}
																				goto IL_06b2;
																				IL_0618:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0626;
																				IL_0626:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0634;
																				IL_0634:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06a2;
																				IL_06a2:
																				num5 -= 2;
																				goto end_IL_0304;
																			}
																			break;
																			IL_02f4:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e0;
																	IL_06fc:
																	ptr2 += 8;
																	break;
																	IL_06ee:
																	num5++;
																	goto IL_06fc;
																	IL_06e0:
																	array[num5] = 0;
																	goto IL_06ee;
																	continue;
																	end_IL_0304:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07b7;
													IL_07b7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_070a:
													break;
												}
												continue;
												end_IL_071d:
												break;
											}
											continue;
											end_IL_0727:
											break;
										}
										continue;
										end_IL_0732:
										break;
									}
									continue;
									end_IL_0747:
									break;
								}
								continue;
								end_IL_075c:
								break;
							}
							continue;
							end_IL_076c:
							break;
						}
						continue;
						end_IL_077c:
						break;
					}
					continue;
					end_IL_078c:
					break;
				}
				continue;
				end_IL_079c:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_2, int int_3)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										num = 59;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RsaAnyAddResource.getCookiePercentPositivePattern);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 8;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0211:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01f4:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_01e7:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_01d7:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_01c7:
																											if (2 > b)
																											{
																												while (1 >= b)
																												{
																													num = 97;
																													while (true)
																													{
																														if (num != 97)
																														{
																															if (num != 1078)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 49:
																															case 61:
																																goto IL_01b4;
																															case 64:
																																goto IL_01c7;
																															case 16:
																															case 88:
																																goto end_IL_01a1;
																															case 30:
																																goto IL_01e7;
																															case 45:
																																goto IL_01f4;
																															case 4:
																																goto IL_0201;
																															case 34:
																																goto IL_0211;
																															case 24:
																																goto end_IL_0211;
																															case 3:
																															case 90:
																																goto end_IL_0221;
																															case 20:
																															case 35:
																																goto IL_023c;
																															case 26:
																															case 31:
																																goto IL_0247;
																															case 9:
																															case 40:
																																goto IL_0257;
																															case 43:
																																goto IL_0282;
																															case 27:
																																goto IL_0290;
																															case 19:
																																goto IL_029e;
																															case 52:
																																goto IL_02b1;
																															case 54:
																																goto IL_02c4;
																															case 5:
																															case 60:
																																goto IL_02d7;
																															case 63:
																																goto IL_0345;
																															case 66:
																																goto IL_0358;
																															case 68:
																																goto IL_0368;
																															case 69:
																																goto IL_0378;
																															case 51:
																															case 85:
																																goto IL_038b;
																															case 25:
																																goto IL_0399;
																															case 21:
																																goto IL_03bc;
																															case 12:
																																goto IL_03c6;
																															case 80:
																																goto IL_03d4;
																															case 15:
																															case 86:
																																goto IL_03f0;
																															case 72:
																															case 89:
																																goto IL_040c;
																															case 36:
																																goto IL_0431;
																															case 70:
																																goto IL_043c;
																															case 58:
																															case 74:
																																goto IL_0447;
																															case 1:
																																goto IL_0487;
																															case 18:
																																goto IL_049b;
																															case 7:
																															case 13:
																															case 14:
																															case 23:
																															case 29:
																															case 39:
																															case 44:
																															case 46:
																															case 47:
																															case 48:
																															case 57:
																															case 62:
																															case 77:
																															case 78:
																															case 81:
																															case 82:
																															case 83:
																															case 84:
																																goto end_IL_01b4;
																															case 75:
																																goto IL_04ce;
																															case 56:
																																goto IL_04dc;
																															case 65:
																																goto IL_04ea;
																															case 2:
																															case 8:
																															case 10:
																															case 22:
																															case 28:
																															case 37:
																															case 38:
																															case 41:
																															case 53:
																															case 71:
																																goto end_IL_0231;
																															case 0:
																																goto end_IL_04f8;
																															case 67:
																																goto end_IL_050b;
																															case 59:
																																goto end_IL_0516;
																															case 73:
																																goto end_IL_0520;
																															case 11:
																																goto end_IL_052b;
																															case 6:
																																goto end_IL_0549;
																															case 42:
																															case 87:
																																goto end_IL_055e;
																															case 79:
																																goto end_IL_056e;
																															case 55:
																															case 76:
																																goto end_IL_057e;
																															case 32:
																																goto end_IL_058e;
																															case 33:
																																goto end_IL_059e;
																															case 17:
																															case 50:
																																goto IL_05c2;
																															}
																															continue;
																														}
																														if (1 <= b)
																														{
																														}
																														goto end_IL_01b4;
																														continue;
																														end_IL_01a1:
																														break;
																													}
																													goto IL_01d7;
																													continue;
																													end_IL_01b4:
																													break;
																													IL_01b4:;
																												}
																												break;
																											}
																											goto IL_02d7;
																											IL_0345:
																											num5 -= 2;
																											goto end_IL_0231;
																											IL_02d7:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0345;
																										}
																										break;
																									}
																									goto IL_0431;
																									IL_049b:
																									num5--;
																									goto end_IL_0231;
																									IL_0431:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_043c;
																									IL_043c:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0447;
																									IL_0447:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0487;
																									IL_0487:
																									array[num5 - 2] = 0;
																									goto IL_049b;
																								}
																								break;
																							}
																							goto IL_0257;
																							IL_0378:
																							num5--;
																							goto end_IL_0231;
																							IL_0257:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_02c4;
																							IL_02c4:
																							ptr2 += 8;
																							goto IL_0378;
																						}
																						break;
																					}
																					goto IL_023c;
																					IL_040c:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0231;
																					IL_023c:
																					if (6 < b)
																					{
																						goto IL_0247;
																					}
																					goto IL_0282;
																					IL_0247:
																					if (7 < b)
																					{
																						goto IL_02b1;
																					}
																					goto IL_0358;
																					IL_0358:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_038b;
																					IL_038b:
																					array[num5] = 0;
																					goto IL_0399;
																					IL_0399:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03bc;
																					IL_03bc:
																					array2[num5] = null;
																					goto IL_03c6;
																					IL_03c6:
																					num5++;
																					goto IL_03d4;
																					IL_03d4:
																					ptr2 += 8;
																					num = 28;
																					goto end_IL_0231;
																					IL_02b1:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0368;
																					IL_0368:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_03f0;
																					IL_03f0:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0231;
																					IL_0282:
																					if (6 <= b)
																					{
																						goto end_IL_0231;
																					}
																					goto IL_0290;
																					IL_0290:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_029e;
																					IL_029e:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_040c;
																				}
																				break;
																				IL_0201:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04ce;
																		IL_04ea:
																		ptr2 += 8;
																		goto end_IL_0231;
																		IL_04dc:
																		num5++;
																		goto IL_04ea;
																		IL_04ce:
																		array[num5] = 0;
																		goto IL_04dc;
																		continue;
																		end_IL_0211:
																		break;
																	}
																	continue;
																	end_IL_0221:
																	break;
																}
																continue;
																end_IL_0231:
																break;
															}
															continue;
														}
														num = 17;
														goto IL_05c2;
														IL_05c2:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04f8:
														break;
													}
													continue;
													end_IL_050b:
													break;
												}
												continue;
												end_IL_0516:
												break;
											}
											continue;
											end_IL_0520:
											break;
										}
										continue;
										end_IL_052b:
										break;
									}
									continue;
									end_IL_0549:
									break;
								}
								continue;
								end_IL_055e:
								break;
							}
							continue;
							end_IL_056e:
							break;
						}
						continue;
						end_IL_057e:
						break;
					}
					continue;
					end_IL_058e:
					break;
				}
				continue;
				end_IL_059e:
				break;
			}
		}
	}

	private static int smethod_17(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}
}
