using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

[HarmonyPatch(typeof(VRRig), "PostTick")]
internal class Class172
{
	private static float float_0;

	private static float float_1;

	private static bool bool_0;

	private static bool bool_1;

	private static float float_2;

	private static double double_0;

	private static IntPtr[] PrincipalPermissionStandardTaskContinuation;

	private static IntPtr[] MakeByRefTypeRandomlyGenerated;

	private static IntPtr[] CreationTimeUtcVARFLAGFUIDEFAULT;

	private static IntPtr[] getBestFitMappingFreeze;

	private static IntPtr[] FullDateTimePatternApplication;

	private unsafe static void Postfix(VRRig __instance)
	{
		int num = 221;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = __instance;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EndEntityImageFileMachine.GetRootObjectlpvarValue);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_0719:
														byte b = *ptr2;
														while (true)
														{
															IL_0709:
															ptr2++;
															while (true)
															{
																IL_06f9:
																if (b >= 1)
																{
																	while (b <= 38)
																	{
																		while (true)
																		{
																			IL_06d9:
																			if (19 >= b)
																			{
																				while (true)
																				{
																					IL_06cc:
																					if (19 > b)
																					{
																						while (true)
																						{
																							IL_06b9:
																							if (9 >= b)
																							{
																								num = 306;
																								while (true)
																								{
																									IL_06a9:
																									if (9 > b)
																									{
																										while (true)
																										{
																											IL_0699:
																											if (4 < b)
																											{
																												while (true)
																												{
																													IL_0689:
																													if (6 >= b)
																													{
																														while (true)
																														{
																															IL_0679:
																															if (6 <= b)
																															{
																																while (true)
																																{
																																	IL_0637:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																	while (true)
																																	{
																																		IL_0621:
																																		array[num5 - 2] = 0;
																																		while (true)
																																		{
																																			IL_0608:
																																			num5--;
																																			num = 374;
																																			while (num != 374)
																																			{
																																				if (num != 1355)
																																				{
																																					goto IL_0ded;
																																				}
																																				switch (num)
																																				{
																																				case 59:
																																					goto IL_0608;
																																				case 180:
																																					goto IL_0621;
																																				case 76:
																																				case 77:
																																					goto IL_0637;
																																				case 122:
																																					goto IL_0679;
																																				case 128:
																																				case 151:
																																					goto IL_0689;
																																				case 243:
																																					goto IL_0699;
																																				case 306:
																																					goto IL_06a9;
																																				case 354:
																																					goto IL_06b9;
																																				case 233:
																																					goto IL_06cc;
																																				case 207:
																																					goto IL_06d9;
																																				case 196:
																																					goto IL_06e9;
																																				case 32:
																																					goto IL_06f9;
																																				case 226:
																																					goto IL_0709;
																																				case 38:
																																				case 101:
																																					goto IL_0719;
																																				case 87:
																																				case 93:
																																					goto IL_0732;
																																				case 126:
																																					goto IL_0746;
																																				case 137:
																																					goto IL_079d;
																																				case 53:
																																				case 186:
																																					goto IL_07ab;
																																				case 168:
																																					goto IL_07b6;
																																				case 127:
																																				case 202:
																																					goto IL_07c9;
																																				case 219:
																																					goto IL_07e5;
																																				case 111:
																																				case 181:
																																					goto IL_07f0;
																																				case 178:
																																					goto IL_07fe;
																																				case 199:
																																					goto IL_0811;
																																				case 24:
																																				case 136:
																																					goto IL_081f;
																																				case 138:
																																					goto IL_0837;
																																				case 237:
																																					goto IL_084a;
																																				case 195:
																																					goto IL_0861;
																																				case 197:
																																				case 247:
																																					goto IL_0874;
																																				case 249:
																																					goto IL_0890;
																																				case 246:
																																				case 266:
																																					goto IL_089e;
																																				case 97:
																																				case 209:
																																					goto IL_08ac;
																																				case 259:
																																					goto IL_08b7;
																																				case 19:
																																					goto IL_08ca;
																																				case 148:
																																					goto IL_08d8;
																																				case 182:
																																				case 253:
																																					goto IL_08e6;
																																				case 152:
																																					goto IL_0938;
																																				case 73:
																																				case 276:
																																					goto IL_094b;
																																				case 16:
																																					goto IL_098b;
																																				case 107:
																																				case 287:
																																					goto IL_09a4;
																																				case 265:
																																					goto IL_09c8;
																																				case 95:
																																					goto IL_09d6;
																																				case 161:
																																					goto IL_09e4;
																																				case 293:
																																					goto IL_09f7;
																																				case 54:
																																				case 285:
																																					goto IL_0a05;
																																				case 305:
																																					goto IL_0a13;
																																				case 57:
																																				case 139:
																																					goto IL_0a21;
																																				case 39:
																																					goto IL_0a83;
																																				case 309:
																																					goto IL_0a96;
																																				case 310:
																																					goto IL_0aa9;
																																				case 23:
																																				case 160:
																																					goto IL_0ab7;
																																				case 112:
																																					goto IL_0af7;
																																				case 55:
																																					goto IL_0b0b;
																																				case 317:
																																					goto IL_0b1e;
																																				case 149:
																																				case 324:
																																					goto IL_0b37;
																																				case 124:
																																					goto IL_0b5b;
																																				case 213:
																																					goto IL_0b69;
																																				case 193:
																																					goto IL_0b77;
																																				case 325:
																																					goto IL_0b8a;
																																				case 75:
																																				case 353:
																																					goto IL_0b9d;
																																				case 82:
																																					goto IL_0bab;
																																				case 14:
																																				case 72:
																																					goto IL_0bb9;
																																				case 68:
																																					goto IL_0c17;
																																				case 22:
																																				case 361:
																																					goto IL_0c2a;
																																				case 90:
																																					goto IL_0c48;
																																				case 258:
																																					goto IL_0c56;
																																				case 224:
																																					goto IL_0c64;
																																				case 302:
																																				case 311:
																																					goto IL_0c77;
																																				case 257:
																																					goto IL_0c82;
																																				case 41:
																																				case 45:
																																					goto IL_0c90;
																																				case 235:
																																					goto IL_0cd0;
																																				case 63:
																																					goto IL_0ced;
																																				case 227:
																																					goto IL_0d00;
																																				case 120:
																																					goto IL_0d0e;
																																				case 51:
																																				case 208:
																																					goto IL_0d25;
																																				case 326:
																																					goto IL_0d38;
																																				case 110:
																																				case 236:
																																					goto IL_0d46;
																																				case 176:
																																					goto IL_0d54;
																																				case 27:
																																				case 113:
																																					goto IL_0d5f;
																																				case 69:
																																					goto IL_0d9f;
																																				case 91:
																																					goto IL_0db3;
																																				case 189:
																																				case 344:
																																					goto IL_0dc6;
																																				case 244:
																																					goto IL_0dd4;
																																				case 130:
																																				case 292:
																																					goto IL_0ded;
																																				case 280:
																																					goto IL_0e06;
																																				case 102:
																																					goto IL_0e1d;
																																				case 74:
																																					goto IL_0e2b;
																																				case 146:
																																					goto IL_0e3e;
																																				case 9:
																																					goto IL_0e4c;
																																				case 78:
																																				case 129:
																																					goto IL_0e5a;
																																				case 185:
																																					goto IL_0e83;
																																				case 191:
																																					goto IL_0e91;
																																				case 156:
																																				case 360:
																																					goto IL_0ea4;
																																				case 215:
																																					goto IL_0eb2;
																																				case 123:
																																					goto IL_0ed5;
																																				case 200:
																																					goto IL_0edf;
																																				case 331:
																																					goto IL_0eed;
																																				case 0:
																																					goto IL_0f00;
																																				case 254:
																																					goto IL_0f0e;
																																				case 323:
																																					goto IL_0f1c;
																																				case 169:
																																				case 318:
																																					goto IL_0f2a;
																																				case 42:
																																				case 316:
																																					goto IL_0f35;
																																				case 175:
																																					goto IL_0f43;
																																				case 103:
																																					goto IL_0f56;
																																				case 37:
																																				case 357:
																																					goto IL_0f6d;
																																				case 135:
																																					goto IL_0f90;
																																				case 18:
																																					goto IL_0f9e;
																																				case 271:
																																					goto IL_0fac;
																																				case 114:
																																					goto IL_0fbf;
																																				case 312:
																																				case 339:
																																					goto IL_0fca;
																																				case 351:
																																					goto IL_0fed;
																																				case 67:
																																					goto IL_0ffb;
																																				case 33:
																																					goto IL_1009;
																																				case 21:
																																					goto IL_101c;
																																				case 83:
																																					goto IL_102a;
																																				case 173:
																																				case 225:
																																					goto IL_1038;
																																				case 150:
																																					goto IL_1070;
																																				case 230:
																																					goto IL_1084;
																																				case 240:
																																					goto IL_10a0;
																																				case 20:
																																				case 165:
																																					goto IL_10ab;
																																				case 358:
																																					goto IL_10ce;
																																				case 242:
																																					goto IL_10dc;
																																				case 40:
																																					goto IL_10ea;
																																				case 12:
																																					goto IL_10fd;
																																				case 268:
																																					goto IL_110b;
																																				case 290:
																																				case 304:
																																					goto IL_1116;
																																				case 116:
																																					goto IL_1124;
																																				case 289:
																																				case 352:
																																					goto IL_1132;
																																				case 164:
																																					goto IL_1155;
																																				case 88:
																																					goto IL_1163;
																																				case 194:
																																					goto IL_1171;
																																				case 313:
																																				case 322:
																																					goto IL_1184;
																																				case 171:
																																					goto IL_11bc;
																																				case 231:
																																					goto IL_11d0;
																																				case 300:
																																					goto IL_11e3;
																																				case 7:
																																				case 251:
																																					goto IL_11ee;
																																				case 291:
																																					goto IL_11fc;
																																				case 206:
																																				case 288:
																																					goto IL_120a;
																																				case 118:
																																					goto IL_122d;
																																				case 84:
																																					goto IL_123b;
																																				case 29:
																																					goto IL_1249;
																																				case 228:
																																					goto IL_125c;
																																				case 214:
																																				case 229:
																																					goto IL_126a;
																																				case 15:
																																					goto IL_127e;
																																				case 201:
																																					goto IL_12b6;
																																				case 320:
																																					goto IL_12c9;
																																				case 262:
																																				case 267:
																																					goto IL_12d4;
																																				case 212:
																																					goto IL_12f7;
																																				case 47:
																																					goto IL_1305;
																																				case 58:
																																					goto IL_1313;
																																				case 117:
																																					goto IL_1326;
																																				case 125:
																																					goto IL_1334;
																																				case 119:
																																				case 159:
																																					goto IL_133f;
																																				case 297:
																																					goto IL_137c;
																																				case 269:
																																					goto IL_138a;
																																				case 314:
																																					goto IL_139d;
																																				case 5:
																																					goto IL_13ab;
																																				case 36:
																																					goto IL_13b9;
																																				case 333:
																																					goto IL_13c7;
																																				case 26:
																																				case 307:
																																					goto IL_13d5;
																																				case 98:
																																					goto IL_1413;
																																				case 145:
																																					goto IL_1427;
																																				case 238:
																																				case 336:
																																					goto IL_1443;
																																				case 298:
																																					goto IL_1481;
																																				case 184:
																																					goto IL_148f;
																																				case 263:
																																				case 327:
																																					goto IL_14ab;
																																				case 25:
																																					goto IL_14b6;
																																				case 132:
																																				case 365:
																																					goto IL_14c4;
																																				case 44:
																																					goto IL_14d8;
																																				case 274:
																																					goto IL_1510;
																																				case 282:
																																				case 363:
																																					goto IL_1523;
																																				case 321:
																																					goto IL_1531;
																																				case 115:
																																				case 346:
																																					goto IL_153f;
																																				case 170:
																																					goto IL_1562;
																																				case 218:
																																					goto IL_1570;
																																				case 284:
																																					goto IL_157e;
																																				case 277:
																																					goto IL_1591;
																																				case 198:
																																					goto IL_159f;
																																				case 92:
																																					goto IL_15aa;
																																				case 334:
																																					goto IL_15b8;
																																				case 64:
																																				case 166:
																																					goto IL_15c6;
																																				case 4:
																																					goto IL_15e9;
																																				case 367:
																																					goto IL_15f7;
																																				case 104:
																																					goto IL_1605;
																																				case 281:
																																				case 303:
																																					goto IL_1621;
																																				case 296:
																																					goto IL_165e;
																																				case 342:
																																					goto IL_166c;
																																				case 187:
																																					goto IL_167f;
																																				case 2:
																																				case 260:
																																					goto IL_168a;
																																				case 239:
																																					goto IL_1698;
																																				case 71:
																																				case 192:
																																					goto IL_16a6;
																																				case 133:
																																					goto IL_16de;
																																				case 347:
																																					goto IL_16f2;
																																				case 355:
																																					goto IL_1702;
																																				case 28:
																																				case 108:
																																					goto IL_170d;
																																				case 275:
																																					goto IL_1745;
																																				case 8:
																																					goto IL_1759;
																																				case 1:
																																				case 11:
																																				case 17:
																																				case 30:
																																				case 31:
																																				case 34:
																																				case 35:
																																				case 46:
																																				case 48:
																																				case 49:
																																				case 56:
																																				case 60:
																																				case 65:
																																				case 79:
																																				case 80:
																																				case 85:
																																				case 86:
																																				case 89:
																																				case 94:
																																				case 99:
																																				case 140:
																																				case 141:
																																				case 153:
																																				case 155:
																																				case 163:
																																				case 172:
																																				case 174:
																																				case 203:
																																				case 204:
																																				case 205:
																																				case 211:
																																				case 216:
																																				case 217:
																																				case 222:
																																				case 223:
																																				case 241:
																																				case 245:
																																				case 250:
																																				case 255:
																																				case 256:
																																				case 261:
																																				case 264:
																																				case 272:
																																				case 278:
																																				case 279:
																																				case 286:
																																				case 299:
																																				case 308:
																																				case 315:
																																				case 319:
																																				case 328:
																																				case 329:
																																				case 330:
																																				case 332:
																																				case 335:
																																				case 337:
																																				case 348:
																																				case 349:
																																				case 350:
																																				case 356:
																																				case 362:
																																				case 366:
																																					goto end_IL_06e9;
																																				case 13:
																																				case 43:
																																				case 50:
																																				case 52:
																																				case 61:
																																				case 66:
																																				case 70:
																																				case 81:
																																				case 96:
																																				case 100:
																																				case 105:
																																				case 106:
																																				case 109:
																																				case 142:
																																				case 143:
																																				case 144:
																																				case 147:
																																				case 154:
																																				case 157:
																																				case 158:
																																				case 167:
																																				case 177:
																																				case 179:
																																				case 183:
																																				case 188:
																																				case 190:
																																				case 210:
																																				case 232:
																																				case 234:
																																				case 252:
																																				case 270:
																																				case 273:
																																				case 283:
																																				case 294:
																																				case 338:
																																				case 340:
																																				case 341:
																																				case 343:
																																				case 359:
																																				case 364:
																																					goto end_IL_05f5;
																																				case 134:
																																					goto end_IL_177c;
																																				case 248:
																																					goto end_IL_178f;
																																				case 345:
																																					goto end_IL_1799;
																																				case 6:
																																					goto end_IL_17a4;
																																				case 162:
																																					goto end_IL_17b4;
																																				case 3:
																																				case 62:
																																					goto end_IL_17c4;
																																				case 131:
																																					goto end_IL_17d4;
																																				case 295:
																																				case 301:
																																					goto end_IL_17e4;
																																				case 220:
																																					goto end_IL_17f4;
																																				case 221:
																																					goto end_IL_1804;
																																				case 10:
																																				case 121:
																																					return;
																																				}
																																				continue;
																																				end_IL_05f5:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															num = 127;
																															goto IL_07c9;
																															IL_0ab7:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_0af7;
																															IL_0af7:
																															array[num5 - 2] = 0;
																															goto IL_0b0b;
																															IL_07c9:
																															if (5 < b)
																															{
																																goto end_IL_06e9;
																															}
																															num = 310;
																															goto IL_0aa9;
																															IL_0b0b:
																															num5--;
																															break;
																															IL_0aa9:
																															if (5 > b)
																															{
																																goto end_IL_06e9;
																															}
																															goto IL_0ab7;
																														}
																														break;
																													}
																													goto IL_0c77;
																													IL_0d25:
																													num5--;
																													break;
																													IL_0c77:
																													if (7 >= b)
																													{
																														goto IL_0c82;
																													}
																													goto IL_0d00;
																													IL_0c82:
																													if (7 > b)
																													{
																														goto end_IL_06e9;
																													}
																													goto IL_0c90;
																													IL_0c90:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0cd0;
																													IL_0cd0:
																													array[num5 - 2] = 0;
																													num = 63;
																													goto IL_0ced;
																													IL_0ced:
																													num5--;
																													break;
																													IL_0d00:
																													if (8 < b)
																													{
																														goto end_IL_06e9;
																													}
																													goto IL_0d0e;
																													IL_0d0e:
																													if (8 > b)
																													{
																														goto end_IL_06e9;
																													}
																													num = 208;
																													goto IL_0d25;
																												}
																												break;
																											}
																											goto IL_0d38;
																											IL_0edf:
																											num5++;
																											goto IL_0eed;
																											IL_0d38:
																											if (4 > b)
																											{
																												goto IL_0d46;
																											}
																											goto IL_0ea4;
																											IL_0d46:
																											if (2 >= b)
																											{
																												goto IL_0d54;
																											}
																											goto IL_0e3e;
																											IL_0d54:
																											if (2 <= b)
																											{
																												goto IL_0d5f;
																											}
																											goto IL_0dc6;
																											IL_0d5f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0d9f;
																											IL_0d9f:
																											array[num5 - 2] = 0;
																											goto IL_0db3;
																											IL_0db3:
																											num5--;
																											break;
																											IL_0dc6:
																											if (1 < b)
																											{
																												goto end_IL_06e9;
																											}
																											goto IL_0dd4;
																											IL_0dd4:
																											if (1 > b)
																											{
																												num = 79;
																												goto end_IL_06e9;
																											}
																											goto IL_0ded;
																											IL_0eed:
																											ptr2 += 8;
																											break;
																											IL_0ded:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0e06;
																											IL_0e06:
																											array[num5] = 0;
																											num = 102;
																											goto IL_0e1d;
																											IL_0e1d:
																											num5++;
																											goto IL_0e2b;
																											IL_0e2b:
																											ptr2 += 8;
																											break;
																											IL_0e3e:
																											if (3 < b)
																											{
																												goto end_IL_06e9;
																											}
																											goto IL_0e4c;
																											IL_0e4c:
																											if (3 > b)
																											{
																												goto end_IL_06e9;
																											}
																											goto IL_0e5a;
																											IL_0e5a:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0e83;
																											IL_0e83:
																											ptr2 += 8;
																											goto IL_0e91;
																											IL_0e91:
																											num5--;
																											break;
																											IL_0ea4:
																											array[num5] = 0;
																											goto IL_0eb2;
																											IL_0eb2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0ed5;
																											IL_0ed5:
																											array2[num5] = null;
																											goto IL_0edf;
																										}
																										break;
																									}
																									goto IL_094b;
																									IL_0a96:
																									num5--;
																									break;
																									IL_094b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_098b;
																									IL_098b:
																									array[num5 - 2] = 0;
																									goto IL_0a96;
																								}
																								break;
																							}
																							goto IL_079d;
																							IL_09d6:
																							num5++;
																							goto IL_09e4;
																							IL_09e4:
																							ptr2 += 8;
																							break;
																							IL_079d:
																							if (14 < b)
																							{
																								goto IL_07ab;
																							}
																							goto IL_0890;
																							IL_07ab:
																							if (16 >= b)
																							{
																								goto IL_07b6;
																							}
																							goto IL_07e5;
																							IL_07b6:
																							if (16 <= b)
																							{
																								goto IL_0874;
																							}
																							goto IL_0b9d;
																							IL_0b9d:
																							if (15 < b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_0bab;
																							IL_0bab:
																							if (15 > b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_0bb9;
																							IL_0bb9:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0c17;
																							IL_0c17:
																							num5--;
																							break;
																							IL_0874:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							break;
																							IL_07e5:
																							if (17 < b)
																							{
																								goto IL_07f0;
																							}
																							goto IL_0811;
																							IL_07f0:
																							if (18 < b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_07fe;
																							IL_07fe:
																							if (18 > b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_0c2a;
																							IL_0c2a:
																							array2[num5] = ((delegate*<VRRig>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																							goto IL_0c48;
																							IL_0c48:
																							array[num5] = 5;
																							goto IL_0c56;
																							IL_0c56:
																							num5++;
																							goto IL_0c64;
																							IL_0c64:
																							ptr2 += 8;
																							break;
																							IL_0811:
																							if (17 > b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_081f;
																							IL_081f:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0837;
																							IL_0837:
																							array[num5] = 5;
																							goto IL_0b1e;
																							IL_0b1e:
																							num5++;
																							num = 325;
																							goto IL_0b8a;
																							IL_0b8a:
																							ptr2 += 8;
																							break;
																							IL_0890:
																							if (14 > b)
																							{
																								goto IL_089e;
																							}
																							goto IL_09a4;
																							IL_089e:
																							if (11 < b)
																							{
																								goto IL_08ac;
																							}
																							goto IL_09f7;
																							IL_08ac:
																							if (12 >= b)
																							{
																								goto IL_08b7;
																							}
																							goto IL_08ca;
																							IL_08b7:
																							if (12 > b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_0b37;
																							IL_0b37:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_0b5b;
																							IL_0b5b:
																							array[num5] = 0;
																							goto IL_0b69;
																							IL_0b69:
																							num5++;
																							goto IL_0b77;
																							IL_0b77:
																							ptr2 += 8;
																							break;
																							IL_08ca:
																							if (13 < b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_08d8;
																							IL_08d8:
																							if (13 > b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_08e6;
																							IL_08e6:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0938;
																							IL_0938:
																							num5--;
																							break;
																							IL_09f7:
																							if (11 <= b)
																							{
																								break;
																							}
																							goto IL_0a05;
																							IL_0a05:
																							if (10 < b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_0a13;
																							IL_0a13:
																							if (10 > b)
																							{
																								goto end_IL_06e9;
																							}
																							goto IL_0a21;
																							IL_0a21:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0a83;
																							IL_0a83:
																							num5 -= 2;
																							break;
																							IL_09a4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_09c8;
																							IL_09c8:
																							array[num5] = 0;
																							goto IL_09d6;
																						}
																						break;
																					}
																					goto IL_0732;
																					IL_0861:
																					ptr2 += 8;
																					break;
																					IL_0732:
																					array[num5 - 2] = 0;
																					goto IL_0746;
																					IL_0746:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (VRRig)array2[num5 - 1]) ? 1 : 0);
																					goto IL_084a;
																					IL_084a:
																					num5--;
																					num = 195;
																					goto IL_0861;
																				}
																				break;
																			}
																			goto IL_0f00;
																			IL_16de:
																			array[num5 - 1] = 5;
																			goto IL_16f2;
																			IL_0f00:
																			if (29 < b)
																			{
																				goto IL_0f0e;
																			}
																			goto IL_12c9;
																			IL_0f0e:
																			if (34 < b)
																			{
																				goto IL_0f1c;
																			}
																			num = 240;
																			goto IL_10a0;
																			IL_0f1c:
																			if (36 < b)
																			{
																				goto IL_0f2a;
																			}
																			goto IL_0fbf;
																			IL_0f2a:
																			if (37 < b)
																			{
																				goto IL_0f35;
																			}
																			goto IL_0f56;
																			IL_0f35:
																			if (38 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_0f43;
																			IL_0f43:
																			if (38 > b)
																			{
																			}
																			goto end_IL_06e9;
																			IL_0f56:
																			if (37 > b)
																			{
																				goto end_IL_06e9;
																			}
																			num = 37;
																			goto IL_0f6d;
																			IL_1702:
																			if (27 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_170d;
																			IL_0f6d:
																			array2[num5] = ((delegate*<Quaternion>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_0f90;
																			IL_0f90:
																			array[num5] = 4;
																			goto IL_0f9e;
																			IL_0f9e:
																			num5++;
																			goto IL_0fac;
																			IL_0fac:
																			ptr2 += 8;
																			break;
																			IL_0fbf:
																			if (36 <= b)
																			{
																				goto IL_0fca;
																			}
																			goto IL_101c;
																			IL_0fca:
																			array2[num5] = ((delegate*<Vector3>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_0fed;
																			IL_0fed:
																			array[num5] = 4;
																			goto IL_0ffb;
																			IL_0ffb:
																			num5++;
																			goto IL_1009;
																			IL_1009:
																			ptr2 += 8;
																			break;
																			IL_101c:
																			if (35 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_102a;
																			IL_102a:
																			if (35 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_1038;
																			IL_1038:
																			array2[num5 - 1] = ((delegate*<VRRig, VRMap>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																			goto IL_1070;
																			IL_1070:
																			array[num5 - 1] = 5;
																			goto IL_1084;
																			IL_1084:
																			ptr2 += 8;
																			break;
																			IL_16f2:
																			ptr2 += 8;
																			break;
																			IL_10a0:
																			if (34 <= b)
																			{
																				goto IL_10ab;
																			}
																			goto IL_10fd;
																			IL_10ab:
																			array2[num5] = ((delegate*<Quaternion>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_10ce;
																			IL_10ce:
																			array[num5] = 4;
																			goto IL_10dc;
																			IL_10dc:
																			num5++;
																			goto IL_10ea;
																			IL_10ea:
																			ptr2 += 8;
																			break;
																			IL_10fd:
																			if (31 >= b)
																			{
																				goto IL_110b;
																			}
																			goto IL_11e3;
																			IL_110b:
																			if (31 > b)
																			{
																				goto IL_1116;
																			}
																			goto IL_1184;
																			IL_1116:
																			if (30 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_1124;
																			IL_1124:
																			if (30 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_1132;
																			IL_1132:
																			array2[num5] = ((delegate*<Quaternion>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_1155;
																			IL_1155:
																			array[num5] = 4;
																			goto IL_1163;
																			IL_1163:
																			num5++;
																			goto IL_1171;
																			IL_1171:
																			ptr2 += 8;
																			break;
																			IL_1184:
																			array2[num5 - 1] = ((delegate*<VRRig, VRMap>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																			goto IL_11bc;
																			IL_11bc:
																			array[num5 - 1] = 5;
																			goto IL_11d0;
																			IL_11d0:
																			ptr2 += 8;
																			break;
																			IL_11e3:
																			if (32 < b)
																			{
																				goto IL_11ee;
																			}
																			goto IL_125c;
																			IL_11ee:
																			if (33 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_11fc;
																			IL_11fc:
																			if (33 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_120a;
																			IL_120a:
																			array2[num5] = ((delegate*<Vector3>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_122d;
																			IL_122d:
																			array[num5] = 4;
																			goto IL_123b;
																			IL_123b:
																			num5++;
																			goto IL_1249;
																			IL_1249:
																			ptr2 += 8;
																			break;
																			IL_125c:
																			if (32 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_126a;
																			IL_126a:
																			array[num5 - 1] = 5;
																			goto IL_127e;
																			IL_127e:
																			array2[num5 - 1] = ((delegate*<Component, Transform>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																			goto IL_12b6;
																			IL_12b6:
																			ptr2 += 8;
																			break;
																			IL_12c9:
																			if (29 <= b)
																			{
																				goto IL_12d4;
																			}
																			goto IL_1326;
																			IL_12d4:
																			array2[num5] = ((delegate*<Vector3>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_12f7;
																			IL_12f7:
																			array[num5] = 4;
																			goto IL_1305;
																			IL_1305:
																			num5++;
																			goto IL_1313;
																			IL_1313:
																			ptr2 += 8;
																			break;
																			IL_1326:
																			if (24 >= b)
																			{
																				goto IL_1334;
																			}
																			goto IL_1591;
																			IL_1334:
																			if (24 <= b)
																			{
																				goto IL_133f;
																			}
																			goto IL_139d;
																			IL_133f:
																			((delegate*<Transform, Vector3, void>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																			goto IL_137c;
																			IL_137c:
																			num5 -= 2;
																			goto IL_138a;
																			IL_138a:
																			ptr2 += 8;
																			break;
																			IL_139d:
																			if (21 >= b)
																			{
																				goto IL_13ab;
																			}
																			num = 327;
																			goto IL_14ab;
																			IL_13ab:
																			if (21 > b)
																			{
																				goto IL_13b9;
																			}
																			num = 238;
																			goto IL_1443;
																			IL_13b9:
																			if (20 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_13c7;
																			IL_13c7:
																			if (20 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_13d5;
																			IL_13d5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<VRRig, bool>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]) ? 1 : 0);
																			goto IL_1413;
																			IL_1413:
																			array[num5 - 1] = 0;
																			goto IL_1427;
																			IL_1427:
																			ptr2 += 8;
																			break;
																			IL_1745:
																			array[num5 - 1] = 5;
																			goto IL_1759;
																			IL_1443:
																			((delegate*<Behaviour, bool, void>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																			goto IL_1481;
																			IL_1481:
																			num5 -= 2;
																			goto IL_148f;
																			IL_148f:
																			ptr2 += 8;
																			break;
																			IL_170d:
																			array2[num5 - 1] = ((delegate*<VRRig, VRMap>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																			goto IL_1745;
																			IL_14ab:
																			if (22 >= b)
																			{
																				goto IL_14b6;
																			}
																			goto IL_1523;
																			IL_14b6:
																			if (22 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_14c4;
																			IL_14c4:
																			array[num5 - 1] = 5;
																			goto IL_14d8;
																			IL_14d8:
																			array2[num5 - 1] = ((delegate*<Component, Transform>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																			goto IL_1510;
																			IL_1510:
																			ptr2 += 8;
																			break;
																			IL_1523:
																			if (23 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_1531;
																			IL_1531:
																			if (23 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_153f;
																			IL_153f:
																			array2[num5] = ((delegate*<Vector3>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_1562;
																			IL_1562:
																			array[num5] = 4;
																			goto IL_1570;
																			IL_1570:
																			num5++;
																			goto IL_157e;
																			IL_157e:
																			ptr2 += 8;
																			break;
																			IL_1591:
																			if (26 >= b)
																			{
																				goto IL_159f;
																			}
																			goto IL_167f;
																			IL_159f:
																			if (26 > b)
																			{
																				goto IL_15aa;
																			}
																			num = 303;
																			goto IL_1621;
																			IL_15aa:
																			if (25 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_15b8;
																			IL_15b8:
																			if (25 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_15c6;
																			IL_15c6:
																			array2[num5] = ((delegate*<Quaternion>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])();
																			goto IL_15e9;
																			IL_15e9:
																			array[num5] = 4;
																			goto IL_15f7;
																			IL_15f7:
																			num5++;
																			goto IL_1605;
																			IL_1605:
																			ptr2 += 8;
																			break;
																			IL_1759:
																			ptr2 += 8;
																			break;
																			IL_1621:
																			((delegate*<Transform, Quaternion, void>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 2], (Quaternion)array2[num5 - 1]);
																			goto IL_165e;
																			IL_165e:
																			num5 -= 2;
																			goto IL_166c;
																			IL_166c:
																			ptr2 += 8;
																			break;
																			IL_167f:
																			if (27 < b)
																			{
																				goto IL_168a;
																			}
																			goto IL_1702;
																			IL_168a:
																			if (28 < b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_1698;
																			IL_1698:
																			if (28 > b)
																			{
																				goto end_IL_06e9;
																			}
																			goto IL_16a6;
																			IL_16a6:
																			array2[num5 - 1] = ((delegate*<VRMap, Transform>)PrincipalPermissionStandardTaskContinuation[*(int*)(ptr2 + num3)])((VRMap)array2[num5 - 1]);
																			goto IL_16de;
																		}
																		goto end_IL_06f9;
																		continue;
																		end_IL_06e9:
																		break;
																		IL_06e9:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_06f9:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_177c:
													break;
												}
												continue;
												end_IL_178f:
												break;
											}
											continue;
											end_IL_1799:
											break;
										}
										continue;
										end_IL_17a4:
										break;
									}
									continue;
									end_IL_17b4:
									break;
								}
								continue;
								end_IL_17c4:
								break;
							}
							continue;
							end_IL_17d4:
							break;
						}
						continue;
						end_IL_17e4:
						break;
					}
					continue;
					end_IL_17f4:
					break;
				}
				continue;
				end_IL_1804:
				break;
			}
		}
	}

	public Class172()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_0)
	{
		int num = 67;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadBlockAsyncInternaldGuidTypeInfo.TimeZoneInfoCurrencyWrapper);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02ed:
														byte b = *ptr2;
														while (true)
														{
															IL_02dd:
															ptr2++;
															while (true)
															{
																IL_02cd:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_02b0:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_02a0:
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_0290:
																							if (11 > b)
																							{
																								while (true)
																								{
																									IL_0283:
																									if (9 < b)
																									{
																										while (10 >= b)
																										{
																											num = 144;
																											while (true)
																											{
																												if (num != 144)
																												{
																													if (num != 1125)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 99:
																														goto IL_0270;
																													case 78:
																													case 121:
																														goto IL_0283;
																													case 10:
																														goto IL_0290;
																													case 0:
																														goto IL_02a0;
																													case 117:
																														goto IL_02b0;
																													case 90:
																														goto IL_02bd;
																													case 103:
																														goto IL_02cd;
																													case 39:
																														goto IL_02dd;
																													case 26:
																													case 128:
																														goto IL_02ed;
																													case 8:
																														goto IL_02f8;
																													case 17:
																														goto IL_030b;
																													case 18:
																													case 24:
																														goto IL_0319;
																													case 4:
																														goto IL_0324;
																													case 2:
																													case 5:
																														goto IL_0332;
																													case 31:
																														goto IL_034a;
																													case 27:
																														goto IL_0358;
																													case 19:
																													case 72:
																														goto IL_0366;
																													case 16:
																														goto IL_0374;
																													case 21:
																														goto IL_0397;
																													case 45:
																													case 89:
																														goto IL_03a3;
																													case 41:
																														goto IL_03b1;
																													case 95:
																														goto IL_03cd;
																													case 102:
																														goto IL_03db;
																													case 80:
																													case 104:
																														goto IL_03ee;
																													case 60:
																														goto IL_03f9;
																													case 57:
																													case 107:
																														goto IL_041a;
																													case 84:
																														goto IL_0428;
																													case 42:
																													case 114:
																														goto IL_043b;
																													case 48:
																														goto IL_047b;
																													case 69:
																														goto IL_048f;
																													case 120:
																														goto IL_04a2;
																													case 82:
																													case 126:
																														goto IL_04b2;
																													case 112:
																														goto IL_0514;
																													case 38:
																													case 127:
																														goto IL_0527;
																													case 43:
																														goto IL_0550;
																													case 91:
																														goto IL_055e;
																													case 133:
																														goto IL_0571;
																													case 3:
																														goto IL_057f;
																													case 101:
																													case 130:
																														goto IL_058d;
																													case 93:
																														goto IL_05cd;
																													case 125:
																														goto IL_05e1;
																													case 50:
																													case 136:
																														goto IL_05f4;
																													case 22:
																														goto IL_0617;
																													case 23:
																														goto IL_0625;
																													case 54:
																														goto IL_0633;
																													case 137:
																														goto IL_0646;
																													case 15:
																													case 63:
																														goto IL_0654;
																													case 28:
																														goto IL_066d;
																													case 129:
																														goto IL_067b;
																													case 37:
																														goto IL_0689;
																													case 61:
																													case 122:
																														goto IL_06aa;
																													case 65:
																														goto IL_06f3;
																													case 79:
																														goto IL_0707;
																													case 35:
																													case 71:
																														goto IL_071a;
																													case 9:
																														goto IL_072e;
																													case 94:
																														goto IL_0782;
																													case 110:
																														goto IL_0790;
																													case 119:
																														goto IL_07ac;
																													case 53:
																														goto IL_07b7;
																													case 76:
																														goto IL_07c2;
																													case 36:
																														goto IL_07d8;
																													case 25:
																													case 118:
																														goto IL_07e3;
																													case 105:
																														goto IL_07fc;
																													case 12:
																														goto IL_0807;
																													case 55:
																													case 88:
																														goto IL_0812;
																													case 14:
																													case 29:
																													case 33:
																													case 40:
																													case 44:
																													case 46:
																													case 49:
																													case 52:
																													case 58:
																													case 62:
																													case 64:
																													case 68:
																													case 70:
																													case 75:
																													case 77:
																													case 81:
																													case 83:
																													case 96:
																													case 100:
																													case 109:
																													case 111:
																													case 116:
																													case 124:
																													case 131:
																													case 135:
																														goto end_IL_0270;
																													case 1:
																													case 6:
																													case 20:
																													case 30:
																													case 32:
																													case 73:
																													case 85:
																													case 86:
																													case 87:
																													case 92:
																													case 97:
																													case 106:
																													case 108:
																													case 115:
																													case 123:
																													case 132:
																													case 134:
																														goto end_IL_025d;
																													case 13:
																														goto end_IL_0835;
																													case 34:
																														goto end_IL_0848;
																													case 98:
																														goto end_IL_0852;
																													case 11:
																														goto end_IL_085d;
																													case 51:
																													case 59:
																														goto end_IL_0872;
																													case 7:
																														goto end_IL_0882;
																													case 47:
																													case 113:
																														goto end_IL_0892;
																													case 66:
																														goto end_IL_08a2;
																													case 67:
																														goto end_IL_08b2;
																													case 56:
																													case 74:
																														goto IL_08cd;
																													}
																													continue;
																												}
																												if (10 > b)
																												{
																													goto end_IL_0270;
																												}
																												goto IL_06aa;
																												IL_06aa:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 65;
																												goto IL_06f3;
																												IL_0707:
																												num5--;
																												break;
																												IL_06f3:
																												array[num5 - 2] = 0;
																												goto IL_0707;
																												continue;
																												end_IL_025d:
																												break;
																											}
																											goto end_IL_02cd;
																											continue;
																											end_IL_0270:
																											break;
																											IL_0270:;
																										}
																										break;
																									}
																									goto IL_02f8;
																									IL_04b2:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0514;
																									IL_02f8:
																									if (9 > b)
																									{
																										goto IL_03a3;
																									}
																									goto IL_04b2;
																									IL_03a3:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_03b1;
																									IL_03b1:
																									if (8 > b)
																									{
																										break;
																									}
																									num = 136;
																									goto IL_05f4;
																									IL_0514:
																									num5 -= 2;
																									goto end_IL_02cd;
																									IL_05f4:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0617;
																									IL_0617:
																									array[num5] = 0;
																									goto IL_0625;
																									IL_0625:
																									num5++;
																									goto IL_0633;
																									IL_0633:
																									ptr2 += 8;
																									goto end_IL_02cd;
																								}
																								break;
																							}
																							goto IL_071a;
																							IL_0790:
																							ptr2 += 8;
																							num = 123;
																							goto end_IL_02cd;
																							IL_071a:
																							array[num5 - 2] = 0;
																							goto IL_072e;
																							IL_072e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)MakeByRefTypeRandomlyGenerated[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_0782;
																							IL_0782:
																							num5--;
																							goto IL_0790;
																						}
																						break;
																					}
																					goto IL_07ac;
																					IL_0807:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_0812;
																					IL_07ac:
																					if (13 < b)
																					{
																						goto IL_07b7;
																					}
																					num = 36;
																					goto IL_07d8;
																					IL_07b7:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_07c2;
																					IL_07c2:
																					if (14 <= b)
																					{
																					}
																					break;
																					IL_0812:
																					num5--;
																					goto end_IL_02cd;
																					IL_07d8:
																					if (13 <= b)
																					{
																						goto IL_07e3;
																					}
																					goto IL_07fc;
																					IL_07e3:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02cd;
																					IL_07fc:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_0807;
																				}
																				break;
																			}
																			goto IL_030b;
																			IL_047b:
																			array[num5 - 2] = 0;
																			goto IL_048f;
																			IL_030b:
																			if (7 > b)
																			{
																				goto IL_0319;
																			}
																			goto IL_043b;
																			IL_0319:
																			if (3 >= b)
																			{
																				goto IL_0324;
																			}
																			goto IL_034a;
																			IL_0324:
																			if (3 <= b)
																			{
																				goto IL_0332;
																			}
																			goto IL_03ee;
																			IL_0332:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02cd;
																			IL_03ee:
																			if (1 < b)
																			{
																				goto IL_03f9;
																			}
																			num = 137;
																			goto IL_0646;
																			IL_03f9:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04a2;
																			IL_04a2:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0527;
																			IL_0527:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0550;
																			IL_0550:
																			ptr2 += 8;
																			goto IL_055e;
																			IL_055e:
																			num5--;
																			goto end_IL_02cd;
																			IL_048f:
																			num5--;
																			goto end_IL_02cd;
																			IL_0646:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0654;
																			IL_0654:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_066d;
																			IL_066d:
																			array[num5] = 0;
																			goto IL_067b;
																			IL_067b:
																			num5++;
																			goto IL_0689;
																			IL_0689:
																			ptr2 += 8;
																			goto end_IL_02cd;
																			IL_034a:
																			if (5 >= b)
																			{
																				goto IL_0358;
																			}
																			goto IL_0571;
																			IL_0358:
																			if (5 <= b)
																			{
																				goto IL_0366;
																			}
																			goto IL_041a;
																			IL_0366:
																			array[num5] = 0;
																			goto IL_0374;
																			IL_0374:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0397;
																			IL_0397:
																			array2[num5] = null;
																			goto IL_03cd;
																			IL_03cd:
																			num5++;
																			goto IL_03db;
																			IL_03db:
																			ptr2 += 8;
																			goto end_IL_02cd;
																			IL_041a:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0428;
																			IL_0428:
																			if (4 <= b)
																			{
																				goto end_IL_02cd;
																			}
																			break;
																			IL_0571:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_057f;
																			IL_057f:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_058d;
																			IL_058d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05cd;
																			IL_05cd:
																			array[num5 - 2] = 0;
																			goto IL_05e1;
																			IL_05e1:
																			num5--;
																			goto end_IL_02cd;
																			IL_043b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_047b;
																		}
																		break;
																		IL_02bd:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02cd:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_08cd;
												IL_08cd:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0835:
												break;
											}
											continue;
											end_IL_0848:
											break;
										}
										continue;
										end_IL_0852:
										break;
									}
									continue;
									end_IL_085d:
									break;
								}
								continue;
								end_IL_0872:
								break;
							}
							continue;
							end_IL_0882:
							break;
						}
						continue;
						end_IL_0892:
						break;
					}
					continue;
					end_IL_08a2:
					break;
				}
				continue;
				end_IL_08b2:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 65;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 54;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TKINDENUMsetYearMonthPattern.RemoveSurrogatesetWindow);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_03e6:
															byte b = *ptr2;
															while (true)
															{
																IL_03d6:
																ptr2++;
																while (true)
																{
																	IL_03c6:
																	if (b >= 1)
																	{
																		while (b <= 17)
																		{
																			while (true)
																			{
																				IL_03a6:
																				if (9 < b)
																				{
																					while (true)
																					{
																						IL_0399:
																						if (13 >= b)
																						{
																							while (true)
																							{
																								IL_0389:
																								if (13 > b)
																								{
																									while (true)
																									{
																										IL_037c:
																										if (11 >= b)
																										{
																											while (true)
																											{
																												IL_036c:
																												if (11 > b)
																												{
																													while (10 >= b)
																													{
																														while (10 <= b)
																														{
																															while (true)
																															{
																																IL_033c:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_0317:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																	while (true)
																																	{
																																		IL_030b:
																																		array2[num5] = null;
																																		while (true)
																																		{
																																			IL_02fb:
																																			num5++;
																																			while (true)
																																			{
																																				IL_02e2:
																																				ptr2 += 8;
																																				num = 176;
																																				while (num != 176)
																																				{
																																					if (num != 1157)
																																					{
																																						goto end_IL_034c;
																																					}
																																					switch (num)
																																					{
																																					case 80:
																																						goto IL_02e2;
																																					case 62:
																																						goto IL_02fb;
																																					case 61:
																																						goto IL_030b;
																																					case 17:
																																						goto IL_0317;
																																					case 120:
																																					case 139:
																																						goto IL_033c;
																																					case 1:
																																						goto IL_034c;
																																					case 95:
																																						goto IL_035c;
																																					case 10:
																																						goto IL_036c;
																																					case 68:
																																						goto IL_037c;
																																					case 22:
																																						goto IL_0389;
																																					case 124:
																																					case 156:
																																						goto IL_0399;
																																					case 72:
																																						goto IL_03a6;
																																					case 18:
																																						goto IL_03b6;
																																					case 43:
																																						goto IL_03c6;
																																					case 42:
																																						goto IL_03d6;
																																					case 86:
																																					case 94:
																																						goto IL_03e6;
																																					case 31:
																																					case 39:
																																						goto IL_03f1;
																																					case 40:
																																					case 58:
																																						goto IL_0404;
																																					case 71:
																																						goto IL_0412;
																																					case 28:
																																					case 77:
																																						goto IL_042b;
																																					case 45:
																																					case 91:
																																						goto IL_0476;
																																					case 108:
																																						goto IL_04dd;
																																					case 106:
																																					case 111:
																																						goto IL_04f3;
																																					case 56:
																																						goto IL_0537;
																																					case 11:
																																						goto IL_054b;
																																					case 126:
																																						goto IL_055e;
																																					case 127:
																																						goto IL_0571;
																																					case 36:
																																					case 158:
																																						goto IL_0584;
																																					case 132:
																																						goto IL_058f;
																																					case 104:
																																					case 125:
																																						goto IL_059d;
																																					case 15:
																																						goto IL_05b9;
																																					case 67:
																																						goto IL_05c7;
																																					case 161:
																																						goto IL_05da;
																																					case 66:
																																					case 102:
																																						goto IL_05e5;
																																					case 4:
																																						goto IL_05f8;
																																					case 79:
																																						goto IL_0606;
																																					case 26:
																																					case 155:
																																						goto IL_0614;
																																					case 41:
																																						goto IL_0628;
																																					case 84:
																																						goto IL_067c;
																																					case 168:
																																						goto IL_068a;
																																					case 82:
																																						goto IL_069d;
																																					case 48:
																																					case 59:
																																						goto IL_06ab;
																																					case 37:
																																						goto IL_06b9;
																																					case 13:
																																					case 30:
																																						goto IL_06c4;
																																					case 149:
																																						goto IL_06e2;
																																					case 114:
																																						goto IL_06f0;
																																					case 136:
																																					case 151:
																																						goto IL_070c;
																																					case 141:
																																						goto IL_071a;
																																					case 63:
																																					case 103:
																																						goto IL_0725;
																																					case 110:
																																						goto IL_0733;
																																					case 12:
																																					case 105:
																																						goto IL_0741;
																																					case 52:
																																						goto IL_075a;
																																					case 135:
																																						goto IL_0768;
																																					case 38:
																																						goto IL_0776;
																																					case 89:
																																					case 119:
																																						goto IL_0789;
																																					case 29:
																																						goto IL_07c9;
																																					case 93:
																																						goto IL_07dd;
																																					case 169:
																																						goto IL_07f0;
																																					case 154:
																																						goto IL_07fe;
																																					case 112:
																																					case 121:
																																						goto IL_080c;
																																					case 83:
																																						goto IL_0835;
																																					case 145:
																																						goto IL_084e;
																																					case 137:
																																						goto IL_085c;
																																					case 113:
																																					case 118:
																																						goto IL_0867;
																																					case 92:
																																						goto IL_0872;
																																					case 9:
																																					case 97:
																																						goto IL_0880;
																																					case 70:
																																						goto IL_088e;
																																					case 107:
																																						goto IL_08a6;
																																					case 24:
																																						goto IL_08b4;
																																					case 33:
																																					case 53:
																																						goto IL_08d5;
																																					case 166:
																																						goto IL_0914;
																																					case 152:
																																						goto IL_0930;
																																					case 140:
																																						goto IL_093b;
																																					case 98:
																																					case 147:
																																						goto IL_0946;
																																					case 143:
																																						goto IL_096f;
																																					case 128:
																																						goto IL_097d;
																																					case 25:
																																						goto IL_098d;
																																					case 34:
																																						goto IL_0998;
																																					case 75:
																																					case 138:
																																						goto IL_09a3;
																																					case 0:
																																					case 2:
																																					case 3:
																																					case 5:
																																					case 6:
																																					case 8:
																																					case 14:
																																					case 16:
																																					case 20:
																																					case 27:
																																					case 35:
																																					case 44:
																																					case 51:
																																					case 55:
																																					case 60:
																																					case 74:
																																					case 76:
																																					case 81:
																																					case 85:
																																					case 87:
																																					case 96:
																																					case 99:
																																					case 101:
																																					case 116:
																																					case 130:
																																					case 142:
																																					case 144:
																																					case 146:
																																					case 150:
																																					case 157:
																																					case 160:
																																					case 162:
																																					case 164:
																																					case 165:
																																					case 167:
																																						goto end_IL_034c;
																																					case 19:
																																					case 23:
																																					case 32:
																																					case 47:
																																					case 49:
																																					case 50:
																																					case 57:
																																					case 69:
																																					case 73:
																																					case 78:
																																					case 88:
																																					case 90:
																																					case 115:
																																					case 123:
																																					case 129:
																																					case 133:
																																					case 134:
																																					case 159:
																																					case 163:
																																						goto end_IL_02cf;
																																					case 148:
																																						goto end_IL_09cb;
																																					case 7:
																																						goto end_IL_09de;
																																					case 122:
																																						goto end_IL_09e8;
																																					case 100:
																																						goto end_IL_09f3;
																																					case 109:
																																					case 153:
																																						goto end_IL_0a03;
																																					case 117:
																																						goto end_IL_0a13;
																																					case 54:
																																						goto end_IL_0a23;
																																					case 131:
																																						goto end_IL_0a33;
																																					case 64:
																																						goto end_IL_0a43;
																																					case 65:
																																						goto end_IL_0a4e;
																																					case 21:
																																					case 46:
																																						goto IL_0a69;
																																					}
																																					continue;
																																					end_IL_02cf:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_03c6;
																															continue;
																															end_IL_034c:
																															break;
																															IL_034c:;
																														}
																														break;
																														IL_035c:;
																													}
																													break;
																												}
																												goto IL_04f3;
																												IL_054b:
																												num5--;
																												goto end_IL_03c6;
																												IL_04f3:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																												goto IL_0537;
																												IL_0537:
																												array[num5 - 2] = 0;
																												goto IL_054b;
																											}
																											break;
																										}
																										goto IL_0404;
																										IL_04dd:
																										array[num5 - 2] = 0;
																										goto IL_0571;
																										IL_0404:
																										if (12 < b)
																										{
																											break;
																										}
																										goto IL_0412;
																										IL_0412:
																										if (12 > b)
																										{
																											num = 81;
																											break;
																										}
																										goto IL_042b;
																										IL_0571:
																										num5--;
																										goto end_IL_03c6;
																										IL_042b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 108;
																										goto IL_04dd;
																									}
																									break;
																								}
																								goto IL_0476;
																								IL_055e:
																								num5 -= 2;
																								goto end_IL_03c6;
																								IL_0476:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_055e;
																							}
																							break;
																						}
																						goto IL_03f1;
																						IL_068a:
																						ptr2 += 8;
																						goto end_IL_03c6;
																						IL_03f1:
																						if (15 < b)
																						{
																							goto IL_0584;
																						}
																						goto IL_05da;
																						IL_0584:
																						if (16 >= b)
																						{
																							goto IL_058f;
																						}
																						goto IL_05b9;
																						IL_058f:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_059d;
																						IL_059d:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_03c6;
																						IL_05b9:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_05c7;
																						IL_05c7:
																						if (17 <= b)
																						{
																						}
																						break;
																						IL_05da:
																						if (15 <= b)
																						{
																							goto IL_05e5;
																						}
																						goto IL_05f8;
																						IL_05e5:
																						num5--;
																						goto end_IL_03c6;
																						IL_05f8:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_0606;
																						IL_0606:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0614;
																						IL_0614:
																						array[num5 - 2] = 0;
																						goto IL_0628;
																						IL_0628:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)CreationTimeUtcVARFLAGFUIDEFAULT[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_067c;
																						IL_067c:
																						num5--;
																						goto IL_068a;
																					}
																					break;
																				}
																				goto IL_069d;
																				IL_098d:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0998;
																				IL_069d:
																				if (9 <= b)
																				{
																					goto end_IL_03c6;
																				}
																				goto IL_06ab;
																				IL_06ab:
																				if (4 >= b)
																				{
																					goto IL_06b9;
																				}
																				goto IL_084e;
																				IL_06b9:
																				if (4 <= b)
																				{
																					goto IL_06c4;
																				}
																				num = 151;
																				goto IL_070c;
																				IL_06c4:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_06e2;
																				IL_06e2:
																				ptr2 += 8;
																				goto IL_06f0;
																				IL_06f0:
																				num5--;
																				goto end_IL_03c6;
																				IL_0998:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_09a3;
																				IL_070c:
																				if (2 >= b)
																				{
																					goto IL_071a;
																				}
																				goto IL_07f0;
																				IL_071a:
																				if (2 > b)
																				{
																					goto IL_0725;
																				}
																				goto IL_0789;
																				IL_0725:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0733;
																				IL_0733:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0741;
																				IL_0741:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_075a;
																				IL_075a:
																				array[num5] = 0;
																				goto IL_0768;
																				IL_0768:
																				num5++;
																				goto IL_0776;
																				IL_0776:
																				ptr2 += 8;
																				goto end_IL_03c6;
																				IL_0789:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_07c9;
																				IL_07c9:
																				array[num5 - 2] = 0;
																				goto IL_07dd;
																				IL_07dd:
																				num5--;
																				goto end_IL_03c6;
																				IL_07f0:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_07fe;
																				IL_07fe:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_080c;
																				IL_080c:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0835;
																				IL_0835:
																				array[num5 - 1] = 5;
																				goto end_IL_03c6;
																				IL_084e:
																				if (6 >= b)
																				{
																					goto IL_085c;
																				}
																				goto IL_0930;
																				IL_085c:
																				if (6 > b)
																				{
																					goto IL_0867;
																				}
																				goto IL_08d5;
																				IL_0867:
																				if (5 < b)
																				{
																					num = 160;
																					break;
																				}
																				goto IL_0872;
																				IL_0872:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0880;
																				IL_0880:
																				array[num5] = 5;
																				goto IL_088e;
																				IL_088e:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_08a6;
																				IL_08a6:
																				num5++;
																				goto IL_08b4;
																				IL_08b4:
																				ptr2 += 8;
																				goto end_IL_03c6;
																				IL_09a3:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_03c6;
																				IL_08d5:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0914;
																				IL_0914:
																				num5 -= 3;
																				num = 23;
																				goto end_IL_03c6;
																				IL_0930:
																				if (7 >= b)
																				{
																					goto IL_093b;
																				}
																				goto IL_098d;
																				IL_093b:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0946;
																				IL_0946:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_096f;
																				IL_096f:
																				ptr2 += 8;
																				goto IL_097d;
																				IL_097d:
																				num5--;
																				goto end_IL_03c6;
																			}
																			break;
																			IL_03b6:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_03c6:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0a69;
													IL_0a69:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_09cb:
													break;
												}
												continue;
												end_IL_09de:
												break;
											}
											continue;
											end_IL_09e8:
											break;
										}
										continue;
										end_IL_09f3:
										break;
									}
									continue;
									end_IL_0a03:
									break;
								}
								continue;
								end_IL_0a13:
								break;
							}
							continue;
							end_IL_0a23:
							break;
						}
						continue;
						end_IL_0a33:
						break;
					}
					continue;
					end_IL_0a43:
					break;
				}
				continue;
				end_IL_0a4e:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_0)
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetClientContextSinkgetExceptionType.ReadBytesOnlyReferenceRegistered);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0277:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_024d:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_0234:
																							array[num5] = 0;
																							num = 81;
																							while (true)
																							{
																								IL_020f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_0203:
																									array2[num5] = null;
																									while (true)
																									{
																										IL_01ea:
																										num5++;
																										num = 114;
																										while (true)
																										{
																											if (num != 114)
																											{
																												if (num != 1095)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 107:
																													goto IL_01ea;
																												case 26:
																													goto IL_0203;
																												case 81:
																													goto IL_020f;
																												case 17:
																												case 22:
																													goto IL_0234;
																												case 36:
																													goto IL_024d;
																												case 60:
																													goto end_IL_024d;
																												case 30:
																													goto end_IL_025a;
																												case 71:
																													goto IL_0277;
																												case 67:
																													goto end_IL_0277;
																												case 11:
																												case 98:
																													goto end_IL_0287;
																												case 34:
																												case 54:
																													goto IL_02b0;
																												case 40:
																												case 57:
																													goto IL_02bb;
																												case 33:
																												case 41:
																													goto IL_02c6;
																												case 5:
																													goto IL_02d4;
																												case 70:
																													goto IL_02e7;
																												case 78:
																													goto IL_02f7;
																												case 7:
																												case 24:
																													goto IL_0305;
																												case 9:
																												case 93:
																													goto IL_0321;
																												case 31:
																													goto IL_0383;
																												case 59:
																												case 100:
																													goto IL_0396;
																												case 65:
																													goto end_IL_01d7;
																												case 8:
																												case 58:
																													goto IL_03ac;
																												case 14:
																													goto IL_03ba;
																												case 62:
																												case 91:
																													goto IL_03c8;
																												case 15:
																												case 63:
																													goto IL_03ef;
																												case 44:
																													goto IL_041d;
																												case 64:
																												case 97:
																													goto IL_0428;
																												case 46:
																													goto IL_0436;
																												case 86:
																													goto IL_0449;
																												case 49:
																												case 96:
																													goto IL_0457;
																												case 102:
																													goto IL_046f;
																												case 0:
																													goto IL_047d;
																												case 99:
																													goto IL_048b;
																												case 104:
																													goto IL_049e;
																												case 2:
																													goto IL_04a9;
																												case 21:
																												case 89:
																													goto IL_04b7;
																												case 12:
																													goto IL_04f7;
																												case 1:
																													goto IL_050b;
																												case 35:
																												case 90:
																													goto IL_0530;
																												case 18:
																													goto IL_053e;
																												case 20:
																												case 72:
																													goto IL_0549;
																												case 43:
																													goto IL_056c;
																												case 16:
																													goto IL_057a;
																												case 4:
																													goto IL_0588;
																												case 106:
																													goto IL_0598;
																												case 28:
																													goto IL_05a6;
																												case 10:
																												case 19:
																												case 25:
																												case 29:
																												case 39:
																												case 47:
																												case 48:
																												case 50:
																												case 51:
																												case 52:
																												case 53:
																												case 68:
																												case 73:
																												case 76:
																												case 83:
																												case 85:
																												case 87:
																												case 94:
																												case 95:
																												case 105:
																													goto end_IL_0267;
																												case 13:
																												case 23:
																												case 27:
																												case 32:
																												case 37:
																												case 38:
																												case 42:
																												case 66:
																												case 74:
																												case 75:
																												case 84:
																												case 88:
																												case 92:
																													goto end_IL_0297;
																												case 45:
																													goto end_IL_05d9;
																												case 61:
																													goto end_IL_05ec;
																												case 101:
																													goto end_IL_05f6;
																												case 79:
																													goto end_IL_0601;
																												case 6:
																												case 80:
																													goto end_IL_0616;
																												case 69:
																													goto end_IL_0626;
																												case 82:
																												case 103:
																													goto end_IL_0636;
																												case 55:
																													goto end_IL_0646;
																												case 56:
																													goto end_IL_0656;
																												case 3:
																												case 77:
																													goto IL_0671;
																												}
																												continue;
																											}
																											ptr2 += 8;
																											goto end_IL_0297;
																											continue;
																											end_IL_01d7:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_03a1;
																					}
																					num = 59;
																					goto IL_0396;
																					IL_0449:
																					if (3 > b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_0457;
																					IL_0457:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0297;
																					IL_0396:
																					if (2 >= b)
																					{
																						goto IL_03a1;
																					}
																					goto IL_041d;
																					IL_03a1:
																					if (2 > b)
																					{
																						goto IL_03ac;
																					}
																					goto IL_03ef;
																					IL_03ac:
																					if (1 < b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_03ba;
																					IL_03ba:
																					if (1 > b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_03c8;
																					IL_03c8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 102;
																					goto IL_046f;
																					IL_046f:
																					array[num5] = 0;
																					goto IL_047d;
																					IL_047d:
																					num5++;
																					goto IL_048b;
																					IL_048b:
																					ptr2 += 8;
																					goto end_IL_0297;
																					IL_03ef:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0598;
																					IL_0598:
																					ptr2 += 8;
																					goto IL_05a6;
																					IL_05a6:
																					num5--;
																					goto end_IL_0297;
																					IL_041d:
																					if (3 < b)
																					{
																						goto IL_0428;
																					}
																					goto IL_0449;
																					IL_0428:
																					if (4 < b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_0436;
																					IL_0436:
																					if (4 <= b)
																					{
																						goto end_IL_0297;
																					}
																					goto end_IL_0267;
																					continue;
																					end_IL_024d:
																					break;
																				}
																				continue;
																			}
																			goto IL_02b0;
																			IL_057a:
																			num5++;
																			goto IL_0588;
																			IL_02b0:
																			if (8 < b)
																			{
																				goto IL_02bb;
																			}
																			goto IL_02e7;
																			IL_02bb:
																			if (9 < b)
																			{
																				goto IL_02c6;
																			}
																			goto IL_02f7;
																			IL_02c6:
																			if (10 < b)
																			{
																				goto end_IL_0267;
																			}
																			goto IL_02d4;
																			IL_02d4:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_0267;
																			IL_02f7:
																			if (9 > b)
																			{
																				goto end_IL_0267;
																			}
																			goto IL_0305;
																			IL_0305:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0297;
																			IL_02e7:
																			if (8 <= b)
																			{
																				goto IL_0321;
																			}
																			goto IL_049e;
																			IL_0321:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0383;
																			IL_0383:
																			num5 -= 2;
																			goto end_IL_0297;
																			IL_049e:
																			if (6 >= b)
																			{
																				goto IL_04a9;
																			}
																			num = 90;
																			goto IL_0530;
																			IL_04a9:
																			if (6 > b)
																			{
																				goto end_IL_0267;
																			}
																			goto IL_04b7;
																			IL_04b7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04f7;
																			IL_04f7:
																			array[num5 - 2] = 0;
																			goto IL_050b;
																			IL_050b:
																			num5--;
																			num = 88;
																			goto end_IL_0297;
																			IL_0588:
																			ptr2 += 8;
																			goto end_IL_0297;
																			IL_0530:
																			if (7 < b)
																			{
																				goto end_IL_0267;
																			}
																			goto IL_053e;
																			IL_053e:
																			if (7 > b)
																			{
																				goto end_IL_0267;
																			}
																			goto IL_0549;
																			IL_0549:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_056c;
																			IL_056c:
																			array[num5] = 0;
																			goto IL_057a;
																			continue;
																			end_IL_025a:
																			break;
																		}
																		continue;
																		end_IL_0267:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0297;
																continue;
																end_IL_0277:
																break;
															}
															continue;
															end_IL_0287:
															break;
														}
														continue;
														end_IL_0297:
														break;
													}
													continue;
												}
												goto IL_0671;
												IL_0671:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d9:
												break;
											}
											continue;
											end_IL_05ec:
											break;
										}
										continue;
										end_IL_05f6:
										break;
									}
									continue;
									end_IL_0601:
									break;
								}
								continue;
								end_IL_0616:
								break;
							}
							continue;
							end_IL_0626:
							break;
						}
						continue;
						end_IL_0636:
						break;
					}
					continue;
					end_IL_0646:
					break;
				}
				continue;
				end_IL_0656:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_0, int int_1)
	{
		int num = 53;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										num = 98;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadOnlyDictionaryKeyCollectionIStoreBindingResultBoundVersion.setConfigurationFileBufferHeight);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0294:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				if (6 >= b)
																				{
																					while (true)
																					{
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0254:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0247:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0234:
																												if (1 >= b)
																												{
																													num = 129;
																													while (true)
																													{
																														if (num != 129)
																														{
																															if (num != 1110)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 122:
																																goto IL_0234;
																															case 26:
																																goto IL_0247;
																															case 44:
																															case 79:
																																goto IL_0254;
																															case 68:
																																goto end_IL_0254;
																															case 45:
																																goto end_IL_0264;
																															case 40:
																																goto end_IL_0274;
																															case 75:
																																goto IL_0294;
																															case 33:
																																goto end_IL_0294;
																															case 15:
																															case 81:
																																goto end_IL_02a4;
																															case 37:
																															case 60:
																																goto IL_02bf;
																															case 59:
																																goto IL_02e8;
																															case 95:
																																goto IL_0304;
																															case 56:
																																goto IL_0312;
																															case 17:
																															case 77:
																																goto IL_0320;
																															case 96:
																																goto IL_0365;
																															case 0:
																															case 7:
																																goto IL_0370;
																															case 25:
																																goto IL_0383;
																															case 67:
																															case 70:
																																goto IL_0391;
																															case 27:
																																goto IL_03d1;
																															case 28:
																																goto IL_03e5;
																															case 102:
																																goto IL_03f8;
																															case 46:
																																goto IL_040c;
																															case 110:
																																goto IL_041f;
																															case 51:
																															case 86:
																																goto IL_042d;
																															case 57:
																																goto IL_043b;
																															case 32:
																																goto IL_045e;
																															case 11:
																																goto end_IL_0221;
																															case 82:
																																goto IL_0476;
																															case 121:
																																goto IL_0489;
																															case 23:
																															case 85:
																																goto IL_04b8;
																															case 22:
																																goto IL_04f8;
																															case 109:
																																goto IL_050c;
																															case 103:
																																goto IL_051f;
																															case 97:
																																goto IL_052d;
																															case 47:
																															case 80:
																																goto IL_0538;
																															case 2:
																																goto IL_0546;
																															case 105:
																																goto IL_0573;
																															case 93:
																																goto IL_0581;
																															case 12:
																															case 76:
																																goto IL_0594;
																															case 43:
																																goto IL_059f;
																															case 18:
																															case 62:
																																goto IL_05ad;
																															case 115:
																																goto IL_05c6;
																															case 100:
																																goto IL_05d4;
																															case 101:
																																goto IL_05e2;
																															case 91:
																															case 106:
																																goto IL_05f5;
																															case 89:
																																goto IL_0603;
																															case 14:
																															case 74:
																																goto IL_0611;
																															case 19:
																																goto IL_0651;
																															case 88:
																																goto IL_0665;
																															case 92:
																																goto IL_0678;
																															case 63:
																															case 87:
																																goto IL_0683;
																															case 120:
																																goto IL_068e;
																															case 65:
																															case 111:
																																goto IL_0699;
																															case 118:
																																goto IL_06b2;
																															case 54:
																															case 61:
																																goto IL_06bd;
																															case 3:
																															case 5:
																															case 8:
																															case 20:
																															case 24:
																															case 30:
																															case 31:
																															case 38:
																															case 39:
																															case 42:
																															case 49:
																															case 50:
																															case 58:
																															case 64:
																															case 72:
																															case 73:
																															case 90:
																															case 94:
																															case 99:
																															case 113:
																															case 114:
																															case 117:
																																goto end_IL_0284;
																															case 36:
																																goto IL_06f0;
																															case 78:
																																goto IL_06fe;
																															case 41:
																																goto IL_070c;
																															case 1:
																															case 4:
																															case 6:
																															case 10:
																															case 29:
																															case 35:
																															case 55:
																															case 69:
																															case 71:
																															case 83:
																															case 107:
																															case 112:
																															case 119:
																																goto end_IL_02b4;
																															case 16:
																																goto end_IL_071a;
																															case 98:
																																goto end_IL_072d;
																															case 34:
																																goto end_IL_0737;
																															case 9:
																																goto end_IL_0742;
																															case 66:
																																goto end_IL_0760;
																															case 108:
																															case 116:
																																goto end_IL_0775;
																															case 48:
																																goto end_IL_0785;
																															case 84:
																															case 104:
																																goto end_IL_0795;
																															case 52:
																																goto end_IL_07a5;
																															case 53:
																																goto end_IL_07b5;
																															case 13:
																															case 21:
																																goto IL_07d0;
																															}
																															continue;
																														}
																														if (1 <= b)
																														{
																															num = 117;
																														}
																														goto end_IL_0284;
																														continue;
																														end_IL_0221:
																														break;
																													}
																													break;
																												}
																												goto IL_0304;
																												IL_03f8:
																												array[num5 - 2] = 0;
																												goto IL_040c;
																												IL_040c:
																												num5--;
																												goto end_IL_02b4;
																												IL_0304:
																												if (2 < b)
																												{
																													goto end_IL_0284;
																												}
																												goto IL_0312;
																												IL_0312:
																												if (2 > b)
																												{
																													goto end_IL_0284;
																												}
																												goto IL_0320;
																												IL_0320:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_03f8;
																											}
																											break;
																										}
																										goto IL_02bf;
																										IL_0489:
																										num5--;
																										goto end_IL_02b4;
																										IL_02bf:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_02e8;
																										IL_02e8:
																										ptr2 += 8;
																										num = 121;
																										goto IL_0489;
																									}
																									goto IL_0468;
																								}
																								goto IL_0365;
																								IL_03e5:
																								num5--;
																								goto end_IL_02b4;
																								IL_0365:
																								if (4 < b)
																								{
																									goto IL_0370;
																								}
																								goto IL_0383;
																								IL_0370:
																								if (5 < b)
																								{
																									goto end_IL_0284;
																								}
																								goto IL_041f;
																								IL_041f:
																								if (5 > b)
																								{
																									goto end_IL_0284;
																								}
																								goto IL_042d;
																								IL_042d:
																								array[num5] = 0;
																								goto IL_043b;
																								IL_043b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_045e;
																								IL_045e:
																								array2[num5] = null;
																								goto IL_0468;
																								IL_0468:
																								num5++;
																								goto IL_0476;
																								IL_0476:
																								ptr2 += 8;
																								goto end_IL_02b4;
																								IL_0383:
																								if (4 > b)
																								{
																									goto end_IL_0284;
																								}
																								goto IL_0391;
																								IL_0391:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03d1;
																								IL_03d1:
																								array[num5 - 2] = 0;
																								goto IL_03e5;
																								continue;
																								end_IL_0254:
																								break;
																							}
																							continue;
																						}
																						goto IL_04b8;
																						IL_050c:
																						num5--;
																						goto end_IL_02b4;
																						IL_04b8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04f8;
																						IL_04f8:
																						array[num5 - 2] = 0;
																						goto IL_050c;
																						continue;
																						end_IL_0264:
																						break;
																					}
																					continue;
																				}
																				goto IL_051f;
																				IL_06bd:
																				num5--;
																				goto end_IL_02b4;
																				IL_051f:
																				if (9 >= b)
																				{
																					goto IL_052d;
																				}
																				goto IL_0678;
																				IL_052d:
																				if (9 <= b)
																				{
																					goto IL_0538;
																				}
																				goto IL_0594;
																				IL_0538:
																				array[num5] = 0;
																				goto IL_0546;
																				IL_0546:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)getBestFitMappingFreeze[*(int*)(ptr2 + num3)])();
																				num = 105;
																				goto IL_0573;
																				IL_0573:
																				num5++;
																				goto IL_0581;
																				IL_0581:
																				ptr2 += 8;
																				goto end_IL_02b4;
																				IL_0594:
																				if (7 >= b)
																				{
																					goto IL_059f;
																				}
																				goto IL_05f5;
																				IL_059f:
																				if (7 > b)
																				{
																					goto end_IL_0284;
																				}
																				goto IL_05ad;
																				IL_05ad:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_05c6;
																				IL_05c6:
																				array[num5] = 0;
																				goto IL_05d4;
																				IL_05d4:
																				num5++;
																				goto IL_05e2;
																				IL_05e2:
																				ptr2 += 8;
																				goto end_IL_02b4;
																				IL_05f5:
																				if (8 < b)
																				{
																					goto end_IL_0284;
																				}
																				goto IL_0603;
																				IL_0603:
																				if (8 > b)
																				{
																					goto end_IL_0284;
																				}
																				goto IL_0611;
																				IL_0611:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0651;
																				IL_0651:
																				array[num5 - 2] = 0;
																				goto IL_0665;
																				IL_0665:
																				num5--;
																				goto end_IL_02b4;
																				IL_0678:
																				if (10 < b)
																				{
																					goto IL_0683;
																				}
																				goto IL_06b2;
																				IL_0683:
																				if (11 < b)
																				{
																					goto end_IL_0284;
																				}
																				goto IL_068e;
																				IL_068e:
																				if (11 > b)
																				{
																					goto end_IL_0284;
																				}
																				goto IL_0699;
																				IL_0699:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02b4;
																				IL_06b2:
																				if (10 > b)
																				{
																					goto end_IL_0284;
																				}
																				goto IL_06bd;
																				continue;
																				end_IL_0274:
																				break;
																			}
																			continue;
																			end_IL_0284:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06f0;
																	IL_070c:
																	ptr2 += 8;
																	goto end_IL_02b4;
																	IL_06fe:
																	num5++;
																	goto IL_070c;
																	IL_06f0:
																	array[num5] = 0;
																	goto IL_06fe;
																	continue;
																	end_IL_0294:
																	break;
																}
																continue;
																end_IL_02a4:
																break;
															}
															continue;
															end_IL_02b4:
															break;
														}
														continue;
													}
													goto IL_07d0;
													IL_07d0:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_071a:
													break;
												}
												continue;
												end_IL_072d:
												break;
											}
											continue;
											end_IL_0737:
											break;
										}
										continue;
										end_IL_0742:
										break;
									}
									continue;
									end_IL_0760:
									break;
								}
								continue;
								end_IL_0775:
								break;
							}
							continue;
							end_IL_0785:
							break;
						}
						continue;
						end_IL_0795:
						break;
					}
					continue;
					end_IL_07a5:
					break;
				}
				continue;
				end_IL_07b5:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 21;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setApplyToMembersConsoleApplication.HexNumberSX);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 61;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_03a7:
																		if (b >= 1)
																		{
																			goto IL_022a;
																		}
																		goto IL_0376;
																		IL_0376:
																		while (true)
																		{
																			IL_0376_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 130;
																			while (true)
																			{
																				if (num != 130)
																				{
																					if (num != 1111)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 32:
																						goto IL_022a;
																					case 114:
																						goto IL_0238;
																					case 40:
																					case 90:
																						goto IL_0246;
																					case 0:
																					case 53:
																						goto IL_0251;
																					case 107:
																						goto IL_025c;
																					case 109:
																						goto IL_0278;
																					case 58:
																						goto IL_0286;
																					case 19:
																						goto IL_0299;
																					case 52:
																						goto IL_02a7;
																					case 74:
																						goto IL_02b5;
																					case 82:
																						goto IL_02c3;
																					case 93:
																						goto IL_02d6;
																					case 26:
																					case 71:
																						goto IL_02e4;
																					case 27:
																					case 29:
																						goto IL_02ef;
																					case 54:
																					case 108:
																						goto IL_02fa;
																					case 97:
																						goto IL_0305;
																					case 99:
																						goto IL_0315;
																					case 106:
																						goto IL_0325;
																					case 116:
																						goto IL_0335;
																					case 9:
																					case 122:
																						goto IL_0345;
																					case 98:
																						goto IL_0350;
																					case 91:
																						goto IL_035b;
																					case 45:
																						goto IL_036b;
																					case 22:
																					case 23:
																					case 24:
																					case 28:
																					case 33:
																					case 35:
																					case 37:
																					case 38:
																					case 65:
																					case 70:
																					case 77:
																					case 78:
																					case 79:
																					case 81:
																					case 89:
																					case 92:
																					case 94:
																					case 102:
																					case 110:
																					case 111:
																					case 112:
																					case 115:
																						goto IL_0376_2;
																					case 101:
																						goto IL_03a7;
																					case 80:
																						goto end_IL_03a7;
																					case 10:
																					case 64:
																						goto end_IL_03b7;
																					case 41:
																					case 113:
																						goto IL_03d2;
																					case 7:
																					case 47:
																						goto IL_03e5;
																					case 13:
																					case 56:
																						goto IL_0401;
																					case 46:
																						goto IL_0415;
																					case 15:
																						goto IL_0469;
																					case 48:
																						goto IL_0477;
																					case 49:
																					case 83:
																						goto IL_048a;
																					case 88:
																						goto end_IL_0217;
																					case 69:
																						goto IL_04de;
																					case 20:
																					case 76:
																						goto IL_04f1;
																					case 57:
																						goto IL_04ff;
																					case 1:
																						goto IL_0522;
																					case 96:
																						goto IL_052c;
																					case 50:
																						goto IL_053a;
																					case 34:
																					case 105:
																						goto IL_054d;
																					case 104:
																						goto IL_0576;
																					case 30:
																						goto IL_058d;
																					case 43:
																					case 100:
																						goto IL_05a0;
																					case 59:
																						goto IL_05e0;
																					case 103:
																						goto IL_05f4;
																					case 51:
																					case 84:
																						goto IL_0610;
																					case 44:
																						goto IL_0629;
																					case 66:
																						goto IL_0637;
																					case 25:
																						goto IL_0645;
																					case 31:
																					case 120:
																						goto IL_0658;
																					case 121:
																						goto IL_0698;
																					case 75:
																						goto IL_06b5;
																					case 117:
																					case 118:
																						goto IL_06c8;
																					case 87:
																						goto IL_0708;
																					case 119:
																						goto IL_071c;
																					case 123:
																						goto IL_073a;
																					case 42:
																						goto IL_0748;
																					case 4:
																					case 12:
																					case 14:
																					case 16:
																					case 39:
																					case 55:
																					case 61:
																					case 62:
																					case 67:
																					case 72:
																					case 73:
																					case 86:
																					case 95:
																						goto end_IL_03c7;
																					case 2:
																						goto end_IL_0756;
																					case 11:
																						goto end_IL_0769;
																					case 68:
																						goto end_IL_077c;
																					case 17:
																						goto end_IL_0787;
																					case 85:
																						goto end_IL_079c;
																					case 18:
																					case 63:
																						goto end_IL_07b1;
																					case 3:
																						goto end_IL_07c1;
																					case 21:
																						goto end_IL_07d1;
																					case 60:
																						goto end_IL_07e1;
																					case 5:
																						goto end_IL_07f1;
																					case 6:
																						goto end_IL_07fc;
																					case 8:
																					case 36:
																						goto IL_0817;
																					}
																					continue;
																				}
																				array[num5] = 0;
																				goto IL_073a;
																				IL_073a:
																				num5++;
																				goto IL_0748;
																				IL_0748:
																				ptr2 += 8;
																				goto end_IL_03c7;
																				continue;
																				end_IL_0217:
																				break;
																			}
																			break;
																		}
																		goto IL_04ca;
																		IL_022a:
																		if (b <= 11)
																		{
																			goto IL_0238;
																		}
																		goto IL_0376;
																		IL_0238:
																		if (6 < b)
																		{
																			goto IL_0246;
																		}
																		goto IL_02d6;
																		IL_0246:
																		if (9 < b)
																		{
																			goto IL_0251;
																		}
																		goto IL_0299;
																		IL_0251:
																		if (10 >= b)
																		{
																			goto IL_025c;
																		}
																		goto IL_0278;
																		IL_025c:
																		if (10 > b)
																		{
																			num = 115;
																			goto IL_0376;
																		}
																		goto IL_03d2;
																		IL_05e0:
																		array[num5 - 2] = 0;
																		goto IL_05f4;
																		IL_03d2:
																		num5--;
																		goto end_IL_03c7;
																		IL_0278:
																		if (11 >= b)
																		{
																			goto IL_0286;
																		}
																		goto IL_0376;
																		IL_0286:
																		if (11 > b)
																		{
																			goto IL_0376;
																		}
																		goto IL_03e5;
																		IL_03e5:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_03c7;
																		IL_0299:
																		if (9 > b)
																		{
																			goto IL_02a7;
																		}
																		goto IL_0401;
																		IL_02a7:
																		if (7 < b)
																		{
																			goto IL_02b5;
																		}
																		goto IL_0335;
																		IL_02b5:
																		if (8 >= b)
																		{
																			goto IL_02c3;
																		}
																		goto IL_0376;
																		IL_02c3:
																		if (8 > b)
																		{
																			goto IL_0376;
																		}
																		goto IL_048a;
																		IL_048a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_04ca;
																		IL_04ca:
																		array[num5 - 2] = 0;
																		goto IL_04de;
																		IL_04de:
																		num5--;
																		goto end_IL_03c7;
																		IL_0335:
																		if (7 > b)
																		{
																			goto IL_0376;
																		}
																		num = 84;
																		goto IL_0610;
																		IL_05f4:
																		num5--;
																		goto end_IL_03c7;
																		IL_0610:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		goto IL_0629;
																		IL_0629:
																		array[num5] = 0;
																		goto IL_0637;
																		IL_0637:
																		num5++;
																		goto IL_0645;
																		IL_0645:
																		ptr2 += 8;
																		goto end_IL_03c7;
																		IL_0401:
																		array[num5 - 2] = 0;
																		goto IL_0415;
																		IL_0415:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)FullDateTimePatternApplication[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																		goto IL_0469;
																		IL_0469:
																		num5--;
																		goto IL_0477;
																		IL_0477:
																		ptr2 += 8;
																		goto end_IL_03c7;
																		IL_02d6:
																		if (6 > b)
																		{
																			goto IL_02e4;
																		}
																		goto IL_05a0;
																		IL_02e4:
																		if (3 < b)
																		{
																			goto IL_02ef;
																		}
																		goto IL_0325;
																		IL_02ef:
																		if (4 < b)
																		{
																			goto IL_02fa;
																		}
																		goto IL_0315;
																		IL_02fa:
																		if (5 >= b)
																		{
																			goto IL_0305;
																		}
																		goto IL_0376;
																		IL_0305:
																		if (5 > b)
																		{
																			goto IL_0376;
																		}
																		goto IL_04f1;
																		IL_04f1:
																		array[num5] = 0;
																		goto IL_04ff;
																		IL_04ff:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0522;
																		IL_0522:
																		array2[num5] = null;
																		goto IL_052c;
																		IL_052c:
																		num5++;
																		goto IL_053a;
																		IL_053a:
																		ptr2 += 8;
																		goto end_IL_03c7;
																		IL_0315:
																		if (4 > b)
																		{
																			goto IL_0376;
																		}
																		goto IL_0658;
																		IL_0658:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0698;
																		IL_0698:
																		array[num5 - 2] = 0;
																		num = 75;
																		goto IL_06b5;
																		IL_06b5:
																		num5--;
																		goto end_IL_03c7;
																		IL_0325:
																		if (3 > b)
																		{
																			goto IL_0345;
																		}
																		goto IL_054d;
																		IL_0345:
																		if (1 < b)
																		{
																			goto IL_0350;
																		}
																		goto IL_036b;
																		IL_0350:
																		if (2 >= b)
																		{
																			goto IL_035b;
																		}
																		goto IL_0376;
																		IL_035b:
																		if (2 > b)
																		{
																			goto IL_0376;
																		}
																		goto IL_06c8;
																		IL_06c8:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0708;
																		IL_0708:
																		array[num5 - 2] = 0;
																		goto IL_071c;
																		IL_071c:
																		num5--;
																		goto end_IL_03c7;
																		IL_036b:
																		if (1 > b)
																		{
																		}
																		goto IL_0376;
																		IL_054d:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0576;
																		IL_0576:
																		ptr2 += 8;
																		num = 30;
																		goto IL_058d;
																		IL_058d:
																		num5--;
																		goto end_IL_03c7;
																		IL_05a0:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_05e0;
																		continue;
																		end_IL_03a7:
																		break;
																	}
																	continue;
																	end_IL_03b7:
																	break;
																}
																continue;
																end_IL_03c7:
																break;
															}
															continue;
														}
														goto IL_0817;
														IL_0817:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0756:
														break;
													}
													continue;
													end_IL_0769:
													break;
												}
												continue;
												end_IL_077c:
												break;
											}
											continue;
											end_IL_0787:
											break;
										}
										continue;
										end_IL_079c:
										break;
									}
									continue;
									end_IL_07b1:
									break;
								}
								continue;
								end_IL_07c1:
								break;
							}
							continue;
							end_IL_07d1:
							break;
						}
						continue;
						end_IL_07e1:
						break;
					}
					continue;
					end_IL_07f1:
					break;
				}
				continue;
				end_IL_07fc:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0, int int_1)
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref headLowAvailableWaitHandle.setCalendarAddSeconds);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_01e8:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				if (4 >= b)
																				{
																					while (true)
																					{
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01a8:
																								if (2 < b)
																								{
																									num = 94;
																									while (true)
																									{
																										if (num != 94)
																										{
																											if (num != 1075)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 76:
																												goto IL_01a8;
																											case 44:
																												goto end_IL_01a8;
																											case 20:
																												goto end_IL_01bb;
																											case 31:
																												goto end_IL_01c8;
																											case 53:
																												goto IL_01e8;
																											case 81:
																												goto end_IL_01e8;
																											case 46:
																											case 68:
																												goto end_IL_01f8;
																											case 8:
																											case 13:
																												goto IL_021c;
																											case 35:
																												goto IL_0245;
																											case 49:
																												goto IL_0253;
																											case 59:
																												goto IL_0266;
																											case 45:
																											case 54:
																												goto IL_0274;
																											case 4:
																												goto IL_02e2;
																											case 62:
																											case 86:
																												goto end_IL_0195;
																											case 17:
																												goto IL_0303;
																											case 9:
																												goto IL_0316;
																											case 41:
																												goto IL_0324;
																											case 7:
																											case 74:
																												goto IL_0332;
																											case 26:
																												goto IL_0372;
																											case 38:
																												goto IL_0386;
																											case 5:
																												goto IL_0399;
																											case 55:
																											case 85:
																												goto IL_03a7;
																											case 15:
																												goto IL_03b2;
																											case 18:
																											case 24:
																												goto IL_03c0;
																											case 21:
																												goto IL_03ce;
																											case 60:
																												goto IL_03f1;
																											case 0:
																												goto IL_03fb;
																											case 43:
																												goto IL_0409;
																											case 77:
																												goto IL_041c;
																											case 66:
																												goto IL_0427;
																											case 6:
																											case 47:
																												goto IL_0432;
																											case 82:
																												goto IL_044e;
																											case 65:
																												goto IL_0459;
																											case 37:
																												goto IL_0464;
																											case 56:
																											case 69:
																												goto IL_046f;
																											case 1:
																											case 11:
																											case 19:
																											case 33:
																											case 36:
																											case 40:
																											case 48:
																											case 51:
																											case 52:
																											case 57:
																											case 67:
																											case 72:
																											case 75:
																											case 78:
																											case 79:
																											case 84:
																												goto end_IL_01d8;
																											case 39:
																												goto IL_04a7;
																											case 27:
																												goto IL_04b5;
																											case 61:
																												goto IL_04c3;
																											case 3:
																											case 10:
																											case 12:
																											case 14:
																											case 23:
																											case 32:
																											case 34:
																											case 63:
																											case 70:
																											case 71:
																											case 83:
																												goto end_IL_0208;
																											case 28:
																												goto end_IL_04d1;
																											case 16:
																												goto end_IL_04e4;
																											case 25:
																												goto end_IL_04ee;
																											case 73:
																												goto end_IL_04f9;
																											case 2:
																												goto end_IL_050e;
																											case 58:
																											case 64:
																												goto end_IL_0523;
																											case 80:
																												goto end_IL_0533;
																											case 50:
																											case 87:
																												goto end_IL_0543;
																											case 29:
																												goto end_IL_0553;
																											case 30:
																												goto end_IL_0563;
																											case 22:
																											case 42:
																												goto IL_057e;
																											}
																											continue;
																										}
																										goto IL_0316;
																										IL_0372:
																										array[num5 - 2] = 0;
																										goto IL_0386;
																										IL_0386:
																										num5--;
																										goto end_IL_0208;
																										IL_0316:
																										if (3 < b)
																										{
																											goto end_IL_01d8;
																										}
																										goto IL_0324;
																										IL_0324:
																										if (3 > b)
																										{
																											goto end_IL_01d8;
																										}
																										goto IL_0332;
																										IL_0332:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0372;
																										continue;
																										end_IL_0195:
																										break;
																									}
																									goto IL_02f5;
																								}
																								goto IL_0266;
																								IL_02f5:
																								if (1 < b)
																								{
																									goto end_IL_01d8;
																								}
																								goto IL_0303;
																								IL_0303:
																								if (1 > b)
																								{
																								}
																								goto end_IL_01d8;
																								IL_0266:
																								if (2 <= b)
																								{
																									goto IL_0274;
																								}
																								goto IL_02f5;
																								IL_0274:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_02e2;
																								IL_02e2:
																								num5 -= 2;
																								goto end_IL_0208;
																								continue;
																								end_IL_01a8:
																								break;
																							}
																							continue;
																						}
																						num = 13;
																						goto IL_021c;
																						IL_0245:
																						ptr2 += 8;
																						goto IL_0253;
																						IL_0253:
																						num5--;
																						goto end_IL_0208;
																						IL_021c:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0245;
																						continue;
																						end_IL_01bb:
																						break;
																					}
																					continue;
																				}
																				goto IL_0399;
																				IL_046f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0208;
																				IL_0399:
																				if (6 < b)
																				{
																					goto IL_03a7;
																				}
																				goto IL_044e;
																				IL_03a7:
																				if (7 >= b)
																				{
																					goto IL_03b2;
																				}
																				goto IL_041c;
																				IL_03b2:
																				if (7 > b)
																				{
																					goto end_IL_01d8;
																				}
																				goto IL_03c0;
																				IL_03c0:
																				array[num5] = 0;
																				goto IL_03ce;
																				IL_03ce:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03f1;
																				IL_03f1:
																				array2[num5] = null;
																				goto IL_03fb;
																				IL_03fb:
																				num5++;
																				goto IL_0409;
																				IL_0409:
																				ptr2 += 8;
																				goto end_IL_0208;
																				IL_041c:
																				if (8 < b)
																				{
																					goto end_IL_01d8;
																				}
																				goto IL_0427;
																				IL_0427:
																				if (8 > b)
																				{
																					goto end_IL_01d8;
																				}
																				goto IL_0432;
																				IL_0432:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0208;
																				IL_044e:
																				if (6 <= b)
																				{
																					goto end_IL_0208;
																				}
																				goto IL_0459;
																				IL_0459:
																				if (5 < b)
																				{
																					goto end_IL_01d8;
																				}
																				goto IL_0464;
																				IL_0464:
																				if (5 > b)
																				{
																					goto end_IL_01d8;
																				}
																				goto IL_046f;
																				continue;
																				end_IL_01c8:
																				break;
																			}
																			continue;
																			end_IL_01d8:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04a7;
																	IL_04c3:
																	ptr2 += 8;
																	goto end_IL_0208;
																	IL_04b5:
																	num5++;
																	goto IL_04c3;
																	IL_04a7:
																	array[num5] = 0;
																	goto IL_04b5;
																	continue;
																	end_IL_01e8:
																	break;
																}
																continue;
																end_IL_01f8:
																break;
															}
															continue;
															end_IL_0208:
															break;
														}
														continue;
													}
													goto IL_057e;
													IL_057e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04d1:
													break;
												}
												continue;
												end_IL_04e4:
												break;
											}
											continue;
											end_IL_04ee:
											break;
										}
										continue;
										end_IL_04f9:
										break;
									}
									continue;
									end_IL_050e:
									break;
								}
								continue;
								end_IL_0523:
								break;
							}
							continue;
							end_IL_0533:
							break;
						}
						continue;
						end_IL_0543:
						break;
					}
					continue;
					end_IL_0553:
					break;
				}
				continue;
				end_IL_0563:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_0)
	{
		int num = 83;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 82;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 63;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IEnumUnknownGetRuntimeMethods.FLicensedInvalidProgramException);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02a0:
														byte b = *ptr2;
														num = 36;
														while (true)
														{
															IL_0290:
															ptr2++;
															while (true)
															{
																IL_0280:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0263:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0253:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0243:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0233:
																									if (4 >= b)
																									{
																										while (4 <= b)
																										{
																											num = 124;
																											while (num != 124)
																											{
																												if (num != 1105)
																												{
																													goto IL_0394;
																												}
																												switch (num)
																												{
																												case 58:
																													goto IL_0220;
																												case 33:
																												case 108:
																													goto IL_0233;
																												case 1:
																												case 11:
																													goto IL_0243;
																												case 31:
																													goto IL_0253;
																												case 39:
																													goto IL_0263;
																												case 109:
																													goto IL_0270;
																												case 50:
																													goto IL_0280;
																												case 36:
																													goto IL_0290;
																												case 12:
																												case 90:
																													goto IL_02a0;
																												case 59:
																												case 114:
																													goto IL_02b4;
																												case 110:
																													goto IL_02c2;
																												case 19:
																												case 95:
																													goto IL_02d0;
																												case 40:
																												case 105:
																													goto IL_02db;
																												case 32:
																													goto IL_02e9;
																												case 0:
																												case 111:
																													goto IL_02f7;
																												case 23:
																													goto IL_031a;
																												case 9:
																													goto IL_0328;
																												case 25:
																													goto IL_0336;
																												case 75:
																													goto IL_0349;
																												case 4:
																												case 73:
																													goto IL_0354;
																												case 103:
																													goto IL_0394;
																												case 28:
																													goto IL_03a8;
																												case 35:
																												case 57:
																													goto IL_03c9;
																												case 6:
																													goto IL_042b;
																												case 101:
																													goto IL_043e;
																												case 43:
																													goto IL_0449;
																												case 30:
																												case 46:
																													goto IL_0457;
																												case 55:
																													goto IL_0473;
																												case 69:
																													goto IL_047e;
																												case 92:
																													goto IL_04a8;
																												case 84:
																													goto IL_04b6;
																												case 53:
																												case 89:
																													goto IL_04c4;
																												case 86:
																													goto IL_04db;
																												case 67:
																													goto IL_04fe;
																												case 37:
																													goto IL_0508;
																												case 106:
																													goto IL_051f;
																												case 21:
																													goto IL_0532;
																												case 5:
																												case 38:
																													goto IL_0540;
																												case 13:
																												case 102:
																													goto IL_054b;
																												case 94:
																													goto IL_0559;
																												case 14:
																												case 87:
																													goto IL_0567;
																												case 99:
																													goto IL_0590;
																												case 2:
																													goto IL_059e;
																												case 91:
																													goto IL_05b1;
																												case 41:
																												case 70:
																													goto IL_05bf;
																												case 52:
																													goto IL_05d8;
																												case 7:
																													goto IL_05e6;
																												case 45:
																													goto IL_05f4;
																												case 48:
																												case 60:
																													goto IL_0607;
																												case 24:
																												case 71:
																													goto IL_061c;
																												case 42:
																													goto IL_065c;
																												case 104:
																													goto IL_0670;
																												case 3:
																												case 10:
																												case 15:
																												case 18:
																												case 22:
																												case 29:
																												case 34:
																												case 44:
																												case 47:
																												case 49:
																												case 56:
																												case 61:
																												case 65:
																												case 68:
																												case 72:
																												case 80:
																												case 81:
																												case 85:
																												case 93:
																												case 97:
																												case 98:
																												case 113:
																												case 116:
																													goto end_IL_0220;
																												case 8:
																												case 26:
																												case 27:
																												case 51:
																												case 54:
																												case 62:
																												case 74:
																												case 76:
																												case 77:
																												case 88:
																												case 107:
																												case 112:
																												case 115:
																													goto end_IL_020d;
																												case 100:
																													goto end_IL_0693;
																												case 117:
																													goto end_IL_06a6;
																												case 79:
																													goto end_IL_06b0;
																												case 78:
																													goto end_IL_06bb;
																												case 63:
																												case 66:
																													goto end_IL_06d0;
																												case 20:
																													goto end_IL_06e0;
																												case 16:
																												case 96:
																													goto end_IL_06f0;
																												case 82:
																													goto end_IL_0709;
																												case 83:
																													goto end_IL_0719;
																												case 17:
																												case 64:
																													goto IL_073d;
																												}
																												continue;
																												end_IL_020d:
																												break;
																											}
																											goto end_IL_0280;
																											continue;
																											end_IL_0220:
																											break;
																											IL_0220:;
																										}
																										break;
																									}
																									goto IL_04a8;
																									IL_051f:
																									ptr2 += 8;
																									goto end_IL_0280;
																									IL_04a8:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_04b6;
																									IL_04b6:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_04c4;
																									IL_04c4:
																									array[num5] = 0;
																									num = 86;
																									goto IL_04db;
																									IL_04db:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_04fe;
																									IL_04fe:
																									array2[num5] = null;
																									goto IL_0508;
																									IL_0508:
																									num5++;
																									num = 106;
																									goto IL_051f;
																								}
																								break;
																							}
																							goto IL_0532;
																							IL_0607:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0280;
																							IL_0532:
																							if (3 > b)
																							{
																								goto IL_0540;
																							}
																							goto IL_0607;
																							IL_0540:
																							if (1 < b)
																							{
																								goto IL_054b;
																							}
																							goto IL_05b1;
																							IL_054b:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0559;
																							IL_0559:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0567;
																							IL_0567:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0590;
																							IL_0590:
																							ptr2 += 8;
																							goto IL_059e;
																							IL_059e:
																							num5--;
																							goto end_IL_0280;
																							IL_05b1:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_05bf;
																							IL_05bf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_05d8;
																							IL_05d8:
																							array[num5] = 0;
																							goto IL_05e6;
																							IL_05e6:
																							num5++;
																							goto IL_05f4;
																							IL_05f4:
																							ptr2 += 8;
																							goto end_IL_0280;
																						}
																						break;
																					}
																					goto IL_061c;
																					IL_0670:
																					num5--;
																					goto end_IL_0280;
																					IL_061c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_065c;
																					IL_065c:
																					array[num5 - 2] = 0;
																					goto IL_0670;
																				}
																				break;
																			}
																			goto IL_02b4;
																			IL_0473:
																			if (11 < b)
																			{
																				num = 15;
																				break;
																			}
																			goto IL_047e;
																			IL_02b4:
																			if (9 >= b)
																			{
																				goto IL_02c2;
																			}
																			goto IL_043e;
																			IL_02c2:
																			if (9 > b)
																			{
																				goto IL_02d0;
																			}
																			goto IL_03c9;
																			IL_02d0:
																			if (7 < b)
																			{
																				goto IL_02db;
																			}
																			goto IL_0349;
																			IL_02db:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_02e9;
																			IL_02e9:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_02f7;
																			IL_02f7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_031a;
																			IL_031a:
																			array[num5] = 0;
																			goto IL_0328;
																			IL_0328:
																			num5++;
																			goto IL_0336;
																			IL_0336:
																			ptr2 += 8;
																			goto end_IL_0280;
																			IL_0349:
																			if (7 > b)
																			{
																				num = 81;
																				break;
																			}
																			goto IL_0354;
																			IL_0354:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0394;
																			IL_0394:
																			array[num5 - 2] = 0;
																			goto IL_03a8;
																			IL_03a8:
																			num5--;
																			goto end_IL_0280;
																			IL_047e:
																			if (11 > b)
																			{
																				num = 49;
																			}
																			break;
																			IL_03c9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_042b;
																			IL_042b:
																			num5 -= 2;
																			goto end_IL_0280;
																			IL_043e:
																			if (10 >= b)
																			{
																				goto IL_0449;
																			}
																			goto IL_0473;
																			IL_0449:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0457;
																			IL_0457:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0280;
																		}
																		break;
																		IL_0270:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0280:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_073d;
												IL_073d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0693:
												break;
											}
											continue;
											end_IL_06a6:
											break;
										}
										continue;
										end_IL_06b0:
										break;
									}
									continue;
									end_IL_06bb:
									break;
								}
								continue;
								end_IL_06d0:
								break;
							}
							continue;
							end_IL_06e0:
							break;
						}
						continue;
						end_IL_06f0:
						break;
					}
					continue;
					end_IL_0709:
					break;
				}
				continue;
				end_IL_0719:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0, int int_1)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 96;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TryAddApplicationNameValue.MultipleUseNullAuthority);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0230:
																byte b = *ptr2;
																while (true)
																{
																	IL_0220:
																	ptr2++;
																	while (true)
																	{
																		IL_0210:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_0200:
																				if (b > 9)
																				{
																					num = 116;
																					while (num != 116)
																					{
																						if (num != 1097)
																						{
																							goto end_IL_0210;
																						}
																						switch (num)
																						{
																						case 16:
																							goto IL_0200;
																						case 48:
																							goto IL_0210;
																						case 75:
																							goto IL_0220;
																						case 52:
																						case 104:
																							goto IL_0230;
																						case 90:
																							goto IL_023b;
																						case 31:
																						case 32:
																							goto IL_0246;
																						case 33:
																							goto IL_0254;
																						case 29:
																						case 36:
																							goto IL_0262;
																						case 86:
																							goto IL_0275;
																						case 47:
																						case 67:
																							goto IL_0280;
																						case 9:
																						case 28:
																							goto IL_028e;
																						case 44:
																						case 69:
																							goto IL_0299;
																						case 72:
																							goto IL_02a7;
																						case 11:
																						case 89:
																							goto IL_02b5;
																						case 54:
																						case 68:
																							goto IL_02fa;
																						case 94:
																							goto IL_030d;
																						case 42:
																						case 95:
																							goto IL_0326;
																						case 70:
																							goto IL_033f;
																						case 49:
																							goto IL_0356;
																						case 5:
																							goto IL_0364;
																						case 79:
																						case 97:
																							goto IL_0377;
																						case 37:
																							goto IL_03a0;
																						case 81:
																							goto IL_03ae;
																						case 99:
																							goto IL_03c1;
																						case 46:
																							goto IL_03e4;
																						case 0:
																							goto IL_03ee;
																						case 38:
																							goto IL_03fc;
																						case 102:
																							goto IL_040f;
																						case 74:
																						case 91:
																							goto IL_041d;
																						case 3:
																							goto IL_042b;
																						case 56:
																						case 60:
																							goto IL_0439;
																						case 105:
																							goto IL_0455;
																						case 83:
																							goto IL_0460;
																						case 43:
																							goto IL_046e;
																						case 57:
																						case 101:
																							goto IL_0481;
																						case 45:
																							goto IL_04c1;
																						case 85:
																							goto IL_04d5;
																						case 106:
																							goto IL_04e8;
																						case 18:
																						case 55:
																							goto IL_04f6;
																						case 87:
																							goto IL_0536;
																						case 64:
																							goto IL_054a;
																						case 107:
																							goto IL_055d;
																						case 51:
																							goto IL_0571;
																						case 109:
																							goto IL_0584;
																						case 34:
																						case 76:
																							goto IL_058f;
																						case 80:
																							goto IL_05cf;
																						case 13:
																							goto IL_05e3;
																						case 1:
																						case 7:
																						case 12:
																						case 17:
																						case 20:
																						case 21:
																						case 23:
																						case 25:
																						case 27:
																						case 39:
																						case 50:
																						case 59:
																						case 61:
																						case 62:
																						case 63:
																						case 77:
																						case 82:
																						case 92:
																						case 93:
																						case 108:
																							goto end_IL_01ed;
																						case 30:
																							goto IL_0616;
																						case 73:
																							goto IL_0624;
																						case 58:
																							goto IL_0632;
																						case 2:
																						case 4:
																						case 8:
																						case 10:
																						case 15:
																						case 19:
																						case 22:
																						case 40:
																						case 84:
																						case 88:
																						case 103:
																							goto end_IL_0210;
																						case 35:
																							goto end_IL_0640;
																						case 24:
																							goto end_IL_0653;
																						case 100:
																							goto end_IL_065d;
																						case 26:
																							goto end_IL_0668;
																						case 98:
																							goto end_IL_067d;
																						case 96:
																							goto end_IL_0692;
																						case 78:
																							goto end_IL_06a2;
																						case 14:
																							goto end_IL_06b2;
																						case 53:
																						case 71:
																							goto end_IL_06bd;
																						case 65:
																							goto end_IL_06cd;
																						case 66:
																							goto end_IL_06dd;
																						case 6:
																						case 41:
																							goto IL_06f8;
																						}
																						continue;
																						end_IL_01ed:
																						break;
																					}
																					break;
																				}
																				goto IL_023b;
																				IL_03e4:
																				array2[num5] = null;
																				goto IL_03ee;
																				IL_03ee:
																				num5++;
																				goto IL_03fc;
																				IL_023b:
																				if (5 < b)
																				{
																					goto IL_0246;
																				}
																				goto IL_0275;
																				IL_0246:
																				if (7 >= b)
																				{
																					goto IL_0254;
																				}
																				goto IL_040f;
																				IL_0254:
																				if (7 > b)
																				{
																					goto IL_0262;
																				}
																				goto IL_0326;
																				IL_0262:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0584;
																				IL_0584:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_058f;
																				IL_058f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05cf;
																				IL_05cf:
																				array[num5 - 2] = 0;
																				goto IL_05e3;
																				IL_05e3:
																				num5--;
																				goto end_IL_0210;
																				IL_0326:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_033f;
																				IL_033f:
																				array[num5] = 0;
																				num = 49;
																				goto IL_0356;
																				IL_0356:
																				num5++;
																				goto IL_0364;
																				IL_0364:
																				ptr2 += 8;
																				goto end_IL_0210;
																				IL_040f:
																				if (8 < b)
																				{
																					goto IL_041d;
																				}
																				goto IL_04e8;
																				IL_041d:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_042b;
																				IL_042b:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0439;
																				IL_0439:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0210;
																				IL_04e8:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04f6;
																				IL_04f6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0536;
																				IL_0536:
																				array[num5 - 2] = 0;
																				goto IL_054a;
																				IL_054a:
																				num5--;
																				goto end_IL_0210;
																				IL_0275:
																				if (5 > b)
																				{
																					goto IL_0280;
																				}
																				goto IL_02fa;
																				IL_0280:
																				if (2 < b)
																				{
																					goto IL_028e;
																				}
																				goto IL_0455;
																				IL_028e:
																				if (3 < b)
																				{
																					goto IL_0299;
																				}
																				goto IL_030d;
																				IL_0299:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_02a7;
																				IL_02a7:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_02b5;
																				IL_02b5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_055d;
																				IL_055d:
																				array[num5 - 2] = 0;
																				goto IL_0571;
																				IL_0571:
																				num5--;
																				goto end_IL_0210;
																				IL_030d:
																				if (3 > b)
																				{
																					break;
																				}
																				num = 79;
																				goto IL_0377;
																				IL_03fc:
																				ptr2 += 8;
																				goto end_IL_0210;
																				IL_0377:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03a0;
																				IL_03a0:
																				ptr2 += 8;
																				goto IL_03ae;
																				IL_03ae:
																				num5--;
																				goto end_IL_0210;
																				IL_0455:
																				if (2 > b)
																				{
																					goto IL_0460;
																				}
																				goto IL_0481;
																				IL_0460:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_046e;
																				IL_046e:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0481:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c1;
																				IL_04c1:
																				array[num5 - 2] = 0;
																				goto IL_04d5;
																				IL_04d5:
																				num5--;
																				goto end_IL_0210;
																				IL_02fa:
																				array[num5] = 0;
																				goto IL_03c1;
																				IL_03c1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03e4;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0616;
																		IL_0632:
																		ptr2 += 8;
																		break;
																		IL_0624:
																		num5++;
																		goto IL_0632;
																		IL_0616:
																		array[num5] = 0;
																		goto IL_0624;
																		continue;
																		end_IL_0210:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_06f8;
														IL_06f8:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0640:
														break;
													}
													continue;
													end_IL_0653:
													break;
												}
												continue;
												end_IL_065d:
												break;
											}
											continue;
											end_IL_0668:
											break;
										}
										continue;
										end_IL_067d:
										break;
									}
									continue;
									end_IL_0692:
									break;
								}
								continue;
								end_IL_06a2:
								break;
							}
							continue;
							end_IL_06b2:
							break;
						}
						continue;
						end_IL_06bd:
						break;
					}
					continue;
					end_IL_06cd:
					break;
				}
				continue;
				end_IL_06dd:
				break;
			}
		}
	}

	static Class172()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 14;
				while (true)
				{
					if (num != 14)
					{
						if (num != 995)
						{
							break;
						}
						switch (num)
						{
						case 1:
							goto end_IL_0041;
						case 2:
							goto end_IL_004e;
						case 0:
							return;
						case 3:
							return;
						case 4:
							return;
						case 5:
							return;
						case 6:
							return;
						case 7:
							return;
						}
						continue;
					}
					return;
					continue;
					end_IL_0041:
					break;
				}
				continue;
				end_IL_004e:
				break;
			}
		}
	}
}
