using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 46)]
internal struct AllowWhiteSpacesForm
{
	internal static AllowWhiteSpacesForm EventWaitHandleremoveUnhandledException/* Not supported: data(01 00 00 00 01 01 00 00 00 02 00 00 00 00 00 00 00 00 03 00 00 00 00 00 00 00 00 04 00 00 00 01 01 00 00 00 05 00 00 00 02 02 00 00 00 06) */;
}
