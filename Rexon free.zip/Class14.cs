using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("45 FPS Lock", "World", "Locks frame rate to ~45fps.", false, 39, ModType.const_0, false)]
internal class Class14 : MonoBehaviour
{
	private static bool bool_0;

	private static float float_0;

	private static int int_0;

	private static double double_0;

	private static int int_1;

	private static IntPtr[] getParentWindowHandleThreadPoolCallBack;

	private static IntPtr[] GetRegisteredActivatedServiceTypesgetAsyncResult;

	private unsafe void Update()
	{
		int num = 79;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 95;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SchemaTypeUpdateTimeOut.RealErrorObjectDS);
											num = 112;
											while (true)
											{
												byte* ptr2 = ptr;
												num = 86;
												while (true)
												{
													if (num5 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 17;
															while (true)
															{
																IL_0404:
																if (b >= 1)
																{
																	while (b <= 23)
																	{
																		while (true)
																		{
																			IL_03e4:
																			if (12 >= b)
																			{
																				while (true)
																				{
																					IL_03d4:
																					if (12 > b)
																					{
																						while (true)
																						{
																							IL_03c4:
																							if (6 >= b)
																							{
																								while (true)
																								{
																									IL_03b4:
																									if (6 > b)
																									{
																										while (true)
																										{
																											IL_03a4:
																											if (3 < b)
																											{
																												while (true)
																												{
																													IL_0394:
																													if (4 >= b)
																													{
																														while (4 <= b)
																														{
																															while (true)
																															{
																																IL_0374:
																																array[num6] = 0;
																																while (true)
																																{
																																	IL_0346:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																																	num = 201;
																																	while (true)
																																	{
																																		if (num != 201)
																																		{
																																			if (num != 1182)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 53:
																																				goto IL_0346;
																																			case 128:
																																			case 192:
																																				goto IL_0374;
																																			case 83:
																																				goto IL_0384;
																																			case 12:
																																				goto IL_0394;
																																			case 59:
																																				goto IL_03a4;
																																			case 65:
																																				goto IL_03b4;
																																			case 31:
																																				goto IL_03c4;
																																			case 76:
																																				goto IL_03d4;
																																			case 185:
																																				goto IL_03e4;
																																			case 99:
																																				goto IL_03f4;
																																			case 17:
																																				goto IL_0404;
																																			case 45:
																																				goto end_IL_0404;
																																			case 22:
																																			case 132:
																																				goto end_IL_0414;
																																			case 2:
																																				goto IL_0438;
																																			case 138:
																																				goto IL_0446;
																																			case 27:
																																			case 122:
																																				goto IL_0454;
																																			case 146:
																																				goto IL_0494;
																																			case 23:
																																				goto IL_04a8;
																																			case 49:
																																			case 158:
																																				goto IL_04bb;
																																			case 162:
																																				goto IL_0500;
																																			case 63:
																																				goto IL_050b;
																																			case 155:
																																				goto IL_0516;
																																			case 123:
																																			case 136:
																																				goto IL_0524;
																																			case 90:
																																				goto IL_053d;
																																			case 120:
																																				goto IL_054b;
																																			case 97:
																																				goto IL_0559;
																																			case 66:
																																				goto IL_056c;
																																			case 115:
																																			case 129:
																																				goto IL_057f;
																																			case 84:
																																				goto IL_05b1;
																																			case 14:
																																				goto IL_05bf;
																																			case 150:
																																			case 173:
																																				goto IL_05d2;
																																			case 127:
																																				goto IL_05eb;
																																			case 118:
																																				goto IL_05f9;
																																			case 73:
																																				goto IL_0607;
																																			case 175:
																																				goto IL_061a;
																																			case 80:
																																				goto IL_062e;
																																			case 194:
																																				goto IL_0641;
																																			case 103:
																																			case 188:
																																				goto IL_064f;
																																			case 82:
																																				goto IL_068f;
																																			case 106:
																																				goto IL_06a3;
																																			case 36:
																																				goto IL_06c0;
																																			case 81:
																																				goto IL_06ce;
																																			case 61:
																																				goto IL_06e1;
																																			case 58:
																																				goto IL_06ef;
																																			case 0:
																																				goto IL_06fd;
																																			case 166:
																																				goto IL_0708;
																																			case 16:
																																			case 157:
																																				goto IL_0716;
																																			case 56:
																																				goto IL_0756;
																																			case 48:
																																				goto IL_076a;
																																			case 85:
																																				goto IL_0786;
																																			case 15:
																																				goto IL_0794;
																																			case 4:
																																			case 43:
																																				goto IL_07ab;
																																			case 88:
																																			case 139:
																																				goto IL_07c7;
																																			case 32:
																																				goto IL_0807;
																																			case 135:
																																				goto IL_081b;
																																			case 186:
																																				goto IL_082e;
																																			case 114:
																																				goto IL_083c;
																																			case 29:
																																			case 187:
																																				goto IL_084a;
																																			case 126:
																																				goto IL_08ac;
																																			case 189:
																																				goto IL_08c8;
																																			case 40:
																																				goto IL_08d6;
																																			case 170:
																																				goto IL_08e9;
																																			case 50:
																																				goto IL_08f7;
																																			case 34:
																																				goto IL_0905;
																																			case 68:
																																			case 105:
																																				goto IL_0910;
																																			case 21:
																																				goto IL_0959;
																																			case 71:
																																				goto IL_096d;
																																			case 67:
																																				goto IL_0989;
																																			case 109:
																																				goto IL_0997;
																																			case 121:
																																			case 130:
																																				goto IL_09a5;
																																			case 133:
																																				goto IL_09c2;
																																			case 116:
																																				goto IL_0a01;
																																			case 91:
																																				goto IL_0a1d;
																																			case 70:
																																				goto IL_0a2b;
																																			case 125:
																																			case 152:
																																				goto IL_0a42;
																																			case 137:
																																				goto IL_0a6c;
																																			case 69:
																																				goto IL_0a7a;
																																			case 7:
																																				goto IL_0a8d;
																																			case 42:
																																				goto IL_0a98;
																																			case 10:
																																			case 141:
																																				goto IL_0aaf;
																																			case 191:
																																				goto IL_0acb;
																																			case 8:
																																				goto IL_0ae2;
																																			case 75:
																																				goto IL_0afe;
																																			case 100:
																																			case 164:
																																				goto IL_0b09;
																																			case 6:
																																				goto IL_0b49;
																																			case 171:
																																				goto IL_0b5d;
																																			case 107:
																																				goto IL_0b70;
																																			case 167:
																																				goto IL_0b7e;
																																			case 1:
																																			case 41:
																																				goto IL_0b89;
																																			case 159:
																																				goto IL_0bdb;
																																			case 3:
																																				goto IL_0bf7;
																																			case 140:
																																				goto IL_0c02;
																																			case 9:
																																			case 47:
																																				goto IL_0c10;
																																			case 168:
																																				goto IL_0c28;
																																			case 184:
																																				goto IL_0c36;
																																			case 143:
																																			case 190:
																																				goto IL_0c44;
																																			case 19:
																																				goto IL_0c85;
																																			case 145:
																																				goto IL_0c99;
																																			case 35:
																																				goto IL_0cac;
																																			case 172:
																																				goto IL_0cb7;
																																			case 28:
																																			case 94:
																																				goto IL_0cc5;
																																			case 113:
																																				goto IL_0ce7;
																																			case 180:
																																				goto IL_0cf5;
																																			case 5:
																																				goto IL_0d03;
																																			case 181:
																																				goto IL_0d16;
																																			case 110:
																																				goto IL_0d21;
																																			case 24:
																																			case 160:
																																				goto IL_0d2c;
																																			case 72:
																																				goto IL_0d40;
																																			case 178:
																																				goto IL_0d7f;
																																			case 20:
																																			case 25:
																																			case 26:
																																			case 30:
																																			case 33:
																																			case 44:
																																			case 51:
																																			case 52:
																																			case 54:
																																			case 62:
																																			case 64:
																																			case 74:
																																			case 77:
																																			case 92:
																																			case 96:
																																			case 104:
																																			case 108:
																																			case 111:
																																			case 117:
																																			case 119:
																																			case 153:
																																			case 161:
																																			case 176:
																																			case 177:
																																			case 182:
																																			case 193:
																																				goto end_IL_0333;
																																			case 37:
																																			case 38:
																																			case 46:
																																			case 55:
																																			case 57:
																																			case 60:
																																			case 86:
																																			case 87:
																																			case 89:
																																			case 93:
																																			case 101:
																																			case 102:
																																			case 124:
																																			case 131:
																																			case 142:
																																			case 144:
																																			case 147:
																																			case 148:
																																			case 149:
																																			case 151:
																																			case 163:
																																			case 165:
																																			case 169:
																																			case 174:
																																			case 179:
																																			case 183:
																																				goto end_IL_042d;
																																			case 112:
																																				goto end_IL_0da2;
																																			case 134:
																																				goto end_IL_0db5;
																																			case 98:
																																				goto end_IL_0dc8;
																																			case 95:
																																				goto end_IL_0ddc;
																																			case 154:
																																				goto end_IL_0dec;
																																			case 156:
																																				goto end_IL_0dfc;
																																			case 13:
																																				goto end_IL_0e07;
																																			case 18:
																																				goto end_IL_0e17;
																																			case 78:
																																				goto end_IL_0e27;
																																			case 79:
																																				goto end_IL_0e37;
																																			case 11:
																																			case 39:
																																				return;
																																			}
																																			continue;
																																		}
																																		array2[num6] = null;
																																		goto IL_06c0;
																																		IL_06c0:
																																		num6++;
																																		goto IL_06ce;
																																		IL_06ce:
																																		ptr2 += 8;
																																		goto end_IL_042d;
																																		continue;
																																		end_IL_0333:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																															IL_0384:;
																														}
																														break;
																													}
																													goto IL_0438;
																													IL_04a8:
																													num6--;
																													goto end_IL_042d;
																													IL_0438:
																													if (5 < b)
																													{
																														break;
																													}
																													goto IL_0446;
																													IL_0446:
																													if (5 > b)
																													{
																														break;
																													}
																													goto IL_0454;
																													IL_0454:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_0494;
																													IL_0494:
																													array[num6 - 2] = 0;
																													goto IL_04a8;
																												}
																												break;
																											}
																											goto IL_0500;
																											IL_05bf:
																											num6--;
																											goto end_IL_042d;
																											IL_0500:
																											if (3 > b)
																											{
																												goto IL_050b;
																											}
																											goto IL_057f;
																											IL_050b:
																											if (1 >= b)
																											{
																												goto IL_0516;
																											}
																											goto IL_056c;
																											IL_0516:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0524;
																											IL_0524:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																											goto IL_053d;
																											IL_053d:
																											array[num6] = 0;
																											goto IL_054b;
																											IL_054b:
																											num6++;
																											goto IL_0559;
																											IL_0559:
																											ptr2 += 8;
																											goto end_IL_042d;
																											IL_056c:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_0641;
																											IL_0641:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_064f;
																											IL_064f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_068f;
																											IL_068f:
																											array[num6 - 2] = 0;
																											goto IL_06a3;
																											IL_06a3:
																											num6--;
																											goto end_IL_042d;
																											IL_057f:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											num = 84;
																											goto IL_05b1;
																											IL_05b1:
																											ptr2 += 8;
																											goto IL_05bf;
																										}
																										break;
																									}
																									goto IL_04bb;
																									IL_062e:
																									num6--;
																									goto end_IL_042d;
																									IL_04bb:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_061a;
																									IL_061a:
																									array[num6 - 2] = 0;
																									goto IL_062e;
																								}
																								break;
																							}
																							goto IL_06e1;
																							IL_08c8:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_08d6;
																							IL_06e1:
																							if (9 >= b)
																							{
																								goto IL_06ef;
																							}
																							goto IL_082e;
																							IL_06ef:
																							if (9 > b)
																							{
																								goto IL_06fd;
																							}
																							goto IL_07c7;
																							IL_06fd:
																							if (7 >= b)
																							{
																								goto IL_0708;
																							}
																							goto IL_0786;
																							IL_0708:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0716;
																							IL_0716:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0756;
																							IL_0756:
																							array[num6 - 2] = 0;
																							goto IL_076a;
																							IL_076a:
																							num6--;
																							num = 144;
																							goto end_IL_042d;
																							IL_0786:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_0794;
																							IL_0794:
																							if (8 > b)
																							{
																								break;
																							}
																							num = 43;
																							goto IL_07ab;
																							IL_08d6:
																							if (11 > b)
																							{
																								break;
																							}
																							goto end_IL_042d;
																							IL_07ab:
																							num6--;
																							num = 179;
																							goto end_IL_042d;
																							IL_07c7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0807;
																							IL_0807:
																							array[num6 - 2] = 0;
																							goto IL_081b;
																							IL_081b:
																							num6--;
																							goto end_IL_042d;
																							IL_082e:
																							if (10 >= b)
																							{
																								goto IL_083c;
																							}
																							goto IL_08c8;
																							IL_083c:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_084a;
																							IL_084a:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_08ac;
																							IL_08ac:
																							num6 -= 2;
																							num = 148;
																							goto end_IL_042d;
																						}
																						break;
																					}
																					goto IL_05d2;
																					IL_0607:
																					ptr2 += 16;
																					goto end_IL_042d;
																					IL_05d2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																					goto IL_05eb;
																					IL_05eb:
																					array[num6] = 1;
																					goto IL_05f9;
																					IL_05f9:
																					num6++;
																					goto IL_0607;
																				}
																				break;
																			}
																			goto IL_08e9;
																			IL_0d16:
																			if (17 < b)
																			{
																				break;
																			}
																			goto IL_0d21;
																			IL_08e9:
																			if (18 < b)
																			{
																				goto IL_08f7;
																			}
																			num = 75;
																			goto IL_0afe;
																			IL_08f7:
																			if (21 >= b)
																			{
																				goto IL_0905;
																			}
																			goto IL_0a8d;
																			IL_0905:
																			if (21 <= b)
																			{
																				goto IL_0910;
																			}
																			goto IL_0989;
																			IL_0910:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			num = 21;
																			goto IL_0959;
																			IL_0959:
																			array[num6 - 2] = 3;
																			goto IL_096d;
																			IL_096d:
																			num6--;
																			num = 101;
																			goto end_IL_042d;
																			IL_0989:
																			if (19 >= b)
																			{
																				goto IL_0997;
																			}
																			goto IL_0a1d;
																			IL_0997:
																			if (19 > b)
																			{
																				break;
																			}
																			goto IL_09a5;
																			IL_09a5:
																			array[num6 - 1] = 0;
																			num = 133;
																			goto IL_09c2;
																			IL_09c2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)getParentWindowHandleThreadPoolCallBack[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0a01;
																			IL_0a01:
																			ptr2 += 8;
																			num = 165;
																			goto end_IL_042d;
																			IL_0a1d:
																			if (20 < b)
																			{
																				break;
																			}
																			goto IL_0a2b;
																			IL_0a2b:
																			if (20 > b)
																			{
																				break;
																			}
																			num = 152;
																			goto IL_0a42;
																			IL_0d2c:
																			array[num6 - 1] = 3;
																			goto IL_0d40;
																			IL_0a42:
																			((delegate*<int, void>)getParentWindowHandleThreadPoolCallBack[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0a6c;
																			IL_0a6c:
																			num6--;
																			goto IL_0a7a;
																			IL_0a7a:
																			ptr2 += 8;
																			goto end_IL_042d;
																			IL_0a8d:
																			if (22 >= b)
																			{
																				goto IL_0a98;
																			}
																			goto IL_0acb;
																			IL_0a98:
																			if (22 > b)
																			{
																				break;
																			}
																			num = 10;
																			goto IL_0aaf;
																			IL_0d40:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getParentWindowHandleThreadPoolCallBack[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0d7f;
																			IL_0aaf:
																			byte* num7 = ptr2;
																			num5 = 1;
																			ptr2 = num7 + -200;
																			goto end_IL_042d;
																			IL_0acb:
																			if (23 < b)
																			{
																				break;
																			}
																			num = 8;
																			goto IL_0ae2;
																			IL_0d7f:
																			ptr2 += 8;
																			goto end_IL_042d;
																			IL_0ae2:
																			if (23 > b)
																			{
																			}
																			break;
																			IL_0d21:
																			if (17 > b)
																			{
																				break;
																			}
																			goto IL_0d2c;
																			IL_0afe:
																			if (18 <= b)
																			{
																				goto IL_0b09;
																			}
																			goto IL_0b70;
																			IL_0b09:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0b49;
																			IL_0b49:
																			array[num6 - 2] = 3;
																			goto IL_0b5d;
																			IL_0b5d:
																			num6--;
																			goto end_IL_042d;
																			IL_0b70:
																			if (15 >= b)
																			{
																				goto IL_0b7e;
																			}
																			goto IL_0cac;
																			IL_0b7e:
																			if (15 <= b)
																			{
																				goto IL_0b89;
																			}
																			goto IL_0bf7;
																			IL_0b89:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0bdb;
																			IL_0bdb:
																			num6--;
																			num = 57;
																			goto end_IL_042d;
																			IL_0bf7:
																			if (13 >= b)
																			{
																				goto IL_0c02;
																			}
																			goto IL_0c28;
																			IL_0c02:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0c10;
																			IL_0c10:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_042d;
																			IL_0c28:
																			if (14 < b)
																			{
																				break;
																			}
																			goto IL_0c36;
																			IL_0c36:
																			if (14 > b)
																			{
																				break;
																			}
																			goto IL_0c44;
																			IL_0c44:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																			goto IL_0c85;
																			IL_0c85:
																			array[num6 - 2] = 0;
																			goto IL_0c99;
																			IL_0c99:
																			num6--;
																			goto end_IL_042d;
																			IL_0cac:
																			if (16 >= b)
																			{
																				goto IL_0cb7;
																			}
																			goto IL_0d16;
																			IL_0cb7:
																			if (16 > b)
																			{
																				break;
																			}
																			goto IL_0cc5;
																			IL_0cc5:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																			num = 113;
																			goto IL_0ce7;
																			IL_0ce7:
																			array[num6] = 3;
																			goto IL_0cf5;
																			IL_0cf5:
																			num6++;
																			goto IL_0d03;
																			IL_0d03:
																			ptr2 += 16;
																			goto end_IL_042d;
																		}
																		break;
																		IL_03f4:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_042d;
																continue;
																end_IL_0404:
																break;
															}
															continue;
															end_IL_0414:
															break;
														}
														continue;
														end_IL_042d:
														break;
													}
													continue;
													end_IL_0da2:
													break;
												}
												continue;
												end_IL_0db5:
												break;
											}
											continue;
											end_IL_0dc8:
											break;
										}
										continue;
										end_IL_0ddc:
										break;
									}
									continue;
									end_IL_0dec:
									break;
								}
								continue;
								end_IL_0dfc:
								break;
							}
							continue;
							end_IL_0e07:
							break;
						}
						continue;
						end_IL_0e17:
						break;
					}
					continue;
					end_IL_0e27:
					break;
				}
				continue;
				end_IL_0e37:
				break;
			}
		}
	}

	public Class14()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 9;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HostCanGenerateEnterpriseControllersSid.WaitDelegateMethodInfo);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f4:
														byte b = *ptr2;
														while (true)
														{
															IL_02e4:
															ptr2++;
															while (true)
															{
																IL_02d4:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02b7:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_02a7:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0297:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0287:
																									if (7 >= b)
																									{
																										while (7 <= b)
																										{
																											while (true)
																											{
																												IL_0235:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_021f:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_0206:
																														num5--;
																														num = 121;
																														while (num != 121)
																														{
																															if (num != 1102)
																															{
																																goto end_IL_0277;
																															}
																															switch (num)
																															{
																															case 96:
																																goto IL_0206;
																															case 38:
																																goto IL_021f;
																															case 47:
																															case 98:
																																goto IL_0235;
																															case 97:
																																goto IL_0277;
																															case 34:
																															case 56:
																																goto IL_0287;
																															case 18:
																																goto IL_0297;
																															case 67:
																															case 102:
																																goto IL_02a7;
																															case 5:
																																goto IL_02b7;
																															case 44:
																																goto IL_02c4;
																															case 55:
																																goto IL_02d4;
																															case 39:
																																goto IL_02e4;
																															case 35:
																															case 90:
																																goto IL_02f4;
																															case 53:
																																goto IL_02ff;
																															case 3:
																															case 63:
																																goto IL_030d;
																															case 13:
																																goto IL_0318;
																															case 4:
																																goto IL_0326;
																															case 50:
																																goto IL_0334;
																															case 57:
																															case 68:
																																goto IL_0344;
																															case 65:
																																goto IL_034f;
																															case 52:
																																goto IL_035d;
																															case 27:
																																goto IL_0379;
																															case 69:
																															case 72:
																																goto IL_038c;
																															case 20:
																																goto IL_03ae;
																															case 74:
																																goto IL_03bc;
																															case 71:
																																goto IL_03ca;
																															case 73:
																															case 78:
																																goto IL_03dd;
																															case 7:
																																goto IL_03e8;
																															case 28:
																															case 60:
																																goto IL_03f6;
																															case 31:
																																goto IL_0412;
																															case 59:
																																goto IL_0420;
																															case 83:
																															case 86:
																																goto IL_0433;
																															case 29:
																																goto IL_0473;
																															case 14:
																																goto IL_0487;
																															case 43:
																															case 91:
																																goto IL_049a;
																															case 79:
																															case 99:
																																goto IL_04bb;
																															case 105:
																																goto IL_04c9;
																															case 15:
																															case 64:
																																goto IL_04d7;
																															case 54:
																																goto IL_04fa;
																															case 87:
																																goto IL_0508;
																															case 62:
																																goto IL_0516;
																															case 12:
																															case 106:
																																goto IL_0529;
																															case 30:
																																goto IL_0537;
																															case 33:
																															case 89:
																																goto IL_0545;
																															case 70:
																																goto IL_0577;
																															case 100:
																																goto IL_0585;
																															case 2:
																															case 107:
																																goto IL_0598;
																															case 94:
																																goto IL_05a6;
																															case 112:
																																goto IL_05c9;
																															case 80:
																																goto IL_05d3;
																															case 21:
																																goto IL_05e1;
																															case 41:
																															case 85:
																																goto IL_05fd;
																															case 24:
																																goto IL_0668;
																															case 6:
																															case 11:
																															case 17:
																															case 19:
																															case 22:
																															case 23:
																															case 25:
																															case 37:
																															case 40:
																															case 42:
																															case 45:
																															case 58:
																															case 61:
																															case 81:
																															case 82:
																															case 101:
																															case 108:
																															case 111:
																															case 113:
																															case 114:
																																goto end_IL_0277;
																															case 0:
																															case 1:
																															case 10:
																															case 26:
																															case 32:
																															case 36:
																															case 46:
																															case 48:
																															case 77:
																															case 93:
																															case 95:
																															case 104:
																															case 109:
																																goto end_IL_01f3;
																															case 66:
																																goto end_IL_068b;
																															case 16:
																																goto end_IL_069e;
																															case 92:
																																goto end_IL_06a8;
																															case 49:
																																goto end_IL_06b3;
																															case 51:
																															case 110:
																																goto end_IL_06c8;
																															case 88:
																																goto end_IL_06d8;
																															case 76:
																															case 103:
																																goto end_IL_06e8;
																															case 8:
																																goto end_IL_06f8;
																															case 9:
																																goto end_IL_0708;
																															case 75:
																															case 84:
																																goto IL_0723;
																															}
																															continue;
																															end_IL_01f3:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_02d4;
																											continue;
																											end_IL_0277:
																											break;
																											IL_0277:;
																										}
																										break;
																									}
																									goto IL_04bb;
																									IL_0516:
																									ptr2 += 8;
																									goto end_IL_02d4;
																									IL_04bb:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_04c9;
																									IL_04c9:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_04d7;
																									IL_04d7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_04fa;
																									IL_04fa:
																									array[num5] = 0;
																									goto IL_0508;
																									IL_0508:
																									num5++;
																									goto IL_0516;
																								}
																								break;
																							}
																							goto IL_05fd;
																							IL_0668:
																							num5 -= 2;
																							goto end_IL_02d4;
																							IL_05fd:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 24;
																							goto IL_0668;
																						}
																						break;
																					}
																					goto IL_03dd;
																					IL_0420:
																					if (11 > b)
																					{
																					}
																					break;
																					IL_03dd:
																					if (10 >= b)
																					{
																						goto IL_03e8;
																					}
																					goto IL_0412;
																					IL_03e8:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_03f6;
																					IL_03f6:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02d4;
																					IL_0412:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0420;
																				}
																				break;
																			}
																			goto IL_02ff;
																			IL_0473:
																			array[num5 - 2] = 0;
																			goto IL_0487;
																			IL_02ff:
																			if (6 > b)
																			{
																				goto IL_030d;
																			}
																			goto IL_0433;
																			IL_030d:
																			if (3 >= b)
																			{
																				goto IL_0318;
																			}
																			goto IL_0344;
																			IL_0318:
																			if (3 > b)
																			{
																				goto IL_0326;
																			}
																			goto IL_049a;
																			IL_0326:
																			if (1 >= b)
																			{
																				goto IL_0334;
																			}
																			goto IL_0529;
																			IL_0334:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_038c;
																			IL_038c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 20;
																			goto IL_03ae;
																			IL_03ae:
																			array[num5] = 0;
																			goto IL_03bc;
																			IL_03bc:
																			num5++;
																			goto IL_03ca;
																			IL_03ca:
																			ptr2 += 8;
																			goto end_IL_02d4;
																			IL_0529:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0537;
																			IL_0537:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0545;
																			IL_0545:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 70;
																			goto IL_0577;
																			IL_0577:
																			ptr2 += 8;
																			goto IL_0585;
																			IL_0585:
																			num5--;
																			goto end_IL_02d4;
																			IL_049a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 109;
																			goto end_IL_02d4;
																			IL_0344:
																			if (4 < b)
																			{
																				goto IL_034f;
																			}
																			goto IL_0379;
																			IL_034f:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_035d;
																			IL_035d:
																			if (5 > b)
																			{
																				break;
																			}
																			num = 2;
																			goto IL_0598;
																			IL_0487:
																			num5--;
																			goto end_IL_02d4;
																			IL_0598:
																			array[num5] = 0;
																			goto IL_05a6;
																			IL_05a6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05c9;
																			IL_05c9:
																			array2[num5] = null;
																			goto IL_05d3;
																			IL_05d3:
																			num5++;
																			goto IL_05e1;
																			IL_05e1:
																			ptr2 += 8;
																			num = 93;
																			goto end_IL_02d4;
																			IL_0379:
																			if (4 <= b)
																			{
																				goto end_IL_02d4;
																			}
																			break;
																			IL_0433:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0473;
																		}
																		break;
																		IL_02c4:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d4:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0723;
												IL_0723:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068b:
												break;
											}
											continue;
											end_IL_069e:
											break;
										}
										continue;
										end_IL_06a8:
										break;
									}
									continue;
									end_IL_06b3:
									break;
								}
								continue;
								end_IL_06c8:
								break;
							}
							continue;
							end_IL_06d8:
							break;
						}
						continue;
						end_IL_06e8:
						break;
					}
					continue;
					end_IL_06f8:
					break;
				}
				continue;
				end_IL_0708:
				break;
			}
		}
	}

	private static int smethod_1(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		int num3;
		if (num <= num2)
		{
			num = int_3;
			num2 = int_2;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_2;
			num2 = int_3;
			num -= num2;
			num3 = num;
		}
		num = num3;
		num2 = 280;
		num2 = 40;
		int num4 = smethod_6(40, 8);
		num2 = num4;
		return num;
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StreamReaderCanon.StandardBiasOpenNamespace);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0228:
															byte b = *ptr2;
															while (true)
															{
																IL_0218:
																ptr2++;
																while (true)
																{
																	IL_0208:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e8:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01db:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (5 >= b)
																								{
																									while (5 <= b)
																									{
																										num = 94;
																										while (true)
																										{
																											if (num != 94)
																											{
																												if (num != 1075)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 46:
																													goto IL_01a8;
																												case 49:
																												case 76:
																													goto IL_01bb;
																												case 55:
																													goto IL_01cb;
																												case 57:
																												case 72:
																													goto IL_01db;
																												case 19:
																													goto IL_01e8;
																												case 17:
																													goto IL_01f8;
																												case 26:
																													goto IL_0208;
																												case 86:
																													goto IL_0218;
																												case 8:
																												case 65:
																													goto IL_0228;
																												case 63:
																													goto IL_0233;
																												case 75:
																													goto IL_0254;
																												case 51:
																													goto IL_025f;
																												case 7:
																												case 40:
																													goto IL_026d;
																												case 52:
																													goto IL_027b;
																												case 35:
																													goto IL_029e;
																												case 28:
																													goto IL_02a8;
																												case 66:
																													goto IL_02b6;
																												case 41:
																												case 54:
																													goto IL_02db;
																												case 60:
																													goto end_IL_0195;
																												case 10:
																												case 33:
																													goto IL_02f7;
																												case 18:
																													goto IL_0313;
																												case 32:
																												case 45:
																													goto IL_031e;
																												case 59:
																													goto IL_0347;
																												case 70:
																													goto IL_0355;
																												case 50:
																												case 71:
																													goto IL_0371;
																												case 9:
																													goto IL_037f;
																												case 24:
																													goto IL_038d;
																												case 5:
																												case 43:
																													goto IL_039b;
																												case 20:
																													goto IL_03db;
																												case 13:
																													goto IL_03ef;
																												case 68:
																													goto IL_040b;
																												case 56:
																												case 67:
																													goto IL_0416;
																												case 21:
																													goto IL_0484;
																												case 27:
																													goto IL_0494;
																												case 64:
																													goto IL_049f;
																												case 4:
																												case 11:
																												case 14:
																												case 25:
																												case 34:
																												case 36:
																												case 38:
																												case 58:
																												case 61:
																												case 69:
																												case 73:
																												case 81:
																												case 83:
																												case 84:
																												case 87:
																													goto end_IL_01a8;
																												case 6:
																													goto IL_04cd;
																												case 80:
																													goto IL_04db;
																												case 29:
																													goto IL_04e9;
																												case 1:
																												case 12:
																												case 15:
																												case 16:
																												case 30:
																												case 31:
																												case 37:
																												case 53:
																												case 74:
																												case 82:
																												case 85:
																													goto end_IL_01cb;
																												case 39:
																													goto end_IL_04f7;
																												case 62:
																													goto end_IL_050a;
																												case 23:
																													goto end_IL_0514;
																												case 0:
																													goto end_IL_051f;
																												case 77:
																													goto end_IL_0534;
																												case 42:
																												case 48:
																													goto end_IL_0549;
																												case 2:
																													goto end_IL_0559;
																												case 3:
																												case 47:
																													goto end_IL_0569;
																												case 78:
																													goto end_IL_0579;
																												case 79:
																													goto end_IL_0589;
																												case 22:
																												case 44:
																													goto IL_05ad;
																												}
																												continue;
																											}
																											goto IL_0233;
																											IL_0233:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											num = 53;
																											goto end_IL_01cb;
																											continue;
																											end_IL_0195:
																											break;
																										}
																										goto IL_02e9;
																										continue;
																										end_IL_01a8:
																										break;
																										IL_01a8:;
																									}
																									break;
																									IL_01bb:;
																								}
																								goto end_IL_01f8;
																								continue;
																								end_IL_01cb:
																								break;
																								IL_01cb:;
																							}
																							break;
																						}
																						goto IL_0254;
																						IL_02e9:
																						if (8 > b)
																						{
																							goto end_IL_01f8;
																						}
																						goto IL_02f7;
																						IL_0254:
																						if (7 >= b)
																						{
																							goto IL_025f;
																						}
																						num = 41;
																						goto IL_02db;
																						IL_025f:
																						if (7 > b)
																						{
																							goto end_IL_01f8;
																						}
																						goto IL_026d;
																						IL_026d:
																						array[num5] = 0;
																						goto IL_027b;
																						IL_027b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_029e;
																						IL_029e:
																						array2[num5] = null;
																						goto IL_02a8;
																						IL_02a8:
																						num5++;
																						goto IL_02b6;
																						IL_02b6:
																						ptr2 += 8;
																						num = 85;
																						break;
																						IL_02f7:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_02db:
																						if (8 < b)
																						{
																							goto end_IL_01f8;
																						}
																						goto IL_02e9;
																					}
																					break;
																				}
																				goto IL_0313;
																				IL_0484:
																				num5 -= 2;
																				break;
																				IL_0313:
																				if (4 <= b)
																				{
																					goto IL_031e;
																				}
																				num = 50;
																				goto IL_0371;
																				IL_031e:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0347;
																				IL_0347:
																				ptr2 += 8;
																				goto IL_0355;
																				IL_0355:
																				num5--;
																				break;
																				IL_0494:
																				if (1 < b)
																				{
																					goto end_IL_01f8;
																				}
																				goto IL_049f;
																				IL_0371:
																				if (2 < b)
																				{
																					goto IL_037f;
																				}
																				num = 68;
																				goto IL_040b;
																				IL_037f:
																				if (3 < b)
																				{
																					goto end_IL_01f8;
																				}
																				goto IL_038d;
																				IL_038d:
																				if (3 > b)
																				{
																					goto end_IL_01f8;
																				}
																				goto IL_039b;
																				IL_039b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03db;
																				IL_03db:
																				array[num5 - 2] = 0;
																				goto IL_03ef;
																				IL_03ef:
																				num5--;
																				break;
																				IL_049f:
																				if (1 > b)
																				{
																				}
																				goto end_IL_01f8;
																				IL_040b:
																				if (2 <= b)
																				{
																					goto IL_0416;
																				}
																				goto IL_0494;
																				IL_0416:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0484;
																			}
																			goto end_IL_0208;
																			continue;
																			end_IL_01f8:
																			break;
																			IL_01f8:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04cd;
																	IL_04e9:
																	ptr2 += 8;
																	break;
																	IL_04db:
																	num5++;
																	goto IL_04e9;
																	IL_04cd:
																	array[num5] = 0;
																	goto IL_04db;
																	continue;
																	end_IL_0208:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 22;
													goto IL_05ad;
													IL_05ad:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f7:
													break;
												}
												continue;
												end_IL_050a:
												break;
											}
											continue;
											end_IL_0514:
											break;
										}
										continue;
										end_IL_051f:
										break;
									}
									continue;
									end_IL_0534:
									break;
								}
								continue;
								end_IL_0549:
								break;
							}
							continue;
							end_IL_0559:
							break;
						}
						continue;
						end_IL_0569:
						break;
					}
					continue;
					end_IL_0579:
					break;
				}
				continue;
				end_IL_0589:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2, int int_3)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									IL_06a9:
									array3[0] = int_2;
									while (true)
									{
										IL_0694:
										array3[1] = int_3;
										while (true)
										{
											IL_0680:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GenericExecuteCanWrite.EventProviderBrowserBack);
											num = 16;
											while (true)
											{
												IL_0676:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_066b:
													num = 105;
													while (true)
													{
														IL_0658:
														if (num4 != 1)
														{
															while (true)
															{
																IL_026c:
																num = 68;
																while (true)
																{
																	IL_0261:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0251:
																		ptr2++;
																		while (true)
																		{
																			IL_0241:
																			if (b >= 1)
																			{
																				while (b <= 9)
																				{
																					while (true)
																					{
																						IL_0224:
																						if (5 < b)
																						{
																							while (true)
																							{
																								IL_0214:
																								if (7 >= b)
																								{
																									while (true)
																									{
																										IL_0207:
																										if (7 > b)
																										{
																											while (6 >= b)
																											{
																												num = 113;
																												while (true)
																												{
																													if (num != 113)
																													{
																														if (num != 1094)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 90:
																															goto IL_01f4;
																														case 13:
																															goto IL_0207;
																														case 38:
																															goto IL_0214;
																														case 57:
																															goto IL_0224;
																														case 85:
																															goto IL_0231;
																														case 29:
																															goto IL_0241;
																														case 84:
																															goto IL_0251;
																														case 68:
																															goto IL_0261;
																														case 39:
																															goto IL_026c;
																														case 11:
																															goto IL_0277;
																														case 35:
																														case 36:
																															goto IL_0287;
																														case 7:
																															goto IL_02a0;
																														case 45:
																														case 53:
																															goto IL_02b0;
																														case 18:
																															goto IL_02be;
																														case 3:
																															goto IL_02e1;
																														case 62:
																															goto IL_02f4;
																														case 83:
																															goto IL_0307;
																														case 8:
																															goto IL_031e;
																														case 96:
																															goto IL_0331;
																														case 49:
																														case 52:
																															goto IL_033c;
																														case 15:
																														case 58:
																															goto IL_0350;
																														case 94:
																															goto IL_0363;
																														case 93:
																														case 95:
																															goto IL_0371;
																														case 37:
																															goto IL_039a;
																														case 47:
																															goto IL_03a8;
																														case 50:
																															goto IL_03bb;
																														case 40:
																														case 41:
																															goto IL_03c6;
																														case 54:
																															goto IL_0406;
																														case 55:
																														case 97:
																															goto IL_041f;
																														case 4:
																															goto IL_042d;
																														case 98:
																															goto IL_0440;
																														case 32:
																														case 56:
																															goto IL_044e;
																														case 20:
																															goto IL_048e;
																														case 69:
																															goto IL_04a2;
																														case 100:
																															goto IL_04b5;
																														case 104:
																															goto IL_04c8;
																														case 46:
																														case 82:
																															goto IL_04e9;
																														case 61:
																															goto IL_0532;
																														case 81:
																															goto IL_0546;
																														case 28:
																															goto IL_0559;
																														case 0:
																														case 48:
																															goto IL_0564;
																														case 80:
																															goto IL_0572;
																														case 9:
																														case 14:
																															goto IL_0580;
																														case 78:
																															goto IL_059c;
																														case 1:
																														case 12:
																															goto IL_05a7;
																														case 87:
																															goto IL_05e7;
																														case 21:
																															goto IL_05fb;
																														case 5:
																														case 23:
																														case 24:
																														case 26:
																														case 30:
																														case 31:
																														case 42:
																														case 51:
																														case 59:
																														case 60:
																														case 63:
																														case 64:
																														case 65:
																														case 70:
																														case 71:
																														case 73:
																														case 79:
																														case 91:
																														case 102:
																														case 106:
																															goto end_IL_01f4;
																														case 2:
																															goto IL_062e;
																														case 101:
																															goto IL_063c;
																														case 76:
																															goto IL_064a;
																														case 6:
																														case 10:
																														case 17:
																														case 27:
																														case 33:
																														case 72:
																														case 88:
																														case 92:
																														case 103:
																														case 105:
																															goto IL_0658;
																														case 43:
																															goto IL_066b;
																														case 16:
																															goto IL_0676;
																														case 25:
																															goto IL_0680;
																														case 66:
																															goto IL_0694;
																														case 19:
																															goto IL_06a9;
																														case 86:
																															goto end_IL_01e1;
																														case 44:
																														case 89:
																															goto end_IL_06be;
																														case 34:
																															goto end_IL_06ce;
																														case 22:
																														case 99:
																															goto end_IL_06de;
																														case 74:
																															goto end_IL_06ee;
																														case 75:
																															goto end_IL_06fe;
																														case 67:
																														case 77:
																															goto IL_0719;
																														}
																														continue;
																													}
																													if (6 > b)
																													{
																														goto end_IL_01f4;
																													}
																													goto IL_04e9;
																													IL_04e9:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 61;
																													goto IL_0532;
																													IL_0546:
																													num5--;
																													goto IL_0658;
																													IL_0532:
																													array[num5 - 2] = 0;
																													goto IL_0546;
																													continue;
																													end_IL_01e1:
																													break;
																												}
																												goto end_IL_0241;
																												continue;
																												end_IL_01f4:
																												break;
																												IL_01f4:;
																											}
																											break;
																										}
																										goto IL_0287;
																										IL_031e:
																										ptr2 += 8;
																										goto IL_0658;
																										IL_0287:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_02a0;
																										IL_02a0:
																										array[num5] = 0;
																										goto IL_0307;
																										IL_0307:
																										num5++;
																										num = 8;
																										goto IL_031e;
																									}
																									break;
																								}
																								goto IL_0559;
																								IL_05fb:
																								num5--;
																								goto IL_0658;
																								IL_0559:
																								if (8 < b)
																								{
																									goto IL_0564;
																								}
																								goto IL_059c;
																								IL_0564:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_0572;
																								IL_0572:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0580;
																								IL_0580:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto IL_0658;
																								IL_059c:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_05a7;
																								IL_05a7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05e7;
																								IL_05e7:
																								array[num5 - 2] = 0;
																								goto IL_05fb;
																							}
																							break;
																						}
																						goto IL_0277;
																						IL_041f:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_042d;
																						IL_0277:
																						if (5 <= b)
																						{
																							goto IL_02b0;
																						}
																						goto IL_0331;
																						IL_02b0:
																						array[num5] = 0;
																						goto IL_02be;
																						IL_02be:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02e1;
																						IL_02e1:
																						array2[num5] = null;
																						num = 62;
																						goto IL_02f4;
																						IL_02f4:
																						num5++;
																						goto IL_04b5;
																						IL_04b5:
																						ptr2 += 8;
																						goto IL_0658;
																						IL_0331:
																						if (2 < b)
																						{
																							goto IL_033c;
																						}
																						goto IL_03bb;
																						IL_033c:
																						if (3 < b)
																						{
																							num = 15;
																							goto IL_0350;
																						}
																						goto IL_0363;
																						IL_042d:
																						if (1 <= b)
																						{
																						}
																						break;
																						IL_0350:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_0440;
																						IL_0440:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_044e;
																						IL_044e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_048e;
																						IL_048e:
																						array[num5 - 2] = 0;
																						goto IL_04a2;
																						IL_04a2:
																						num5--;
																						goto IL_0658;
																						IL_0363:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_0371;
																						IL_0371:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_039a;
																						IL_039a:
																						ptr2 += 8;
																						goto IL_03a8;
																						IL_03a8:
																						num5--;
																						goto IL_0658;
																						IL_03bb:
																						if (2 <= b)
																						{
																							goto IL_03c6;
																						}
																						goto IL_041f;
																						IL_03c6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0406;
																						IL_0406:
																						array[num5 - 2] = 0;
																						goto IL_04c8;
																						IL_04c8:
																						num5--;
																						goto IL_0658;
																					}
																					break;
																					IL_0231:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_062e;
																			IL_064a:
																			ptr2 += 8;
																			goto IL_0658;
																			IL_063c:
																			num5++;
																			goto IL_064a;
																			IL_062e:
																			array[num5] = 0;
																			goto IL_063c;
																			continue;
																			end_IL_0241:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														goto IL_0719;
														IL_0719:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_06be:
								break;
							}
							continue;
							end_IL_06ce:
							break;
						}
						continue;
						end_IL_06de:
						break;
					}
					continue;
					end_IL_06ee:
					break;
				}
				continue;
				end_IL_06fe:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 17;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 10;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsRightToLeftExtractNameSpace.opExplicitTypeLibrary);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_035f:
														byte b = *ptr2;
														while (true)
														{
															IL_034f:
															ptr2++;
															while (true)
															{
																IL_033f:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_031f:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_030f:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02ff:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_02ef:
																									if (5 < b)
																									{
																										while (6 >= b)
																										{
																											while (6 <= b)
																											{
																												while (true)
																												{
																													IL_028d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_026e:
																														array[num5 - 2] = 0;
																														num = 147;
																														while (true)
																														{
																															if (num != 147)
																															{
																																if (num != 1128)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 122:
																																	goto IL_026e;
																																case 48:
																																case 67:
																																	goto IL_028d;
																																case 92:
																																	goto IL_02cf;
																																case 22:
																																case 115:
																																	goto IL_02df;
																																case 53:
																																case 91:
																																	goto IL_02ef;
																																case 9:
																																case 47:
																																	goto IL_02ff;
																																case 44:
																																	goto IL_030f;
																																case 75:
																																	goto IL_031f;
																																case 133:
																																	goto IL_032f;
																																case 101:
																																	goto IL_033f;
																																case 52:
																																	goto IL_034f;
																																case 42:
																																case 83:
																																	goto IL_035f;
																																case 104:
																																	goto IL_037d;
																																case 27:
																																case 80:
																																	goto IL_0388;
																																case 61:
																																	goto IL_0396;
																																case 50:
																																	goto IL_03b9;
																																case 39:
																																	goto IL_03c3;
																																case 117:
																																	goto IL_03d1;
																																case 6:
																																	goto IL_03e4;
																																case 38:
																																	goto IL_03ef;
																																case 107:
																																	goto IL_0410;
																																case 21:
																																case 100:
																																	goto IL_041b;
																																case 65:
																																case 140:
																																	goto IL_0433;
																																case 35:
																																case 49:
																																	goto IL_043e;
																																case 71:
																																	goto IL_044c;
																																case 81:
																																case 136:
																																	goto IL_045a;
																																case 46:
																																	goto IL_048c;
																																case 15:
																																	goto IL_049a;
																																case 120:
																																	goto IL_04ad;
																																case 41:
																																case 74:
																																	goto IL_04bb;
																																case 13:
																																	goto IL_04d4;
																																case 106:
																																	goto IL_04eb;
																																case 18:
																																	goto IL_04f9;
																																case 72:
																																case 130:
																																	goto IL_050c;
																																case 125:
																																	goto IL_054c;
																																case 121:
																																	goto IL_0569;
																																case 11:
																																	goto IL_057c;
																																case 128:
																																case 139:
																																	goto IL_058a;
																																case 118:
																																	goto IL_0595;
																																case 78:
																																case 111:
																																	goto IL_05a0;
																																case 36:
																																	goto IL_05ae;
																																case 29:
																																case 131:
																																	goto IL_05bc;
																																case 88:
																																case 129:
																																	goto IL_05cf;
																																case 94:
																																	goto IL_05eb;
																																case 95:
																																	goto IL_05f9;
																																case 134:
																																	goto IL_060c;
																																case 1:
																																case 77:
																																	goto IL_061a;
																																case 33:
																																	goto IL_0628;
																																case 56:
																																case 84:
																																	goto IL_0633;
																																case 85:
																																	goto IL_0695;
																																case 0:
																																	goto IL_06a8;
																																case 54:
																																	goto IL_06b6;
																																case 112:
																																case 124:
																																	goto IL_06c4;
																																case 98:
																																	goto IL_06e7;
																																case 34:
																																	goto IL_06f5;
																																case 26:
																																	goto IL_0703;
																																case 43:
																																	goto IL_0716;
																																case 86:
																																	goto IL_0724;
																																case 60:
																																case 82:
																																	goto IL_0732;
																																case 102:
																																	goto IL_0772;
																																case 87:
																																	goto IL_0786;
																																case 45:
																																case 108:
																																	goto IL_079f;
																																case 90:
																																	goto IL_07b3;
																																case 114:
																																	goto IL_07f2;
																																case 3:
																																case 5:
																																case 7:
																																case 8:
																																case 14:
																																case 19:
																																case 20:
																																case 23:
																																case 25:
																																case 28:
																																case 30:
																																case 37:
																																case 55:
																																case 59:
																																case 63:
																																case 64:
																																case 66:
																																case 69:
																																case 70:
																																case 73:
																																case 76:
																																case 97:
																																case 103:
																																case 110:
																																case 113:
																																case 137:
																																	goto end_IL_02cf;
																																case 2:
																																case 4:
																																case 24:
																																case 32:
																																case 40:
																																case 51:
																																case 58:
																																case 62:
																																case 93:
																																case 99:
																																case 105:
																																case 109:
																																case 116:
																																case 126:
																																case 127:
																																case 135:
																																case 138:
																																	goto end_IL_025b;
																																case 89:
																																	goto end_IL_0815;
																																case 12:
																																	goto end_IL_0828;
																																case 123:
																																	goto end_IL_0832;
																																case 10:
																																	goto end_IL_083d;
																																case 57:
																																case 119:
																																	goto end_IL_0852;
																																case 96:
																																	goto end_IL_0862;
																																case 68:
																																case 132:
																																	goto end_IL_087b;
																																case 16:
																																	goto end_IL_088b;
																																case 17:
																																	goto end_IL_089b;
																																case 31:
																																case 79:
																																	goto IL_08b6;
																																}
																																continue;
																															}
																															num5--;
																															break;
																															continue;
																															end_IL_025b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_033f;
																												continue;
																												end_IL_02cf:
																												break;
																												IL_02cf:;
																											}
																											break;
																											IL_02df:;
																										}
																										break;
																									}
																									goto IL_037d;
																									IL_03ef:
																									if (4 <= b)
																									{
																										goto end_IL_033f;
																									}
																									break;
																									IL_037d:
																									if (5 <= b)
																									{
																										goto IL_0388;
																									}
																									goto IL_03e4;
																									IL_0388:
																									array[num5] = 0;
																									goto IL_0396;
																									IL_0396:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_03b9;
																									IL_03b9:
																									array2[num5] = null;
																									goto IL_03c3;
																									IL_03c3:
																									num5++;
																									goto IL_03d1;
																									IL_03d1:
																									ptr2 += 8;
																									goto end_IL_033f;
																									IL_03e4:
																									if (4 < b)
																									{
																										num = 64;
																										break;
																									}
																									goto IL_03ef;
																								}
																								break;
																							}
																							goto IL_0410;
																							IL_04f9:
																							ptr2 += 8;
																							goto end_IL_033f;
																							IL_0410:
																							if (3 <= b)
																							{
																								goto IL_041b;
																							}
																							goto IL_0433;
																							IL_041b:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_033f;
																							IL_0433:
																							if (1 < b)
																							{
																								goto IL_043e;
																							}
																							goto IL_04ad;
																							IL_043e:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_044c;
																							IL_044c:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_045a;
																							IL_045a:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 46;
																							goto IL_048c;
																							IL_048c:
																							ptr2 += 8;
																							goto IL_049a;
																							IL_049a:
																							num5--;
																							goto end_IL_033f;
																							IL_04ad:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_04bb;
																							IL_04bb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_04d4;
																							IL_04d4:
																							array[num5] = 0;
																							num = 106;
																							goto IL_04eb;
																							IL_04eb:
																							num5++;
																							goto IL_04f9;
																						}
																						break;
																					}
																					goto IL_050c;
																					IL_0569:
																					num5--;
																					goto end_IL_033f;
																					IL_050c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_054c;
																					IL_054c:
																					array[num5 - 2] = 0;
																					num = 121;
																					goto IL_0569;
																				}
																				break;
																			}
																			goto IL_057c;
																			IL_07f2:
																			ptr2 += 8;
																			goto end_IL_033f;
																			IL_057c:
																			if (11 < b)
																			{
																				goto IL_058a;
																			}
																			goto IL_060c;
																			IL_058a:
																			if (13 >= b)
																			{
																				goto IL_0595;
																			}
																			goto IL_05eb;
																			IL_0595:
																			if (13 > b)
																			{
																				goto IL_05a0;
																			}
																			goto IL_05cf;
																			IL_05a0:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_05ae;
																			IL_05ae:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_05bc;
																			IL_05bc:
																			num5--;
																			goto end_IL_033f;
																			IL_05cf:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_033f;
																			IL_05eb:
																			if (14 < b)
																			{
																				break;
																			}
																			goto IL_05f9;
																			IL_05f9:
																			if (14 <= b)
																			{
																			}
																			break;
																			IL_060c:
																			if (11 > b)
																			{
																				goto IL_061a;
																			}
																			goto IL_079f;
																			IL_061a:
																			if (9 >= b)
																			{
																				goto IL_0628;
																			}
																			goto IL_0716;
																			IL_0628:
																			if (9 <= b)
																			{
																				goto IL_0633;
																			}
																			goto IL_06a8;
																			IL_0633:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0695;
																			IL_0695:
																			num5 -= 2;
																			goto end_IL_033f;
																			IL_06a8:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_06b6;
																			IL_06b6:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_06c4;
																			IL_06c4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_06e7;
																			IL_06e7:
																			array[num5] = 0;
																			goto IL_06f5;
																			IL_06f5:
																			num5++;
																			goto IL_0703;
																			IL_0703:
																			ptr2 += 8;
																			goto end_IL_033f;
																			IL_0716:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0724;
																			IL_0724:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0732;
																			IL_0732:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0772;
																			IL_0772:
																			array[num5 - 2] = 0;
																			goto IL_0786;
																			IL_0786:
																			num5--;
																			num = 51;
																			goto end_IL_033f;
																			IL_079f:
																			array[num5 - 1] = 0;
																			goto IL_07b3;
																			IL_07b3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)GetRegisteredActivatedServiceTypesgetAsyncResult[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_07f2;
																		}
																		break;
																		IL_032f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_033f:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_08b6;
												IL_08b6:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0815:
												break;
											}
											continue;
											end_IL_0828:
											break;
										}
										continue;
										end_IL_0832:
										break;
									}
									continue;
									end_IL_083d:
									break;
								}
								continue;
								end_IL_0852:
								break;
							}
							continue;
							end_IL_0862:
							break;
						}
						continue;
						end_IL_087b:
						break;
					}
					continue;
					end_IL_088b:
					break;
				}
				continue;
				end_IL_089b:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 19;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StoreLocationGetRealProxy.ResponseXmlElementNameOpenExistingResult);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 92;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	if (b >= 1)
																	{
																		num = 111;
																		while (true)
																		{
																			if (num != 111)
																			{
																				if (num != 1092)
																				{
																					goto IL_0588;
																				}
																				switch (num)
																				{
																				case 75:
																					goto end_IL_01d9;
																				case 92:
																					goto end_IL_01e9;
																				case 31:
																				case 64:
																					goto end_IL_01fc;
																				case 96:
																					goto IL_022e;
																				case 14:
																					goto IL_023c;
																				case 67:
																				case 102:
																					goto IL_024a;
																				case 73:
																					goto IL_0258;
																				case 2:
																				case 46:
																					goto IL_0263;
																				case 83:
																					goto IL_02a3;
																				case 23:
																					goto IL_02b7;
																				case 10:
																					goto IL_02ca;
																				case 4:
																					goto IL_02d8;
																				case 101:
																					goto IL_02eb;
																				case 49:
																				case 65:
																					goto IL_02f9;
																				case 88:
																					goto IL_0307;
																				case 30:
																				case 82:
																					goto IL_0315;
																				case 38:
																					goto IL_0355;
																				case 72:
																					goto IL_0369;
																				case 54:
																					goto IL_037c;
																				case 24:
																				case 86:
																					goto IL_038a;
																				case 76:
																					goto IL_03b3;
																				case 103:
																					goto IL_03ca;
																				case 28:
																				case 55:
																					goto IL_03dd;
																				case 25:
																					goto IL_03eb;
																				case 44:
																					goto IL_040e;
																				case 71:
																					goto IL_0421;
																				case 22:
																					goto IL_042f;
																				case 40:
																					goto IL_0442;
																				case 48:
																					goto IL_0450;
																				case 5:
																				case 43:
																					goto IL_045b;
																				case 37:
																					goto IL_0474;
																				case 66:
																					goto IL_0482;
																				case 81:
																					goto IL_0490;
																				case 93:
																					goto IL_04a3;
																				case 62:
																					goto IL_04b1;
																				case 11:
																				case 36:
																					goto IL_04bf;
																				case 69:
																					goto IL_0508;
																				case 53:
																					goto IL_051c;
																				case 12:
																				case 26:
																					goto IL_052f;
																				case 97:
																					goto IL_053a;
																				case 42:
																				case 74:
																					goto IL_0548;
																				case 94:
																					goto IL_0588;
																				case 91:
																					goto IL_059c;
																				case 89:
																					goto IL_05af;
																				case 85:
																					goto IL_05ba;
																				case 1:
																				case 95:
																					goto IL_05c5;
																				case 0:
																				case 6:
																				case 13:
																				case 17:
																				case 21:
																				case 27:
																				case 29:
																				case 34:
																				case 45:
																				case 47:
																				case 52:
																				case 58:
																				case 60:
																				case 61:
																				case 70:
																				case 78:
																				case 84:
																				case 90:
																				case 98:
																					goto IL_05de;
																				case 99:
																					goto IL_060a;
																				case 79:
																					goto IL_0618;
																				case 68:
																					goto IL_0626;
																				case 7:
																				case 9:
																				case 33:
																				case 39:
																				case 41:
																				case 56:
																				case 57:
																				case 59:
																				case 63:
																				case 87:
																				case 104:
																					goto end_IL_020c;
																				case 50:
																					goto end_IL_0634;
																				case 16:
																					goto end_IL_0647;
																				case 20:
																					goto end_IL_0651;
																				case 15:
																					goto end_IL_065c;
																				case 80:
																					goto end_IL_0671;
																				case 3:
																				case 100:
																					goto end_IL_0686;
																				case 32:
																					goto end_IL_0696;
																				case 8:
																				case 35:
																					goto end_IL_06a6;
																				case 18:
																					goto end_IL_06b6;
																				case 19:
																					goto end_IL_06c6;
																				case 51:
																				case 77:
																					goto IL_06ea;
																				}
																				continue;
																			}
																			if (b <= 9)
																			{
																				goto IL_022e;
																			}
																			goto IL_05de;
																			IL_05af:
																			if (9 >= b)
																			{
																				goto IL_05ba;
																			}
																			goto IL_05de;
																			IL_05c5:
																			byte* num5 = ptr2;
																			num4 = 1;
																			ptr2 = num5 + -200;
																			goto end_IL_020c;
																			IL_05ba:
																			if (9 <= b)
																			{
																				goto IL_05c5;
																			}
																			goto IL_05de;
																			IL_022e:
																			if (5 >= b)
																			{
																				goto IL_023c;
																			}
																			goto IL_0442;
																			IL_023c:
																			if (5 > b)
																			{
																				goto IL_024a;
																			}
																			goto IL_03dd;
																			IL_024a:
																			if (2 >= b)
																			{
																				goto IL_0258;
																			}
																			goto IL_02eb;
																			IL_0258:
																			if (2 <= b)
																			{
																				goto IL_0263;
																			}
																			goto IL_02ca;
																			IL_0263:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_02a3;
																			IL_02a3:
																			array[num6 - 2] = 0;
																			goto IL_02b7;
																			IL_02b7:
																			num6--;
																			goto end_IL_020c;
																			IL_02ca:
																			if (1 >= b)
																			{
																				goto IL_02d8;
																			}
																			goto IL_05de;
																			IL_02d8:
																			if (1 > b)
																			{
																			}
																			goto IL_05de;
																			IL_02eb:
																			if (3 < b)
																			{
																				goto IL_02f9;
																			}
																			goto IL_037c;
																			IL_02f9:
																			if (4 >= b)
																			{
																				goto IL_0307;
																			}
																			goto IL_05de;
																			IL_0307:
																			if (4 <= b)
																			{
																				goto IL_0315;
																			}
																			goto IL_05de;
																			IL_0315:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0355;
																			IL_0355:
																			array[num6 - 2] = 0;
																			goto IL_0369;
																			IL_0369:
																			num6--;
																			goto end_IL_020c;
																			IL_037c:
																			if (3 <= b)
																			{
																				goto IL_038a;
																			}
																			goto IL_05de;
																			IL_038a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_03b3;
																			IL_03b3:
																			ptr2 += 8;
																			num = 103;
																			goto IL_03ca;
																			IL_03ca:
																			num6--;
																			goto end_IL_020c;
																			IL_03dd:
																			array[num6] = 0;
																			goto IL_03eb;
																			IL_03eb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_040e;
																			IL_040e:
																			array2[num6] = null;
																			num = 71;
																			goto IL_0421;
																			IL_0421:
																			num6++;
																			goto IL_042f;
																			IL_042f:
																			ptr2 += 8;
																			goto end_IL_020c;
																			IL_0442:
																			if (7 >= b)
																			{
																				goto IL_0450;
																			}
																			goto IL_052f;
																			IL_0450:
																			if (7 <= b)
																			{
																				goto IL_045b;
																			}
																			goto IL_04a3;
																			IL_045b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0474;
																			IL_0474:
																			array[num6] = 0;
																			goto IL_0482;
																			IL_0482:
																			num6++;
																			goto IL_0490;
																			IL_0490:
																			ptr2 += 8;
																			goto end_IL_020c;
																			IL_04a3:
																			if (6 >= b)
																			{
																				goto IL_04b1;
																			}
																			goto IL_05de;
																			IL_04b1:
																			if (6 <= b)
																			{
																				goto IL_04bf;
																			}
																			goto IL_05de;
																			IL_04bf:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			num = 69;
																			goto IL_0508;
																			IL_0508:
																			array[num6 - 2] = 0;
																			goto IL_051c;
																			IL_051c:
																			num6--;
																			goto end_IL_020c;
																			IL_052f:
																			if (8 >= b)
																			{
																				goto IL_053a;
																			}
																			goto IL_05af;
																			IL_053a:
																			if (8 <= b)
																			{
																				goto IL_0548;
																			}
																			goto IL_05de;
																			IL_0548:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0588;
																			IL_0588:
																			array[num6 - 2] = 0;
																			goto IL_059c;
																			IL_059c:
																			num6--;
																			goto end_IL_020c;
																			continue;
																			end_IL_01d9:
																			break;
																		}
																		continue;
																	}
																	goto IL_05de;
																	IL_0618:
																	num6++;
																	goto IL_0626;
																	IL_0626:
																	ptr2 += 8;
																	goto end_IL_020c;
																	IL_05de:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	num = 99;
																	goto IL_060a;
																	IL_060a:
																	array[num6] = 0;
																	goto IL_0618;
																	continue;
																	end_IL_01e9:
																	break;
																}
																continue;
																end_IL_01fc:
																break;
															}
															continue;
															end_IL_020c:
															break;
														}
														continue;
													}
													num = 51;
													goto IL_06ea;
													IL_06ea:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0634:
													break;
												}
												continue;
												end_IL_0647:
												break;
											}
											continue;
											end_IL_0651:
											break;
										}
										continue;
										end_IL_065c:
										break;
									}
									continue;
									end_IL_0671:
									break;
								}
								continue;
								end_IL_0686:
								break;
							}
							continue;
							end_IL_0696:
							break;
						}
						continue;
						end_IL_06a6:
						break;
					}
					continue;
					end_IL_06b6:
					break;
				}
				continue;
				end_IL_06c6:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							IL_0208:
							num = 73;
							while (true)
							{
								IL_01f8:
								int[] array3 = new int[3];
								while (true)
								{
									IL_01e8:
									long[] array4 = new long[2];
									while (true)
									{
										IL_01d3:
										array3[0] = int_2;
										while (true)
										{
											IL_01be:
											array3[1] = int_3;
											while (true)
											{
												IL_01b3:
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MaxSizepermissionSetID.getVisualizerTypeNamegetIsEnabled);
												while (true)
												{
													IL_01a9:
													byte* ptr2 = ptr;
													while (true)
													{
														IL_019e:
														num = 95;
														while (true)
														{
															if (num != 95)
															{
																if (num != 1076)
																{
																	break;
																}
																switch (num)
																{
																case 86:
																	goto IL_019e;
																case 43:
																	goto IL_01a9;
																case 58:
																	goto IL_01b3;
																case 5:
																	goto IL_01be;
																case 25:
																	goto IL_01d3;
																case 55:
																	goto IL_01e8;
																case 73:
																	goto IL_01f8;
																case 28:
																	goto IL_0208;
																case 83:
																	goto end_IL_018b;
																case 24:
																case 29:
																	goto end_IL_0213;
																case 20:
																	goto end_IL_0223;
																case 21:
																	goto end_IL_0233;
																case 9:
																case 13:
																case 30:
																case 34:
																case 52:
																case 69:
																case 70:
																case 71:
																case 81:
																	goto IL_024e;
																case 0:
																case 67:
																	goto IL_025e;
																case 54:
																	goto IL_0267;
																case 41:
																	goto IL_0275;
																case 26:
																	goto IL_0283;
																case 50:
																	goto IL_0291;
																case 60:
																case 79:
																	goto IL_029f;
																case 39:
																	goto IL_02aa;
																case 2:
																case 8:
																	goto IL_02b5;
																case 27:
																	goto IL_02c3;
																case 16:
																case 82:
																	goto IL_02d1;
																case 74:
																	goto IL_02f2;
																case 6:
																case 37:
																	goto IL_02fd;
																case 15:
																	goto IL_030b;
																case 49:
																case 76:
																	goto IL_0319;
																case 18:
																	goto IL_0335;
																case 10:
																case 51:
																	goto IL_0343;
																case 63:
																	goto IL_0351;
																case 36:
																	goto IL_037d;
																case 78:
																	goto IL_0387;
																case 14:
																	goto IL_0395;
																case 53:
																	goto IL_03a8;
																case 12:
																case 23:
																	goto IL_03b6;
																case 19:
																	goto IL_03c4;
																case 75:
																	goto IL_03d2;
																case 17:
																case 65:
																	goto IL_03e0;
																case 45:
																	goto IL_0420;
																case 85:
																	goto IL_0434;
																case 88:
																	goto IL_0447;
																case 32:
																case 46:
																	goto IL_0455;
																case 7:
																	goto IL_04c3;
																case 84:
																	goto IL_04d6;
																case 77:
																	goto IL_04e4;
																case 3:
																case 33:
																	goto IL_04f7;
																case 4:
																	goto IL_0520;
																case 11:
																	goto IL_052e;
																case 64:
																	goto IL_054a;
																case 1:
																	goto IL_0558;
																case 57:
																	goto IL_0566;
																case 22:
																case 31:
																case 35:
																case 38:
																case 40:
																case 42:
																case 47:
																case 48:
																case 56:
																case 59:
																case 61:
																case 62:
																case 66:
																case 68:
																case 80:
																case 87:
																	goto IL_0579;
																case 44:
																case 72:
																	goto IL_05a7;
																}
																continue;
															}
															goto IL_024e;
															IL_054a:
															array[num4] = 0;
															goto IL_0558;
															IL_0558:
															num4++;
															goto IL_0566;
															IL_024e:
															if (num5 != 1)
															{
																goto IL_025e;
															}
															num = 44;
															goto IL_05a7;
															IL_0566:
															ptr2 += 8;
															goto IL_024e;
															IL_05a7:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
															IL_025e:
															b = *ptr2;
															goto IL_0267;
															IL_0267:
															ptr2++;
															goto IL_0275;
															IL_0275:
															if (b >= 1)
															{
																goto IL_0283;
															}
															goto IL_0579;
															IL_0283:
															if (b <= 8)
															{
																goto IL_0291;
															}
															goto IL_0579;
															IL_0291:
															if (4 < b)
															{
																goto IL_029f;
															}
															goto IL_03a8;
															IL_029f:
															if (6 >= b)
															{
																goto IL_02aa;
															}
															goto IL_02f2;
															IL_02aa:
															if (6 <= b)
															{
																goto IL_024e;
															}
															goto IL_02b5;
															IL_02b5:
															if (5 >= b)
															{
																goto IL_02c3;
															}
															goto IL_0579;
															IL_02c3:
															if (5 <= b)
															{
																goto IL_02d1;
															}
															goto IL_0579;
															IL_02d1:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															num = 69;
															goto IL_024e;
															IL_02f2:
															if (7 < b)
															{
																goto IL_02fd;
															}
															goto IL_0335;
															IL_02fd:
															if (8 >= b)
															{
																goto IL_030b;
															}
															goto IL_0579;
															IL_030b:
															if (8 <= b)
															{
																goto IL_0319;
															}
															goto IL_0579;
															IL_0319:
															byte* num6 = ptr2;
															num5 = 1;
															ptr2 = num6 + -200;
															goto IL_024e;
															IL_0335:
															if (7 <= b)
															{
																goto IL_0343;
															}
															goto IL_0579;
															IL_0343:
															array[num4] = 0;
															goto IL_0351;
															IL_0351:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
															num = 36;
															goto IL_037d;
															IL_037d:
															array2[num4] = null;
															goto IL_0387;
															IL_0387:
															num4++;
															goto IL_0395;
															IL_0395:
															ptr2 += 8;
															goto IL_024e;
															IL_03a8:
															if (4 > b)
															{
																goto IL_03b6;
															}
															goto IL_04f7;
															IL_03b6:
															if (2 < b)
															{
																goto IL_03c4;
															}
															goto IL_0447;
															IL_03c4:
															if (3 >= b)
															{
																goto IL_03d2;
															}
															goto IL_0579;
															IL_03d2:
															if (3 <= b)
															{
																goto IL_03e0;
															}
															goto IL_0579;
															IL_03e0:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
															goto IL_0420;
															IL_0420:
															array[num4 - 2] = 0;
															goto IL_0434;
															IL_0434:
															num4--;
															goto IL_024e;
															IL_0447:
															if (2 <= b)
															{
																goto IL_0455;
															}
															goto IL_04d6;
															IL_0455:
															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_04c3;
															IL_04c3:
															num4 -= 2;
															goto IL_024e;
															IL_04d6:
															if (1 >= b)
															{
																goto IL_04e4;
															}
															goto IL_0579;
															IL_04e4:
															if (1 <= b)
															{
															}
															goto IL_0579;
															IL_04f7:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
															goto IL_0520;
															IL_0520:
															ptr2 += 8;
															goto IL_052e;
															IL_052e:
															num4--;
															num = 71;
															goto IL_024e;
															IL_0579:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
															goto IL_054a;
															continue;
															end_IL_018b:
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0213:
						break;
					}
					continue;
					end_IL_0223:
					break;
				}
				continue;
				end_IL_0233:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 20;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getUniqueKeyContainerNameIsolatedStoragePermissionAttribute.FactorySerializationInfoEnumerator);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 109;
															while (true)
															{
																if (num != 109)
																{
																	if (num != 1090)
																	{
																		goto IL_0468;
																	}
																	switch (num)
																	{
																	case 50:
																		goto end_IL_01c3;
																	case 4:
																	case 39:
																		goto end_IL_01d3;
																	case 6:
																		goto IL_0205;
																	case 52:
																		goto IL_0213;
																	case 14:
																		goto IL_0221;
																	case 31:
																	case 64:
																		goto IL_022f;
																	case 80:
																	case 102:
																		goto IL_023a;
																	case 90:
																		goto IL_0245;
																	case 22:
																	case 35:
																		goto IL_0253;
																	case 13:
																		goto IL_026b;
																	case 12:
																		goto IL_0279;
																	case 85:
																		goto IL_028c;
																	case 46:
																	case 75:
																		goto IL_0297;
																	case 82:
																		goto IL_02c0;
																	case 79:
																		goto IL_02ce;
																	case 41:
																		goto IL_02e1;
																	case 92:
																		goto IL_02f8;
																	case 11:
																	case 32:
																		goto IL_0306;
																	case 17:
																		goto IL_031f;
																	case 78:
																		goto IL_032d;
																	case 43:
																		goto IL_033b;
																	case 2:
																	case 81:
																		goto IL_034e;
																	case 88:
																		goto IL_0365;
																	case 0:
																		goto IL_0388;
																	case 47:
																		goto IL_0392;
																	case 72:
																		goto IL_03a0;
																	case 49:
																		goto IL_03b3;
																	case 18:
																		goto IL_03c1;
																	case 40:
																	case 86:
																		goto IL_03cc;
																	case 27:
																		goto IL_042e;
																	case 61:
																		goto IL_0441;
																	case 42:
																		goto IL_044c;
																	case 28:
																		goto IL_045a;
																	case 3:
																	case 15:
																		goto IL_0468;
																	case 70:
																		goto IL_048b;
																	case 96:
																		goto IL_0499;
																	case 84:
																		goto IL_04a7;
																	case 16:
																		goto IL_04c3;
																	case 36:
																	case 45:
																		goto IL_04d1;
																	case 93:
																		goto IL_0511;
																	case 58:
																		goto IL_052e;
																	case 56:
																		goto IL_053e;
																	case 38:
																		goto IL_0549;
																	case 37:
																		goto IL_0554;
																	case 33:
																		goto IL_056a;
																	case 30:
																	case 34:
																		goto IL_0575;
																	case 1:
																	case 5:
																	case 7:
																	case 8:
																	case 9:
																	case 19:
																	case 25:
																	case 26:
																	case 48:
																	case 53:
																	case 55:
																	case 57:
																	case 59:
																	case 60:
																	case 66:
																	case 71:
																	case 83:
																	case 89:
																	case 95:
																	case 100:
																		goto IL_058e;
																	case 10:
																	case 24:
																	case 29:
																	case 44:
																	case 54:
																	case 62:
																	case 65:
																	case 69:
																	case 74:
																	case 76:
																	case 87:
																	case 98:
																	case 99:
																		goto end_IL_01ec;
																	case 94:
																		goto end_IL_05a1;
																	case 91:
																		goto end_IL_05b4;
																	case 77:
																		goto end_IL_05be;
																	case 67:
																		goto end_IL_05c9;
																	case 97:
																	case 101:
																		goto end_IL_05de;
																	case 73:
																		goto end_IL_05ee;
																	case 23:
																	case 68:
																		goto end_IL_05fe;
																	case 20:
																		goto end_IL_060e;
																	case 21:
																		goto end_IL_061e;
																	case 51:
																	case 63:
																		goto IL_0642;
																	}
																	continue;
																}
																if (b >= 1)
																{
																	goto IL_0205;
																}
																goto IL_058e;
																IL_0549:
																if (10 >= b)
																{
																	goto IL_0554;
																}
																goto IL_058e;
																IL_058e:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_01ec;
																IL_0554:
																if (10 <= b)
																{
																}
																goto IL_058e;
																IL_0205:
																if (b <= 10)
																{
																	goto IL_0213;
																}
																goto IL_058e;
																IL_0213:
																if (5 >= b)
																{
																	goto IL_0221;
																}
																goto IL_03b3;
																IL_0221:
																if (5 > b)
																{
																	goto IL_022f;
																}
																goto IL_034e;
																IL_022f:
																if (2 < b)
																{
																	goto IL_023a;
																}
																goto IL_028c;
																IL_023a:
																if (3 >= b)
																{
																	goto IL_0245;
																}
																goto IL_026b;
																IL_0245:
																if (3 <= b)
																{
																	goto IL_0253;
																}
																goto IL_058e;
																IL_0253:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_01ec;
																IL_026b:
																if (4 >= b)
																{
																	goto IL_0279;
																}
																goto IL_058e;
																IL_0279:
																if (4 <= b)
																{
																	goto end_IL_01ec;
																}
																goto IL_058e;
																IL_028c:
																if (2 <= b)
																{
																	goto IL_0297;
																}
																goto IL_02e1;
																IL_0297:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_02c0;
																IL_02c0:
																ptr2 += 8;
																goto IL_02ce;
																IL_02ce:
																num5--;
																goto end_IL_01ec;
																IL_02e1:
																if (1 >= b)
																{
																	num = 92;
																	goto IL_02f8;
																}
																goto IL_058e;
																IL_056a:
																if (9 <= b)
																{
																	goto IL_0575;
																}
																goto IL_058e;
																IL_02f8:
																if (1 <= b)
																{
																	goto IL_0306;
																}
																goto IL_058e;
																IL_0306:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_031f;
																IL_031f:
																array[num5] = 0;
																goto IL_032d;
																IL_032d:
																num5++;
																goto IL_033b;
																IL_033b:
																ptr2 += 8;
																goto end_IL_01ec;
																IL_034e:
																array[num5] = 0;
																num = 88;
																goto IL_0365;
																IL_0365:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0388;
																IL_0388:
																array2[num5] = null;
																goto IL_0392;
																IL_0392:
																num5++;
																goto IL_03a0;
																IL_03a0:
																ptr2 += 8;
																goto end_IL_01ec;
																IL_03b3:
																if (8 >= b)
																{
																	goto IL_03c1;
																}
																goto IL_053e;
																IL_03c1:
																if (8 <= b)
																{
																	goto IL_03cc;
																}
																goto IL_0441;
																IL_03cc:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_042e;
																IL_042e:
																num5 -= 2;
																goto end_IL_01ec;
																IL_0441:
																if (6 < b)
																{
																	goto IL_044c;
																}
																num = 16;
																goto IL_04c3;
																IL_044c:
																if (7 >= b)
																{
																	goto IL_045a;
																}
																goto IL_058e;
																IL_045a:
																if (7 <= b)
																{
																	goto IL_0468;
																}
																goto IL_058e;
																IL_0468:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_048b;
																IL_048b:
																array[num5] = 0;
																goto IL_0499;
																IL_0499:
																num5++;
																goto IL_04a7;
																IL_04a7:
																ptr2 += 8;
																goto end_IL_01ec;
																IL_0575:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_01ec;
																IL_04c3:
																if (6 <= b)
																{
																	goto IL_04d1;
																}
																goto IL_058e;
																IL_04d1:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0511;
																IL_0511:
																array[num5 - 2] = 0;
																num = 58;
																goto IL_052e;
																IL_052e:
																num5--;
																goto end_IL_01ec;
																IL_053e:
																if (9 < b)
																{
																	goto IL_0549;
																}
																num = 33;
																goto IL_056a;
																continue;
																end_IL_01c3:
																break;
															}
															continue;
															end_IL_01d3:
															break;
														}
														continue;
														end_IL_01ec:
														break;
													}
													continue;
												}
												goto IL_0642;
												IL_0642:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05a1:
												break;
											}
											continue;
											end_IL_05b4:
											break;
										}
										continue;
										end_IL_05be:
										break;
									}
									continue;
									end_IL_05c9:
									break;
								}
								continue;
								end_IL_05de:
								break;
							}
							continue;
							end_IL_05ee:
							break;
						}
						continue;
						end_IL_05fe:
						break;
					}
					continue;
					end_IL_060e:
					break;
				}
				continue;
				end_IL_061e:
				break;
			}
		}
	}

	static Class14()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 0:
								goto IL_0046;
							case 4:
								goto end_IL_0039;
							case 5:
								goto end_IL_0052;
							case 1:
								return;
							case 2:
								return;
							case 3:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				continue;
				end_IL_0052:
				break;
			}
		}
	}
}
