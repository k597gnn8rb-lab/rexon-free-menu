using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Head Spin", "Rig", "Spins your head.", false, 3, ModType.const_0, false)]
internal class Class182 : MonoBehaviour
{
	private float float_0;

	private static int int_0;

	private static int int_1;

	private static bool bool_0;

	private static bool bool_1;

	private static double double_0;

	private static double double_1;

	private static double double_2;

	private static IntPtr[] IntegerEnumInstallerDeploymentMetadata;

	private static IntPtr[] ActivatorLevelgetArray;

	private static IntPtr[] ConvertTimeBySystemTimeZoneIdCreateServerChannelSinkChain;

	private static IntPtr[] ApplicationsgetIsGlobalTypeDefToken;

	private static IntPtr[] ObjectAceTypeCurrentAssembly;

	private unsafe void Update()
	{
		int num = 271;
		int num5 = default(int);
		int num7 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 309;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									int[] array4 = new int[7];
									num = 263;
									while (true)
									{
										long[] array5 = new long[4];
										while (true)
										{
											object[] array6 = new object[1];
											while (true)
											{
												array6[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SEPSecondSuffKeyProperty.TrustedCredentialManagerAccessgetDisallowPublisherPolicy);
													num = 165;
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																IL_0675:
																byte b = *ptr2;
																while (true)
																{
																	IL_0665:
																	ptr2++;
																	while (true)
																	{
																		IL_0655:
																		if (b >= 1)
																		{
																			while (b <= 42)
																			{
																				while (true)
																				{
																					IL_0635:
																					if (21 < b)
																					{
																						while (true)
																						{
																							IL_0625:
																							if (32 < b)
																							{
																								while (true)
																								{
																									IL_0618:
																									if (37 < b)
																									{
																										while (true)
																										{
																											IL_0608:
																											if (40 < b)
																											{
																												while (true)
																												{
																													IL_05f8:
																													if (41 < b)
																													{
																														while (42 >= b)
																														{
																															num = 208;
																															while (42 <= b)
																															{
																																num = 357;
																																while (num != 357)
																																{
																																	if (num != 1338)
																																	{
																																		goto end_IL_0655;
																																	}
																																	switch (num)
																																	{
																																	case 208:
																																		goto IL_05d2;
																																	case 150:
																																		goto IL_05e5;
																																	case 232:
																																		goto IL_05f8;
																																	case 253:
																																		goto IL_0608;
																																	case 70:
																																		goto IL_0618;
																																	case 95:
																																		goto IL_0625;
																																	case 118:
																																		goto IL_0635;
																																	case 86:
																																		goto IL_0645;
																																	case 258:
																																		goto IL_0655;
																																	case 283:
																																		goto IL_0665;
																																	case 236:
																																	case 249:
																																		goto IL_0675;
																																	case 151:
																																		goto IL_0680;
																																	case 85:
																																	case 138:
																																		goto IL_068b;
																																	case 113:
																																		goto IL_06a8;
																																	case 166:
																																		goto IL_06ec;
																																	case 187:
																																		goto IL_06ff;
																																	case 72:
																																		goto IL_070a;
																																	case 223:
																																		goto IL_0723;
																																	case 92:
																																		goto IL_0731;
																																	case 218:
																																		goto IL_073f;
																																	case 238:
																																		goto IL_075b;
																																	case 160:
																																		goto IL_0769;
																																	case 111:
																																	case 210:
																																		goto IL_0777;
																																	case 77:
																																		goto IL_078b;
																																	case 129:
																																		goto IL_07d8;
																																	case 252:
																																		goto IL_07eb;
																																	case 148:
																																	case 204:
																																		goto IL_0802;
																																	case 102:
																																		goto IL_0870;
																																	case 250:
																																	case 260:
																																		goto IL_0883;
																																	case 237:
																																	case 269:
																																		goto IL_089c;
																																	case 172:
																																		goto IL_08e4;
																																	case 235:
																																	case 290:
																																		goto IL_08f7;
																																	case 300:
																																		goto IL_091c;
																																	case 65:
																																		goto IL_092a;
																																	case 155:
																																		goto IL_0941;
																																	case 47:
																																	case 170:
																																		goto IL_0958;
																																	case 178:
																																		goto IL_09b8;
																																	case 304:
																																		goto IL_09d4;
																																	case 9:
																																		goto IL_0a13;
																																	case 307:
																																		goto IL_0a26;
																																	case 316:
																																		goto IL_0a36;
																																	case 12:
																																	case 281:
																																		goto IL_0a44;
																																	case 284:
																																		goto IL_0a7c;
																																	case 199:
																																		goto IL_0a90;
																																	case 248:
																																	case 332:
																																		goto IL_0aa3;
																																	case 28:
																																		goto IL_0aca;
																																	case 23:
																																		goto IL_0ade;
																																	case 336:
																																		goto IL_0afc;
																																	case 112:
																																		goto IL_0b0a;
																																	case 255:
																																		goto IL_0b18;
																																	case 30:
																																		goto IL_0b26;
																																	case 181:
																																		goto IL_0b34;
																																	case 296:
																																		goto IL_0b42;
																																	case 317:
																																		goto IL_0b50;
																																	case 198:
																																	case 212:
																																		goto IL_0b5e;
																																	case 240:
																																		goto IL_0b72;
																																	case 88:
																																		goto IL_0bb1;
																																	case 98:
																																	case 186:
																																		goto IL_0bc4;
																																	case 60:
																																		goto IL_0c04;
																																	case 24:
																																		goto IL_0c18;
																																	case 279:
																																		goto IL_0c34;
																																	case 161:
																																		goto IL_0c3f;
																																	case 130:
																																		goto IL_0c4d;
																																	case 143:
																																	case 303:
																																		goto IL_0c64;
																																	case 104:
																																		goto IL_0c72;
																																	case 207:
																																		goto IL_0c96;
																																	case 11:
																																		goto IL_0ca4;
																																	case 71:
																																		goto IL_0cb7;
																																	case 164:
																																	case 277:
																																		goto IL_0cc5;
																																	case 256:
																																		goto IL_0ce2;
																																	case 114:
																																		goto IL_0d21;
																																	case 53:
																																	case 203:
																																		goto IL_0d34;
																																	case 205:
																																		goto IL_0d74;
																																	case 266:
																																		goto IL_0d88;
																																	case 274:
																																		goto IL_0da4;
																																	case 126:
																																		goto IL_0db2;
																																	case 142:
																																	case 287:
																																		goto IL_0dbd;
																																	case 57:
																																		goto IL_0dd6;
																																	case 163:
																																		goto IL_0de9;
																																	case 16:
																																		goto IL_0df4;
																																	case 73:
																																	case 134:
																																		goto IL_0e02;
																																	case 191:
																																		goto IL_0e10;
																																	case 295:
																																		goto IL_0e2e;
																																	case 131:
																																		goto IL_0e3c;
																																	case 310:
																																		goto IL_0e4f;
																																	case 176:
																																		goto IL_0e5d;
																																	case 52:
																																	case 220:
																																		goto IL_0e74;
																																	case 197:
																																		goto IL_0eb5;
																																	case 282:
																																		goto IL_0ec9;
																																	case 242:
																																		goto IL_0edc;
																																	case 103:
																																		goto IL_0ee7;
																																	case 315:
																																		goto IL_0efa;
																																	case 297:
																																		goto IL_0f08;
																																	case 74:
																																	case 328:
																																		goto IL_0f16;
																																	case 294:
																																		goto IL_0f34;
																																	case 323:
																																		goto IL_0f42;
																																	case 96:
																																		goto IL_0f50;
																																	case 21:
																																	case 119:
																																		goto IL_0f6c;
																																	case 179:
																																		goto IL_0f76;
																																	case 254:
																																		goto IL_0f84;
																																	case 337:
																																		goto IL_0f97;
																																	case 343:
																																		goto IL_0faa;
																																	case 347:
																																		goto IL_0fbd;
																																	case 286:
																																	case 348:
																																		goto IL_0fd0;
																																	case 6:
																																		goto IL_0fe4;
																																	case 326:
																																		goto IL_1023;
																																	case 78:
																																		goto IL_1036;
																																	case 153:
																																		goto IL_1044;
																																	case 41:
																																		goto IL_1052;
																																	case 122:
																																	case 245:
																																		goto IL_105d;
																																	case 125:
																																		goto IL_10bf;
																																	case 171:
																																		goto IL_10d2;
																																	case 202:
																																		goto IL_10e0;
																																	case 61:
																																		goto IL_10ee;
																																	case 268:
																																		goto IL_10fc;
																																	case 26:
																																	case 123:
																																		goto IL_1107;
																																	case 137:
																																		goto IL_1147;
																																	case 29:
																																		goto IL_115b;
																																	case 308:
																																		goto IL_116e;
																																	case 214:
																																		goto IL_1185;
																																	case 189:
																																	case 334:
																																		goto IL_1193;
																																	case 259:
																																		goto IL_11ac;
																																	case 76:
																																		goto IL_11ba;
																																	case 132:
																																		goto IL_11c8;
																																	case 107:
																																		goto IL_11db;
																																	case 135:
																																		goto IL_11e6;
																																	case 49:
																																	case 228:
																																		goto IL_11f4;
																																	case 247:
																																		goto IL_121d;
																																	case 345:
																																		goto IL_122b;
																																	case 275:
																																		goto IL_123e;
																																	case 211:
																																		goto IL_124c;
																																	case 35:
																																	case 67:
																																		goto IL_125a;
																																	case 319:
																																		goto IL_1268;
																																	case 14:
																																		goto IL_128b;
																																	case 38:
																																		goto IL_1295;
																																	case 58:
																																		goto IL_12a3;
																																	case 94:
																																	case 173:
																																		goto IL_12b6;
																																	case 108:
																																		goto IL_12f6;
																																	case 193:
																																		goto IL_130a;
																																	case 115:
																																		goto IL_131d;
																																	case 48:
																																		goto IL_132b;
																																	case 93:
																																	case 340:
																																		goto IL_1336;
																																	case 109:
																																		goto IL_1376;
																																	case 110:
																																		goto IL_138a;
																																	case 7:
																																		goto IL_139d;
																																	case 62:
																																		goto IL_13ab;
																																	case 216:
																																	case 221:
																																		goto IL_13b9;
																																	case 206:
																																		goto IL_13f9;
																																	case 190:
																																		goto IL_140d;
																																	case 194:
																																		goto IL_1420;
																																	case 63:
																																		goto IL_142b;
																																	case 127:
																																	case 169:
																																		goto IL_1439;
																																	case 158:
																																		goto IL_144c;
																																	case 116:
																																		goto IL_145a;
																																	case 45:
																																	case 99:
																																		goto IL_1468;
																																	case 83:
																																		goto IL_14b1;
																																	case 84:
																																		goto IL_14ce;
																																	case 288:
																																		goto IL_14e1;
																																	case 219:
																																		goto IL_14ef;
																																	case 262:
																																		goto IL_14fd;
																																	case 311:
																																	case 330:
																																		goto IL_1508;
																																	case 10:
																																		goto IL_1522;
																																	case 183:
																																		goto IL_1530;
																																	case 338:
																																		goto IL_153e;
																																	case 46:
																																		goto IL_1551;
																																	case 162:
																																		goto IL_155c;
																																	case 257:
																																	case 324:
																																		goto IL_156a;
																																	case 157:
																																		goto IL_1582;
																																	case 243:
																																		goto IL_1590;
																																	case 280:
																																		goto IL_15a7;
																																	case 276:
																																		goto IL_15ba;
																																	case 272:
																																		goto IL_15c8;
																																	case 100:
																																	case 346:
																																		goto IL_15d6;
																																	case 299:
																																		goto IL_1614;
																																	case 265:
																																		goto IL_1628;
																																	case 141:
																																		goto IL_163b;
																																	case 121:
																																		goto IL_1646;
																																	case 192:
																																	case 251:
																																		goto IL_1654;
																																	case 2:
																																		goto IL_1694;
																																	case 341:
																																		goto IL_16a8;
																																	case 81:
																																		goto IL_16bb;
																																	case 289:
																																		goto IL_16c9;
																																	case 87:
																																	case 180:
																																		goto IL_16d7;
																																	case 291:
																																		goto IL_1705;
																																	case 215:
																																		goto IL_1721;
																																	case 149:
																																	case 267:
																																		goto IL_172c;
																																	case 177:
																																		goto IL_177e;
																																	case 306:
																																		goto IL_1791;
																																	case 226:
																																		goto IL_179c;
																																	case 97:
																																		goto IL_17a7;
																																	case 209:
																																		goto IL_17b5;
																																	case 313:
																																	case 327:
																																		goto IL_17c8;
																																	case 147:
																																		goto IL_17e1;
																																	case 312:
																																		goto IL_17ef;
																																	case 342:
																																		goto IL_17fd;
																																	case 34:
																																		goto IL_1810;
																																	case 128:
																																		goto IL_181b;
																																	case 234:
																																	case 320:
																																		goto IL_1832;
																																	case 66:
																																		goto IL_184a;
																																	case 19:
																																		goto IL_1858;
																																	case 89:
																																	case 273:
																																		goto IL_1866;
																																	case 264:
																																		goto IL_18b0;
																																	case 200:
																																		goto IL_18c4;
																																	case 322:
																																	case 335:
																																		goto IL_18d4;
																																	case 106:
																																		goto IL_18ed;
																																	case 350:
																																		goto IL_18fb;
																																	case 3:
																																		goto IL_1909;
																																	case 0:
																																	case 13:
																																	case 15:
																																	case 22:
																																	case 25:
																																	case 37:
																																	case 40:
																																	case 42:
																																	case 44:
																																	case 50:
																																	case 51:
																																	case 56:
																																	case 69:
																																	case 79:
																																	case 80:
																																	case 91:
																																	case 117:
																																	case 124:
																																	case 136:
																																	case 140:
																																	case 145:
																																	case 146:
																																	case 167:
																																	case 175:
																																	case 184:
																																	case 185:
																																	case 188:
																																	case 195:
																																	case 213:
																																	case 224:
																																	case 225:
																																	case 227:
																																	case 233:
																																	case 244:
																																	case 246:
																																	case 285:
																																	case 292:
																																	case 302:
																																	case 305:
																																	case 318:
																																	case 325:
																																	case 329:
																																	case 339:
																																	case 344:
																																		goto end_IL_05bf;
																																	case 1:
																																	case 4:
																																	case 5:
																																	case 8:
																																	case 17:
																																	case 18:
																																	case 20:
																																	case 27:
																																	case 31:
																																	case 32:
																																	case 33:
																																	case 36:
																																	case 39:
																																	case 43:
																																	case 54:
																																	case 55:
																																	case 59:
																																	case 64:
																																	case 75:
																																	case 82:
																																	case 101:
																																	case 120:
																																	case 133:
																																	case 139:
																																	case 144:
																																	case 152:
																																	case 154:
																																	case 156:
																																	case 168:
																																	case 182:
																																	case 196:
																																	case 217:
																																	case 230:
																																	case 231:
																																	case 239:
																																	case 241:
																																	case 261:
																																	case 278:
																																	case 293:
																																	case 301:
																																	case 314:
																																	case 321:
																																	case 331:
																																	case 333:
																																	case 349:
																																		goto end_IL_0655;
																																	case 165:
																																		goto end_IL_192c;
																																	case 105:
																																		goto end_IL_193f;
																																	case 229:
																																		goto end_IL_1949;
																																	case 222:
																																		goto end_IL_195d;
																																	case 263:
																																		goto end_IL_196d;
																																	case 174:
																																		goto end_IL_197d;
																																	case 159:
																																		goto end_IL_198d;
																																	case 298:
																																		goto end_IL_19a6;
																																	case 90:
																																		goto end_IL_19b6;
																																	case 309:
																																		goto end_IL_19c6;
																																	case 270:
																																		goto end_IL_19d6;
																																	case 271:
																																		goto end_IL_19e6;
																																	case 68:
																																	case 201:
																																		return;
																																	}
																																	continue;
																																	end_IL_05bf:
																																	break;
																																}
																																break;
																																IL_05d2:;
																															}
																															break;
																															IL_05e5:;
																														}
																														break;
																													}
																													goto IL_06ec;
																													IL_08f7:
																													byte* num6 = ptr2;
																													num5 = 1;
																													ptr2 = num6 + -200;
																													num = 196;
																													goto end_IL_0655;
																													IL_06ec:
																													if (41 > b)
																													{
																														break;
																													}
																													goto IL_08f7;
																												}
																												break;
																											}
																											goto IL_07eb;
																											IL_0aa3:
																											array2[num7 - 1] = array2[num7 - 1];
																											num = 28;
																											goto IL_0aca;
																											IL_07eb:
																											if (40 <= b)
																											{
																												num = 204;
																												goto IL_0802;
																											}
																											goto IL_091c;
																											IL_0aca:
																											array[num7 - 1] = 15;
																											goto IL_0ade;
																											IL_0802:
																											ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0870;
																											IL_0870:
																											num7 -= 2;
																											goto end_IL_0655;
																											IL_091c:
																											if (38 < b)
																											{
																												goto IL_092a;
																											}
																											goto IL_0a26;
																											IL_092a:
																											if (39 < b)
																											{
																												break;
																											}
																											num = 155;
																											goto IL_0941;
																											IL_0ade:
																											array3[num7 - 1] = *(int*)(ptr2 + num3);
																											goto IL_0fbd;
																											IL_0941:
																											if (39 > b)
																											{
																												break;
																											}
																											num = 47;
																											goto IL_0958;
																											IL_0fbd:
																											ptr2 += 8;
																											goto end_IL_0655;
																											IL_0958:
																											((delegate*<object, IntPtr, object[], int[], ref Vector3>)IntegerEnumInstallerDeploymentMetadata[array3[num7 - 2]])(array2[num7 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2])), array6, array4).y = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]));
																											goto IL_09b8;
																											IL_09b8:
																											num7 -= 2;
																											num = 230;
																											goto end_IL_0655;
																											IL_0a26:
																											if (38 > b)
																											{
																												break;
																											}
																											goto IL_0aa3;
																										}
																										break;
																									}
																									goto IL_0680;
																									IL_0a44:
																									array2[num7 - 1] = ((delegate*<VRRig, VRMap>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])((VRRig)array2[num7 - 1]);
																									goto IL_0a7c;
																									IL_0680:
																									if (37 <= b)
																									{
																										goto IL_068b;
																									}
																									goto IL_06ff;
																									IL_068b:
																									array[num7 - 1] = 3;
																									num = 113;
																									goto IL_06a8;
																									IL_06a8:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]) = ((delegate*<double, double>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]));
																									goto IL_0faa;
																									IL_0faa:
																									ptr2 += 8;
																									goto end_IL_0655;
																									IL_06ff:
																									if (34 >= b)
																									{
																										goto IL_070a;
																									}
																									goto IL_0723;
																									IL_070a:
																									if (34 > b)
																									{
																										goto IL_075b;
																									}
																									num = 250;
																									goto IL_0883;
																									IL_0a7c:
																									array[num7 - 1] = 5;
																									goto IL_0a90;
																									IL_0883:
																									array[num7 - 1] = 3;
																									goto IL_09d4;
																									IL_09d4:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]) = ((delegate*<double, double>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]));
																									goto IL_0a13;
																									IL_0a13:
																									ptr2 += 8;
																									goto end_IL_0655;
																									IL_075b:
																									if (33 < b)
																									{
																										break;
																									}
																									goto IL_0769;
																									IL_0769:
																									if (33 > b)
																									{
																										break;
																									}
																									goto IL_0777;
																									IL_0777:
																									array[num7 - 2] = 0;
																									goto IL_078b;
																									IL_078b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])((VRRig)array2[num7 - 2], (UnityEngine.Object)array2[num7 - 1]) ? 1 : 0);
																									goto IL_07d8;
																									IL_07d8:
																									num7--;
																									goto IL_0f97;
																									IL_0f97:
																									ptr2 += 8;
																									goto end_IL_0655;
																									IL_0723:
																									if (35 < b)
																									{
																										goto IL_0731;
																									}
																									goto IL_0a36;
																									IL_0731:
																									if (36 < b)
																									{
																										break;
																									}
																									goto IL_073f;
																									IL_073f:
																									if (36 > b)
																									{
																										break;
																									}
																									num = 269;
																									goto IL_089c;
																									IL_0a90:
																									ptr2 += 8;
																									goto end_IL_0655;
																									IL_089c:
																									ptr2 = ((array2[num7 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_08e4;
																									IL_08e4:
																									num7--;
																									goto end_IL_0655;
																									IL_0a36:
																									if (35 > b)
																									{
																										break;
																									}
																									goto IL_0a44;
																								}
																								break;
																							}
																							goto IL_0afc;
																							IL_0f6c:
																							array2[num7] = null;
																							goto IL_0f76;
																							IL_0afc:
																							if (32 > b)
																							{
																								goto IL_0b0a;
																							}
																							num = 21;
																							goto IL_0f6c;
																							IL_0b0a:
																							if (26 >= b)
																							{
																								goto IL_0b18;
																							}
																							goto IL_0da4;
																							IL_0b18:
																							if (26 > b)
																							{
																								goto IL_0b26;
																							}
																							goto IL_0d34;
																							IL_0b26:
																							if (23 >= b)
																							{
																								goto IL_0b34;
																							}
																							goto IL_0c34;
																							IL_0b34:
																							if (23 > b)
																							{
																								goto IL_0b42;
																							}
																							goto IL_0bc4;
																							IL_0b42:
																							if (22 < b)
																							{
																								break;
																							}
																							goto IL_0b50;
																							IL_0b50:
																							if (22 > b)
																							{
																								break;
																							}
																							goto IL_0b5e;
																							IL_0b5e:
																							array[num7 - 1] = 3;
																							goto IL_0b72;
																							IL_0b72:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]) = ((delegate*<double, double>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]));
																							goto IL_0bb1;
																							IL_0bb1:
																							ptr2 += 8;
																							goto end_IL_0655;
																							IL_0bc4:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																							goto IL_0c04;
																							IL_0c04:
																							array[num7 - 2] = 3;
																							goto IL_0c18;
																							IL_0c18:
																							num7--;
																							num = 239;
																							goto end_IL_0655;
																							IL_0c34:
																							if (24 < b)
																							{
																								goto IL_0c3f;
																							}
																							goto IL_0cb7;
																							IL_0c3f:
																							if (25 < b)
																							{
																								break;
																							}
																							goto IL_0c4d;
																							IL_0c4d:
																							if (25 > b)
																							{
																								break;
																							}
																							num = 303;
																							goto IL_0c64;
																							IL_0f76:
																							array[num7] = 5;
																							goto IL_0f84;
																							IL_0c64:
																							array[num7] = 3;
																							goto IL_0c72;
																							IL_0c72:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = ((delegate*<float>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])();
																							goto IL_0c96;
																							IL_0c96:
																							num7++;
																							goto IL_0ca4;
																							IL_0ca4:
																							ptr2 += 8;
																							goto end_IL_0655;
																							IL_0cb7:
																							if (24 > b)
																							{
																								break;
																							}
																							goto IL_0cc5;
																							IL_0cc5:
																							array[num7 - 1] = 0;
																							num = 256;
																							goto IL_0ce2;
																							IL_0ce2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]) = ((delegate*<double, int>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]));
																							goto IL_0d21;
																							IL_0d21:
																							ptr2 += 8;
																							goto end_IL_0655;
																							IL_0d34:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																							goto IL_0d74;
																							IL_0d74:
																							array[num7 - 2] = 3;
																							goto IL_0d88;
																							IL_0d88:
																							num7--;
																							num = 152;
																							goto end_IL_0655;
																							IL_0da4:
																							if (29 >= b)
																							{
																								goto IL_0db2;
																							}
																							goto IL_0edc;
																							IL_0db2:
																							if (29 <= b)
																							{
																								goto IL_0dbd;
																							}
																							goto IL_0de9;
																							IL_0dbd:
																							global::_003CModule_003E.vrrig_56 = (VRRig)array2[num7 - 1];
																							goto IL_0dd6;
																							IL_0dd6:
																							num7--;
																							goto end_IL_0655;
																							IL_0de9:
																							if (27 >= b)
																							{
																								goto IL_0df4;
																							}
																							goto IL_0e4f;
																							IL_0df4:
																							if (27 > b)
																							{
																								break;
																							}
																							goto IL_0e02;
																							IL_0e02:
																							array[num7] = 5;
																							goto IL_0e10;
																							IL_0e10:
																							array2[num7] = ((delegate*<GorillaTagger>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])();
																							goto IL_0e2e;
																							IL_0e2e:
																							num7++;
																							goto IL_0e3c;
																							IL_0e3c:
																							ptr2 += 8;
																							goto end_IL_0655;
																							IL_0e4f:
																							if (28 < b)
																							{
																								break;
																							}
																							goto IL_0e5d;
																							IL_0e5d:
																							if (28 > b)
																							{
																								break;
																							}
																							num = 220;
																							goto IL_0e74;
																							IL_0f84:
																							num7++;
																							goto end_IL_0655;
																							IL_0e74:
																							array2[num7 - 1] = ((delegate*<GorillaTagger, VRRig>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num7 - 1]);
																							num = 197;
																							goto IL_0eb5;
																							IL_0eb5:
																							array[num7 - 1] = 5;
																							goto IL_0ec9;
																							IL_0ec9:
																							ptr2 += 8;
																							goto end_IL_0655;
																							IL_0edc:
																							if (30 >= b)
																							{
																								goto IL_0ee7;
																							}
																							goto IL_0efa;
																							IL_0ee7:
																							if (30 > b)
																							{
																								break;
																							}
																							goto IL_0fd0;
																							IL_0fd0:
																							array[num7 - 1] = 3;
																							goto IL_0fe4;
																							IL_0fe4:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]) = ((delegate*<double, double>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]));
																							goto IL_1023;
																							IL_1023:
																							ptr2 += 8;
																							goto end_IL_0655;
																							IL_0efa:
																							if (31 < b)
																							{
																								break;
																							}
																							goto IL_0f08;
																							IL_0f08:
																							if (31 > b)
																							{
																								break;
																							}
																							goto IL_0f16;
																							IL_0f16:
																							array2[num7] = ((delegate*<VRRig>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])();
																							goto IL_0f34;
																							IL_0f34:
																							array[num7] = 5;
																							goto IL_0f42;
																							IL_0f42:
																							num7++;
																							goto IL_0f50;
																							IL_0f50:
																							ptr2 += 8;
																							goto end_IL_0655;
																						}
																						break;
																					}
																					goto IL_1036;
																					IL_18d4:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(double*)(ptr2 + num4);
																					goto IL_18ed;
																					IL_1036:
																					if (21 > b)
																					{
																						goto IL_1044;
																					}
																					goto IL_18d4;
																					IL_1044:
																					if (10 >= b)
																					{
																						goto IL_1052;
																					}
																					goto IL_14e1;
																					IL_1052:
																					if (10 <= b)
																					{
																						goto IL_105d;
																					}
																					goto IL_10d2;
																					IL_105d:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_10bf;
																					IL_10bf:
																					num7 -= 2;
																					goto end_IL_0655;
																					IL_10d2:
																					if (5 >= b)
																					{
																						goto IL_10e0;
																					}
																					goto IL_131d;
																					IL_10e0:
																					if (5 > b)
																					{
																						goto IL_10ee;
																					}
																					goto IL_12b6;
																					IL_10ee:
																					if (2 >= b)
																					{
																						goto IL_10fc;
																					}
																					goto IL_11db;
																					IL_10fc:
																					if (2 <= b)
																					{
																						goto IL_1107;
																					}
																					goto IL_116e;
																					IL_1107:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					goto IL_1147;
																					IL_1147:
																					array[num7 - 2] = 0;
																					goto IL_115b;
																					IL_115b:
																					num7--;
																					goto end_IL_0655;
																					IL_116e:
																					if (1 < b)
																					{
																						break;
																					}
																					num = 214;
																					goto IL_1185;
																					IL_18ed:
																					array[num7] = 3;
																					goto IL_18fb;
																					IL_1185:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_1193;
																					IL_1193:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(int*)(ptr2 + num3);
																					goto IL_11ac;
																					IL_11ac:
																					array[num7] = 0;
																					goto IL_11ba;
																					IL_11ba:
																					num7++;
																					goto IL_11c8;
																					IL_11c8:
																					ptr2 += 8;
																					goto end_IL_0655;
																					IL_11db:
																					if (3 >= b)
																					{
																						goto IL_11e6;
																					}
																					goto IL_123e;
																					IL_11e6:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_11f4;
																					IL_11f4:
																					ref int reference = ref array4[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					goto IL_121d;
																					IL_121d:
																					ptr2 += 8;
																					goto IL_122b;
																					IL_122b:
																					num7--;
																					goto end_IL_0655;
																					IL_123e:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_124c;
																					IL_124c:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_125a;
																					IL_125a:
																					array[num7] = 0;
																					goto IL_1268;
																					IL_1268:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = array4[*(int*)(ptr2 + num3)];
																					goto IL_128b;
																					IL_128b:
																					array2[num7] = null;
																					goto IL_1295;
																					IL_1295:
																					num7++;
																					goto IL_12a3;
																					IL_12a3:
																					ptr2 += 8;
																					goto end_IL_0655;
																					IL_12b6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					goto IL_12f6;
																					IL_12f6:
																					array[num7 - 2] = 0;
																					goto IL_130a;
																					IL_130a:
																					num7--;
																					goto end_IL_0655;
																					IL_131d:
																					if (7 >= b)
																					{
																						goto IL_132b;
																					}
																					goto IL_1420;
																					IL_132b:
																					if (7 <= b)
																					{
																						goto IL_1336;
																					}
																					goto IL_139d;
																					IL_1336:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					goto IL_1376;
																					IL_1376:
																					array[num7 - 2] = 0;
																					goto IL_138a;
																					IL_138a:
																					num7--;
																					goto end_IL_0655;
																					IL_139d:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_13ab;
																					IL_13ab:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_13b9;
																					IL_13b9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					goto IL_13f9;
																					IL_13f9:
																					array[num7 - 2] = 0;
																					goto IL_140d;
																					IL_140d:
																					num7--;
																					goto end_IL_0655;
																					IL_1420:
																					if (8 >= b)
																					{
																						goto IL_142b;
																					}
																					goto IL_144c;
																					IL_142b:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_1439;
																					IL_1439:
																					num7--;
																					goto end_IL_0655;
																					IL_144c:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_145a;
																					IL_145a:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_1468;
																					IL_1468:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					num = 83;
																					goto IL_14b1;
																					IL_14b1:
																					array[num7 - 2] = 0;
																					num = 84;
																					goto IL_14ce;
																					IL_14ce:
																					num7--;
																					goto end_IL_0655;
																					IL_14e1:
																					if (15 < b)
																					{
																						goto IL_14ef;
																					}
																					num = 215;
																					goto IL_1721;
																					IL_14ef:
																					if (18 >= b)
																					{
																						goto IL_14fd;
																					}
																					goto IL_163b;
																					IL_14fd:
																					if (18 <= b)
																					{
																						goto IL_1508;
																					}
																					goto IL_1551;
																					IL_1508:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(float*)(ptr2 + num3);
																					goto IL_1522;
																					IL_1522:
																					array[num7] = 3;
																					goto IL_1530;
																					IL_1530:
																					num7++;
																					goto IL_153e;
																					IL_153e:
																					ptr2 += 8;
																					goto end_IL_0655;
																					IL_1551:
																					if (16 >= b)
																					{
																						goto IL_155c;
																					}
																					goto IL_15ba;
																					IL_155c:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_156a;
																					IL_156a:
																					array2[num7] = array6[*(int*)(ptr2 + num3)];
																					goto IL_1582;
																					IL_1582:
																					array[num7] = 5;
																					goto IL_1590;
																					IL_1590:
																					num7++;
																					num = 280;
																					goto IL_15a7;
																					IL_15a7:
																					ptr2 += 8;
																					goto end_IL_0655;
																					IL_15ba:
																					if (17 < b)
																					{
																						break;
																					}
																					goto IL_15c8;
																					IL_15c8:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_15d6;
																					IL_15d6:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]) = ((delegate*<Class182, float>)IntegerEnumInstallerDeploymentMetadata[*(int*)(ptr2 + num3)])((Class182)array2[num7 - 1]);
																					goto IL_1614;
																					IL_1614:
																					array[num7 - 1] = 3;
																					goto IL_1628;
																					IL_1628:
																					ptr2 += 8;
																					goto end_IL_0655;
																					IL_163b:
																					if (19 >= b)
																					{
																						goto IL_1646;
																					}
																					goto IL_16bb;
																					IL_1646:
																					if (19 > b)
																					{
																						break;
																					}
																					goto IL_1654;
																					IL_1654:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					goto IL_1694;
																					IL_1694:
																					array[num7 - 2] = 3;
																					goto IL_16a8;
																					IL_16a8:
																					num7--;
																					goto end_IL_0655;
																					IL_16bb:
																					if (20 < b)
																					{
																						break;
																					}
																					goto IL_16c9;
																					IL_16c9:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_16d7;
																					IL_16d7:
																					((Class182)array2[num7 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]));
																					goto IL_1705;
																					IL_1705:
																					num7 -= 2;
																					goto end_IL_0655;
																					IL_18fb:
																					num7++;
																					goto IL_1909;
																					IL_1721:
																					if (15 <= b)
																					{
																						goto IL_172c;
																					}
																					goto IL_1791;
																					IL_172c:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_177e;
																					IL_177e:
																					num7--;
																					goto end_IL_0655;
																					IL_1791:
																					if (12 >= b)
																					{
																						goto IL_179c;
																					}
																					goto IL_1810;
																					IL_179c:
																					if (12 > b)
																					{
																						goto IL_17a7;
																					}
																					goto IL_17c8;
																					IL_17a7:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_17b5;
																					IL_17b5:
																					if (11 > b)
																					{
																						break;
																					}
																					goto end_IL_0655;
																					IL_17c8:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(long*)(ptr2 + num4);
																					goto IL_17e1;
																					IL_17e1:
																					array[num7] = 1;
																					goto IL_17ef;
																					IL_17ef:
																					num7++;
																					goto IL_17fd;
																					IL_17fd:
																					ptr2 += 16;
																					goto end_IL_0655;
																					IL_1810:
																					if (13 >= b)
																					{
																						goto IL_181b;
																					}
																					goto IL_184a;
																					IL_181b:
																					if (13 > b)
																					{
																						break;
																					}
																					num = 234;
																					goto IL_1832;
																					IL_1909:
																					ptr2 += 16;
																					goto end_IL_0655;
																					IL_1832:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0655;
																					IL_184a:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_1858;
																					IL_1858:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_1866;
																					IL_1866:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1])) ? 1 : 0);
																					num = 264;
																					goto IL_18b0;
																					IL_18b0:
																					array[num7 - 2] = 0;
																					goto IL_18c4;
																					IL_18c4:
																					num7--;
																					goto end_IL_0655;
																				}
																				break;
																				IL_0645:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0655:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
															end_IL_192c:
															break;
														}
														continue;
														end_IL_193f:
														break;
													}
													continue;
													end_IL_1949:
													break;
												}
												continue;
												end_IL_195d:
												break;
											}
											continue;
											end_IL_196d:
											break;
										}
										continue;
										end_IL_197d:
										break;
									}
									continue;
									end_IL_198d:
									break;
								}
								continue;
								end_IL_19a6:
								break;
							}
							continue;
							end_IL_19b6:
							break;
						}
						continue;
						end_IL_19c6:
						break;
					}
					continue;
					end_IL_19d6:
					break;
				}
				continue;
				end_IL_19e6:
				break;
			}
		}
	}

	private void OnDisable()
	{
		getFullNameAppendData(this);
	}

	private unsafe void method_0()
	{
		int num = 172;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							num = 50;
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnumConnectionsgetSourceException.ITransportHeadersParallelOptions);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_0464:
															num = 164;
															while (true)
															{
																IL_0450:
																byte b = *ptr2;
																num = 13;
																while (true)
																{
																	IL_0437:
																	ptr2++;
																	num = 161;
																	while (true)
																	{
																		IL_0427:
																		if (b >= 1)
																		{
																			while (b <= 23)
																			{
																				while (true)
																				{
																					IL_0407:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_03f7:
																							if (18 < b)
																							{
																								while (true)
																								{
																									IL_03e4:
																									if (21 >= b)
																									{
																										num = 57;
																										while (true)
																										{
																											IL_03d4:
																											if (21 <= b)
																											{
																												while (true)
																												{
																													IL_03be:
																													array[num6 - 1] = 0;
																													while (true)
																													{
																														IL_037d:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)ActivatorLevelgetArray[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																														while (true)
																														{
																															IL_0364:
																															ptr2 += 8;
																															num = 205;
																															while (num != 205)
																															{
																																if (num != 1186)
																																{
																																	goto IL_07eb;
																																}
																																switch (num)
																																{
																																case 42:
																																	goto IL_0364;
																																case 70:
																																	goto IL_037d;
																																case 46:
																																case 77:
																																	goto IL_03be;
																																case 57:
																																	goto IL_03d4;
																																case 176:
																																	goto IL_03e4;
																																case 157:
																																	goto IL_03f7;
																																case 124:
																																	goto IL_0407;
																																case 165:
																																	goto IL_0417;
																																case 161:
																																	goto IL_0427;
																																case 13:
																																	goto IL_0437;
																																case 164:
																																	goto IL_0450;
																																case 129:
																																	goto IL_0464;
																																case 36:
																																	goto IL_046f;
																																case 47:
																																	goto IL_047a;
																																case 83:
																																	goto IL_048d;
																																case 86:
																																	goto IL_04a0;
																																case 98:
																																	goto IL_04b3;
																																case 32:
																																	goto IL_04be;
																																case 109:
																																	goto IL_04dc;
																																case 103:
																																	goto IL_04f3;
																																case 5:
																																case 31:
																																	goto IL_0501;
																																case 113:
																																	goto IL_0541;
																																case 60:
																																	goto IL_0555;
																																case 34:
																																case 114:
																																	goto IL_0568;
																																case 118:
																																	goto IL_0586;
																																case 35:
																																	goto IL_0591;
																																case 111:
																																	goto IL_05a4;
																																case 130:
																																	goto IL_05b7;
																																case 59:
																																	goto IL_05c2;
																																case 41:
																																	goto IL_05d0;
																																case 18:
																																case 51:
																																	goto IL_05de;
																																case 23:
																																	goto IL_05f5;
																																case 87:
																																	goto IL_061e;
																																case 16:
																																case 30:
																																	goto IL_062c;
																																case 101:
																																	goto IL_068e;
																																case 133:
																																	goto IL_06a1;
																																case 6:
																																case 137:
																																	goto IL_06af;
																																case 152:
																																	goto IL_06c2;
																																case 66:
																																	goto IL_06d9;
																																case 155:
																																	goto IL_06ec;
																																case 14:
																																case 148:
																																	goto IL_06fa;
																																case 185:
																																	goto IL_073f;
																																case 156:
																																	goto IL_074d;
																																case 143:
																																	goto IL_075b;
																																case 11:
																																	goto IL_0769;
																																case 25:
																																	goto IL_0774;
																																case 7:
																																case 81:
																																	goto IL_0782;
																																case 78:
																																	goto IL_079b;
																																case 37:
																																	goto IL_07a9;
																																case 72:
																																	goto IL_07b7;
																																case 183:
																																	goto IL_07ca;
																																case 54:
																																	goto IL_07d8;
																																case 110:
																																	goto IL_07eb;
																																case 106:
																																	goto IL_07f6;
																																case 44:
																																case 90:
																																	goto IL_0804;
																																case 68:
																																	goto IL_0812;
																																case 170:
																																	goto IL_0835;
																																case 82:
																																	goto IL_083f;
																																case 127:
																																	goto IL_0856;
																																case 119:
																																	goto IL_0869;
																																case 179:
																																	goto IL_0877;
																																case 55:
																																case 79:
																																	goto IL_0885;
																																case 159:
																																	goto IL_08c5;
																																case 73:
																																	goto IL_08d9;
																																case 9:
																																case 147:
																																	goto IL_08ec;
																																case 26:
																																	goto IL_092c;
																																case 2:
																																	goto IL_0949;
																																case 188:
																																	goto IL_095c;
																																case 12:
																																	goto IL_096a;
																																case 189:
																																	goto IL_097d;
																																case 145:
																																	goto IL_0991;
																																case 4:
																																case 190:
																																	goto IL_09ad;
																																case 134:
																																	goto IL_09d6;
																																case 69:
																																	goto IL_09e4;
																																case 191:
																																	goto IL_09f7;
																																case 21:
																																case 123:
																																	goto IL_0a05;
																																case 67:
																																case 194:
																																	goto IL_0a21;
																																case 187:
																																	goto IL_0a61;
																																case 126:
																																	goto IL_0a75;
																																case 195:
																																	goto IL_0a88;
																																case 192:
																																	goto IL_0a96;
																																case 22:
																																	goto IL_0aa4;
																																case 197:
																																	goto IL_0ab7;
																																case 40:
																																case 184:
																																	goto IL_0ac2;
																																case 19:
																																	goto IL_0aeb;
																																case 105:
																																	goto IL_0af9;
																																case 10:
																																	goto IL_0b0c;
																																case 58:
																																	goto IL_0b1a;
																																case 8:
																																case 193:
																																	goto IL_0b25;
																																case 62:
																																	goto IL_0b66;
																																case 150:
																																	goto IL_0b7a;
																																case 56:
																																	goto IL_0b8d;
																																case 65:
																																	goto IL_0b98;
																																case 144:
																																	goto IL_0ba6;
																																case 91:
																																case 115:
																																	goto IL_0bb4;
																																case 182:
																																	goto IL_0bd5;
																																case 33:
																																case 100:
																																	goto IL_0be3;
																																case 177:
																																	goto IL_0bfc;
																																case 141:
																																	goto IL_0c0a;
																																case 160:
																																	goto IL_0c18;
																																case 64:
																																	goto IL_0c2b;
																																case 95:
																																	goto IL_0c36;
																																case 80:
																																	goto IL_0c44;
																																case 3:
																																case 43:
																																	goto IL_0c52;
																																case 88:
																																	goto IL_0c6a;
																																case 167:
																																	goto IL_0c78;
																																case 97:
																																	goto IL_0c8f;
																																case 85:
																																	goto IL_0ca2;
																																case 175:
																																case 181:
																																	goto IL_0cb0;
																																case 63:
																																	goto IL_0d02;
																																case 117:
																																case 198:
																																	goto IL_0d12;
																																case 178:
																																	goto IL_0d52;
																																case 29:
																																	goto IL_0d66;
																																case 0:
																																case 1:
																																case 15:
																																case 20:
																																case 38:
																																case 45:
																																case 48:
																																case 49:
																																case 52:
																																case 71:
																																case 74:
																																case 92:
																																case 93:
																																case 94:
																																case 102:
																																case 108:
																																case 112:
																																case 121:
																																case 122:
																																case 136:
																																case 146:
																																case 153:
																																case 158:
																																case 166:
																																case 174:
																																case 196:
																																	goto end_IL_0417;
																																case 17:
																																case 24:
																																case 27:
																																case 28:
																																case 53:
																																case 61:
																																case 75:
																																case 84:
																																case 96:
																																case 99:
																																case 104:
																																case 125:
																																case 131:
																																case 132:
																																case 135:
																																case 138:
																																case 139:
																																case 140:
																																case 142:
																																case 149:
																																case 162:
																																case 163:
																																case 168:
																																case 169:
																																case 180:
																																	goto end_IL_0351;
																																case 39:
																																	goto end_IL_0d89;
																																case 120:
																																	goto end_IL_0d9c;
																																case 107:
																																	goto end_IL_0da6;
																																case 128:
																																	goto end_IL_0db1;
																																case 151:
																																	goto end_IL_0dc1;
																																case 50:
																																case 89:
																																	goto end_IL_0dd1;
																																case 76:
																																	goto end_IL_0de1;
																																case 186:
																																	goto end_IL_0df1;
																																case 116:
																																	goto end_IL_0e0a;
																																case 171:
																																	goto end_IL_0e1a;
																																case 172:
																																	goto end_IL_0e2a;
																																case 154:
																																case 173:
																																	return;
																																}
																																continue;
																																end_IL_0351:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_046f;
																											IL_0991:
																											num6--;
																											num = 53;
																											break;
																											IL_046f:
																											if (19 >= b)
																											{
																												goto IL_047a;
																											}
																											goto IL_048d;
																											IL_047a:
																											if (19 > b)
																											{
																												goto end_IL_0417;
																											}
																											goto IL_0568;
																											IL_0568:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																											goto IL_0a88;
																											IL_0a88:
																											array[num6] = 3;
																											goto IL_0a96;
																											IL_0a96:
																											num6++;
																											goto IL_0aa4;
																											IL_0aa4:
																											ptr2 += 16;
																											break;
																											IL_048d:
																											if (20 < b)
																											{
																												goto end_IL_0417;
																											}
																											goto IL_06ec;
																											IL_06ec:
																											if (20 > b)
																											{
																												goto end_IL_0417;
																											}
																											goto IL_06fa;
																											IL_06fa:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_097d;
																											IL_097d:
																											array[num6 - 2] = 3;
																											goto IL_0991;
																										}
																										break;
																									}
																									goto IL_04a0;
																									IL_095c:
																									if (23 < b)
																									{
																										goto end_IL_0417;
																									}
																									goto IL_096a;
																									IL_096a:
																									if (23 > b)
																									{
																									}
																									goto end_IL_0417;
																									IL_04a0:
																									if (22 < b)
																									{
																										goto IL_095c;
																									}
																									goto IL_09f7;
																									IL_09f7:
																									if (22 > b)
																									{
																										goto end_IL_0417;
																									}
																									goto IL_0a05;
																									IL_0a05:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									break;
																								}
																								break;
																							}
																							goto IL_0ab7;
																							IL_0cb0:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0d02;
																							IL_0ab7:
																							if (18 <= b)
																							{
																								goto IL_0ac2;
																							}
																							goto IL_0b0c;
																							IL_0ac2:
																							((delegate*<Class182, void>)ActivatorLevelgetArray[*(int*)(ptr2 + num3)])((Class182)array2[num6 - 1]);
																							goto IL_0aeb;
																							IL_0aeb:
																							num6--;
																							goto IL_0af9;
																							IL_0af9:
																							ptr2 += 8;
																							break;
																							IL_0b0c:
																							if (15 >= b)
																							{
																								goto IL_0b1a;
																							}
																							goto IL_0c2b;
																							IL_0b1a:
																							if (15 <= b)
																							{
																								goto IL_0b25;
																							}
																							goto IL_0b8d;
																							IL_0b25:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																							goto IL_0b66;
																							IL_0b66:
																							array[num6 - 2] = 0;
																							goto IL_0b7a;
																							IL_0b7a:
																							num6--;
																							break;
																							IL_0b8d:
																							if (13 < b)
																							{
																								goto IL_0b98;
																							}
																							num = 182;
																							goto IL_0bd5;
																							IL_0b98:
																							if (14 < b)
																							{
																								goto end_IL_0417;
																							}
																							goto IL_0ba6;
																							IL_0ba6:
																							if (14 > b)
																							{
																								goto end_IL_0417;
																							}
																							goto IL_0bb4;
																							IL_0bb4:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_0d02:
																							num6--;
																							break;
																							IL_0bd5:
																							if (13 > b)
																							{
																								goto end_IL_0417;
																							}
																							goto IL_0be3;
																							IL_0be3:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0bfc;
																							IL_0bfc:
																							array[num6] = 1;
																							goto IL_0c0a;
																							IL_0c0a:
																							num6++;
																							goto IL_0c18;
																							IL_0c18:
																							ptr2 += 16;
																							break;
																							IL_0c2b:
																							if (16 < b)
																							{
																								goto IL_0c36;
																							}
																							goto IL_0ca2;
																							IL_0c36:
																							if (17 < b)
																							{
																								goto end_IL_0417;
																							}
																							goto IL_0c44;
																							IL_0c44:
																							if (17 > b)
																							{
																								goto end_IL_0417;
																							}
																							goto IL_0c52;
																							IL_0c52:
																							array2[num6] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0c6a;
																							IL_0c6a:
																							array[num6] = 5;
																							goto IL_0c78;
																							IL_0c78:
																							num6++;
																							num = 97;
																							goto IL_0c8f;
																							IL_0c8f:
																							ptr2 += 8;
																							break;
																							IL_0ca2:
																							if (16 > b)
																							{
																								goto end_IL_0417;
																							}
																							goto IL_0cb0;
																						}
																						break;
																					}
																					goto IL_04b3;
																					IL_092c:
																					array[num6 - 2] = 0;
																					num = 2;
																					goto IL_0949;
																					IL_04b3:
																					if (12 <= b)
																					{
																						num = 162;
																						break;
																					}
																					goto IL_04be;
																					IL_04be:
																					if (6 < b)
																					{
																						goto IL_04dc;
																					}
																					goto IL_073f;
																					IL_04dc:
																					if (9 >= b)
																					{
																						num = 103;
																						goto IL_04f3;
																					}
																					goto IL_05b7;
																					IL_0949:
																					num6--;
																					break;
																					IL_04f3:
																					if (9 <= b)
																					{
																						goto IL_0501;
																					}
																					goto IL_0586;
																					IL_0501:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0541;
																					IL_0541:
																					array[num6 - 2] = 0;
																					goto IL_0555;
																					IL_0555:
																					num6--;
																					break;
																					IL_0586:
																					if (7 >= b)
																					{
																						goto IL_0591;
																					}
																					goto IL_05a4;
																					IL_0591:
																					if (7 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_0a21;
																					IL_0a21:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0a61;
																					IL_0a61:
																					array[num6 - 2] = 0;
																					goto IL_0a75;
																					IL_0a75:
																					num6--;
																					break;
																					IL_05a4:
																					if (8 < b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_06a1;
																					IL_06a1:
																					if (8 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_06af;
																					IL_06af:
																					num6--;
																					break;
																					IL_05b7:
																					if (10 < b)
																					{
																						goto IL_05c2;
																					}
																					goto IL_061e;
																					IL_05c2:
																					if (11 < b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_05d0;
																					IL_05d0:
																					if (11 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_05de;
																					IL_05de:
																					array[num6] = 0;
																					num = 23;
																					goto IL_05f5;
																					IL_05f5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)ActivatorLevelgetArray[*(int*)(ptr2 + num3)])();
																					goto IL_06c2;
																					IL_06c2:
																					num6++;
																					num = 66;
																					goto IL_06d9;
																					IL_06d9:
																					ptr2 += 8;
																					break;
																					IL_061e:
																					if (10 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_062c;
																					IL_062c:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_068e;
																					IL_068e:
																					num6 -= 2;
																					break;
																					IL_073f:
																					if (6 > b)
																					{
																						goto IL_074d;
																					}
																					goto IL_08ec;
																					IL_074d:
																					if (3 >= b)
																					{
																						goto IL_075b;
																					}
																					goto IL_07eb;
																					IL_075b:
																					if (3 > b)
																					{
																						goto IL_0769;
																					}
																					goto IL_09ad;
																					IL_0769:
																					if (1 >= b)
																					{
																						goto IL_0774;
																					}
																					goto IL_07ca;
																					IL_0774:
																					if (1 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_0782;
																					IL_0782:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																					goto IL_079b;
																					IL_079b:
																					array[num6] = 0;
																					goto IL_07a9;
																					IL_07a9:
																					num6++;
																					goto IL_07b7;
																					IL_07b7:
																					ptr2 += 8;
																					break;
																					IL_07ca:
																					if (2 < b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_07d8;
																					IL_07d8:
																					if (2 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_0d12;
																					IL_0d12:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0d52;
																					IL_0d52:
																					array[num6 - 2] = 0;
																					goto IL_0d66;
																					IL_0d66:
																					num6--;
																					break;
																					IL_09ad:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_09d6;
																					IL_09d6:
																					ptr2 += 8;
																					goto IL_09e4;
																					IL_09e4:
																					num6--;
																					break;
																					IL_07eb:
																					if (4 >= b)
																					{
																						goto IL_07f6;
																					}
																					goto IL_0869;
																					IL_07f6:
																					if (4 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_0804;
																					IL_0804:
																					array[num6] = 0;
																					goto IL_0812;
																					IL_0812:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0835;
																					IL_0835:
																					array2[num6] = null;
																					goto IL_083f;
																					IL_083f:
																					num6++;
																					num = 127;
																					goto IL_0856;
																					IL_0856:
																					ptr2 += 8;
																					break;
																					IL_0869:
																					if (5 < b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_0877;
																					IL_0877:
																					if (5 > b)
																					{
																						goto end_IL_0417;
																					}
																					goto IL_0885;
																					IL_0885:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_08c5;
																					IL_08c5:
																					array[num6 - 2] = 0;
																					goto IL_08d9;
																					IL_08d9:
																					num6--;
																					break;
																					IL_08ec:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_092c;
																				}
																				goto end_IL_0427;
																				continue;
																				end_IL_0417:
																				break;
																				IL_0417:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0427:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0d89:
														break;
													}
													continue;
													end_IL_0d9c:
													break;
												}
												continue;
												end_IL_0da6:
												break;
											}
											continue;
											end_IL_0db1:
											break;
										}
										continue;
										end_IL_0dc1:
										break;
									}
									continue;
									end_IL_0dd1:
									break;
								}
								continue;
								end_IL_0de1:
								break;
							}
							continue;
							end_IL_0df1:
							break;
						}
						continue;
						end_IL_0e0a:
						break;
					}
					continue;
					end_IL_0e1a:
					break;
				}
				continue;
				end_IL_0e2a:
				break;
			}
		}
	}

	private void method_1()
	{
		int num = 150;
		num = 50;
		num = 260;
		num = 20;
		num = 50;
		num = 38;
		num = 54;
		num = 54;
		num = 287;
		num = 41;
		num = 364;
		num = 28;
		num = 41;
		num = 69;
		num = 1081;
		num = 1081;
		num = 1135;
		num = 440;
		num = 110;
		num = 0;
		int num2 = 0;
		do
		{
			num = num2;
			object obj;
			object vrrig_;
			double num4;
			double num3;
			if (num == 3)
			{
				vrrig_ = global::_003CModule_003E.vrrig_57;
				obj = null;
				if (!((VRRig)vrrig_ != (UnityEngine.Object)obj))
				{
					break;
				}
				num3 = 2.0;
				num4 = 2.0;
				num3 = 4.0;
				int num5 = Convert.ToInt32(num3);
				num = num5;
				num2 = num;
			}
			num = num2;
			if (num != 2)
			{
				goto IL_0144;
			}
			vrrig_ = null;
			global::_003CModule_003E.vrrig_57 = (VRRig)vrrig_;
			num3 = 4.0;
			num4 = 1.5;
			double num6 = Math.Truncate(num4);
			num4 = num6;
			num3 -= num4;
			int num7 = Convert.ToInt32(num3);
			num = num7;
			num2 = num;
			num = num2;
			if (num == 1)
			{
				goto IL_00da;
			}
			goto IL_0191;
			IL_0144:
			num = num2;
			if (num == 1)
			{
				goto IL_00da;
			}
			goto IL_0191;
			IL_00da:
			GorillaTagger instance = GorillaTagger.Instance;
			vrrig_ = instance;
			obj = vrrig_;
			if (obj != null)
			{
				vrrig_ = ((GorillaTagger)vrrig_).offlineVRRig;
				global::_003CModule_003E.vrrig_57 = (VRRig)vrrig_;
				num3 = 4.0;
				num4 = 1.5;
				double num8 = Math.Truncate(num4);
				num4 = num8;
				num3 -= num4;
				int num9 = Convert.ToInt32(num3);
				num = num9;
				num2 = num;
				goto IL_0144;
			}
			num3 = 1.2384058440442351;
			num4 = 1.0;
			double num10 = Math.Tanh(num4);
			num4 = num10;
			num3 += num4;
			int num11 = Convert.ToInt32(num3);
			num = num11;
			num2 = num;
			goto IL_0191;
			IL_0191:
			num = num2;
			if (num == 5)
			{
				vrrig_ = global::_003CModule_003E.vrrig_57;
				vrrig_ = ((VRRig)vrrig_).head;
				num4 = 0.0;
				((VRMap)vrrig_).trackingRotationOffset.y = (float)num4;
				num3 = 6.989992496600445;
				num4 = 3.0;
				double num12 = Math.Cos(num4);
				num4 = num12;
				num3 += num4;
				int num13 = Convert.ToInt32(num3);
				num = num13;
				num2 = num;
			}
			num = num2;
			if (num == 4)
			{
				vrrig_ = global::_003CModule_003E.vrrig_57;
				vrrig_ = ((VRRig)vrrig_).head;
				if (vrrig_ == null)
				{
					break;
				}
				num3 = 7.0;
				num4 = 2.5;
				double num14 = Math.Floor(num4);
				num4 = num14;
				num3 -= num4;
				int num15 = Convert.ToInt32(num3);
				num = num15;
				num2 = num;
			}
			if (num2 == 0)
			{
				num = 1;
				num2 = 1;
			}
			num = num2;
		}
		while (num != 6);
	}

	public Class182()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 84;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 69;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MessageSmugglerLockAssemblyPath.SerializationFormatterMethodSpec);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 117;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0280:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_0263:
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_0253:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_0243:
																									if (9 > b)
																									{
																										while (true)
																										{
																											IL_0230:
																											if (7 >= b)
																											{
																												num = 128;
																												while (true)
																												{
																													if (num != 128)
																													{
																														if (num != 1109)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 22:
																														case 76:
																															goto IL_0230;
																														case 41:
																															goto IL_0243;
																														case 82:
																														case 91:
																															goto IL_0253;
																														case 20:
																															goto IL_0263;
																														case 71:
																															goto IL_0270;
																														case 44:
																															goto IL_0280;
																														case 67:
																															goto end_IL_0280;
																														case 16:
																														case 94:
																															goto end_IL_0290;
																														case 47:
																															goto IL_02ab;
																														case 5:
																															goto IL_02b9;
																														case 17:
																															goto IL_02c4;
																														case 2:
																															goto IL_02da;
																														case 58:
																															goto IL_02ed;
																														case 7:
																														case 66:
																															goto IL_02fd;
																														case 78:
																															goto IL_0310;
																														case 87:
																															goto IL_0323;
																														case 10:
																														case 21:
																															goto IL_0331;
																														case 62:
																															goto IL_035a;
																														case 96:
																															goto IL_0368;
																														case 55:
																														case 97:
																															goto IL_0384;
																														case 74:
																															goto IL_038f;
																														case 72:
																															goto IL_03a2;
																														case 8:
																															goto IL_03b0;
																														case 42:
																														case 79:
																															goto IL_03be;
																														case 29:
																															goto IL_042c;
																														case 99:
																															goto IL_043f;
																														case 38:
																														case 106:
																															goto IL_044f;
																														case 49:
																															goto IL_048f;
																														case 111:
																															goto IL_04a3;
																														case 112:
																														case 118:
																															goto IL_04b6;
																														case 113:
																														case 120:
																															goto IL_04ce;
																														case 35:
																															goto IL_04e7;
																														case 100:
																															goto IL_04f5;
																														case 80:
																															goto IL_0503;
																														case 14:
																														case 104:
																															goto IL_052d;
																														case 11:
																															goto IL_053b;
																														case 27:
																															goto IL_055e;
																														case 98:
																															goto IL_0568;
																														case 9:
																															goto IL_057f;
																														case 34:
																														case 56:
																															goto IL_0592;
																														case 18:
																															goto IL_05d2;
																														case 36:
																															goto IL_05e6;
																														case 92:
																															goto IL_05f9;
																														case 81:
																															goto IL_0604;
																														case 26:
																															goto IL_0612;
																														case 68:
																														case 73:
																															goto IL_0620;
																														case 3:
																															goto IL_0645;
																														case 63:
																															goto IL_0650;
																														case 64:
																															goto IL_065b;
																														case 15:
																														case 114:
																															goto IL_0666;
																														case 89:
																															goto IL_067a;
																														case 75:
																															goto IL_06b9;
																														case 43:
																														case 103:
																															goto IL_06c9;
																														case 1:
																														case 19:
																														case 23:
																														case 24:
																														case 25:
																														case 30:
																														case 31:
																														case 39:
																														case 46:
																														case 48:
																														case 51:
																														case 54:
																														case 57:
																														case 60:
																														case 61:
																														case 70:
																														case 77:
																														case 85:
																														case 95:
																														case 109:
																														case 116:
																														case 121:
																															goto end_IL_021d;
																														case 105:
																															goto IL_0705;
																														case 0:
																															goto IL_0713;
																														case 110:
																															goto IL_0721;
																														case 12:
																														case 13:
																														case 28:
																														case 32:
																														case 37:
																														case 40:
																														case 50:
																														case 52:
																														case 53:
																														case 59:
																														case 88:
																														case 93:
																														case 101:
																														case 102:
																														case 117:
																															goto end_IL_02a0;
																														case 6:
																															goto end_IL_0738;
																														case 45:
																															goto end_IL_074b;
																														case 4:
																															goto end_IL_075e;
																														case 115:
																															goto end_IL_0769;
																														case 107:
																															goto end_IL_077e;
																														case 33:
																														case 86:
																															goto end_IL_0793;
																														case 108:
																															goto end_IL_07a3;
																														case 69:
																															goto end_IL_07b3;
																														case 119:
																															goto end_IL_07c3;
																														case 83:
																															goto end_IL_07d3;
																														case 84:
																															goto end_IL_07de;
																														case 65:
																														case 90:
																															goto IL_07f9;
																														}
																														continue;
																													}
																													if (7 > b)
																													{
																														break;
																													}
																													num = 14;
																													goto IL_052d;
																													IL_053b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_055e;
																													IL_0568:
																													num5++;
																													num = 9;
																													goto IL_057f;
																													IL_055e:
																													array2[num5] = null;
																													goto IL_0568;
																													IL_057f:
																													ptr2 += 8;
																													goto end_IL_02a0;
																													IL_052d:
																													array[num5] = 0;
																													goto IL_053b;
																													continue;
																													end_IL_021d:
																													break;
																												}
																												break;
																											}
																											goto IL_02ed;
																											IL_04f5:
																											num5++;
																											goto IL_0503;
																											IL_0503:
																											ptr2 += 8;
																											goto end_IL_02a0;
																											IL_02ed:
																											if (8 < b)
																											{
																												break;
																											}
																											goto IL_0310;
																											IL_0310:
																											if (8 > b)
																											{
																												break;
																											}
																											goto IL_04ce;
																											IL_04ce:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_04e7;
																											IL_04e7:
																											array[num5] = 0;
																											goto IL_04f5;
																										}
																										break;
																									}
																									goto IL_0592;
																									IL_05e6:
																									num5--;
																									goto end_IL_02a0;
																									IL_0592:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05d2;
																									IL_05d2:
																									array[num5 - 2] = 0;
																									goto IL_05e6;
																								}
																								break;
																							}
																							goto IL_05f9;
																							IL_06b9:
																							ptr2 += 8;
																							goto end_IL_02a0;
																							IL_05f9:
																							if (11 < b)
																							{
																								goto IL_0604;
																							}
																							num = 3;
																							goto IL_0645;
																							IL_0604:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_0612;
																							IL_0612:
																							if (12 > b)
																							{
																								break;
																							}
																							goto IL_0620;
																							IL_0620:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_02a0;
																							IL_06c9:
																							num5--;
																							goto end_IL_02a0;
																							IL_0645:
																							if (11 > b)
																							{
																								goto IL_0650;
																							}
																							goto IL_06c9;
																							IL_0650:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_065b;
																							IL_065b:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0666;
																							IL_0666:
																							array[num5 - 1] = 0;
																							goto IL_067a;
																							IL_067a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ConvertTimeBySystemTimeZoneIdCreateServerChannelSinkChain[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_06b9;
																						}
																						break;
																					}
																					goto IL_02ab;
																					IL_048f:
																					array[num5 - 2] = 0;
																					goto IL_04a3;
																					IL_02ab:
																					if (6 <= b)
																					{
																						goto end_IL_02a0;
																					}
																					goto IL_02b9;
																					IL_02b9:
																					if (3 < b)
																					{
																						goto IL_02c4;
																					}
																					num = 2;
																					goto IL_02da;
																					IL_02c4:
																					if (4 < b)
																					{
																						goto IL_02fd;
																					}
																					goto IL_0323;
																					IL_02fd:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_043f;
																					IL_043f:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_04b6;
																					IL_04b6:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_02a0;
																					IL_0323:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0331;
																					IL_0331:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_035a;
																					IL_035a:
																					ptr2 += 8;
																					goto IL_0368;
																					IL_0368:
																					num5--;
																					num = 37;
																					goto end_IL_02a0;
																					IL_04a3:
																					num5--;
																					goto end_IL_02a0;
																					IL_02da:
																					if (3 > b)
																					{
																						goto IL_0384;
																					}
																					goto IL_044f;
																					IL_0384:
																					if (1 >= b)
																					{
																						goto IL_038f;
																					}
																					goto IL_03a2;
																					IL_038f:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_03a2:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_03b0;
																					IL_03b0:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_03be;
																					IL_03be:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_042c;
																					IL_042c:
																					num5 -= 2;
																					goto end_IL_02a0;
																					IL_044f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_048f;
																				}
																				break;
																				IL_0270:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 105;
																		goto IL_0705;
																		IL_0721:
																		ptr2 += 8;
																		num = 40;
																		goto end_IL_02a0;
																		IL_0713:
																		num5++;
																		goto IL_0721;
																		IL_0705:
																		array[num5] = 0;
																		goto IL_0713;
																		continue;
																		end_IL_0280:
																		break;
																	}
																	continue;
																	end_IL_0290:
																	break;
																}
																continue;
																end_IL_02a0:
																break;
															}
															continue;
														}
														goto IL_07f9;
														IL_07f9:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0738:
														break;
													}
													continue;
													end_IL_074b:
													break;
												}
												continue;
												end_IL_075e:
												break;
											}
											continue;
											end_IL_0769:
											break;
										}
										continue;
										end_IL_077e:
										break;
									}
									continue;
									end_IL_0793:
									break;
								}
								continue;
								end_IL_07a3:
								break;
							}
							continue;
							end_IL_07b3:
							break;
						}
						continue;
						end_IL_07c3:
						break;
					}
					continue;
					end_IL_07d3:
					break;
				}
				continue;
				end_IL_07de:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 111;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCultureInfoInstalledWinCultures.OnSerializedAttributeEventChannelType);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 75;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02d9:
															byte b = *ptr2;
															while (true)
															{
																IL_02c9:
																ptr2++;
																while (true)
																{
																	IL_02b9:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0299:
																				if (6 >= b)
																				{
																					num = 54;
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_0279:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_026c:
																									if (4 >= b)
																									{
																										while (4 <= b)
																										{
																											while (true)
																											{
																												IL_0231:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_0221:
																													ptr2 += 8;
																													while (true)
																													{
																														IL_0208:
																														num5--;
																														num = 118;
																														while (num != 118)
																														{
																															if (num != 1099)
																															{
																																goto IL_02a9;
																															}
																															switch (num)
																															{
																															case 26:
																																goto IL_0208;
																															case 44:
																																goto IL_0221;
																															case 19:
																															case 28:
																																goto IL_0231;
																															case 62:
																																goto IL_025c;
																															case 15:
																															case 63:
																																goto IL_026c;
																															case 34:
																																goto IL_0279;
																															case 54:
																																goto IL_0289;
																															case 65:
																																goto IL_0299;
																															case 98:
																																goto IL_02a9;
																															case 107:
																																goto IL_02b9;
																															case 67:
																																goto IL_02c9;
																															case 13:
																															case 23:
																																goto IL_02d9;
																															case 14:
																															case 78:
																																goto IL_02e4;
																															case 53:
																																goto IL_02fb;
																															case 84:
																																goto IL_030e;
																															case 59:
																																goto IL_0319;
																															case 73:
																																goto IL_0329;
																															case 3:
																																goto IL_0334;
																															case 60:
																															case 86:
																																goto IL_0347;
																															case 64:
																																goto IL_035b;
																															case 1:
																																goto IL_039a;
																															case 91:
																																goto IL_03ad;
																															case 6:
																															case 49:
																																goto IL_03bb;
																															case 104:
																																goto IL_03ce;
																															case 85:
																																goto IL_03d9;
																															case 35:
																															case 95:
																																goto IL_03e7;
																															case 70:
																																goto IL_03f5;
																															case 25:
																																goto IL_0418;
																															case 9:
																																goto IL_0422;
																															case 58:
																																goto IL_0430;
																															case 0:
																																goto IL_0443;
																															case 103:
																																goto IL_0451;
																															case 50:
																															case 105:
																																goto IL_045f;
																															case 97:
																																goto IL_0478;
																															case 92:
																																goto IL_0486;
																															case 93:
																																goto IL_0494;
																															case 106:
																																goto IL_04a7;
																															case 42:
																															case 88:
																																goto IL_04b5;
																															case 7:
																															case 109:
																																goto IL_04d1;
																															case 102:
																																goto IL_04e9;
																															case 37:
																															case 96:
																																goto IL_04f4;
																															case 2:
																																goto IL_0534;
																															case 10:
																																goto IL_0548;
																															case 101:
																																goto IL_055b;
																															case 61:
																																goto IL_0569;
																															case 81:
																																goto IL_0577;
																															case 68:
																															case 89:
																																goto IL_0585;
																															case 76:
																																goto IL_05f3;
																															case 43:
																																goto IL_0603;
																															case 4:
																															case 8:
																															case 11:
																															case 17:
																															case 18:
																															case 20:
																															case 21:
																															case 22:
																															case 24:
																															case 29:
																															case 32:
																															case 36:
																															case 39:
																															case 46:
																															case 47:
																															case 56:
																															case 72:
																															case 77:
																															case 87:
																															case 90:
																															case 100:
																																goto end_IL_025c;
																															case 45:
																																goto IL_0631;
																															case 38:
																																goto IL_0648;
																															case 41:
																																goto IL_0656;
																															case 5:
																															case 12:
																															case 30:
																															case 31:
																															case 33:
																															case 40:
																															case 52:
																															case 55:
																															case 69:
																															case 75:
																															case 80:
																															case 94:
																															case 108:
																																goto end_IL_01f5;
																															case 66:
																																goto end_IL_0664;
																															case 57:
																																goto end_IL_0677;
																															case 79:
																																goto end_IL_068a;
																															case 27:
																																goto end_IL_0695;
																															case 82:
																																goto end_IL_06aa;
																															case 48:
																															case 71:
																																goto end_IL_06bf;
																															case 99:
																																goto end_IL_06cf;
																															case 51:
																															case 74:
																																goto end_IL_06df;
																															case 110:
																																goto end_IL_06ef;
																															case 111:
																																goto end_IL_06ff;
																															case 16:
																															case 83:
																																goto IL_071a;
																															}
																															continue;
																															end_IL_01f5:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_0289;
																											continue;
																											end_IL_025c:
																											break;
																											IL_025c:;
																										}
																										break;
																									}
																									goto IL_02e4;
																									IL_02fb:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_04d1;
																									IL_02e4:
																									if (5 < b)
																									{
																										break;
																									}
																									num = 53;
																									goto IL_02fb;
																									IL_04d1:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0289;
																								}
																								break;
																							}
																							goto IL_04e9;
																							IL_0603:
																							if (1 > b)
																							{
																							}
																							break;
																							IL_04e9:
																							if (3 <= b)
																							{
																								goto IL_04f4;
																							}
																							goto IL_055b;
																							IL_04f4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0534;
																							IL_0534:
																							array[num5 - 2] = 0;
																							goto IL_0548;
																							IL_0548:
																							num5--;
																							goto end_IL_0289;
																							IL_055b:
																							if (1 < b)
																							{
																								goto IL_0569;
																							}
																							goto IL_0603;
																							IL_0569:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0577;
																							IL_0577:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0585;
																							IL_0585:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_05f3;
																							IL_05f3:
																							num5 -= 2;
																							goto end_IL_0289;
																						}
																						goto end_IL_02a9;
																						continue;
																						end_IL_0289:
																						break;
																						IL_0289:;
																					}
																					break;
																				}
																				goto IL_030e;
																				IL_03ad:
																				if (10 > b)
																				{
																					goto end_IL_02a9;
																				}
																				goto IL_03bb;
																				IL_03bb:
																				num5--;
																				break;
																				IL_030e:
																				if (9 >= b)
																				{
																					goto IL_0319;
																				}
																				goto IL_0329;
																				IL_0319:
																				if (9 <= b)
																				{
																					goto IL_0347;
																				}
																				goto IL_03ce;
																				IL_0347:
																				array[num5 - 1] = 0;
																				goto IL_035b;
																				IL_035b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ApplicationsgetIsGlobalTypeDefToken[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_039a;
																				IL_039a:
																				ptr2 += 8;
																				break;
																				IL_03ce:
																				if (7 >= b)
																				{
																					goto IL_03d9;
																				}
																				goto IL_0443;
																				IL_03d9:
																				if (7 > b)
																				{
																					goto end_IL_02a9;
																				}
																				goto IL_03e7;
																				IL_03e7:
																				array[num5] = 0;
																				goto IL_03f5;
																				IL_03f5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0418;
																				IL_0418:
																				array2[num5] = null;
																				goto IL_0422;
																				IL_0422:
																				num5++;
																				goto IL_0430;
																				IL_0430:
																				ptr2 += 8;
																				break;
																				IL_0443:
																				if (8 < b)
																				{
																					goto end_IL_02a9;
																				}
																				goto IL_0451;
																				IL_0451:
																				if (8 > b)
																				{
																					goto end_IL_02a9;
																				}
																				goto IL_045f;
																				IL_045f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0478;
																				IL_0478:
																				array[num5] = 0;
																				goto IL_0486;
																				IL_0486:
																				num5++;
																				goto IL_0494;
																				IL_0494:
																				ptr2 += 8;
																				break;
																				IL_0329:
																				if (10 < b)
																				{
																					goto IL_0334;
																				}
																				goto IL_03ad;
																				IL_0334:
																				if (11 < b)
																				{
																					goto end_IL_02a9;
																				}
																				goto IL_04a7;
																				IL_04a7:
																				if (11 > b)
																				{
																					goto end_IL_02a9;
																				}
																				goto IL_04b5;
																				IL_04b5:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																			}
																			goto end_IL_02b9;
																			continue;
																			end_IL_02a9:
																			break;
																			IL_02a9:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0631;
																	IL_0656:
																	ptr2 += 8;
																	break;
																	IL_0648:
																	num5++;
																	goto IL_0656;
																	IL_0631:
																	array[num5] = 0;
																	num = 38;
																	goto IL_0648;
																	continue;
																	end_IL_02b9:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_071a;
													IL_071a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0664:
													break;
												}
												continue;
												end_IL_0677:
												break;
											}
											continue;
											end_IL_068a:
											break;
										}
										continue;
										end_IL_0695:
										break;
									}
									continue;
									end_IL_06aa:
									break;
								}
								continue;
								end_IL_06bf:
								break;
							}
							continue;
							end_IL_06cf:
							break;
						}
						continue;
						end_IL_06df:
						break;
					}
					continue;
					end_IL_06ef:
					break;
				}
				continue;
				end_IL_06ff:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 107;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 115;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SystemThreadingSpinLockDebugViewgetDateEnd.systemThreadingSpinLockDebugViewgetDateEnd_0);
										while (true)
										{
											IL_08ca:
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0387:
														byte b = *ptr2;
														while (true)
														{
															IL_0377:
															ptr2++;
															while (true)
															{
																IL_0364:
																if (b >= 1)
																{
																	num = 88;
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0344:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0337:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0327:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_0317:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_030a:
																											if (2 < b)
																											{
																												while (3 >= b)
																												{
																													while (3 <= b)
																													{
																														while (true)
																														{
																															IL_02bf:
																															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																															while (true)
																															{
																																IL_02a0:
																																array[num5 - 1] = 5;
																																num = 156;
																																while (num != 156)
																																{
																																	if (num != 1137)
																																	{
																																		goto end_IL_08b7;
																																	}
																																	switch (num)
																																	{
																																	case 43:
																																		goto IL_02a0;
																																	case 9:
																																	case 49:
																																		goto IL_02bf;
																																	case 110:
																																		goto IL_02ea;
																																	case 51:
																																		goto IL_02fa;
																																	case 69:
																																		goto IL_030a;
																																	case 106:
																																		goto IL_0317;
																																	case 59:
																																		goto IL_0327;
																																	case 20:
																																		goto IL_0337;
																																	case 45:
																																		goto IL_0344;
																																	case 88:
																																		goto IL_0354;
																																	case 122:
																																		goto IL_0364;
																																	case 30:
																																		goto IL_0377;
																																	case 40:
																																	case 89:
																																		goto IL_0387;
																																	case 27:
																																		goto IL_0392;
																																	case 22:
																																	case 95:
																																		goto IL_03a5;
																																	case 18:
																																	case 114:
																																		goto IL_03bd;
																																	case 77:
																																		goto IL_03db;
																																	case 19:
																																		goto IL_03e9;
																																	case 23:
																																	case 118:
																																		goto IL_03fc;
																																	case 42:
																																	case 70:
																																		goto IL_0407;
																																	case 91:
																																		goto IL_0415;
																																	case 71:
																																	case 84:
																																		goto IL_0423;
																																	case 21:
																																		goto IL_0451;
																																	case 0:
																																	case 104:
																																		goto IL_045f;
																																	case 47:
																																		goto IL_049e;
																																	case 109:
																																	case 125:
																																		goto IL_04b1;
																																	case 44:
																																		goto IL_04f1;
																																	case 127:
																																		goto IL_0505;
																																	case 46:
																																	case 133:
																																		goto IL_0518;
																																	case 102:
																																		goto IL_0526;
																																	case 41:
																																	case 98:
																																		goto IL_0534;
																																	case 103:
																																		goto IL_0542;
																																	case 33:
																																		goto IL_055a;
																																	case 13:
																																		goto IL_0568;
																																	case 137:
																																		goto IL_057b;
																																	case 14:
																																		goto IL_0589;
																																	case 16:
																																	case 138:
																																		goto IL_059c;
																																	case 129:
																																		goto IL_05aa;
																																	case 50:
																																	case 144:
																																		goto IL_05b8;
																																	case 38:
																																		goto IL_05d1;
																																	case 5:
																																		goto IL_05df;
																																	case 60:
																																		goto IL_05ed;
																																	case 93:
																																	case 116:
																																		goto IL_0609;
																																	case 74:
																																		goto IL_0617;
																																	case 10:
																																	case 124:
																																		goto IL_062b;
																																	case 1:
																																		goto IL_066b;
																																	case 68:
																																		goto IL_067f;
																																	case 149:
																																		goto IL_0692;
																																	case 148:
																																		goto IL_06a0;
																																	case 82:
																																	case 139:
																																		goto IL_06ab;
																																	case 37:
																																		goto IL_06b9;
																																	case 28:
																																	case 35:
																																		goto IL_06cc;
																																	case 24:
																																		goto IL_06da;
																																	case 57:
																																		goto IL_06fd;
																																	case 117:
																																		goto IL_0707;
																																	case 142:
																																		goto IL_0715;
																																	case 128:
																																		goto IL_0728;
																																	case 15:
																																		goto IL_0736;
																																	case 6:
																																	case 90:
																																		goto IL_0744;
																																	case 26:
																																		goto IL_0788;
																																	case 108:
																																		goto IL_079c;
																																	case 3:
																																	case 4:
																																		goto IL_07b8;
																																	case 32:
																																	case 123:
																																		goto IL_07c3;
																																	case 100:
																																		goto IL_07d1;
																																	case 81:
																																		goto IL_07e4;
																																	case 36:
																																	case 86:
																																		goto IL_07f2;
																																	case 66:
																																		goto IL_0800;
																																	case 53:
																																	case 120:
																																		goto IL_080e;
																																	case 64:
																																		goto IL_0870;
																																	case 31:
																																	case 96:
																																		goto IL_088b;
																																	case 2:
																																	case 12:
																																	case 25:
																																	case 29:
																																	case 34:
																																	case 48:
																																	case 52:
																																	case 55:
																																	case 61:
																																	case 73:
																																	case 75:
																																	case 76:
																																	case 80:
																																	case 85:
																																	case 94:
																																	case 97:
																																	case 101:
																																	case 105:
																																	case 111:
																																	case 119:
																																	case 126:
																																	case 130:
																																	case 131:
																																	case 132:
																																	case 135:
																																	case 136:
																																	case 145:
																																		goto end_IL_02ea;
																																	case 17:
																																	case 54:
																																	case 56:
																																	case 62:
																																	case 63:
																																	case 72:
																																	case 78:
																																	case 79:
																																	case 92:
																																	case 99:
																																	case 112:
																																	case 113:
																																	case 121:
																																	case 134:
																																	case 140:
																																	case 141:
																																	case 143:
																																		goto end_IL_028d;
																																	case 147:
																																		goto IL_08ca;
																																	case 146:
																																		goto end_IL_08b7;
																																	case 115:
																																		goto end_IL_08d4;
																																	case 87:
																																		goto end_IL_08df;
																																	case 65:
																																	case 67:
																																		goto end_IL_08ef;
																																	case 58:
																																		goto end_IL_0908;
																																	case 83:
																																	case 107:
																																		goto end_IL_0918;
																																	case 7:
																																		goto end_IL_0928;
																																	case 8:
																																		goto end_IL_0938;
																																	case 11:
																																	case 39:
																																		goto IL_095c;
																																	}
																																	continue;
																																	end_IL_028d:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_0364;
																														continue;
																														end_IL_02ea:
																														break;
																														IL_02ea:;
																													}
																													break;
																													IL_02fa:;
																												}
																												break;
																											}
																											goto IL_0392;
																											IL_0505:
																											num5--;
																											goto end_IL_0364;
																											IL_0392:
																											if (2 <= b)
																											{
																												goto IL_04b1;
																											}
																											goto IL_059c;
																											IL_059c:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_05aa;
																											IL_05aa:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_05b8;
																											IL_05b8:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_05d1;
																											IL_05d1:
																											array[num5] = 0;
																											goto IL_05df;
																											IL_05df:
																											num5++;
																											goto IL_05ed;
																											IL_05ed:
																											ptr2 += 8;
																											num = 141;
																											goto end_IL_0364;
																											IL_04b1:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_04f1;
																											IL_04f1:
																											array[num5 - 2] = 0;
																											goto IL_0505;
																										}
																										break;
																									}
																									goto IL_03bd;
																									IL_03e9:
																									num5--;
																									goto end_IL_0364;
																									IL_03bd:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_03db;
																									IL_03db:
																									ptr2 += 8;
																									goto IL_03e9;
																								}
																								break;
																							}
																							goto IL_03fc;
																							IL_0568:
																							ptr2 += 8;
																							goto end_IL_0364;
																							IL_03fc:
																							if (6 < b)
																							{
																								goto IL_0407;
																							}
																							goto IL_0451;
																							IL_0407:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0415;
																							IL_0415:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0423;
																							IL_0423:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_057b;
																							IL_057b:
																							ptr2 += 8;
																							goto IL_0589;
																							IL_0589:
																							num5--;
																							goto end_IL_0364;
																							IL_0451:
																							if (6 <= b)
																							{
																								goto IL_045f;
																							}
																							goto IL_0518;
																							IL_045f:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_049e;
																							IL_049e:
																							num5 -= 3;
																							goto end_IL_0364;
																							IL_0518:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0526;
																							IL_0526:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0534;
																							IL_0534:
																							array[num5] = 5;
																							goto IL_0542;
																							IL_0542:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_055a;
																							IL_055a:
																							num5++;
																							goto IL_0568;
																						}
																						break;
																					}
																					goto IL_03a5;
																					IL_03a5:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0364;
																				}
																				break;
																			}
																			goto IL_0609;
																			IL_080e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0870;
																			IL_0609:
																			if (12 >= b)
																			{
																				goto IL_0617;
																			}
																			num = 4;
																			goto IL_07b8;
																			IL_0617:
																			if (12 <= b)
																			{
																				num = 10;
																				goto IL_062b;
																			}
																			goto IL_0692;
																			IL_088b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0364;
																			IL_062b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_066b;
																			IL_066b:
																			array[num5 - 2] = 0;
																			goto IL_067f;
																			IL_067f:
																			num5--;
																			goto end_IL_0364;
																			IL_0692:
																			if (10 >= b)
																			{
																				goto IL_06a0;
																			}
																			goto IL_0728;
																			IL_06a0:
																			if (10 > b)
																			{
																				goto IL_06ab;
																			}
																			goto IL_06cc;
																			IL_06ab:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06b9;
																			IL_06b9:
																			if (9 <= b)
																			{
																				goto end_IL_0364;
																			}
																			break;
																			IL_06cc:
																			array[num5] = 0;
																			goto IL_06da;
																			IL_06da:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_06fd;
																			IL_06fd:
																			array2[num5] = null;
																			goto IL_0707;
																			IL_0707:
																			num5++;
																			goto IL_0715;
																			IL_0715:
																			ptr2 += 8;
																			goto end_IL_0364;
																			IL_0728:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0736;
																			IL_0736:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0744;
																			IL_0744:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0788;
																			IL_0788:
																			array[num5 - 2] = 0;
																			goto IL_079c;
																			IL_079c:
																			num5--;
																			goto end_IL_0364;
																			IL_0870:
																			num5 -= 2;
																			goto end_IL_0364;
																			IL_07b8:
																			if (14 < b)
																			{
																				goto IL_07c3;
																			}
																			goto IL_07e4;
																			IL_07c3:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_07d1;
																			IL_07d1:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_07e4:
																			if (14 > b)
																			{
																				goto IL_07f2;
																			}
																			goto IL_088b;
																			IL_07f2:
																			if (13 < b)
																			{
																				num = 29;
																				break;
																			}
																			goto IL_0800;
																			IL_0800:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_080e;
																		}
																		break;
																		IL_0354:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0364:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_095c;
												IL_095c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b7:
												break;
											}
											break;
										}
										continue;
										end_IL_08d4:
										break;
									}
									continue;
									end_IL_08df:
									break;
								}
								continue;
								end_IL_08ef:
								break;
							}
							continue;
							end_IL_0908:
							break;
						}
						continue;
						end_IL_0918:
						break;
					}
					continue;
					end_IL_0928:
					break;
				}
				continue;
				end_IL_0938:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2, int int_3)
	{
		int num = 10;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 9;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 22;
								while (true)
								{
									array3[0] = int_2;
									num = 118;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddDeclarativeSecurityFormatDecimal.DynamicDaylightTimeDisabledSleep);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02af:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_028f:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_027f:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_026f:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0262:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_0237:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													while (true)
																													{
																														IL_021e:
																														array[num5] = 0;
																														num = 127;
																														while (true)
																														{
																															if (num != 127)
																															{
																																if (num != 1108)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 84:
																																	goto IL_021e;
																																case 85:
																																case 105:
																																	goto IL_0237;
																																case 103:
																																	goto IL_0252;
																																case 93:
																																	goto IL_0262;
																																case 108:
																																	goto IL_026f;
																																case 13:
																																case 48:
																																	goto IL_027f;
																																case 120:
																																	goto IL_028f;
																																case 46:
																																	goto IL_029f;
																																case 104:
																																	goto IL_02af;
																																case 7:
																																	goto end_IL_02af;
																																case 24:
																																case 36:
																																	goto end_IL_02bf;
																																case 4:
																																	goto IL_02da;
																																case 69:
																																	goto IL_02e8;
																																case 15:
																																case 74:
																																	goto IL_02f6;
																																case 107:
																																	goto IL_0336;
																																case 32:
																																	goto IL_034a;
																																case 64:
																																	goto IL_036b;
																																case 38:
																																case 111:
																																	goto IL_037e;
																																case 56:
																																	goto IL_0392;
																																case 6:
																																	goto IL_03d1;
																																case 115:
																																	goto IL_03e4;
																																case 72:
																																case 112:
																																	goto IL_03ef;
																																case 71:
																																	goto IL_03fd;
																																case 68:
																																case 98:
																																	goto IL_040b;
																																case 50:
																																	goto IL_0427;
																																case 16:
																																case 35:
																																	goto IL_0435;
																																case 33:
																																	goto IL_0448;
																																case 42:
																																case 65:
																																	goto IL_0453;
																																case 75:
																																	goto IL_0493;
																																case 52:
																																	goto IL_04a7;
																																case 31:
																																	goto end_IL_020b;
																																case 26:
																																case 41:
																																	goto IL_04c8;
																																case 11:
																																case 63:
																																	goto IL_04d6;
																																case 8:
																																	goto IL_04e4;
																																case 25:
																																case 59:
																																	goto IL_04f2;
																																case 94:
																																	goto IL_0500;
																																case 73:
																																	goto IL_0523;
																																case 45:
																																	goto IL_0536;
																																case 5:
																																	goto IL_0544;
																																case 23:
																																	goto IL_0557;
																																case 39:
																																case 91:
																																	goto IL_0565;
																																case 17:
																																	goto IL_05a5;
																																case 12:
																																	goto IL_05b9;
																																case 87:
																																	goto IL_05cc;
																																case 61:
																																case 113:
																																	goto IL_05d7;
																																case 54:
																																	goto IL_0600;
																																case 1:
																																	goto IL_060e;
																																case 28:
																																	goto IL_0621;
																																case 119:
																																	goto IL_062c;
																																case 81:
																																	goto IL_0637;
																																case 0:
																																case 21:
																																	goto IL_0642;
																																case 80:
																																	goto IL_0682;
																																case 19:
																																	goto IL_0696;
																																case 34:
																																	goto IL_06a6;
																																case 14:
																																case 20:
																																case 27:
																																case 30:
																																case 40:
																																case 43:
																																case 49:
																																case 53:
																																case 55:
																																case 58:
																																case 60:
																																case 62:
																																case 67:
																																case 78:
																																case 79:
																																case 82:
																																case 83:
																																case 88:
																																case 90:
																																case 92:
																																case 102:
																																case 109:
																																	goto end_IL_0252;
																																case 100:
																																	goto IL_06dd;
																																case 95:
																																	goto IL_06eb;
																																case 37:
																																	goto IL_06f9;
																																case 3:
																																case 18:
																																case 29:
																																case 44:
																																case 47:
																																case 51:
																																case 70:
																																case 77:
																																case 96:
																																case 97:
																																case 106:
																																case 110:
																																case 114:
																																	goto end_IL_02cf;
																																case 116:
																																	goto end_IL_0707;
																																case 101:
																																	goto end_IL_071a;
																																case 118:
																																	goto end_IL_0724;
																																case 22:
																																	goto end_IL_072f;
																																case 99:
																																	goto end_IL_0744;
																																case 66:
																																case 86:
																																	goto end_IL_0762;
																																case 117:
																																	goto end_IL_077b;
																																case 57:
																																case 76:
																																	goto end_IL_078b;
																																case 9:
																																	goto end_IL_079b;
																																case 10:
																																	goto end_IL_07ab;
																																case 2:
																																case 89:
																																	goto IL_07cf;
																																}
																																continue;
																															}
																															num5++;
																															goto IL_036b;
																															IL_036b:
																															ptr2 += 8;
																															goto end_IL_02cf;
																															continue;
																															end_IL_020b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_04ba;
																												continue;
																												end_IL_0252:
																												break;
																												IL_0252:;
																											}
																											break;
																										}
																										goto IL_02da;
																										IL_034a:
																										num5--;
																										goto end_IL_02cf;
																										IL_02da:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_02e8;
																										IL_02e8:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_02f6;
																										IL_02f6:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0336;
																										IL_0336:
																										array[num5 - 2] = 0;
																										goto IL_034a;
																									}
																									break;
																								}
																								goto IL_037e;
																								IL_03d1:
																								ptr2 += 8;
																								goto end_IL_02cf;
																								IL_037e:
																								array[num5 - 1] = 0;
																								goto IL_0392;
																								IL_0392:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ObjectAceTypeCurrentAssembly[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_03d1;
																							}
																							break;
																						}
																						goto IL_03e4;
																						IL_0435:
																						num5--;
																						goto end_IL_02cf;
																						IL_03e4:
																						if (10 < b)
																						{
																							goto IL_03ef;
																						}
																						goto IL_0427;
																						IL_03ef:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_03fd;
																						IL_03fd:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_040b;
																						IL_040b:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02cf;
																						IL_0427:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0435;
																					}
																					break;
																				}
																				goto IL_0448;
																				IL_06a6:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0448:
																				if (6 <= b)
																				{
																					goto IL_0453;
																				}
																				goto IL_04ba;
																				IL_0453:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0493;
																				IL_0493:
																				array[num5 - 2] = 0;
																				goto IL_04a7;
																				IL_04a7:
																				num5--;
																				goto end_IL_02cf;
																				IL_04ba:
																				if (3 < b)
																				{
																					goto IL_04c8;
																				}
																				goto IL_05cc;
																				IL_04c8:
																				if (4 < b)
																				{
																					goto IL_04d6;
																				}
																				goto IL_0557;
																				IL_04d6:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_04e4;
																				IL_04e4:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_04f2;
																				IL_04f2:
																				array[num5] = 0;
																				goto IL_0500;
																				IL_0500:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0523;
																				IL_0523:
																				array2[num5] = null;
																				num = 45;
																				goto IL_0536;
																				IL_0536:
																				num5++;
																				goto IL_0544;
																				IL_0544:
																				ptr2 += 8;
																				goto end_IL_02cf;
																				IL_0557:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0565;
																				IL_0565:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05a5;
																				IL_05a5:
																				array[num5 - 2] = 0;
																				goto IL_05b9;
																				IL_05b9:
																				num5--;
																				goto end_IL_02cf;
																				IL_05cc:
																				if (3 <= b)
																				{
																					goto IL_05d7;
																				}
																				goto IL_0621;
																				IL_05d7:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0600;
																				IL_0600:
																				ptr2 += 8;
																				goto IL_060e;
																				IL_060e:
																				num5--;
																				goto end_IL_02cf;
																				IL_0621:
																				if (1 < b)
																				{
																					goto IL_062c;
																				}
																				goto IL_06a6;
																				IL_062c:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0637;
																				IL_0637:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0642;
																				IL_0642:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0682;
																				IL_0682:
																				array[num5 - 2] = 0;
																				goto IL_0696;
																				IL_0696:
																				num5--;
																				goto end_IL_02cf;
																			}
																			break;
																			IL_029f:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 100;
																	goto IL_06dd;
																	IL_06f9:
																	ptr2 += 8;
																	goto end_IL_02cf;
																	IL_06eb:
																	num5++;
																	goto IL_06f9;
																	IL_06dd:
																	array[num5] = 0;
																	goto IL_06eb;
																	continue;
																	end_IL_02af:
																	break;
																}
																continue;
																end_IL_02bf:
																break;
															}
															continue;
															end_IL_02cf:
															break;
														}
														continue;
													}
													goto IL_07cf;
													IL_07cf:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0707:
													break;
												}
												continue;
												end_IL_071a:
												break;
											}
											continue;
											end_IL_0724:
											break;
										}
										continue;
										end_IL_072f:
										break;
									}
									continue;
									end_IL_0744:
									break;
								}
								continue;
								end_IL_0762:
								break;
							}
							continue;
							end_IL_077b:
							break;
						}
						continue;
						end_IL_078b:
						break;
					}
					continue;
					end_IL_079b:
					break;
				}
				continue;
				end_IL_07ab:
				break;
			}
		}
	}

	private static int smethod_4(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 88;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getAsyncDelegateInlineField.ReadChargetKeyInfoElement);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 63;
																while (true)
																{
																	IL_0222:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0205:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01f2:
																						if (4 > b)
																						{
																							num = 35;
																							while (true)
																							{
																								IL_01e5:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01d5:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												num = 97;
																												while (true)
																												{
																													if (num != 97)
																													{
																														if (num != 1078)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 19:
																															goto IL_01c2;
																														case 61:
																															goto IL_01d5;
																														case 35:
																														case 82:
																															goto IL_01e5;
																														case 7:
																															goto IL_01f2;
																														case 27:
																															goto IL_0205;
																														case 90:
																															goto IL_0212;
																														case 63:
																															goto IL_0222;
																														case 2:
																															goto end_IL_0222;
																														case 28:
																														case 62:
																															goto end_IL_0232;
																														case 32:
																														case 39:
																															goto IL_0256;
																														case 42:
																															goto IL_0266;
																														case 56:
																															goto IL_0274;
																														case 30:
																														case 64:
																															goto IL_0282;
																														case 47:
																															goto IL_02c2;
																														case 65:
																															goto IL_02db;
																														case 8:
																														case 53:
																															goto IL_02e9;
																														case 31:
																															goto IL_02f7;
																														case 66:
																															goto IL_030a;
																														case 52:
																														case 54:
																															goto IL_0315;
																														case 23:
																															goto IL_0323;
																														case 49:
																															goto IL_0336;
																														case 41:
																														case 43:
																															goto IL_0344;
																														case 34:
																															goto IL_0352;
																														case 45:
																															goto IL_0375;
																														case 68:
																															goto IL_0388;
																														case 10:
																															goto IL_0396;
																														case 22:
																														case 72:
																															goto IL_03a9;
																														case 50:
																															goto IL_03d2;
																														case 71:
																															goto end_IL_01af;
																														case 51:
																														case 80:
																															goto IL_03f3;
																														case 58:
																														case 81:
																															goto IL_040b;
																														case 69:
																															goto IL_0482;
																														case 60:
																														case 86:
																															goto IL_0495;
																														case 87:
																															goto IL_04ae;
																														case 0:
																														case 1:
																														case 4:
																														case 5:
																														case 9:
																														case 12:
																														case 17:
																														case 25:
																														case 29:
																														case 40:
																														case 46:
																														case 48:
																														case 59:
																														case 67:
																														case 73:
																														case 74:
																														case 76:
																														case 89:
																															goto end_IL_01c2;
																														case 26:
																															goto IL_04f5;
																														case 75:
																															goto IL_0503;
																														case 70:
																															goto IL_0511;
																														case 3:
																														case 6:
																														case 14:
																														case 16:
																														case 18:
																														case 20:
																														case 21:
																														case 33:
																														case 38:
																														case 44:
																														case 83:
																															goto end_IL_024b;
																														case 36:
																															goto end_IL_051f;
																														case 15:
																															goto end_IL_0532;
																														case 13:
																															goto end_IL_053c;
																														case 55:
																															goto end_IL_0547;
																														case 88:
																															goto end_IL_055c;
																														case 24:
																														case 78:
																															goto end_IL_0571;
																														case 77:
																															goto end_IL_0581;
																														case 37:
																														case 79:
																															goto end_IL_059a;
																														case 84:
																															goto end_IL_05aa;
																														case 85:
																															goto end_IL_05ba;
																														case 11:
																														case 57:
																															goto IL_05d5;
																														}
																														continue;
																													}
																													if (1 > b)
																													{
																													}
																													goto end_IL_01c2;
																													continue;
																													end_IL_01af:
																													break;
																												}
																												goto IL_03e0;
																												continue;
																												end_IL_01c2:
																												break;
																												IL_01c2:;
																											}
																											break;
																										}
																										goto IL_040b;
																										IL_0482:
																										num5 -= 2;
																										goto end_IL_024b;
																										IL_040b:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										num = 69;
																										goto IL_0482;
																									}
																									break;
																								}
																								goto IL_0266;
																								IL_04ae:
																								num5--;
																								goto end_IL_024b;
																								IL_0266:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0274;
																								IL_0274:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0282;
																								IL_0282:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02c2;
																								IL_02c2:
																								array[num5 - 2] = 0;
																								goto IL_04ae;
																							}
																							break;
																						}
																						goto IL_03a9;
																						IL_03d2:
																						ptr2 += 8;
																						goto IL_03e0;
																						IL_03e0:
																						num5--;
																						goto end_IL_024b;
																						IL_03a9:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03d2;
																					}
																					break;
																				}
																				goto IL_0256;
																				IL_0396:
																				ptr2 += 8;
																				goto end_IL_024b;
																				IL_0256:
																				if (6 >= b)
																				{
																					goto IL_02db;
																				}
																				goto IL_030a;
																				IL_02db:
																				if (6 <= b)
																				{
																					goto end_IL_024b;
																				}
																				goto IL_02e9;
																				IL_02e9:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_02f7;
																				IL_02f7:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_03f3;
																				IL_03f3:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_024b;
																				IL_030a:
																				if (7 < b)
																				{
																					goto IL_0315;
																				}
																				goto IL_0336;
																				IL_0315:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0323;
																				IL_0323:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0495;
																				IL_0495:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_024b;
																				IL_0336:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0344;
																				IL_0344:
																				array[num5] = 0;
																				goto IL_0352;
																				IL_0352:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0375;
																				IL_0375:
																				array2[num5] = null;
																				num = 68;
																				goto IL_0388;
																				IL_0388:
																				num5++;
																				goto IL_0396;
																			}
																			break;
																			IL_0212:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 26;
																	goto IL_04f5;
																	IL_0511:
																	ptr2 += 8;
																	goto end_IL_024b;
																	IL_0503:
																	num5++;
																	goto IL_0511;
																	IL_04f5:
																	array[num5] = 0;
																	goto IL_0503;
																	continue;
																	end_IL_0222:
																	break;
																}
																continue;
																end_IL_0232:
																break;
															}
															continue;
															end_IL_024b:
															break;
														}
														continue;
													}
													goto IL_05d5;
													IL_05d5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_051f:
													break;
												}
												continue;
												end_IL_0532:
												break;
											}
											continue;
											end_IL_053c:
											break;
										}
										continue;
										end_IL_0547:
										break;
									}
									continue;
									end_IL_055c:
									break;
								}
								continue;
								end_IL_0571:
								break;
							}
							continue;
							end_IL_0581:
							break;
						}
						continue;
						end_IL_059a:
						break;
					}
					continue;
					end_IL_05aa:
					break;
				}
				continue;
				end_IL_05ba:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetOffsetRegisteredChannel.getDeniedPermissionsViewAccessControl);
										while (true)
										{
											IL_0696:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0683:
												if (num4 != 1)
												{
													while (true)
													{
														IL_027f:
														byte b = *ptr2;
														while (true)
														{
															IL_026f:
															ptr2++;
															while (true)
															{
																IL_025f:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_023f:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_022f:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_021f:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_020c:
																									if (7 >= b)
																									{
																										num = 119;
																										while (true)
																										{
																											if (num != 119)
																											{
																												if (num != 1100)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 23:
																													goto IL_020c;
																												case 55:
																													goto IL_021f;
																												case 41:
																												case 90:
																													goto IL_022f;
																												case 58:
																													goto IL_023f;
																												case 37:
																													goto IL_024f;
																												case 38:
																													goto IL_025f;
																												case 30:
																													goto IL_026f;
																												case 85:
																												case 102:
																													goto IL_027f;
																												case 4:
																												case 25:
																													goto IL_02a3;
																												case 60:
																													goto IL_02e3;
																												case 61:
																													goto IL_02f7;
																												case 105:
																													goto IL_030a;
																												case 49:
																													goto IL_0318;
																												case 63:
																												case 101:
																													goto IL_0326;
																												case 31:
																													goto IL_0349;
																												case 46:
																													goto IL_0357;
																												case 51:
																													goto IL_0365;
																												case 67:
																												case 75:
																													goto IL_0378;
																												case 65:
																													goto IL_03da;
																												case 39:
																													goto IL_03ed;
																												case 2:
																													goto IL_03f8;
																												case 6:
																												case 108:
																													goto IL_0406;
																												case 13:
																													goto IL_0422;
																												case 95:
																													goto IL_0439;
																												case 42:
																													goto IL_044c;
																												case 8:
																												case 53:
																													goto IL_045a;
																												case 68:
																													goto IL_0468;
																												case 16:
																												case 24:
																													goto IL_0473;
																												case 27:
																												case 82:
																													goto IL_048b;
																												case 3:
																												case 18:
																													goto IL_0496;
																												case 22:
																													goto IL_04a4;
																												case 26:
																												case 72:
																													goto IL_04b2;
																												case 66:
																													goto IL_04db;
																												case 45:
																													goto IL_04e9;
																												case 103:
																													goto IL_04fc;
																												case 76:
																												case 92:
																													goto IL_050a;
																												case 98:
																													goto IL_052c;
																												case 50:
																													goto IL_053a;
																												case 93:
																													goto IL_0548;
																												case 64:
																													goto IL_055b;
																												case 28:
																													goto IL_0566;
																												case 87:
																													goto IL_0582;
																												case 17:
																													goto IL_0590;
																												case 5:
																												case 56:
																													goto IL_059e;
																												case 79:
																													goto IL_05b5;
																												case 94:
																													goto IL_05d8;
																												case 40:
																													goto IL_05e2;
																												case 62:
																													goto IL_05f0;
																												case 9:
																												case 111:
																													goto IL_0603;
																												case 36:
																													goto IL_0643;
																												case 81:
																													goto IL_0657;
																												case 0:
																												case 1:
																												case 7:
																												case 11:
																												case 14:
																												case 19:
																												case 32:
																												case 33:
																												case 35:
																												case 44:
																												case 70:
																												case 71:
																												case 73:
																												case 77:
																												case 80:
																												case 83:
																												case 88:
																												case 99:
																												case 100:
																												case 104:
																												case 106:
																													goto end_IL_024f;
																												case 10:
																												case 12:
																												case 15:
																												case 29:
																												case 34:
																												case 47:
																												case 48:
																												case 52:
																												case 59:
																												case 69:
																												case 86:
																												case 96:
																												case 97:
																												case 109:
																													goto IL_0683;
																												case 57:
																													goto IL_0696;
																												case 110:
																													goto end_IL_01f9;
																												case 89:
																													goto end_IL_06a0;
																												case 74:
																													goto end_IL_06ab;
																												case 43:
																												case 84:
																													goto end_IL_06c0;
																												case 91:
																													goto end_IL_06d0;
																												case 78:
																												case 107:
																													goto end_IL_06e0;
																												case 20:
																													goto end_IL_06f0;
																												case 21:
																													goto end_IL_0700;
																												case 54:
																												case 112:
																													goto IL_071b;
																												}
																												continue;
																											}
																											if (7 > b)
																											{
																												num = 100;
																												goto end_IL_024f;
																											}
																											goto IL_02a3;
																											IL_02f7:
																											num5--;
																											goto IL_0683;
																											IL_02e3:
																											array[num5 - 2] = 0;
																											goto IL_02f7;
																											IL_02a3:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_02e3;
																											continue;
																											end_IL_01f9:
																											break;
																										}
																										break;
																									}
																									goto IL_030a;
																									IL_0357:
																									num5++;
																									goto IL_0365;
																									IL_0365:
																									ptr2 += 8;
																									goto IL_0683;
																									IL_030a:
																									if (8 < b)
																									{
																										goto end_IL_024f;
																									}
																									goto IL_0318;
																									IL_0318:
																									if (8 > b)
																									{
																										goto end_IL_024f;
																									}
																									goto IL_0326;
																									IL_0326:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0349;
																									IL_0349:
																									array[num5] = 0;
																									goto IL_0357;
																								}
																								break;
																							}
																							goto IL_0378;
																							IL_03da:
																							num5 -= 2;
																							goto IL_0683;
																							IL_0378:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03da;
																						}
																						break;
																					}
																					goto IL_03ed;
																					IL_0439:
																					if (11 > b)
																					{
																					}
																					goto end_IL_024f;
																					IL_03ed:
																					if (10 >= b)
																					{
																						goto IL_03f8;
																					}
																					goto IL_0422;
																					IL_03f8:
																					if (10 > b)
																					{
																						goto end_IL_024f;
																					}
																					goto IL_0406;
																					IL_0406:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_0683;
																					IL_0422:
																					if (11 < b)
																					{
																						goto end_IL_024f;
																					}
																					num = 95;
																					goto IL_0439;
																				}
																				break;
																			}
																			goto IL_044c;
																			IL_0643:
																			array[num5 - 2] = 0;
																			goto IL_0657;
																			IL_044c:
																			if (6 > b)
																			{
																				goto IL_045a;
																			}
																			goto IL_0603;
																			IL_045a:
																			if (3 >= b)
																			{
																				goto IL_0468;
																			}
																			goto IL_055b;
																			IL_0468:
																			if (3 <= b)
																			{
																				goto IL_0473;
																			}
																			goto IL_048b;
																			IL_0473:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_0683;
																			IL_048b:
																			if (1 < b)
																			{
																				goto IL_0496;
																			}
																			goto IL_04fc;
																			IL_0496:
																			if (2 < b)
																			{
																				goto end_IL_024f;
																			}
																			goto IL_04a4;
																			IL_04a4:
																			if (2 > b)
																			{
																				goto end_IL_024f;
																			}
																			goto IL_04b2;
																			IL_04b2:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04db;
																			IL_04db:
																			ptr2 += 8;
																			goto IL_04e9;
																			IL_04e9:
																			num5--;
																			goto IL_0683;
																			IL_04fc:
																			if (1 > b)
																			{
																				goto end_IL_024f;
																			}
																			goto IL_050a;
																			IL_050a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 98;
																			goto IL_052c;
																			IL_052c:
																			array[num5] = 0;
																			goto IL_053a;
																			IL_053a:
																			num5++;
																			goto IL_0548;
																			IL_0548:
																			ptr2 += 8;
																			goto IL_0683;
																			IL_055b:
																			if (4 >= b)
																			{
																				goto IL_0566;
																			}
																			goto IL_0582;
																			IL_0566:
																			if (4 > b)
																			{
																				num = 71;
																				goto end_IL_024f;
																			}
																			goto IL_0683;
																			IL_0657:
																			num5--;
																			num = 15;
																			goto IL_0683;
																			IL_0582:
																			if (5 < b)
																			{
																				goto end_IL_024f;
																			}
																			goto IL_0590;
																			IL_0590:
																			if (5 > b)
																			{
																				goto end_IL_024f;
																			}
																			goto IL_059e;
																			IL_059e:
																			array[num5] = 0;
																			num = 79;
																			goto IL_05b5;
																			IL_05b5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05d8;
																			IL_05d8:
																			array2[num5] = null;
																			goto IL_05e2;
																			IL_05e2:
																			num5++;
																			goto IL_05f0;
																			IL_05f0:
																			ptr2 += 8;
																			goto IL_0683;
																			IL_0603:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0643;
																		}
																		goto end_IL_025f;
																		continue;
																		end_IL_024f:
																		break;
																		IL_024f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0683;
																continue;
																end_IL_025f:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_071b;
												IL_071b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										continue;
										end_IL_06a0:
										break;
									}
									continue;
									end_IL_06ab:
									break;
								}
								continue;
								end_IL_06c0:
								break;
							}
							continue;
							end_IL_06d0:
							break;
						}
						continue;
						end_IL_06e0:
						break;
					}
					continue;
					end_IL_06f0:
					break;
				}
				continue;
				end_IL_0700:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 109;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 7;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getFieldTypesUnicodeEncoded.ExceptionFromErrorCodeCryptoAPITransform);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0309:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02ec:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02dc:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_02cc:
																							if (14 >= b)
																							{
																								while (true)
																								{
																									IL_02bf:
																									if (14 > b)
																									{
																										while (13 >= b)
																										{
																											while (13 <= b)
																											{
																												num = 155;
																												while (true)
																												{
																													if (num != 155)
																													{
																														if (num != 1136)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 69:
																															goto IL_029c;
																														case 56:
																															goto IL_02af;
																														case 137:
																															goto IL_02bf;
																														case 61:
																														case 112:
																															goto IL_02cc;
																														case 15:
																														case 132:
																															goto IL_02dc;
																														case 13:
																															goto IL_02ec;
																														case 94:
																															goto IL_02f9;
																														case 130:
																															goto end_IL_0289;
																														case 74:
																															goto end_IL_0309;
																														case 70:
																														case 80:
																															goto end_IL_0319;
																														case 8:
																															goto IL_0334;
																														case 3:
																														case 26:
																															goto IL_0341;
																														case 12:
																														case 28:
																															goto IL_035d;
																														case 19:
																														case 98:
																															goto IL_0375;
																														case 59:
																														case 75:
																															goto IL_0380;
																														case 23:
																															goto IL_038b;
																														case 105:
																															goto IL_039b;
																														case 4:
																														case 107:
																															goto IL_03ae;
																														case 60:
																															goto IL_03bc;
																														case 37:
																														case 93:
																															goto IL_03c7;
																														case 114:
																															goto IL_03e8;
																														case 55:
																														case 68:
																															goto IL_03f6;
																														case 21:
																														case 51:
																															goto IL_0401;
																														case 6:
																															goto IL_0418;
																														case 40:
																														case 72:
																															goto IL_0426;
																														case 9:
																															goto IL_044f;
																														case 100:
																															goto IL_0468;
																														case 88:
																															goto IL_0473;
																														case 44:
																															goto IL_0481;
																														case 47:
																														case 52:
																															goto IL_048f;
																														case 17:
																														case 78:
																															goto IL_04ad;
																														case 32:
																															goto IL_04ed;
																														case 58:
																															goto IL_0501;
																														case 46:
																														case 103:
																															goto IL_0514;
																														case 25:
																															goto IL_0532;
																														case 31:
																															goto IL_0540;
																														case 129:
																															goto IL_0553;
																														case 133:
																															goto IL_0561;
																														case 106:
																															goto IL_056f;
																														case 138:
																															goto IL_0582;
																														case 125:
																															goto IL_059a;
																														case 36:
																															goto IL_05a8;
																														case 143:
																															goto IL_05bb;
																														case 11:
																														case 123:
																															goto IL_05c9;
																														case 27:
																															goto IL_05f2;
																														case 84:
																															goto IL_0600;
																														case 35:
																														case 148:
																															goto IL_0613;
																														case 45:
																															goto IL_0652;
																														case 81:
																															goto IL_0665;
																														case 141:
																															goto IL_06c7;
																														case 76:
																															goto IL_06da;
																														case 20:
																															goto IL_06e8;
																														case 73:
																															goto IL_06fb;
																														case 57:
																														case 145:
																															goto IL_0706;
																														case 140:
																															goto IL_0746;
																														case 113:
																															goto IL_075a;
																														case 86:
																														case 128:
																															goto IL_0776;
																														case 49:
																														case 83:
																															goto IL_0784;
																														case 5:
																															goto IL_0792;
																														case 48:
																														case 67:
																															goto IL_07a0;
																														case 65:
																															goto IL_07e4;
																														case 10:
																															goto IL_07f8;
																														case 102:
																															goto IL_080b;
																														case 91:
																														case 96:
																															goto IL_0816;
																														case 66:
																															goto IL_0821;
																														case 0:
																														case 87:
																															goto IL_082e;
																														case 41:
																															goto IL_083c;
																														case 16:
																															goto IL_085f;
																														case 38:
																															goto IL_0872;
																														case 110:
																															goto IL_0880;
																														case 1:
																														case 2:
																														case 14:
																														case 18:
																														case 24:
																														case 33:
																														case 34:
																														case 43:
																														case 54:
																														case 63:
																														case 90:
																														case 95:
																														case 97:
																														case 111:
																														case 115:
																														case 116:
																														case 117:
																														case 119:
																														case 120:
																														case 122:
																														case 131:
																														case 134:
																														case 135:
																														case 136:
																														case 146:
																															goto end_IL_029c;
																														case 29:
																														case 30:
																														case 39:
																														case 50:
																														case 53:
																														case 71:
																														case 77:
																														case 79:
																														case 85:
																														case 89:
																														case 99:
																														case 121:
																														case 124:
																														case 126:
																														case 139:
																														case 142:
																														case 144:
																														case 147:
																															goto end_IL_0329;
																														case 82:
																															goto end_IL_08a3;
																														case 92:
																															goto end_IL_08b6;
																														case 64:
																															goto end_IL_08c0;
																														case 42:
																															goto end_IL_08cb;
																														case 22:
																														case 62:
																															goto end_IL_08db;
																														case 104:
																															goto end_IL_08eb;
																														case 7:
																														case 127:
																															goto end_IL_08fb;
																														case 108:
																															goto end_IL_090b;
																														case 109:
																															goto end_IL_091b;
																														case 101:
																														case 118:
																															goto IL_093f;
																														}
																														continue;
																													}
																													goto IL_0665;
																													IL_0665:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_06c7;
																													IL_06c7:
																													num5 -= 2;
																													goto end_IL_0329;
																													continue;
																													end_IL_0289:
																													break;
																												}
																												goto IL_0309;
																												continue;
																												end_IL_029c:
																												break;
																												IL_029c:;
																											}
																											break;
																											IL_02af:;
																										}
																										break;
																									}
																									goto IL_0341;
																									IL_0341:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0329;
																								}
																								break;
																							}
																							goto IL_06da;
																							IL_06e8:
																							if (15 <= b)
																							{
																							}
																							break;
																							IL_06da:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_06e8;
																						}
																						break;
																					}
																					goto IL_06fb;
																					IL_0872:
																					num5++;
																					goto IL_0880;
																					IL_06fb:
																					if (12 <= b)
																					{
																						goto IL_0706;
																					}
																					num = 128;
																					goto IL_0776;
																					IL_0706:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0746;
																					IL_0746:
																					array[num5 - 2] = 0;
																					goto IL_075a;
																					IL_075a:
																					num5--;
																					goto end_IL_0329;
																					IL_0880:
																					ptr2 += 8;
																					goto end_IL_0329;
																					IL_0776:
																					if (10 < b)
																					{
																						goto IL_0784;
																					}
																					goto IL_080b;
																					IL_0784:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0792;
																					IL_0792:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_07a0;
																					IL_07a0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_07e4;
																					IL_07e4:
																					array[num5 - 2] = 0;
																					goto IL_07f8;
																					IL_07f8:
																					num5--;
																					goto end_IL_0329;
																					IL_080b:
																					if (10 > b)
																					{
																						goto IL_0816;
																					}
																					goto IL_082e;
																					IL_0816:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0821;
																					IL_0821:
																					if (9 <= b)
																					{
																						goto end_IL_0329;
																					}
																					break;
																					IL_082e:
																					array[num5] = 0;
																					goto IL_083c;
																					IL_083c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_085f;
																					IL_085f:
																					array2[num5] = null;
																					num = 38;
																					goto IL_0872;
																				}
																				break;
																			}
																			goto IL_0334;
																			IL_0532:
																			ptr2 += 8;
																			goto IL_0540;
																			IL_0334:
																			if (8 <= b)
																			{
																				goto IL_035d;
																			}
																			goto IL_0375;
																			IL_0375:
																			if (4 < b)
																			{
																				goto IL_0380;
																			}
																			goto IL_03e8;
																			IL_0380:
																			if (6 >= b)
																			{
																				goto IL_038b;
																			}
																			goto IL_039b;
																			IL_038b:
																			if (6 > b)
																			{
																				goto IL_03ae;
																			}
																			goto IL_0613;
																			IL_03ae:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_03bc;
																			IL_03bc:
																			if (5 > b)
																			{
																				num = 18;
																				break;
																			}
																			goto IL_03c7;
																			IL_03c7:
																			array[num5] = 5;
																			goto IL_0582;
																			IL_0582:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_059a;
																			IL_059a:
																			num5++;
																			goto IL_05a8;
																			IL_05a8:
																			ptr2 += 8;
																			goto end_IL_0329;
																			IL_0540:
																			num5--;
																			goto end_IL_0329;
																			IL_0613:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0652;
																			IL_0652:
																			num5 -= 3;
																			goto end_IL_0329;
																			IL_039b:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_05bb;
																			IL_05bb:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_05c9;
																			IL_05c9:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05f2;
																			IL_05f2:
																			ptr2 += 8;
																			goto IL_0600;
																			IL_0600:
																			num5--;
																			goto end_IL_0329;
																			IL_03e8:
																			if (4 > b)
																			{
																				goto IL_03f6;
																			}
																			goto IL_0514;
																			IL_03f6:
																			if (2 < b)
																			{
																				goto IL_0401;
																			}
																			goto IL_0468;
																			IL_0401:
																			if (3 < b)
																			{
																				break;
																			}
																			num = 6;
																			goto IL_0418;
																			IL_035d:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0329;
																			IL_0418:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0426;
																			IL_0426:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_044f;
																			IL_044f:
																			array[num5 - 1] = 5;
																			goto end_IL_0329;
																			IL_0468:
																			if (2 > b)
																			{
																				goto IL_0473;
																			}
																			goto IL_04ad;
																			IL_0473:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0481;
																			IL_0481:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_048f;
																			IL_048f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0553;
																			IL_0553:
																			array[num5] = 0;
																			goto IL_0561;
																			IL_0561:
																			num5++;
																			goto IL_056f;
																			IL_056f:
																			ptr2 += 8;
																			goto end_IL_0329;
																			IL_04ad:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04ed;
																			IL_04ed:
																			array[num5 - 2] = 0;
																			goto IL_0501;
																			IL_0501:
																			num5--;
																			goto end_IL_0329;
																			IL_0514:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0532;
																		}
																		break;
																		IL_02f9:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0329;
																continue;
																end_IL_0309:
																break;
															}
															continue;
															end_IL_0319:
															break;
														}
														continue;
														end_IL_0329:
														break;
													}
													continue;
												}
												goto IL_093f;
												IL_093f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a3:
												break;
											}
											continue;
											end_IL_08b6:
											break;
										}
										continue;
										end_IL_08c0:
										break;
									}
									continue;
									end_IL_08cb:
									break;
								}
								continue;
								end_IL_08db:
								break;
							}
							continue;
							end_IL_08eb:
							break;
						}
						continue;
						end_IL_08fb:
						break;
					}
					continue;
					end_IL_090b:
					break;
				}
				continue;
				end_IL_091b:
				break;
			}
		}
	}

	static Class182()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 16;
				while (true)
				{
					if (num != 16)
					{
						if (num != 997)
						{
							return;
						}
						switch (num)
						{
						case 5:
							goto end_IL_004c;
						case 6:
							goto end_IL_0059;
						case 3:
						case 8:
							goto IL_0072;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 4:
							return;
						case 7:
							return;
						case 9:
							return;
						}
						continue;
					}
					goto IL_0072;
					IL_0072:
					num = 9;
					return;
					continue;
					end_IL_004c:
					break;
				}
				continue;
				end_IL_0059:
				break;
			}
		}
	}

	private static void getFullNameAppendData(Class182 class182_1)
	{
		class182_1.method_1();
	}
}
