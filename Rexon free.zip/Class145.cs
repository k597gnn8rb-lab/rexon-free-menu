using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

[HarmonyPatch(typeof(VRRig), "DroppedByPlayer")]
internal class Class145
{
	private static double double_0;

	private static bool bool_0;

	private static bool bool_1;

	private static int int_0;

	private static bool bool_2;

	private static IntPtr[] IsSingleByteQueueUserWorkItemCallback;

	private static IntPtr[] NativeOffsetAggregateDictionary;

	private static IntPtr[] FoundEndOfHebrewNumberA;

	private unsafe static bool Prefix(VRRig grabbedByRig, Vector3 throwVelocity)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 95;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 56;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 249;
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											object[] array5 = new object[2];
											while (true)
											{
												array5[0] = grabbedByRig;
												while (true)
												{
													array5[1] = throwVelocity;
													while (true)
													{
														byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetFilegetDefault.TwoLetterISOLanguageNameAddOID);
														while (true)
														{
															byte* ptr2 = ptr;
															while (true)
															{
																if (num4 != 1)
																{
																	while (true)
																	{
																		byte b = *ptr2;
																		while (true)
																		{
																			ptr2++;
																			while (true)
																			{
																				IL_05ec:
																				if (b >= 1)
																				{
																					while (b <= 35)
																					{
																						while (true)
																						{
																							IL_05cc:
																							if (18 >= b)
																							{
																								while (true)
																								{
																									IL_05bc:
																									if (18 > b)
																									{
																										while (true)
																										{
																											IL_05ac:
																											if (9 >= b)
																											{
																												while (true)
																												{
																													IL_059c:
																													if (9 > b)
																													{
																														while (true)
																														{
																															IL_058c:
																															if (4 >= b)
																															{
																																while (true)
																																{
																																	IL_057c:
																																	if (4 > b)
																																	{
																																		while (true)
																																		{
																																			IL_056c:
																																			if (2 < b)
																																			{
																																				while (3 >= b)
																																				{
																																					while (3 <= b)
																																					{
																																						num = 128;
																																						while (true)
																																						{
																																							IL_0515:
																																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																							num = 34;
																																							while (true)
																																							{
																																								IL_04fc:
																																								ptr2 += 8;
																																								num = 307;
																																								while (true)
																																								{
																																									if (num != 307)
																																									{
																																										if (num != 1288)
																																										{
																																											break;
																																										}
																																										switch (num)
																																										{
																																										case 34:
																																											goto IL_04fc;
																																										case 128:
																																										case 289:
																																											goto IL_0515;
																																										case 24:
																																											goto IL_0549;
																																										case 109:
																																											goto IL_055c;
																																										case 292:
																																											goto IL_056c;
																																										case 170:
																																											goto IL_057c;
																																										case 77:
																																											goto IL_058c;
																																										case 111:
																																											goto IL_059c;
																																										case 241:
																																											goto IL_05ac;
																																										case 200:
																																											goto IL_05bc;
																																										case 295:
																																											goto IL_05cc;
																																										case 9:
																																											goto IL_05dc;
																																										case 3:
																																											goto IL_05ec;
																																										case 234:
																																											goto end_IL_05ec;
																																										case 51:
																																										case 150:
																																											goto end_IL_05fc;
																																										case 119:
																																											goto IL_0617;
																																										case 218:
																																											goto IL_0622;
																																										case 78:
																																										case 226:
																																											goto end_IL_04e9;
																																										case 231:
																																											goto IL_0640;
																																										case 199:
																																											goto IL_0663;
																																										case 120:
																																											goto IL_066d;
																																										case 26:
																																											goto IL_067b;
																																										case 242:
																																											goto IL_068e;
																																										case 145:
																																										case 257:
																																											goto IL_069e;
																																										case 134:
																																											goto IL_06de;
																																										case 247:
																																											goto IL_06f2;
																																										case 194:
																																										case 260:
																																											goto IL_0705;
																																										case 15:
																																										case 268:
																																											goto IL_0720;
																																										case 166:
																																											goto IL_0758;
																																										case 156:
																																											goto IL_0775;
																																										case 270:
																																											goto IL_0791;
																																										case 180:
																																											goto IL_079f;
																																										case 21:
																																											goto IL_07ad;
																																										case 164:
																																										case 288:
																																											goto IL_07c9;
																																										case 233:
																																											goto IL_0812;
																																										case 88:
																																											goto IL_0826;
																																										case 4:
																																											goto IL_084c;
																																										case 187:
																																											goto IL_085a;
																																										case 297:
																																											goto IL_0868;
																																										case 25:
																																											goto IL_0876;
																																										case 11:
																																										case 152:
																																											goto IL_0884;
																																										case 272:
																																											goto IL_08c4;
																																										case 5:
																																											goto IL_08e1;
																																										case 131:
																																										case 264:
																																											goto IL_08f4;
																																										case 179:
																																											goto IL_0934;
																																										case 113:
																																											goto IL_0948;
																																										case 165:
																																											goto IL_095b;
																																										case 18:
																																											goto IL_0966;
																																										case 72:
																																											goto IL_0974;
																																										case 101:
																																										case 216:
																																											goto IL_0982;
																																										case 154:
																																											goto IL_099e;
																																										case 67:
																																										case 138:
																																											goto IL_09ac;
																																										case 124:
																																											goto IL_09ec;
																																										case 38:
																																											goto IL_0a00;
																																										case 30:
																																											goto IL_0a13;
																																										case 121:
																																											goto IL_0a21;
																																										case 189:
																																											goto IL_0a2f;
																																										case 107:
																																											goto IL_0a3d;
																																										case 105:
																																											goto IL_0a4b;
																																										case 126:
																																										case 209:
																																											goto IL_0a59;
																																										case 62:
																																											goto IL_0ab7;
																																										case 98:
																																										case 116:
																																											goto IL_0aca;
																																										case 220:
																																											goto IL_0ae6;
																																										case 210:
																																											goto IL_0af1;
																																										case 66:
																																										case 97:
																																											goto IL_0aff;
																																										case 283:
																																											goto IL_0b20;
																																										case 87:
																																											goto IL_0b2e;
																																										case 69:
																																											goto IL_0b3c;
																																										case 240:
																																											goto IL_0b4f;
																																										case 80:
																																											goto IL_0b5d;
																																										case 42:
																																										case 112:
																																											goto IL_0b6b;
																																										case 29:
																																											goto IL_0b79;
																																										case 135:
																																											goto IL_0b97;
																																										case 193:
																																											goto IL_0bae;
																																										case 286:
																																											goto IL_0bc1;
																																										case 91:
																																										case 118:
																																											goto IL_0bcc;
																																										case 204:
																																											goto IL_0bf0;
																																										case 300:
																																											goto IL_0bfe;
																																										case 191:
																																											goto IL_0c0c;
																																										case 184:
																																											goto IL_0c1f;
																																										case 285:
																																											goto IL_0c2d;
																																										case 89:
																																										case 139:
																																											goto IL_0c3b;
																																										case 232:
																																											goto IL_0c4f;
																																										case 219:
																																											goto IL_0ca3;
																																										case 275:
																																											goto IL_0cb1;
																																										case 2:
																																											goto IL_0cc4;
																																										case 61:
																																											goto IL_0cd2;
																																										case 167:
																																										case 256:
																																											goto IL_0ce0;
																																										case 182:
																																											goto IL_0d42;
																																										case 261:
																																											goto IL_0d55;
																																										case 40:
																																											goto IL_0d63;
																																										case 148:
																																											goto IL_0d76;
																																										case 104:
																																											goto IL_0d84;
																																										case 259:
																																											goto IL_0d92;
																																										case 183:
																																											goto IL_0da0;
																																										case 0:
																																											goto IL_0dae;
																																										case 267:
																																										case 276:
																																											goto IL_0db9;
																																										case 273:
																																											goto IL_0ddb;
																																										case 47:
																																											goto IL_0de9;
																																										case 161:
																																											goto IL_0df7;
																																										case 39:
																																											goto IL_0e0a;
																																										case 83:
																																											goto IL_0e18;
																																										case 86:
																																										case 281:
																																											goto IL_0e26;
																																										case 129:
																																											goto IL_0e94;
																																										case 19:
																																											goto IL_0ea7;
																																										case 27:
																																											goto IL_0eb5;
																																										case 103:
																																										case 274:
																																											goto IL_0ec3;
																																										case 68:
																																											goto IL_0f01;
																																										case 265:
																																											goto IL_0f15;
																																										case 224:
																																										case 236:
																																											goto IL_0f28;
																																										case 269:
																																											goto IL_0f3c;
																																										case 293:
																																											goto IL_0f7b;
																																										case 203:
																																											goto IL_0f8e;
																																										case 6:
																																											goto IL_0f9c;
																																										case 93:
																																										case 298:
																																											goto IL_0fa7;
																																										case 130:
																																											goto IL_0fe5;
																																										case 7:
																																											goto IL_0ff9;
																																										case 55:
																																											goto IL_100c;
																																										case 174:
																																											goto IL_101a;
																																										case 84:
																																										case 214:
																																											goto IL_1028;
																																										case 299:
																																											goto IL_1066;
																																										case 212:
																																											goto IL_107a;
																																										case 229:
																																											goto IL_108d;
																																										case 238:
																																											goto IL_1098;
																																										case 132:
																																										case 157:
																																											goto IL_10a6;
																																										case 188:
																																											goto IL_10ba;
																																										case 198:
																																											goto IL_10f9;
																																										case 173:
																																											goto IL_110c;
																																										case 16:
																																											goto IL_111a;
																																										case 17:
																																											goto IL_112d;
																																										case 44:
																																										case 205:
																																											goto IL_1138;
																																										case 262:
																																											goto IL_1152;
																																										case 280:
																																											goto IL_1160;
																																										case 291:
																																											goto IL_116e;
																																										case 127:
																																											goto IL_1181;
																																										case 149:
																																											goto IL_118f;
																																										case 81:
																																										case 192:
																																											goto IL_119a;
																																										case 14:
																																											goto IL_11ae;
																																										case 52:
																																											goto IL_11eb;
																																										case 158:
																																											goto IL_11fe;
																																										case 90:
																																											goto IL_120c;
																																										case 36:
																																										case 58:
																																											goto IL_1217;
																																										case 278:
																																											goto IL_1269;
																																										case 294:
																																											goto IL_127c;
																																										case 122:
																																											goto IL_128a;
																																										case 254:
																																										case 290:
																																											goto IL_1298;
																																										case 73:
																																											goto IL_12ac;
																																										case 266:
																																											goto IL_12fe;
																																										case 45:
																																											goto IL_130c;
																																										case 221:
																																											goto IL_131f;
																																										case 225:
																																											goto IL_132d;
																																										case 50:
																																										case 211:
																																											goto IL_133b;
																																										case 76:
																																											goto IL_134f;
																																										case 41:
																																											goto IL_1387;
																																										case 23:
																																											goto IL_13a3;
																																										case 102:
																																											goto IL_13b1;
																																										case 99:
																																											goto IL_13bc;
																																										case 60:
																																											goto IL_13ca;
																																										case 155:
																																										case 235:
																																											goto IL_13d8;
																																										case 146:
																																											goto IL_13e6;
																																										case 59:
																																											goto IL_1404;
																																										case 82:
																																											goto IL_141b;
																																										case 8:
																																										case 94:
																																											goto IL_142e;
																																										case 142:
																																											goto IL_144b;
																																										case 217:
																																											goto IL_1483;
																																										case 143:
																																											goto IL_1496;
																																										case 252:
																																											goto IL_14a1;
																																										case 230:
																																										case 282:
																																											goto IL_14af;
																																										case 106:
																																											goto IL_14c3;
																																										case 141:
																																											goto IL_1500;
																																										case 144:
																																											goto IL_1513;
																																										case 207:
																																											goto IL_1521;
																																										case 151:
																																										case 271:
																																											goto IL_1538;
																																										case 227:
																																											goto IL_154c;
																																										case 123:
																																											goto IL_159e;
																																										case 284:
																																											goto IL_15ac;
																																										case 10:
																																										case 22:
																																										case 28:
																																										case 31:
																																										case 35:
																																										case 43:
																																										case 48:
																																										case 53:
																																										case 63:
																																										case 64:
																																										case 74:
																																										case 85:
																																										case 92:
																																										case 100:
																																										case 108:
																																										case 110:
																																										case 114:
																																										case 133:
																																										case 137:
																																										case 153:
																																										case 163:
																																										case 171:
																																										case 175:
																																										case 177:
																																										case 178:
																																										case 185:
																																										case 186:
																																										case 190:
																																										case 197:
																																										case 208:
																																										case 213:
																																										case 215:
																																										case 228:
																																										case 243:
																																										case 246:
																																										case 250:
																																										case 251:
																																										case 263:
																																											goto end_IL_0549;
																																										case 12:
																																										case 13:
																																										case 32:
																																										case 37:
																																										case 46:
																																										case 49:
																																										case 54:
																																										case 65:
																																										case 70:
																																										case 71:
																																										case 75:
																																										case 79:
																																										case 115:
																																										case 125:
																																										case 136:
																																										case 140:
																																										case 147:
																																										case 159:
																																										case 168:
																																										case 169:
																																										case 172:
																																										case 181:
																																										case 195:
																																										case 196:
																																										case 201:
																																										case 202:
																																										case 206:
																																										case 222:
																																										case 223:
																																										case 237:
																																										case 245:
																																										case 248:
																																										case 253:
																																										case 255:
																																										case 258:
																																										case 277:
																																										case 279:
																																										case 287:
																																											goto end_IL_060c;
																																										case 57:
																																											goto end_IL_15cf;
																																										case 160:
																																											goto end_IL_15e2;
																																										case 1:
																																											goto end_IL_15ec;
																																										case 33:
																																											goto end_IL_15f7;
																																										case 176:
																																											goto end_IL_160c;
																																										case 117:
																																											goto end_IL_161c;
																																										case 249:
																																											goto end_IL_162c;
																																										case 20:
																																											goto end_IL_163c;
																																										case 296:
																																											goto end_IL_164c;
																																										case 56:
																																											goto end_IL_1657;
																																										case 162:
																																											goto end_IL_1667;
																																										case 95:
																																											goto end_IL_1677;
																																										case 96:
																																											goto end_IL_1682;
																																										case 239:
																																										case 244:
																																											goto IL_16a6;
																																										}
																																										continue;
																																									}
																																									num5--;
																																									goto end_IL_060c;
																																									continue;
																																									end_IL_04e9:
																																									break;
																																								}
																																								break;
																																							}
																																							break;
																																						}
																																						goto IL_0632;
																																						continue;
																																						end_IL_0549:
																																						break;
																																						IL_0549:;
																																					}
																																					break;
																																					IL_055c:;
																																				}
																																				break;
																																			}
																																			goto IL_0617;
																																			IL_06f2:
																																			num5--;
																																			goto end_IL_060c;
																																			IL_0617:
																																			if (2 > b)
																																			{
																																				goto IL_0622;
																																			}
																																			goto IL_069e;
																																			IL_0622:
																																			if (1 < b)
																																			{
																																				break;
																																			}
																																			goto IL_068e;
																																			IL_068e:
																																			if (1 > b)
																																			{
																																				break;
																																			}
																																			goto IL_0705;
																																			IL_0705:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																			goto IL_0791;
																																			IL_0791:
																																			array[num5] = 0;
																																			goto IL_079f;
																																			IL_079f:
																																			num5++;
																																			goto IL_07ad;
																																			IL_07ad:
																																			ptr2 += 8;
																																			num = 79;
																																			goto end_IL_060c;
																																			IL_069e:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																			goto IL_06de;
																																			IL_06de:
																																			array[num5 - 2] = 0;
																																			goto IL_06f2;
																																		}
																																		break;
																																	}
																																	goto IL_0632;
																																	IL_067b:
																																	ptr2 += 8;
																																	goto end_IL_060c;
																																	IL_0632:
																																	array[num5] = 0;
																																	goto IL_0640;
																																	IL_0640:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																	goto IL_0663;
																																	IL_0663:
																																	array2[num5] = null;
																																	goto IL_066d;
																																	IL_066d:
																																	num5++;
																																	goto IL_067b;
																																}
																																break;
																															}
																															goto IL_084c;
																															IL_09ec:
																															array[num5 - 2] = 0;
																															goto IL_0a00;
																															IL_084c:
																															if (6 >= b)
																															{
																																goto IL_085a;
																															}
																															goto IL_095b;
																															IL_085a:
																															if (6 > b)
																															{
																																goto IL_0868;
																															}
																															goto IL_08f4;
																															IL_0868:
																															if (5 < b)
																															{
																																break;
																															}
																															goto IL_0876;
																															IL_0876:
																															if (5 > b)
																															{
																																break;
																															}
																															goto IL_0884;
																															IL_0884:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_08c4;
																															IL_08c4:
																															array[num5 - 2] = 0;
																															num = 5;
																															goto IL_08e1;
																															IL_08e1:
																															num5--;
																															goto end_IL_060c;
																															IL_08f4:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_0934;
																															IL_0934:
																															array[num5 - 2] = 0;
																															goto IL_0948;
																															IL_0948:
																															num5--;
																															goto end_IL_060c;
																															IL_095b:
																															if (7 < b)
																															{
																																goto IL_0966;
																															}
																															num = 154;
																															goto IL_099e;
																															IL_0966:
																															if (8 < b)
																															{
																																break;
																															}
																															goto IL_0974;
																															IL_0974:
																															if (8 > b)
																															{
																																break;
																															}
																															goto IL_0982;
																															IL_0982:
																															num5--;
																															goto end_IL_060c;
																															IL_0a00:
																															num5--;
																															goto end_IL_060c;
																															IL_099e:
																															if (7 > b)
																															{
																																break;
																															}
																															goto IL_09ac;
																															IL_09ac:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_09ec;
																														}
																														break;
																													}
																													goto IL_07c9;
																													IL_0826:
																													num5--;
																													goto end_IL_060c;
																													IL_07c9:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 233;
																													goto IL_0812;
																													IL_0812:
																													array[num5 - 2] = 0;
																													goto IL_0826;
																												}
																												break;
																											}
																											goto IL_0a13;
																											IL_0d63:
																											if (12 > b)
																											{
																												break;
																											}
																											goto end_IL_060c;
																											IL_0a13:
																											if (13 < b)
																											{
																												goto IL_0a21;
																											}
																											goto IL_0bc1;
																											IL_0a21:
																											if (15 >= b)
																											{
																												goto IL_0a2f;
																											}
																											goto IL_0ae6;
																											IL_0a2f:
																											if (15 > b)
																											{
																												goto IL_0a3d;
																											}
																											goto IL_0aca;
																											IL_0a3d:
																											if (14 < b)
																											{
																												break;
																											}
																											goto IL_0a4b;
																											IL_0a4b:
																											if (14 > b)
																											{
																												break;
																											}
																											goto IL_0a59;
																											IL_0a59:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0ab7;
																											IL_0ab7:
																											num5--;
																											goto end_IL_060c;
																											IL_0aca:
																											byte* num6 = ptr2;
																											num4 = 1;
																											ptr2 = num6 + -200;
																											goto end_IL_060c;
																											IL_0ae6:
																											if (16 >= b)
																											{
																												goto IL_0af1;
																											}
																											goto IL_0b4f;
																											IL_0af1:
																											if (16 > b)
																											{
																												break;
																											}
																											goto IL_0aff;
																											IL_0aff:
																											array2[num5] = array5[*(int*)(ptr2 + num3)];
																											num = 283;
																											goto IL_0b20;
																											IL_0b20:
																											array[num5] = 5;
																											goto IL_0b2e;
																											IL_0b2e:
																											num5++;
																											goto IL_0b3c;
																											IL_0b3c:
																											ptr2 += 8;
																											goto end_IL_060c;
																											IL_0b4f:
																											if (17 < b)
																											{
																												break;
																											}
																											goto IL_0b5d;
																											IL_0b5d:
																											if (17 > b)
																											{
																												break;
																											}
																											goto IL_0b6b;
																											IL_0b6b:
																											array[num5] = 5;
																											goto IL_0b79;
																											IL_0b79:
																											array2[num5] = ((delegate*<GorillaTagger>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])();
																											goto IL_0b97;
																											IL_0b97:
																											num5++;
																											num = 193;
																											goto IL_0bae;
																											IL_0bae:
																											ptr2 += 8;
																											goto end_IL_060c;
																											IL_0bc1:
																											if (13 <= b)
																											{
																												goto IL_0bcc;
																											}
																											goto IL_0c1f;
																											IL_0bcc:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])() ? 1 : 0);
																											goto IL_0bf0;
																											IL_0bf0:
																											array[num5] = 0;
																											goto IL_0bfe;
																											IL_0bfe:
																											num5++;
																											goto IL_0c0c;
																											IL_0c0c:
																											ptr2 += 8;
																											goto end_IL_060c;
																											IL_0c1f:
																											if (11 >= b)
																											{
																												goto IL_0c2d;
																											}
																											goto IL_0d55;
																											IL_0c2d:
																											if (11 <= b)
																											{
																												goto IL_0c3b;
																											}
																											goto IL_0cc4;
																											IL_0c3b:
																											array[num5 - 2] = 0;
																											goto IL_0c4f;
																											IL_0c4f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																											goto IL_0ca3;
																											IL_0ca3:
																											num5--;
																											goto IL_0cb1;
																											IL_0cb1:
																											ptr2 += 8;
																											goto end_IL_060c;
																											IL_0cc4:
																											if (10 < b)
																											{
																												break;
																											}
																											goto IL_0cd2;
																											IL_0cd2:
																											if (10 > b)
																											{
																												break;
																											}
																											goto IL_0ce0;
																											IL_0ce0:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0d42;
																											IL_0d42:
																											num5 -= 2;
																											goto end_IL_060c;
																											IL_0d55:
																											if (12 < b)
																											{
																												break;
																											}
																											goto IL_0d63;
																										}
																										break;
																									}
																									goto IL_0720;
																									IL_0775:
																									ptr2 += 8;
																									num = 71;
																									goto end_IL_060c;
																									IL_0720:
																									array2[num5 - 1] = ((delegate*<GorillaTagger, VRRig>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																									goto IL_0758;
																									IL_0758:
																									array[num5 - 1] = 5;
																									num = 156;
																									goto IL_0775;
																								}
																								break;
																							}
																							goto IL_0d76;
																							IL_159e:
																							num5--;
																							goto IL_15ac;
																							IL_0d76:
																							if (27 < b)
																							{
																								goto IL_0d84;
																							}
																							goto IL_112d;
																							IL_0d84:
																							if (31 >= b)
																							{
																								goto IL_0d92;
																							}
																							goto IL_0f8e;
																							IL_0d92:
																							if (31 > b)
																							{
																								goto IL_0da0;
																							}
																							goto IL_0f28;
																							IL_0da0:
																							if (29 >= b)
																							{
																								goto IL_0dae;
																							}
																							goto IL_0ea7;
																							IL_0dae:
																							if (29 <= b)
																							{
																								goto IL_0db9;
																							}
																							goto IL_0e0a;
																							IL_0db9:
																							array2[num5] = (Vector3)array5[*(int*)(ptr2 + num3)];
																							goto IL_0ddb;
																							IL_0ddb:
																							array[num5] = 4;
																							goto IL_0de9;
																							IL_0de9:
																							num5++;
																							goto IL_0df7;
																							IL_0df7:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_0e0a:
																							if (28 < b)
																							{
																								break;
																							}
																							goto IL_0e18;
																							IL_0e18:
																							if (28 > b)
																							{
																								break;
																							}
																							goto IL_0e26;
																							IL_0e26:
																							ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0e94;
																							IL_0e94:
																							num5 -= 2;
																							goto end_IL_060c;
																							IL_0ea7:
																							if (30 < b)
																							{
																								break;
																							}
																							goto IL_0eb5;
																							IL_0eb5:
																							if (30 > b)
																							{
																								break;
																							}
																							goto IL_0ec3;
																							IL_0ec3:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<Vector3, float>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																							goto IL_0f01;
																							IL_0f01:
																							array[num5 - 1] = 3;
																							goto IL_0f15;
																							IL_0f15:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_0f28:
																							array[num5 - 1] = 0;
																							goto IL_0f3c;
																							IL_0f3c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<float, bool>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]))) ? 1 : 0);
																							goto IL_0f7b;
																							IL_0f7b:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_0f8e:
																							if (33 >= b)
																							{
																								goto IL_0f9c;
																							}
																							goto IL_108d;
																							IL_0f9c:
																							if (33 <= b)
																							{
																								goto IL_0fa7;
																							}
																							goto IL_100c;
																							IL_0fa7:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<Vector3, float>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																							goto IL_0fe5;
																							IL_0fe5:
																							array[num5 - 1] = 3;
																							goto IL_0ff9;
																							IL_0ff9:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_100c:
																							if (32 < b)
																							{
																								break;
																							}
																							goto IL_101a;
																							IL_101a:
																							if (32 > b)
																							{
																								break;
																							}
																							goto IL_1028;
																							IL_1028:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<Vector3, float>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																							goto IL_1066;
																							IL_1066:
																							array[num5 - 1] = 3;
																							goto IL_107a;
																							IL_107a:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_108d:
																							if (34 >= b)
																							{
																								goto IL_1098;
																							}
																							goto IL_110c;
																							IL_1098:
																							if (34 > b)
																							{
																								break;
																							}
																							goto IL_10a6;
																							IL_10a6:
																							array[num5 - 1] = 0;
																							goto IL_10ba;
																							IL_10ba:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<float, bool>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]))) ? 1 : 0);
																							goto IL_10f9;
																							IL_10f9:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_110c:
																							if (35 < b)
																							{
																								break;
																							}
																							goto IL_111a;
																							IL_111a:
																							if (35 > b)
																							{
																							}
																							break;
																							IL_112d:
																							if (27 <= b)
																							{
																								goto IL_1138;
																							}
																							goto IL_1181;
																							IL_1138:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																							goto IL_1152;
																							IL_1152:
																							array[num5] = 3;
																							goto IL_1160;
																							IL_1160:
																							num5++;
																							goto IL_116e;
																							IL_116e:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_1181:
																							if (22 >= b)
																							{
																								goto IL_118f;
																							}
																							goto IL_13a3;
																							IL_118f:
																							if (22 <= b)
																							{
																								goto IL_119a;
																							}
																							goto IL_11fe;
																							IL_119a:
																							array[num5 - 1] = 4;
																							goto IL_11ae;
																							IL_11ae:
																							array2[num5 - 1] = ((delegate*<Transform, Vector3>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																							goto IL_11eb;
																							IL_11eb:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_11fe:
																							if (20 >= b)
																							{
																								goto IL_120c;
																							}
																							goto IL_131f;
																							IL_120c:
																							if (20 <= b)
																							{
																								goto IL_1217;
																							}
																							goto IL_127c;
																							IL_1217:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_1269;
																							IL_1269:
																							num5--;
																							goto end_IL_060c;
																							IL_127c:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_128a;
																							IL_128a:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_1298;
																							IL_1298:
																							array[num5 - 2] = 0;
																							goto IL_12ac;
																							IL_12ac:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (VRRig)array2[num5 - 1]) ? 1 : 0);
																							goto IL_12fe;
																							IL_12fe:
																							num5--;
																							goto IL_130c;
																							IL_130c:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_131f:
																							if (21 < b)
																							{
																								break;
																							}
																							goto IL_132d;
																							IL_132d:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_133b;
																							IL_133b:
																							array[num5 - 1] = 5;
																							goto IL_134f;
																							IL_134f:
																							array2[num5 - 1] = ((delegate*<Component, Transform>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																							goto IL_1387;
																							IL_1387:
																							ptr2 += 8;
																							num = 169;
																							goto end_IL_060c;
																							IL_13a3:
																							if (24 >= b)
																							{
																								goto IL_13b1;
																							}
																							goto IL_1496;
																							IL_13b1:
																							if (24 > b)
																							{
																								goto IL_13bc;
																							}
																							goto IL_142e;
																							IL_13bc:
																							if (23 < b)
																							{
																								break;
																							}
																							goto IL_13ca;
																							IL_13ca:
																							if (23 > b)
																							{
																								break;
																							}
																							goto IL_13d8;
																							IL_13d8:
																							array[num5] = 5;
																							goto IL_13e6;
																							IL_13e6:
																							array2[num5] = ((delegate*<GorillaTagger>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])();
																							goto IL_1404;
																							IL_1404:
																							num5++;
																							num = 82;
																							goto IL_141b;
																							IL_141b:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_142e:
																							array[num5 - 1] = 5;
																							num = 142;
																							goto IL_144b;
																							IL_144b:
																							array2[num5 - 1] = ((delegate*<Component, Transform>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																							goto IL_1483;
																							IL_1483:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_1496:
																							if (25 >= b)
																							{
																								goto IL_14a1;
																							}
																							goto IL_1513;
																							IL_14a1:
																							if (25 > b)
																							{
																								break;
																							}
																							goto IL_14af;
																							IL_14af:
																							array[num5 - 1] = 4;
																							goto IL_14c3;
																							IL_14c3:
																							array2[num5 - 1] = ((delegate*<Transform, Vector3>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																							goto IL_1500;
																							IL_1500:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_1513:
																							if (26 < b)
																							{
																								break;
																							}
																							goto IL_1521;
																							IL_1521:
																							if (26 > b)
																							{
																								break;
																							}
																							num = 151;
																							goto IL_1538;
																							IL_15ac:
																							ptr2 += 8;
																							goto end_IL_060c;
																							IL_1538:
																							array[num5 - 2] = 3;
																							goto IL_154c;
																							IL_154c:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<Vector3, Vector3, float>)IsSingleByteQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																							goto IL_159e;
																						}
																						break;
																						IL_05dc:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_060c;
																				continue;
																				end_IL_05ec:
																				break;
																			}
																			continue;
																			end_IL_05fc:
																			break;
																		}
																		continue;
																		end_IL_060c:
																		break;
																	}
																	continue;
																}
																goto IL_16a6;
																IL_16a6:
																return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																continue;
																end_IL_15cf:
																break;
															}
															continue;
															end_IL_15e2:
															break;
														}
														continue;
														end_IL_15ec:
														break;
													}
													continue;
													end_IL_15f7:
													break;
												}
												continue;
												end_IL_160c:
												break;
											}
											continue;
											end_IL_161c:
											break;
										}
										continue;
										end_IL_162c:
										break;
									}
									continue;
									end_IL_163c:
									break;
								}
								continue;
								end_IL_164c:
								break;
							}
							continue;
							end_IL_1657:
							break;
						}
						continue;
						end_IL_1667:
						break;
					}
					continue;
					end_IL_1677:
					break;
				}
				continue;
				end_IL_1682:
				break;
			}
		}
	}

	public Class145()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			return num - num2;
		}
		num = int_1;
		num2 = int_2;
		return num - num2;
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 90;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 56;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getOpcodesetInitLocals.IRuntimeFieldInfoUnderlyingField);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_027d:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0260:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0250:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0240:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0233:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (true)
																											{
																												IL_0210:
																												if (5 > b)
																												{
																													num = 120;
																													while (num != 120)
																													{
																														if (num != 1101)
																														{
																															goto IL_03c9;
																														}
																														switch (num)
																														{
																														case 73:
																															goto IL_0210;
																														case 43:
																															goto IL_0223;
																														case 98:
																														case 103:
																															goto IL_0233;
																														case 15:
																															goto IL_0240;
																														case 85:
																															goto IL_0250;
																														case 102:
																															goto IL_0260;
																														case 17:
																															goto IL_026d;
																														case 81:
																															goto IL_027d;
																														case 14:
																															goto end_IL_027d;
																														case 5:
																														case 70:
																															goto end_IL_028d;
																														case 47:
																															goto IL_02a8;
																														case 96:
																														case 108:
																															goto IL_02bb;
																														case 104:
																															goto IL_02c9;
																														case 20:
																														case 57:
																															goto IL_02d4;
																														case 13:
																															goto IL_0336;
																														case 80:
																															goto IL_0349;
																														case 27:
																															goto IL_0354;
																														case 22:
																														case 69:
																															goto IL_0362;
																														case 61:
																															goto IL_03a2;
																														case 58:
																															goto IL_03b6;
																														case 35:
																														case 68:
																															goto IL_03c9;
																														case 100:
																															goto IL_03d7;
																														case 59:
																														case 86:
																															goto IL_03e5;
																														case 91:
																															goto IL_0411;
																														case 16:
																															goto IL_041f;
																														case 87:
																															goto IL_042d;
																														case 32:
																															goto IL_0440;
																														case 3:
																														case 55:
																															goto IL_044b;
																														case 8:
																															goto IL_0459;
																														case 42:
																															goto IL_0475;
																														case 7:
																														case 112:
																															goto IL_0483;
																														case 30:
																														case 78:
																															goto IL_049f;
																														case 67:
																															goto IL_04ad;
																														case 21:
																															goto IL_04d0;
																														case 60:
																															goto IL_04da;
																														case 38:
																															goto IL_04e8;
																														case 84:
																															goto IL_04fb;
																														case 65:
																														case 66:
																															goto IL_0506;
																														case 0:
																															goto IL_051e;
																														case 82:
																															goto IL_0529;
																														case 77:
																															goto IL_0537;
																														case 44:
																														case 99:
																															goto IL_0545;
																														case 107:
																															goto IL_056e;
																														case 41:
																															goto IL_057c;
																														case 110:
																															goto IL_05a1;
																														case 29:
																														case 50:
																															goto IL_05af;
																														case 24:
																															goto IL_05c8;
																														case 33:
																															goto IL_05d6;
																														case 36:
																															goto IL_05e4;
																														case 4:
																														case 48:
																															goto IL_05fd;
																														case 1:
																															goto IL_063d;
																														case 25:
																															goto IL_0651;
																														case 9:
																														case 12:
																														case 26:
																														case 34:
																														case 39:
																														case 40:
																														case 45:
																														case 46:
																														case 49:
																														case 53:
																														case 54:
																														case 64:
																														case 72:
																														case 83:
																														case 88:
																														case 92:
																														case 94:
																														case 101:
																														case 105:
																														case 111:
																														case 113:
																															goto end_IL_01fd;
																														case 2:
																														case 6:
																														case 11:
																														case 18:
																														case 19:
																														case 23:
																														case 28:
																														case 63:
																														case 71:
																														case 75:
																														case 76:
																														case 97:
																														case 106:
																														case 109:
																															goto end_IL_029d;
																														case 74:
																															goto end_IL_0674;
																														case 62:
																															goto end_IL_0687;
																														case 56:
																															goto end_IL_0691;
																														case 93:
																															goto end_IL_069c;
																														case 51:
																														case 79:
																															goto end_IL_06b1;
																														case 52:
																															goto end_IL_06ca;
																														case 31:
																														case 95:
																															goto end_IL_06da;
																														case 89:
																															goto end_IL_06ea;
																														case 90:
																															goto end_IL_06fa;
																														case 10:
																														case 37:
																															goto IL_0715;
																														}
																														continue;
																														end_IL_01fd:
																														break;
																													}
																													break;
																												}
																												goto IL_049f;
																												IL_04da:
																												num5++;
																												goto IL_04e8;
																												IL_04e8:
																												ptr2 += 8;
																												goto end_IL_029d;
																												IL_049f:
																												array[num5] = 0;
																												goto IL_04ad;
																												IL_04ad:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_04d0;
																												IL_04d0:
																												array2[num5] = null;
																												goto IL_04da;
																											}
																											break;
																											IL_0223:;
																										}
																										break;
																									}
																									goto IL_02a8;
																									IL_02a8:
																									if (4 <= b)
																									{
																										goto end_IL_029d;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_04fb;
																							IL_05d6:
																							num5++;
																							goto IL_05e4;
																							IL_04fb:
																							if (3 <= b)
																							{
																								goto IL_0506;
																							}
																							goto IL_051e;
																							IL_0506:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_029d;
																							IL_051e:
																							if (1 < b)
																							{
																								goto IL_0529;
																							}
																							num = 110;
																							goto IL_05a1;
																							IL_0529:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0537;
																							IL_0537:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0545;
																							IL_0545:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_056e;
																							IL_056e:
																							ptr2 += 8;
																							goto IL_057c;
																							IL_057c:
																							num5--;
																							num = 109;
																							goto end_IL_029d;
																							IL_05e4:
																							ptr2 += 8;
																							num = 11;
																							goto end_IL_029d;
																							IL_05a1:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_05af;
																							IL_05af:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_05c8;
																							IL_05c8:
																							array[num5] = 0;
																							goto IL_05d6;
																						}
																						break;
																					}
																					goto IL_05fd;
																					IL_0651:
																					num5--;
																					goto end_IL_029d;
																					IL_05fd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_063d;
																					IL_063d:
																					array[num5 - 2] = 0;
																					goto IL_0651;
																				}
																				break;
																			}
																			goto IL_02bb;
																			IL_0475:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0483;
																			IL_02bb:
																			if (9 >= b)
																			{
																				goto IL_02c9;
																			}
																			goto IL_0440;
																			IL_02c9:
																			if (9 <= b)
																			{
																				goto IL_02d4;
																			}
																			goto IL_0349;
																			IL_02d4:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0336;
																			IL_0336:
																			num5 -= 2;
																			goto end_IL_029d;
																			IL_0349:
																			if (7 >= b)
																			{
																				goto IL_0354;
																			}
																			goto IL_03c9;
																			IL_0354:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0362;
																			IL_0362:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03a2;
																			IL_03a2:
																			array[num5 - 2] = 0;
																			goto IL_03b6;
																			IL_03b6:
																			num5--;
																			goto end_IL_029d;
																			IL_03c9:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_03d7;
																			IL_03d7:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_03e5;
																			IL_03e5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 91;
																			goto IL_0411;
																			IL_0411:
																			array[num5] = 0;
																			goto IL_041f;
																			IL_041f:
																			num5++;
																			goto IL_042d;
																			IL_042d:
																			ptr2 += 8;
																			goto end_IL_029d;
																			IL_0440:
																			if (10 < b)
																			{
																				goto IL_044b;
																			}
																			goto IL_0475;
																			IL_044b:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0459;
																			IL_0459:
																			if (11 <= b)
																			{
																				num = 105;
																			}
																			break;
																			IL_0483:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_029d;
																		}
																		break;
																		IL_026d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_029d;
																continue;
																end_IL_027d:
																break;
															}
															continue;
															end_IL_028d:
															break;
														}
														continue;
														end_IL_029d:
														break;
													}
													continue;
												}
												goto IL_0715;
												IL_0715:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0674:
												break;
											}
											continue;
											end_IL_0687:
											break;
										}
										continue;
										end_IL_0691:
										break;
									}
									continue;
									end_IL_069c:
									break;
								}
								continue;
								end_IL_06b1:
								break;
							}
							continue;
							end_IL_06ca:
							break;
						}
						continue;
						end_IL_06da:
						break;
					}
					continue;
					end_IL_06ea:
					break;
				}
				continue;
				end_IL_06fa:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 36;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClsidAccessRuleType.MessageSmugglerOverideEventProvider);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 54;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_01fc:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				if (4 >= b)
																				{
																					while (true)
																					{
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01bc:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01ac:
																										if (2 > b)
																										{
																											num = 95;
																											while (true)
																											{
																												if (num != 95)
																												{
																													if (num != 1076)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 64:
																														goto IL_01ac;
																													case 19:
																													case 41:
																														goto IL_01bc;
																													case 13:
																														goto end_IL_0199;
																													case 72:
																														goto end_IL_01cc;
																													case 29:
																														goto end_IL_01dc;
																													case 83:
																														goto IL_01fc;
																													case 43:
																														goto end_IL_01fc;
																													case 24:
																													case 57:
																														goto end_IL_020c;
																													case 10:
																													case 76:
																														goto IL_0227;
																													case 40:
																														goto IL_0295;
																													case 59:
																														goto IL_02a8;
																													case 61:
																														goto IL_02b6;
																													case 4:
																													case 28:
																														goto IL_02d2;
																													case 5:
																														goto IL_02e0;
																													case 48:
																													case 70:
																														goto IL_02ee;
																													case 32:
																														goto IL_032e;
																													case 26:
																														goto IL_034b;
																													case 44:
																													case 75:
																														goto IL_035e;
																													case 66:
																														goto IL_0387;
																													case 69:
																														goto IL_0395;
																													case 9:
																														goto IL_03a8;
																													case 30:
																														goto IL_03b3;
																													case 81:
																														goto IL_03c1;
																													case 63:
																														goto IL_03cf;
																													case 7:
																													case 82:
																														goto IL_03dd;
																													case 56:
																													case 84:
																														goto IL_03f5;
																													case 50:
																														goto IL_0400;
																													case 87:
																														goto IL_040e;
																													case 51:
																													case 68:
																														goto IL_041c;
																													case 86:
																														goto IL_044a;
																													case 1:
																													case 52:
																														goto IL_0455;
																													case 37:
																														goto IL_0463;
																													case 20:
																														goto IL_0486;
																													case 55:
																														goto IL_0490;
																													case 85:
																														goto IL_049e;
																													case 0:
																													case 14:
																													case 15:
																													case 17:
																													case 18:
																													case 22:
																													case 33:
																													case 45:
																													case 46:
																													case 49:
																													case 58:
																													case 62:
																													case 71:
																													case 74:
																													case 77:
																													case 88:
																														goto end_IL_01ec;
																													case 78:
																														goto IL_04d1;
																													case 6:
																														goto IL_04df;
																													case 3:
																														goto IL_04ed;
																													case 25:
																													case 27:
																													case 34:
																													case 38:
																													case 39:
																													case 42:
																													case 47:
																													case 54:
																													case 60:
																													case 67:
																													case 79:
																														goto end_IL_021c;
																													case 80:
																														goto end_IL_0504;
																													case 8:
																														goto end_IL_0517;
																													case 12:
																														goto end_IL_052a;
																													case 73:
																														goto end_IL_0535;
																													case 31:
																														goto end_IL_054a;
																													case 16:
																													case 21:
																														goto end_IL_055f;
																													case 23:
																														goto end_IL_056f;
																													case 53:
																													case 65:
																														goto end_IL_057f;
																													case 35:
																														goto end_IL_058f;
																													case 36:
																														goto end_IL_059f;
																													case 2:
																													case 11:
																														goto IL_05ba;
																													}
																													continue;
																												}
																												goto IL_02a8;
																												IL_02a8:
																												if (1 < b)
																												{
																													goto end_IL_01ec;
																												}
																												goto IL_02b6;
																												IL_02b6:
																												if (1 > b)
																												{
																													num = 14;
																												}
																												goto end_IL_01ec;
																												continue;
																												end_IL_0199:
																												break;
																											}
																											break;
																										}
																										goto IL_0227;
																										IL_0227:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0295;
																										IL_0295:
																										num5 -= 2;
																										goto end_IL_021c;
																									}
																									break;
																								}
																								goto IL_02d2;
																								IL_034b:
																								num5--;
																								goto end_IL_021c;
																								IL_02d2:
																								if (3 < b)
																								{
																									goto end_IL_01ec;
																								}
																								goto IL_02e0;
																								IL_02e0:
																								if (3 > b)
																								{
																									goto end_IL_01ec;
																								}
																								goto IL_02ee;
																								IL_02ee:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_032e;
																								IL_032e:
																								array[num5 - 2] = 0;
																								num = 26;
																								goto IL_034b;
																							}
																							continue;
																						}
																						goto IL_035e;
																						IL_0395:
																						num5--;
																						goto end_IL_021c;
																						IL_035e:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0387;
																						IL_0387:
																						ptr2 += 8;
																						goto IL_0395;
																						continue;
																						end_IL_01cc:
																						break;
																					}
																					continue;
																				}
																				goto IL_03a8;
																				IL_0490:
																				num5++;
																				goto IL_049e;
																				IL_03a8:
																				if (6 >= b)
																				{
																					goto IL_03b3;
																				}
																				goto IL_03f5;
																				IL_03b3:
																				if (6 <= b)
																				{
																					goto end_IL_021c;
																				}
																				goto IL_03c1;
																				IL_03c1:
																				if (5 < b)
																				{
																					goto end_IL_01ec;
																				}
																				goto IL_03cf;
																				IL_03cf:
																				if (5 > b)
																				{
																					goto end_IL_01ec;
																				}
																				goto IL_03dd;
																				IL_03dd:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_021c;
																				IL_03f5:
																				if (7 < b)
																				{
																					goto IL_0400;
																				}
																				num = 86;
																				goto IL_044a;
																				IL_0400:
																				if (8 < b)
																				{
																					goto end_IL_01ec;
																				}
																				goto IL_040e;
																				IL_040e:
																				if (8 > b)
																				{
																					goto end_IL_01ec;
																				}
																				goto IL_041c;
																				IL_041c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 39;
																				goto end_IL_021c;
																				IL_049e:
																				ptr2 += 8;
																				goto end_IL_021c;
																				IL_044a:
																				if (7 > b)
																				{
																					goto end_IL_01ec;
																				}
																				goto IL_0455;
																				IL_0455:
																				array[num5] = 0;
																				goto IL_0463;
																				IL_0463:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0486;
																				IL_0486:
																				array2[num5] = null;
																				goto IL_0490;
																				continue;
																				end_IL_01dc:
																				break;
																			}
																			continue;
																			end_IL_01ec:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d1;
																	IL_04ed:
																	ptr2 += 8;
																	num = 47;
																	goto end_IL_021c;
																	IL_04df:
																	num5++;
																	goto IL_04ed;
																	IL_04d1:
																	array[num5] = 0;
																	goto IL_04df;
																	continue;
																	end_IL_01fc:
																	break;
																}
																continue;
																end_IL_020c:
																break;
															}
															continue;
															end_IL_021c:
															break;
														}
														continue;
													}
													goto IL_05ba;
													IL_05ba:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0504:
													break;
												}
												continue;
												end_IL_0517:
												break;
											}
											continue;
											end_IL_052a:
											break;
										}
										continue;
										end_IL_0535:
										break;
									}
									continue;
									end_IL_054a:
									break;
								}
								continue;
								end_IL_055f:
								break;
							}
							continue;
							end_IL_056f:
							break;
						}
						continue;
						end_IL_057f:
						break;
					}
					continue;
					end_IL_058f:
					break;
				}
				continue;
				end_IL_059f:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1, int int_2)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 71;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsolatedStorageFileStreamTOKENSOURCE.ObjectUtfXml);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 36;
																while (true)
																{
																	IL_01f8:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01d8:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01c8:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01b8:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01a8:
																										if (3 < b)
																										{
																											num = 94;
																											while (num != 94)
																											{
																												if (num != 1075)
																												{
																													goto IL_03c3;
																												}
																												switch (num)
																												{
																												case 22:
																												case 67:
																													goto IL_01a8;
																												case 31:
																													goto IL_01b8;
																												case 51:
																													goto IL_01c8;
																												case 17:
																													goto IL_01d8;
																												case 27:
																													goto IL_01e8;
																												case 36:
																													goto IL_01f8;
																												case 49:
																													goto end_IL_01f8;
																												case 21:
																												case 84:
																													goto end_IL_0208;
																												case 69:
																													goto IL_022c;
																												case 60:
																												case 61:
																													goto IL_023a;
																												case 44:
																													goto IL_027a;
																												case 66:
																													goto IL_028e;
																												case 6:
																												case 70:
																													goto IL_02a1;
																												case 1:
																													goto IL_02ca;
																												case 19:
																													goto IL_02d8;
																												case 55:
																													goto IL_02eb;
																												case 79:
																												case 82:
																													goto IL_02f6;
																												case 48:
																													goto IL_030d;
																												case 16:
																												case 23:
																													goto IL_0320;
																												case 52:
																													goto IL_0397;
																												case 56:
																													goto IL_03aa;
																												case 13:
																													goto IL_03b5;
																												case 46:
																													goto IL_03c3;
																												case 62:
																													goto IL_03ce;
																												case 25:
																												case 85:
																													goto IL_03dc;
																												case 32:
																													goto IL_040b;
																												case 45:
																												case 58:
																													goto IL_0416;
																												case 5:
																													goto IL_0424;
																												case 33:
																												case 35:
																													goto IL_0432;
																												case 18:
																													goto IL_044e;
																												case 57:
																												case 65:
																													goto IL_0459;
																												case 28:
																													goto IL_0470;
																												case 77:
																													goto IL_0493;
																												case 81:
																													goto IL_049d;
																												case 29:
																													goto IL_04ab;
																												case 2:
																												case 3:
																												case 9:
																												case 12:
																												case 15:
																												case 34:
																												case 40:
																												case 41:
																												case 47:
																												case 53:
																												case 59:
																												case 75:
																												case 78:
																												case 80:
																												case 87:
																													goto end_IL_0195;
																												case 7:
																													goto IL_04de;
																												case 54:
																													goto IL_04ec;
																												case 11:
																													goto IL_0503;
																												case 0:
																												case 4:
																												case 8:
																												case 20:
																												case 24:
																												case 43:
																												case 50:
																												case 68:
																												case 72:
																												case 73:
																												case 74:
																													goto end_IL_0221;
																												case 37:
																													goto end_IL_0511;
																												case 14:
																													goto end_IL_0524;
																												case 30:
																													goto end_IL_052e;
																												case 39:
																													goto end_IL_0539;
																												case 10:
																													goto end_IL_054e;
																												case 76:
																												case 86:
																													goto end_IL_0563;
																												case 71:
																													goto end_IL_0573;
																												case 38:
																												case 83:
																													goto end_IL_0583;
																												case 63:
																													goto end_IL_0593;
																												case 64:
																													goto end_IL_05ac;
																												case 26:
																												case 42:
																													goto IL_05c7;
																												}
																												continue;
																												end_IL_0195:
																												break;
																											}
																											break;
																										}
																										goto IL_022c;
																										IL_027a:
																										array[num5 - 2] = 0;
																										goto IL_028e;
																										IL_028e:
																										num5--;
																										goto end_IL_0221;
																										IL_022c:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_023a;
																										IL_023a:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_027a;
																									}
																									break;
																								}
																								goto IL_02eb;
																								IL_0320:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								num = 52;
																								goto IL_0397;
																								IL_02eb:
																								if (2 > b)
																								{
																									goto IL_02f6;
																								}
																								goto IL_0320;
																								IL_02f6:
																								if (1 < b)
																								{
																									break;
																								}
																								num = 48;
																								goto IL_030d;
																								IL_0397:
																								num5 -= 2;
																								goto end_IL_0221;
																								IL_030d:
																								if (1 <= b)
																								{
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_02a1;
																						IL_02d8:
																						num5--;
																						goto end_IL_0221;
																						IL_02a1:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02ca;
																						IL_02ca:
																						ptr2 += 8;
																						goto IL_02d8;
																					}
																					break;
																				}
																				goto IL_03aa;
																				IL_049d:
																				num5++;
																				goto IL_04ab;
																				IL_03aa:
																				if (6 >= b)
																				{
																					goto IL_03b5;
																				}
																				goto IL_040b;
																				IL_03b5:
																				if (6 <= b)
																				{
																					goto end_IL_0221;
																				}
																				goto IL_03c3;
																				IL_03c3:
																				if (5 < b)
																				{
																					num = 40;
																					break;
																				}
																				goto IL_03ce;
																				IL_03ce:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_03dc;
																				IL_03dc:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 24;
																				goto end_IL_0221;
																				IL_04ab:
																				ptr2 += 8;
																				goto end_IL_0221;
																				IL_040b:
																				if (7 < b)
																				{
																					goto IL_0416;
																				}
																				goto IL_044e;
																				IL_0416:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0424;
																				IL_0424:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0432;
																				IL_0432:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0221;
																				IL_044e:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0459;
																				IL_0459:
																				array[num5] = 0;
																				num = 28;
																				goto IL_0470;
																				IL_0470:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0493;
																				IL_0493:
																				array2[num5] = null;
																				goto IL_049d;
																			}
																			break;
																			IL_01e8:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04de;
																	IL_0503:
																	ptr2 += 8;
																	goto end_IL_0221;
																	IL_04ec:
																	num5++;
																	num = 11;
																	goto IL_0503;
																	IL_04de:
																	array[num5] = 0;
																	goto IL_04ec;
																	continue;
																	end_IL_01f8:
																	break;
																}
																continue;
																end_IL_0208:
																break;
															}
															continue;
															end_IL_0221:
															break;
														}
														continue;
													}
													goto IL_05c7;
													IL_05c7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0511:
													break;
												}
												continue;
												end_IL_0524:
												break;
											}
											continue;
											end_IL_052e:
											break;
										}
										continue;
										end_IL_0539:
										break;
									}
									continue;
									end_IL_054e:
									break;
								}
								continue;
								end_IL_0563:
								break;
							}
							continue;
							end_IL_0573:
							break;
						}
						continue;
						end_IL_0583:
						break;
					}
					continue;
					end_IL_0593:
					break;
				}
				continue;
				end_IL_05ac:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BrowserForwardReflectionTypeInfo.getIsFamilyOrAssemblyTrySetApartmentState);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0259:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0239:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0229:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0219:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_020c:
																										if (2 > b)
																										{
																											while (true)
																											{
																												IL_01fc:
																												if (1 < b)
																												{
																													num = 115;
																													while (num != 115)
																													{
																														if (num != 1096)
																														{
																															goto IL_044b;
																														}
																														switch (num)
																														{
																														case 76:
																														case 78:
																															goto IL_01fc;
																														case 105:
																															goto IL_020c;
																														case 29:
																														case 102:
																															goto IL_0219;
																														case 87:
																															goto IL_0229;
																														case 19:
																															goto IL_0239;
																														case 74:
																															goto IL_0249;
																														case 30:
																															goto IL_0259;
																														case 97:
																															goto end_IL_0259;
																														case 52:
																														case 99:
																															goto end_IL_0269;
																														case 55:
																															goto IL_0284;
																														case 66:
																														case 83:
																															goto IL_0297;
																														case 15:
																															goto IL_02d7;
																														case 34:
																															goto IL_02eb;
																														case 92:
																															goto IL_02fe;
																														case 4:
																															goto IL_030c;
																														case 73:
																															goto IL_031a;
																														case 77:
																														case 89:
																															goto IL_0328;
																														case 42:
																															goto IL_0368;
																														case 6:
																															goto IL_037c;
																														case 31:
																															goto IL_0398;
																														case 14:
																														case 22:
																															goto IL_03a6;
																														case 79:
																															goto IL_03cf;
																														case 46:
																															goto IL_03dd;
																														case 68:
																														case 94:
																															goto IL_03f9;
																														case 44:
																															goto IL_0410;
																														case 103:
																															goto IL_0433;
																														case 82:
																															goto IL_043d;
																														case 10:
																															goto IL_044b;
																														case 56:
																														case 61:
																															goto IL_045e;
																														case 8:
																															goto IL_046c;
																														case 27:
																															goto IL_0477;
																														case 90:
																														case 108:
																															goto IL_0485;
																														case 0:
																															goto IL_04c5;
																														case 45:
																															goto IL_04d9;
																														case 39:
																														case 91:
																															goto IL_04ec;
																														case 104:
																															goto IL_0503;
																														case 1:
																														case 106:
																															goto IL_0511;
																														case 41:
																															goto IL_052d;
																														case 47:
																														case 86:
																															goto IL_0544;
																														case 81:
																															goto IL_0552;
																														case 21:
																														case 23:
																															goto IL_0560;
																														case 5:
																															goto IL_05a0;
																														case 53:
																															goto IL_05b4;
																														case 13:
																														case 35:
																															goto IL_05c7;
																														case 80:
																															goto IL_05e9;
																														case 32:
																															goto IL_05f7;
																														case 7:
																															goto IL_0605;
																														case 2:
																														case 9:
																														case 20:
																														case 25:
																														case 26:
																														case 37:
																														case 43:
																														case 50:
																														case 51:
																														case 57:
																														case 58:
																														case 64:
																														case 65:
																														case 69:
																														case 71:
																														case 72:
																														case 75:
																														case 84:
																														case 95:
																														case 98:
																															goto end_IL_01e9;
																														case 18:
																															goto IL_0638;
																														case 88:
																															goto IL_0646;
																														case 59:
																															goto IL_0654;
																														case 11:
																														case 16:
																														case 17:
																														case 24:
																														case 28:
																														case 49:
																														case 60:
																														case 70:
																														case 85:
																														case 96:
																														case 107:
																															goto end_IL_0279;
																														case 67:
																															goto end_IL_066b;
																														case 54:
																															goto end_IL_067e;
																														case 93:
																															goto end_IL_0688;
																														case 12:
																															goto end_IL_0693;
																														case 48:
																															goto end_IL_06a8;
																														case 100:
																														case 101:
																															goto end_IL_06bd;
																														case 33:
																															goto end_IL_06cd;
																														case 3:
																														case 40:
																															goto end_IL_06dd;
																														case 62:
																															goto end_IL_06ed;
																														case 63:
																															goto end_IL_06fd;
																														case 36:
																														case 38:
																															goto IL_0718;
																														}
																														continue;
																														end_IL_01e9:
																														break;
																													}
																													break;
																												}
																												goto IL_0284;
																												IL_0284:
																												if (1 <= b)
																												{
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_0297;
																										IL_02eb:
																										num5--;
																										goto end_IL_0279;
																										IL_0297:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_02d7;
																										IL_02d7:
																										array[num5 - 2] = 0;
																										goto IL_02eb;
																									}
																									break;
																								}
																								goto IL_02fe;
																								IL_03cf:
																								ptr2 += 8;
																								goto IL_03dd;
																								IL_02fe:
																								if (3 < b)
																								{
																									goto IL_030c;
																								}
																								num = 31;
																								goto IL_0398;
																								IL_030c:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_031a;
																								IL_031a:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0328;
																								IL_0328:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0368;
																								IL_0368:
																								array[num5 - 2] = 0;
																								goto IL_037c;
																								IL_037c:
																								num5--;
																								goto end_IL_0279;
																								IL_03dd:
																								num5--;
																								num = 70;
																								goto end_IL_0279;
																								IL_0398:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_03a6;
																								IL_03a6:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03cf;
																							}
																							break;
																						}
																						goto IL_03f9;
																						IL_044b:
																						ptr2 += 8;
																						goto end_IL_0279;
																						IL_03f9:
																						array[num5] = 0;
																						num = 44;
																						goto IL_0410;
																						IL_0410:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0433;
																						IL_0433:
																						array2[num5] = null;
																						goto IL_043d;
																						IL_043d:
																						num5++;
																						goto IL_044b;
																					}
																					break;
																				}
																				goto IL_045e;
																				IL_05e9:
																				array[num5] = 0;
																				goto IL_05f7;
																				IL_045e:
																				if (7 < b)
																				{
																					goto IL_046c;
																				}
																				goto IL_052d;
																				IL_046c:
																				if (8 >= b)
																				{
																					goto IL_0477;
																				}
																				goto IL_04ec;
																				IL_0477:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0485;
																				IL_0485:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c5;
																				IL_04c5:
																				array[num5 - 2] = 0;
																				goto IL_04d9;
																				IL_04d9:
																				num5--;
																				goto end_IL_0279;
																				IL_04ec:
																				if (9 < b)
																				{
																					break;
																				}
																				num = 104;
																				goto IL_0503;
																				IL_05f7:
																				num5++;
																				goto IL_0605;
																				IL_0503:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0511;
																				IL_0511:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0279;
																				IL_052d:
																				if (7 > b)
																				{
																					num = 47;
																					goto IL_0544;
																				}
																				goto IL_05c7;
																				IL_0605:
																				ptr2 += 8;
																				goto end_IL_0279;
																				IL_0544:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0552;
																				IL_0552:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0560;
																				IL_0560:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05a0;
																				IL_05a0:
																				array[num5 - 2] = 0;
																				goto IL_05b4;
																				IL_05b4:
																				num5--;
																				goto end_IL_0279;
																				IL_05c7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 80;
																				goto IL_05e9;
																			}
																			break;
																			IL_0249:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0638;
																	IL_0654:
																	ptr2 += 8;
																	num = 107;
																	goto end_IL_0279;
																	IL_0646:
																	num5++;
																	goto IL_0654;
																	IL_0638:
																	array[num5] = 0;
																	goto IL_0646;
																	continue;
																	end_IL_0259:
																	break;
																}
																continue;
																end_IL_0269:
																break;
															}
															continue;
															end_IL_0279:
															break;
														}
														continue;
													}
													goto IL_0718;
													IL_0718:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_066b:
													break;
												}
												continue;
												end_IL_067e:
												break;
											}
											continue;
											end_IL_0688:
											break;
										}
										continue;
										end_IL_0693:
										break;
									}
									continue;
									end_IL_06a8:
									break;
								}
								continue;
								end_IL_06bd:
								break;
							}
							continue;
							end_IL_06cd:
							break;
						}
						continue;
						end_IL_06dd:
						break;
					}
					continue;
					end_IL_06ed:
					break;
				}
				continue;
				end_IL_06fd:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1)
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 89;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResumeDefineUnmanagedMarshal.GetStringArrayYield);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b7:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0297:
																			if (7 < b)
																			{
																				num = 101;
																				while (true)
																				{
																					IL_0287:
																					if (10 >= b)
																					{
																						while (true)
																						{
																							IL_0277:
																							if (10 <= b)
																							{
																								while (true)
																								{
																									IL_0258:
																									array[num5 - 2] = 0;
																									num = 138;
																									while (true)
																									{
																										if (num != 138)
																										{
																											if (num != 1119)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 31:
																											case 88:
																												goto IL_0258;
																											case 93:
																												goto IL_0277;
																											case 58:
																											case 101:
																												goto IL_0287;
																											case 57:
																												goto IL_0297;
																											case 19:
																												goto IL_02a7;
																											case 115:
																												goto IL_02b7;
																											case 38:
																												goto end_IL_02b7;
																											case 118:
																											case 124:
																												goto end_IL_02c7;
																											case 41:
																												goto IL_02e2;
																											case 40:
																												goto IL_02f0;
																											case 16:
																												goto IL_02fe;
																											case 20:
																												goto IL_030c;
																											case 54:
																												goto IL_031a;
																											case 1:
																											case 55:
																												goto IL_0336;
																											case 0:
																											case 64:
																												goto IL_0346;
																											case 4:
																											case 52:
																												goto IL_0351;
																											case 60:
																												goto IL_0364;
																											case 34:
																											case 76:
																												goto IL_0377;
																											case 90:
																												goto IL_039f;
																											case 3:
																											case 63:
																												goto IL_03aa;
																											case 15:
																												goto IL_03c1;
																											case 37:
																											case 92:
																												goto IL_03d4;
																											case 73:
																											case 96:
																												goto IL_03e7;
																											case 83:
																											case 100:
																												goto IL_03ff;
																											case 102:
																												goto IL_0424;
																											case 11:
																											case 69:
																												goto IL_043d;
																											case 47:
																												goto IL_046f;
																											case 106:
																												goto IL_0482;
																											case 35:
																												goto IL_0490;
																											case 107:
																												goto IL_04a3;
																											case 22:
																											case 104:
																												goto IL_04ae;
																											case 84:
																												goto IL_04bc;
																											case 9:
																												goto IL_04df;
																											case 17:
																												goto IL_04f2;
																											case 95:
																												goto IL_0509;
																											case 48:
																												goto IL_051c;
																											case 78:
																												goto IL_052a;
																											case 108:
																												goto IL_053d;
																											case 24:
																											case 109:
																												goto IL_054d;
																											case 8:
																												goto IL_05af;
																											case 82:
																											case 112:
																												goto IL_05c2;
																											case 53:
																												goto IL_05db;
																											case 14:
																												goto IL_05e9;
																											case 25:
																												goto IL_05f7;
																											case 50:
																											case 114:
																												goto IL_060a;
																											case 116:
																												goto IL_061d;
																											case 26:
																												goto IL_062b;
																											case 5:
																												goto IL_0642;
																											case 125:
																												goto IL_0655;
																											case 23:
																											case 36:
																												goto IL_0663;
																											case 61:
																												goto IL_06ac;
																											case 86:
																												goto IL_06c0;
																											case 46:
																											case 127:
																												goto IL_06d3;
																											case 70:
																												goto IL_06e1;
																											case 49:
																											case 72:
																												goto IL_06ef;
																											case 128:
																												goto IL_072f;
																											case 32:
																												goto IL_0743;
																											case 131:
																												goto IL_0756;
																											case 120:
																												goto IL_07c6;
																											case 130:
																												goto IL_07d4;
																											case 2:
																											case 10:
																											case 13:
																											case 18:
																											case 28:
																											case 30:
																											case 33:
																											case 39:
																											case 44:
																											case 45:
																											case 56:
																											case 59:
																											case 66:
																											case 74:
																											case 75:
																											case 81:
																											case 97:
																											case 99:
																											case 105:
																											case 110:
																											case 111:
																											case 121:
																											case 122:
																											case 126:
																												goto end_IL_0245;
																											case 12:
																											case 21:
																											case 29:
																											case 42:
																											case 43:
																											case 65:
																											case 80:
																											case 85:
																											case 87:
																											case 91:
																											case 94:
																											case 98:
																											case 103:
																											case 113:
																											case 117:
																											case 123:
																												goto end_IL_02d7;
																											case 79:
																												goto end_IL_07f7;
																											case 71:
																												goto end_IL_080a;
																											case 119:
																												goto end_IL_0814;
																											case 129:
																												goto end_IL_081f;
																											case 68:
																											case 77:
																												goto end_IL_0834;
																											case 51:
																												goto end_IL_0844;
																											case 27:
																											case 89:
																												goto end_IL_0854;
																											case 6:
																												goto end_IL_0864;
																											case 7:
																												goto end_IL_0874;
																											case 62:
																											case 67:
																												goto IL_0898;
																											}
																											continue;
																										}
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)NativeOffsetAggregateDictionary[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																										num = 120;
																										goto IL_07c6;
																										IL_07c6:
																										num5--;
																										goto IL_07d4;
																										IL_07d4:
																										ptr2 += 8;
																										goto end_IL_02d7;
																										continue;
																										end_IL_0245:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_0346;
																							IL_05af:
																							num5 -= 2;
																							goto end_IL_02d7;
																							IL_0346:
																							if (8 < b)
																							{
																								goto IL_0351;
																							}
																							goto IL_0364;
																							IL_0351:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_0655;
																							IL_0655:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0663;
																							IL_0663:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 61;
																							goto IL_06ac;
																							IL_06ac:
																							array[num5 - 2] = 0;
																							goto IL_06c0;
																							IL_06c0:
																							num5--;
																							goto end_IL_02d7;
																							IL_0364:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_054d;
																							IL_054d:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_05af;
																						}
																						break;
																					}
																					goto IL_0336;
																					IL_0482:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0490;
																					IL_0336:
																					if (12 >= b)
																					{
																						goto IL_039f;
																					}
																					goto IL_0482;
																					IL_039f:
																					if (12 > b)
																					{
																						goto IL_03aa;
																					}
																					goto IL_03ff;
																					IL_03aa:
																					if (11 < b)
																					{
																						break;
																					}
																					num = 15;
																					goto IL_03c1;
																					IL_0490:
																					if (13 <= b)
																					{
																					}
																					break;
																					IL_03c1:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_060a;
																					IL_060a:
																					num5--;
																					goto end_IL_02d7;
																					IL_03ff:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 94;
																					goto end_IL_02d7;
																				}
																				break;
																			}
																			goto IL_02e2;
																			IL_0377:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_061d;
																			IL_061d:
																			array[num5] = 0;
																			goto IL_062b;
																			IL_02e2:
																			if (7 > b)
																			{
																				goto IL_02f0;
																			}
																			goto IL_0377;
																			IL_02f0:
																			if (3 >= b)
																			{
																				goto IL_02fe;
																			}
																			goto IL_03d4;
																			IL_02fe:
																			if (3 > b)
																			{
																				goto IL_030c;
																			}
																			goto IL_03e7;
																			IL_030c:
																			if (1 < b)
																			{
																				goto IL_031a;
																			}
																			goto IL_053d;
																			IL_031a:
																			if (2 < b)
																			{
																				break;
																			}
																			num = 102;
																			goto IL_0424;
																			IL_062b:
																			num5++;
																			num = 5;
																			goto IL_0642;
																			IL_0424:
																			if (2 > b)
																			{
																				num = 110;
																				break;
																			}
																			goto IL_043d;
																			IL_0642:
																			ptr2 += 8;
																			goto end_IL_02d7;
																			IL_043d:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 47;
																			goto IL_046f;
																			IL_046f:
																			ptr2 += 8;
																			goto IL_0756;
																			IL_0756:
																			num5--;
																			goto end_IL_02d7;
																			IL_053d:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_05c2;
																			IL_05c2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_05db;
																			IL_05db:
																			array[num5] = 0;
																			goto IL_05e9;
																			IL_05e9:
																			num5++;
																			goto IL_05f7;
																			IL_05f7:
																			ptr2 += 8;
																			goto end_IL_02d7;
																			IL_03e7:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02d7;
																			IL_03d4:
																			if (5 >= b)
																			{
																				goto IL_04a3;
																			}
																			goto IL_06d3;
																			IL_06d3:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_06e1;
																			IL_06e1:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_06ef;
																			IL_06ef:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_072f;
																			IL_072f:
																			array[num5 - 2] = 0;
																			goto IL_0743;
																			IL_0743:
																			num5--;
																			goto end_IL_02d7;
																			IL_04a3:
																			if (5 <= b)
																			{
																				goto IL_04ae;
																			}
																			goto IL_051c;
																			IL_04ae:
																			array[num5] = 0;
																			goto IL_04bc;
																			IL_04bc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04df;
																			IL_04df:
																			array2[num5] = null;
																			num = 17;
																			goto IL_04f2;
																			IL_04f2:
																			num5++;
																			num = 95;
																			goto IL_0509;
																			IL_0509:
																			ptr2 += 8;
																			goto end_IL_02d7;
																			IL_051c:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_052a;
																			IL_052a:
																			if (4 <= b)
																			{
																				goto end_IL_02d7;
																			}
																			break;
																		}
																		break;
																		IL_02a7:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d7;
																continue;
																end_IL_02b7:
																break;
															}
															continue;
															end_IL_02c7:
															break;
														}
														continue;
														end_IL_02d7:
														break;
													}
													continue;
												}
												goto IL_0898;
												IL_0898:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_07f7:
												break;
											}
											continue;
											end_IL_080a:
											break;
										}
										continue;
										end_IL_0814:
										break;
									}
									continue;
									end_IL_081f:
									break;
								}
								continue;
								end_IL_0834:
								break;
							}
							continue;
							end_IL_0844:
							break;
						}
						continue;
						end_IL_0854:
						break;
					}
					continue;
					end_IL_0864:
					break;
				}
				continue;
				end_IL_0874:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 89;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BlockCopyCurrentIntoBuffer.PortableEventLevel);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0336:
															byte b = *ptr2;
															while (true)
															{
																IL_0326:
																ptr2++;
																while (true)
																{
																	IL_0316:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02f6:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02e6:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_02d3:
																								if (9 > b)
																								{
																									num = 51;
																									while (true)
																									{
																										IL_02c6:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_02a6:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0281:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_0275:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_0265:
																																num5++;
																																while (true)
																																{
																																	IL_024c:
																																	ptr2 += 8;
																																	num = 135;
																																	while (num != 135)
																																	{
																																		if (num != 1116)
																																		{
																																			goto IL_05c6;
																																		}
																																		switch (num)
																																		{
																																		case 58:
																																			goto IL_024c;
																																		case 93:
																																			goto IL_0265;
																																		case 59:
																																			goto IL_0275;
																																		case 55:
																																			goto IL_0281;
																																		case 53:
																																		case 103:
																																			goto IL_02a6;
																																		case 13:
																																			goto IL_02b6;
																																		case 51:
																																		case 74:
																																			goto IL_02c6;
																																		case 91:
																																			goto IL_02d3;
																																		case 40:
																																		case 46:
																																			goto IL_02e6;
																																		case 90:
																																			goto IL_02f6;
																																		case 16:
																																			goto IL_0306;
																																		case 115:
																																			goto IL_0316;
																																		case 108:
																																			goto IL_0326;
																																		case 30:
																																		case 94:
																																			goto IL_0336;
																																		case 4:
																																		case 24:
																																			goto IL_0341;
																																		case 17:
																																			goto IL_0358;
																																		case 21:
																																		case 36:
																																			goto IL_0368;
																																		case 20:
																																			goto IL_03a8;
																																		case 65:
																																			goto IL_03bc;
																																		case 47:
																																		case 101:
																																			goto IL_03cf;
																																		case 43:
																																			goto IL_03e8;
																																		case 48:
																																			goto IL_03f6;
																																		case 105:
																																			goto IL_0404;
																																		case 38:
																																		case 118:
																																			goto IL_0417;
																																		case 60:
																																		case 95:
																																			goto IL_0422;
																																		case 39:
																																			goto IL_0430;
																																		case 71:
																																			goto IL_0443;
																																		case 9:
																																		case 111:
																																			goto IL_044e;
																																		case 3:
																																			goto IL_0461;
																																		case 34:
																																			goto IL_046f;
																																		case 62:
																																		case 78:
																																			goto IL_047d;
																																		case 82:
																																			goto IL_0491;
																																		case 35:
																																			goto IL_04e5;
																																		case 61:
																																			goto IL_04f3;
																																		case 76:
																																		case 122:
																																			goto IL_0506;
																																		case 14:
																																			goto IL_0522;
																																		case 77:
																																			goto IL_0530;
																																		case 79:
																																		case 117:
																																			goto IL_053e;
																																		case 32:
																																			goto IL_0549;
																																		case 64:
																																		case 98:
																																			goto IL_0557;
																																		case 109:
																																			goto IL_0580;
																																		case 114:
																																			goto IL_0597;
																																		case 112:
																																			goto IL_05aa;
																																		case 5:
																																			goto IL_05b8;
																																		case 0:
																																		case 92:
																																			goto IL_05c6;
																																		case 29:
																																			goto IL_05de;
																																		case 28:
																																		case 106:
																																			goto IL_05e9;
																																		case 52:
																																			goto IL_0629;
																																		case 88:
																																			goto IL_063d;
																																		case 57:
																																			goto IL_0650;
																																		case 2:
																																			goto IL_065b;
																																		case 6:
																																		case 107:
																																			goto IL_0677;
																																		case 120:
																																			goto IL_0685;
																																		case 96:
																																		case 121:
																																			goto IL_0693;
																																		case 18:
																																			goto IL_0701;
																																		case 1:
																																		case 7:
																																		case 8:
																																		case 10:
																																		case 11:
																																		case 12:
																																		case 22:
																																		case 26:
																																		case 33:
																																		case 37:
																																		case 42:
																																		case 50:
																																		case 54:
																																		case 56:
																																		case 68:
																																		case 75:
																																		case 80:
																																		case 87:
																																		case 99:
																																		case 104:
																																		case 116:
																																		case 119:
																																		case 125:
																																		case 126:
																																		case 127:
																																			goto end_IL_02b6;
																																		case 97:
																																			goto IL_0746;
																																		case 73:
																																			goto IL_0754;
																																		case 66:
																																			goto IL_0762;
																																		case 15:
																																		case 19:
																																		case 23:
																																		case 25:
																																		case 31:
																																		case 44:
																																		case 49:
																																		case 69:
																																		case 70:
																																		case 83:
																																		case 84:
																																		case 113:
																																		case 123:
																																		case 128:
																																			goto end_IL_0239;
																																		case 72:
																																			goto end_IL_0770;
																																		case 63:
																																			goto end_IL_0783;
																																		case 41:
																																			goto end_IL_078d;
																																		case 45:
																																			goto end_IL_0798;
																																		case 102:
																																			goto end_IL_07ad;
																																		case 27:
																																		case 81:
																																			goto end_IL_07c2;
																																		case 89:
																																			goto end_IL_07d2;
																																		case 100:
																																		case 110:
																																			goto end_IL_07e2;
																																		case 85:
																																			goto end_IL_07f2;
																																		case 86:
																																			goto end_IL_080b;
																																		case 67:
																																		case 124:
																																			goto IL_0826;
																																		}
																																		continue;
																																		end_IL_0239:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_0316;
																												continue;
																												end_IL_02b6:
																												break;
																												IL_02b6:;
																											}
																											break;
																										}
																										goto IL_0341;
																										IL_03f6:
																										num5++;
																										goto IL_0404;
																										IL_0341:
																										if (8 < b)
																										{
																											break;
																										}
																										num = 17;
																										goto IL_0358;
																										IL_0404:
																										ptr2 += 8;
																										goto end_IL_0316;
																										IL_0358:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_03cf;
																										IL_03cf:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_03e8;
																										IL_03e8:
																										array[num5] = 0;
																										goto IL_03f6;
																									}
																									break;
																								}
																								goto IL_0368;
																								IL_03a8:
																								array[num5 - 2] = 0;
																								goto IL_03bc;
																								IL_03bc:
																								num5--;
																								goto end_IL_0316;
																								IL_0368:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03a8;
																							}
																							break;
																						}
																						goto IL_0417;
																						IL_04f3:
																						ptr2 += 8;
																						goto end_IL_0316;
																						IL_0417:
																						if (11 < b)
																						{
																							goto IL_0422;
																						}
																						goto IL_0443;
																						IL_0422:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0430;
																						IL_0430:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_0506;
																						IL_0506:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0316;
																						IL_0443:
																						if (11 <= b)
																						{
																							goto IL_044e;
																						}
																						goto IL_0461;
																						IL_044e:
																						num5--;
																						goto end_IL_0316;
																						IL_0461:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_046f;
																						IL_046f:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_047d;
																						IL_047d:
																						array[num5 - 2] = 0;
																						goto IL_0491;
																						IL_0491:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)FoundEndOfHebrewNumberA[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_04e5;
																						IL_04e5:
																						num5--;
																						goto IL_04f3;
																					}
																					break;
																				}
																				goto IL_0522;
																				IL_0693:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0701;
																				IL_0522:
																				if (6 <= b)
																				{
																					goto end_IL_0316;
																				}
																				goto IL_0530;
																				IL_0530:
																				if (3 < b)
																				{
																					goto IL_053e;
																				}
																				goto IL_05de;
																				IL_053e:
																				if (4 >= b)
																				{
																					goto IL_0549;
																				}
																				goto IL_05aa;
																				IL_0549:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0557;
																				IL_0557:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0580;
																				IL_0580:
																				ptr2 += 8;
																				num = 114;
																				goto IL_0597;
																				IL_0597:
																				num5--;
																				goto end_IL_0316;
																				IL_05aa:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_05b8;
																				IL_05b8:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_05c6;
																				IL_05c6:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0316;
																				IL_05de:
																				if (3 <= b)
																				{
																					goto IL_05e9;
																				}
																				goto IL_0650;
																				IL_05e9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0629;
																				IL_0629:
																				array[num5 - 2] = 0;
																				goto IL_063d;
																				IL_063d:
																				num5--;
																				goto end_IL_0316;
																				IL_0650:
																				if (1 >= b)
																				{
																					goto IL_065b;
																				}
																				num = 107;
																				goto IL_0677;
																				IL_065b:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0701:
																				num5 -= 2;
																				num = 23;
																				goto end_IL_0316;
																				IL_0677:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0685;
																				IL_0685:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0693;
																			}
																			break;
																			IL_0306:;
																		}
																	}
																	else
																	{
																		num = 127;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0746;
																	IL_0754:
																	num5++;
																	goto IL_0762;
																	IL_0762:
																	ptr2 += 8;
																	break;
																	IL_0746:
																	array[num5] = 0;
																	goto IL_0754;
																	continue;
																	end_IL_0316:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0826;
													IL_0826:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0770:
													break;
												}
												continue;
												end_IL_0783:
												break;
											}
											continue;
											end_IL_078d:
											break;
										}
										continue;
										end_IL_0798:
										break;
									}
									continue;
									end_IL_07ad:
									break;
								}
								continue;
								end_IL_07c2:
								break;
							}
							continue;
							end_IL_07d2:
							break;
						}
						continue;
						end_IL_07e2:
						break;
					}
					continue;
					end_IL_07f2:
					break;
				}
				continue;
				end_IL_080b:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 3;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setSecurityZonegetXsdType.MembergetTarget);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_023e:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0221:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0211:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0201:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_01f1:
																									if (6 >= b)
																									{
																										num = 96;
																										while (6 <= b)
																										{
																											num = 104;
																											while (true)
																											{
																												if (num != 104)
																												{
																													if (num != 1085)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 96:
																														goto IL_01de;
																													case 64:
																														goto IL_01f1;
																													case 19:
																														goto IL_0201;
																													case 87:
																														goto IL_0211;
																													case 90:
																														goto IL_0221;
																													case 53:
																														goto IL_022e;
																													case 88:
																														goto IL_023e;
																													case 51:
																														goto end_IL_023e;
																													case 63:
																													case 79:
																														goto end_IL_024e;
																													case 48:
																														goto IL_0269;
																													case 18:
																														goto IL_0277;
																													case 5:
																													case 21:
																														goto IL_0285;
																													case 67:
																														goto IL_02ad;
																													case 12:
																													case 13:
																														goto IL_02bb;
																													case 72:
																														goto IL_02c9;
																													case 22:
																													case 75:
																														goto IL_02fa;
																													case 39:
																														goto IL_0308;
																													case 15:
																													case 24:
																														goto IL_0316;
																													case 77:
																														goto IL_0332;
																													case 44:
																														goto IL_0340;
																													case 14:
																													case 78:
																														goto IL_0353;
																													case 47:
																														goto IL_03b5;
																													case 70:
																													case 80:
																														goto IL_03c8;
																													case 68:
																														goto end_IL_01cb;
																													case 92:
																														goto IL_03e9;
																													case 93:
																														goto IL_03fc;
																													case 17:
																														goto IL_0406;
																													case 74:
																														goto IL_0414;
																													case 41:
																													case 97:
																														goto IL_0427;
																													case 9:
																														goto IL_0435;
																													case 65:
																													case 95:
																														goto IL_0440;
																													case 42:
																														goto IL_0469;
																													case 32:
																														goto IL_0477;
																													case 11:
																														goto IL_048a;
																													case 23:
																														goto IL_0498;
																													case 76:
																													case 86:
																														goto IL_04a6;
																													case 81:
																														goto IL_04bf;
																													case 8:
																														goto IL_04cd;
																													case 61:
																														goto IL_04e4;
																													case 94:
																														goto IL_04f7;
																													case 6:
																													case 20:
																														goto IL_0502;
																													case 16:
																														goto IL_0510;
																													case 60:
																														goto IL_0523;
																													case 45:
																													case 71:
																														goto IL_0531;
																													case 29:
																														goto IL_0549;
																													case 46:
																														goto IL_0592;
																													case 91:
																														goto IL_05a6;
																													case 4:
																													case 25:
																													case 28:
																													case 30:
																													case 37:
																													case 38:
																													case 40:
																													case 43:
																													case 54:
																													case 57:
																													case 58:
																													case 83:
																													case 85:
																														goto end_IL_01de;
																													case 0:
																													case 1:
																													case 7:
																													case 33:
																													case 34:
																													case 36:
																													case 49:
																													case 52:
																													case 55:
																													case 59:
																													case 62:
																													case 82:
																													case 84:
																														goto end_IL_025e;
																													case 10:
																														goto end_IL_05c9;
																													case 69:
																														goto end_IL_05dc;
																													case 26:
																														goto end_IL_05e6;
																													case 35:
																														goto end_IL_05f1;
																													case 56:
																													case 66:
																														goto end_IL_0606;
																													case 50:
																														goto end_IL_0616;
																													case 73:
																													case 89:
																														goto end_IL_0626;
																													case 2:
																														goto end_IL_0636;
																													case 3:
																														goto end_IL_0646;
																													case 27:
																													case 31:
																														goto IL_0661;
																													}
																													continue;
																												}
																												goto IL_0549;
																												IL_0592:
																												array[num5 - 2] = 0;
																												goto IL_05a6;
																												IL_05a6:
																												num5--;
																												goto end_IL_025e;
																												IL_0549:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 46;
																												goto IL_0592;
																												continue;
																												end_IL_01cb:
																												break;
																											}
																											goto IL_03d6;
																											continue;
																											end_IL_01de:
																											break;
																											IL_01de:;
																										}
																										break;
																									}
																									goto IL_0269;
																									IL_0340:
																									num5++;
																									goto IL_03e9;
																									IL_03e9:
																									ptr2 += 8;
																									goto end_IL_025e;
																									IL_0269:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_0277;
																									IL_0277:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0285;
																									IL_0285:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0332;
																									IL_0332:
																									array[num5] = 0;
																									goto IL_0340;
																								}
																								break;
																							}
																							goto IL_0353;
																							IL_03b5:
																							num5 -= 2;
																							goto end_IL_025e;
																							IL_0353:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03b5;
																						}
																						break;
																					}
																					goto IL_02fa;
																					IL_03d6:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_02fa:
																					if (9 >= b)
																					{
																						goto IL_0308;
																					}
																					goto IL_03c8;
																					IL_0308:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0316;
																					IL_0316:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_025e;
																					IL_03c8:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_03d6;
																				}
																				break;
																			}
																			goto IL_02ad;
																			IL_0531:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_025e;
																			IL_02ad:
																			if (5 <= b)
																			{
																				goto IL_02bb;
																			}
																			goto IL_0427;
																			IL_02bb:
																			array[num5] = 0;
																			goto IL_02c9;
																			IL_02c9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 93;
																			goto IL_03fc;
																			IL_03fc:
																			array2[num5] = null;
																			goto IL_0406;
																			IL_0406:
																			num5++;
																			goto IL_0414;
																			IL_0414:
																			ptr2 += 8;
																			goto end_IL_025e;
																			IL_0427:
																			if (2 >= b)
																			{
																				goto IL_0435;
																			}
																			goto IL_04f7;
																			IL_0435:
																			if (2 <= b)
																			{
																				goto IL_0440;
																			}
																			goto IL_048a;
																			IL_0440:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0469;
																			IL_0469:
																			ptr2 += 8;
																			goto IL_0477;
																			IL_0477:
																			num5--;
																			goto end_IL_025e;
																			IL_048a:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0498;
																			IL_0498:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04a6;
																			IL_04a6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04bf;
																			IL_04bf:
																			array[num5] = 0;
																			goto IL_04cd;
																			IL_04cd:
																			num5++;
																			num = 61;
																			goto IL_04e4;
																			IL_04e4:
																			ptr2 += 8;
																			goto end_IL_025e;
																			IL_04f7:
																			if (3 < b)
																			{
																				goto IL_0502;
																			}
																			goto IL_0523;
																			IL_0502:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0510;
																			IL_0510:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_025e;
																			IL_0523:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0531;
																		}
																		break;
																		IL_022e:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_025e;
																continue;
																end_IL_023e:
																break;
															}
															continue;
															end_IL_024e:
															break;
														}
														continue;
														end_IL_025e:
														break;
													}
													continue;
												}
												goto IL_0661;
												IL_0661:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05c9:
												break;
											}
											continue;
											end_IL_05dc:
											break;
										}
										continue;
										end_IL_05e6:
										break;
									}
									continue;
									end_IL_05f1:
									break;
								}
								continue;
								end_IL_0606:
								break;
							}
							continue;
							end_IL_0616:
							break;
						}
						continue;
						end_IL_0626:
						break;
					}
					continue;
					end_IL_0636:
					break;
				}
				continue;
				end_IL_0646:
				break;
			}
		}
	}

	static Class145()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num == 12 || num != 993)
						{
							return;
						}
						switch (num)
						{
						case 0:
						case 2:
							goto end_IL_0039;
						case 3:
							goto end_IL_0046;
						case 4:
							goto end_IL_0055;
						case 1:
							return;
						case 5:
							return;
						}
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_0055:
				break;
			}
		}
	}
}
