using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 30)]
internal struct bufferSizeNoArgs
{
	internal static bufferSizeNoArgs WindowsRuntimeImportAttributegetRandomlyGenerated/* Not supported: data(01 00 00 00 00 00 00 00 00 02 FF FF FF FC FC FF FF FF 02 00 00 00 02 02 00 00 00 03 04 05) */;
}
