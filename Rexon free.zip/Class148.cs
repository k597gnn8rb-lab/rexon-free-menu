using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Interface;
using UnityEngine;

[Mod("Anti Report Distance", "Safety", "Triggers (VR) / Click (PC) to adjust.", false, 2, ModType.const_0, false)]
internal class Class148 : MonoBehaviour
{
	private float float_0;

	private float float_1;

	private static double double_0;

	private static float float_2;

	private static int int_0;

	private static float float_3;

	private static bool bool_0;

	private static float float_4;

	private static IntPtr[] getTreatControlCAsInputGetFieldFromHandle;

	private static IntPtr[] LookForMyCallerLargeObjectHeapCompactionMode;

	private static IntPtr[] IsVirtualPinnedBufferMemoryStream;

	private static IntPtr[] UTFEncodingActivationServices;

	private static IntPtr[] NumPadResourceReader;

	private static IntPtr[] OpcodeIsFromThisAppDomain;

	private static float MdConstantgetTimeSeparator(Class148 class148_1)
	{
		return class148_1.float_0;
	}

	private static void DXNDSImpersonated(string string_0)
	{
		BundleManager.smethod_49(string_0);
	}

	public Class148()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static float getUseStdAsciiRulesgetRemovable(float float_5, float float_6, float float_7)
	{
		return Mathf.Clamp(float_5, float_6, float_7);
	}

	private static double DayOfWeekTokentailHigh(double double_1)
	{
		return Math.Log(double_1);
	}

	private static float PMOpCode(float float_5)
	{
		return Mathf.Abs(float_5);
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ICustomDebuggerNotificationPublic.BrfalseEnumPrivateFiles);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0365:
														byte b = *ptr2;
														while (true)
														{
															IL_0355:
															ptr2++;
															while (true)
															{
																IL_0345:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_0328:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_0318:
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_0308:
																							if (11 <= b)
																							{
																								while (true)
																								{
																									IL_02f2:
																									array[num5 - 2] = 0;
																									while (true)
																									{
																										IL_0293:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)NumPadResourceReader[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																										num = 56;
																										while (true)
																										{
																											IL_0283:
																											num5--;
																											while (true)
																											{
																												IL_026a:
																												ptr2 += 8;
																												num = 146;
																												while (num != 146)
																												{
																													if (num != 1127)
																													{
																														goto IL_057e;
																													}
																													switch (num)
																													{
																													case 38:
																														goto IL_026a;
																													case 56:
																														goto IL_0283;
																													case 28:
																														goto IL_0293;
																													case 81:
																													case 101:
																														goto IL_02f2;
																													case 79:
																														goto IL_0308;
																													case 93:
																													case 122:
																														goto IL_0318;
																													case 16:
																														goto IL_0328;
																													case 55:
																														goto IL_0335;
																													case 76:
																														goto IL_0345;
																													case 91:
																														goto IL_0355;
																													case 23:
																													case 125:
																														goto IL_0365;
																													case 49:
																														goto IL_0370;
																													case 40:
																													case 65:
																														goto IL_037e;
																													case 62:
																														goto IL_03be;
																													case 64:
																													case 87:
																														goto IL_03d4;
																													case 77:
																														goto IL_03df;
																													case 19:
																														goto IL_03f2;
																													case 75:
																														goto IL_0400;
																													case 92:
																														goto IL_0413;
																													case 109:
																														goto IL_0426;
																													case 103:
																														goto IL_0431;
																													case 10:
																														goto IL_043f;
																													case 89:
																														goto IL_044d;
																													case 34:
																														goto IL_045d;
																													case 24:
																													case 82:
																														goto IL_0468;
																													case 84:
																														goto IL_047b;
																													case 88:
																													case 102:
																														goto IL_0489;
																													case 8:
																														goto IL_0497;
																													case 86:
																													case 111:
																														goto IL_04aa;
																													case 69:
																														goto IL_04cc;
																													case 112:
																														goto IL_04df;
																													case 44:
																													case 115:
																														goto IL_04fb;
																													case 114:
																														goto IL_055d;
																													case 117:
																														goto IL_0570;
																													case 1:
																														goto IL_057e;
																													case 72:
																													case 119:
																														goto IL_0591;
																													case 29:
																													case 121:
																														goto IL_05d6;
																													case 95:
																														goto IL_05e4;
																													case 96:
																														goto IL_0607;
																													case 12:
																														goto IL_0611;
																													case 25:
																														goto IL_061f;
																													case 124:
																														goto IL_0632;
																													case 17:
																													case 31:
																														goto IL_063d;
																													case 116:
																													case 126:
																														goto IL_0690;
																													case 127:
																														goto IL_06a8;
																													case 14:
																														goto IL_06bc;
																													case 128:
																														goto IL_06cf;
																													case 85:
																													case 107:
																														goto IL_06dd;
																													case 71:
																														goto IL_0700;
																													case 4:
																														goto IL_070e;
																													case 59:
																														goto IL_071c;
																													case 60:
																													case 135:
																														goto IL_072f;
																													case 48:
																														goto IL_073d;
																													case 2:
																													case 50:
																														goto IL_074b;
																													case 105:
																														goto IL_0774;
																													case 129:
																														goto IL_0782;
																													case 139:
																														goto IL_079e;
																													case 94:
																														goto IL_07b2;
																													case 37:
																														goto IL_07c5;
																													case 7:
																													case 22:
																														goto IL_07d0;
																													case 70:
																														goto IL_07e4;
																													case 113:
																														goto IL_07f1;
																													case 120:
																														goto IL_07fc;
																													case 18:
																														goto IL_0807;
																													case 53:
																													case 130:
																														goto IL_0812;
																													case 45:
																													case 123:
																														goto IL_0822;
																													case 6:
																													case 13:
																													case 26:
																													case 27:
																													case 30:
																													case 33:
																													case 35:
																													case 43:
																													case 46:
																													case 51:
																													case 52:
																													case 61:
																													case 63:
																													case 68:
																													case 73:
																													case 78:
																													case 80:
																													case 83:
																													case 100:
																													case 104:
																													case 106:
																													case 118:
																													case 132:
																													case 134:
																													case 136:
																													case 138:
																														goto end_IL_0335;
																													case 0:
																													case 3:
																													case 11:
																													case 15:
																													case 20:
																													case 21:
																													case 39:
																													case 41:
																													case 54:
																													case 67:
																													case 97:
																													case 108:
																													case 110:
																													case 131:
																													case 133:
																													case 137:
																														goto end_IL_0257;
																													case 36:
																														goto end_IL_084e;
																													case 47:
																														goto end_IL_0861;
																													case 58:
																														goto end_IL_086b;
																													case 32:
																														goto end_IL_0876;
																													case 42:
																													case 66:
																														goto end_IL_088b;
																													case 90:
																														goto end_IL_089b;
																													case 5:
																													case 74:
																														goto end_IL_08ab;
																													case 98:
																														goto end_IL_08bb;
																													case 99:
																														goto end_IL_08cb;
																													case 9:
																													case 57:
																														goto IL_08e6;
																													}
																													continue;
																													end_IL_0257:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_03d4;
																							IL_06a8:
																							array[num5 - 2] = 0;
																							goto IL_06bc;
																							IL_03d4:
																							if (9 >= b)
																							{
																								goto IL_03df;
																							}
																							goto IL_03f2;
																							IL_03df:
																							if (9 > b)
																							{
																								goto IL_04df;
																							}
																							goto IL_04fb;
																							IL_04fb:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_055d;
																							IL_055d:
																							num5 -= 2;
																							break;
																							IL_04df:
																							if (8 < b)
																							{
																								num = 63;
																								goto end_IL_0335;
																							}
																							goto IL_06cf;
																							IL_06bc:
																							num5--;
																							break;
																							IL_06cf:
																							if (8 > b)
																							{
																								goto end_IL_0335;
																							}
																							goto IL_06dd;
																							IL_06dd:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0700;
																							IL_0700:
																							array[num5] = 0;
																							goto IL_070e;
																							IL_070e:
																							num5++;
																							goto IL_071c;
																							IL_071c:
																							ptr2 += 8;
																							break;
																							IL_03f2:
																							if (10 < b)
																							{
																								goto end_IL_0335;
																							}
																							goto IL_0400;
																							IL_0400:
																							if (10 > b)
																							{
																								goto end_IL_0335;
																							}
																							goto IL_0591;
																							IL_0591:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_06a8;
																						}
																						break;
																					}
																					goto IL_07c5;
																					IL_0812:
																					num5--;
																					break;
																					IL_07c5:
																					if (13 < b)
																					{
																						goto IL_07d0;
																					}
																					goto IL_07f1;
																					IL_07d0:
																					if (14 < b)
																					{
																						goto end_IL_0335;
																					}
																					num = 70;
																					goto IL_07e4;
																					IL_0822:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_07e4:
																					if (14 <= b)
																					{
																					}
																					goto end_IL_0335;
																					IL_07f1:
																					if (13 > b)
																					{
																						goto IL_07fc;
																					}
																					goto IL_0822;
																					IL_07fc:
																					if (12 < b)
																					{
																						goto end_IL_0335;
																					}
																					goto IL_0807;
																					IL_0807:
																					if (12 > b)
																					{
																						goto end_IL_0335;
																					}
																					goto IL_0812;
																				}
																				break;
																			}
																			goto IL_0370;
																			IL_0611:
																			num5++;
																			goto IL_061f;
																			IL_0370:
																			if (7 <= b)
																			{
																				goto IL_037e;
																			}
																			goto IL_0426;
																			IL_037e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03be;
																			IL_03be:
																			array[num5 - 2] = 0;
																			goto IL_0413;
																			IL_0413:
																			num5--;
																			break;
																			IL_0426:
																			if (3 >= b)
																			{
																				goto IL_0431;
																			}
																			goto IL_045d;
																			IL_0431:
																			if (3 > b)
																			{
																				goto IL_043f;
																			}
																			goto IL_0690;
																			IL_043f:
																			if (1 >= b)
																			{
																				goto IL_044d;
																			}
																			goto IL_072f;
																			IL_044d:
																			if (1 > b)
																			{
																				goto end_IL_0335;
																			}
																			goto IL_04aa;
																			IL_04aa:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 69;
																			goto IL_04cc;
																			IL_04cc:
																			array[num5] = 0;
																			goto IL_0570;
																			IL_0570:
																			num5++;
																			goto IL_057e;
																			IL_057e:
																			ptr2 += 8;
																			break;
																			IL_072f:
																			if (2 < b)
																			{
																				goto end_IL_0335;
																			}
																			goto IL_073d;
																			IL_073d:
																			if (2 > b)
																			{
																				goto end_IL_0335;
																			}
																			goto IL_074b;
																			IL_074b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0774;
																			IL_0774:
																			ptr2 += 8;
																			goto IL_0782;
																			IL_0782:
																			num5--;
																			num = 54;
																			break;
																			IL_0690:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_045d:
																			if (5 < b)
																			{
																				goto IL_0468;
																			}
																			goto IL_047b;
																			IL_0468:
																			if (6 < b)
																			{
																				goto end_IL_0335;
																			}
																			goto IL_0632;
																			IL_0632:
																			if (6 > b)
																			{
																				num = 43;
																				goto end_IL_0335;
																			}
																			goto IL_063d;
																			IL_063d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_079e;
																			IL_079e:
																			array[num5 - 2] = 0;
																			goto IL_07b2;
																			IL_07b2:
																			num5--;
																			break;
																			IL_061f:
																			ptr2 += 8;
																			break;
																			IL_047b:
																			if (5 > b)
																			{
																				goto IL_0489;
																			}
																			goto IL_05d6;
																			IL_0489:
																			if (4 < b)
																			{
																				goto end_IL_0335;
																			}
																			goto IL_0497;
																			IL_0497:
																			if (4 > b)
																			{
																				goto end_IL_0335;
																			}
																			break;
																			IL_05d6:
																			array[num5] = 0;
																			goto IL_05e4;
																			IL_05e4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0607;
																			IL_0607:
																			array2[num5] = null;
																			goto IL_0611;
																		}
																		goto end_IL_0345;
																		continue;
																		end_IL_0335:
																		break;
																		IL_0335:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0345:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_08e6;
												IL_08e6:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_084e:
												break;
											}
											continue;
											end_IL_0861:
											break;
										}
										continue;
										end_IL_086b:
										break;
									}
									continue;
									end_IL_0876:
									break;
								}
								continue;
								end_IL_088b:
								break;
							}
							continue;
							end_IL_089b:
							break;
						}
						continue;
						end_IL_08ab:
						break;
					}
					continue;
					end_IL_08bb:
					break;
				}
				continue;
				end_IL_08cb:
				break;
			}
		}
	}

	private static string IClientFormatterSinkMembershipCondition(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 53;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 6;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MaxCharCountGetMethodImplementationFlags.GetPrimesetNamespace);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															IL_02b8:
															ptr2++;
															while (true)
															{
																IL_02a8:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0288:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_0278:
																					if (10 >= b)
																					{
																						while (true)
																						{
																							IL_0268:
																							if (10 > b)
																							{
																								while (true)
																								{
																									IL_0258:
																									if (8 < b)
																									{
																										num = 138;
																										while (true)
																										{
																											if (num != 138)
																											{
																												if (num != 1119)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 72:
																													goto IL_0258;
																												case 86:
																													goto IL_0268;
																												case 55:
																												case 71:
																													goto IL_0278;
																												case 44:
																													goto IL_0288;
																												case 29:
																													goto IL_0298;
																												case 5:
																													goto IL_02a8;
																												case 128:
																													goto IL_02b8;
																												case 4:
																												case 81:
																													goto end_IL_0245;
																												case 84:
																													goto IL_02d3;
																												case 32:
																												case 108:
																													goto IL_02e1;
																												case 105:
																													goto IL_0304;
																												case 106:
																													goto IL_0312;
																												case 50:
																													goto IL_0329;
																												case 83:
																												case 120:
																													goto IL_033c;
																												case 99:
																													goto IL_034a;
																												case 93:
																													goto IL_036e;
																												case 54:
																													goto IL_037c;
																												case 116:
																													goto IL_0398;
																												case 73:
																													goto IL_03a6;
																												case 22:
																												case 36:
																													goto IL_03b4;
																												case 130:
																													goto IL_0416;
																												case 76:
																													goto IL_0437;
																												case 78:
																													goto IL_0442;
																												case 7:
																												case 21:
																													goto IL_044d;
																												case 26:
																													goto IL_0469;
																												case 115:
																													goto IL_0477;
																												case 43:
																												case 127:
																													goto IL_0485;
																												case 35:
																												case 103:
																													goto IL_04a1;
																												case 68:
																													goto IL_04af;
																												case 123:
																													goto IL_04c2;
																												case 95:
																													goto IL_04d0;
																												case 14:
																												case 92:
																													goto IL_04de;
																												case 2:
																													goto IL_04ec;
																												case 23:
																												case 110:
																													goto IL_04f7;
																												case 67:
																													goto IL_0505;
																												case 39:
																												case 51:
																													goto IL_0518;
																												case 41:
																													goto IL_0526;
																												case 66:
																													goto IL_0549;
																												case 121:
																													goto IL_0553;
																												case 62:
																													goto IL_0561;
																												case 15:
																													goto IL_0574;
																												case 1:
																													goto IL_0582;
																												case 101:
																												case 112:
																													goto IL_0590;
																												case 31:
																													goto IL_05d0;
																												case 109:
																													goto IL_05e4;
																												case 42:
																													goto IL_05f7;
																												case 11:
																												case 25:
																													goto IL_0602;
																												case 3:
																													goto IL_061a;
																												case 13:
																												case 46:
																													goto IL_0625;
																												case 126:
																													goto IL_0633;
																												case 45:
																												case 111:
																													goto IL_0641;
																												case 118:
																													goto IL_066a;
																												case 24:
																													goto IL_0678;
																												case 102:
																													goto IL_068b;
																												case 94:
																												case 129:
																													goto IL_0699;
																												case 28:
																													goto IL_06b2;
																												case 77:
																													goto IL_06c0;
																												case 33:
																													goto IL_06ce;
																												case 98:
																												case 131:
																													goto IL_06de;
																												case 8:
																													goto IL_071e;
																												case 63:
																													goto IL_0732;
																												case 0:
																												case 9:
																												case 12:
																												case 16:
																												case 20:
																												case 30:
																												case 34:
																												case 37:
																												case 47:
																												case 49:
																												case 56:
																												case 61:
																												case 64:
																												case 69:
																												case 74:
																												case 85:
																												case 87:
																												case 88:
																												case 89:
																												case 96:
																												case 97:
																												case 113:
																												case 122:
																												case 124:
																												case 125:
																													goto end_IL_0298;
																												case 10:
																												case 19:
																												case 27:
																												case 38:
																												case 40:
																												case 48:
																												case 57:
																												case 58:
																												case 60:
																												case 65:
																												case 79:
																												case 80:
																												case 82:
																												case 104:
																												case 114:
																												case 119:
																													goto end_IL_02c8;
																												case 100:
																													goto end_IL_0755;
																												case 117:
																													goto end_IL_0768;
																												case 70:
																													goto end_IL_0772;
																												case 75:
																													goto end_IL_077d;
																												case 6:
																												case 91:
																													goto end_IL_0792;
																												case 59:
																													goto end_IL_07a2;
																												case 90:
																												case 107:
																													goto end_IL_07b2;
																												case 52:
																													goto end_IL_07cb;
																												case 53:
																													goto end_IL_07db;
																												case 17:
																												case 18:
																													goto IL_07f6;
																												}
																												continue;
																											}
																											goto IL_0398;
																											IL_03b4:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0416;
																											IL_0416:
																											num5 -= 2;
																											goto end_IL_02c8;
																											IL_0398:
																											if (9 < b)
																											{
																												num = 12;
																												goto end_IL_0298;
																											}
																											goto IL_03a6;
																											IL_03a6:
																											if (9 > b)
																											{
																												goto end_IL_0298;
																											}
																											goto IL_03b4;
																											continue;
																											end_IL_0245:
																											break;
																										}
																										break;
																									}
																									goto IL_02d3;
																									IL_0312:
																									num5++;
																									num = 50;
																									goto IL_0329;
																									IL_0329:
																									ptr2 += 8;
																									goto end_IL_02c8;
																									IL_02d3:
																									if (8 > b)
																									{
																										goto end_IL_0298;
																									}
																									goto IL_02e1;
																									IL_02e1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0304;
																									IL_0304:
																									array[num5] = 0;
																									goto IL_0312;
																								}
																								break;
																							}
																							goto IL_033c;
																							IL_037c:
																							ptr2 += 8;
																							num = 19;
																							goto end_IL_02c8;
																							IL_033c:
																							array[num5] = 0;
																							goto IL_034a;
																							IL_034a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)UTFEncodingActivationServices[*(int*)(ptr2 + num3)])();
																							goto IL_036e;
																							IL_036e:
																							num5++;
																							goto IL_037c;
																						}
																						break;
																					}
																					goto IL_0437;
																					IL_04a1:
																					if (13 < b)
																					{
																						goto end_IL_0298;
																					}
																					goto IL_04af;
																					IL_0437:
																					if (12 >= b)
																					{
																						goto IL_0442;
																					}
																					num = 103;
																					goto IL_04a1;
																					IL_0442:
																					if (12 <= b)
																					{
																						goto IL_044d;
																					}
																					goto IL_0469;
																					IL_044d:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02c8;
																					IL_0469:
																					if (11 < b)
																					{
																						goto end_IL_0298;
																					}
																					goto IL_0477;
																					IL_0477:
																					if (11 > b)
																					{
																						goto end_IL_0298;
																					}
																					goto IL_0485;
																					IL_0485:
																					num5--;
																					goto end_IL_02c8;
																					IL_04af:
																					if (13 > b)
																					{
																					}
																					goto end_IL_0298;
																				}
																				break;
																			}
																			goto IL_04c2;
																			IL_0732:
																			num5--;
																			goto end_IL_02c8;
																			IL_04c2:
																			if (7 > b)
																			{
																				goto IL_04d0;
																			}
																			goto IL_06de;
																			IL_04d0:
																			if (3 < b)
																			{
																				goto IL_04de;
																			}
																			goto IL_05f7;
																			IL_04de:
																			if (5 >= b)
																			{
																				goto IL_04ec;
																			}
																			goto IL_0574;
																			IL_04ec:
																			if (5 > b)
																			{
																				goto IL_04f7;
																			}
																			goto IL_0518;
																			IL_04f7:
																			if (4 < b)
																			{
																				goto end_IL_0298;
																			}
																			goto IL_0505;
																			IL_0505:
																			if (4 <= b)
																			{
																				goto end_IL_02c8;
																			}
																			goto end_IL_0298;
																			IL_0518:
																			array[num5] = 0;
																			goto IL_0526;
																			IL_0526:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0549;
																			IL_0549:
																			array2[num5] = null;
																			goto IL_0553;
																			IL_0553:
																			num5++;
																			goto IL_0561;
																			IL_0561:
																			ptr2 += 8;
																			goto end_IL_02c8;
																			IL_0574:
																			if (6 < b)
																			{
																				goto end_IL_0298;
																			}
																			goto IL_0582;
																			IL_0582:
																			if (6 > b)
																			{
																				goto end_IL_0298;
																			}
																			goto IL_0590;
																			IL_0590:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05d0;
																			IL_05d0:
																			array[num5 - 2] = 0;
																			goto IL_05e4;
																			IL_05e4:
																			num5--;
																			goto end_IL_02c8;
																			IL_05f7:
																			if (3 <= b)
																			{
																				goto IL_0602;
																			}
																			goto IL_061a;
																			IL_0602:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02c8;
																			IL_061a:
																			if (1 < b)
																			{
																				goto IL_0625;
																			}
																			goto IL_068b;
																			IL_0625:
																			if (2 < b)
																			{
																				goto end_IL_0298;
																			}
																			goto IL_0633;
																			IL_0633:
																			if (2 > b)
																			{
																				goto end_IL_0298;
																			}
																			goto IL_0641;
																			IL_0641:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_066a;
																			IL_066a:
																			ptr2 += 8;
																			goto IL_0678;
																			IL_0678:
																			num5--;
																			goto end_IL_02c8;
																			IL_068b:
																			if (1 > b)
																			{
																				goto end_IL_0298;
																			}
																			goto IL_0699;
																			IL_0699:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_06b2;
																			IL_06b2:
																			array[num5] = 0;
																			goto IL_06c0;
																			IL_06c0:
																			num5++;
																			goto IL_06ce;
																			IL_06ce:
																			ptr2 += 8;
																			goto end_IL_02c8;
																			IL_06de:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_071e;
																			IL_071e:
																			array[num5 - 2] = 0;
																			goto IL_0732;
																		}
																		goto end_IL_02a8;
																		continue;
																		end_IL_0298:
																		break;
																		IL_0298:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02c8;
																continue;
																end_IL_02a8:
																break;
															}
															break;
														}
														continue;
														end_IL_02c8:
														break;
													}
													continue;
												}
												goto IL_07f6;
												IL_07f6:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0755:
												break;
											}
											continue;
											end_IL_0768:
											break;
										}
										continue;
										end_IL_0772:
										break;
									}
									continue;
									end_IL_077d:
									break;
								}
								continue;
								end_IL_0792:
								break;
							}
							continue;
							end_IL_07a2:
							break;
						}
						continue;
						end_IL_07b2:
						break;
					}
					continue;
					end_IL_07cb:
					break;
				}
				continue;
				end_IL_07db:
				break;
			}
		}
	}

	private static float DefaultThreadCurrentCultureCustomAttributes()
	{
		return global::_003CModule_003E.float_106;
	}

	private unsafe void OnDisable()
	{
		//The blocks IL_000e, IL_001e, IL_0373, IL_0386, IL_03a5, IL_03b5, IL_03c5, IL_03d2, IL_03e2, IL_03ef, IL_03ff, IL_040f, IL_041f, IL_042f, IL_043f, IL_044a, IL_045d, IL_046b, IL_04ab, IL_04bf, IL_04d2, IL_04dd, IL_051d, IL_0531, IL_0544, IL_0552, IL_0560, IL_056e, IL_0581, IL_058f, IL_059a, IL_05c3, IL_05d1, IL_05e4, IL_05ef, IL_05fd, IL_0610, IL_0619, IL_062c, IL_0637, IL_0645, IL_0653, IL_0676, IL_0680, IL_068e, IL_06a1, IL_06af, IL_06bd, IL_06fd, IL_0713, IL_0753, IL_0767, IL_077a, IL_078d, IL_079b, IL_07a4, IL_07e4, IL_07f8, IL_080b, IL_086d, IL_0880, IL_08d4, IL_08e2, IL_08f5, IL_0903, IL_0911, IL_091f, IL_092d, IL_093b, IL_0949, IL_0966, IL_09b5, IL_09bf, IL_09ec, IL_0a00, IL_0a0e, IL_0a21, IL_0a2f, IL_0a3d, IL_0a5b, IL_0a69, IL_0a7c, IL_0aa5, IL_0abe, IL_0ac9, IL_0ad7, IL_0ae5, IL_0af3, IL_0b0b, IL_0b19, IL_0b2c, IL_0b3a, IL_0b52, IL_0b70, IL_0b94, IL_0bac, IL_0bbf, IL_0bfd, IL_0c10, IL_0c1e, IL_0c29, IL_0c52, IL_0c6b, IL_0c76, IL_0c84, IL_0c98, IL_0cd0, IL_0ce3, IL_0cf1, IL_0cff, IL_0d23, IL_0d31, IL_0d3f, IL_0d52, IL_0d60, IL_0d6b, IL_0d94, IL_0da2, IL_0db5, IL_0dc3, IL_0dd1, IL_0dee, IL_0e35, IL_0e43, IL_0e53, IL_0e5e, IL_0e69, IL_0e82, IL_0e9b, IL_0ea9, IL_0eb7, IL_0ec5, IL_0ed8, IL_0ee2, IL_0eed, IL_0efd, IL_0f16, IL_0f26, IL_0f36, IL_0f46, IL_0f56, IL_0f66 are reachable both inside and outside the pinned region starting at IL_0f7b. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 102;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef62 = default(int);
			ref int reference = ref __rxRef62;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0f66:
					num2 = 1;
					while (true)
					{
						IL_0f56:
						num3 = num2 * 4;
						while (true)
						{
							IL_0f46:
							array2 = new byte[4];
							while (true)
							{
								IL_0f36:
								array3 = new object[4];
								while (true)
								{
									IL_0f26:
									array4 = new int[4];
									while (true)
									{
										IL_0f16:
										array5 = new int[6];
										while (true)
										{
											IL_0efd:
											array6 = new long[4];
											num = 131;
											while (true)
											{
												IL_0eed:
												array7 = new object[21];
												while (true)
												{
													IL_0ee2:
													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddChildCharArrayTypeInfo.InternalMemberTypeESubKeyCount);
													while (true)
													{
														IL_0ed8:
														ptr2 = ptr;
														while (true)
														{
															if (num4 == 1)
															{
																return;
															}
															while (true)
															{
																IL_043f:
																byte b = *ptr2;
																while (true)
																{
																	IL_042f:
																	ptr2++;
																	while (true)
																	{
																		IL_041f:
																		if (b >= 1)
																		{
																			while (b <= 24)
																			{
																				while (true)
																				{
																					IL_03ff:
																					if (12 >= b)
																					{
																						while (12 > b)
																						{
																							while (true)
																							{
																								IL_03e2:
																								if (6 < b)
																								{
																									while (true)
																									{
																										IL_03d2:
																										if (9 < b)
																										{
																											while (true)
																											{
																												IL_03c5:
																												if (10 < b)
																												{
																													while (11 >= b)
																													{
																														while (11 <= b)
																														{
																															while (true)
																															{
																																IL_0386:
																																array2[num5 - 2] = 0;
																																num = 217;
																																while (true)
																																{
																																	if (num != 217)
																																	{
																																		if (num != 1198)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 102:
																																			break;
																																		default:
																																			continue;
																																		case 1:
																																		case 42:
																																			goto IL_0386;
																																		case 43:
																																			goto IL_03a5;
																																		case 156:
																																			goto IL_03b5;
																																		case 13:
																																			goto IL_03c5;
																																		case 192:
																																			goto IL_03d2;
																																		case 177:
																																			goto IL_03e2;
																																		case 168:
																																			goto IL_03ef;
																																		case 170:
																																			goto IL_03ff;
																																		case 19:
																																			goto IL_040f;
																																		case 146:
																																			goto IL_041f;
																																		case 162:
																																			goto IL_042f;
																																		case 182:
																																		case 194:
																																			goto IL_043f;
																																		case 39:
																																			goto IL_044a;
																																		case 41:
																																			goto IL_045d;
																																		case 68:
																																		case 87:
																																			goto IL_046b;
																																		case 66:
																																			goto IL_04ab;
																																		case 99:
																																			goto IL_04bf;
																																		case 145:
																																			goto IL_04d2;
																																		case 26:
																																		case 75:
																																			goto IL_04dd;
																																		case 138:
																																			goto IL_051d;
																																		case 23:
																																			goto IL_0531;
																																		case 127:
																																			goto IL_0544;
																																		case 52:
																																			goto IL_0552;
																																		case 141:
																																			goto IL_0560;
																																		case 40:
																																		case 126:
																																			goto IL_056e;
																																		case 202:
																																			goto IL_0581;
																																		case 176:
																																			goto IL_058f;
																																		case 140:
																																		case 197:
																																			goto IL_059a;
																																		case 5:
																																			goto IL_05c3;
																																		case 161:
																																			goto IL_05d1;
																																		case 15:
																																			goto IL_05e4;
																																		case 88:
																																			goto IL_05ef;
																																		case 137:
																																			goto IL_05fd;
																																		case 173:
																																			goto IL_0619;
																																		case 78:
																																			goto IL_062c;
																																		case 129:
																																			goto IL_0637;
																																		case 31:
																																		case 108:
																																			goto IL_0645;
																																		case 72:
																																			goto IL_0653;
																																		case 34:
																																			goto IL_0676;
																																		case 111:
																																			goto IL_0680;
																																		case 50:
																																			goto IL_068e;
																																		case 91:
																																			goto IL_06a1;
																																		case 180:
																																			goto IL_06af;
																																		case 28:
																																		case 92:
																																			goto IL_06bd;
																																		case 171:
																																			goto IL_06fd;
																																		case 118:
																																		case 203:
																																			goto IL_0713;
																																		case 165:
																																			goto IL_0753;
																																		case 16:
																																			goto IL_0767;
																																		case 205:
																																			goto IL_077a;
																																		case 207:
																																			goto IL_078d;
																																		case 21:
																																		case 63:
																																			goto IL_07a4;
																																		case 29:
																																			goto IL_07e4;
																																		case 153:
																																			goto IL_07f8;
																																		case 49:
																																		case 209:
																																			goto IL_080b;
																																		case 152:
																																			goto IL_086d;
																																		case 193:
																																			goto IL_08d4;
																																		case 30:
																																			goto IL_08e2;
																																		case 47:
																																			goto IL_08f5;
																																		case 73:
																																			goto IL_0903;
																																		case 59:
																																			goto IL_0911;
																																		case 155:
																																			goto IL_091f;
																																		case 90:
																																			goto IL_092d;
																																		case 188:
																																			goto IL_093b;
																																		case 142:
																																		case 154:
																																			goto IL_0949;
																																		case 122:
																																			goto IL_0a00;
																																		case 58:
																																			goto IL_0a0e;
																																		case 175:
																																			goto IL_0a21;
																																		case 139:
																																			goto IL_0a2f;
																																		case 148:
																																		case 160:
																																			goto IL_0a3d;
																																		case 74:
																																			goto IL_0a5b;
																																		case 10:
																																			goto IL_0a69;
																																		case 136:
																																		case 149:
																																			goto end_IL_0373;
																																		case 64:
																																			goto IL_0aa5;
																																		case 2:
																																			goto IL_0abe;
																																		case 169:
																																			goto IL_0ac9;
																																		case 89:
																																			goto IL_0ad7;
																																		case 104:
																																		case 120:
																																			goto IL_0ae5;
																																		case 172:
																																			goto IL_0af3;
																																		case 132:
																																			goto IL_0b0b;
																																		case 116:
																																			goto IL_0b19;
																																		case 93:
																																			goto IL_0b2c;
																																		case 70:
																																		case 187:
																																			goto IL_0b3a;
																																		case 121:
																																			goto IL_0b52;
																																		case 96:
																																			goto IL_0b70;
																																		case 106:
																																			goto IL_0b94;
																																		case 164:
																																			goto IL_0bac;
																																		case 133:
																																		case 196:
																																			goto IL_0bbf;
																																		case 45:
																																			goto IL_0bfd;
																																		case 167:
																																			goto IL_0c10;
																																		case 125:
																																			goto IL_0c1e;
																																		case 38:
																																		case 98:
																																			goto IL_0c29;
																																		case 107:
																																			goto IL_0c52;
																																		case 147:
																																			goto IL_0c6b;
																																		case 191:
																																			goto IL_0c76;
																																		case 24:
																																		case 157:
																																			goto IL_0c84;
																																		case 95:
																																			goto IL_0c98;
																																		case 190:
																																			goto IL_0cd0;
																																		case 109:
																																			goto IL_0ce3;
																																		case 181:
																																			goto IL_0cf1;
																																		case 57:
																																		case 119:
																																			goto IL_0cff;
																																		case 115:
																																			goto IL_0d23;
																																		case 6:
																																			goto IL_0d31;
																																		case 55:
																																			goto IL_0d3f;
																																		case 158:
																																			goto IL_0d52;
																																		case 48:
																																			goto IL_0d60;
																																		case 61:
																																		case 184:
																																			goto IL_0d6b;
																																		case 81:
																																			goto IL_0d94;
																																		case 46:
																																			goto IL_0da2;
																																		case 134:
																																			goto IL_0db5;
																																		case 56:
																																			goto IL_0dc3;
																																		case 62:
																																		case 82:
																																			goto IL_0dd1;
																																		case 117:
																																			goto IL_0dee;
																																		case 79:
																																			goto IL_0e35;
																																		case 110:
																																			goto IL_0e43;
																																		case 124:
																																			goto IL_0e53;
																																		case 8:
																																			goto IL_0e5e;
																																		case 143:
																																		case 151:
																																			goto IL_0e69;
																																		case 7:
																																		case 12:
																																		case 17:
																																		case 20:
																																		case 35:
																																		case 37:
																																		case 44:
																																		case 51:
																																		case 65:
																																		case 84:
																																		case 85:
																																		case 86:
																																		case 105:
																																		case 112:
																																		case 113:
																																		case 128:
																																		case 159:
																																		case 163:
																																		case 174:
																																		case 178:
																																		case 189:
																																		case 195:
																																		case 199:
																																		case 200:
																																		case 201:
																																		case 204:
																																		case 208:
																																			goto end_IL_03a5;
																																		case 186:
																																			goto IL_0e9b;
																																		case 123:
																																			goto IL_0ea9;
																																		case 0:
																																			goto IL_0eb7;
																																		case 3:
																																		case 4:
																																		case 9:
																																		case 11:
																																		case 22:
																																		case 25:
																																		case 27:
																																		case 32:
																																		case 36:
																																		case 53:
																																		case 54:
																																		case 60:
																																		case 71:
																																		case 76:
																																		case 77:
																																		case 80:
																																		case 83:
																																		case 94:
																																		case 97:
																																		case 114:
																																		case 130:
																																		case 144:
																																		case 150:
																																		case 166:
																																		case 179:
																																		case 183:
																																		case 210:
																																			goto end_IL_03ef;
																																		case 18:
																																			goto IL_0ed8;
																																		case 198:
																																			goto IL_0ee2;
																																		case 131:
																																			goto IL_0eed;
																																		case 185:
																																			goto IL_0efd;
																																		case 14:
																																			goto IL_0f16;
																																		case 103:
																																			goto IL_0f26;
																																		case 100:
																																			goto IL_0f36;
																																		case 69:
																																		case 135:
																																			goto IL_0f46;
																																		case 67:
																																			goto IL_0f56;
																																		case 101:
																																			goto IL_0f66;
																																		case 33:
																																		case 206:
																																			return;
																																		}
																																		goto end_IL_0ec5;
																																	}
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																																	goto IL_08d4;
																																	IL_08d4:
																																	num5--;
																																	goto IL_08e2;
																																	IL_08e2:
																																	ptr2 += 8;
																																	goto end_IL_03ef;
																																	continue;
																																	end_IL_0373:
																																	break;
																																}
																																break;
																															}
																															goto IL_0a7c;
																															continue;
																															end_IL_03a5:
																															break;
																															IL_03a5:;
																														}
																														break;
																														IL_03b5:;
																													}
																													break;
																												}
																												goto IL_044a;
																												IL_086d:
																												num5 -= 2;
																												goto end_IL_03ef;
																												IL_044a:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_080b;
																												IL_080b:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_086d;
																											}
																											break;
																										}
																										goto IL_04d2;
																										IL_07e4:
																										array2[num5 - 2] = 0;
																										goto IL_07f8;
																										IL_04d2:
																										if (9 <= b)
																										{
																											goto IL_04dd;
																										}
																										goto IL_0544;
																										IL_04dd:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_051d;
																										IL_051d:
																										array2[num5 - 2] = 0;
																										goto IL_0531;
																										IL_0531:
																										num5--;
																										goto end_IL_03ef;
																										IL_0544:
																										if (7 < b)
																										{
																											goto IL_0552;
																										}
																										goto IL_078d;
																										IL_0552:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_0560;
																										IL_0560:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_056e;
																										IL_056e:
																										num5--;
																										goto end_IL_03ef;
																										IL_078d:
																										if (7 > b)
																										{
																											break;
																										}
																										num = 21;
																										goto IL_07a4;
																										IL_07f8:
																										num5--;
																										goto end_IL_03ef;
																										IL_07a4:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_07e4;
																									}
																									break;
																								}
																								goto IL_045d;
																								IL_06fd:
																								array2[num5 - 2] = 0;
																								goto IL_077a;
																								IL_045d:
																								if (6 <= b)
																								{
																									goto IL_046b;
																								}
																								goto IL_0581;
																								IL_046b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_04ab;
																								IL_04ab:
																								array2[num5 - 2] = 0;
																								goto IL_04bf;
																								IL_04bf:
																								num5--;
																								goto end_IL_03ef;
																								IL_0581:
																								if (3 >= b)
																								{
																									goto IL_058f;
																								}
																								goto IL_062c;
																								IL_058f:
																								if (3 <= b)
																								{
																									goto IL_059a;
																								}
																								goto IL_05e4;
																								IL_059a:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_05c3;
																								IL_05c3:
																								ptr2 += 8;
																								goto IL_05d1;
																								IL_05d1:
																								num5--;
																								goto end_IL_03ef;
																								IL_05e4:
																								if (1 < b)
																								{
																									goto IL_05ef;
																								}
																								num = 173;
																								goto IL_0619;
																								IL_05ef:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_05fd;
																								IL_05fd:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_0713;
																								IL_0713:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_0753;
																								IL_0753:
																								array2[num5 - 2] = 0;
																								goto IL_0767;
																								IL_0767:
																								num5--;
																								goto end_IL_03ef;
																								IL_077a:
																								num5--;
																								goto end_IL_03ef;
																								IL_0619:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_062c:
																								if (4 >= b)
																								{
																									goto IL_0637;
																								}
																								goto IL_06a1;
																								IL_0637:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0645;
																								IL_0645:
																								array2[num5] = 0;
																								goto IL_0653;
																								IL_0653:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0676;
																								IL_0676:
																								array3[num5] = null;
																								goto IL_0680;
																								IL_0680:
																								num5++;
																								goto IL_068e;
																								IL_068e:
																								ptr2 += 8;
																								goto end_IL_03ef;
																								IL_06a1:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_06af;
																								IL_06af:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_06bd;
																								IL_06bd:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_06fd;
																							}
																							goto end_IL_040f;
																							continue;
																							end_IL_03ef:
																							break;
																							IL_03ef:;
																						}
																						break;
																					}
																					goto IL_08f5;
																					IL_0e43:
																					ptr2 += 8;
																					break;
																					IL_08f5:
																					if (18 >= b)
																					{
																						goto IL_0903;
																					}
																					goto IL_0c10;
																					IL_0903:
																					if (18 > b)
																					{
																						goto IL_0911;
																					}
																					goto IL_0bbf;
																					IL_0911:
																					if (15 >= b)
																					{
																						goto IL_091f;
																					}
																					goto IL_0abe;
																					IL_091f:
																					if (15 > b)
																					{
																						goto IL_092d;
																					}
																					goto IL_0a7c;
																					IL_092d:
																					if (13 >= b)
																					{
																						goto IL_093b;
																					}
																					goto IL_0a21;
																					IL_093b:
																					if (13 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0949;
																					IL_0949:
																					array8 = array3;
																					num6 = num5;
																					if (array == null)
																					{
																						goto IL_0958;
																					}
																					num7 = ptr2;
																					byte b2 = *num7;
																					ptr2 = num7 + 4;
																					int num8 = *(int*)(ptr2 + num3);
																					ptr2 += 8;
																					byte* ptr3 = ptr2 + num8;
																					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																					while (ptr2 != ptr3)
																					{
																						*ptr4 = (byte)(*ptr2 ^ b2);
																						ptr2++;
																						ptr4++;
																					}
																					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																					goto IL_0a00;
																					IL_0e53:
																					if (24 < b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0e5e;
																					IL_0e5e:
																					if (24 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0e69;
																					IL_0e69:
																					num9 = ptr2;
																					num10 = -200;
																					num4 = 1;
																					ptr2 = num9 + num10;
																					break;
																					IL_0a00:
																					array2[num5] = 5;
																					goto IL_0a0e;
																					IL_0a0e:
																					num5++;
																					break;
																					IL_0a21:
																					if (14 < b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0a2f;
																					IL_0a2f:
																					if (14 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0a3d;
																					IL_0a3d:
																					array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																					goto IL_0a5b;
																					IL_0a5b:
																					ptr2 += 8;
																					goto IL_0a69;
																					IL_0a69:
																					num5--;
																					break;
																					IL_0a7c:
																					array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																					goto IL_0aa5;
																					IL_0aa5:
																					array2[num5 - 1] = 5;
																					break;
																					IL_0abe:
																					if (16 < b)
																					{
																						goto IL_0ac9;
																					}
																					goto IL_0b2c;
																					IL_0ac9:
																					if (17 < b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0ad7;
																					IL_0ad7:
																					if (17 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0ae5;
																					IL_0ae5:
																					array2[num5] = 5;
																					goto IL_0af3;
																					IL_0af3:
																					array3[num5] = array7[*(int*)(ptr2 + num3)];
																					goto IL_0b0b;
																					IL_0b0b:
																					num5++;
																					goto IL_0b19;
																					IL_0b19:
																					ptr2 += 8;
																					break;
																					IL_0b2c:
																					if (16 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0b3a;
																					IL_0b3a:
																					array2[num5] = array2[num5 - 1];
																					goto IL_0b52;
																					IL_0b52:
																					array4[num5 - 0] = array4[num5 - 1];
																					goto IL_0b70;
																					IL_0b70:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_0b94;
																					IL_0b94:
																					array3[num5] = array3[num5 - 1];
																					goto IL_0bac;
																					IL_0bac:
																					num5++;
																					break;
																					IL_0bbf:
																					((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																					goto IL_0bfd;
																					IL_0bfd:
																					num5 -= 3;
																					break;
																					IL_0c10:
																					if (21 >= b)
																					{
																						goto IL_0c1e;
																					}
																					goto IL_0d52;
																					IL_0c1e:
																					if (21 <= b)
																					{
																						goto IL_0c29;
																					}
																					goto IL_0c6b;
																					IL_0c29:
																					array3[num5 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																					goto IL_0c52;
																					IL_0c52:
																					array2[num5 - 1] = 5;
																					break;
																					IL_0c6b:
																					if (19 >= b)
																					{
																						goto IL_0c76;
																					}
																					goto IL_0ce3;
																					IL_0c76:
																					if (19 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0c84;
																					IL_0c84:
																					array2[num5 - 1] = 5;
																					goto IL_0c98;
																					IL_0c98:
																					array3[num5 - 1] = ((delegate*<string[], string>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																					goto IL_0cd0;
																					IL_0cd0:
																					ptr2 += 8;
																					break;
																					IL_0ce3:
																					if (20 < b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0cf1;
																					IL_0cf1:
																					if (20 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0cff;
																					IL_0cff:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<float>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])();
																					goto IL_0d23;
																					IL_0d23:
																					array2[num5] = 3;
																					goto IL_0d31;
																					IL_0d31:
																					num5++;
																					goto IL_0d3f;
																					IL_0d3f:
																					ptr2 += 8;
																					break;
																					IL_0d52:
																					if (23 >= b)
																					{
																						goto IL_0d60;
																					}
																					goto IL_0e53;
																					IL_0d60:
																					if (23 <= b)
																					{
																						goto IL_0d6b;
																					}
																					goto IL_0db5;
																					IL_0d6b:
																					((delegate*<string, void>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																					goto IL_0d94;
																					IL_0d94:
																					num5--;
																					goto IL_0da2;
																					IL_0da2:
																					ptr2 += 8;
																					break;
																					IL_0db5:
																					if (22 < b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0dc3;
																					IL_0dc3:
																					if (22 > b)
																					{
																						goto end_IL_040f;
																					}
																					goto IL_0dd1;
																					IL_0dd1:
																					array2[num5 - 2] = 5;
																					num = 117;
																					goto IL_0dee;
																					IL_0dee:
																					array3[num5 - 2] = ((delegate*<string, object, string>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
																					goto IL_0e35;
																					IL_0e35:
																					num5--;
																					goto IL_0e43;
																				}
																				goto end_IL_041f;
																				continue;
																				end_IL_040f:
																				break;
																				IL_040f:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																		goto IL_0e9b;
																		IL_0eb7:
																		ptr2 += 8;
																		break;
																		IL_0ea9:
																		num5++;
																		goto IL_0eb7;
																		IL_0e9b:
																		array2[num5] = 0;
																		goto IL_0ea9;
																		continue;
																		end_IL_041f:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
															end_IL_0ec5:
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0958:
			while (true)
			{
				IL_0958_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0a00_2:
						array2[num5] = 5;
						while (true)
						{
							IL_0a0e_2:
							num5++;
							while (true)
							{
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									IL_043f_2:
									byte b = *ptr2;
									while (true)
									{
										IL_042f_2:
										ptr2++;
										while (true)
										{
											IL_041f_2:
											if (b >= 1)
											{
												while (b <= 24)
												{
													while (true)
													{
														IL_03ff_2:
														if (12 >= b)
														{
															while (12 > b)
															{
																while (true)
																{
																	IL_03e2_2:
																	if (6 < b)
																	{
																		while (true)
																		{
																			IL_03d2_2:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_03c5_2:
																					if (10 < b)
																					{
																						while (11 >= b)
																						{
																							while (11 <= b)
																							{
																								while (true)
																								{
																									IL_0386_2:
																									array2[num5 - 2] = 0;
																									num = 217;
																									while (true)
																									{
																										if (num != 217)
																										{
																											if (num != 1198)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 1:
																											case 42:
																												goto IL_0386_2;
																											case 43:
																												goto IL_03a5_2;
																											case 156:
																												goto IL_03b5_2;
																											case 13:
																												goto IL_03c5_2;
																											case 192:
																												goto IL_03d2_2;
																											case 177:
																												goto IL_03e2_2;
																											case 168:
																												goto IL_03ef_2;
																											case 170:
																												goto IL_03ff_2;
																											case 19:
																												goto IL_040f_2;
																											case 146:
																												goto IL_041f_2;
																											case 162:
																												goto IL_042f_2;
																											case 182:
																											case 194:
																												goto IL_043f_2;
																											case 39:
																												goto IL_044a_2;
																											case 41:
																												goto IL_045d_2;
																											case 68:
																											case 87:
																												goto IL_046b_2;
																											case 66:
																												goto IL_04ab_2;
																											case 99:
																												goto IL_04bf_2;
																											case 145:
																												goto IL_04d2_2;
																											case 26:
																											case 75:
																												goto IL_04dd_2;
																											case 138:
																												goto IL_051d_2;
																											case 23:
																												goto IL_0531_2;
																											case 127:
																												goto IL_0544_2;
																											case 52:
																												goto IL_0552_2;
																											case 141:
																												goto IL_0560_2;
																											case 40:
																											case 126:
																												goto IL_056e_2;
																											case 202:
																												goto IL_0581_2;
																											case 176:
																												goto IL_058f_2;
																											case 140:
																											case 197:
																												goto IL_059a_2;
																											case 5:
																												goto IL_05c3_2;
																											case 161:
																												goto IL_05d1_2;
																											case 15:
																												goto IL_05e4_2;
																											case 88:
																												goto IL_05ef_2;
																											case 137:
																												goto IL_05fd_2;
																											case 173:
																												goto IL_0619_2;
																											case 78:
																												goto IL_062c_2;
																											case 129:
																												goto IL_0637_2;
																											case 31:
																											case 108:
																												goto IL_0645_2;
																											case 72:
																												goto IL_0653_2;
																											case 34:
																												goto IL_0676_2;
																											case 111:
																												goto IL_0680_2;
																											case 50:
																												goto IL_068e_2;
																											case 91:
																												goto IL_06a1_2;
																											case 180:
																												goto IL_06af_2;
																											case 28:
																											case 92:
																												goto IL_06bd_2;
																											case 171:
																												goto IL_06fd_2;
																											case 118:
																											case 203:
																												goto IL_0713_2;
																											case 165:
																												goto IL_0753_2;
																											case 16:
																												goto IL_0767_2;
																											case 205:
																												goto IL_077a_2;
																											case 207:
																												goto IL_078d_2;
																											case 21:
																											case 63:
																												goto IL_07a4_2;
																											case 29:
																												goto IL_07e4_2;
																											case 153:
																												goto IL_07f8_2;
																											case 49:
																											case 209:
																												goto IL_080b_2;
																											case 152:
																												goto IL_086d_2;
																											case 193:
																												goto IL_08d4_2;
																											case 30:
																												goto IL_08e2_2;
																											case 47:
																												goto IL_08f5_2;
																											case 73:
																												goto IL_0903_2;
																											case 59:
																												goto IL_0911_2;
																											case 155:
																												goto IL_091f_2;
																											case 90:
																												goto IL_092d_2;
																											case 188:
																												goto IL_093b_2;
																											case 142:
																											case 154:
																												goto end_IL_0ec5_2;
																											case 122:
																												goto IL_0a00_2;
																											case 58:
																												goto IL_0a0e_2;
																											case 175:
																												goto IL_0a21_2;
																											case 139:
																												goto IL_0a2f_2;
																											case 148:
																											case 160:
																												goto IL_0a3d_2;
																											case 74:
																												goto IL_0a5b_2;
																											case 10:
																												goto IL_0a69_2;
																											case 136:
																											case 149:
																												goto end_IL_0373_2;
																											case 64:
																												goto IL_0aa5_2;
																											case 2:
																												goto IL_0abe_2;
																											case 169:
																												goto IL_0ac9_2;
																											case 89:
																												goto IL_0ad7_2;
																											case 104:
																											case 120:
																												goto IL_0ae5_2;
																											case 172:
																												goto IL_0af3_2;
																											case 132:
																												goto IL_0b0b_2;
																											case 116:
																												goto IL_0b19_2;
																											case 93:
																												goto IL_0b2c_2;
																											case 70:
																											case 187:
																												goto IL_0b3a_2;
																											case 121:
																												goto IL_0b52_2;
																											case 96:
																												goto IL_0b70_2;
																											case 106:
																												goto IL_0b94_2;
																											case 164:
																												goto IL_0bac_2;
																											case 133:
																											case 196:
																												goto IL_0bbf_2;
																											case 45:
																												goto IL_0bfd_2;
																											case 167:
																												goto IL_0c10_2;
																											case 125:
																												goto IL_0c1e_2;
																											case 38:
																											case 98:
																												goto IL_0c29_2;
																											case 107:
																												goto IL_0c52_2;
																											case 147:
																												goto IL_0c6b_2;
																											case 191:
																												goto IL_0c76_2;
																											case 24:
																											case 157:
																												goto IL_0c84_2;
																											case 95:
																												goto IL_0c98_2;
																											case 190:
																												goto IL_0cd0_2;
																											case 109:
																												goto IL_0ce3_2;
																											case 181:
																												goto IL_0cf1_2;
																											case 57:
																											case 119:
																												goto IL_0cff_2;
																											case 115:
																												goto IL_0d23_2;
																											case 6:
																												goto IL_0d31_2;
																											case 55:
																												goto IL_0d3f_2;
																											case 158:
																												goto IL_0d52_2;
																											case 48:
																												goto IL_0d60_2;
																											case 61:
																											case 184:
																												goto IL_0d6b_2;
																											case 81:
																												goto IL_0d94_2;
																											case 46:
																												goto IL_0da2_2;
																											case 134:
																												goto IL_0db5_2;
																											case 56:
																												goto IL_0dc3_2;
																											case 62:
																											case 82:
																												goto IL_0dd1_2;
																											case 117:
																												goto IL_0dee_2;
																											case 79:
																												goto IL_0e35_2;
																											case 110:
																												goto IL_0e43_2;
																											case 124:
																												goto IL_0e53_2;
																											case 8:
																												goto IL_0e5e_2;
																											case 143:
																											case 151:
																												goto IL_0e69_2;
																											case 7:
																											case 12:
																											case 17:
																											case 20:
																											case 35:
																											case 37:
																											case 44:
																											case 51:
																											case 65:
																											case 84:
																											case 85:
																											case 86:
																											case 105:
																											case 112:
																											case 113:
																											case 128:
																											case 159:
																											case 163:
																											case 174:
																											case 178:
																											case 189:
																											case 195:
																											case 199:
																											case 200:
																											case 201:
																											case 204:
																											case 208:
																												goto end_IL_03a5_2;
																											case 186:
																												goto IL_0e9b_2;
																											case 123:
																												goto IL_0ea9_2;
																											case 0:
																												goto IL_0eb7_2;
																											case 3:
																											case 4:
																											case 9:
																											case 11:
																											case 22:
																											case 25:
																											case 27:
																											case 32:
																											case 36:
																											case 53:
																											case 54:
																											case 60:
																											case 71:
																											case 76:
																											case 77:
																											case 80:
																											case 83:
																											case 94:
																											case 97:
																											case 114:
																											case 130:
																											case 144:
																											case 150:
																											case 166:
																											case 179:
																											case 183:
																											case 210:
																												goto end_IL_03ef_2;
																											case 18:
																												ptr2 = ptr;
																												goto end_IL_03ef_2;
																											case 198:
																												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddChildCharArrayTypeInfo.InternalMemberTypeESubKeyCount);
																												goto case 18;
																											case 131:
																												array7 = new object[21];
																												goto case 198;
																											case 185:
																												array6 = new long[4];
																												num = 131;
																												goto case 131;
																											case 14:
																												array5 = new int[6];
																												goto case 185;
																											case 103:
																												array4 = new int[4];
																												goto case 14;
																											case 100:
																												array3 = new object[4];
																												goto case 103;
																											case 69:
																											case 135:
																												array2 = new byte[4];
																												goto case 100;
																											case 67:
																												num3 = num2 * 4;
																												goto case 69;
																											case 101:
																												num2 = 1;
																												goto case 67;
																											case 102:
																												goto end_IL_0966;
																											case 33:
																											case 206:
																												return;
																											}
																											continue;
																										}
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																										goto IL_08d4_2;
																										IL_08d4_2:
																										num5--;
																										goto IL_08e2_2;
																										IL_08e2_2:
																										ptr2 += 8;
																										goto end_IL_03ef_2;
																										continue;
																										end_IL_0373_2:
																										break;
																									}
																									break;
																								}
																								goto IL_0a7c_2;
																								continue;
																								end_IL_03a5_2:
																								break;
																								IL_03a5_2:;
																							}
																							break;
																							IL_03b5_2:;
																						}
																						break;
																					}
																					goto IL_044a_2;
																					IL_086d_2:
																					num5 -= 2;
																					goto end_IL_03ef_2;
																					IL_044a_2:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_080b_2;
																					IL_080b_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_086d_2;
																				}
																				break;
																			}
																			goto IL_04d2_2;
																			IL_07e4_2:
																			array2[num5 - 2] = 0;
																			goto IL_07f8_2;
																			IL_04d2_2:
																			if (9 <= b)
																			{
																				goto IL_04dd_2;
																			}
																			goto IL_0544_2;
																			IL_04dd_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_051d_2;
																			IL_051d_2:
																			array2[num5 - 2] = 0;
																			goto IL_0531_2;
																			IL_0531_2:
																			num5--;
																			goto end_IL_03ef_2;
																			IL_0544_2:
																			if (7 < b)
																			{
																				goto IL_0552_2;
																			}
																			goto IL_078d_2;
																			IL_0552_2:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0560_2;
																			IL_0560_2:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_056e_2;
																			IL_056e_2:
																			num5--;
																			goto end_IL_03ef_2;
																			IL_078d_2:
																			if (7 > b)
																			{
																				break;
																			}
																			num = 21;
																			goto IL_07a4_2;
																			IL_07f8_2:
																			num5--;
																			goto end_IL_03ef_2;
																			IL_07a4_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_07e4_2;
																		}
																		break;
																	}
																	goto IL_045d_2;
																	IL_06fd_2:
																	array2[num5 - 2] = 0;
																	goto IL_077a_2;
																	IL_045d_2:
																	if (6 <= b)
																	{
																		goto IL_046b_2;
																	}
																	goto IL_0581_2;
																	IL_046b_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_04ab_2;
																	IL_04ab_2:
																	array2[num5 - 2] = 0;
																	goto IL_04bf_2;
																	IL_04bf_2:
																	num5--;
																	goto end_IL_03ef_2;
																	IL_0581_2:
																	if (3 >= b)
																	{
																		goto IL_058f_2;
																	}
																	goto IL_062c_2;
																	IL_058f_2:
																	if (3 <= b)
																	{
																		goto IL_059a_2;
																	}
																	goto IL_05e4_2;
																	IL_059a_2:
																	reference = ref array5[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_05c3_2;
																	IL_05c3_2:
																	ptr2 += 8;
																	goto IL_05d1_2;
																	IL_05d1_2:
																	num5--;
																	goto end_IL_03ef_2;
																	IL_05e4_2:
																	if (1 < b)
																	{
																		goto IL_05ef_2;
																	}
																	num = 173;
																	goto IL_0619_2;
																	IL_05ef_2:
																	if (2 < b)
																	{
																		break;
																	}
																	goto IL_05fd_2;
																	IL_05fd_2:
																	if (2 > b)
																	{
																		break;
																	}
																	goto IL_0713_2;
																	IL_0713_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_0753_2;
																	IL_0753_2:
																	array2[num5 - 2] = 0;
																	goto IL_0767_2;
																	IL_0767_2:
																	num5--;
																	goto end_IL_03ef_2;
																	IL_077a_2:
																	num5--;
																	goto end_IL_03ef_2;
																	IL_0619_2:
																	if (1 > b)
																	{
																	}
																	break;
																	IL_062c_2:
																	if (4 >= b)
																	{
																		goto IL_0637_2;
																	}
																	goto IL_06a1_2;
																	IL_0637_2:
																	if (4 > b)
																	{
																		break;
																	}
																	goto IL_0645_2;
																	IL_0645_2:
																	array2[num5] = 0;
																	goto IL_0653_2;
																	IL_0653_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																	goto IL_0676_2;
																	IL_0676_2:
																	array3[num5] = null;
																	goto IL_0680_2;
																	IL_0680_2:
																	num5++;
																	goto IL_068e_2;
																	IL_068e_2:
																	ptr2 += 8;
																	goto end_IL_03ef_2;
																	IL_06a1_2:
																	if (5 < b)
																	{
																		break;
																	}
																	goto IL_06af_2;
																	IL_06af_2:
																	if (5 > b)
																	{
																		break;
																	}
																	goto IL_06bd_2;
																	IL_06bd_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_06fd_2;
																}
																goto end_IL_040f_2;
																continue;
																end_IL_03ef_2:
																break;
																IL_03ef_2:;
															}
															break;
														}
														goto IL_08f5_2;
														IL_0e69_2:
														num9 = ptr2;
														num10 = -200;
														num4 = 1;
														ptr2 = num9 + num10;
														break;
														IL_08f5_2:
														if (18 >= b)
														{
															goto IL_0903_2;
														}
														goto IL_0c10_2;
														IL_0903_2:
														if (18 > b)
														{
															goto IL_0911_2;
														}
														goto IL_0bbf_2;
														IL_0911_2:
														if (15 >= b)
														{
															goto IL_091f_2;
														}
														goto IL_0abe_2;
														IL_091f_2:
														if (15 > b)
														{
															goto IL_092d_2;
														}
														goto IL_0a7c_2;
														IL_092d_2:
														if (13 >= b)
														{
															goto IL_093b_2;
														}
														goto IL_0a21_2;
														IL_093b_2:
														if (13 > b)
														{
															goto end_IL_040f_2;
														}
														goto end_IL_0ec5_2;
														IL_0a21_2:
														if (14 < b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0a2f_2;
														IL_0a2f_2:
														if (14 > b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0a3d_2;
														IL_0a3d_2:
														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
														goto IL_0a5b_2;
														IL_0a5b_2:
														ptr2 += 8;
														goto IL_0a69_2;
														IL_0a69_2:
														num5--;
														break;
														IL_0a7c_2:
														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_0aa5_2;
														IL_0aa5_2:
														array2[num5 - 1] = 5;
														break;
														IL_0abe_2:
														if (16 < b)
														{
															goto IL_0ac9_2;
														}
														goto IL_0b2c_2;
														IL_0ac9_2:
														if (17 < b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0ad7_2;
														IL_0ad7_2:
														if (17 > b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0ae5_2;
														IL_0ae5_2:
														array2[num5] = 5;
														goto IL_0af3_2;
														IL_0af3_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_0b0b_2;
														IL_0b0b_2:
														num5++;
														goto IL_0b19_2;
														IL_0b19_2:
														ptr2 += 8;
														break;
														IL_0b2c_2:
														if (16 > b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0b3a_2;
														IL_0b3a_2:
														array2[num5] = array2[num5 - 1];
														goto IL_0b52_2;
														IL_0b52_2:
														array4[num5 - 0] = array4[num5 - 1];
														goto IL_0b70_2;
														IL_0b70_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0b94_2;
														IL_0b94_2:
														array3[num5] = array3[num5 - 1];
														goto IL_0bac_2;
														IL_0bac_2:
														num5++;
														break;
														IL_0bbf_2:
														((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
														goto IL_0bfd_2;
														IL_0bfd_2:
														num5 -= 3;
														break;
														IL_0c10_2:
														if (21 >= b)
														{
															goto IL_0c1e_2;
														}
														goto IL_0d52_2;
														IL_0c1e_2:
														if (21 <= b)
														{
															goto IL_0c29_2;
														}
														goto IL_0c6b_2;
														IL_0c29_2:
														array3[num5 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_0c52_2;
														IL_0c52_2:
														array2[num5 - 1] = 5;
														break;
														IL_0c6b_2:
														if (19 >= b)
														{
															goto IL_0c76_2;
														}
														goto IL_0ce3_2;
														IL_0c76_2:
														if (19 > b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0c84_2;
														IL_0c84_2:
														array2[num5 - 1] = 5;
														goto IL_0c98_2;
														IL_0c98_2:
														array3[num5 - 1] = ((delegate*<string[], string>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
														goto IL_0cd0_2;
														IL_0cd0_2:
														ptr2 += 8;
														break;
														IL_0ce3_2:
														if (20 < b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0cf1_2;
														IL_0cf1_2:
														if (20 > b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0cff_2;
														IL_0cff_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<float>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])();
														goto IL_0d23_2;
														IL_0d23_2:
														array2[num5] = 3;
														goto IL_0d31_2;
														IL_0d31_2:
														num5++;
														goto IL_0d3f_2;
														IL_0d3f_2:
														ptr2 += 8;
														break;
														IL_0d52_2:
														if (23 >= b)
														{
															goto IL_0d60_2;
														}
														goto IL_0e53_2;
														IL_0d60_2:
														if (23 <= b)
														{
															goto IL_0d6b_2;
														}
														goto IL_0db5_2;
														IL_0d6b_2:
														((delegate*<string, void>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
														goto IL_0d94_2;
														IL_0d94_2:
														num5--;
														goto IL_0da2_2;
														IL_0da2_2:
														ptr2 += 8;
														break;
														IL_0db5_2:
														if (22 < b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0dc3_2;
														IL_0dc3_2:
														if (22 > b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0dd1_2;
														IL_0dd1_2:
														array2[num5 - 2] = 5;
														num = 117;
														goto IL_0dee_2;
														IL_0dee_2:
														array3[num5 - 2] = ((delegate*<string, object, string>)IsVirtualPinnedBufferMemoryStream[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
														goto IL_0e35_2;
														IL_0e35_2:
														num5--;
														goto IL_0e43_2;
														IL_0e43_2:
														ptr2 += 8;
														break;
														IL_0e53_2:
														if (24 < b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0e5e_2;
														IL_0e5e_2:
														if (24 > b)
														{
															goto end_IL_040f_2;
														}
														goto IL_0e69_2;
													}
													goto end_IL_041f_2;
													continue;
													end_IL_040f_2:
													break;
													IL_040f_2:;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_0e9b_2;
											IL_0eb7_2:
											ptr2 += 8;
											break;
											IL_0ea9_2:
											num5++;
											goto IL_0eb7_2;
											IL_0e9b_2:
											array2[num5] = 0;
											goto IL_0ea9_2;
											continue;
											end_IL_041f_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_0ec5_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_0958_2;
					}
					continue;
					end_IL_0966:
					break;
				}
				break;
			}
		}
	}

	private static double ResourceManagerNotCreatingResourceSetRemoveAccessRuleSpecific(double double_1)
	{
		return Math.Round(double_1);
	}

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_0503, IL_0516, IL_052b, IL_0550, IL_0560, IL_0573, IL_0583, IL_0590, IL_05a3, IL_05b3, IL_05c3, IL_05d3, IL_05e3, IL_05f3, IL_05fe, IL_060e, IL_064e, IL_0664, IL_067a, IL_0688, IL_069b, IL_06ae, IL_06e6, IL_06f9, IL_0704, IL_0744, IL_0758, IL_076b, IL_0779, IL_0787, IL_07a0, IL_07ae, IL_07bc, IL_07cf, IL_0801, IL_080f, IL_0822, IL_0830, IL_0843, IL_0851, IL_085f, IL_086d, IL_087b, IL_08bb, IL_08cf, IL_08e2, IL_08eb, IL_092b, IL_093f, IL_0952, IL_095d, IL_0966, IL_0974, IL_09b4, IL_09c8, IL_09db, IL_09e9, IL_09f7, IL_0a0a, IL_0a18, IL_0a23, IL_0a41, IL_0a4f, IL_0a62, IL_0a70, IL_0a7e, IL_0a8c, IL_0a9a, IL_0afc, IL_0b0f, IL_0b1d, IL_0b26, IL_0b34, IL_0b51, IL_0ba0, IL_0baa, IL_0bd7, IL_0beb, IL_0bf9, IL_0c0c, IL_0c1a, IL_0c25, IL_0c33, IL_0c41, IL_0c59, IL_0c67, IL_0c7a, IL_0c88, IL_0c96, IL_0cd4, IL_0ce7, IL_0cf0, IL_0cfb, IL_0d09, IL_0d17, IL_0d40, IL_0d59, IL_0d71, IL_0d8f, IL_0dbc, IL_0dd4, IL_0de7, IL_0df5, IL_0e00, IL_0e14, IL_0e53, IL_0e66, IL_0e74, IL_0e82, IL_0e90, IL_0e9b, IL_0ef9, IL_0f0c, IL_0f1a, IL_0f28, IL_0f36, IL_0f5a, IL_0f68, IL_0f7b, IL_0f89, IL_0f97, IL_0fbb, IL_0fc9, IL_0fd7, IL_0fea, IL_100d, IL_101b, IL_1029, IL_1045, IL_1053, IL_105e, IL_1078, IL_108b, IL_1099, IL_10a7, IL_10b0, IL_10f0, IL_110d, IL_1120, IL_112e, IL_113c, IL_11aa, IL_11bd, IL_11cb, IL_11d9, IL_11e2, IL_1222, IL_1236, IL_1249, IL_1257, IL_1262, IL_127a, IL_1288, IL_1296, IL_12a9, IL_12b7, IL_12c5, IL_12d3, IL_12dc, IL_12f0, IL_1337, IL_1345, IL_1358, IL_1366, IL_1374, IL_139d, IL_13ab, IL_13be, IL_13c7, IL_13d2, IL_1404, IL_141d, IL_142b, IL_1439, IL_1479, IL_148d, IL_14a0, IL_14ae, IL_14b9, IL_14d5, IL_14e3, IL_14f1, IL_151a, IL_1528, IL_1538, IL_1543, IL_154e, IL_157c, IL_158c, IL_1597, IL_15a2, IL_15b5, IL_15c8, IL_15d2, IL_15e6, IL_15f6, IL_1606, IL_1616, IL_1626, IL_1636, IL_1646, IL_1656, IL_1666 are reachable both inside and outside the pinned region starting at IL_167b. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 236;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef63 = default(int);
			ref int reference = ref __rxRef63;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1666:
					num2 = 1;
					while (true)
					{
						IL_1656:
						num3 = num2 * 4;
						while (true)
						{
							IL_1646:
							array2 = new byte[4];
							while (true)
							{
								IL_1636:
								array3 = new object[4];
								while (true)
								{
									IL_1626:
									array4 = new int[4];
									while (true)
									{
										IL_1616:
										array5 = new int[6];
										while (true)
										{
											IL_1606:
											array6 = new long[4];
											while (true)
											{
												IL_15f6:
												array7 = new object[22];
												while (true)
												{
													IL_15e6:
													array7[0] = this;
													while (true)
													{
														IL_15d2:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AuthorizationRuleCollectionCalendarHijri.HostExecutionContextSwitcherMTA);
														num = 16;
														while (true)
														{
															IL_15c8:
															ptr2 = ptr;
															while (true)
															{
																IL_15b5:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_05f3:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_05e3:
																		ptr2++;
																		while (true)
																		{
																			IL_05d3:
																			if (b >= 1)
																			{
																				while (b <= 36)
																				{
																					while (true)
																					{
																						IL_05b3:
																						if (18 < b)
																						{
																							goto IL_0de7;
																						}
																						while (true)
																						{
																							IL_05a3:
																							if (18 > b)
																							{
																								while (true)
																								{
																									IL_0590:
																									if (9 >= b)
																									{
																										num = 143;
																										while (true)
																										{
																											IL_0583:
																											if (9 > b)
																											{
																												while (true)
																												{
																													IL_0573:
																													if (4 >= b)
																													{
																														while (true)
																														{
																															IL_0560:
																															if (4 <= b)
																															{
																																num = 270;
																																while (true)
																																{
																																	IL_0550:
																																	array2[num5] = 0;
																																	while (true)
																																	{
																																		IL_052b:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																																		while (true)
																																		{
																																			IL_0516:
																																			array3[num5] = null;
																																			num = 310;
																																			while (true)
																																			{
																																				if (num != 310)
																																				{
																																					if (num != 1291)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 236:
																																						break;
																																					default:
																																						continue;
																																					case 232:
																																						goto IL_0516;
																																					case 269:
																																						goto IL_052b;
																																					case 270:
																																					case 277:
																																						goto IL_0550;
																																					case 76:
																																						goto IL_0560;
																																					case 271:
																																						goto IL_0573;
																																					case 143:
																																						goto IL_0583;
																																					case 135:
																																						goto IL_0590;
																																					case 171:
																																						goto IL_05a3;
																																					case 100:
																																						goto IL_05b3;
																																					case 5:
																																						goto IL_05c3;
																																					case 260:
																																						goto IL_05d3;
																																					case 209:
																																						goto IL_05e3;
																																					case 120:
																																					case 282:
																																						goto IL_05f3;
																																					case 72:
																																						goto IL_05fe;
																																					case 3:
																																					case 88:
																																						goto IL_060e;
																																					case 93:
																																						goto IL_064e;
																																					case 108:
																																					case 160:
																																						goto IL_0664;
																																					case 170:
																																						goto IL_067a;
																																					case 77:
																																						goto IL_0688;
																																					case 178:
																																						goto IL_069b;
																																					case 193:
																																						goto IL_06ae;
																																					case 151:
																																						goto IL_06e6;
																																					case 259:
																																						goto IL_06f9;
																																					case 0:
																																					case 185:
																																						goto IL_0704;
																																					case 10:
																																						goto IL_0744;
																																					case 228:
																																						goto IL_0758;
																																					case 29:
																																						goto IL_076b;
																																					case 204:
																																						goto IL_0779;
																																					case 187:
																																					case 266:
																																						goto IL_0787;
																																					case 211:
																																						goto IL_07a0;
																																					case 200:
																																						goto IL_07ae;
																																					case 205:
																																						goto IL_07bc;
																																					case 92:
																																					case 286:
																																						goto IL_07cf;
																																					case 195:
																																						goto IL_0801;
																																					case 291:
																																						goto IL_080f;
																																					case 8:
																																						goto IL_0830;
																																					case 226:
																																						goto IL_0843;
																																					case 127:
																																						goto IL_0851;
																																					case 37:
																																						goto IL_085f;
																																					case 11:
																																						goto IL_086d;
																																					case 60:
																																					case 183:
																																						goto IL_087b;
																																					case 38:
																																						goto IL_08bb;
																																					case 152:
																																						goto IL_08cf;
																																					case 161:
																																					case 163:
																																						goto IL_08eb;
																																					case 116:
																																						goto IL_092b;
																																					case 99:
																																						goto IL_093f;
																																					case 156:
																																						goto IL_0952;
																																					case 2:
																																						goto IL_0966;
																																					case 45:
																																					case 87:
																																						goto IL_0974;
																																					case 181:
																																						goto IL_09b4;
																																					case 227:
																																						goto IL_09c8;
																																					case 288:
																																						goto IL_09db;
																																					case 177:
																																						goto IL_09e9;
																																					case 192:
																																					case 285:
																																						goto IL_09f7;
																																					case 238:
																																						goto IL_0a0a;
																																					case 199:
																																						goto IL_0a18;
																																					case 1:
																																					case 191:
																																						goto IL_0a23;
																																					case 46:
																																						goto IL_0a41;
																																					case 115:
																																						goto IL_0a4f;
																																					case 67:
																																						goto IL_0a62;
																																					case 221:
																																						goto IL_0a70;
																																					case 105:
																																						goto IL_0a7e;
																																					case 86:
																																						goto IL_0a8c;
																																					case 48:
																																					case 208:
																																						goto IL_0a9a;
																																					case 64:
																																						goto IL_0afc;
																																					case 140:
																																						goto IL_0b0f;
																																					case 175:
																																						goto IL_0b26;
																																					case 42:
																																					case 174:
																																						goto IL_0b34;
																																					case 128:
																																						goto IL_0beb;
																																					case 231:
																																						goto IL_0bf9;
																																					case 241:
																																						goto IL_0c0c;
																																					case 68:
																																						goto IL_0c1a;
																																					case 35:
																																						goto IL_0c25;
																																					case 74:
																																					case 287:
																																						goto IL_0c33;
																																					case 225:
																																						goto IL_0c41;
																																					case 117:
																																						goto IL_0c59;
																																					case 299:
																																						goto IL_0c67;
																																					case 279:
																																						goto IL_0c7a;
																																					case 158:
																																						goto IL_0c88;
																																					case 148:
																																					case 276:
																																						goto IL_0c96;
																																					case 210:
																																						goto IL_0cd4;
																																					case 258:
																																						goto IL_0cf0;
																																					case 194:
																																						goto IL_0cfb;
																																					case 168:
																																						goto IL_0d09;
																																					case 249:
																																					case 275:
																																						goto IL_0d17;
																																					case 17:
																																						goto IL_0d40;
																																					case 142:
																																					case 301:
																																						goto IL_0d59;
																																					case 121:
																																						goto IL_0d71;
																																					case 111:
																																						goto IL_0d8f;
																																					case 19:
																																						goto IL_0dbc;
																																					case 149:
																																						goto IL_0dd4;
																																					case 41:
																																						goto IL_0de7;
																																					case 55:
																																						goto IL_0df5;
																																					case 133:
																																					case 273:
																																						goto IL_0e00;
																																					case 173:
																																						goto IL_0e14;
																																					case 262:
																																						goto IL_0e53;
																																					case 294:
																																						goto IL_0e66;
																																					case 122:
																																						goto IL_0e74;
																																					case 126:
																																						goto IL_0e82;
																																					case 284:
																																						goto IL_0e90;
																																					case 39:
																																					case 245:
																																						goto IL_0e9b;
																																					case 119:
																																						goto IL_0ef9;
																																					case 263:
																																						goto IL_0f0c;
																																					case 114:
																																						goto IL_0f1a;
																																					case 15:
																																					case 251:
																																						goto IL_0f28;
																																					case 4:
																																						goto IL_0f36;
																																					case 165:
																																						goto IL_0f5a;
																																					case 239:
																																						goto IL_0f68;
																																					case 56:
																																						goto IL_0f7b;
																																					case 190:
																																						goto IL_0f89;
																																					case 7:
																																					case 169:
																																						goto IL_0f97;
																																					case 91:
																																						goto IL_0fbb;
																																					case 53:
																																						goto IL_0fc9;
																																					case 255:
																																						goto IL_0fd7;
																																					case 33:
																																					case 141:
																																						goto IL_0fea;
																																					case 66:
																																						goto IL_100d;
																																					case 18:
																																						goto IL_101b;
																																					case 134:
																																						goto IL_1029;
																																					case 242:
																																						goto IL_1045;
																																					case 295:
																																						goto IL_1053;
																																					case 85:
																																					case 292:
																																						goto IL_105e;
																																					case 28:
																																						goto IL_1078;
																																					case 107:
																																						goto IL_108b;
																																					case 222:
																																						goto IL_1099;
																																					case 237:
																																					case 244:
																																						goto IL_10b0;
																																					case 79:
																																						goto IL_10f0;
																																					case 63:
																																						goto IL_110d;
																																					case 61:
																																						goto IL_1120;
																																					case 159:
																																						goto IL_112e;
																																					case 153:
																																					case 230:
																																						goto IL_113c;
																																					case 95:
																																						goto IL_11aa;
																																					case 172:
																																						goto IL_11bd;
																																					case 118:
																																						goto IL_11cb;
																																					case 20:
																																					case 176:
																																						goto IL_11e2;
																																					case 130:
																																						goto IL_1222;
																																					case 6:
																																						goto IL_1236;
																																					case 250:
																																						goto IL_1249;
																																					case 103:
																																						goto IL_1257;
																																					case 59:
																																					case 157:
																																						goto IL_1262;
																																					case 267:
																																						goto IL_127a;
																																					case 281:
																																						goto IL_1288;
																																					case 254:
																																						goto IL_1296;
																																					case 137:
																																						goto IL_12a9;
																																					case 50:
																																						goto IL_12b7;
																																					case 34:
																																						goto IL_12c5;
																																					case 138:
																																					case 155:
																																						goto IL_12dc;
																																					case 164:
																																						goto IL_12f0;
																																					case 213:
																																						goto IL_1337;
																																					case 89:
																																						goto IL_1345;
																																					case 180:
																																						goto IL_1358;
																																					case 26:
																																						goto IL_1366;
																																					case 75:
																																					case 167:
																																						goto IL_1374;
																																					case 129:
																																						goto IL_139d;
																																					case 203:
																																						goto IL_13ab;
																																					case 62:
																																						goto IL_13c7;
																																					case 27:
																																					case 139:
																																						goto IL_13d2;
																																					case 90:
																																						goto IL_1404;
																																					case 81:
																																						goto IL_141d;
																																					case 248:
																																						goto IL_142b;
																																					case 43:
																																					case 110:
																																						goto IL_1439;
																																					case 274:
																																						goto IL_1479;
																																					case 272:
																																						goto IL_148d;
																																					case 297:
																																						goto IL_14a0;
																																					case 65:
																																						goto IL_14ae;
																																					case 206:
																																					case 289:
																																						goto IL_14b9;
																																					case 283:
																																						goto IL_14d5;
																																					case 109:
																																						goto IL_14e3;
																																					case 51:
																																					case 256:
																																						goto end_IL_0503;
																																					case 233:
																																						goto IL_151a;
																																					case 302:
																																						goto IL_1528;
																																					case 94:
																																						goto IL_1538;
																																					case 96:
																																						goto IL_1543;
																																					case 47:
																																					case 124:
																																						goto IL_154e;
																																					case 179:
																																						goto IL_157c;
																																					case 12:
																																						goto IL_158c;
																																					case 125:
																																						goto IL_1597;
																																					case 21:
																																					case 25:
																																					case 32:
																																					case 36:
																																					case 44:
																																					case 54:
																																					case 57:
																																					case 58:
																																					case 69:
																																					case 70:
																																					case 71:
																																					case 78:
																																					case 80:
																																					case 82:
																																					case 84:
																																					case 97:
																																					case 102:
																																					case 106:
																																					case 132:
																																					case 144:
																																					case 145:
																																					case 162:
																																					case 166:
																																					case 182:
																																					case 184:
																																					case 197:
																																					case 201:
																																					case 202:
																																					case 212:
																																					case 219:
																																					case 223:
																																					case 224:
																																					case 247:
																																					case 261:
																																					case 264:
																																					case 268:
																																					case 290:
																																					case 298:
																																					case 303:
																																						goto end_IL_05c3;
																																					case 9:
																																					case 13:
																																					case 14:
																																					case 22:
																																					case 23:
																																					case 24:
																																					case 30:
																																					case 31:
																																					case 40:
																																					case 49:
																																					case 73:
																																					case 98:
																																					case 101:
																																					case 104:
																																					case 112:
																																					case 113:
																																					case 123:
																																					case 136:
																																					case 146:
																																					case 147:
																																					case 186:
																																					case 188:
																																					case 189:
																																					case 214:
																																					case 215:
																																					case 218:
																																					case 229:
																																					case 234:
																																					case 240:
																																					case 243:
																																					case 246:
																																					case 252:
																																					case 253:
																																					case 257:
																																					case 265:
																																					case 278:
																																					case 293:
																																					case 296:
																																					case 300:
																																						goto IL_15b5;
																																					case 16:
																																						goto IL_15c8;
																																					case 280:
																																						goto IL_15d2;
																																					case 220:
																																						goto IL_15e6;
																																					case 83:
																																						goto IL_15f6;
																																					case 196:
																																						goto IL_1606;
																																					case 207:
																																						goto IL_1616;
																																					case 52:
																																						goto IL_1626;
																																					case 198:
																																						goto IL_1636;
																																					case 131:
																																					case 150:
																																						goto IL_1646;
																																					case 154:
																																						goto IL_1656;
																																					case 235:
																																						goto IL_1666;
																																					case 216:
																																					case 217:
																																						return;
																																					}
																																					goto end_IL_05b3;
																																				}
																																				num5++;
																																				goto IL_0830;
																																				IL_0830:
																																				ptr2 += 8;
																																				goto IL_15b5;
																																				continue;
																																				end_IL_0503:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_05fe;
																															IL_0801:
																															ptr2 += 8;
																															goto IL_080f;
																															IL_080f:
																															num5--;
																															goto IL_15b5;
																															IL_05fe:
																															if (2 < b)
																															{
																																goto IL_067a;
																															}
																															goto IL_06f9;
																															IL_06f9:
																															if (2 <= b)
																															{
																																goto IL_0704;
																															}
																															goto IL_076b;
																															IL_0704:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																															goto IL_0744;
																															IL_0744:
																															array2[num5 - 2] = 0;
																															goto IL_0758;
																															IL_0758:
																															num5--;
																															goto IL_15b5;
																															IL_076b:
																															if (1 < b)
																															{
																																goto end_IL_05c3;
																															}
																															goto IL_0779;
																															IL_0779:
																															if (1 > b)
																															{
																																goto end_IL_05c3;
																															}
																															goto IL_0787;
																															IL_0787:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																															goto IL_07a0;
																															IL_07a0:
																															array2[num5] = 0;
																															goto IL_07ae;
																															IL_07ae:
																															num5++;
																															goto IL_07bc;
																															IL_07bc:
																															ptr2 += 8;
																															goto IL_15b5;
																															IL_067a:
																															if (3 < b)
																															{
																																goto end_IL_05c3;
																															}
																															goto IL_0688;
																															IL_0688:
																															if (3 > b)
																															{
																																goto end_IL_05c3;
																															}
																															goto IL_07cf;
																															IL_07cf:
																															reference = ref array5[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																															num = 195;
																															goto IL_0801;
																														}
																														break;
																													}
																													goto IL_0843;
																													IL_09db:
																													if (8 < b)
																													{
																														goto end_IL_05c3;
																													}
																													goto IL_09e9;
																													IL_0843:
																													if (6 >= b)
																													{
																														goto IL_0851;
																													}
																													goto IL_0952;
																													IL_0851:
																													if (6 > b)
																													{
																														goto IL_085f;
																													}
																													num = 161;
																													goto IL_08eb;
																													IL_085f:
																													if (5 < b)
																													{
																														goto end_IL_05c3;
																													}
																													goto IL_086d;
																													IL_086d:
																													if (5 > b)
																													{
																														goto end_IL_05c3;
																													}
																													goto IL_087b;
																													IL_087b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																													goto IL_08bb;
																													IL_08bb:
																													array2[num5 - 2] = 0;
																													goto IL_08cf;
																													IL_08cf:
																													num5--;
																													goto IL_15b5;
																													IL_09e9:
																													if (8 > b)
																													{
																														goto end_IL_05c3;
																													}
																													goto IL_09f7;
																													IL_08eb:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																													goto IL_092b;
																													IL_092b:
																													array2[num5 - 2] = 0;
																													goto IL_093f;
																													IL_093f:
																													num5--;
																													goto IL_15b5;
																													IL_0952:
																													if (7 >= b)
																													{
																														num = 2;
																														goto IL_0966;
																													}
																													goto IL_09db;
																													IL_09f7:
																													num5--;
																													goto IL_15b5;
																													IL_0966:
																													if (7 > b)
																													{
																														goto end_IL_05c3;
																													}
																													goto IL_0974;
																													IL_0974:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																													goto IL_09b4;
																													IL_09b4:
																													array2[num5 - 2] = 0;
																													goto IL_09c8;
																													IL_09c8:
																													num5--;
																													goto IL_15b5;
																												}
																												break;
																											}
																											goto IL_060e;
																											IL_069b:
																											num5--;
																											goto IL_15b5;
																											IL_060e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_064e;
																											IL_064e:
																											array2[num5 - 2] = 0;
																											goto IL_069b;
																										}
																										break;
																									}
																									goto IL_0a0a;
																									IL_0d17:
																									array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																									goto IL_0d40;
																									IL_0d40:
																									array2[num5 - 1] = 5;
																									goto IL_15b5;
																									IL_0a0a:
																									if (13 >= b)
																									{
																										goto IL_0a18;
																									}
																									goto IL_0c0c;
																									IL_0a18:
																									if (13 <= b)
																									{
																										goto IL_0a23;
																									}
																									goto IL_0a62;
																									IL_0a23:
																									array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																									goto IL_0a41;
																									IL_0a41:
																									ptr2 += 8;
																									goto IL_0a4f;
																									IL_0a4f:
																									num5--;
																									goto IL_15b5;
																									IL_0a62:
																									if (11 >= b)
																									{
																										goto IL_0a70;
																									}
																									goto IL_0b0f;
																									IL_0a70:
																									if (11 <= b)
																									{
																										goto IL_15b5;
																									}
																									goto IL_0a7e;
																									IL_0a7e:
																									if (10 < b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0a8c;
																									IL_0a8c:
																									if (10 > b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0a9a;
																									IL_0a9a:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0afc;
																									IL_0afc:
																									num5 -= 2;
																									goto IL_15b5;
																									IL_0b0f:
																									if (12 < b)
																									{
																										goto end_IL_05c3;
																									}
																									num = 175;
																									goto IL_0b26;
																									IL_0d59:
																									array2[num5] = array2[num5 - 1];
																									goto IL_0d71;
																									IL_0b26:
																									if (12 > b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0b34;
																									IL_0b34:
																									array8 = array3;
																									num6 = num5;
																									if (array == null)
																									{
																										goto IL_0b43;
																									}
																									num7 = ptr2;
																									byte b2 = *num7;
																									ptr2 = num7 + 4;
																									int num8 = *(int*)(ptr2 + num3);
																									ptr2 += 8;
																									byte* ptr3 = ptr2 + num8;
																									byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																									while (ptr2 != ptr3)
																									{
																										*ptr4 = (byte)(*ptr2 ^ b2);
																										ptr2++;
																										ptr4++;
																									}
																									array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																									goto IL_0beb;
																									IL_0d71:
																									array4[num5 - 0] = array4[num5 - 1];
																									goto IL_0d8f;
																									IL_0d8f:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									num = 19;
																									goto IL_0dbc;
																									IL_0dbc:
																									array3[num5] = array3[num5 - 1];
																									goto IL_0dd4;
																									IL_0beb:
																									array2[num5] = 5;
																									goto IL_0bf9;
																									IL_0bf9:
																									num5++;
																									goto IL_15b5;
																									IL_0c0c:
																									if (15 < b)
																									{
																										goto IL_0c1a;
																									}
																									num = 258;
																									goto IL_0cf0;
																									IL_0c1a:
																									if (16 >= b)
																									{
																										goto IL_0c25;
																									}
																									goto IL_0c7a;
																									IL_0c25:
																									if (16 > b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0c33;
																									IL_0c33:
																									array2[num5] = 5;
																									goto IL_0c41;
																									IL_0c41:
																									array3[num5] = array7[*(int*)(ptr2 + num3)];
																									goto IL_0c59;
																									IL_0c59:
																									num5++;
																									goto IL_0c67;
																									IL_0c67:
																									ptr2 += 8;
																									goto IL_15b5;
																									IL_0c7a:
																									if (17 < b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0c88;
																									IL_0c88:
																									if (17 > b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0c96;
																									IL_0c96:
																									((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																									goto IL_0cd4;
																									IL_0cd4:
																									num5 -= 3;
																									goto IL_15b5;
																									IL_0dd4:
																									num5++;
																									goto IL_15b5;
																									IL_0cf0:
																									if (15 > b)
																									{
																										goto IL_0cfb;
																									}
																									goto IL_0d59;
																									IL_0cfb:
																									if (14 < b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0d09;
																									IL_0d09:
																									if (14 > b)
																									{
																										goto end_IL_05c3;
																									}
																									goto IL_0d17;
																								}
																								break;
																							}
																							goto IL_0664;
																							IL_06e6:
																							ptr2 += 8;
																							goto IL_15b5;
																							IL_0664:
																							array2[num5 - 1] = 5;
																							goto IL_06ae;
																							IL_06ae:
																							array3[num5 - 1] = ((delegate*<string[], string>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																							goto IL_06e6;
																						}
																						goto IL_14f1;
																						IL_1543:
																						if (35 > b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_154e;
																						IL_0de7:
																						if (27 >= b)
																						{
																							goto IL_0df5;
																						}
																						goto IL_1249;
																						IL_0df5:
																						if (27 <= b)
																						{
																							goto IL_0e00;
																						}
																						goto IL_0e66;
																						IL_0e00:
																						array2[num5 - 1] = 3;
																						goto IL_0e14;
																						IL_0e14:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<float, float>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])));
																						goto IL_0e53;
																						IL_0e53:
																						ptr2 += 8;
																						goto IL_15b5;
																						IL_0e66:
																						if (22 >= b)
																						{
																							goto IL_0e74;
																						}
																						goto IL_1045;
																						IL_0e74:
																						if (22 > b)
																						{
																							goto IL_0e82;
																						}
																						goto IL_0fea;
																						IL_0e82:
																						if (20 >= b)
																						{
																							goto IL_0e90;
																						}
																						goto IL_0f7b;
																						IL_0e90:
																						if (20 <= b)
																						{
																							goto IL_0e9b;
																						}
																						goto IL_0f0c;
																						IL_0e9b:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0ef9;
																						IL_0ef9:
																						num5--;
																						goto IL_15b5;
																						IL_0f0c:
																						if (19 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_0f1a;
																						IL_0f1a:
																						if (19 > b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_0f28;
																						IL_0f28:
																						array2[num5] = 0;
																						goto IL_0f36;
																						IL_0f36:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_0f5a;
																						IL_0f5a:
																						num5++;
																						goto IL_0f68;
																						IL_0f68:
																						ptr2 += 8;
																						goto IL_15b5;
																						IL_0f7b:
																						if (21 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_0f89;
																						IL_0f89:
																						if (21 > b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_0f97;
																						IL_0f97:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<float>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])();
																						goto IL_0fbb;
																						IL_0fbb:
																						array2[num5] = 3;
																						goto IL_0fc9;
																						IL_0fc9:
																						num5++;
																						goto IL_0fd7;
																						IL_0fd7:
																						ptr2 += 8;
																						goto IL_15b5;
																						IL_0fea:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(float*)(ptr2 + num3);
																						num = 66;
																						goto IL_100d;
																						IL_100d:
																						array2[num5] = 3;
																						goto IL_101b;
																						IL_101b:
																						num5++;
																						goto IL_1029;
																						IL_1029:
																						ptr2 += 8;
																						num = 188;
																						goto IL_15b5;
																						IL_1045:
																						if (24 >= b)
																						{
																							goto IL_1053;
																						}
																						goto IL_1120;
																						IL_1053:
																						if (24 <= b)
																						{
																							goto IL_105e;
																						}
																						goto IL_108b;
																						IL_105e:
																						Class147.float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_1078;
																						IL_1078:
																						num5--;
																						goto IL_15b5;
																						IL_108b:
																						if (23 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_1099;
																						IL_1099:
																						if (23 > b)
																						{
																							goto end_IL_05c3;
																						}
																						num = 237;
																						goto IL_10b0;
																						IL_154e:
																						((Class148)array3[num5 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_157c;
																						IL_10b0:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_10f0;
																						IL_10f0:
																						array2[num5 - 2] = 3;
																						num = 63;
																						goto IL_110d;
																						IL_110d:
																						num5--;
																						goto IL_15b5;
																						IL_1120:
																						if (25 >= b)
																						{
																							goto IL_112e;
																						}
																						goto IL_11bd;
																						IL_112e:
																						if (25 > b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_113c;
																						IL_113c:
																						ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_11aa;
																						IL_11aa:
																						num5 -= 2;
																						goto IL_15b5;
																						IL_11bd:
																						if (26 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_11cb;
																						IL_11cb:
																						if (26 > b)
																						{
																							goto end_IL_05c3;
																						}
																						num = 20;
																						goto IL_11e2;
																						IL_157c:
																						num5 -= 2;
																						goto IL_15b5;
																						IL_11e2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_1222;
																						IL_1222:
																						array2[num5 - 2] = 3;
																						goto IL_1236;
																						IL_1236:
																						num5--;
																						goto IL_15b5;
																						IL_1249:
																						if (32 >= b)
																						{
																							goto IL_1257;
																						}
																						goto IL_14a0;
																						IL_1257:
																						if (32 <= b)
																						{
																							goto IL_1262;
																						}
																						goto IL_12a9;
																						IL_1262:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_127a;
																						IL_127a:
																						array2[num5] = 5;
																						goto IL_1288;
																						IL_1288:
																						num5++;
																						goto IL_1296;
																						IL_1296:
																						ptr2 += 8;
																						goto IL_15b5;
																						IL_12a9:
																						if (29 < b)
																						{
																							goto IL_12b7;
																						}
																						num = 62;
																						goto IL_13c7;
																						IL_12b7:
																						if (30 >= b)
																						{
																							goto IL_12c5;
																						}
																						goto IL_1358;
																						IL_12c5:
																						if (30 > b)
																						{
																							goto end_IL_05c3;
																						}
																						num = 155;
																						goto IL_12dc;
																						IL_1597:
																						if (36 <= b)
																						{
																						}
																						goto end_IL_05c3;
																						IL_12dc:
																						array2[num5 - 2] = 5;
																						goto IL_12f0;
																						IL_12f0:
																						array3[num5 - 2] = ((delegate*<string, object, string>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
																						goto IL_1337;
																						IL_1337:
																						num5--;
																						goto IL_1345;
																						IL_1345:
																						ptr2 += 8;
																						goto IL_15b5;
																						IL_1358:
																						if (31 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_1366;
																						IL_1366:
																						if (31 > b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_1374;
																						IL_1374:
																						((delegate*<string, void>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																						goto IL_139d;
																						IL_139d:
																						num5--;
																						goto IL_13ab;
																						IL_13ab:
																						ptr2 += 8;
																						goto IL_15b5;
																						IL_158c:
																						if (36 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_1597;
																						IL_13c7:
																						if (29 <= b)
																						{
																							goto IL_13d2;
																						}
																						goto IL_141d;
																						IL_13d2:
																						array3[num5 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						num = 90;
																						goto IL_1404;
																						IL_1404:
																						array2[num5 - 1] = 5;
																						goto IL_15b5;
																						IL_141d:
																						if (28 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_142b;
																						IL_142b:
																						if (28 > b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_1439;
																						IL_1439:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_1479;
																						IL_1479:
																						array2[num5 - 2] = 3;
																						goto IL_148d;
																						IL_148d:
																						num5--;
																						goto IL_15b5;
																						IL_14a0:
																						if (34 >= b)
																						{
																							goto IL_14ae;
																						}
																						goto IL_1538;
																						IL_14ae:
																						if (34 <= b)
																						{
																							goto IL_14b9;
																						}
																						goto IL_14d5;
																						IL_14b9:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						goto IL_15b5;
																						IL_14d5:
																						if (33 < b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_14e3;
																						IL_14e3:
																						if (33 > b)
																						{
																							goto end_IL_05c3;
																						}
																						goto IL_14f1;
																						IL_14f1:
																						((delegate*<UnityEngine.Object, void>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((Class148)array3[num5 - 1]);
																						goto IL_151a;
																						IL_151a:
																						num5--;
																						goto IL_1528;
																						IL_1528:
																						ptr2 += 8;
																						goto IL_15b5;
																						IL_1538:
																						if (35 >= b)
																						{
																							goto IL_1543;
																						}
																						goto IL_158c;
																						continue;
																						end_IL_05b3:
																						break;
																					}
																					goto end_IL_05d3;
																					continue;
																					end_IL_05c3:
																					break;
																					IL_05c3:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_15b5;
																			continue;
																			end_IL_05d3:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0b43:
			while (true)
			{
				IL_0b43_2:
				array = new byte[4];
				while (true)
				{
					IL_0b51:
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num5] = 5;
						while (true)
						{
							IL_0bf9_2:
							num5++;
							while (true)
							{
								IL_15b5_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_05d3_2:
											if (b >= 1)
											{
												while (b <= 36)
												{
													while (true)
													{
														IL_05b3_2:
														if (18 < b)
														{
															goto IL_0de7_2;
														}
														while (true)
														{
															IL_05a3_2:
															if (18 > b)
															{
																while (true)
																{
																	IL_0590_2:
																	if (9 >= b)
																	{
																		num = 143;
																		while (true)
																		{
																			IL_0583_2:
																			if (9 > b)
																			{
																				while (true)
																				{
																					IL_0573_2:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_0560_2:
																							if (4 <= b)
																							{
																								num = 270;
																								while (true)
																								{
																									IL_0550_2:
																									array2[num5] = 0;
																									while (true)
																									{
																										IL_052b_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																										while (true)
																										{
																											IL_0516_2:
																											array3[num5] = null;
																											num = 310;
																											while (true)
																											{
																												if (num != 310)
																												{
																													if (num != 1291)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 232:
																														goto IL_0516_2;
																													case 269:
																														goto IL_052b_2;
																													case 270:
																													case 277:
																														goto IL_0550_2;
																													case 76:
																														goto IL_0560_2;
																													case 271:
																														goto IL_0573_2;
																													case 143:
																														goto IL_0583_2;
																													case 135:
																														goto IL_0590_2;
																													case 171:
																														goto IL_05a3_2;
																													case 100:
																														goto IL_05b3_2;
																													case 5:
																														goto end_IL_05b3_2;
																													case 260:
																														goto IL_05d3_2;
																													case 209:
																														goto end_IL_05d3_2;
																													case 120:
																													case 282:
																														goto end_IL_05e3;
																													case 72:
																														goto IL_05fe_2;
																													case 3:
																													case 88:
																														goto IL_060e_2;
																													case 93:
																														goto IL_064e_2;
																													case 108:
																													case 160:
																														goto IL_0664_2;
																													case 170:
																														goto IL_067a_2;
																													case 77:
																														goto IL_0688_2;
																													case 178:
																														goto IL_069b_2;
																													case 193:
																														goto IL_06ae_2;
																													case 151:
																														goto IL_06e6_2;
																													case 259:
																														goto IL_06f9_2;
																													case 0:
																													case 185:
																														goto IL_0704_2;
																													case 10:
																														goto IL_0744_2;
																													case 228:
																														goto IL_0758_2;
																													case 29:
																														goto IL_076b_2;
																													case 204:
																														goto IL_0779_2;
																													case 187:
																													case 266:
																														goto IL_0787_2;
																													case 211:
																														goto IL_07a0_2;
																													case 200:
																														goto IL_07ae_2;
																													case 205:
																														goto IL_07bc_2;
																													case 92:
																													case 286:
																														goto IL_07cf_2;
																													case 195:
																														goto IL_0801_2;
																													case 291:
																														goto IL_080f_2;
																													case 8:
																														goto IL_0830_2;
																													case 226:
																														goto IL_0843_2;
																													case 127:
																														goto IL_0851_2;
																													case 37:
																														goto IL_085f_2;
																													case 11:
																														goto IL_086d_2;
																													case 60:
																													case 183:
																														goto IL_087b_2;
																													case 38:
																														goto IL_08bb_2;
																													case 152:
																														goto IL_08cf_2;
																													case 161:
																													case 163:
																														goto IL_08eb_2;
																													case 116:
																														goto IL_092b_2;
																													case 99:
																														goto IL_093f_2;
																													case 156:
																														goto IL_0952_2;
																													case 2:
																														goto IL_0966_2;
																													case 45:
																													case 87:
																														goto IL_0974_2;
																													case 181:
																														goto IL_09b4_2;
																													case 227:
																														goto IL_09c8_2;
																													case 288:
																														goto IL_09db_2;
																													case 177:
																														goto IL_09e9_2;
																													case 192:
																													case 285:
																														goto IL_09f7_2;
																													case 238:
																														goto IL_0a0a_2;
																													case 199:
																														goto IL_0a18_2;
																													case 1:
																													case 191:
																														goto IL_0a23_2;
																													case 46:
																														goto IL_0a41_2;
																													case 115:
																														goto IL_0a4f_2;
																													case 67:
																														goto IL_0a62_2;
																													case 221:
																														goto IL_0a70_2;
																													case 105:
																														goto IL_0a7e_2;
																													case 86:
																														goto IL_0a8c_2;
																													case 48:
																													case 208:
																														goto IL_0a9a_2;
																													case 64:
																														goto IL_0afc_2;
																													case 140:
																														goto IL_0b0f_2;
																													case 175:
																														goto IL_0b26_2;
																													case 42:
																													case 174:
																														goto IL_0b34_2;
																													case 128:
																														goto end_IL_05f3;
																													case 231:
																														goto IL_0bf9_2;
																													case 241:
																														goto IL_0c0c_2;
																													case 68:
																														goto IL_0c1a_2;
																													case 35:
																														goto IL_0c25_2;
																													case 74:
																													case 287:
																														goto IL_0c33_2;
																													case 225:
																														goto IL_0c41_2;
																													case 117:
																														goto IL_0c59_2;
																													case 299:
																														goto IL_0c67_2;
																													case 279:
																														goto IL_0c7a_2;
																													case 158:
																														goto IL_0c88_2;
																													case 148:
																													case 276:
																														goto IL_0c96_2;
																													case 210:
																														goto IL_0cd4_2;
																													case 258:
																														goto IL_0cf0_2;
																													case 194:
																														goto IL_0cfb_2;
																													case 168:
																														goto IL_0d09_2;
																													case 249:
																													case 275:
																														goto IL_0d17_2;
																													case 17:
																														goto IL_0d40_2;
																													case 142:
																													case 301:
																														goto IL_0d59_2;
																													case 121:
																														goto IL_0d71_2;
																													case 111:
																														goto IL_0d8f_2;
																													case 19:
																														goto IL_0dbc_2;
																													case 149:
																														goto IL_0dd4_2;
																													case 41:
																														goto IL_0de7_2;
																													case 55:
																														goto IL_0df5_2;
																													case 133:
																													case 273:
																														goto IL_0e00_2;
																													case 173:
																														goto IL_0e14_2;
																													case 262:
																														goto IL_0e53_2;
																													case 294:
																														goto IL_0e66_2;
																													case 122:
																														goto IL_0e74_2;
																													case 126:
																														goto IL_0e82_2;
																													case 284:
																														goto IL_0e90_2;
																													case 39:
																													case 245:
																														goto IL_0e9b_2;
																													case 119:
																														goto IL_0ef9_2;
																													case 263:
																														goto IL_0f0c_2;
																													case 114:
																														goto IL_0f1a_2;
																													case 15:
																													case 251:
																														goto IL_0f28_2;
																													case 4:
																														goto IL_0f36_2;
																													case 165:
																														goto IL_0f5a_2;
																													case 239:
																														goto IL_0f68_2;
																													case 56:
																														goto IL_0f7b_2;
																													case 190:
																														goto IL_0f89_2;
																													case 7:
																													case 169:
																														goto IL_0f97_2;
																													case 91:
																														goto IL_0fbb_2;
																													case 53:
																														goto IL_0fc9_2;
																													case 255:
																														goto IL_0fd7_2;
																													case 33:
																													case 141:
																														goto IL_0fea_2;
																													case 66:
																														goto IL_100d_2;
																													case 18:
																														goto IL_101b_2;
																													case 134:
																														goto IL_1029_2;
																													case 242:
																														goto IL_1045_2;
																													case 295:
																														goto IL_1053_2;
																													case 85:
																													case 292:
																														goto IL_105e_2;
																													case 28:
																														goto IL_1078_2;
																													case 107:
																														goto IL_108b_2;
																													case 222:
																														goto IL_1099_2;
																													case 237:
																													case 244:
																														goto IL_10b0_2;
																													case 79:
																														goto IL_10f0_2;
																													case 63:
																														goto IL_110d_2;
																													case 61:
																														goto IL_1120_2;
																													case 159:
																														goto IL_112e_2;
																													case 153:
																													case 230:
																														goto IL_113c_2;
																													case 95:
																														goto IL_11aa_2;
																													case 172:
																														goto IL_11bd_2;
																													case 118:
																														goto IL_11cb_2;
																													case 20:
																													case 176:
																														goto IL_11e2_2;
																													case 130:
																														goto IL_1222_2;
																													case 6:
																														goto IL_1236_2;
																													case 250:
																														goto IL_1249_2;
																													case 103:
																														goto IL_1257_2;
																													case 59:
																													case 157:
																														goto IL_1262_2;
																													case 267:
																														goto IL_127a_2;
																													case 281:
																														goto IL_1288_2;
																													case 254:
																														goto IL_1296_2;
																													case 137:
																														goto IL_12a9_2;
																													case 50:
																														goto IL_12b7_2;
																													case 34:
																														goto IL_12c5_2;
																													case 138:
																													case 155:
																														goto IL_12dc_2;
																													case 164:
																														goto IL_12f0_2;
																													case 213:
																														goto IL_1337_2;
																													case 89:
																														goto IL_1345_2;
																													case 180:
																														goto IL_1358_2;
																													case 26:
																														goto IL_1366_2;
																													case 75:
																													case 167:
																														goto IL_1374_2;
																													case 129:
																														goto IL_139d_2;
																													case 203:
																														goto IL_13ab_2;
																													case 62:
																														goto IL_13c7_2;
																													case 27:
																													case 139:
																														goto IL_13d2_2;
																													case 90:
																														goto IL_1404_2;
																													case 81:
																														goto IL_141d_2;
																													case 248:
																														goto IL_142b_2;
																													case 43:
																													case 110:
																														goto IL_1439_2;
																													case 274:
																														goto IL_1479_2;
																													case 272:
																														goto IL_148d_2;
																													case 297:
																														goto IL_14a0_2;
																													case 65:
																														goto IL_14ae_2;
																													case 206:
																													case 289:
																														goto IL_14b9_2;
																													case 283:
																														goto IL_14d5_2;
																													case 109:
																														goto IL_14e3_2;
																													case 51:
																													case 256:
																														goto end_IL_0503_2;
																													case 233:
																														goto IL_151a_2;
																													case 302:
																														goto IL_1528_2;
																													case 94:
																														goto IL_1538_2;
																													case 96:
																														goto IL_1543_2;
																													case 47:
																													case 124:
																														goto IL_154e_2;
																													case 179:
																														goto IL_157c_2;
																													case 12:
																														goto IL_158c_2;
																													case 125:
																														goto IL_1597_2;
																													case 21:
																													case 25:
																													case 32:
																													case 36:
																													case 44:
																													case 54:
																													case 57:
																													case 58:
																													case 69:
																													case 70:
																													case 71:
																													case 78:
																													case 80:
																													case 82:
																													case 84:
																													case 97:
																													case 102:
																													case 106:
																													case 132:
																													case 144:
																													case 145:
																													case 162:
																													case 166:
																													case 182:
																													case 184:
																													case 197:
																													case 201:
																													case 202:
																													case 212:
																													case 219:
																													case 223:
																													case 224:
																													case 247:
																													case 261:
																													case 264:
																													case 268:
																													case 290:
																													case 298:
																													case 303:
																														goto end_IL_05c3_2;
																													case 9:
																													case 13:
																													case 14:
																													case 22:
																													case 23:
																													case 24:
																													case 30:
																													case 31:
																													case 40:
																													case 49:
																													case 73:
																													case 98:
																													case 101:
																													case 104:
																													case 112:
																													case 113:
																													case 123:
																													case 136:
																													case 146:
																													case 147:
																													case 186:
																													case 188:
																													case 189:
																													case 214:
																													case 215:
																													case 218:
																													case 229:
																													case 234:
																													case 240:
																													case 243:
																													case 246:
																													case 252:
																													case 253:
																													case 257:
																													case 265:
																													case 278:
																													case 293:
																													case 296:
																													case 300:
																														goto IL_15b5_2;
																													case 16:
																														ptr2 = ptr;
																														goto IL_15b5_2;
																													case 280:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AuthorizationRuleCollectionCalendarHijri.HostExecutionContextSwitcherMTA);
																														num = 16;
																														goto case 16;
																													case 220:
																														array7[0] = this;
																														goto case 280;
																													case 83:
																														array7 = new object[22];
																														goto case 220;
																													case 196:
																														array6 = new long[4];
																														goto case 83;
																													case 207:
																														array5 = new int[6];
																														goto case 196;
																													case 52:
																														array4 = new int[4];
																														goto case 207;
																													case 198:
																														array3 = new object[4];
																														goto case 52;
																													case 131:
																													case 150:
																														array2 = new byte[4];
																														goto case 198;
																													case 154:
																														num3 = num2 * 4;
																														goto case 131;
																													case 235:
																														num2 = 1;
																														goto case 154;
																													case 236:
																														goto end_IL_0beb;
																													case 216:
																													case 217:
																														return;
																													}
																													continue;
																												}
																												num5++;
																												goto IL_0830_2;
																												IL_0830_2:
																												ptr2 += 8;
																												goto IL_15b5_2;
																												continue;
																												end_IL_0503_2:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_05fe_2;
																							IL_0801_2:
																							ptr2 += 8;
																							goto IL_080f_2;
																							IL_080f_2:
																							num5--;
																							goto IL_15b5_2;
																							IL_05fe_2:
																							if (2 < b)
																							{
																								goto IL_067a_2;
																							}
																							goto IL_06f9_2;
																							IL_06f9_2:
																							if (2 <= b)
																							{
																								goto IL_0704_2;
																							}
																							goto IL_076b_2;
																							IL_0704_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0744_2;
																							IL_0744_2:
																							array2[num5 - 2] = 0;
																							goto IL_0758_2;
																							IL_0758_2:
																							num5--;
																							goto IL_15b5_2;
																							IL_076b_2:
																							if (1 < b)
																							{
																								goto end_IL_05c3_2;
																							}
																							goto IL_0779_2;
																							IL_0779_2:
																							if (1 > b)
																							{
																								goto end_IL_05c3_2;
																							}
																							goto IL_0787_2;
																							IL_0787_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																							goto IL_07a0_2;
																							IL_07a0_2:
																							array2[num5] = 0;
																							goto IL_07ae_2;
																							IL_07ae_2:
																							num5++;
																							goto IL_07bc_2;
																							IL_07bc_2:
																							ptr2 += 8;
																							goto IL_15b5_2;
																							IL_067a_2:
																							if (3 < b)
																							{
																								goto end_IL_05c3_2;
																							}
																							goto IL_0688_2;
																							IL_0688_2:
																							if (3 > b)
																							{
																								goto end_IL_05c3_2;
																							}
																							goto IL_07cf_2;
																							IL_07cf_2:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							num = 195;
																							goto IL_0801_2;
																						}
																						break;
																					}
																					goto IL_0843_2;
																					IL_09db_2:
																					if (8 < b)
																					{
																						goto end_IL_05c3_2;
																					}
																					goto IL_09e9_2;
																					IL_0843_2:
																					if (6 >= b)
																					{
																						goto IL_0851_2;
																					}
																					goto IL_0952_2;
																					IL_0851_2:
																					if (6 > b)
																					{
																						goto IL_085f_2;
																					}
																					num = 161;
																					goto IL_08eb_2;
																					IL_085f_2:
																					if (5 < b)
																					{
																						goto end_IL_05c3_2;
																					}
																					goto IL_086d_2;
																					IL_086d_2:
																					if (5 > b)
																					{
																						goto end_IL_05c3_2;
																					}
																					goto IL_087b_2;
																					IL_087b_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_08bb_2;
																					IL_08bb_2:
																					array2[num5 - 2] = 0;
																					goto IL_08cf_2;
																					IL_08cf_2:
																					num5--;
																					goto IL_15b5_2;
																					IL_09e9_2:
																					if (8 > b)
																					{
																						goto end_IL_05c3_2;
																					}
																					goto IL_09f7_2;
																					IL_08eb_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_092b_2;
																					IL_092b_2:
																					array2[num5 - 2] = 0;
																					goto IL_093f_2;
																					IL_093f_2:
																					num5--;
																					goto IL_15b5_2;
																					IL_0952_2:
																					if (7 >= b)
																					{
																						num = 2;
																						goto IL_0966_2;
																					}
																					goto IL_09db_2;
																					IL_09f7_2:
																					num5--;
																					goto IL_15b5_2;
																					IL_0966_2:
																					if (7 > b)
																					{
																						goto end_IL_05c3_2;
																					}
																					goto IL_0974_2;
																					IL_0974_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_09b4_2;
																					IL_09b4_2:
																					array2[num5 - 2] = 0;
																					goto IL_09c8_2;
																					IL_09c8_2:
																					num5--;
																					goto IL_15b5_2;
																				}
																				break;
																			}
																			goto IL_060e_2;
																			IL_069b_2:
																			num5--;
																			goto IL_15b5_2;
																			IL_060e_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_064e_2;
																			IL_064e_2:
																			array2[num5 - 2] = 0;
																			goto IL_069b_2;
																		}
																		break;
																	}
																	goto IL_0a0a_2;
																	IL_0d71_2:
																	array4[num5 - 0] = array4[num5 - 1];
																	goto IL_0d8f_2;
																	IL_0d8f_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	num = 19;
																	goto IL_0dbc_2;
																	IL_0a0a_2:
																	if (13 >= b)
																	{
																		goto IL_0a18_2;
																	}
																	goto IL_0c0c_2;
																	IL_0a18_2:
																	if (13 <= b)
																	{
																		goto IL_0a23_2;
																	}
																	goto IL_0a62_2;
																	IL_0a23_2:
																	array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																	goto IL_0a41_2;
																	IL_0a41_2:
																	ptr2 += 8;
																	goto IL_0a4f_2;
																	IL_0a4f_2:
																	num5--;
																	goto IL_15b5_2;
																	IL_0a62_2:
																	if (11 >= b)
																	{
																		goto IL_0a70_2;
																	}
																	goto IL_0b0f_2;
																	IL_0a70_2:
																	if (11 <= b)
																	{
																		goto IL_15b5_2;
																	}
																	goto IL_0a7e_2;
																	IL_0a7e_2:
																	if (10 < b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0a8c_2;
																	IL_0a8c_2:
																	if (10 > b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0a9a_2;
																	IL_0a9a_2:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0afc_2;
																	IL_0afc_2:
																	num5 -= 2;
																	goto IL_15b5_2;
																	IL_0b0f_2:
																	if (12 < b)
																	{
																		goto end_IL_05c3_2;
																	}
																	num = 175;
																	goto IL_0b26_2;
																	IL_0dbc_2:
																	array3[num5] = array3[num5 - 1];
																	goto IL_0dd4_2;
																	IL_0b26_2:
																	if (12 > b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0b34_2;
																	IL_0b34_2:
																	array8 = array3;
																	num6 = num5;
																	if (array == null)
																	{
																		goto IL_0b43_2;
																	}
																	goto IL_0b51;
																	IL_0c0c_2:
																	if (15 < b)
																	{
																		goto IL_0c1a_2;
																	}
																	num = 258;
																	goto IL_0cf0_2;
																	IL_0c1a_2:
																	if (16 >= b)
																	{
																		goto IL_0c25_2;
																	}
																	goto IL_0c7a_2;
																	IL_0c25_2:
																	if (16 > b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0c33_2;
																	IL_0c33_2:
																	array2[num5] = 5;
																	goto IL_0c41_2;
																	IL_0c41_2:
																	array3[num5] = array7[*(int*)(ptr2 + num3)];
																	goto IL_0c59_2;
																	IL_0c59_2:
																	num5++;
																	goto IL_0c67_2;
																	IL_0c67_2:
																	ptr2 += 8;
																	goto IL_15b5_2;
																	IL_0c7a_2:
																	if (17 < b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0c88_2;
																	IL_0c88_2:
																	if (17 > b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0c96_2;
																	IL_0c96_2:
																	((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																	goto IL_0cd4_2;
																	IL_0cd4_2:
																	num5 -= 3;
																	goto IL_15b5_2;
																	IL_0dd4_2:
																	num5++;
																	goto IL_15b5_2;
																	IL_0cf0_2:
																	if (15 > b)
																	{
																		goto IL_0cfb_2;
																	}
																	goto IL_0d59_2;
																	IL_0cfb_2:
																	if (14 < b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0d09_2;
																	IL_0d09_2:
																	if (14 > b)
																	{
																		goto end_IL_05c3_2;
																	}
																	goto IL_0d17_2;
																	IL_0d17_2:
																	array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																	goto IL_0d40_2;
																	IL_0d40_2:
																	array2[num5 - 1] = 5;
																	goto IL_15b5_2;
																	IL_0d59_2:
																	array2[num5] = array2[num5 - 1];
																	goto IL_0d71_2;
																}
																break;
															}
															goto IL_0664_2;
															IL_06e6_2:
															ptr2 += 8;
															goto IL_15b5_2;
															IL_0664_2:
															array2[num5 - 1] = 5;
															goto IL_06ae_2;
															IL_06ae_2:
															array3[num5 - 1] = ((delegate*<string[], string>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
															goto IL_06e6_2;
														}
														goto IL_14f1_2;
														IL_1543_2:
														if (35 > b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_154e_2;
														IL_0de7_2:
														if (27 >= b)
														{
															goto IL_0df5_2;
														}
														goto IL_1249_2;
														IL_0df5_2:
														if (27 <= b)
														{
															goto IL_0e00_2;
														}
														goto IL_0e66_2;
														IL_0e00_2:
														array2[num5 - 1] = 3;
														goto IL_0e14_2;
														IL_0e14_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<float, float>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])));
														goto IL_0e53_2;
														IL_0e53_2:
														ptr2 += 8;
														goto IL_15b5_2;
														IL_0e66_2:
														if (22 >= b)
														{
															goto IL_0e74_2;
														}
														goto IL_1045_2;
														IL_0e74_2:
														if (22 > b)
														{
															goto IL_0e82_2;
														}
														goto IL_0fea_2;
														IL_0e82_2:
														if (20 >= b)
														{
															goto IL_0e90_2;
														}
														goto IL_0f7b_2;
														IL_0e90_2:
														if (20 <= b)
														{
															goto IL_0e9b_2;
														}
														goto IL_0f0c_2;
														IL_0e9b_2:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0ef9_2;
														IL_0ef9_2:
														num5--;
														goto IL_15b5_2;
														IL_0f0c_2:
														if (19 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_0f1a_2;
														IL_0f1a_2:
														if (19 > b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_0f28_2;
														IL_0f28_2:
														array2[num5] = 0;
														goto IL_0f36_2;
														IL_0f36_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_0f5a_2;
														IL_0f5a_2:
														num5++;
														goto IL_0f68_2;
														IL_0f68_2:
														ptr2 += 8;
														goto IL_15b5_2;
														IL_0f7b_2:
														if (21 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_0f89_2;
														IL_0f89_2:
														if (21 > b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_0f97_2;
														IL_0f97_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<float>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])();
														goto IL_0fbb_2;
														IL_0fbb_2:
														array2[num5] = 3;
														goto IL_0fc9_2;
														IL_0fc9_2:
														num5++;
														goto IL_0fd7_2;
														IL_0fd7_2:
														ptr2 += 8;
														goto IL_15b5_2;
														IL_0fea_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(float*)(ptr2 + num3);
														num = 66;
														goto IL_100d_2;
														IL_100d_2:
														array2[num5] = 3;
														goto IL_101b_2;
														IL_101b_2:
														num5++;
														goto IL_1029_2;
														IL_1029_2:
														ptr2 += 8;
														num = 188;
														goto IL_15b5_2;
														IL_1045_2:
														if (24 >= b)
														{
															goto IL_1053_2;
														}
														goto IL_1120_2;
														IL_1053_2:
														if (24 <= b)
														{
															goto IL_105e_2;
														}
														goto IL_108b_2;
														IL_105e_2:
														Class147.float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_1078_2;
														IL_1078_2:
														num5--;
														goto IL_15b5_2;
														IL_108b_2:
														if (23 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_1099_2;
														IL_1099_2:
														if (23 > b)
														{
															goto end_IL_05c3_2;
														}
														num = 237;
														goto IL_10b0_2;
														IL_154e_2:
														((Class148)array3[num5 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_157c_2;
														IL_10b0_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_10f0_2;
														IL_10f0_2:
														array2[num5 - 2] = 3;
														num = 63;
														goto IL_110d_2;
														IL_110d_2:
														num5--;
														goto IL_15b5_2;
														IL_1120_2:
														if (25 >= b)
														{
															goto IL_112e_2;
														}
														goto IL_11bd_2;
														IL_112e_2:
														if (25 > b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_113c_2;
														IL_113c_2:
														ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_11aa_2;
														IL_11aa_2:
														num5 -= 2;
														goto IL_15b5_2;
														IL_11bd_2:
														if (26 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_11cb_2;
														IL_11cb_2:
														if (26 > b)
														{
															goto end_IL_05c3_2;
														}
														num = 20;
														goto IL_11e2_2;
														IL_157c_2:
														num5 -= 2;
														goto IL_15b5_2;
														IL_11e2_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_1222_2;
														IL_1222_2:
														array2[num5 - 2] = 3;
														goto IL_1236_2;
														IL_1236_2:
														num5--;
														goto IL_15b5_2;
														IL_1249_2:
														if (32 >= b)
														{
															goto IL_1257_2;
														}
														goto IL_14a0_2;
														IL_1257_2:
														if (32 <= b)
														{
															goto IL_1262_2;
														}
														goto IL_12a9_2;
														IL_1262_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_127a_2;
														IL_127a_2:
														array2[num5] = 5;
														goto IL_1288_2;
														IL_1288_2:
														num5++;
														goto IL_1296_2;
														IL_1296_2:
														ptr2 += 8;
														goto IL_15b5_2;
														IL_12a9_2:
														if (29 < b)
														{
															goto IL_12b7_2;
														}
														num = 62;
														goto IL_13c7_2;
														IL_12b7_2:
														if (30 >= b)
														{
															goto IL_12c5_2;
														}
														goto IL_1358_2;
														IL_12c5_2:
														if (30 > b)
														{
															goto end_IL_05c3_2;
														}
														num = 155;
														goto IL_12dc_2;
														IL_1597_2:
														if (36 <= b)
														{
														}
														goto end_IL_05c3_2;
														IL_12dc_2:
														array2[num5 - 2] = 5;
														goto IL_12f0_2;
														IL_12f0_2:
														array3[num5 - 2] = ((delegate*<string, object, string>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
														goto IL_1337_2;
														IL_1337_2:
														num5--;
														goto IL_1345_2;
														IL_1345_2:
														ptr2 += 8;
														goto IL_15b5_2;
														IL_1358_2:
														if (31 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_1366_2;
														IL_1366_2:
														if (31 > b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_1374_2;
														IL_1374_2:
														((delegate*<string, void>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
														goto IL_139d_2;
														IL_139d_2:
														num5--;
														goto IL_13ab_2;
														IL_13ab_2:
														ptr2 += 8;
														goto IL_15b5_2;
														IL_158c_2:
														if (36 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_1597_2;
														IL_13c7_2:
														if (29 <= b)
														{
															goto IL_13d2_2;
														}
														goto IL_141d_2;
														IL_13d2_2:
														array3[num5 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														num = 90;
														goto IL_1404_2;
														IL_1404_2:
														array2[num5 - 1] = 5;
														goto IL_15b5_2;
														IL_141d_2:
														if (28 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_142b_2;
														IL_142b_2:
														if (28 > b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_1439_2;
														IL_1439_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_1479_2;
														IL_1479_2:
														array2[num5 - 2] = 3;
														goto IL_148d_2;
														IL_148d_2:
														num5--;
														goto IL_15b5_2;
														IL_14a0_2:
														if (34 >= b)
														{
															goto IL_14ae_2;
														}
														goto IL_1538_2;
														IL_14ae_2:
														if (34 <= b)
														{
															goto IL_14b9_2;
														}
														goto IL_14d5_2;
														IL_14b9_2:
														num9 = ptr2;
														num10 = -200;
														num4 = 1;
														ptr2 = num9 + num10;
														goto IL_15b5_2;
														IL_14d5_2:
														if (33 < b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_14e3_2;
														IL_14e3_2:
														if (33 > b)
														{
															goto end_IL_05c3_2;
														}
														goto IL_14f1_2;
														IL_14f1_2:
														((delegate*<UnityEngine.Object, void>)getTreatControlCAsInputGetFieldFromHandle[*(int*)(ptr2 + num3)])((Class148)array3[num5 - 1]);
														goto IL_151a_2;
														IL_151a_2:
														num5--;
														goto IL_1528_2;
														IL_1528_2:
														ptr2 += 8;
														goto IL_15b5_2;
														IL_1538_2:
														if (35 >= b)
														{
															goto IL_1543_2;
														}
														goto IL_158c_2;
														continue;
														end_IL_05b3_2:
														break;
													}
													continue;
													end_IL_05c3_2:
													break;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_15b5_2;
											continue;
											end_IL_05d3_2:
											break;
										}
										continue;
										end_IL_05e3:
										break;
									}
									continue;
									end_IL_05f3:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0beb:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 54;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 30;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											num = 21;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TablesUtils.IsCanceledBindType);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 11;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 2;
																	while (true)
																	{
																		IL_023f:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_021f:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_020f:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_01ff:
																									if (2 < b)
																									{
																										while (true)
																										{
																											IL_01ef:
																											if (3 >= b)
																											{
																												while (true)
																												{
																													IL_01dc:
																													if (3 > b)
																													{
																														num = 107;
																														while (num != 107)
																														{
																															if (num != 1088)
																															{
																																goto IL_0350;
																															}
																															switch (num)
																															{
																															case 36:
																																goto IL_01dc;
																															case 0:
																																goto IL_01ef;
																															case 18:
																															case 27:
																																goto IL_01ff;
																															case 51:
																																goto IL_020f;
																															case 12:
																																goto IL_021f;
																															case 84:
																																goto IL_022f;
																															case 2:
																																goto IL_023f;
																															case 75:
																																goto end_IL_023f;
																															case 46:
																															case 60:
																																goto end_IL_024f;
																															case 7:
																															case 45:
																																goto IL_0273;
																															case 80:
																																goto IL_029c;
																															case 69:
																																goto IL_02aa;
																															case 97:
																																goto IL_02bd;
																															case 16:
																															case 82:
																																goto IL_02c8;
																															case 56:
																																goto IL_0308;
																															case 74:
																																goto IL_031c;
																															case 26:
																																goto IL_032f;
																															case 38:
																																goto IL_033d;
																															case 32:
																															case 71:
																																goto IL_0350;
																															case 83:
																																goto IL_035e;
																															case 62:
																															case 95:
																																goto IL_036c;
																															case 50:
																																goto IL_03ac;
																															case 5:
																																goto IL_03c0;
																															case 1:
																															case 55:
																																goto IL_03d3;
																															case 31:
																																goto IL_03e1;
																															case 28:
																																goto IL_0404;
																															case 99:
																																goto IL_040e;
																															case 23:
																																goto IL_041c;
																															case 81:
																																goto IL_042f;
																															case 22:
																																goto IL_043d;
																															case 47:
																															case 73:
																																goto IL_0448;
																															case 14:
																																goto IL_0461;
																															case 90:
																																goto IL_046f;
																															case 19:
																																goto IL_047d;
																															case 94:
																																goto IL_0490;
																															case 63:
																																goto IL_049e;
																															case 43:
																															case 87:
																																goto IL_04ac;
																															case 39:
																																goto IL_04ec;
																															case 49:
																																goto IL_0500;
																															case 24:
																																goto IL_0513;
																															case 61:
																																goto IL_051e;
																															case 35:
																																goto IL_052c;
																															case 68:
																															case 78:
																																goto IL_053a;
																															case 100:
																																goto IL_0556;
																															case 9:
																															case 89:
																																goto IL_0561;
																															case 33:
																																goto IL_05a1;
																															case 86:
																																goto IL_05b5;
																															case 6:
																															case 15:
																															case 20:
																															case 40:
																															case 44:
																															case 48:
																															case 57:
																															case 58:
																															case 70:
																															case 76:
																															case 77:
																															case 79:
																															case 85:
																															case 91:
																															case 92:
																																goto end_IL_01c9;
																															case 37:
																																goto IL_05e8;
																															case 13:
																																goto IL_05f6;
																															case 72:
																																goto IL_0604;
																															case 3:
																															case 4:
																															case 8:
																															case 10:
																															case 11:
																															case 42:
																															case 52:
																															case 65:
																															case 88:
																															case 96:
																															case 98:
																																goto end_IL_0268;
																															case 67:
																																goto end_IL_061b;
																															case 21:
																																goto end_IL_062e;
																															case 29:
																																goto end_IL_0641;
																															case 59:
																																goto end_IL_064c;
																															case 93:
																																goto end_IL_066a;
																															case 25:
																															case 66:
																																goto end_IL_067f;
																															case 41:
																																goto end_IL_068f;
																															case 30:
																																goto end_IL_069f;
																															case 17:
																																goto end_IL_06af;
																															case 53:
																																goto end_IL_06bf;
																															case 54:
																																goto end_IL_06ca;
																															case 34:
																															case 64:
																																goto IL_06e5;
																															}
																															continue;
																															end_IL_01c9:
																															break;
																														}
																														break;
																													}
																													goto IL_0273;
																													IL_029c:
																													ptr2 += 8;
																													goto IL_02aa;
																													IL_02aa:
																													num5--;
																													goto end_IL_0268;
																													IL_0273:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_029c;
																												}
																												break;
																											}
																											goto IL_0350;
																											IL_03c0:
																											num5--;
																											goto end_IL_0268;
																											IL_0350:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_035e;
																											IL_035e:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_036c;
																											IL_036c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_03ac;
																											IL_03ac:
																											array[num5 - 2] = 0;
																											goto IL_03c0;
																										}
																										break;
																									}
																									goto IL_02bd;
																									IL_033d:
																									if (1 <= b)
																									{
																									}
																									break;
																									IL_02bd:
																									if (2 <= b)
																									{
																										goto IL_02c8;
																									}
																									goto IL_032f;
																									IL_02c8:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0308;
																									IL_0308:
																									array[num5 - 2] = 0;
																									goto IL_031c;
																									IL_031c:
																									num5--;
																									goto end_IL_0268;
																									IL_032f:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_033d;
																								}
																								break;
																							}
																							goto IL_03d3;
																							IL_041c:
																							ptr2 += 8;
																							goto end_IL_0268;
																							IL_03d3:
																							array[num5] = 0;
																							goto IL_03e1;
																							IL_03e1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0404;
																							IL_0404:
																							array2[num5] = null;
																							goto IL_040e;
																							IL_040e:
																							num5++;
																							goto IL_041c;
																						}
																						break;
																					}
																					goto IL_042f;
																					IL_05b5:
																					num5--;
																					goto end_IL_0268;
																					IL_042f:
																					if (7 >= b)
																					{
																						goto IL_043d;
																					}
																					goto IL_0513;
																					IL_043d:
																					if (7 <= b)
																					{
																						goto IL_0448;
																					}
																					goto IL_0490;
																					IL_0448:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0461;
																					IL_0461:
																					array[num5] = 0;
																					goto IL_046f;
																					IL_046f:
																					num5++;
																					goto IL_047d;
																					IL_047d:
																					ptr2 += 8;
																					goto end_IL_0268;
																					IL_0490:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_049e;
																					IL_049e:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_04ac;
																					IL_04ac:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04ec;
																					IL_04ec:
																					array[num5 - 2] = 0;
																					goto IL_0500;
																					IL_0500:
																					num5--;
																					goto end_IL_0268;
																					IL_0513:
																					if (8 < b)
																					{
																						goto IL_051e;
																					}
																					goto IL_0556;
																					IL_051e:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_052c;
																					IL_052c:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_053a;
																					IL_053a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0268;
																					IL_0556:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0561;
																					IL_0561:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05a1;
																					IL_05a1:
																					array[num5 - 2] = 0;
																					goto IL_05b5;
																				}
																				break;
																				IL_022f:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05e8;
																		IL_0604:
																		ptr2 += 8;
																		num = 88;
																		goto end_IL_0268;
																		IL_05f6:
																		num5++;
																		goto IL_0604;
																		IL_05e8:
																		array[num5] = 0;
																		goto IL_05f6;
																		continue;
																		end_IL_023f:
																		break;
																	}
																	continue;
																	end_IL_024f:
																	break;
																}
																continue;
																end_IL_0268:
																break;
															}
															continue;
														}
														goto IL_06e5;
														IL_06e5:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_061b:
														break;
													}
													continue;
													end_IL_062e:
													break;
												}
												continue;
												end_IL_0641:
												break;
											}
											continue;
											end_IL_064c:
											break;
										}
										continue;
										end_IL_066a:
										break;
									}
									continue;
									end_IL_067f:
									break;
								}
								continue;
								end_IL_068f:
								break;
							}
							continue;
							end_IL_069f:
							break;
						}
						continue;
						end_IL_06af:
						break;
					}
					continue;
					end_IL_06bf:
					break;
				}
				continue;
				end_IL_06ca:
				break;
			}
		}
	}

	private static float CharSetNotSpecGetEnumeratorDelegate()
	{
		return Time.time;
	}

	private static float getUnmanagedCodeFUNCFLAGFIMMEDIATEBIND(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.leftControllerIndexFloat;
	}

	private static double getIsNestedPublicsetHelpLink(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static int SecurityAttributeDESCUNION(int int_1)
	{
		return smethod_1(int_1);
	}

	private static int smethod_3(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe void Update()
	{
		int num = 4;
		int num3 = default(int);
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			num = 14;
			while (true)
			{
				if (num != 14)
				{
					if (num != 995)
					{
						return;
					}
					switch (num)
					{
					case 4:
						goto end_IL_0044;
					case 7:
						goto IL_006b;
					case 2:
						goto IL_0070;
					case 3:
					case 5:
						goto IL_00be;
					case 1:
						goto IL_00c4;
					case 0:
					case 6:
						return;
					}
					continue;
				}
				num3 = 0;
				num = 7;
				goto IL_006b;
				IL_00be:
				if (num3 != 45)
				{
					goto IL_0070;
				}
				goto IL_00c4;
				IL_0070:
				((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, Class148, void>)LookForMyCallerLargeObjectHeapCompactionMode[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref num11, this);
				goto IL_00be;
				IL_00c4:
				num3 = 0;
				return;
				IL_006b:
				num3 = 0;
				goto IL_00be;
				continue;
				end_IL_0044:
				break;
			}
		}
	}

	private static float TrySetResultApplicationTrust()
	{
		return Class147.float_0;
	}

	private static int OrderablePartitionerMapToCollectionAdapter(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static float DecoderUTFFallbackBufferAddAlgorithm(Class148 class148_1)
	{
		return class148_1.float_1;
	}

	private static string getMutexRightsAssemblyFlags(string string_0, object object_0)
	{
		return string.Format(string_0, object_0);
	}

	private static double AssignPrimarySZArrayEnumerator(double double_1)
	{
		return Math.Sin(double_1);
	}

	static Class148()
	{
		int num = 7;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 15;
			while (true)
			{
				if (num != 15)
				{
					if (num != 996)
					{
						return;
					}
					switch (num)
					{
					case 7:
						goto end_IL_0045;
					case 0:
					case 3:
						goto IL_0068;
					case 8:
						goto IL_0072;
					case 1:
						return;
					case 2:
						return;
					case 4:
						return;
					case 5:
						return;
					case 6:
						return;
					}
					continue;
				}
				Class300.smethod_0();
				goto IL_0068;
				IL_0068:
				num = 8;
				goto IL_0072;
				IL_0072:
				num = 6;
				return;
				continue;
				end_IL_0045:
				break;
			}
		}
	}

	private static float ConstructionResponseWeak()
	{
		return global::_003CModule_003E.float_105;
	}

	private static double FrameworkCulturesWaitTimeout(double double_1)
	{
		return Math.Cos(double_1);
	}

	private static float EnclosingMarkFileAssociationSection(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightControllerIndexFloat;
	}

	private unsafe static int smethod_4()
	{
		int num = 157;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 15;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RsaAnyDecimal.IsFullTypeNameSetExplicitCacheCoherencyGuid);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03d6:
														byte b = *ptr2;
														while (true)
														{
															IL_03bd:
															ptr2++;
															num = 131;
															while (true)
															{
																IL_03ad:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		num = 88;
																		while (true)
																		{
																			IL_038d:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_036d:
																						if (4 < b)
																						{
																							goto IL_0877;
																						}
																						while (true)
																						{
																							IL_035d:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_034d:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_033d:
																											if (2 <= b)
																											{
																												while (true)
																												{
																													IL_02fb:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_02dc:
																														array[num5 - 2] = 0;
																														num = 171;
																														while (true)
																														{
																															if (num != 171)
																															{
																																if (num != 1152)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 73:
																																	goto IL_02dc;
																																case 8:
																																case 75:
																																	goto IL_02fb;
																																case 14:
																																	goto IL_033d;
																																case 111:
																																	goto IL_034d;
																																case 31:
																																	goto IL_035d;
																																case 35:
																																case 46:
																																	goto IL_036d;
																																case 29:
																																	goto end_IL_036d;
																																case 88:
																																	goto IL_038d;
																																case 106:
																																	goto IL_039a;
																																case 131:
																																	goto IL_03ad;
																																case 117:
																																	goto IL_03bd;
																																case 18:
																																case 67:
																																	goto IL_03d6;
																																case 58:
																																case 61:
																																	goto IL_03e1;
																																case 22:
																																	goto IL_03ef;
																																case 41:
																																case 84:
																																	goto IL_0402;
																																case 57:
																																	goto IL_0410;
																																case 47:
																																case 71:
																																	goto IL_0427;
																																case 25:
																																case 82:
																																	goto IL_0432;
																																case 81:
																																	goto IL_0440;
																																case 13:
																																case 100:
																																	goto IL_0453;
																																case 104:
																																	goto IL_0473;
																																case 27:
																																case 109:
																																	goto IL_0483;
																																case 79:
																																case 116:
																																	goto IL_04ae;
																																case 118:
																																	goto IL_04ca;
																																case 123:
																																	goto IL_04e3;
																																case 128:
																																	goto IL_04f1;
																																case 141:
																																	goto IL_0504;
																																case 120:
																																	goto IL_0512;
																																case 97:
																																	goto IL_051d;
																																case 107:
																																	goto IL_052b;
																																case 87:
																																	goto IL_0539;
																																case 36:
																																case 130:
																																	goto IL_0547;
																																case 64:
																																	goto IL_0555;
																																case 129:
																																	goto IL_0578;
																																case 23:
																																case 52:
																																	goto IL_0590;
																																case 99:
																																	goto IL_059e;
																																case 60:
																																case 72:
																																	goto IL_05ac;
																																case 59:
																																	goto IL_05ec;
																																case 4:
																																	goto IL_0600;
																																case 10:
																																case 77:
																																	goto IL_0613;
																																case 45:
																																	goto IL_067e;
																																case 146:
																																	goto IL_0691;
																																case 155:
																																	goto IL_069f;
																																case 162:
																																	goto IL_06b2;
																																case 69:
																																case 150:
																																	goto IL_06c0;
																																case 122:
																																	goto IL_06ce;
																																case 48:
																																case 94:
																																	goto IL_06e7;
																																case 147:
																																	goto IL_0704;
																																case 142:
																																	goto IL_0758;
																																case 127:
																																	goto IL_0766;
																																case 119:
																																case 135:
																																	goto IL_0779;
																																case 17:
																																case 164:
																																	goto IL_0795;
																																case 56:
																																	goto IL_07d9;
																																case 70:
																																	goto IL_07ed;
																																case 133:
																																case 139:
																																	goto IL_0813;
																																case 19:
																																	goto IL_0821;
																																case 98:
																																case 144:
																																	goto IL_082f;
																																case 158:
																																	goto IL_0848;
																																case 44:
																																	goto IL_0856;
																																case 159:
																																	goto IL_0864;
																																case 38:
																																case 161:
																																	goto IL_0877;
																																case 149:
																																	goto IL_0885;
																																case 136:
																																case 160:
																																	goto IL_0890;
																																case 30:
																																	goto IL_08cf;
																																case 74:
																																	goto IL_08e2;
																																case 6:
																																	goto IL_08f0;
																																case 89:
																																case 102:
																																	goto IL_08fe;
																																case 62:
																																	goto IL_090c;
																																case 39:
																																	goto IL_092d;
																																case 9:
																																	goto IL_093b;
																																case 55:
																																	goto IL_094e;
																																case 34:
																																case 65:
																																	goto IL_0959;
																																case 78:
																																	goto IL_0964;
																																case 0:
																																case 54:
																																	goto IL_096f;
																																case 37:
																																	goto IL_098f;
																																case 93:
																																case 151:
																																	goto end_IL_02c9;
																																case 124:
																																	goto IL_09c3;
																																case 95:
																																	goto IL_09d1;
																																case 1:
																																case 2:
																																case 7:
																																case 20:
																																case 26:
																																case 28:
																																case 33:
																																case 40:
																																case 42:
																																case 43:
																																case 49:
																																case 50:
																																case 63:
																																case 76:
																																case 80:
																																case 83:
																																case 85:
																																case 101:
																																case 105:
																																case 114:
																																case 132:
																																case 137:
																																case 138:
																																case 143:
																																case 148:
																																case 153:
																																case 154:
																																case 163:
																																	goto end_IL_039a;
																																case 3:
																																case 5:
																																case 11:
																																case 12:
																																case 24:
																																case 32:
																																case 66:
																																case 68:
																																case 86:
																																case 91:
																																case 92:
																																case 96:
																																case 103:
																																case 110:
																																case 112:
																																case 113:
																																case 125:
																																case 134:
																																case 140:
																																case 152:
																																	goto end_IL_037d;
																																case 51:
																																	goto end_IL_09f4;
																																case 53:
																																	goto end_IL_0a07;
																																case 115:
																																	goto end_IL_0a11;
																																case 21:
																																	goto end_IL_0a1c;
																																case 121:
																																case 126:
																																	goto end_IL_0a2c;
																																case 90:
																																	goto end_IL_0a3c;
																																case 15:
																																case 145:
																																	goto end_IL_0a4c;
																																case 156:
																																	goto end_IL_0a5c;
																																case 157:
																																	goto end_IL_0a6c;
																																case 16:
																																case 108:
																																	goto IL_0a99;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_037d;
																															continue;
																															end_IL_02c9:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0813;
																											IL_0864:
																											ptr2 += 8;
																											goto end_IL_037d;
																											IL_0813:
																											if (1 < b)
																											{
																												goto end_IL_039a;
																											}
																											goto IL_0821;
																											IL_0821:
																											if (1 > b)
																											{
																												goto end_IL_039a;
																											}
																											goto IL_082f;
																											IL_082f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0848;
																											IL_0848:
																											array[num5] = 0;
																											goto IL_0856;
																											IL_0856:
																											num5++;
																											goto IL_0864;
																										}
																										break;
																									}
																									goto IL_03e1;
																									IL_04ca:
																									array[num5 - 1] = 5;
																									goto end_IL_037d;
																									IL_03e1:
																									if (3 < b)
																									{
																										goto end_IL_039a;
																									}
																									goto IL_03ef;
																									IL_03ef:
																									if (3 > b)
																									{
																										goto end_IL_039a;
																									}
																									goto IL_0483;
																									IL_0483:
																									array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_04ca;
																								}
																								break;
																							}
																							goto IL_0453;
																							IL_04f1:
																							num5--;
																							goto end_IL_037d;
																							IL_0453:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_04e3;
																							IL_04e3:
																							ptr2 += 8;
																							goto IL_04f1;
																						}
																						goto IL_099a;
																						IL_09c3:
																						ptr2 += 8;
																						goto IL_09d1;
																						IL_0877:
																						if (6 >= b)
																						{
																							goto IL_0885;
																						}
																						goto IL_094e;
																						IL_0885:
																						if (6 <= b)
																						{
																							goto IL_0890;
																						}
																						goto IL_08e2;
																						IL_0890:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_08cf;
																						IL_08cf:
																						num5 -= 3;
																						goto end_IL_037d;
																						IL_08e2:
																						if (5 < b)
																						{
																							goto end_IL_039a;
																						}
																						goto IL_08f0;
																						IL_08f0:
																						if (5 > b)
																						{
																							goto end_IL_039a;
																						}
																						goto IL_08fe;
																						IL_08fe:
																						array[num5] = 5;
																						goto IL_090c;
																						IL_090c:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						num = 39;
																						goto IL_092d;
																						IL_092d:
																						num5++;
																						goto IL_093b;
																						IL_093b:
																						ptr2 += 8;
																						goto end_IL_037d;
																						IL_094e:
																						if (7 < b)
																						{
																							goto IL_0959;
																						}
																						goto IL_098f;
																						IL_0959:
																						if (8 < b)
																						{
																							goto end_IL_039a;
																						}
																						goto IL_0964;
																						IL_0964:
																						if (8 > b)
																						{
																							num = 85;
																							goto end_IL_039a;
																						}
																						goto IL_096f;
																						IL_096f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_037d;
																						IL_09d1:
																						num5--;
																						goto end_IL_037d;
																						IL_098f:
																						if (7 > b)
																						{
																							goto end_IL_039a;
																						}
																						goto IL_099a;
																						IL_099a:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_09c3;
																						continue;
																						end_IL_036d:
																						break;
																					}
																					continue;
																					end_IL_037d:
																					break;
																				}
																				break;
																			}
																			goto IL_0402;
																			IL_05ec:
																			array[num5 - 2] = 0;
																			goto IL_0600;
																			IL_0402:
																			if (13 < b)
																			{
																				goto IL_0410;
																			}
																			goto IL_0504;
																			IL_0410:
																			if (15 < b)
																			{
																				num = 47;
																				goto IL_0427;
																			}
																			goto IL_06b2;
																			IL_0600:
																			num5--;
																			break;
																			IL_0427:
																			if (16 < b)
																			{
																				goto IL_0432;
																			}
																			goto IL_0473;
																			IL_0432:
																			if (17 < b)
																			{
																				goto end_IL_039a;
																			}
																			goto IL_0440;
																			IL_0440:
																			if (17 > b)
																			{
																			}
																			goto end_IL_039a;
																			IL_0473:
																			if (16 > b)
																			{
																				goto end_IL_039a;
																			}
																			goto IL_04ae;
																			IL_04ae:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_06b2:
																			if (15 > b)
																			{
																				goto IL_06c0;
																			}
																			goto IL_0779;
																			IL_06c0:
																			if (14 < b)
																			{
																				goto end_IL_039a;
																			}
																			goto IL_06ce;
																			IL_06ce:
																			if (14 > b)
																			{
																				num = 20;
																				goto end_IL_039a;
																			}
																			goto IL_06e7;
																			IL_0613:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 45;
																			goto IL_067e;
																			IL_06e7:
																			array[num5 - 2] = 0;
																			num = 147;
																			goto IL_0704;
																			IL_0704:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)OpcodeIsFromThisAppDomain[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0758;
																			IL_0758:
																			num5--;
																			goto IL_0766;
																			IL_0766:
																			ptr2 += 8;
																			break;
																			IL_0779:
																			num5--;
																			num = 32;
																			break;
																			IL_0504:
																			if (13 > b)
																			{
																				goto IL_0512;
																			}
																			goto IL_0613;
																			IL_0512:
																			if (11 >= b)
																			{
																				goto IL_051d;
																			}
																			num = 52;
																			goto IL_0590;
																			IL_051d:
																			if (11 > b)
																			{
																				goto IL_052b;
																			}
																			goto IL_0795;
																			IL_052b:
																			if (10 < b)
																			{
																				goto end_IL_039a;
																			}
																			goto IL_0539;
																			IL_0539:
																			if (10 > b)
																			{
																				goto end_IL_039a;
																			}
																			goto IL_0547;
																			IL_0547:
																			array[num5] = 0;
																			goto IL_0555;
																			IL_0555:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0578;
																			IL_0578:
																			array2[num5] = null;
																			goto IL_0691;
																			IL_0691:
																			num5++;
																			goto IL_069f;
																			IL_069f:
																			ptr2 += 8;
																			break;
																			IL_0795:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_07d9;
																			IL_07d9:
																			array[num5 - 2] = 0;
																			goto IL_07ed;
																			IL_07ed:
																			num5--;
																			break;
																			IL_067e:
																			num5 -= 2;
																			break;
																			IL_0590:
																			if (12 < b)
																			{
																				goto end_IL_039a;
																			}
																			goto IL_059e;
																			IL_059e:
																			if (12 > b)
																			{
																				goto end_IL_039a;
																			}
																			goto IL_05ac;
																			IL_05ac:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05ec;
																		}
																		goto end_IL_03ad;
																		continue;
																		end_IL_039a:
																		break;
																		IL_039a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_03ad:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 108;
												goto IL_0a99;
												IL_0a99:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09f4:
												break;
											}
											continue;
											end_IL_0a07:
											break;
										}
										continue;
										end_IL_0a11:
										break;
									}
									continue;
									end_IL_0a1c:
									break;
								}
								continue;
								end_IL_0a2c:
								break;
							}
							continue;
							end_IL_0a3c:
							break;
						}
						continue;
						end_IL_0a4c:
						break;
					}
					continue;
					end_IL_0a5c:
					break;
				}
				continue;
				end_IL_0a6c:
				break;
			}
		}
	}

	private static double UNICODESTRINGEnumFields(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static float LocalSymInfoMetadataSectionHashAlgorithm()
	{
		return Time.time;
	}

	private static ControllerInputPoller IsAnonymousConfiguration()
	{
		return ControllerInputPoller.instance;
	}

	private unsafe static int smethod_5(int int_1)
	{
		int num = 2;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 21;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							IL_06bd:
							int[] array3 = new int[4];
							while (true)
							{
								IL_06ad:
								long[] array4 = new long[3];
								while (true)
								{
									IL_0698:
									array3[0] = int_1;
									while (true)
									{
										IL_068d:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnsafePackMonitoringTotalProcessorTime.DangerousAddRefIsMailNewsDisplay);
										while (true)
										{
											IL_0683:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0670:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d8:
														byte b = *ptr2;
														while (true)
														{
															IL_02bf:
															ptr2++;
															num = 47;
															while (true)
															{
																IL_02af:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_028f:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_027f:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0272:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0262:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0252:
																											if (1 >= b)
																											{
																												while (true)
																												{
																													IL_0242:
																													if (1 <= b)
																													{
																														while (true)
																														{
																															IL_0227:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_0217:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_01fe:
																																	num5++;
																																	num = 119;
																																	while (true)
																																	{
																																		if (num != 119)
																																		{
																																			if (num != 1100)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 9:
																																				goto IL_01fe;
																																			case 76:
																																				goto IL_0217;
																																			case 28:
																																			case 31:
																																				goto IL_0227;
																																			case 51:
																																				goto IL_0242;
																																			case 107:
																																				goto IL_0252;
																																			case 67:
																																				goto IL_0262;
																																			case 101:
																																				goto IL_0272;
																																			case 98:
																																				goto IL_027f;
																																			case 55:
																																				goto IL_028f;
																																			case 83:
																																				goto IL_029f;
																																			case 47:
																																				goto IL_02af;
																																			case 40:
																																				goto IL_02bf;
																																			case 10:
																																			case 92:
																																				goto IL_02d8;
																																			case 33:
																																			case 84:
																																				goto IL_02f1;
																																			case 18:
																																			case 37:
																																				goto IL_02fc;
																																			case 54:
																																				goto IL_030a;
																																			case 29:
																																			case 32:
																																				goto IL_0318;
																																			case 24:
																																				goto IL_0328;
																																			case 91:
																																				goto IL_0344;
																																			case 43:
																																				goto IL_0367;
																																			case 94:
																																				goto IL_0371;
																																			case 75:
																																				goto IL_037f;
																																			case 81:
																																			case 109:
																																				goto IL_0392;
																																			case 85:
																																			case 110:
																																				goto IL_03aa;
																																			case 0:
																																				goto IL_03b8;
																																			case 41:
																																			case 89:
																																				goto IL_03c6;
																																			case 58:
																																				goto IL_03ef;
																																			case 71:
																																				goto IL_03fd;
																																			case 8:
																																			case 93:
																																				goto IL_0423;
																																			case 17:
																																				goto IL_0463;
																																			case 23:
																																				goto IL_0477;
																																			case 22:
																																				goto IL_0493;
																																			case 87:
																																				goto IL_04a1;
																																			case 102:
																																				goto IL_04af;
																																			case 103:
																																				goto IL_04ba;
																																			case 45:
																																			case 104:
																																				goto IL_04c8;
																																			case 56:
																																				goto IL_0508;
																																			case 30:
																																				goto IL_051c;
																																			case 69:
																																				goto IL_052f;
																																			case 60:
																																				goto IL_053d;
																																			case 78:
																																			case 112:
																																				goto IL_054b;
																																			case 95:
																																				goto IL_056e;
																																			case 20:
																																				goto IL_057c;
																																			case 50:
																																				goto IL_058a;
																																			case 7:
																																			case 34:
																																				goto IL_059d;
																																			case 4:
																																				goto IL_05ff;
																																			case 88:
																																			case 100:
																																				goto IL_0618;
																																			case 13:
																																				goto IL_0623;
																																			case 15:
																																			case 96:
																																				goto IL_062e;
																																			case 16:
																																				goto IL_0647;
																																			case 5:
																																				goto IL_0652;
																																			case 3:
																																			case 6:
																																			case 14:
																																			case 19:
																																			case 35:
																																			case 46:
																																			case 49:
																																			case 57:
																																			case 59:
																																			case 62:
																																			case 63:
																																			case 64:
																																			case 68:
																																			case 72:
																																			case 74:
																																			case 79:
																																			case 82:
																																			case 97:
																																			case 99:
																																			case 105:
																																			case 111:
																																				goto end_IL_0242;
																																			case 11:
																																			case 12:
																																			case 26:
																																			case 27:
																																			case 36:
																																			case 39:
																																			case 42:
																																			case 44:
																																			case 48:
																																			case 61:
																																			case 65:
																																			case 73:
																																			case 77:
																																			case 90:
																																				goto IL_0670;
																																			case 86:
																																				goto IL_0683;
																																			case 106:
																																				goto IL_068d;
																																			case 108:
																																				goto IL_0698;
																																			case 70:
																																				goto IL_06ad;
																																			case 52:
																																			case 66:
																																				goto IL_06bd;
																																			case 38:
																																				goto end_IL_01eb;
																																			case 21:
																																			case 25:
																																				goto end_IL_06cd;
																																			case 1:
																																				goto end_IL_06dd;
																																			case 2:
																																				goto end_IL_06ed;
																																			case 53:
																																			case 80:
																																				goto IL_0711;
																																			}
																																			continue;
																																		}
																																		ptr2 += 8;
																																		goto IL_0670;
																																		continue;
																																		end_IL_01eb:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02af;
																													}
																													num = 59;
																													break;
																													continue;
																													end_IL_0242:
																													break;
																												}
																												break;
																											}
																											goto IL_03aa;
																											IL_03fd:
																											num5--;
																											goto IL_0670;
																											IL_03aa:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_03b8;
																											IL_03b8:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_03c6;
																											IL_03c6:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_03ef;
																											IL_03ef:
																											ptr2 += 8;
																											goto IL_03fd;
																										}
																										break;
																									}
																									goto IL_0392;
																									IL_0392:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_0670;
																								}
																								break;
																							}
																							goto IL_02f1;
																							IL_0328:
																							if (4 > b)
																							{
																								num = 68;
																								break;
																							}
																							goto IL_0670;
																							IL_02f1:
																							if (4 < b)
																							{
																								goto IL_02fc;
																							}
																							goto IL_0328;
																							IL_02fc:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_030a;
																							IL_030a:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0318;
																							IL_0318:
																							array[num5] = 0;
																							goto IL_0344;
																							IL_0344:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0367;
																							IL_0367:
																							array2[num5] = null;
																							goto IL_0371;
																							IL_0371:
																							num5++;
																							goto IL_037f;
																							IL_037f:
																							ptr2 += 8;
																							goto IL_0670;
																						}
																						break;
																					}
																					goto IL_0423;
																					IL_0477:
																					num5--;
																					num = 39;
																					goto IL_0670;
																					IL_0423:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0463;
																					IL_0463:
																					array[num5 - 2] = 0;
																					goto IL_0477;
																				}
																				break;
																			}
																			goto IL_0493;
																			IL_0647:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0652;
																			IL_0493:
																			if (9 >= b)
																			{
																				goto IL_04a1;
																			}
																			num = 88;
																			goto IL_0618;
																			IL_04a1:
																			if (9 > b)
																			{
																				goto IL_04af;
																			}
																			goto IL_059d;
																			IL_04af:
																			if (7 >= b)
																			{
																				goto IL_04ba;
																			}
																			goto IL_052f;
																			IL_04ba:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04c8;
																			IL_04c8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0508;
																			IL_0508:
																			array[num5 - 2] = 0;
																			goto IL_051c;
																			IL_051c:
																			num5--;
																			goto IL_0670;
																			IL_052f:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_053d;
																			IL_053d:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_054b;
																			IL_054b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_056e;
																			IL_056e:
																			array[num5] = 0;
																			goto IL_057c;
																			IL_057c:
																			num5++;
																			goto IL_058a;
																			IL_058a:
																			ptr2 += 8;
																			goto IL_0670;
																			IL_059d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05ff;
																			IL_05ff:
																			num5 -= 2;
																			goto IL_0670;
																			IL_0652:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_0618:
																			if (10 >= b)
																			{
																				goto IL_0623;
																			}
																			goto IL_0647;
																			IL_0623:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_062e;
																			IL_062e:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_0670;
																		}
																		break;
																		IL_029f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0670;
																continue;
																end_IL_02af:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0711;
												IL_0711:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_06cd:
						break;
					}
					continue;
					end_IL_06dd:
					break;
				}
				continue;
				end_IL_06ed:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 18;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							num = 53;
							while (true)
							{
								num = 21;
								while (true)
								{
									int[] array3 = new int[3];
									while (true)
									{
										long[] array4 = new long[2];
										while (true)
										{
											array3[0] = int_1;
											while (true)
											{
												array3[1] = int_2;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ServicegetFieldType.AccessAllowedCallbackDebuggerVisualizerAttribute);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_0236:
																			if (b >= 1)
																			{
																				while (b <= 8)
																				{
																					while (true)
																					{
																						IL_0219:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_020c:
																								if (6 < b)
																								{
																									while (true)
																									{
																										IL_01fc:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_01dc:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_01ae:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 99;
																														while (true)
																														{
																															if (num != 99)
																															{
																																if (num != 1080)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 44:
																																	goto IL_01ae;
																																case 23:
																																case 72:
																																	goto IL_01dc;
																																case 70:
																																	goto IL_01ec;
																																case 86:
																																	goto IL_01fc;
																																case 2:
																																	goto IL_020c;
																																case 62:
																																	goto IL_0219;
																																case 3:
																																	goto IL_0226;
																																case 88:
																																	goto IL_0236;
																																case 13:
																																	goto end_IL_0236;
																																case 11:
																																case 69:
																																	goto end_IL_0246;
																																case 16:
																																	goto IL_0261;
																																case 38:
																																	goto IL_0274;
																																case 0:
																																case 27:
																																	goto IL_027f;
																																case 41:
																																	goto IL_02a8;
																																case 40:
																																case 63:
																																	goto IL_02b8;
																																case 52:
																																	goto IL_02c6;
																																case 65:
																																	goto IL_02d1;
																																case 56:
																																	goto IL_02df;
																																case 66:
																																	goto IL_02f2;
																																case 4:
																																case 67:
																																	goto IL_0305;
																																case 7:
																																case 79:
																																	goto IL_0318;
																																case 1:
																																	goto IL_0326;
																																case 46:
																																case 77:
																																	goto IL_0334;
																																case 37:
																																case 82:
																																	goto IL_034c;
																																case 24:
																																	goto IL_03ba;
																																case 90:
																																	goto IL_03cd;
																																case 19:
																																case 32:
																																	goto IL_03e4;
																																case 10:
																																case 91:
																																	goto IL_0400;
																																case 61:
																																	goto IL_040e;
																																case 78:
																																case 81:
																																	goto end_IL_019b;
																																case 30:
																																	goto IL_0465;
																																case 71:
																																	goto IL_0479;
																																case 89:
																																	goto IL_0493;
																																case 25:
																																	goto IL_04a1;
																																case 6:
																																case 8:
																																case 14:
																																case 17:
																																case 35:
																																case 36:
																																case 43:
																																case 45:
																																case 51:
																																case 54:
																																case 55:
																																case 58:
																																case 59:
																																case 64:
																																case 75:
																																case 80:
																																case 84:
																																case 85:
																																case 87:
																																case 92:
																																	goto end_IL_01ec;
																																case 15:
																																	goto IL_04d4;
																																case 47:
																																	goto IL_04e2;
																																case 9:
																																	goto IL_04f0;
																																case 12:
																																case 22:
																																case 26:
																																case 28:
																																case 33:
																																case 42:
																																case 49:
																																case 50:
																																case 57:
																																case 68:
																																case 76:
																																	goto end_IL_0256;
																																case 31:
																																	goto end_IL_04fe;
																																case 5:
																																	goto end_IL_0511;
																																case 60:
																																	goto end_IL_051b;
																																case 20:
																																	goto end_IL_0526;
																																case 48:
																																	goto end_IL_053b;
																																case 21:
																																	goto end_IL_0550;
																																case 53:
																																	goto end_IL_0560;
																																case 39:
																																	goto end_IL_0570;
																																case 18:
																																	goto end_IL_057b;
																																case 29:
																																	goto end_IL_0594;
																																case 73:
																																	goto end_IL_05a4;
																																case 74:
																																	goto end_IL_05af;
																																case 34:
																																case 83:
																																	goto IL_05ca;
																																}
																																continue;
																															}
																															array2[num5] = null;
																															goto IL_0493;
																															IL_0493:
																															num5++;
																															goto IL_04a1;
																															IL_04a1:
																															ptr2 += 8;
																															goto end_IL_0256;
																															continue;
																															end_IL_019b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_041c;
																												continue;
																												end_IL_01ec:
																												break;
																												IL_01ec:;
																											}
																											break;
																										}
																										goto IL_0305;
																										IL_03e4:
																										byte* num6 = ptr2;
																										num4 = 1;
																										ptr2 = num6 + -200;
																										goto end_IL_0256;
																										IL_0305:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_03cd;
																										IL_03cd:
																										if (8 > b)
																										{
																											break;
																										}
																										num = 32;
																										goto IL_03e4;
																									}
																									break;
																								}
																								goto IL_0261;
																								IL_0334:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0256;
																								IL_0261:
																								if (6 <= b)
																								{
																									goto end_IL_0256;
																								}
																								goto IL_0318;
																								IL_0318:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_0326;
																								IL_0326:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_0334;
																							}
																							break;
																						}
																						goto IL_0274;
																						IL_0479:
																						num5--;
																						goto end_IL_0256;
																						IL_0274:
																						if (4 <= b)
																						{
																							goto IL_027f;
																						}
																						goto IL_02b8;
																						IL_027f:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02a8;
																						IL_02a8:
																						ptr2 += 8;
																						goto IL_02f2;
																						IL_02f2:
																						num5--;
																						goto end_IL_0256;
																						IL_02b8:
																						if (2 >= b)
																						{
																							goto IL_02c6;
																						}
																						goto IL_0400;
																						IL_02c6:
																						if (2 > b)
																						{
																							goto IL_02d1;
																						}
																						goto IL_034c;
																						IL_02d1:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_02df;
																						IL_02df:
																						if (1 > b)
																						{
																						}
																						break;
																						IL_034c:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_03ba;
																						IL_03ba:
																						num5 -= 2;
																						goto end_IL_0256;
																						IL_0400:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_040e;
																						IL_040e:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_041c;
																						IL_041c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 30;
																						goto IL_0465;
																						IL_0465:
																						array[num5 - 2] = 0;
																						goto IL_0479;
																					}
																					break;
																					IL_0226:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04d4;
																			IL_04f0:
																			ptr2 += 8;
																			goto end_IL_0256;
																			IL_04e2:
																			num5++;
																			goto IL_04f0;
																			IL_04d4:
																			array[num5] = 0;
																			goto IL_04e2;
																			continue;
																			end_IL_0236:
																			break;
																		}
																		continue;
																		end_IL_0246:
																		break;
																	}
																	continue;
																	end_IL_0256:
																	break;
																}
																continue;
															}
															goto IL_05ca;
															IL_05ca:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															continue;
															end_IL_04fe:
															break;
														}
														continue;
														end_IL_0511:
														break;
													}
													continue;
													end_IL_051b:
													break;
												}
												continue;
												end_IL_0526:
												break;
											}
											continue;
											end_IL_053b:
											break;
										}
										continue;
										end_IL_0550:
										break;
									}
									continue;
									end_IL_0560:
									break;
								}
								continue;
								end_IL_0570:
								break;
							}
							continue;
							end_IL_057b:
							break;
						}
						continue;
						end_IL_0594:
						break;
					}
					continue;
					end_IL_05a4:
					break;
				}
				continue;
				end_IL_05af:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 49;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										IL_06c4:
										array3[1] = int_2;
										while (true)
										{
											IL_06b9:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SilverlightMakeByRefType.AddKeywordBStrWrapper);
											while (true)
											{
												IL_06af:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_069c:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0280:
															byte b = *ptr2;
															num = 108;
															while (true)
															{
																IL_0270:
																ptr2++;
																while (true)
																{
																	IL_0260:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0243:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0233:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0223:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_0213:
																										if (3 < b)
																										{
																											while (true)
																											{
																												IL_0200:
																												if (4 < b)
																												{
																													num = 116;
																													while (num != 116)
																													{
																														if (num != 1097)
																														{
																															goto end_IL_0260;
																														}
																														switch (num)
																														{
																														case 19:
																														case 97:
																															goto IL_0200;
																														case 14:
																														case 74:
																															goto IL_0213;
																														case 28:
																														case 105:
																															goto IL_0223;
																														case 85:
																															goto IL_0233;
																														case 47:
																															goto IL_0243;
																														case 67:
																															goto IL_0250;
																														case 22:
																															goto IL_0260;
																														case 108:
																															goto IL_0270;
																														case 55:
																														case 98:
																															goto IL_0280;
																														case 20:
																														case 88:
																															goto IL_0294;
																														case 10:
																														case 54:
																															goto IL_029f;
																														case 29:
																															goto IL_02aa;
																														case 43:
																															goto IL_02bd;
																														case 36:
																															goto IL_02d0;
																														case 6:
																														case 13:
																															goto IL_02de;
																														case 18:
																															goto IL_02ec;
																														case 0:
																														case 66:
																															goto IL_02fa;
																														case 52:
																															goto IL_033a;
																														case 12:
																															goto IL_0357;
																														case 94:
																															goto IL_036a;
																														case 84:
																														case 89:
																															goto IL_0378;
																														case 58:
																														case 103:
																															goto IL_0394;
																														case 24:
																															goto IL_03d4;
																														case 72:
																															goto IL_03e8;
																														case 104:
																															goto IL_03fb;
																														case 5:
																														case 7:
																															goto IL_0409;
																														case 59:
																															goto IL_0449;
																														case 4:
																															goto IL_045d;
																														case 44:
																														case 109:
																															goto IL_0470;
																														case 101:
																															goto IL_0492;
																														case 87:
																															goto IL_04a9;
																														case 75:
																															goto IL_04c0;
																														case 34:
																															goto IL_04d3;
																														case 39:
																														case 65:
																															goto IL_04e1;
																														case 46:
																															goto IL_0513;
																														case 79:
																															goto IL_052a;
																														case 86:
																															goto IL_053d;
																														case 17:
																														case 76:
																															goto IL_0548;
																														case 51:
																															goto IL_0553;
																														case 70:
																														case 90:
																															goto IL_057d;
																														case 56:
																															goto IL_05bd;
																														case 80:
																															goto IL_05da;
																														case 32:
																														case 73:
																															goto IL_05f6;
																														case 63:
																															goto IL_0604;
																														case 21:
																															goto IL_0627;
																														case 61:
																															goto IL_0631;
																														case 8:
																															goto IL_063f;
																														case 2:
																														case 9:
																														case 15:
																														case 16:
																														case 26:
																														case 31:
																														case 35:
																														case 37:
																														case 40:
																														case 53:
																														case 57:
																														case 62:
																														case 64:
																														case 77:
																														case 81:
																														case 96:
																														case 99:
																														case 102:
																														case 107:
																															goto end_IL_01ed;
																														case 38:
																															goto IL_0672;
																														case 106:
																															goto IL_0680;
																														case 68:
																															goto IL_068e;
																														case 1:
																														case 23:
																														case 25:
																														case 27:
																														case 41:
																														case 45:
																														case 69:
																														case 71:
																														case 78:
																														case 91:
																														case 95:
																															goto IL_069c;
																														case 30:
																															goto IL_06af;
																														case 93:
																															goto IL_06b9;
																														case 50:
																															goto IL_06c4;
																														case 82:
																															goto end_IL_0260;
																														case 92:
																															goto end_IL_06d9;
																														case 3:
																														case 83:
																															goto end_IL_06ee;
																														case 100:
																															goto end_IL_06fe;
																														case 11:
																														case 33:
																															goto end_IL_070e;
																														case 48:
																															goto end_IL_071e;
																														case 49:
																															goto end_IL_072e;
																														case 42:
																														case 60:
																															goto IL_0749;
																														}
																														continue;
																														end_IL_01ed:
																														break;
																													}
																													break;
																												}
																												goto IL_03fb;
																												IL_0449:
																												array[num5 - 2] = 0;
																												goto IL_045d;
																												IL_045d:
																												num5--;
																												goto IL_069c;
																												IL_03fb:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_0409;
																												IL_0409:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0449;
																											}
																											break;
																										}
																										goto IL_04d3;
																										IL_052a:
																										num5--;
																										goto IL_069c;
																										IL_04d3:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_04e1;
																										IL_04e1:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 46;
																										goto IL_0513;
																										IL_0513:
																										ptr2 += 8;
																										num = 79;
																										goto IL_052a;
																									}
																									break;
																								}
																								goto IL_053d;
																								IL_057d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05bd;
																								IL_053d:
																								if (2 > b)
																								{
																									goto IL_0548;
																								}
																								goto IL_057d;
																								IL_0548:
																								if (1 < b)
																								{
																									num = 26;
																									break;
																								}
																								goto IL_0553;
																								IL_0553:
																								if (1 > b)
																								{
																									num = 16;
																								}
																								break;
																								IL_05da:
																								num5--;
																								num = 91;
																								goto IL_069c;
																								IL_05bd:
																								array[num5 - 2] = 0;
																								num = 80;
																								goto IL_05da;
																							}
																							break;
																						}
																						goto IL_05f6;
																						IL_063f:
																						ptr2 += 8;
																						goto IL_069c;
																						IL_05f6:
																						array[num5] = 0;
																						goto IL_0604;
																						IL_0604:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0627;
																						IL_0627:
																						array2[num5] = null;
																						goto IL_0631;
																						IL_0631:
																						num5++;
																						goto IL_063f;
																					}
																					break;
																				}
																				goto IL_0294;
																				IL_04c0:
																				ptr2 += 8;
																				goto IL_069c;
																				IL_0294:
																				if (7 < b)
																				{
																					goto IL_029f;
																				}
																				goto IL_02d0;
																				IL_029f:
																				if (8 >= b)
																				{
																					goto IL_02aa;
																				}
																				goto IL_02bd;
																				IL_02aa:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0394;
																				IL_0394:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03d4;
																				IL_03d4:
																				array[num5 - 2] = 0;
																				goto IL_03e8;
																				IL_03e8:
																				num5--;
																				goto IL_069c;
																				IL_02bd:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_036a;
																				IL_036a:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0378;
																				IL_0378:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_069c;
																				IL_02d0:
																				if (7 > b)
																				{
																					goto IL_02de;
																				}
																				goto IL_0470;
																				IL_02de:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_02ec;
																				IL_02ec:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_02fa;
																				IL_02fa:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_033a;
																				IL_033a:
																				array[num5 - 2] = 0;
																				num = 12;
																				goto IL_0357;
																				IL_0357:
																				num5--;
																				goto IL_069c;
																				IL_0470:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 101;
																				goto IL_0492;
																				IL_0492:
																				array[num5] = 0;
																				num = 87;
																				goto IL_04a9;
																				IL_04a9:
																				num5++;
																				num = 75;
																				goto IL_04c0;
																			}
																			break;
																			IL_0250:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0672;
																	IL_068e:
																	ptr2 += 8;
																	goto IL_069c;
																	IL_0680:
																	num5++;
																	goto IL_068e;
																	IL_0672:
																	array[num5] = 0;
																	goto IL_0680;
																	continue;
																	end_IL_0260:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_0749;
													IL_0749:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									continue;
									end_IL_06d9:
									break;
								}
								continue;
								end_IL_06ee:
								break;
							}
							continue;
							end_IL_06fe:
							break;
						}
						continue;
						end_IL_070e:
						break;
					}
					continue;
					end_IL_071e:
					break;
				}
				continue;
				end_IL_072e:
				break;
			}
		}
	}
}
