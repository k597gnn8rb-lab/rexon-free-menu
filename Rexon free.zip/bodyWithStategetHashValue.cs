using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 133)]
internal struct bodyWithStategetHashValue
{
	internal static bodyWithStategetHashValue CallbackBatch/* Not supported: data(01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 02 03 00 00 00 02 02 00 00 00 01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 04 03 00 00 00 03 03 00 00 00 05 00 00 00 02 02 00 00 00 05 00 00 00 03 03 00 00 00 06 03 00 00 00 04 04 00 00 00 05 00 00 00 04 04 00 00 00 07 00 00 01 C0 C0 01 00 00 07 00 00 00 07 07 00 00 00 08 02 07 00 00 00 01 01 00 00 00 09 00 00 00 00 00 00 00 00 0A 0B) */;
}
