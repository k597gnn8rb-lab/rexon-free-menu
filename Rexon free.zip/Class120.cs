using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gadget Sphere Small", "Super Infection/Casual [MASTERCLIENT]", "Spawns small gadget sphere.", true, 24, ModType.const_1, false)]
internal class Class120 : MonoBehaviour
{
	private static bool bool_0;

	private static int int_0;

	private static float float_0;

	private static bool bool_1;

	private static bool bool_2;

	private static float float_1;

	private static Vector3 IsolatedStorageScopeSimpleEventTypes;

	private static Quaternion SafeSubWindowsgetRequestedPermissions;

	private static GameEntityCreateData SoapMessageSurrogateL;

	private static IntPtr[] AnsiBStrThreadPoolBoundHandleOverlapped;

	private static IntPtr[] RecentLockAssemblyPath;

	private static IntPtr[] setXMLlocalInit;

	private static IntPtr[] IExpandoPositiveInfinity;

	private unsafe void OnEnable()
	{
		int num = 358;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								int[] array4 = new int[9];
								while (true)
								{
									long[] array5 = new long[3];
									while (true)
									{
										object[] array6 = new object[9];
										while (true)
										{
											array6[0] = this;
											while (true)
											{
												array6[1] = IsolatedStorageScopeSimpleEventTypes;
												while (true)
												{
													array6[5] = IsolatedStorageScopeSimpleEventTypes;
													while (true)
													{
														array6[6] = SafeSubWindowsgetRequestedPermissions;
														while (true)
														{
															array6[7] = IsolatedStorageScopeSimpleEventTypes;
															while (true)
															{
																array6[8] = SoapMessageSurrogateL;
																num = 14;
																while (true)
																{
																	byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InvalidHandleIsDBNull.SymbolTokenGetPublicKeyString);
																	while (true)
																	{
																		byte* ptr2 = ptr;
																		while (true)
																		{
																			if (num4 == 1)
																			{
																				return;
																			}
																			while (true)
																			{
																				byte b = *ptr2;
																				while (true)
																				{
																					ptr2++;
																					while (true)
																					{
																						if (b >= 1)
																						{
																							num = 575;
																							while (true)
																							{
																								if (num != 575)
																								{
																									if (num != 1556)
																									{
																										goto IL_26f8;
																									}
																									switch (num)
																									{
																									case 162:
																										goto end_IL_0919;
																									case 115:
																										goto end_IL_0929;
																									case 210:
																									case 397:
																										goto end_IL_093c;
																									case 176:
																										goto IL_0965;
																									case 338:
																										goto IL_0973;
																									case 133:
																									case 326:
																										goto IL_097e;
																									case 373:
																										goto IL_099c;
																									case 195:
																										goto IL_09aa;
																									case 288:
																										goto IL_09bd;
																									case 561:
																										goto IL_09cb;
																									case 298:
																									case 567:
																										goto IL_09d6;
																									case 107:
																										goto IL_0a34;
																									case 334:
																										goto IL_0a47;
																									case 465:
																										goto IL_0a55;
																									case 270:
																									case 317:
																										goto IL_0a60;
																									case 568:
																										goto IL_0a73;
																									case 546:
																										goto IL_0a81;
																									case 2:
																									case 275:
																										goto IL_0a8c;
																									case 184:
																										goto IL_0a9a;
																									case 126:
																										goto IL_0abd;
																									case 532:
																										goto IL_0ac7;
																									case 293:
																										goto IL_0ad5;
																									case 376:
																										goto IL_0af1;
																									case 312:
																										goto IL_0aff;
																									case 274:
																										goto IL_0b0a;
																									case 428:
																										goto IL_0b18;
																									case 26:
																									case 450:
																										goto IL_0b26;
																									case 372:
																										goto IL_0b48;
																									case 323:
																										goto IL_0b56;
																									case 273:
																										goto IL_0b64;
																									case 125:
																									case 448:
																										goto IL_0b80;
																									case 407:
																										goto IL_0bc0;
																									case 4:
																										goto IL_0bd4;
																									case 336:
																										goto IL_0be7;
																									case 369:
																										goto IL_0bf5;
																									case 394:
																									case 525:
																										goto IL_0c0c;
																									case 272:
																										goto IL_0c35;
																									case 221:
																										goto IL_0c43;
																									case 101:
																										goto IL_0c5f;
																									case 30:
																										goto IL_0c6d;
																									case 77:
																										goto IL_0c7b;
																									case 388:
																										goto IL_0c89;
																									case 123:
																									case 367:
																										goto IL_0c97;
																									case 361:
																										goto IL_0ce0;
																									case 548:
																										goto IL_0cf4;
																									case 289:
																									case 315:
																										goto IL_0d10;
																									case 562:
																										goto IL_0d50;
																									case 268:
																										goto IL_0d6d;
																									case 23:
																										goto IL_0d89;
																									case 24:
																										goto IL_0d97;
																									case 410:
																									case 551:
																										goto IL_0da5;
																									case 167:
																										goto IL_0de5;
																									case 389:
																										goto IL_0df9;
																									case 7:
																										goto IL_0e0c;
																									case 54:
																										goto IL_0e1a;
																									case 158:
																										goto IL_0e28;
																									case 68:
																										goto IL_0e36;
																									case 114:
																										goto IL_0e44;
																									case 138:
																										goto IL_0e52;
																									case 226:
																									case 327:
																										goto IL_0e60;
																									case 496:
																										goto IL_0ea0;
																									case 446:
																										goto IL_0eb4;
																									case 437:
																									case 528:
																										goto IL_0ec7;
																									case 475:
																										goto IL_0f29;
																									case 279:
																										goto IL_0f3c;
																									case 363:
																										goto IL_0f53;
																									case 442:
																									case 550:
																										goto IL_0f61;
																									case 232:
																										goto IL_0f75;
																									case 249:
																										goto IL_0fc9;
																									case 216:
																										goto IL_0fd7;
																									case 325:
																										goto IL_0ff8;
																									case 287:
																										goto IL_1006;
																									case 393:
																										goto IL_1011;
																									case 253:
																									case 554:
																										goto IL_101f;
																									case 307:
																										goto IL_102d;
																									case 239:
																										goto IL_1051;
																									case 386:
																										goto IL_105f;
																									case 252:
																										goto IL_1072;
																									case 436:
																										goto IL_1089;
																									case 175:
																									case 342:
																										goto IL_1097;
																									case 69:
																										goto IL_10a5;
																									case 142:
																										goto IL_10c9;
																									case 72:
																										goto IL_10d7;
																									case 480:
																										goto IL_10f3;
																									case 206:
																										goto IL_10fe;
																									case 61:
																										goto IL_110c;
																									case 71:
																									case 544:
																										goto IL_111a;
																									case 39:
																										goto IL_1128;
																									case 45:
																										goto IL_114c;
																									case 319:
																										goto IL_115a;
																									case 98:
																									case 337:
																										goto IL_116d;
																									case 352:
																										goto IL_11c8;
																									case 329:
																										goto IL_11db;
																									case 304:
																										goto IL_11e9;
																									case 128:
																										goto IL_11f7;
																									case 88:
																										goto IL_1205;
																									case 235:
																										goto IL_1213;
																									case 124:
																									case 476:
																										goto IL_121e;
																									case 161:
																										goto IL_125f;
																									case 134:
																										goto IL_1273;
																									case 310:
																										goto IL_1286;
																									case 58:
																										goto IL_1294;
																									case 51:
																									case 523:
																										goto IL_12a2;
																									case 16:
																										goto IL_12b9;
																									case 494:
																										goto IL_12d7;
																									case 19:
																										goto IL_12e5;
																									case 379:
																										goto IL_12f8;
																									case 331:
																										goto IL_1306;
																									case 280:
																									case 566:
																										goto IL_131d;
																									case 79:
																										goto IL_1331;
																									case 345:
																										goto IL_1369;
																									case 538:
																										goto IL_1385;
																									case 500:
																									case 535:
																										goto IL_1390;
																									case 70:
																										goto IL_13a5;
																									case 6:
																										goto IL_13b8;
																									case 482:
																										goto IL_13c6;
																									case 22:
																									case 85:
																										goto IL_13d1;
																									case 9:
																										goto IL_13fa;
																									case 254:
																										goto IL_1408;
																									case 441:
																										goto IL_1424;
																									case 311:
																										goto IL_1432;
																									case 80:
																									case 139:
																										goto IL_1440;
																									case 12:
																										goto IL_1458;
																									case 343:
																										goto IL_1466;
																									case 306:
																										goto IL_1474;
																									case 52:
																										goto IL_1490;
																									case 378:
																										goto IL_149e;
																									case 153:
																									case 455:
																										goto IL_14ac;
																									case 163:
																									case 300:
																										goto IL_14c8;
																									case 177:
																										goto IL_14e5;
																									case 196:
																										goto IL_1522;
																									case 488:
																										goto IL_1535;
																									case 564:
																										goto IL_1543;
																									case 190:
																									case 540:
																										goto IL_154e;
																									case 204:
																										goto IL_1568;
																									case 251:
																										goto IL_1576;
																									case 302:
																										goto IL_1584;
																									case 96:
																										goto IL_1597;
																									case 148:
																										goto IL_15a5;
																									case 57:
																									case 371:
																										goto IL_15b0;
																									case 502:
																										goto IL_15cd;
																									case 277:
																										goto IL_1605;
																									case 391:
																										goto IL_1618;
																									case 466:
																										goto IL_1626;
																									case 33:
																									case 78:
																										goto IL_1634;
																									case 399:
																										goto IL_1642;
																									case 0:
																										goto IL_1660;
																									case 220:
																										goto IL_166e;
																									case 35:
																										goto IL_1681;
																									case 460:
																										goto IL_1698;
																									case 423:
																									case 499:
																										goto IL_16a6;
																									case 193:
																										goto IL_16ba;
																									case 87:
																										goto IL_16f7;
																									case 173:
																										goto IL_1713;
																									case 478:
																										goto IL_1721;
																									case 120:
																									case 143:
																										goto IL_172f;
																									case 456:
																										goto IL_1743;
																									case 229:
																										goto IL_1794;
																									case 295:
																										goto IL_17a2;
																									case 485:
																										goto IL_17b5;
																									case 154:
																										goto IL_17c3;
																									case 34:
																									case 322:
																										goto IL_17d1;
																									case 333:
																										goto IL_17e5;
																									case 377:
																										goto IL_1837;
																									case 526:
																										goto IL_1845;
																									case 17:
																										goto IL_1858;
																									case 505:
																										goto IL_1863;
																									case 189:
																									case 444:
																										goto IL_1871;
																									case 299:
																										goto IL_1899;
																									case 171:
																										goto IL_18a7;
																									case 534:
																										goto IL_18c3;
																									case 192:
																										goto IL_18d1;
																									case 250:
																									case 403:
																										goto IL_18e8;
																									case 542:
																										goto IL_18ff;
																									case 62:
																										goto IL_191d;
																									case 89:
																										goto IL_192b;
																									case 395:
																										goto IL_193e;
																									case 27:
																										goto IL_194c;
																									case 347:
																										goto IL_195a;
																									case 157:
																									case 524:
																										goto IL_1965;
																									case 265:
																										goto IL_1990;
																									case 522:
																										goto IL_19a9;
																									case 104:
																										goto IL_19b7;
																									case 144:
																									case 490:
																										goto IL_19c2;
																									case 29:
																										goto IL_1a22;
																									case 60:
																										goto IL_1a35;
																									case 178:
																										goto IL_1a4c;
																									case 284:
																									case 489:
																										goto IL_1a57;
																									case 285:
																										goto IL_1a65;
																									case 474:
																										goto IL_1a7e;
																									case 25:
																										goto IL_1a9d;
																									case 238:
																										goto IL_1aab;
																									case 214:
																										goto IL_1abe;
																									case 498:
																										goto IL_1acc;
																									case 111:
																									case 116:
																										goto IL_1ada;
																									case 547:
																										goto IL_1ae8;
																									case 457:
																										goto IL_1b00;
																									case 264:
																										goto IL_1b0e;
																									case 187:
																										goto IL_1b21;
																									case 518:
																										goto IL_1b2f;
																									case 203:
																									case 539:
																										goto IL_1b3d;
																									case 297:
																										goto IL_1b89;
																									case 314:
																										goto IL_1b9c;
																									case 483:
																										goto IL_1baa;
																									case 382:
																										goto IL_1bb8;
																									case 452:
																										goto IL_1bc6;
																									case 74:
																									case 405:
																										goto IL_1bd4;
																									case 360:
																										goto IL_1c33;
																									case 150:
																									case 228:
																										goto IL_1c46;
																									case 263:
																										goto IL_1c54;
																									case 86:
																										goto IL_1c7f;
																									case 462:
																										goto IL_1c8d;
																									case 3:
																										goto IL_1ca0;
																									case 200:
																										goto IL_1cae;
																									case 356:
																									case 433:
																										goto IL_1cbc;
																									case 380:
																										goto IL_1d1b;
																									case 512:
																										goto IL_1d37;
																									case 365:
																										goto IL_1d45;
																									case 219:
																									case 422:
																										goto IL_1d50;
																									case 152:
																										goto IL_1d7a;
																									case 231:
																										goto IL_1d93;
																									case 237:
																										goto IL_1da1;
																									case 42:
																									case 81:
																										goto IL_1dac;
																									case 83:
																										goto IL_1dba;
																									case 108:
																										goto IL_1de5;
																									case 146:
																										goto IL_1df3;
																									case 227:
																										goto IL_1e06;
																									case 543:
																										goto IL_1e14;
																									case 99:
																									case 233:
																										goto IL_1e2b;
																									case 269:
																										goto IL_1e94;
																									case 552:
																										goto IL_1ea7;
																									case 290:
																										goto IL_1eb5;
																									case 21:
																									case 37:
																										goto IL_1ec3;
																									case 286:
																										goto IL_1f00;
																									case 262:
																										goto IL_1f0e;
																									case 435:
																										goto IL_1f21;
																									case 411:
																										goto IL_1f2f;
																									case 563:
																										goto IL_1f3a;
																									case 402:
																									case 439:
																										goto IL_1f48;
																									case 471:
																										goto IL_1f95;
																									case 191:
																										goto IL_1fa3;
																									case 559:
																										goto IL_1fb6;
																									case 103:
																										goto IL_1fc4;
																									case 222:
																										goto IL_1fe0;
																									case 43:
																									case 201:
																										goto IL_1feb;
																									case 429:
																										goto IL_1ff5;
																									case 66:
																										goto IL_2003;
																									case 105:
																										goto IL_2016;
																									case 36:
																										goto IL_2024;
																									case 92:
																									case 425:
																										goto IL_2032;
																									case 106:
																										goto IL_205d;
																									case 511:
																										goto IL_2076;
																									case 364:
																									case 459:
																										goto IL_2081;
																									case 276:
																										goto IL_20a9;
																									case 339:
																										goto IL_20b7;
																									case 84:
																										goto IL_20ca;
																									case 348:
																										goto IL_20d8;
																									case 119:
																										goto IL_20e6;
																									case 330:
																										goto IL_20f4;
																									case 257:
																									case 463:
																										goto IL_20ff;
																									case 113:
																										goto IL_210d;
																									case 415:
																										goto IL_2125;
																									case 443:
																										goto IL_2133;
																									case 256:
																										goto IL_2146;
																									case 520:
																										goto IL_2154;
																									case 453:
																										goto IL_2162;
																									case 59:
																										goto IL_2179;
																									case 172:
																									case 296:
																										goto IL_2187;
																									case 533:
																										goto IL_21a5;
																									case 321:
																										goto IL_21bc;
																									case 400:
																										goto IL_21ca;
																									case 46:
																									case 341:
																										goto IL_21ef;
																									case 536:
																										goto IL_220d;
																									case 137:
																										goto IL_221b;
																									case 537:
																										goto IL_222e;
																									case 102:
																										goto IL_223c;
																									case 127:
																									case 194:
																										goto IL_224a;
																									case 432:
																										goto IL_2262;
																									case 308:
																										goto IL_2270;
																									case 185:
																										goto IL_227b;
																									case 420:
																										goto IL_2289;
																									case 258:
																									case 259:
																										goto IL_2297;
																									case 278:
																										goto IL_22d0;
																									case 199:
																										goto IL_22e4;
																									case 11:
																									case 530:
																										goto IL_22f7;
																									case 324:
																										goto IL_2315;
																									case 260:
																										goto IL_2323;
																									case 430:
																										goto IL_2336;
																									case 169:
																										goto IL_2344;
																									case 236:
																									case 387:
																										goto IL_235b;
																									case 118:
																										goto IL_2379;
																									case 291:
																										goto IL_2387;
																									case 32:
																										goto IL_2395;
																									case 151:
																									case 501:
																										goto IL_23b1;
																									case 122:
																										goto IL_23bf;
																									case 431:
																										goto IL_23d7;
																									case 170:
																										goto IL_23e5;
																									case 473:
																										goto IL_23f8;
																									case 470:
																										goto IL_2406;
																									case 346:
																									case 486:
																										goto IL_2411;
																									case 472:
																										goto IL_241f;
																									case 230:
																										goto IL_2442;
																									case 351:
																										goto IL_2450;
																									case 418:
																										goto IL_2463;
																									case 493:
																										goto IL_2471;
																									case 13:
																									case 513:
																										goto IL_247f;
																									case 215:
																										goto IL_2493;
																									case 556:
																										goto IL_24e5;
																									case 309:
																										goto IL_24f3;
																									case 117:
																										goto IL_2506;
																									case 529:
																										goto IL_2514;
																									case 73:
																									case 344:
																										goto IL_252b;
																									case 202:
																										goto IL_253f;
																									case 246:
																										goto IL_2591;
																									case 509:
																										goto IL_259f;
																									case 129:
																										goto IL_25b2;
																									case 130:
																										goto IL_25c0;
																									case 76:
																									case 217:
																										goto IL_25ce;
																									case 565:
																										goto IL_25dc;
																									case 484:
																										goto IL_25fe;
																									case 305:
																										goto IL_260c;
																									case 38:
																										goto IL_261f;
																									case 416:
																										goto IL_262d;
																									case 271:
																										goto IL_263b;
																									case 349:
																										goto IL_2649;
																									case 93:
																									case 398:
																										goto IL_2657;
																									case 468:
																										goto IL_266b;
																									case 392:
																										goto IL_26bc;
																									case 149:
																										goto IL_26d3;
																									case 41:
																									case 91:
																										goto IL_26f8;
																									case 519:
																										goto IL_2706;
																									case 147:
																										goto IL_271f;
																									case 31:
																										goto IL_273e;
																									case 390:
																										goto IL_274c;
																									case 267:
																										goto IL_275f;
																									case 316:
																										goto IL_276d;
																									case 64:
																									case 447:
																										goto IL_277b;
																									case 207:
																										goto IL_278f;
																									case 413:
																										goto IL_27fe;
																									case 527:
																										goto IL_281a;
																									case 205:
																										goto IL_282e;
																									case 44:
																									case 198:
																										goto IL_2842;
																									case 461:
																										goto IL_2856;
																									case 318:
																										goto IL_2893;
																									case 5:
																									case 15:
																									case 18:
																									case 47:
																									case 48:
																									case 56:
																									case 65:
																									case 67:
																									case 82:
																									case 95:
																									case 97:
																									case 100:
																									case 110:
																									case 112:
																									case 121:
																									case 131:
																									case 132:
																									case 136:
																									case 141:
																									case 145:
																									case 155:
																									case 156:
																									case 160:
																									case 174:
																									case 179:
																									case 181:
																									case 186:
																									case 188:
																									case 209:
																									case 213:
																									case 218:
																									case 224:
																									case 225:
																									case 241:
																									case 243:
																									case 244:
																									case 245:
																									case 248:
																									case 282:
																									case 292:
																									case 320:
																									case 328:
																									case 332:
																									case 340:
																									case 370:
																									case 374:
																									case 401:
																									case 408:
																									case 409:
																									case 412:
																									case 421:
																									case 427:
																									case 434:
																									case 451:
																									case 454:
																									case 458:
																									case 467:
																									case 469:
																									case 491:
																									case 504:
																									case 508:
																									case 510:
																									case 515:
																									case 516:
																									case 521:
																									case 531:
																									case 541:
																									case 545:
																									case 549:
																									case 555:
																										goto IL_28a3;
																									case 1:
																									case 8:
																									case 10:
																									case 20:
																									case 40:
																									case 49:
																									case 50:
																									case 53:
																									case 55:
																									case 63:
																									case 75:
																									case 94:
																									case 109:
																									case 135:
																									case 140:
																									case 164:
																									case 165:
																									case 166:
																									case 168:
																									case 180:
																									case 182:
																									case 183:
																									case 197:
																									case 211:
																									case 212:
																									case 223:
																									case 234:
																									case 240:
																									case 242:
																									case 247:
																									case 255:
																									case 261:
																									case 266:
																									case 281:
																									case 283:
																									case 294:
																									case 301:
																									case 303:
																									case 313:
																									case 335:
																									case 353:
																									case 354:
																									case 355:
																									case 362:
																									case 366:
																									case 368:
																									case 375:
																									case 381:
																									case 383:
																									case 384:
																									case 385:
																									case 396:
																									case 406:
																									case 414:
																									case 424:
																									case 426:
																									case 438:
																									case 440:
																									case 445:
																									case 449:
																									case 464:
																									case 479:
																									case 495:
																									case 497:
																									case 503:
																									case 506:
																									case 517:
																									case 553:
																									case 558:
																									case 560:
																										goto end_IL_094c;
																									case 350:
																										goto end_IL_28b6;
																									case 14:
																										goto end_IL_28c9;
																									case 90:
																										goto end_IL_28d3;
																									case 487:
																										goto end_IL_28de;
																									case 417:
																										goto end_IL_28fd;
																									case 557:
																										goto end_IL_2913;
																									case 28:
																										goto end_IL_2929;
																									case 507:
																										goto end_IL_293f;
																									case 208:
																										goto end_IL_2955;
																									case 404:
																										goto end_IL_2965;
																									case 514:
																										goto end_IL_2975;
																									case 481:
																										goto end_IL_2985;
																									case 492:
																										goto end_IL_2995;
																									case 419:
																									case 477:
																										goto end_IL_29a5;
																									case 357:
																										goto end_IL_29b5;
																									case 358:
																										goto end_IL_29c5;
																									case 159:
																									case 359:
																										return;
																									}
																									continue;
																								}
																								if (b <= 67)
																								{
																									goto IL_0965;
																								}
																								goto IL_28a3;
																								IL_263b:
																								if (47 >= b)
																								{
																									goto IL_2649;
																								}
																								goto IL_28a3;
																								IL_2657:
																								array[num5 - 2] = 4;
																								goto IL_266b;
																								IL_2649:
																								if (47 <= b)
																								{
																									goto IL_2657;
																								}
																								goto IL_28a3;
																								IL_0965:
																								if (34 >= b)
																								{
																									goto IL_0973;
																								}
																								goto IL_193e;
																								IL_0973:
																								if (34 <= b)
																								{
																									goto IL_097e;
																								}
																								goto IL_09bd;
																								IL_097e:
																								array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_099c;
																								IL_099c:
																								ptr2 += 8;
																								goto IL_09aa;
																								IL_09aa:
																								num5--;
																								goto end_IL_094c;
																								IL_09bd:
																								if (17 >= b)
																								{
																									goto IL_09cb;
																								}
																								goto IL_11db;
																								IL_09cb:
																								if (17 <= b)
																								{
																									goto IL_09d6;
																								}
																								goto IL_0a47;
																								IL_09d6:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0a34;
																								IL_0a34:
																								num5--;
																								goto end_IL_094c;
																								IL_0a47:
																								if (8 >= b)
																								{
																									goto IL_0a55;
																								}
																								goto IL_0e0c;
																								IL_0a55:
																								if (8 <= b)
																								{
																									goto IL_0a60;
																								}
																								goto IL_0a73;
																								IL_0a60:
																								num5--;
																								goto end_IL_094c;
																								IL_0a73:
																								if (4 >= b)
																								{
																									goto IL_0a81;
																								}
																								goto IL_0c5f;
																								IL_0a81:
																								if (4 <= b)
																								{
																									goto IL_0a8c;
																								}
																								goto IL_0af1;
																								IL_0a8c:
																								array[num5] = 0;
																								goto IL_0a9a;
																								IL_0a9a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = array4[*(int*)(ptr2 + num3)];
																								goto IL_0abd;
																								IL_0abd:
																								array2[num5] = null;
																								goto IL_0ac7;
																								IL_0ac7:
																								num5++;
																								goto IL_0ad5;
																								IL_0ad5:
																								ptr2 += 8;
																								num = 506;
																								goto end_IL_094c;
																								IL_0af1:
																								if (2 >= b)
																								{
																									goto IL_0aff;
																								}
																								goto IL_0be7;
																								IL_0aff:
																								if (2 > b)
																								{
																									goto IL_0b0a;
																								}
																								num = 125;
																								goto IL_0b80;
																								IL_0b0a:
																								if (1 >= b)
																								{
																									goto IL_0b18;
																								}
																								goto IL_28a3;
																								IL_0b18:
																								if (1 <= b)
																								{
																									goto IL_0b26;
																								}
																								goto IL_28a3;
																								IL_0b26:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																								num = 372;
																								goto IL_0b48;
																								IL_0b48:
																								array[num5] = 0;
																								goto IL_0b56;
																								IL_0b56:
																								num5++;
																								goto IL_0b64;
																								IL_0b64:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_266b:
																								array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																								goto IL_26bc;
																								IL_0b80:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_0bc0;
																								IL_0bc0:
																								array[num5 - 2] = 0;
																								goto IL_0bd4;
																								IL_0bd4:
																								num5--;
																								goto end_IL_094c;
																								IL_0be7:
																								if (3 >= b)
																								{
																									goto IL_0bf5;
																								}
																								goto IL_28a3;
																								IL_0bf5:
																								if (3 <= b)
																								{
																									num = 394;
																									goto IL_0c0c;
																								}
																								goto IL_28a3;
																								IL_26bc:
																								num5--;
																								num = 149;
																								goto IL_26d3;
																								IL_0c0c:
																								ref int reference = ref array4[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_0c35;
																								IL_0c35:
																								ptr2 += 8;
																								goto IL_0c43;
																								IL_0c43:
																								num5--;
																								num = 164;
																								goto end_IL_094c;
																								IL_0c5f:
																								if (6 >= b)
																								{
																									goto IL_0c6d;
																								}
																								goto IL_0d89;
																								IL_0c6d:
																								if (6 > b)
																								{
																									goto IL_0c7b;
																								}
																								num = 315;
																								goto IL_0d10;
																								IL_0c7b:
																								if (5 >= b)
																								{
																									goto IL_0c89;
																								}
																								goto IL_28a3;
																								IL_0c89:
																								if (5 <= b)
																								{
																									goto IL_0c97;
																								}
																								goto IL_28a3;
																								IL_0c97:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								num = 361;
																								goto IL_0ce0;
																								IL_0ce0:
																								array[num5 - 2] = 0;
																								goto IL_0cf4;
																								IL_0cf4:
																								num5--;
																								goto end_IL_094c;
																								IL_26d3:
																								ptr2 += 8;
																								num = 445;
																								goto end_IL_094c;
																								IL_0d10:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_0d50;
																								IL_0d50:
																								array[num5 - 2] = 0;
																								num = 268;
																								goto IL_0d6d;
																								IL_0d6d:
																								num5--;
																								num = 426;
																								goto end_IL_094c;
																								IL_0d89:
																								if (7 >= b)
																								{
																									goto IL_0d97;
																								}
																								goto IL_28a3;
																								IL_0d97:
																								if (7 <= b)
																								{
																									goto IL_0da5;
																								}
																								goto IL_28a3;
																								IL_0da5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_0de5;
																								IL_0de5:
																								array[num5 - 2] = 0;
																								goto IL_0df9;
																								IL_0df9:
																								num5--;
																								goto end_IL_094c;
																								IL_0e0c:
																								if (12 >= b)
																								{
																									goto IL_0e1a;
																								}
																								goto IL_0ff8;
																								IL_0e1a:
																								if (12 <= b)
																								{
																									num = 8;
																									goto end_IL_094c;
																								}
																								goto IL_0e28;
																								IL_0e28:
																								if (10 >= b)
																								{
																									goto IL_0e36;
																								}
																								goto IL_0f3c;
																								IL_0e36:
																								if (10 > b)
																								{
																									goto IL_0e44;
																								}
																								goto IL_0ec7;
																								IL_0e44:
																								if (9 >= b)
																								{
																									goto IL_0e52;
																								}
																								goto IL_28a3;
																								IL_0e52:
																								if (9 <= b)
																								{
																									goto IL_0e60;
																								}
																								goto IL_28a3;
																								IL_0e60:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_0ea0;
																								IL_0ea0:
																								array[num5 - 2] = 0;
																								goto IL_0eb4;
																								IL_0eb4:
																								num5--;
																								goto end_IL_094c;
																								IL_0ec7:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0f29;
																								IL_0f29:
																								num5 -= 2;
																								goto end_IL_094c;
																								IL_0f3c:
																								if (11 >= b)
																								{
																									num = 363;
																									goto IL_0f53;
																								}
																								goto IL_28a3;
																								IL_26f8:
																								array[num5] = 13;
																								goto IL_2706;
																								IL_0f53:
																								if (11 <= b)
																								{
																									goto IL_0f61;
																								}
																								goto IL_28a3;
																								IL_0f61:
																								array[num5 - 2] = 0;
																								goto IL_0f75;
																								IL_0f75:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((delegate*<int, int, int>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																								goto IL_0fc9;
																								IL_0fc9:
																								num5--;
																								goto IL_0fd7;
																								IL_0fd7:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_2842:
																								array[num5 - 1] = 4;
																								goto IL_2856;
																								IL_0ff8:
																								if (14 < b)
																								{
																									goto IL_1006;
																								}
																								num = 480;
																								goto IL_10f3;
																								IL_1006:
																								if (15 >= b)
																								{
																									goto IL_1011;
																								}
																								goto IL_1072;
																								IL_1011:
																								if (15 <= b)
																								{
																									goto IL_101f;
																								}
																								goto IL_28a3;
																								IL_101f:
																								array[num5] = 0;
																								goto IL_102d;
																								IL_102d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_1051;
																								IL_1051:
																								num5++;
																								goto IL_105f;
																								IL_105f:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1072:
																								if (16 >= b)
																								{
																									num = 436;
																									goto IL_1089;
																								}
																								goto IL_28a3;
																								IL_271f:
																								array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																								goto IL_273e;
																								IL_1089:
																								if (16 <= b)
																								{
																									goto IL_1097;
																								}
																								goto IL_28a3;
																								IL_1097:
																								array[num5] = 0;
																								goto IL_10a5;
																								IL_10a5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_10c9;
																								IL_10c9:
																								num5++;
																								goto IL_10d7;
																								IL_10d7:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_2706:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																								goto IL_271f;
																								IL_10f3:
																								if (14 > b)
																								{
																									goto IL_10fe;
																								}
																								goto IL_116d;
																								IL_10fe:
																								if (13 >= b)
																								{
																									goto IL_110c;
																								}
																								goto IL_28a3;
																								IL_110c:
																								if (13 <= b)
																								{
																									goto IL_111a;
																								}
																								goto IL_28a3;
																								IL_111a:
																								array[num5] = 0;
																								goto IL_1128;
																								IL_1128:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_114c;
																								IL_114c:
																								num5++;
																								goto IL_115a;
																								IL_115a:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_116d:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								num = 352;
																								goto IL_11c8;
																								IL_11c8:
																								num5--;
																								goto end_IL_094c;
																								IL_11db:
																								if (25 >= b)
																								{
																									goto IL_11e9;
																								}
																								goto IL_1535;
																								IL_11e9:
																								if (25 > b)
																								{
																									goto IL_11f7;
																								}
																								goto IL_14c8;
																								IL_11f7:
																								if (21 < b)
																								{
																									goto IL_1205;
																								}
																								goto IL_1385;
																								IL_1205:
																								if (23 >= b)
																								{
																									goto IL_1213;
																								}
																								goto IL_12f8;
																								IL_1213:
																								if (23 <= b)
																								{
																									goto IL_121e;
																								}
																								goto IL_1286;
																								IL_121e:
																								array2[num5 - 1] = ((delegate*<GTPlayer, SphereCollider>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((GTPlayer)array2[num5 - 1]);
																								num = 161;
																								goto IL_125f;
																								IL_125f:
																								array[num5 - 1] = 5;
																								goto IL_1273;
																								IL_1273:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1286:
																								if (22 >= b)
																								{
																									goto IL_1294;
																								}
																								goto IL_28a3;
																								IL_1294:
																								if (22 <= b)
																								{
																									goto IL_12a2;
																								}
																								goto IL_28a3;
																								IL_12a2:
																								array[num5] = 5;
																								num = 16;
																								goto IL_12b9;
																								IL_12b9:
																								array2[num5] = ((delegate*<GTPlayer>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])();
																								goto IL_12d7;
																								IL_12d7:
																								num5++;
																								goto IL_12e5;
																								IL_12e5:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_12f8:
																								if (24 >= b)
																								{
																									goto IL_1306;
																								}
																								goto IL_28a3;
																								IL_1306:
																								if (24 <= b)
																								{
																									num = 280;
																									goto IL_131d;
																								}
																								goto IL_28a3;
																								IL_273e:
																								num5++;
																								goto IL_274c;
																								IL_131d:
																								array[num5 - 1] = 5;
																								goto IL_1331;
																								IL_1331:
																								array2[num5 - 1] = ((delegate*<Component, Transform>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																								goto IL_1369;
																								IL_1369:
																								ptr2 += 8;
																								num = 383;
																								goto end_IL_094c;
																								IL_1385:
																								if (21 <= b)
																								{
																									goto IL_1390;
																								}
																								goto IL_13b8;
																								IL_1390:
																								((delegate*<void>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])();
																								goto IL_13a5;
																								IL_13a5:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_13b8:
																								if (19 >= b)
																								{
																									goto IL_13c6;
																								}
																								goto IL_1490;
																								IL_13c6:
																								if (19 <= b)
																								{
																									goto IL_13d1;
																								}
																								goto IL_1424;
																								IL_13d1:
																								((delegate*<UnityEngine.Object, void>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Class120)array2[num5 - 1]);
																								goto IL_13fa;
																								IL_13fa:
																								num5--;
																								goto IL_1408;
																								IL_1408:
																								ptr2 += 8;
																								num = 503;
																								goto end_IL_094c;
																								IL_1424:
																								if (18 >= b)
																								{
																									goto IL_1432;
																								}
																								goto IL_28a3;
																								IL_1432:
																								if (18 <= b)
																								{
																									goto IL_1440;
																								}
																								goto IL_28a3;
																								IL_1440:
																								array2[num5] = array6[*(int*)(ptr2 + num3)];
																								goto IL_1458;
																								IL_1458:
																								array[num5] = 5;
																								goto IL_1466;
																								IL_1466:
																								num5++;
																								goto IL_1474;
																								IL_1474:
																								ptr2 += 8;
																								num = 281;
																								goto end_IL_094c;
																								IL_1490:
																								if (20 >= b)
																								{
																									goto IL_149e;
																								}
																								goto IL_28a3;
																								IL_149e:
																								if (20 <= b)
																								{
																									goto IL_14ac;
																								}
																								goto IL_28a3;
																								IL_14ac:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_094c;
																								IL_14c8:
																								array[num5 - 1] = 4;
																								num = 177;
																								goto IL_14e5;
																								IL_14e5:
																								array2[num5 - 1] = ((delegate*<Transform, Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																								goto IL_1522;
																								IL_1522:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1535:
																								if (29 >= b)
																								{
																									goto IL_1543;
																								}
																								goto IL_1713;
																								IL_1543:
																								if (29 <= b)
																								{
																									goto IL_154e;
																								}
																								goto IL_1597;
																								IL_154e:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																								goto IL_1568;
																								IL_1568:
																								array[num5] = 3;
																								goto IL_1576;
																								IL_1576:
																								num5++;
																								goto IL_1584;
																								IL_1584:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1597:
																								if (27 >= b)
																								{
																									goto IL_15a5;
																								}
																								goto IL_1681;
																								IL_15a5:
																								if (27 <= b)
																								{
																									goto IL_15b0;
																								}
																								goto IL_1618;
																								IL_15b0:
																								array[num5 - 1] = 5;
																								num = 502;
																								goto IL_15cd;
																								IL_15cd:
																								array2[num5 - 1] = ((delegate*<Component, Transform>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																								goto IL_1605;
																								IL_1605:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1618:
																								if (26 >= b)
																								{
																									goto IL_1626;
																								}
																								goto IL_28a3;
																								IL_1626:
																								if (26 <= b)
																								{
																									goto IL_1634;
																								}
																								goto IL_28a3;
																								IL_1634:
																								array[num5] = 5;
																								goto IL_1642;
																								IL_1642:
																								array2[num5] = ((delegate*<GTPlayer>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])();
																								goto IL_1660;
																								IL_1660:
																								num5++;
																								goto IL_166e;
																								IL_166e:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1681:
																								if (28 >= b)
																								{
																									num = 460;
																									goto IL_1698;
																								}
																								goto IL_28a3;
																								IL_274c:
																								ptr2 += 16;
																								goto end_IL_094c;
																								IL_1698:
																								if (28 <= b)
																								{
																									goto IL_16a6;
																								}
																								goto IL_28a3;
																								IL_16a6:
																								array[num5 - 1] = 4;
																								goto IL_16ba;
																								IL_16ba:
																								array2[num5 - 1] = ((delegate*<Transform, Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																								goto IL_16f7;
																								IL_16f7:
																								ptr2 += 8;
																								num = 266;
																								goto end_IL_094c;
																								IL_1713:
																								if (31 >= b)
																								{
																									goto IL_1721;
																								}
																								goto IL_1858;
																								IL_1721:
																								if (31 <= b)
																								{
																									goto IL_172f;
																								}
																								goto IL_17b5;
																								IL_172f:
																								array[num5 - 2] = 4;
																								goto IL_1743;
																								IL_1743:
																								array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																								goto IL_1794;
																								IL_1794:
																								num5--;
																								goto IL_17a2;
																								IL_17a2:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_17b5:
																								if (30 >= b)
																								{
																									goto IL_17c3;
																								}
																								goto IL_28a3;
																								IL_17c3:
																								if (30 <= b)
																								{
																									goto IL_17d1;
																								}
																								goto IL_28a3;
																								IL_17d1:
																								array[num5 - 2] = 4;
																								goto IL_17e5;
																								IL_17e5:
																								array2[num5 - 2] = ((delegate*<Vector3, float, Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																								goto IL_1837;
																								IL_1837:
																								num5--;
																								goto IL_1845;
																								IL_1845:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1858:
																								if (32 >= b)
																								{
																									goto IL_1863;
																								}
																								goto IL_18c3;
																								IL_1863:
																								if (32 <= b)
																								{
																									goto IL_1871;
																								}
																								goto IL_28a3;
																								IL_1871:
																								array6[*(int*)(ptr2 + num3)] = (Vector3)array2[num5 - 1];
																								goto IL_1899;
																								IL_1899:
																								ptr2 += 8;
																								goto IL_18a7;
																								IL_18a7:
																								num5--;
																								num = 197;
																								goto end_IL_094c;
																								IL_18c3:
																								if (33 >= b)
																								{
																									goto IL_18d1;
																								}
																								goto IL_28a3;
																								IL_18d1:
																								if (33 <= b)
																								{
																									num = 403;
																									goto IL_18e8;
																								}
																								goto IL_28a3;
																								IL_275f:
																								if (49 >= b)
																								{
																									goto IL_276d;
																								}
																								goto IL_281a;
																								IL_18e8:
																								array[num5] = 5;
																								num = 542;
																								goto IL_18ff;
																								IL_18ff:
																								array2[num5] = ((delegate*<List<GameEntityCreateData>>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])();
																								goto IL_191d;
																								IL_191d:
																								num5++;
																								goto IL_192b;
																								IL_192b:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_193e:
																								if (51 < b)
																								{
																									goto IL_194c;
																								}
																								goto IL_2076;
																								IL_194c:
																								if (59 >= b)
																								{
																									goto IL_195a;
																								}
																								goto IL_1d37;
																								IL_195a:
																								if (59 <= b)
																								{
																									goto IL_1965;
																								}
																								goto IL_19a9;
																								IL_1965:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_1990;
																								IL_1990:
																								array[num5 - 1] = 1;
																								goto end_IL_094c;
																								IL_19a9:
																								if (55 >= b)
																								{
																									goto IL_19b7;
																								}
																								goto IL_1b9c;
																								IL_19b7:
																								if (55 <= b)
																								{
																									goto IL_19c2;
																								}
																								goto IL_1a35;
																								IL_19c2:
																								((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)AnsiBStrThreadPoolBoundHandleOverlapped[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).entityTypeId = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_1a22;
																								IL_1a22:
																								num5 -= 2;
																								goto end_IL_094c;
																								IL_1a35:
																								if (53 >= b)
																								{
																									num = 178;
																									goto IL_1a4c;
																								}
																								goto IL_1b21;
																								IL_276d:
																								if (49 <= b)
																								{
																									goto IL_277b;
																								}
																								goto IL_28a3;
																								IL_1a4c:
																								if (53 <= b)
																								{
																									goto IL_1a57;
																								}
																								goto IL_1abe;
																								IL_1a57:
																								array[num5] = 13;
																								goto IL_1a65;
																								IL_1a65:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																								goto IL_1a7e;
																								IL_1a7e:
																								array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																								goto IL_1a9d;
																								IL_1a9d:
																								num5++;
																								goto IL_1aab;
																								IL_1aab:
																								ptr2 += 16;
																								goto end_IL_094c;
																								IL_1abe:
																								if (52 >= b)
																								{
																									goto IL_1acc;
																								}
																								goto IL_28a3;
																								IL_1acc:
																								if (52 <= b)
																								{
																									goto IL_1ada;
																								}
																								goto IL_28a3;
																								IL_1ada:
																								array[num5] = 5;
																								goto IL_1ae8;
																								IL_1ae8:
																								array2[num5] = array6[*(int*)(ptr2 + num3)];
																								goto IL_1b00;
																								IL_1b00:
																								num5++;
																								goto IL_1b0e;
																								IL_1b0e:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1b21:
																								if (54 >= b)
																								{
																									goto IL_1b2f;
																								}
																								goto IL_28a3;
																								IL_1b2f:
																								if (54 <= b)
																								{
																									goto IL_1b3d;
																								}
																								goto IL_28a3;
																								IL_1b3d:
																								((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)AnsiBStrThreadPoolBoundHandleOverlapped[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4) = default(GameEntityCreateData);
																								goto IL_1b89;
																								IL_1b89:
																								num5--;
																								goto end_IL_094c;
																								IL_1b9c:
																								if (57 >= b)
																								{
																									goto IL_1baa;
																								}
																								goto IL_1ca0;
																								IL_1baa:
																								if (57 > b)
																								{
																									goto IL_1bb8;
																								}
																								goto IL_1c46;
																								IL_1bb8:
																								if (56 >= b)
																								{
																									goto IL_1bc6;
																								}
																								goto IL_28a3;
																								IL_1bc6:
																								if (56 <= b)
																								{
																									goto IL_1bd4;
																								}
																								goto IL_28a3;
																								IL_1bd4:
																								((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)AnsiBStrThreadPoolBoundHandleOverlapped[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).position = (Vector3)array2[num5 - 1];
																								goto IL_1c33;
																								IL_1c33:
																								num5 -= 2;
																								goto end_IL_094c;
																								IL_1c46:
																								array[num5] = 4;
																								goto IL_1c54;
																								IL_1c54:
																								array2[num5] = (Quaternion)array6[*(int*)(ptr2 + num3)];
																								num = 86;
																								goto IL_1c7f;
																								IL_1c7f:
																								num5++;
																								goto IL_1c8d;
																								IL_1c8d:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1ca0:
																								if (58 >= b)
																								{
																									goto IL_1cae;
																								}
																								goto IL_28a3;
																								IL_1cae:
																								if (58 <= b)
																								{
																									goto IL_1cbc;
																								}
																								goto IL_28a3;
																								IL_1cbc:
																								((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)AnsiBStrThreadPoolBoundHandleOverlapped[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).rotation = (Quaternion)array2[num5 - 1];
																								goto IL_1d1b;
																								IL_1d1b:
																								num5 -= 2;
																								num = 40;
																								goto end_IL_094c;
																								IL_1d37:
																								if (63 >= b)
																								{
																									goto IL_1d45;
																								}
																								goto IL_1f21;
																								IL_1d45:
																								if (63 <= b)
																								{
																									goto IL_1d50;
																								}
																								goto IL_1d93;
																								IL_1d50:
																								*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (nint)((string[])array2[num5 - 1]).LongLength;
																								goto IL_1d7a;
																								IL_1d7a:
																								array[num5 - 1] = 2;
																								goto end_IL_094c;
																								IL_1d93:
																								if (61 >= b)
																								{
																									goto IL_1da1;
																								}
																								goto IL_1ea7;
																								IL_1da1:
																								if (61 <= b)
																								{
																									goto IL_1dac;
																								}
																								goto IL_1e06;
																								IL_1dac:
																								array[num5] = 4;
																								goto IL_1dba;
																								IL_1dba:
																								array2[num5] = (GameEntityCreateData)array6[*(int*)(ptr2 + num3)];
																								num = 108;
																								goto IL_1de5;
																								IL_1de5:
																								num5++;
																								goto IL_1df3;
																								IL_1df3:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1e06:
																								if (60 >= b)
																								{
																									goto IL_1e14;
																								}
																								goto IL_28a3;
																								IL_1e14:
																								if (60 <= b)
																								{
																									num = 233;
																									goto IL_1e2b;
																								}
																								goto IL_28a3;
																								IL_277b:
																								array[num5 - 1] = 4;
																								goto IL_278f;
																								IL_1e2b:
																								((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)AnsiBStrThreadPoolBoundHandleOverlapped[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).createData = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								num = 269;
																								goto IL_1e94;
																								IL_1e94:
																								num5 -= 2;
																								goto end_IL_094c;
																								IL_1ea7:
																								if (62 >= b)
																								{
																									goto IL_1eb5;
																								}
																								goto IL_28a3;
																								IL_1eb5:
																								if (62 <= b)
																								{
																									goto IL_1ec3;
																								}
																								goto IL_28a3;
																								IL_1ec3:
																								((delegate*<List<GameEntityCreateData>, GameEntityCreateData, void>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 2], (GameEntityCreateData)array2[num5 - 1]);
																								goto IL_1f00;
																								IL_1f00:
																								num5 -= 2;
																								goto IL_1f0e;
																								IL_1f0e:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1f21:
																								if (65 < b)
																								{
																									goto IL_1f2f;
																								}
																								goto IL_1fe0;
																								IL_1f2f:
																								if (66 >= b)
																								{
																									goto IL_1f3a;
																								}
																								goto IL_1fb6;
																								IL_1f3a:
																								if (66 <= b)
																								{
																									goto IL_1f48;
																								}
																								goto IL_28a3;
																								IL_1f48:
																								((delegate*<List<GameEntityCreateData>, Player, bool, void>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 3], (Player)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0);
																								goto IL_1f95;
																								IL_1f95:
																								num5 -= 3;
																								goto IL_1fa3;
																								IL_1fa3:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_1fb6:
																								if (67 >= b)
																								{
																									goto IL_1fc4;
																								}
																								goto IL_28a3;
																								IL_1fc4:
																								if (67 <= b)
																								{
																									num = 132;
																								}
																								goto IL_28a3;
																								IL_278f:
																								array2[num5 - 1] = ((delegate*<ref Vector3, Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4));
																								goto IL_27fe;
																								IL_1fe0:
																								if (65 <= b)
																								{
																									goto IL_1feb;
																								}
																								goto IL_2016;
																								IL_1feb:
																								array2[num5] = null;
																								goto IL_1ff5;
																								IL_1ff5:
																								array[num5] = 5;
																								goto IL_2003;
																								IL_2003:
																								num5++;
																								goto end_IL_094c;
																								IL_2016:
																								if (64 >= b)
																								{
																									goto IL_2024;
																								}
																								goto IL_28a3;
																								IL_2024:
																								if (64 <= b)
																								{
																									goto IL_2032;
																								}
																								goto IL_28a3;
																								IL_2032:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																								goto IL_205d;
																								IL_205d:
																								array[num5 - 1] = 0;
																								goto end_IL_094c;
																								IL_2076:
																								if (51 <= b)
																								{
																									goto IL_2081;
																								}
																								goto IL_20ca;
																								IL_2081:
																								array6[*(int*)(ptr2 + num3)] = (Quaternion)array2[num5 - 1];
																								goto IL_20a9;
																								IL_20a9:
																								ptr2 += 8;
																								goto IL_20b7;
																								IL_20b7:
																								num5--;
																								goto end_IL_094c;
																								IL_20ca:
																								if (42 >= b)
																								{
																									goto IL_20d8;
																								}
																								goto IL_23f8;
																								IL_20d8:
																								if (42 > b)
																								{
																									goto IL_20e6;
																								}
																								num = 151;
																								goto IL_23b1;
																								IL_20e6:
																								if (38 >= b)
																								{
																									goto IL_20f4;
																								}
																								goto IL_2262;
																								IL_20f4:
																								if (38 <= b)
																								{
																									goto IL_20ff;
																								}
																								goto IL_2146;
																								IL_20ff:
																								array[num5] = 5;
																								goto IL_210d;
																								IL_210d:
																								array2[num5] = array6[*(int*)(ptr2 + num3)];
																								goto IL_2125;
																								IL_2125:
																								num5++;
																								goto IL_2133;
																								IL_2133:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_2146:
																								if (36 >= b)
																								{
																									goto IL_2154;
																								}
																								goto IL_222e;
																								IL_2154:
																								if (36 > b)
																								{
																									goto IL_2162;
																								}
																								num = 46;
																								goto IL_21ef;
																								IL_2162:
																								if (35 >= b)
																								{
																									num = 59;
																									goto IL_2179;
																								}
																								goto IL_28a3;
																								IL_2856:
																								array2[num5 - 1] = ((delegate*<Vector3, Quaternion>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																								goto IL_2893;
																								IL_2179:
																								if (35 <= b)
																								{
																									goto IL_2187;
																								}
																								goto IL_28a3;
																								IL_2187:
																								array2[num5] = ((delegate*<string[]>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])();
																								goto IL_21a5;
																								IL_21a5:
																								array[num5] = 5;
																								num = 321;
																								goto IL_21bc;
																								IL_21bc:
																								num5++;
																								goto IL_21ca;
																								IL_21ca:
																								ptr2 += 8;
																								num = 479;
																								goto end_IL_094c;
																								IL_281a:
																								if (50 >= b)
																								{
																									num = 205;
																									goto IL_282e;
																								}
																								goto IL_28a3;
																								IL_21ef:
																								array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_220d;
																								IL_220d:
																								ptr2 += 8;
																								goto IL_221b;
																								IL_221b:
																								num5--;
																								goto end_IL_094c;
																								IL_222e:
																								if (37 >= b)
																								{
																									goto IL_223c;
																								}
																								goto IL_28a3;
																								IL_223c:
																								if (37 <= b)
																								{
																									goto IL_224a;
																								}
																								goto IL_28a3;
																								IL_224a:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_094c;
																								IL_2262:
																								if (40 >= b)
																								{
																									goto IL_2270;
																								}
																								goto IL_2336;
																								IL_2270:
																								if (40 > b)
																								{
																									goto IL_227b;
																								}
																								goto IL_22f7;
																								IL_227b:
																								if (39 >= b)
																								{
																									goto IL_2289;
																								}
																								goto IL_28a3;
																								IL_2289:
																								if (39 <= b)
																								{
																									goto IL_2297;
																								}
																								goto IL_28a3;
																								IL_2297:
																								array2[num5 - 2] = ((string[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																								goto IL_22d0;
																								IL_22d0:
																								array[num5 - 2] = 5;
																								goto IL_22e4;
																								IL_22e4:
																								num5--;
																								goto end_IL_094c;
																								IL_22f7:
																								array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_2315;
																								IL_2315:
																								ptr2 += 8;
																								goto IL_2323;
																								IL_2323:
																								num5--;
																								goto end_IL_094c;
																								IL_2336:
																								if (41 >= b)
																								{
																									goto IL_2344;
																								}
																								goto IL_28a3;
																								IL_2344:
																								if (41 <= b)
																								{
																									num = 387;
																									goto IL_235b;
																								}
																								goto IL_28a3;
																								IL_282e:
																								if (50 <= b)
																								{
																									num = 44;
																									goto IL_2842;
																								}
																								goto IL_28a3;
																								IL_235b:
																								array2[num5] = ((delegate*<Dictionary<string, int>>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])();
																								goto IL_2379;
																								IL_2379:
																								array[num5] = 5;
																								goto IL_2387;
																								IL_2387:
																								num5++;
																								goto IL_2395;
																								IL_2395:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_27fe:
																								ptr2 += 8;
																								num = 464;
																								goto end_IL_094c;
																								IL_23b1:
																								array[num5] = 5;
																								goto IL_23bf;
																								IL_23bf:
																								array2[num5] = array6[*(int*)(ptr2 + num3)];
																								goto IL_23d7;
																								IL_23d7:
																								num5++;
																								goto IL_23e5;
																								IL_23e5:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_23f8:
																								if (46 >= b)
																								{
																									goto IL_2406;
																								}
																								goto IL_261f;
																								IL_2406:
																								if (46 <= b)
																								{
																									goto IL_2411;
																								}
																								goto IL_2463;
																								IL_2411:
																								array[num5] = 4;
																								goto IL_241f;
																								IL_241f:
																								array2[num5] = ((delegate*<Vector3>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])();
																								goto IL_2442;
																								IL_2442:
																								num5++;
																								goto IL_2450;
																								IL_2450:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_2463:
																								if (44 >= b)
																								{
																									goto IL_2471;
																								}
																								goto IL_25b2;
																								IL_2471:
																								if (44 <= b)
																								{
																									goto IL_247f;
																								}
																								goto IL_2506;
																								IL_247f:
																								array[num5 - 2] = 0;
																								goto IL_2493;
																								IL_2493:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]);
																								goto IL_24e5;
																								IL_24e5:
																								num5--;
																								goto IL_24f3;
																								IL_24f3:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_2506:
																								if (43 >= b)
																								{
																									goto IL_2514;
																								}
																								goto IL_28a3;
																								IL_2514:
																								if (43 <= b)
																								{
																									num = 344;
																									goto IL_252b;
																								}
																								goto IL_28a3;
																								IL_2893:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_252b:
																								array[num5 - 2] = 0;
																								goto IL_253f;
																								IL_253f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)AnsiBStrThreadPoolBoundHandleOverlapped[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]) ? 1 : 0);
																								goto IL_2591;
																								IL_2591:
																								num5--;
																								goto IL_259f;
																								IL_259f:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_25b2:
																								if (45 >= b)
																								{
																									goto IL_25c0;
																								}
																								goto IL_28a3;
																								IL_25c0:
																								if (45 <= b)
																								{
																									goto IL_25ce;
																								}
																								goto IL_28a3;
																								IL_25ce:
																								array[num5] = 4;
																								goto IL_25dc;
																								IL_25dc:
																								array2[num5] = (Vector3)array6[*(int*)(ptr2 + num3)];
																								goto IL_25fe;
																								IL_25fe:
																								num5++;
																								goto IL_260c;
																								IL_260c:
																								ptr2 += 8;
																								goto end_IL_094c;
																								IL_261f:
																								if (48 >= b)
																								{
																									goto IL_262d;
																								}
																								goto IL_275f;
																								IL_262d:
																								if (48 > b)
																								{
																									goto IL_263b;
																								}
																								num = 41;
																								goto IL_26f8;
																								continue;
																								end_IL_0919:
																								break;
																							}
																							continue;
																						}
																						goto IL_28a3;
																						IL_28a3:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_094c;
																						continue;
																						end_IL_0929:
																						break;
																					}
																					continue;
																					end_IL_093c:
																					break;
																				}
																				continue;
																				end_IL_094c:
																				break;
																			}
																			continue;
																			end_IL_28b6:
																			break;
																		}
																		continue;
																		end_IL_28c9:
																		break;
																	}
																	continue;
																	end_IL_28d3:
																	break;
																}
																continue;
																end_IL_28de:
																break;
															}
															continue;
															end_IL_28fd:
															break;
														}
														continue;
														end_IL_2913:
														break;
													}
													continue;
													end_IL_2929:
													break;
												}
												continue;
												end_IL_293f:
												break;
											}
											continue;
											end_IL_2955:
											break;
										}
										continue;
										end_IL_2965:
										break;
									}
									continue;
									end_IL_2975:
									break;
								}
								continue;
								end_IL_2985:
								break;
							}
							continue;
							end_IL_2995:
							break;
						}
						continue;
						end_IL_29a5:
						break;
					}
					continue;
					end_IL_29b5:
					break;
				}
				continue;
				end_IL_29c5:
				break;
			}
		}
	}

	public Class120()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 99;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RelatedActivityIdIsInterned.getVisualizerObjectSourceTypeNameGAC);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b1:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_028e:
																			if (5 < b)
																			{
																				num = 103;
																				while (true)
																				{
																					IL_0281:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0271:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0261:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_020f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01f0:
																													array[num5 - 2] = 0;
																													num = 112;
																													while (true)
																													{
																														if (num != 112)
																														{
																															if (num != 1093)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 42:
																																goto IL_01f0;
																															case 9:
																															case 41:
																																goto IL_020f;
																															case 48:
																																goto IL_0251;
																															case 85:
																															case 88:
																																goto IL_0261;
																															case 33:
																																goto IL_0271;
																															case 4:
																															case 103:
																																goto IL_0281;
																															case 20:
																																goto IL_028e;
																															case 13:
																																goto IL_02a1;
																															case 39:
																																goto IL_02b1;
																															case 25:
																																goto end_IL_02b1;
																															case 23:
																															case 60:
																																goto end_IL_02c1;
																															case 27:
																															case 44:
																																goto IL_02dc;
																															case 40:
																																goto IL_02e7;
																															case 29:
																																goto IL_02f7;
																															case 17:
																																goto IL_0305;
																															case 87:
																															case 89:
																																goto IL_0318;
																															case 93:
																																goto IL_0334;
																															case 28:
																															case 70:
																																goto IL_033f;
																															case 51:
																																goto IL_034d;
																															case 37:
																																goto IL_0370;
																															case 12:
																																goto IL_037a;
																															case 58:
																																goto IL_0388;
																															case 14:
																															case 30:
																																goto IL_03a4;
																															case 64:
																																goto IL_03af;
																															case 57:
																																goto IL_03ba;
																															case 11:
																																goto IL_03c8;
																															case 5:
																															case 21:
																																goto IL_03e4;
																															case 34:
																																goto IL_040d;
																															case 26:
																																goto IL_0426;
																															case 67:
																																goto IL_043c;
																															case 75:
																																goto IL_0453;
																															case 95:
																																goto IL_0466;
																															case 50:
																															case 81:
																																goto IL_0474;
																															case 98:
																																goto IL_048c;
																															case 100:
																															case 102:
																																goto IL_049f;
																															case 19:
																																goto IL_04b8;
																															case 94:
																																goto IL_04c6;
																															case 62:
																																goto IL_04d4;
																															case 10:
																															case 79:
																																goto IL_0503;
																															case 80:
																																goto IL_0511;
																															case 86:
																															case 105:
																																goto IL_051f;
																															case 15:
																																goto IL_0542;
																															case 73:
																																goto IL_0559;
																															case 16:
																																goto IL_0570;
																															case 18:
																															case 96:
																																goto IL_058c;
																															case 8:
																																goto IL_05f7;
																															case 0:
																															case 2:
																															case 22:
																															case 31:
																															case 32:
																															case 35:
																															case 36:
																															case 45:
																															case 47:
																															case 49:
																															case 52:
																															case 53:
																															case 55:
																															case 72:
																															case 78:
																															case 90:
																															case 92:
																															case 97:
																															case 101:
																															case 104:
																																goto end_IL_01dd;
																															case 1:
																															case 7:
																															case 43:
																															case 54:
																															case 59:
																															case 68:
																															case 69:
																															case 71:
																															case 74:
																															case 76:
																															case 77:
																															case 82:
																															case 91:
																																goto end_IL_02d1;
																															case 46:
																																goto end_IL_061a;
																															case 3:
																																goto end_IL_062d;
																															case 99:
																																goto end_IL_0637;
																															case 61:
																																goto end_IL_0642;
																															case 56:
																															case 63:
																																goto end_IL_0657;
																															case 84:
																																goto end_IL_0670;
																															case 6:
																															case 83:
																																goto end_IL_0680;
																															case 65:
																																goto end_IL_0690;
																															case 66:
																																goto end_IL_06a0;
																															case 24:
																															case 38:
																																goto IL_06bb;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_02d1;
																														continue;
																														end_IL_01dd:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																											IL_0251:;
																										}
																										break;
																									}
																									num = 10;
																									goto IL_0503;
																									IL_0559:
																									num5++;
																									num = 16;
																									goto IL_0570;
																									IL_0570:
																									ptr2 += 8;
																									num = 74;
																									goto end_IL_02d1;
																									IL_0503:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_0511;
																									IL_0511:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_051f;
																									IL_051f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0542;
																									IL_0542:
																									array[num5] = 0;
																									num = 73;
																									goto IL_0559;
																								}
																								break;
																							}
																							goto IL_058c;
																							IL_05f7:
																							num5 -= 2;
																							goto end_IL_02d1;
																							IL_058c:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 8;
																							goto IL_05f7;
																						}
																						break;
																					}
																					goto IL_02dc;
																					IL_0305:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_02dc:
																					if (9 >= b)
																					{
																						goto IL_02e7;
																					}
																					goto IL_02f7;
																					IL_02e7:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0318;
																					IL_0318:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02d1;
																					IL_02f7:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0305;
																				}
																				break;
																			}
																			goto IL_0334;
																			IL_0453:
																			if (4 <= b)
																			{
																				goto end_IL_02d1;
																			}
																			break;
																			IL_0466:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0474;
																			IL_0334:
																			if (5 <= b)
																			{
																				goto IL_033f;
																			}
																			num = 30;
																			goto IL_03a4;
																			IL_033f:
																			array[num5] = 0;
																			goto IL_034d;
																			IL_034d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0370;
																			IL_0370:
																			array2[num5] = null;
																			goto IL_037a;
																			IL_037a:
																			num5++;
																			goto IL_0388;
																			IL_0388:
																			ptr2 += 8;
																			goto end_IL_02d1;
																			IL_0474:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02d1;
																			IL_03a4:
																			if (2 >= b)
																			{
																				goto IL_03af;
																			}
																			goto IL_0426;
																			IL_03af:
																			if (2 > b)
																			{
																				goto IL_03ba;
																			}
																			goto IL_03e4;
																			IL_03ba:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_03c8;
																			IL_03c8:
																			if (1 > b)
																			{
																				break;
																			}
																			num = 100;
																			goto IL_049f;
																			IL_043c:
																			if (4 < b)
																			{
																				break;
																			}
																			num = 75;
																			goto IL_0453;
																			IL_049f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04b8;
																			IL_04b8:
																			array[num5] = 0;
																			goto IL_04c6;
																			IL_04c6:
																			num5++;
																			goto IL_04d4;
																			IL_04d4:
																			ptr2 += 8;
																			goto end_IL_02d1;
																			IL_03e4:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_040d;
																			IL_040d:
																			ptr2 += 8;
																			num = 98;
																			goto IL_048c;
																			IL_048c:
																			num5--;
																			goto end_IL_02d1;
																			IL_0426:
																			if (3 < b)
																			{
																				goto IL_043c;
																			}
																			num = 95;
																			goto IL_0466;
																		}
																		break;
																		IL_02a1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d1;
																continue;
																end_IL_02b1:
																break;
															}
															continue;
															end_IL_02c1:
															break;
														}
														continue;
														end_IL_02d1:
														break;
													}
													continue;
												}
												goto IL_06bb;
												IL_06bb:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_061a:
												break;
											}
											continue;
											end_IL_062d:
											break;
										}
										continue;
										end_IL_0637:
										break;
									}
									continue;
									end_IL_0642:
									break;
								}
								continue;
								end_IL_0657:
								break;
							}
							continue;
							end_IL_0670:
							break;
						}
						continue;
						end_IL_0680:
						break;
					}
					continue;
					end_IL_0690:
					break;
				}
				continue;
				end_IL_06a0:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1, int int_2)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 51;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 74;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setUseStdAsciiRulesgetString.BinaryCompatibilityMapBuildNumber);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_029a:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_027a:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_026a:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_025d:
																								if (9 <= b)
																								{
																									while (true)
																									{
																										IL_024d:
																										array[num5] = 0;
																										while (true)
																										{
																											IL_021e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)RecentLockAssemblyPath[*(int*)(ptr2 + num3)])();
																											num = 127;
																											while (true)
																											{
																												if (num != 127)
																												{
																													if (num != 1108)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 87:
																														goto IL_021e;
																													case 77:
																													case 110:
																														goto IL_024d;
																													case 6:
																														goto IL_025d;
																													case 46:
																													case 112:
																														goto IL_026a;
																													case 82:
																														goto IL_027a;
																													case 117:
																														goto IL_028a;
																													case 58:
																														goto IL_029a;
																													case 8:
																														goto end_IL_029a;
																													case 48:
																													case 63:
																														goto end_IL_02aa;
																													case 0:
																														goto IL_02c5;
																													case 72:
																														goto IL_02d0;
																													case 34:
																													case 35:
																														goto IL_02de;
																													case 24:
																														goto IL_02f7;
																													case 49:
																													case 76:
																														goto IL_0307;
																													case 85:
																														goto IL_0320;
																													case 95:
																														goto IL_0339;
																													case 65:
																														goto IL_0347;
																													case 75:
																													case 102:
																														goto IL_035a;
																													case 32:
																														goto IL_039a;
																													case 80:
																														goto IL_03ae;
																													case 42:
																														goto IL_03cf;
																													case 25:
																														goto IL_03e2;
																													case 91:
																														goto IL_03ed;
																													case 29:
																													case 41:
																														goto IL_03fb;
																													case 36:
																														goto IL_040e;
																													case 88:
																														goto IL_041c;
																													case 2:
																													case 7:
																														goto IL_042a;
																													case 62:
																														goto IL_0446;
																													case 28:
																													case 33:
																														goto IL_0454;
																													case 11:
																														goto IL_0462;
																													case 61:
																													case 71:
																														goto IL_0479;
																													case 52:
																														goto IL_0484;
																													case 67:
																													case 90:
																														goto IL_0497;
																													case 20:
																														goto IL_04a5;
																													case 16:
																													case 79:
																														goto IL_04b3;
																													case 19:
																														goto IL_04f3;
																													case 60:
																														goto IL_0507;
																													case 5:
																													case 31:
																														goto IL_051a;
																													case 55:
																														goto IL_0543;
																													case 93:
																														goto IL_0551;
																													case 69:
																														goto IL_0564;
																													case 26:
																													case 115:
																														goto IL_0572;
																													case 9:
																														goto IL_0580;
																													case 40:
																													case 104:
																														goto IL_058e;
																													case 81:
																														goto IL_059c;
																													case 47:
																														goto IL_05c8;
																													case 45:
																														goto IL_05d2;
																													case 103:
																														goto IL_05e0;
																													case 120:
																														goto IL_05f3;
																													case 70:
																													case 97:
																														goto IL_0601;
																													case 37:
																														goto IL_0641;
																													case 43:
																														goto IL_0655;
																													case 92:
																													case 118:
																														goto IL_0668;
																													case 15:
																														goto IL_06a8;
																													case 109:
																														goto IL_06bc;
																													case 3:
																													case 4:
																													case 12:
																													case 14:
																													case 17:
																													case 18:
																													case 21:
																													case 23:
																													case 30:
																													case 44:
																													case 50:
																													case 54:
																													case 56:
																													case 57:
																													case 59:
																													case 78:
																													case 86:
																													case 100:
																													case 119:
																														goto end_IL_020b;
																													case 105:
																														goto IL_06ef;
																													case 73:
																														goto IL_06fd;
																													case 108:
																														goto IL_070b;
																													case 1:
																													case 10:
																													case 66:
																													case 68:
																													case 83:
																													case 84:
																													case 89:
																													case 94:
																													case 96:
																													case 99:
																													case 106:
																													case 107:
																													case 111:
																														goto end_IL_02ba;
																													case 101:
																														goto end_IL_0719;
																													case 53:
																														goto end_IL_072c;
																													case 27:
																														goto end_IL_0736;
																													case 74:
																														goto end_IL_0741;
																													case 116:
																														goto end_IL_0756;
																													case 22:
																													case 114:
																														goto end_IL_076b;
																													case 113:
																														goto end_IL_0784;
																													case 13:
																													case 51:
																														goto end_IL_0794;
																													case 38:
																														goto end_IL_07a4;
																													case 39:
																														goto end_IL_07b4;
																													case 64:
																													case 98:
																														goto IL_07e1;
																													}
																													continue;
																												}
																												num5++;
																												goto IL_03cf;
																												IL_03cf:
																												ptr2 += 8;
																												goto end_IL_02ba;
																												continue;
																												end_IL_020b:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02c5;
																								IL_035a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_039a;
																								IL_02c5:
																								if (7 >= b)
																								{
																									goto IL_02d0;
																								}
																								goto IL_0307;
																								IL_02d0:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_02de;
																								IL_02de:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_02f7;
																								IL_02f7:
																								array[num5] = 0;
																								goto IL_0339;
																								IL_0339:
																								num5++;
																								goto IL_0347;
																								IL_0347:
																								ptr2 += 8;
																								goto end_IL_02ba;
																								IL_0307:
																								if (8 < b)
																								{
																									num = 17;
																									break;
																								}
																								goto IL_0320;
																								IL_039a:
																								array[num5 - 2] = 0;
																								goto IL_03ae;
																								IL_0320:
																								if (8 > b)
																								{
																									break;
																								}
																								num = 102;
																								goto IL_035a;
																								IL_03ae:
																								num5--;
																								goto end_IL_02ba;
																							}
																							break;
																						}
																						goto IL_03e2;
																						IL_042a:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02ba;
																						IL_03e2:
																						if (10 >= b)
																						{
																							goto IL_03ed;
																						}
																						goto IL_040e;
																						IL_03ed:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_03fb;
																						IL_03fb:
																						num5--;
																						goto end_IL_02ba;
																						IL_040e:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_041c;
																						IL_041c:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_042a;
																					}
																					break;
																				}
																				goto IL_0446;
																				IL_06a8:
																				array[num5 - 2] = 0;
																				goto IL_06bc;
																				IL_0446:
																				if (6 > b)
																				{
																					goto IL_0454;
																				}
																				goto IL_0668;
																				IL_0454:
																				if (3 >= b)
																				{
																					goto IL_0462;
																				}
																				goto IL_0564;
																				IL_0462:
																				if (3 > b)
																				{
																					num = 71;
																					goto IL_0479;
																				}
																				goto IL_051a;
																				IL_06bc:
																				num5--;
																				goto end_IL_02ba;
																				IL_0479:
																				if (1 >= b)
																				{
																					goto IL_0484;
																				}
																				goto IL_0497;
																				IL_0484:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0497:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_04a5;
																				IL_04a5:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_04b3;
																				IL_04b3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f3;
																				IL_04f3:
																				array[num5 - 2] = 0;
																				goto IL_0507;
																				IL_0507:
																				num5--;
																				goto end_IL_02ba;
																				IL_051a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0543;
																				IL_0543:
																				ptr2 += 8;
																				goto IL_0551;
																				IL_0551:
																				num5--;
																				goto end_IL_02ba;
																				IL_0564:
																				if (4 < b)
																				{
																					goto IL_0572;
																				}
																				goto IL_05f3;
																				IL_0572:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0580;
																				IL_0580:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_058e;
																				IL_058e:
																				array[num5] = 0;
																				goto IL_059c;
																				IL_059c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 47;
																				goto IL_05c8;
																				IL_05c8:
																				array2[num5] = null;
																				goto IL_05d2;
																				IL_05d2:
																				num5++;
																				goto IL_05e0;
																				IL_05e0:
																				ptr2 += 8;
																				goto end_IL_02ba;
																				IL_05f3:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0601;
																				IL_0601:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0641;
																				IL_0641:
																				array[num5 - 2] = 0;
																				goto IL_0655;
																				IL_0655:
																				num5--;
																				goto end_IL_02ba;
																				IL_0668:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06a8;
																			}
																			break;
																			IL_028a:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06ef;
																	IL_070b:
																	ptr2 += 8;
																	goto end_IL_02ba;
																	IL_06fd:
																	num5++;
																	goto IL_070b;
																	IL_06ef:
																	array[num5] = 0;
																	goto IL_06fd;
																	continue;
																	end_IL_029a:
																	break;
																}
																continue;
																end_IL_02aa:
																break;
															}
															continue;
															end_IL_02ba:
															break;
														}
														continue;
													}
													num = 98;
													goto IL_07e1;
													IL_07e1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0719:
													break;
												}
												continue;
												end_IL_072c:
												break;
											}
											continue;
											end_IL_0736:
											break;
										}
										continue;
										end_IL_0741:
										break;
									}
									continue;
									end_IL_0756:
									break;
								}
								continue;
								end_IL_076b:
								break;
							}
							continue;
							end_IL_0784:
							break;
						}
						continue;
						end_IL_0794:
						break;
					}
					continue;
					end_IL_07a4:
					break;
				}
				continue;
				end_IL_07b4:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_06f4:
						object[] array2 = new object[3];
						while (true)
						{
							IL_06e4:
							int[] array3 = new int[5];
							while (true)
							{
								IL_06d4:
								long[] array4 = new long[3];
								while (true)
								{
									IL_06bf:
									array3[0] = int_1;
									while (true)
									{
										IL_06aa:
										array3[1] = int_2;
										while (true)
										{
											IL_069f:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResumeSelfSid.MethodCallIDLFLAGFLCID);
											while (true)
											{
												IL_0695:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0682:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0289:
															byte b = *ptr2;
															num = 24;
															while (true)
															{
																IL_0279:
																ptr2++;
																while (true)
																{
																	IL_0269:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0249:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0239:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_022c:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0219:
																										if (2 > b)
																										{
																											num = 19;
																											while (true)
																											{
																												IL_0206:
																												if (1 < b)
																												{
																													num = 114;
																													while (num != 114)
																													{
																														if (num != 1095)
																														{
																															goto end_IL_0269;
																														}
																														switch (num)
																														{
																														case 19:
																														case 89:
																															goto IL_0206;
																														case 1:
																															goto IL_0219;
																														case 59:
																														case 97:
																															goto IL_022c;
																														case 16:
																															goto IL_0239;
																														case 42:
																															goto IL_0249;
																														case 34:
																															goto IL_0259;
																														case 96:
																															goto IL_0269;
																														case 24:
																															goto IL_0279;
																														case 47:
																														case 68:
																															goto IL_0289;
																														case 37:
																														case 43:
																															goto IL_029d;
																														case 61:
																															goto IL_02a8;
																														case 38:
																														case 53:
																															goto IL_02b6;
																														case 35:
																															goto IL_02e8;
																														case 6:
																														case 81:
																															goto IL_02f8;
																														case 17:
																															goto IL_030f;
																														case 83:
																															goto IL_031f;
																														case 54:
																														case 84:
																															goto IL_0332;
																														case 100:
																															goto IL_0372;
																														case 104:
																															goto IL_0386;
																														case 92:
																															goto IL_0399;
																														case 32:
																														case 73:
																															goto IL_03ac;
																														case 18:
																															goto IL_03ec;
																														case 87:
																															goto IL_0400;
																														case 71:
																														case 74:
																															goto IL_041c;
																														case 90:
																															goto IL_042a;
																														case 66:
																															goto IL_044d;
																														case 22:
																															goto IL_0457;
																														case 65:
																															goto IL_0465;
																														case 26:
																														case 88:
																															goto IL_0478;
																														case 25:
																															goto IL_0486;
																														case 0:
																														case 13:
																															goto IL_0494;
																														case 56:
																															goto IL_04a2;
																														case 39:
																														case 94:
																															goto IL_04b9;
																														case 67:
																															goto IL_04f9;
																														case 9:
																															goto IL_050d;
																														case 15:
																														case 23:
																															goto IL_0520;
																														case 64:
																															goto IL_0542;
																														case 8:
																															goto IL_0559;
																														case 55:
																															goto IL_0567;
																														case 21:
																															goto IL_057a;
																														case 33:
																														case 58:
																															goto IL_0585;
																														case 99:
																															goto IL_0593;
																														case 11:
																														case 76:
																															goto IL_05a1;
																														case 52:
																															goto IL_05bd;
																														case 44:
																														case 78:
																															goto IL_05c8;
																														case 4:
																															goto IL_0608;
																														case 29:
																															goto IL_061c;
																														case 2:
																														case 5:
																														case 10:
																														case 27:
																														case 28:
																														case 30:
																														case 31:
																														case 36:
																														case 40:
																														case 41:
																														case 49:
																														case 50:
																														case 75:
																														case 79:
																														case 98:
																														case 101:
																														case 102:
																															goto end_IL_01f3;
																														case 91:
																															goto IL_064f;
																														case 105:
																															goto IL_0666;
																														case 107:
																															goto IL_0674;
																														case 14:
																														case 45:
																														case 46:
																														case 48:
																														case 57:
																														case 69:
																														case 70:
																														case 77:
																														case 80:
																														case 82:
																														case 103:
																															goto IL_0682;
																														case 7:
																															goto IL_0695;
																														case 51:
																															goto IL_069f;
																														case 95:
																															goto IL_06aa;
																														case 72:
																															goto IL_06bf;
																														case 20:
																															goto IL_06d4;
																														case 60:
																														case 106:
																															goto IL_06e4;
																														case 12:
																															goto IL_06f4;
																														case 62:
																														case 63:
																															goto end_IL_0269;
																														case 85:
																															goto end_IL_0704;
																														case 86:
																															goto end_IL_0714;
																														case 3:
																														case 93:
																															goto IL_072f;
																														}
																														continue;
																														end_IL_01f3:
																														break;
																													}
																													break;
																												}
																												goto IL_0399;
																												IL_0399:
																												if (1 > b)
																												{
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_03ac;
																										IL_03ec:
																										array[num5 - 2] = 0;
																										goto IL_0400;
																										IL_0400:
																										num5--;
																										num = 80;
																										goto IL_0682;
																										IL_03ac:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03ec;
																									}
																									break;
																								}
																								goto IL_029d;
																								IL_0372:
																								array[num5 - 2] = 0;
																								goto IL_0386;
																								IL_029d:
																								if (3 >= b)
																								{
																									goto IL_02a8;
																								}
																								goto IL_02f8;
																								IL_02a8:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_02b6;
																								IL_02b6:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 35;
																								goto IL_02e8;
																								IL_02e8:
																								ptr2 += 8;
																								goto IL_031f;
																								IL_031f:
																								num5--;
																								goto IL_0682;
																								IL_02f8:
																								if (4 < b)
																								{
																									break;
																								}
																								num = 17;
																								goto IL_030f;
																								IL_0386:
																								num5--;
																								goto IL_0682;
																								IL_030f:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0332;
																								IL_0332:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0372;
																							}
																							break;
																						}
																						goto IL_041c;
																						IL_0465:
																						ptr2 += 8;
																						goto IL_0682;
																						IL_041c:
																						array[num5] = 0;
																						goto IL_042a;
																						IL_042a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_044d;
																						IL_044d:
																						array2[num5] = null;
																						goto IL_0457;
																						IL_0457:
																						num5++;
																						goto IL_0465;
																					}
																					break;
																				}
																				goto IL_0478;
																				IL_0608:
																				array[num5 - 2] = 0;
																				goto IL_061c;
																				IL_0478:
																				if (7 >= b)
																				{
																					goto IL_0486;
																				}
																				goto IL_057a;
																				IL_0486:
																				if (7 > b)
																				{
																					goto IL_0494;
																				}
																				goto IL_0520;
																				IL_0494:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_04a2;
																				IL_04a2:
																				if (6 > b)
																				{
																					break;
																				}
																				num = 39;
																				goto IL_04b9;
																				IL_061c:
																				num5--;
																				goto IL_0682;
																				IL_04b9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f9;
																				IL_04f9:
																				array[num5 - 2] = 0;
																				goto IL_050d;
																				IL_050d:
																				num5--;
																				goto IL_0682;
																				IL_0520:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 64;
																				goto IL_0542;
																				IL_0542:
																				array[num5] = 0;
																				num = 8;
																				goto IL_0559;
																				IL_0559:
																				num5++;
																				goto IL_0567;
																				IL_0567:
																				ptr2 += 8;
																				goto IL_0682;
																				IL_057a:
																				if (8 < b)
																				{
																					goto IL_0585;
																				}
																				goto IL_05bd;
																				IL_0585:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0593;
																				IL_0593:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_05a1;
																				IL_05a1:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_0682;
																				IL_05bd:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_05c8;
																				IL_05c8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0608;
																			}
																			break;
																			IL_0259:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_064f;
																	IL_0674:
																	ptr2 += 8;
																	goto IL_0682;
																	IL_0666:
																	num5++;
																	goto IL_0674;
																	IL_064f:
																	array[num5] = 0;
																	num = 105;
																	goto IL_0666;
																	continue;
																	end_IL_0269:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_072f;
													IL_072f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_0704:
					break;
				}
				continue;
				end_IL_0714:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1, int int_2)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WindowsFqbnVersionCurrentPrincipal.MemberInfoFromBaseString);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 91;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 50;
																	while (true)
																	{
																		IL_024d:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_0230:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0220:
																							if (5 <= b)
																							{
																								while (true)
																								{
																									IL_0210:
																									array[num5] = 0;
																									while (true)
																									{
																										IL_01e2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										num = 112;
																										while (true)
																										{
																											if (num != 112)
																											{
																												if (num != 1093)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 64:
																													goto IL_01e2;
																												case 16:
																												case 103:
																													goto IL_0210;
																												case 81:
																													goto IL_0220;
																												case 45:
																													goto IL_0230;
																												case 41:
																													goto end_IL_0230;
																												case 50:
																													goto IL_024d;
																												case 61:
																													goto end_IL_024d;
																												case 91:
																													goto end_IL_025d;
																												case 20:
																													goto end_IL_0276;
																												case 17:
																												case 48:
																													goto IL_028c;
																												case 76:
																													goto IL_029a;
																												case 8:
																												case 73:
																													goto IL_02a5;
																												case 67:
																													goto IL_02b8;
																												case 65:
																												case 74:
																													goto IL_02c6;
																												case 69:
																													goto end_IL_01cf;
																												case 33:
																													goto IL_0323;
																												case 86:
																													goto IL_0336;
																												case 0:
																												case 78:
																													goto IL_0341;
																												case 9:
																													goto IL_035a;
																												case 79:
																													goto IL_0368;
																												case 46:
																													goto IL_0376;
																												case 52:
																												case 88:
																													goto IL_0389;
																												case 37:
																													goto IL_0397;
																												case 7:
																												case 14:
																													goto IL_03a5;
																												case 44:
																													goto IL_03e5;
																												case 30:
																												case 90:
																													goto IL_03fe;
																												case 25:
																												case 84:
																													goto IL_040c;
																												case 62:
																													goto IL_041a;
																												case 89:
																													goto IL_0428;
																												case 4:
																												case 56:
																													goto IL_0433;
																												case 55:
																													goto IL_0473;
																												case 66:
																													goto IL_0487;
																												case 13:
																													goto IL_04a8;
																												case 43:
																												case 83:
																													goto IL_04b3;
																												case 28:
																													goto IL_04f3;
																												case 35:
																													goto IL_0507;
																												case 23:
																													goto IL_051a;
																												case 75:
																													goto IL_0528;
																												case 95:
																													goto IL_053b;
																												case 59:
																												case 71:
																													goto IL_0549;
																												case 58:
																													goto IL_0572;
																												case 96:
																													goto IL_058b;
																												case 22:
																												case 99:
																													goto IL_0596;
																												case 100:
																													goto IL_05b2;
																												case 101:
																													goto IL_05c5;
																												case 93:
																													goto IL_05e2;
																												case 2:
																													goto IL_05f0;
																												case 3:
																												case 5:
																												case 12:
																												case 15:
																												case 19:
																												case 21:
																												case 24:
																												case 29:
																												case 40:
																												case 49:
																												case 53:
																												case 77:
																												case 80:
																												case 85:
																												case 92:
																												case 94:
																												case 98:
																												case 105:
																													goto end_IL_023d;
																												case 97:
																													goto IL_0623;
																												case 26:
																													goto IL_063a;
																												case 54:
																													goto IL_0651;
																												case 1:
																												case 18:
																												case 32:
																												case 34:
																												case 36:
																												case 57:
																												case 60:
																												case 68:
																												case 72:
																												case 82:
																												case 104:
																													goto end_IL_0281;
																												case 51:
																													goto end_IL_065f;
																												case 47:
																													goto end_IL_0672;
																												case 63:
																													goto end_IL_067c;
																												case 11:
																													goto end_IL_0687;
																												case 31:
																													goto end_IL_069c;
																												case 6:
																												case 10:
																													goto end_IL_06b1;
																												case 42:
																													goto end_IL_06c1;
																												case 27:
																												case 70:
																													goto end_IL_06d1;
																												case 38:
																													goto end_IL_06e1;
																												case 39:
																													goto end_IL_06f1;
																												case 87:
																												case 102:
																													goto IL_070c;
																												}
																												continue;
																											}
																											array2[num5] = null;
																											goto IL_05e2;
																											IL_05e2:
																											num5++;
																											goto IL_05f0;
																											IL_05f0:
																											ptr2 += 8;
																											goto end_IL_0281;
																											continue;
																											end_IL_01cf:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_03fe;
																							IL_051a:
																							if (1 < b)
																							{
																								goto end_IL_023d;
																							}
																							goto IL_0528;
																							IL_03fe:
																							if (2 < b)
																							{
																								goto IL_040c;
																							}
																							goto IL_04a8;
																							IL_040c:
																							if (3 < b)
																							{
																								goto IL_041a;
																							}
																							goto IL_053b;
																							IL_041a:
																							if (4 < b)
																							{
																								goto end_IL_023d;
																							}
																							goto IL_0428;
																							IL_0428:
																							if (4 > b)
																							{
																								num = 92;
																								goto end_IL_023d;
																							}
																							goto IL_0433;
																							IL_0433:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0473;
																							IL_0473:
																							array[num5 - 2] = 0;
																							goto IL_0487;
																							IL_0487:
																							num5--;
																							goto end_IL_0281;
																							IL_0528:
																							if (1 > b)
																							{
																							}
																							goto end_IL_023d;
																							IL_053b:
																							if (3 > b)
																							{
																								goto end_IL_023d;
																							}
																							goto IL_0549;
																							IL_0549:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0572;
																							IL_0572:
																							ptr2 += 8;
																							num = 101;
																							goto IL_05c5;
																							IL_05c5:
																							num5--;
																							goto end_IL_0281;
																							IL_04a8:
																							if (2 <= b)
																							{
																								goto IL_04b3;
																							}
																							goto IL_051a;
																							IL_04b3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04f3;
																							IL_04f3:
																							array[num5 - 2] = 0;
																							goto IL_0507;
																							IL_0507:
																							num5--;
																							goto end_IL_0281;
																						}
																						goto IL_030f;
																					}
																					goto IL_028c;
																					IL_05b2:
																					num5--;
																					goto end_IL_0281;
																					IL_028c:
																					if (7 < b)
																					{
																						goto IL_029a;
																					}
																					goto IL_0336;
																					IL_029a:
																					if (8 < b)
																					{
																						goto IL_02a5;
																					}
																					goto IL_02b8;
																					IL_02a5:
																					if (9 < b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_058b;
																					IL_058b:
																					if (9 > b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_0596;
																					IL_0596:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0281;
																					IL_02b8:
																					if (8 > b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_02c6;
																					IL_02c6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 69;
																					goto IL_030f;
																					IL_030f:
																					array[num5 - 2] = 0;
																					goto IL_0323;
																					IL_0323:
																					num5--;
																					goto end_IL_0281;
																					IL_0336:
																					if (7 <= b)
																					{
																						goto IL_0341;
																					}
																					goto IL_0389;
																					IL_0341:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_035a;
																					IL_035a:
																					array[num5] = 0;
																					goto IL_0368;
																					IL_0368:
																					num5++;
																					goto IL_0376;
																					IL_0376:
																					ptr2 += 8;
																					goto end_IL_0281;
																					IL_0389:
																					if (6 < b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_0397;
																					IL_0397:
																					if (6 > b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_03a5;
																					IL_03a5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03e5;
																					IL_03e5:
																					array[num5 - 2] = 0;
																					goto IL_05b2;
																					continue;
																					end_IL_0230:
																					break;
																				}
																				continue;
																				end_IL_023d:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0623;
																		IL_0651:
																		ptr2 += 8;
																		goto end_IL_0281;
																		IL_063a:
																		num5++;
																		num = 54;
																		goto IL_0651;
																		IL_0623:
																		array[num5] = 0;
																		num = 26;
																		goto IL_063a;
																		continue;
																		end_IL_024d:
																		break;
																	}
																	continue;
																	end_IL_025d:
																	break;
																}
																continue;
																end_IL_0276:
																break;
															}
															continue;
															end_IL_0281:
															break;
														}
														continue;
													}
													goto IL_070c;
													IL_070c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_065f:
													break;
												}
												continue;
												end_IL_0672:
												break;
											}
											continue;
											end_IL_067c:
											break;
										}
										continue;
										end_IL_0687:
										break;
									}
									continue;
									end_IL_069c:
									break;
								}
								continue;
								end_IL_06b1:
								break;
							}
							continue;
							end_IL_06c1:
							break;
						}
						continue;
						end_IL_06d1:
						break;
					}
					continue;
					end_IL_06e1:
					break;
				}
				continue;
				end_IL_06f1:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 88;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 63;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								num = 47;
								while (true)
								{
									int[] array3 = new int[2];
									while (true)
									{
										long[] array4 = new long[4];
										while (true)
										{
											object[] array5 = new object[1];
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsHomogenousDebuggerNonUserCodeAttribute.UserClaimsApplicationEvidence);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_03c1:
																byte b = *ptr2;
																while (true)
																{
																	IL_03a8:
																	ptr2++;
																	num = 79;
																	while (true)
																	{
																		IL_0398:
																		if (b >= 1)
																		{
																			while (b <= 17)
																			{
																				while (true)
																				{
																					IL_037b:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_036b:
																							if (13 >= b)
																							{
																								while (true)
																								{
																									IL_035b:
																									if (13 <= b)
																									{
																										while (true)
																										{
																											IL_02f7:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											while (true)
																											{
																												IL_02de:
																												num5 -= 2;
																												num = 175;
																												while (num != 175)
																												{
																													if (num != 1156)
																													{
																														goto IL_073b;
																													}
																													switch (num)
																													{
																													case 51:
																														goto IL_02de;
																													case 45:
																													case 113:
																														goto IL_02f7;
																													case 117:
																														goto IL_035b;
																													case 31:
																														goto IL_036b;
																													case 111:
																														goto IL_037b;
																													case 71:
																														goto IL_0388;
																													case 79:
																														goto IL_0398;
																													case 124:
																														goto IL_03a8;
																													case 135:
																													case 161:
																														goto IL_03c1;
																													case 80:
																														goto IL_03cc;
																													case 15:
																													case 67:
																														goto IL_03da;
																													case 21:
																														goto IL_03e8;
																													case 93:
																													case 98:
																														goto IL_03f6;
																													case 6:
																													case 28:
																														goto IL_0401;
																													case 20:
																														goto IL_0411;
																													case 11:
																													case 43:
																														goto IL_041f;
																													case 108:
																														goto IL_0461;
																													case 56:
																													case 94:
																														goto IL_046f;
																													case 115:
																														goto IL_049d;
																													case 40:
																													case 121:
																														goto IL_04b6;
																													case 29:
																													case 112:
																														goto IL_04c1;
																													case 54:
																														goto IL_04cf;
																													case 89:
																													case 91:
																														goto IL_04dd;
																													case 103:
																														goto IL_051d;
																													case 133:
																														goto IL_053f;
																													case 32:
																													case 53:
																														goto IL_054d;
																													case 38:
																														goto IL_0591;
																													case 138:
																														goto IL_05a5;
																													case 68:
																													case 140:
																														goto IL_05b8;
																													case 2:
																														goto IL_05c6;
																													case 105:
																													case 142:
																														goto IL_05d9;
																													case 131:
																														goto IL_05f7;
																													case 37:
																														goto IL_0605;
																													case 145:
																														goto IL_0618;
																													case 46:
																														goto IL_0626;
																													case 52:
																													case 141:
																														goto IL_0631;
																													case 49:
																														goto IL_0670;
																													case 55:
																														goto IL_0683;
																													case 69:
																														goto IL_0691;
																													case 12:
																													case 81:
																														goto IL_069f;
																													case 44:
																														goto IL_06ad;
																													case 62:
																														goto IL_06c5;
																													case 13:
																													case 16:
																														goto IL_06d8;
																													case 34:
																														goto IL_06e3;
																													case 22:
																													case 116:
																														goto IL_06f1;
																													case 86:
																														goto IL_071a;
																													case 132:
																														goto IL_0728;
																													case 100:
																														goto IL_073b;
																													case 19:
																														goto IL_0749;
																													case 101:
																													case 130:
																														goto IL_0757;
																													case 149:
																														goto IL_076f;
																													case 24:
																													case 156:
																														goto IL_078b;
																													case 64:
																														goto IL_0799;
																													case 157:
																														goto IL_07a9;
																													case 158:
																														goto IL_07c2;
																													case 10:
																													case 163:
																														goto IL_07d5;
																													case 8:
																														goto IL_07e3;
																													case 4:
																														goto IL_0806;
																													case 18:
																														goto IL_0810;
																													case 48:
																														goto IL_081e;
																													case 143:
																													case 164:
																														goto IL_0831;
																													case 153:
																														goto IL_084a;
																													case 57:
																														goto IL_0858;
																													case 95:
																														goto IL_0866;
																													case 168:
																														goto IL_0882;
																													case 147:
																														goto IL_0895;
																													case 104:
																													case 151:
																														goto IL_08a0;
																													case 0:
																														goto IL_08ab;
																													case 41:
																													case 77:
																														goto IL_08b9;
																													case 127:
																														goto IL_08d5;
																													case 120:
																														goto IL_08e0;
																													case 134:
																														goto IL_090a;
																													case 78:
																													case 122:
																														goto IL_0915;
																													case 25:
																														goto IL_0928;
																													case 152:
																														goto IL_0936;
																													case 74:
																													case 102:
																														goto IL_0944;
																													case 110:
																														goto IL_0958;
																													case 99:
																														goto IL_09ac;
																													case 162:
																														goto IL_09ba;
																													case 1:
																													case 3:
																													case 5:
																													case 9:
																													case 14:
																													case 23:
																													case 27:
																													case 33:
																													case 42:
																													case 50:
																													case 59:
																													case 60:
																													case 72:
																													case 73:
																													case 75:
																													case 82:
																													case 85:
																													case 90:
																													case 92:
																													case 96:
																													case 107:
																													case 123:
																													case 125:
																													case 126:
																													case 129:
																													case 136:
																													case 139:
																													case 146:
																													case 154:
																													case 155:
																													case 159:
																													case 165:
																													case 166:
																														goto end_IL_0388;
																													case 7:
																													case 26:
																													case 30:
																													case 39:
																													case 61:
																													case 65:
																													case 66:
																													case 70:
																													case 76:
																													case 84:
																													case 97:
																													case 106:
																													case 109:
																													case 118:
																													case 128:
																													case 137:
																													case 144:
																													case 160:
																													case 167:
																														goto end_IL_02cb;
																													case 83:
																														goto end_IL_09e6;
																													case 35:
																														goto end_IL_09f9;
																													case 148:
																														goto end_IL_0a03;
																													case 114:
																														goto end_IL_0a0e;
																													case 47:
																														goto end_IL_0a1e;
																													case 36:
																														goto end_IL_0a2e;
																													case 119:
																														goto end_IL_0a3e;
																													case 63:
																														goto end_IL_0a49;
																													case 17:
																														goto end_IL_0a59;
																													case 87:
																														goto end_IL_0a69;
																													case 88:
																														goto end_IL_0a74;
																													case 58:
																													case 150:
																														goto IL_0a8f;
																													}
																													continue;
																													end_IL_02cb:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_04b6;
																									IL_081e:
																									ptr2 += 8;
																									break;
																									IL_04b6:
																									if (11 < b)
																									{
																										goto IL_04c1;
																									}
																									goto IL_053f;
																									IL_04c1:
																									if (12 < b)
																									{
																										goto end_IL_0388;
																									}
																									goto IL_04cf;
																									IL_04cf:
																									if (12 > b)
																									{
																										goto end_IL_0388;
																									}
																									goto IL_04dd;
																									IL_04dd:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_051d;
																									IL_051d:
																									array[num5 - 2] = 0;
																									num = 168;
																									goto IL_0882;
																									IL_0882:
																									num5--;
																									break;
																									IL_053f:
																									if (11 <= b)
																									{
																										goto IL_054d;
																									}
																									goto IL_078b;
																									IL_054d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_0591;
																									IL_0591:
																									array[num5 - 2] = 0;
																									goto IL_05a5;
																									IL_05a5:
																									num5--;
																									break;
																									IL_078b:
																									if (10 < b)
																									{
																										goto end_IL_0388;
																									}
																									goto IL_0799;
																									IL_0799:
																									if (10 > b)
																									{
																										goto end_IL_0388;
																									}
																									goto IL_07d5;
																									IL_07d5:
																									array[num5] = 0;
																									goto IL_07e3;
																									IL_07e3:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0806;
																									IL_0806:
																									array2[num5] = null;
																									goto IL_0810;
																									IL_0810:
																									num5++;
																									goto IL_081e;
																								}
																								break;
																							}
																							goto IL_0895;
																							IL_0958:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)setXMLlocalInit[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_09ac;
																							IL_0895:
																							if (15 < b)
																							{
																								goto IL_08a0;
																							}
																							goto IL_090a;
																							IL_08a0:
																							if (16 >= b)
																							{
																								goto IL_08ab;
																							}
																							goto IL_08d5;
																							IL_08ab:
																							if (16 > b)
																							{
																								goto end_IL_0388;
																							}
																							goto IL_08b9;
																							IL_08b9:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							break;
																							IL_08d5:
																							if (17 < b)
																							{
																								num = 125;
																								goto end_IL_0388;
																							}
																							goto IL_08e0;
																							IL_08e0:
																							if (17 > b)
																							{
																								num = 73;
																							}
																							goto end_IL_0388;
																							IL_09ba:
																							ptr2 += 8;
																							break;
																							IL_09ac:
																							num5--;
																							goto IL_09ba;
																							IL_090a:
																							if (15 <= b)
																							{
																								goto IL_0915;
																							}
																							goto IL_0928;
																							IL_0915:
																							num5--;
																							break;
																							IL_0928:
																							if (14 < b)
																							{
																								goto end_IL_0388;
																							}
																							goto IL_0936;
																							IL_0936:
																							if (14 > b)
																							{
																								num = 33;
																								goto end_IL_0388;
																							}
																							goto IL_0944;
																							IL_0944:
																							array[num5 - 2] = 0;
																							goto IL_0958;
																						}
																						break;
																					}
																					goto IL_03cc;
																					IL_0757:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_03cc:
																					if (9 <= b)
																					{
																						break;
																					}
																					goto IL_03da;
																					IL_03da:
																					if (4 >= b)
																					{
																						goto IL_03e8;
																					}
																					goto IL_0618;
																					IL_03e8:
																					if (4 > b)
																					{
																						goto IL_03f6;
																					}
																					goto IL_05d9;
																					IL_03f6:
																					if (2 < b)
																					{
																						goto IL_0401;
																					}
																					goto IL_0411;
																					IL_0401:
																					if (3 < b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_0461;
																					IL_0461:
																					if (3 > b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_046f;
																					IL_046f:
																					array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_07a9;
																					IL_07a9:
																					array[num5 - 1] = 5;
																					break;
																					IL_0411:
																					if (2 <= b)
																					{
																						goto IL_041f;
																					}
																					goto IL_05b8;
																					IL_041f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_049d;
																					IL_049d:
																					array[num5 - 2] = 0;
																					goto IL_07c2;
																					IL_07c2:
																					num5--;
																					break;
																					IL_05b8:
																					if (1 < b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_05c6;
																					IL_05c6:
																					if (1 > b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_0831;
																					IL_0831:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_084a;
																					IL_084a:
																					array[num5] = 0;
																					goto IL_0858;
																					IL_0858:
																					num5++;
																					goto IL_0866;
																					IL_0866:
																					ptr2 += 8;
																					num = 76;
																					break;
																					IL_05d9:
																					array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																					goto IL_05f7;
																					IL_05f7:
																					ptr2 += 8;
																					goto IL_0605;
																					IL_0605:
																					num5--;
																					break;
																					IL_0618:
																					if (6 >= b)
																					{
																						goto IL_0626;
																					}
																					goto IL_06d8;
																					IL_0626:
																					if (6 <= b)
																					{
																						goto IL_0631;
																					}
																					goto IL_0683;
																					IL_0631:
																					((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0670;
																					IL_0670:
																					num5 -= 3;
																					break;
																					IL_0683:
																					if (5 < b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_0691;
																					IL_0691:
																					if (5 > b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_069f;
																					IL_069f:
																					array[num5] = 5;
																					goto IL_06ad;
																					IL_06ad:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_06c5;
																					IL_06c5:
																					num5++;
																					goto IL_076f;
																					IL_076f:
																					ptr2 += 8;
																					num = 39;
																					break;
																					IL_06d8:
																					if (7 >= b)
																					{
																						goto IL_06e3;
																					}
																					goto IL_073b;
																					IL_06e3:
																					if (7 > b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_06f1;
																					IL_06f1:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_071a;
																					IL_071a:
																					ptr2 += 8;
																					goto IL_0728;
																					IL_0728:
																					num5--;
																					break;
																					IL_073b:
																					if (8 < b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_0749;
																					IL_0749:
																					if (8 > b)
																					{
																						goto end_IL_0388;
																					}
																					goto IL_0757;
																				}
																				goto end_IL_0398;
																				continue;
																				end_IL_0388:
																				break;
																				IL_0388:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0398:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_0a8f;
														IL_0a8f:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_09e6:
														break;
													}
													continue;
													end_IL_09f9:
													break;
												}
												continue;
												end_IL_0a03:
												break;
											}
											continue;
											end_IL_0a0e:
											break;
										}
										continue;
										end_IL_0a1e:
										break;
									}
									continue;
									end_IL_0a2e:
									break;
								}
								continue;
								end_IL_0a3e:
								break;
							}
							continue;
							end_IL_0a49:
							break;
						}
						continue;
						end_IL_0a59:
						break;
					}
					continue;
					end_IL_0a69:
					break;
				}
				continue;
				end_IL_0a74:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 70;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ZAPRights.MicrosoftTelemetryKeyValuePairComparator);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02d0:
																	if (b >= 1)
																	{
																		goto IL_01b3;
																	}
																	goto IL_02a8;
																	IL_02a8:
																	while (true)
																	{
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_019a:
																			array[num5] = 0;
																			num = 94;
																			while (true)
																			{
																				if (num != 94)
																				{
																					if (num != 1075)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 32:
																						goto IL_019a;
																					case 18:
																						goto end_IL_02a8;
																					case 52:
																						goto IL_01c1;
																					case 2:
																						goto IL_01cc;
																					case 10:
																						goto IL_01da;
																					case 48:
																						goto IL_01e8;
																					case 36:
																					case 61:
																						goto IL_0201;
																					case 17:
																						goto IL_020c;
																					case 56:
																						goto IL_021a;
																					case 22:
																						goto IL_0231;
																					case 49:
																					case 75:
																						goto IL_0241;
																					case 21:
																						goto IL_024c;
																					case 73:
																					case 77:
																						goto IL_025c;
																					case 6:
																						goto IL_0267;
																					case 84:
																						goto IL_0274;
																					case 35:
																						goto IL_027f;
																					case 29:
																					case 87:
																						goto IL_028f;
																					case 47:
																						goto IL_029a;
																					case 1:
																					case 5:
																					case 26:
																					case 28:
																					case 31:
																					case 54:
																					case 60:
																					case 65:
																					case 66:
																					case 67:
																					case 78:
																					case 80:
																					case 83:
																					case 85:
																					case 86:
																						goto end_IL_0187;
																					case 42:
																						goto IL_02d0;
																					case 81:
																						goto end_IL_02d0;
																					case 7:
																					case 44:
																						goto end_IL_02e0;
																					case 12:
																					case 34:
																						goto IL_02fb;
																					case 57:
																						goto IL_0324;
																					case 40:
																						goto IL_0332;
																					case 4:
																					case 68:
																						goto IL_0353;
																					case 59:
																					case 74:
																						goto IL_036b;
																					case 13:
																						goto IL_0379;
																					case 24:
																						goto IL_039c;
																					case 43:
																						goto IL_03a6;
																					case 79:
																						goto IL_03b4;
																					case 58:
																					case 82:
																						goto IL_03c7;
																					case 41:
																						goto IL_0435;
																					case 39:
																					case 76:
																						goto IL_0448;
																					case 11:
																					case 62:
																						goto IL_0464;
																					case 72:
																						goto IL_04a4;
																					case 14:
																						goto IL_04b8;
																					case 20:
																						goto IL_04d6;
																					case 0:
																					case 3:
																					case 9:
																					case 19:
																					case 25:
																					case 37:
																					case 38:
																					case 45:
																					case 46:
																					case 50:
																					case 64:
																						goto end_IL_02f0;
																					case 15:
																						goto end_IL_04e4;
																					case 55:
																						goto end_IL_04f7;
																					case 23:
																						goto end_IL_0501;
																					case 16:
																						goto end_IL_050c;
																					case 33:
																						goto end_IL_0521;
																					case 51:
																					case 71:
																						goto end_IL_0536;
																					case 63:
																						goto end_IL_0546;
																					case 27:
																					case 30:
																						goto end_IL_0556;
																					case 69:
																						goto end_IL_0566;
																					case 70:
																						goto end_IL_0576;
																					case 8:
																					case 53:
																						goto IL_0591;
																					}
																					continue;
																				}
																				num5++;
																				goto IL_04d6;
																				IL_04d6:
																				ptr2 += 8;
																				goto end_IL_02f0;
																				continue;
																				end_IL_0187:
																				break;
																			}
																			break;
																		}
																		continue;
																		end_IL_02a8:
																		break;
																	}
																	goto IL_01b3;
																	IL_01b3:
																	if (b <= 8)
																	{
																		goto IL_01c1;
																	}
																	goto IL_02a8;
																	IL_01c1:
																	if (4 >= b)
																	{
																		goto IL_01cc;
																	}
																	goto IL_0201;
																	IL_01cc:
																	if (4 > b)
																	{
																		goto IL_01da;
																	}
																	goto IL_02fb;
																	IL_01da:
																	if (2 >= b)
																	{
																		goto IL_01e8;
																	}
																	goto IL_028f;
																	IL_01e8:
																	if (2 > b)
																	{
																		num = 73;
																		goto IL_025c;
																	}
																	goto IL_03c7;
																	IL_0274:
																	if (8 >= b)
																	{
																		goto IL_027f;
																	}
																	goto IL_02a8;
																	IL_025c:
																	if (1 >= b)
																	{
																		goto IL_0267;
																	}
																	goto IL_02a8;
																	IL_0267:
																	if (1 > b)
																	{
																	}
																	goto IL_02a8;
																	IL_03c7:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0435;
																	IL_0435:
																	num5 -= 2;
																	goto end_IL_02f0;
																	IL_028f:
																	if (3 >= b)
																	{
																		goto IL_029a;
																	}
																	goto IL_02a8;
																	IL_029a:
																	if (3 > b)
																	{
																		goto IL_02a8;
																	}
																	goto IL_0464;
																	IL_0464:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04a4;
																	IL_04a4:
																	array[num5 - 2] = 0;
																	goto IL_04b8;
																	IL_04b8:
																	num5--;
																	goto end_IL_02f0;
																	IL_02fb:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0324;
																	IL_0324:
																	ptr2 += 8;
																	goto IL_0332;
																	IL_0332:
																	num5--;
																	goto end_IL_02f0;
																	IL_0201:
																	if (6 >= b)
																	{
																		goto IL_020c;
																	}
																	goto IL_0241;
																	IL_020c:
																	if (6 <= b)
																	{
																		num = 50;
																		goto end_IL_02f0;
																	}
																	goto IL_021a;
																	IL_021a:
																	if (5 >= b)
																	{
																		num = 22;
																		goto IL_0231;
																	}
																	goto IL_02a8;
																	IL_0448:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_02f0;
																	IL_0231:
																	if (5 > b)
																	{
																		goto IL_02a8;
																	}
																	goto IL_0353;
																	IL_0353:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02f0;
																	IL_027f:
																	if (8 > b)
																	{
																		goto IL_02a8;
																	}
																	goto IL_0448;
																	IL_0241:
																	if (7 >= b)
																	{
																		goto IL_024c;
																	}
																	goto IL_0274;
																	IL_024c:
																	if (7 > b)
																	{
																		goto IL_02a8;
																	}
																	goto IL_036b;
																	IL_036b:
																	array[num5] = 0;
																	goto IL_0379;
																	IL_0379:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_039c;
																	IL_039c:
																	array2[num5] = null;
																	goto IL_03a6;
																	IL_03a6:
																	num5++;
																	goto IL_03b4;
																	IL_03b4:
																	ptr2 += 8;
																	goto end_IL_02f0;
																	continue;
																	end_IL_02d0:
																	break;
																}
																continue;
																end_IL_02e0:
																break;
															}
															continue;
															end_IL_02f0:
															break;
														}
														continue;
													}
													goto IL_0591;
													IL_0591:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04e4:
													break;
												}
												continue;
												end_IL_04f7:
												break;
											}
											continue;
											end_IL_0501:
											break;
										}
										continue;
										end_IL_050c:
										break;
									}
									continue;
									end_IL_0521:
									break;
								}
								continue;
								end_IL_0536:
								break;
							}
							continue;
							end_IL_0546:
							break;
						}
						continue;
						end_IL_0556:
						break;
					}
					continue;
					end_IL_0566:
					break;
				}
				continue;
				end_IL_0576:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 91;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 107;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 44;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreateSinkVTPTR.WinapiSeekOrigin);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02f0:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02d0:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02c0:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02b0:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02a0:
																									if (10 < b)
																									{
																										num = 156;
																										while (true)
																										{
																											if (num != 156)
																											{
																												if (num != 1137)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 52:
																												case 61:
																													goto IL_02a0;
																												case 20:
																													goto IL_02b0;
																												case 37:
																													goto IL_02c0;
																												case 5:
																													goto IL_02d0;
																												case 42:
																													goto end_IL_02d0;
																												case 126:
																													goto IL_02f0;
																												case 94:
																													goto end_IL_02f0;
																												case 28:
																												case 72:
																													goto end_IL_0300;
																												case 12:
																													goto IL_031b;
																												case 15:
																												case 41:
																													goto IL_0326;
																												case 86:
																													goto IL_0334;
																												case 92:
																													goto IL_035c;
																												case 88:
																													goto IL_036a;
																												case 115:
																												case 137:
																													goto IL_037d;
																												case 99:
																													goto IL_0388;
																												case 9:
																													goto IL_0396;
																												case 96:
																													goto IL_03b2;
																												case 82:
																												case 103:
																													goto IL_03c0;
																												case 59:
																													goto IL_03ce;
																												case 31:
																												case 55:
																													goto IL_03dc;
																												case 27:
																													goto IL_043e;
																												case 76:
																												case 130:
																													goto IL_045a;
																												case 142:
																													goto IL_0476;
																												case 138:
																													goto IL_0480;
																												case 134:
																													goto IL_048e;
																												case 66:
																													goto IL_04a1;
																												case 95:
																													goto IL_04af;
																												case 6:
																												case 83:
																													goto IL_04bd;
																												case 106:
																													goto IL_0501;
																												case 113:
																													goto IL_051e;
																												case 13:
																												case 16:
																													goto IL_0531;
																												case 34:
																													goto IL_0571;
																												case 30:
																													goto IL_0585;
																												case 26:
																													goto IL_05a1;
																												case 11:
																												case 119:
																													goto IL_05af;
																												case 98:
																													goto IL_05bd;
																												case 73:
																													goto IL_05cb;
																												case 67:
																												case 75:
																													goto end_IL_028d;
																												case 102:
																													goto IL_05e4;
																												case 1:
																												case 79:
																													goto IL_05f2;
																												case 43:
																													goto IL_0600;
																												case 104:
																													goto IL_0618;
																												case 29:
																													goto IL_0626;
																												case 47:
																												case 135:
																													goto IL_0639;
																												case 22:
																													goto IL_0678;
																												case 71:
																												case 105:
																													goto IL_0694;
																												case 17:
																													goto IL_06a2;
																												case 45:
																												case 78:
																													goto IL_06b0;
																												case 148:
																													goto IL_06d9;
																												case 141:
																													goto IL_06e7;
																												case 118:
																													goto IL_0703;
																												case 85:
																												case 97:
																													goto IL_070e;
																												case 46:
																													goto IL_072c;
																												case 139:
																													goto IL_073a;
																												case 21:
																													goto IL_074d;
																												case 4:
																													goto IL_075b;
																												case 132:
																												case 136:
																													goto IL_0766;
																												case 146:
																													goto IL_0774;
																												case 2:
																												case 101:
																													goto IL_0782;
																												case 100:
																													goto IL_079b;
																												case 68:
																													goto IL_07b2;
																												case 117:
																													goto IL_07c0;
																												case 60:
																												case 129:
																													goto IL_07d3;
																												case 131:
																													goto IL_0813;
																												case 123:
																													goto IL_0827;
																												case 121:
																													goto IL_083a;
																												case 23:
																													goto IL_0845;
																												case 89:
																												case 114:
																													goto IL_0850;
																												case 18:
																													goto IL_0882;
																												case 25:
																												case 53:
																													goto IL_0898;
																												case 3:
																												case 7:
																												case 10:
																												case 19:
																												case 35:
																												case 36:
																												case 38:
																												case 40:
																												case 48:
																												case 50:
																												case 51:
																												case 56:
																												case 57:
																												case 58:
																												case 62:
																												case 63:
																												case 70:
																												case 80:
																												case 81:
																												case 108:
																												case 116:
																												case 120:
																												case 122:
																												case 124:
																												case 128:
																												case 133:
																												case 143:
																												case 147:
																													goto end_IL_02e0;
																												case 0:
																												case 24:
																												case 32:
																												case 33:
																												case 39:
																												case 64:
																												case 69:
																												case 77:
																												case 84:
																												case 87:
																												case 93:
																												case 111:
																												case 125:
																												case 127:
																												case 140:
																												case 144:
																												case 145:
																												case 149:
																													goto end_IL_0310;
																												case 109:
																													goto end_IL_08c0;
																												case 65:
																													goto end_IL_08d3;
																												case 44:
																													goto end_IL_08dd;
																												case 112:
																													goto end_IL_08e8;
																												case 54:
																												case 110:
																													goto end_IL_08f8;
																												case 49:
																													goto end_IL_0911;
																												case 74:
																												case 107:
																													goto end_IL_0921;
																												case 90:
																													goto end_IL_0931;
																												case 91:
																													goto end_IL_0941;
																												case 8:
																												case 14:
																													goto IL_0965;
																												}
																												continue;
																											}
																											goto IL_04a1;
																											IL_0501:
																											array[num5 - 2] = 0;
																											num = 113;
																											goto IL_051e;
																											IL_051e:
																											num5--;
																											goto end_IL_0310;
																											IL_04a1:
																											if (11 < b)
																											{
																												goto end_IL_02e0;
																											}
																											goto IL_04af;
																											IL_04af:
																											if (11 > b)
																											{
																												goto end_IL_02e0;
																											}
																											goto IL_04bd;
																											IL_04bd:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_0501;
																											continue;
																											end_IL_028d:
																											break;
																										}
																										break;
																									}
																									goto IL_031b;
																									IL_035c:
																									if (9 < b)
																									{
																										goto end_IL_02e0;
																									}
																									goto IL_036a;
																									IL_036a:
																									if (9 > b)
																									{
																										goto end_IL_02e0;
																									}
																									goto end_IL_0310;
																									IL_031b:
																									if (10 <= b)
																									{
																										goto IL_0326;
																									}
																									goto IL_035c;
																									IL_0326:
																									array[num5] = 0;
																									goto IL_0334;
																									IL_0334:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0476;
																									IL_0476:
																									array2[num5] = null;
																									goto IL_0480;
																									IL_0480:
																									num5++;
																									goto IL_048e;
																									IL_048e:
																									ptr2 += 8;
																									goto end_IL_0310;
																								}
																								break;
																							}
																							goto IL_0531;
																							IL_0585:
																							num5--;
																							goto end_IL_0310;
																							IL_0531:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0571;
																							IL_0571:
																							array[num5 - 2] = 0;
																							goto IL_0585;
																						}
																						break;
																					}
																					goto IL_037d;
																					IL_043e:
																					num5 -= 2;
																					num = 24;
																					goto end_IL_0310;
																					IL_037d:
																					if (14 < b)
																					{
																						goto IL_0388;
																					}
																					num = 96;
																					goto IL_03b2;
																					IL_0388:
																					if (15 < b)
																					{
																						goto end_IL_02e0;
																					}
																					goto IL_0396;
																					IL_0396:
																					if (15 <= b)
																					{
																					}
																					goto end_IL_02e0;
																					IL_045a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0310;
																					IL_03b2:
																					if (14 > b)
																					{
																						goto IL_03c0;
																					}
																					goto IL_045a;
																					IL_03c0:
																					if (13 < b)
																					{
																						goto end_IL_02e0;
																					}
																					goto IL_03ce;
																					IL_03ce:
																					if (13 > b)
																					{
																						goto end_IL_02e0;
																					}
																					goto IL_03dc;
																					IL_03dc:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_043e;
																				}
																				goto IL_05d6;
																			}
																			num = 26;
																			goto IL_05a1;
																			IL_0845:
																			if (3 > b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_0850;
																			IL_0850:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 18;
																			goto IL_0882;
																			IL_05a1:
																			if (8 > b)
																			{
																				goto IL_05af;
																			}
																			goto IL_0898;
																			IL_05af:
																			if (4 < b)
																			{
																				goto IL_05bd;
																			}
																			num = 118;
																			goto IL_0703;
																			IL_05bd:
																			if (6 >= b)
																			{
																				goto IL_05cb;
																			}
																			num = 71;
																			goto IL_0694;
																			IL_05cb:
																			if (6 > b)
																			{
																				goto IL_05d6;
																			}
																			goto IL_0639;
																			IL_05d6:
																			if (5 < b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_05e4;
																			IL_05e4:
																			if (5 > b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_05f2;
																			IL_05f2:
																			array[num5] = 5;
																			goto IL_0600;
																			IL_0600:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0618;
																			IL_0618:
																			num5++;
																			goto IL_0626;
																			IL_0626:
																			ptr2 += 8;
																			goto end_IL_0310;
																			IL_0639:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0678;
																			IL_0678:
																			num5 -= 3;
																			goto end_IL_0310;
																			IL_0898:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0310;
																			IL_0694:
																			if (7 < b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_06a2;
																			IL_06a2:
																			if (7 > b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_06b0;
																			IL_06b0:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06d9;
																			IL_06d9:
																			ptr2 += 8;
																			goto IL_06e7;
																			IL_06e7:
																			num5--;
																			goto end_IL_0310;
																			IL_0882:
																			array[num5 - 1] = 5;
																			goto end_IL_0310;
																			IL_0703:
																			if (4 <= b)
																			{
																				goto IL_070e;
																			}
																			goto IL_074d;
																			IL_070e:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_072c;
																			IL_072c:
																			ptr2 += 8;
																			goto IL_073a;
																			IL_073a:
																			num5--;
																			goto end_IL_0310;
																			IL_074d:
																			if (2 >= b)
																			{
																				goto IL_075b;
																			}
																			goto IL_083a;
																			IL_075b:
																			if (2 > b)
																			{
																				goto IL_0766;
																			}
																			goto IL_07d3;
																			IL_0766:
																			if (1 < b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_0774;
																			IL_0774:
																			if (1 > b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_0782;
																			IL_0782:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_079b;
																			IL_079b:
																			array[num5] = 0;
																			num = 68;
																			goto IL_07b2;
																			IL_07b2:
																			num5++;
																			goto IL_07c0;
																			IL_07c0:
																			ptr2 += 8;
																			goto end_IL_0310;
																			IL_07d3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0813;
																			IL_0813:
																			array[num5 - 2] = 0;
																			goto IL_0827;
																			IL_0827:
																			num5--;
																			goto end_IL_0310;
																			IL_083a:
																			if (3 < b)
																			{
																				goto end_IL_02e0;
																			}
																			goto IL_0845;
																			continue;
																			end_IL_02d0:
																			break;
																		}
																		continue;
																		end_IL_02e0:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0310;
																continue;
																end_IL_02f0:
																break;
															}
															continue;
															end_IL_0300:
															break;
														}
														continue;
														end_IL_0310:
														break;
													}
													continue;
												}
												goto IL_0965;
												IL_0965:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c0:
												break;
											}
											continue;
											end_IL_08d3:
											break;
										}
										continue;
										end_IL_08dd:
										break;
									}
									continue;
									end_IL_08e8:
									break;
								}
								continue;
								end_IL_08f8:
								break;
							}
							continue;
							end_IL_0911:
							break;
						}
						continue;
						end_IL_0921:
						break;
					}
					continue;
					end_IL_0931:
					break;
				}
				continue;
				end_IL_0941:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 14;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetAsciiparamdesc.COREISOSTORESerializationMissingKeys);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02f9:
															byte b = *ptr2;
															while (true)
															{
																IL_02e9:
																ptr2++;
																while (true)
																{
																	IL_02d9:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_02cc:
																			if (b <= 12)
																			{
																				while (true)
																				{
																					IL_02bf:
																					if (6 >= b)
																					{
																						while (6 > b)
																						{
																							while (true)
																							{
																								IL_029f:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_028f:
																										if (3 <= b)
																										{
																											while (true)
																											{
																												IL_024d:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_0237:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_021e:
																														num5--;
																														num = 127;
																														while (num != 127)
																														{
																															if (num != 1108)
																															{
																																goto IL_02bf;
																															}
																															switch (num)
																															{
																															case 84:
																																goto IL_021e;
																															case 65:
																																goto IL_0237;
																															case 68:
																															case 93:
																																goto IL_024d;
																															case 119:
																																goto IL_028f;
																															case 41:
																															case 85:
																																goto IL_029f;
																															case 20:
																																goto IL_02af;
																															case 76:
																																goto IL_02bf;
																															case 9:
																																goto IL_02cc;
																															case 108:
																																goto IL_02d9;
																															case 18:
																																goto IL_02e9;
																															case 89:
																															case 99:
																																goto IL_02f9;
																															case 28:
																																goto IL_0312;
																															case 37:
																																goto IL_0320;
																															case 87:
																																goto IL_032e;
																															case 26:
																															case 39:
																																goto IL_0339;
																															case 22:
																																goto IL_034c;
																															case 45:
																																goto IL_035a;
																															case 62:
																															case 75:
																																goto IL_0368;
																															case 7:
																																goto IL_037c;
																															case 59:
																																goto IL_03bb;
																															case 90:
																																goto IL_03ce;
																															case 21:
																															case 56:
																																goto IL_03d9;
																															case 66:
																																goto IL_0419;
																															case 60:
																																goto IL_042d;
																															case 54:
																																goto IL_0440;
																															case 46:
																																goto IL_044b;
																															case 23:
																															case 71:
																																goto IL_0467;
																															case 0:
																															case 101:
																																goto IL_0477;
																															case 67:
																																goto IL_0482;
																															case 47:
																																goto IL_0492;
																															case 82:
																																goto IL_04a0;
																															case 102:
																																goto IL_04b3;
																															case 32:
																															case 74:
																																goto IL_04c1;
																															case 81:
																																goto IL_04da;
																															case 50:
																																goto IL_04e8;
																															case 72:
																																goto IL_04f6;
																															case 10:
																															case 113:
																																goto IL_0509;
																															case 111:
																																goto IL_0532;
																															case 88:
																																goto IL_0540;
																															case 40:
																															case 114:
																																goto IL_0553;
																															case 91:
																															case 116:
																																goto IL_056b;
																															case 92:
																																goto IL_0579;
																															case 4:
																															case 52:
																																goto IL_0587;
																															case 3:
																															case 118:
																																goto IL_05a3;
																															case 5:
																																goto IL_05b1;
																															case 80:
																																goto IL_05d4;
																															case 64:
																																goto IL_05e7;
																															case 19:
																																goto IL_05f5;
																															case 35:
																																goto IL_0608;
																															case 33:
																																goto IL_0613;
																															case 49:
																																goto IL_0626;
																															case 29:
																																goto IL_0634;
																															case 15:
																															case 105:
																																goto IL_063f;
																															case 103:
																																goto IL_06ad;
																															case 1:
																															case 12:
																															case 16:
																															case 17:
																															case 25:
																															case 27:
																															case 30:
																															case 31:
																															case 34:
																															case 36:
																															case 38:
																															case 55:
																															case 79:
																															case 83:
																															case 94:
																															case 98:
																															case 100:
																															case 106:
																															case 107:
																															case 112:
																															case 115:
																																goto end_IL_02cc;
																															case 11:
																																goto IL_06e0;
																															case 42:
																																goto IL_06ee;
																															case 95:
																																goto IL_06fc;
																															case 2:
																															case 24:
																															case 43:
																															case 44:
																															case 51:
																															case 73:
																															case 77:
																															case 78:
																															case 86:
																															case 96:
																															case 97:
																															case 109:
																															case 117:
																															case 120:
																																goto end_IL_020b;
																															case 110:
																																goto end_IL_070a;
																															case 70:
																																goto end_IL_071d;
																															case 104:
																																goto end_IL_0727;
																															case 48:
																																goto end_IL_0732;
																															case 8:
																																goto end_IL_0747;
																															case 6:
																															case 69:
																																goto end_IL_075c;
																															case 58:
																																goto end_IL_076c;
																															case 53:
																															case 63:
																																goto end_IL_077c;
																															case 13:
																																goto end_IL_078c;
																															case 14:
																																goto end_IL_079c;
																															case 57:
																															case 61:
																																goto IL_07b7;
																															}
																															continue;
																															end_IL_020b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_0608;
																										IL_06ad:
																										num5 -= 2;
																										break;
																										IL_0608:
																										if (1 >= b)
																										{
																											goto IL_0613;
																										}
																										goto IL_0626;
																										IL_0613:
																										if (1 > b)
																										{
																										}
																										goto end_IL_02cc;
																										IL_0626:
																										if (2 < b)
																										{
																											goto end_IL_02cc;
																										}
																										goto IL_0634;
																										IL_0634:
																										if (2 > b)
																										{
																											goto end_IL_02cc;
																										}
																										goto IL_063f;
																										IL_063f:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_06ad;
																									}
																									break;
																								}
																								goto IL_0477;
																								IL_0553:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_0477:
																								if (4 >= b)
																								{
																									goto IL_0482;
																								}
																								goto IL_0492;
																								IL_0482:
																								if (4 > b)
																								{
																									goto end_IL_02cc;
																								}
																								goto IL_0509;
																								IL_0509:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0532;
																								IL_0532:
																								ptr2 += 8;
																								goto IL_0540;
																								IL_0540:
																								num5--;
																								break;
																								IL_0492:
																								if (5 < b)
																								{
																									goto end_IL_02cc;
																								}
																								goto IL_04a0;
																								IL_04a0:
																								if (5 > b)
																								{
																									goto end_IL_02cc;
																								}
																								goto IL_0553;
																							}
																							break;
																							IL_02af:;
																						}
																						break;
																					}
																					goto IL_0312;
																					IL_04e8:
																					num5++;
																					goto IL_04f6;
																					IL_0312:
																					if (9 < b)
																					{
																						goto IL_0320;
																					}
																					goto IL_03ce;
																					IL_0320:
																					if (11 >= b)
																					{
																						goto IL_032e;
																					}
																					goto IL_056b;
																					IL_032e:
																					if (11 <= b)
																					{
																						goto IL_0339;
																					}
																					goto IL_034c;
																					IL_0339:
																					num5--;
																					break;
																					IL_034c:
																					if (10 < b)
																					{
																						goto end_IL_02cc;
																					}
																					goto IL_035a;
																					IL_035a:
																					if (10 > b)
																					{
																						goto end_IL_02cc;
																					}
																					goto IL_0368;
																					IL_0368:
																					array[num5 - 1] = 0;
																					goto IL_037c;
																					IL_037c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)IExpandoPositiveInfinity[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_03bb;
																					IL_03bb:
																					ptr2 += 8;
																					break;
																					IL_056b:
																					if (12 < b)
																					{
																						goto end_IL_02cc;
																					}
																					goto IL_0579;
																					IL_0579:
																					if (12 > b)
																					{
																						goto end_IL_02cc;
																					}
																					goto IL_0587;
																					IL_0587:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_03ce:
																					if (9 <= b)
																					{
																						goto IL_03d9;
																					}
																					goto IL_0440;
																					IL_03d9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0419;
																					IL_0419:
																					array[num5 - 2] = 0;
																					goto IL_042d;
																					IL_042d:
																					num5--;
																					break;
																					IL_0440:
																					if (7 >= b)
																					{
																						goto IL_044b;
																					}
																					num = 71;
																					goto IL_0467;
																					IL_044b:
																					if (7 > b)
																					{
																						goto end_IL_02cc;
																					}
																					goto IL_05a3;
																					IL_05a3:
																					array[num5] = 0;
																					goto IL_05b1;
																					IL_05b1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05d4;
																					IL_05d4:
																					array2[num5] = null;
																					num = 64;
																					goto IL_05e7;
																					IL_05e7:
																					num5++;
																					goto IL_05f5;
																					IL_05f5:
																					ptr2 += 8;
																					break;
																					IL_04f6:
																					ptr2 += 8;
																					break;
																					IL_0467:
																					if (8 < b)
																					{
																						goto end_IL_02cc;
																					}
																					goto IL_04b3;
																					IL_04b3:
																					if (8 > b)
																					{
																						goto end_IL_02cc;
																					}
																					goto IL_04c1;
																					IL_04c1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_04da;
																					IL_04da:
																					array[num5] = 0;
																					goto IL_04e8;
																				}
																				goto end_IL_02d9;
																			}
																			num = 27;
																			break;
																			continue;
																			end_IL_02cc:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e0;
																	IL_06fc:
																	ptr2 += 8;
																	break;
																	IL_06ee:
																	num5++;
																	goto IL_06fc;
																	IL_06e0:
																	array[num5] = 0;
																	goto IL_06ee;
																	continue;
																	end_IL_02d9:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07b7;
													IL_07b7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_070a:
													break;
												}
												continue;
												end_IL_071d:
												break;
											}
											continue;
											end_IL_0727:
											break;
										}
										continue;
										end_IL_0732:
										break;
									}
									continue;
									end_IL_0747:
									break;
								}
								continue;
								end_IL_075c:
								break;
							}
							continue;
							end_IL_076c:
							break;
						}
						continue;
						end_IL_077c:
						break;
					}
					continue;
					end_IL_078c:
					break;
				}
				continue;
				end_IL_079c:
				break;
			}
		}
	}

	static Class120()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 13;
			while (true)
			{
				if (num != 13)
				{
					if (num == 994)
					{
						switch (num)
						{
						default:
							continue;
						case 1:
							break;
						case 0:
							return;
						case 2:
							return;
						case 3:
							return;
						case 4:
							return;
						case 5:
							return;
						case 6:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
					num = 4;
				}
				return;
			}
		}
	}
}
