using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Stilt Short Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns short stilts.", false, 3, ModType.const_0, false)]
internal class Class107 : Class93
{
	private static double double_1;

	private static bool bool_0;

	private static bool bool_1;

	private static int int_3;

	private static IntPtr[] EnsureCapacitySequentialScan;

	private static IntPtr[] OtherLetterREQUIRESNEW;

	private static IntPtr[] ProcessingModegetFullTypeName;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0399, IL_03ac, IL_03cb, IL_03db, IL_03eb, IL_03fb, IL_040b, IL_0418, IL_0428, IL_043b, IL_044b, IL_045b, IL_0474, IL_047f, IL_048a, IL_049a, IL_04a8, IL_04b6, IL_04d2, IL_04ea, IL_0522, IL_0535, IL_053e, IL_054c, IL_058a, IL_059d, IL_05b6, IL_05c4, IL_05d2, IL_05e5, IL_05f3, IL_0601, IL_060f, IL_061a, IL_062d, IL_0636, IL_0644, IL_0652, IL_066f, IL_06be, IL_06c8, IL_06f5, IL_0709, IL_0717, IL_072a, IL_0733, IL_0751, IL_075f, IL_0772, IL_077d, IL_078b, IL_07b4, IL_07cd, IL_07d6, IL_07e4, IL_07f2, IL_080a, IL_0828, IL_084c, IL_0864, IL_0877, IL_0885, IL_089d, IL_08ab, IL_08c7, IL_08d5, IL_08e3, IL_08f1, IL_08ff, IL_090a, IL_0918, IL_0926, IL_0934, IL_0957, IL_0961, IL_096f, IL_0982, IL_0990, IL_0999, IL_09c2, IL_09d0, IL_09e3, IL_09ec, IL_09f7, IL_0a05, IL_0a18, IL_0a21, IL_0a61, IL_0a75, IL_0a88, IL_0ad1, IL_0ae5, IL_0af8, IL_0b06, IL_0b11, IL_0b24, IL_0b32, IL_0b40, IL_0b89, IL_0b9d, IL_0bb9, IL_0bc7, IL_0bd5, IL_0c15, IL_0c29, IL_0c45, IL_0c53, IL_0c61, IL_0c6f, IL_0cd1, IL_0ced, IL_0cfb, IL_0d3b, IL_0d4f, IL_0d62, IL_0d76, IL_0dca, IL_0dd8, IL_0de8, IL_0e0a, IL_0e18, IL_0e26, IL_0e34, IL_0e47, IL_0e51, IL_0e5c, IL_0e6c, IL_0e7c, IL_0e8c, IL_0e9c, IL_0eac, IL_0ebc, IL_0ed5, IL_0ee5, IL_0f00 are reachable both inside and outside the pinned region starting at IL_0efa. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 185;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				int __rxRef16 = default(int);
				ref int reference = ref __rxRef16;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0ee5:
						num2 = 1;
						while (true)
						{
							IL_0ed5:
							num3 = num2 * 4;
							while (true)
							{
								IL_0ebc:
								num4 = num2 * 8;
								num = 18;
								while (true)
								{
									IL_0eac:
									array2 = new byte[4];
									while (true)
									{
										IL_0e9c:
										array3 = new object[4];
										while (true)
										{
											IL_0e8c:
											array4 = new int[4];
											while (true)
											{
												IL_0e7c:
												array5 = new int[6];
												while (true)
												{
													IL_0e6c:
													array6 = new long[4];
													while (true)
													{
														IL_0e5c:
														array7 = new object[11];
														while (true)
														{
															IL_0e51:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FrameworkCulturesPermissionSetSection.getGroupsThreadPoolCallBack);
															while (true)
															{
																IL_0e47:
																ptr2 = ptr;
																while (true)
																{
																	IL_0e34:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0474:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_045b:
																				ptr2++;
																				num = 3;
																				while (true)
																				{
																					IL_044b:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_0428:
																								if (11 < b)
																								{
																									num = 66;
																									while (true)
																									{
																										IL_0418:
																										if (17 < b)
																										{
																											while (true)
																											{
																												IL_040b:
																												if (20 >= b)
																												{
																													while (true)
																													{
																														IL_03fb:
																														if (20 > b)
																														{
																															while (true)
																															{
																																IL_03eb:
																																if (18 < b)
																																{
																																	while (19 >= b)
																																	{
																																		while (19 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_03ac:
																																				array2[num6 - 1] = 5;
																																				num = 223;
																																				while (true)
																																				{
																																					if (num != 223)
																																					{
																																						if (num != 1204)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 185:
																																							break;
																																						default:
																																							continue;
																																						case 33:
																																						case 214:
																																							goto IL_03ac;
																																						case 175:
																																							goto IL_03cb;
																																						case 89:
																																							goto IL_03db;
																																						case 153:
																																						case 197:
																																							goto IL_03eb;
																																						case 199:
																																							goto IL_03fb;
																																						case 94:
																																						case 186:
																																							goto IL_040b;
																																						case 66:
																																						case 134:
																																							goto IL_0418;
																																						case 157:
																																							goto IL_0428;
																																						case 191:
																																							goto IL_043b;
																																						case 3:
																																							goto IL_044b;
																																						case 196:
																																							goto IL_045b;
																																						case 53:
																																						case 133:
																																							goto IL_0474;
																																						case 48:
																																							goto IL_047f;
																																						case 22:
																																							goto IL_048a;
																																						case 137:
																																							goto IL_049a;
																																						case 21:
																																							goto IL_04a8;
																																						case 17:
																																						case 129:
																																							goto IL_04b6;
																																						case 135:
																																						case 164:
																																							goto IL_04d2;
																																						case 36:
																																							goto IL_0522;
																																						case 182:
																																							goto IL_053e;
																																						case 165:
																																						case 198:
																																							goto IL_054c;
																																						case 31:
																																							goto IL_058a;
																																						case 63:
																																						case 170:
																																							goto IL_059d;
																																						case 12:
																																							goto IL_05b6;
																																						case 10:
																																							goto IL_05c4;
																																						case 121:
																																							goto IL_05d2;
																																						case 125:
																																							goto IL_05e5;
																																						case 76:
																																						case 159:
																																							goto IL_05f3;
																																						case 149:
																																							goto IL_0601;
																																						case 26:
																																							goto IL_060f;
																																						case 4:
																																							goto IL_061a;
																																						case 41:
																																						case 88:
																																							goto IL_0636;
																																						case 2:
																																							goto IL_0644;
																																						case 29:
																																						case 147:
																																							goto IL_0652;
																																						case 99:
																																							goto IL_0709;
																																						case 62:
																																							goto IL_0717;
																																						case 151:
																																						case 192:
																																							goto IL_0733;
																																						case 127:
																																							goto IL_0751;
																																						case 70:
																																							goto IL_075f;
																																						case 155:
																																							goto IL_0772;
																																						case 20:
																																							goto IL_077d;
																																						case 110:
																																						case 166:
																																							goto IL_078b;
																																						case 187:
																																							goto IL_07b4;
																																						case 54:
																																						case 200:
																																							goto IL_07d6;
																																						case 190:
																																							goto IL_07e4;
																																						case 73:
																																						case 169:
																																							goto IL_07f2;
																																						case 40:
																																							goto IL_080a;
																																						case 7:
																																							goto IL_0828;
																																						case 111:
																																							goto IL_084c;
																																						case 207:
																																							goto IL_0864;
																																						case 81:
																																						case 104:
																																							goto end_IL_0399;
																																						case 0:
																																							goto IL_0885;
																																						case 178:
																																							goto IL_089d;
																																						case 209:
																																							goto IL_08ab;
																																						case 189:
																																							goto IL_08c7;
																																						case 14:
																																						case 126:
																																							goto IL_08d5;
																																						case 168:
																																							goto IL_08e3;
																																						case 74:
																																						case 202:
																																							goto IL_08f1;
																																						case 117:
																																							goto IL_08ff;
																																						case 25:
																																						case 52:
																																							goto IL_090a;
																																						case 65:
																																							goto IL_0918;
																																						case 75:
																																						case 173:
																																							goto IL_0926;
																																						case 139:
																																							goto IL_0934;
																																						case 13:
																																							goto IL_0957;
																																						case 100:
																																							goto IL_0961;
																																						case 116:
																																							goto IL_096f;
																																						case 5:
																																							goto IL_0982;
																																						case 23:
																																						case 205:
																																							goto IL_0999;
																																						case 11:
																																							goto IL_09c2;
																																						case 181:
																																							goto IL_09d0;
																																						case 120:
																																							goto IL_09ec;
																																						case 69:
																																							goto IL_09f7;
																																						case 8:
																																							goto IL_0a05;
																																						case 91:
																																						case 123:
																																							goto IL_0a21;
																																						case 96:
																																							goto IL_0a61;
																																						case 95:
																																							goto IL_0a75;
																																						case 56:
																																						case 90:
																																							goto IL_0a88;
																																						case 105:
																																							goto IL_0ad1;
																																						case 162:
																																							goto IL_0ae5;
																																						case 140:
																																							goto IL_0af8;
																																						case 28:
																																							goto IL_0b06;
																																						case 39:
																																						case 103:
																																							goto IL_0b11;
																																						case 61:
																																						case 194:
																																							goto IL_0b24;
																																						case 142:
																																							goto IL_0b32;
																																						case 44:
																																						case 216:
																																							goto IL_0b40;
																																						case 50:
																																							goto IL_0b89;
																																						case 37:
																																							goto IL_0b9d;
																																						case 212:
																																							goto IL_0bb9;
																																						case 85:
																																							goto IL_0bc7;
																																						case 102:
																																						case 177:
																																							goto IL_0bd5;
																																						case 163:
																																							goto IL_0c15;
																																						case 210:
																																							goto IL_0c29;
																																						case 188:
																																							goto IL_0c45;
																																						case 46:
																																						case 128:
																																							goto IL_0c53;
																																						case 97:
																																							goto IL_0c61;
																																						case 152:
																																						case 193:
																																							goto IL_0c6f;
																																						case 59:
																																							goto IL_0cd1;
																																						case 158:
																																							goto IL_0ced;
																																						case 1:
																																						case 179:
																																							goto IL_0cfb;
																																						case 138:
																																							goto IL_0d3b;
																																						case 161:
																																							goto IL_0d4f;
																																						case 55:
																																						case 180:
																																							goto IL_0d62;
																																						case 67:
																																							goto IL_0d76;
																																						case 122:
																																							goto IL_0dca;
																																						case 148:
																																							goto IL_0dd8;
																																						case 9:
																																						case 15:
																																						case 16:
																																						case 19:
																																						case 27:
																																						case 42:
																																						case 51:
																																						case 57:
																																						case 60:
																																						case 71:
																																						case 77:
																																						case 78:
																																						case 82:
																																						case 83:
																																						case 84:
																																						case 86:
																																						case 93:
																																						case 98:
																																						case 101:
																																						case 107:
																																						case 109:
																																						case 112:
																																						case 114:
																																						case 115:
																																						case 130:
																																						case 132:
																																						case 141:
																																						case 145:
																																						case 150:
																																						case 154:
																																						case 167:
																																						case 174:
																																						case 203:
																																						case 204:
																																						case 206:
																																						case 208:
																																						case 211:
																																						case 213:
																																							goto end_IL_03cb;
																																						case 64:
																																							goto IL_0e0a;
																																						case 92:
																																							goto IL_0e18;
																																						case 38:
																																							goto IL_0e26;
																																						case 6:
																																						case 24:
																																						case 32:
																																						case 43:
																																						case 47:
																																						case 49:
																																						case 58:
																																						case 68:
																																						case 72:
																																						case 79:
																																						case 106:
																																						case 108:
																																						case 118:
																																						case 119:
																																						case 124:
																																						case 136:
																																						case 143:
																																						case 144:
																																						case 146:
																																						case 171:
																																						case 172:
																																						case 183:
																																						case 195:
																																						case 201:
																																						case 215:
																																							goto IL_0e34;
																																						case 156:
																																							goto IL_0e47;
																																						case 176:
																																							goto IL_0e51;
																																						case 30:
																																							goto IL_0e5c;
																																						case 160:
																																							goto IL_0e6c;
																																						case 34:
																																							goto IL_0e7c;
																																						case 113:
																																							goto IL_0e8c;
																																						case 87:
																																							goto IL_0e9c;
																																						case 18:
																																							goto IL_0eac;
																																						case 131:
																																							goto IL_0ebc;
																																						case 45:
																																							goto IL_0ed5;
																																						case 184:
																																							goto IL_0ee5;
																																						case 35:
																																						case 80:
																																							goto IL_0f00;
																																						}
																																						goto end_IL_044b;
																																					}
																																					array3[num6 - 1] = ((delegate*<string[], string>)EnsureCapacitySequentialScan[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																																					goto IL_0522;
																																					IL_0522:
																																					ptr2 += 8;
																																					goto IL_0e34;
																																					continue;
																																					end_IL_0399:
																																					break;
																																				}
																																				break;
																																			}
																																			goto IL_0877;
																																			continue;
																																			end_IL_03cb:
																																			break;
																																			IL_03cb:;
																																		}
																																		break;
																																		IL_03db:;
																																	}
																																	break;
																																}
																																num = 182;
																																goto IL_053e;
																																IL_054c:
																																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																																goto IL_058a;
																																IL_058a:
																																num6 -= 3;
																																goto IL_0e34;
																																IL_053e:
																																if (18 > b)
																																{
																																	break;
																																}
																																goto IL_054c;
																															}
																															break;
																														}
																														goto IL_059d;
																														IL_05d2:
																														ptr2 += 16;
																														goto IL_0e34;
																														IL_059d:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																														goto IL_05b6;
																														IL_05b6:
																														array2[num6] = 1;
																														goto IL_05c4;
																														IL_05c4:
																														num6++;
																														goto IL_05d2;
																													}
																													break;
																												}
																												goto IL_047f;
																												IL_04b6:
																												num7 = ptr2;
																												num8 = -200;
																												num5 = 1;
																												ptr2 = num7 + num8;
																												goto IL_0e34;
																												IL_047f:
																												if (21 >= b)
																												{
																													goto IL_048a;
																												}
																												goto IL_049a;
																												IL_048a:
																												if (21 > b)
																												{
																													break;
																												}
																												goto IL_04d2;
																												IL_04d2:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto IL_0e34;
																												IL_049a:
																												if (22 < b)
																												{
																													break;
																												}
																												goto IL_04a8;
																												IL_04a8:
																												if (22 > b)
																												{
																													break;
																												}
																												goto IL_04b6;
																											}
																											break;
																										}
																										goto IL_05e5;
																										IL_0828:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_084c;
																										IL_05e5:
																										if (17 > b)
																										{
																											goto IL_05f3;
																										}
																										goto IL_0877;
																										IL_05f3:
																										if (14 >= b)
																										{
																											goto IL_0601;
																										}
																										goto IL_0772;
																										IL_0601:
																										if (14 > b)
																										{
																											goto IL_060f;
																										}
																										num = 192;
																										goto IL_0733;
																										IL_060f:
																										if (12 >= b)
																										{
																											goto IL_061a;
																										}
																										num = 88;
																										goto IL_0636;
																										IL_061a:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0e34;
																										IL_0864:
																										num6++;
																										goto IL_0e34;
																										IL_0636:
																										if (13 < b)
																										{
																											break;
																										}
																										goto IL_0644;
																										IL_0644:
																										if (13 > b)
																										{
																											break;
																										}
																										goto IL_0652;
																										IL_0652:
																										array8 = array3;
																										num9 = num6;
																										if (array == null)
																										{
																											goto IL_0661;
																										}
																										num10 = ptr2;
																										byte b2 = *num10;
																										ptr2 = num10 + 4;
																										int num11 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num11;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_0709;
																										IL_0877:
																										array2[num6] = 5;
																										goto IL_0885;
																										IL_0885:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_089d;
																										IL_089d:
																										num6++;
																										goto IL_08ab;
																										IL_0709:
																										array2[num6] = 5;
																										goto IL_0717;
																										IL_0717:
																										num6++;
																										goto IL_0e34;
																										IL_084c:
																										array3[num6] = array3[num6 - 1];
																										goto IL_0864;
																										IL_0733:
																										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										goto IL_0751;
																										IL_0751:
																										ptr2 += 8;
																										goto IL_075f;
																										IL_075f:
																										num6--;
																										goto IL_0e34;
																										IL_0772:
																										if (15 >= b)
																										{
																											goto IL_077d;
																										}
																										num = 54;
																										goto IL_07d6;
																										IL_077d:
																										if (15 > b)
																										{
																											break;
																										}
																										goto IL_078b;
																										IL_078b:
																										array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																										goto IL_07b4;
																										IL_07b4:
																										array2[num6 - 1] = 5;
																										goto IL_0e34;
																										IL_08ab:
																										ptr2 += 8;
																										num = 43;
																										goto IL_0e34;
																										IL_07d6:
																										if (16 < b)
																										{
																											break;
																										}
																										goto IL_07e4;
																										IL_07e4:
																										if (16 > b)
																										{
																											break;
																										}
																										goto IL_07f2;
																										IL_07f2:
																										array2[num6] = array2[num6 - 1];
																										goto IL_080a;
																										IL_080a:
																										array4[num6 - 0] = array4[num6 - 1];
																										goto IL_0828;
																									}
																									break;
																								}
																								goto IL_08c7;
																								IL_0d4f:
																								num6--;
																								goto IL_0e34;
																								IL_0d62:
																								array2[num6 - 2] = 0;
																								goto IL_0d76;
																								IL_08c7:
																								if (11 > b)
																								{
																									goto IL_08d5;
																								}
																								goto IL_0d62;
																								IL_08d5:
																								if (5 >= b)
																								{
																									goto IL_08e3;
																								}
																								goto IL_0af8;
																								IL_08e3:
																								if (5 > b)
																								{
																									goto IL_08f1;
																								}
																								goto IL_0a88;
																								IL_08f1:
																								if (2 < b)
																								{
																									goto IL_08ff;
																								}
																								num = 120;
																								goto IL_09ec;
																								IL_08ff:
																								if (3 < b)
																								{
																									goto IL_090a;
																								}
																								goto IL_0982;
																								IL_090a:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0918;
																								IL_0918:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0926;
																								IL_0926:
																								array2[num6] = 0;
																								goto IL_0934;
																								IL_0934:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0957;
																								IL_0957:
																								array3[num6] = null;
																								goto IL_0961;
																								IL_0961:
																								num6++;
																								goto IL_096f;
																								IL_096f:
																								ptr2 += 8;
																								goto IL_0e34;
																								IL_0982:
																								if (3 > b)
																								{
																									break;
																								}
																								num = 23;
																								goto IL_0999;
																								IL_0dca:
																								num6--;
																								goto IL_0dd8;
																								IL_0999:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_09c2;
																								IL_09c2:
																								ptr2 += 8;
																								goto IL_09d0;
																								IL_09d0:
																								num6--;
																								goto IL_0e34;
																								IL_0d76:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)EnsureCapacitySequentialScan[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_0dca;
																								IL_09ec:
																								if (2 > b)
																								{
																									goto IL_09f7;
																								}
																								num = 91;
																								goto IL_0a21;
																								IL_09f7:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0a05;
																								IL_0a05:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0dd8:
																								ptr2 += 8;
																								goto IL_0e34;
																								IL_0a21:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a61;
																								IL_0a61:
																								array2[num6 - 2] = 0;
																								goto IL_0a75;
																								IL_0a75:
																								num6--;
																								goto IL_0e34;
																								IL_0a88:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 105;
																								goto IL_0ad1;
																								IL_0ad1:
																								array2[num6 - 2] = 0;
																								goto IL_0ae5;
																								IL_0ae5:
																								num6--;
																								goto IL_0e34;
																								IL_0af8:
																								if (8 >= b)
																								{
																									goto IL_0b06;
																								}
																								goto IL_0c45;
																								IL_0b06:
																								if (8 <= b)
																								{
																									goto IL_0b11;
																								}
																								goto IL_0b24;
																								IL_0b11:
																								num6--;
																								goto IL_0e34;
																								IL_0b24:
																								if (6 >= b)
																								{
																									goto IL_0b32;
																								}
																								goto IL_0bb9;
																								IL_0b32:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_0b40;
																								IL_0b40:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 50;
																								goto IL_0b89;
																								IL_0b89:
																								array2[num6 - 2] = 0;
																								goto IL_0b9d;
																								IL_0b9d:
																								num6--;
																								num = 72;
																								goto IL_0e34;
																								IL_0bb9:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_0bc7;
																								IL_0bc7:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0bd5;
																								IL_0bd5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0c15;
																								IL_0c15:
																								array2[num6 - 2] = 0;
																								goto IL_0c29;
																								IL_0c29:
																								num6--;
																								num = 124;
																								goto IL_0e34;
																								IL_0c45:
																								if (9 < b)
																								{
																									goto IL_0c53;
																								}
																								goto IL_0ced;
																								IL_0c53:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_0c61;
																								IL_0c61:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_0c6f;
																								IL_0c6f:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0cd1;
																								IL_0cd1:
																								num6 -= 2;
																								num = 143;
																								goto IL_0e34;
																								IL_0ced:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0cfb;
																								IL_0cfb:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0d3b;
																								IL_0d3b:
																								array2[num6 - 2] = 0;
																								goto IL_0d4f;
																							}
																							break;
																							IL_043b:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					num = 64;
																					goto IL_0e0a;
																					IL_0e26:
																					ptr2 += 8;
																					goto IL_0e34;
																					IL_0e18:
																					num6++;
																					goto IL_0e26;
																					IL_0e0a:
																					array2[num6] = 0;
																					goto IL_0e18;
																					continue;
																					end_IL_044b:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0f00;
																	IL_0f00:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0661:
				while (true)
				{
					IL_0661_2:
					array = new byte[4];
					while (true)
					{
						IL_066f:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0717_2:
								num6++;
								while (true)
								{
									IL_0e34_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												num = 3;
												while (true)
												{
													IL_044b_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_0428_2:
																if (11 < b)
																{
																	num = 66;
																	while (true)
																	{
																		IL_0418_2:
																		if (17 < b)
																		{
																			while (true)
																			{
																				IL_040b_2:
																				if (20 >= b)
																				{
																					while (true)
																					{
																						IL_03fb_2:
																						if (20 > b)
																						{
																							while (true)
																							{
																								IL_03eb_2:
																								if (18 < b)
																								{
																									while (19 >= b)
																									{
																										while (19 <= b)
																										{
																											while (true)
																											{
																												IL_03ac_2:
																												array2[num6 - 1] = 5;
																												num = 223;
																												while (true)
																												{
																													if (num != 223)
																													{
																														if (num != 1204)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 33:
																														case 214:
																															goto IL_03ac_2;
																														case 175:
																															goto IL_03cb_2;
																														case 89:
																															goto IL_03db_2;
																														case 153:
																														case 197:
																															goto IL_03eb_2;
																														case 199:
																															goto IL_03fb_2;
																														case 94:
																														case 186:
																															goto IL_040b_2;
																														case 66:
																														case 134:
																															goto IL_0418_2;
																														case 157:
																															goto IL_0428_2;
																														case 191:
																															goto IL_043b_2;
																														case 3:
																															goto IL_044b_2;
																														case 196:
																															goto end_IL_044b_2;
																														case 53:
																														case 133:
																															goto end_IL_045b;
																														case 48:
																															goto IL_047f_2;
																														case 22:
																															goto IL_048a_2;
																														case 137:
																															goto IL_049a_2;
																														case 21:
																															goto IL_04a8_2;
																														case 17:
																														case 129:
																															goto IL_04b6_2;
																														case 135:
																														case 164:
																															goto IL_04d2_2;
																														case 36:
																															goto IL_0522_2;
																														case 182:
																															goto IL_053e_2;
																														case 165:
																														case 198:
																															goto IL_054c_2;
																														case 31:
																															goto IL_058a_2;
																														case 63:
																														case 170:
																															goto IL_059d_2;
																														case 12:
																															goto IL_05b6_2;
																														case 10:
																															goto IL_05c4_2;
																														case 121:
																															goto IL_05d2_2;
																														case 125:
																															goto IL_05e5_2;
																														case 76:
																														case 159:
																															goto IL_05f3_2;
																														case 149:
																															goto IL_0601_2;
																														case 26:
																															goto IL_060f_2;
																														case 4:
																															goto IL_061a_2;
																														case 41:
																														case 88:
																															goto IL_0636_2;
																														case 2:
																															goto IL_0644_2;
																														case 29:
																														case 147:
																															goto IL_0652_2;
																														case 99:
																															goto end_IL_0474;
																														case 62:
																															goto IL_0717_2;
																														case 151:
																														case 192:
																															goto IL_0733_2;
																														case 127:
																															goto IL_0751_2;
																														case 70:
																															goto IL_075f_2;
																														case 155:
																															goto IL_0772_2;
																														case 20:
																															goto IL_077d_2;
																														case 110:
																														case 166:
																															goto IL_078b_2;
																														case 187:
																															goto IL_07b4_2;
																														case 54:
																														case 200:
																															goto IL_07d6_2;
																														case 190:
																															goto IL_07e4_2;
																														case 73:
																														case 169:
																															goto IL_07f2_2;
																														case 40:
																															goto IL_080a_2;
																														case 7:
																															goto IL_0828_2;
																														case 111:
																															goto IL_084c_2;
																														case 207:
																															goto IL_0864_2;
																														case 81:
																														case 104:
																															goto end_IL_0399_2;
																														case 0:
																															goto IL_0885_2;
																														case 178:
																															goto IL_089d_2;
																														case 209:
																															goto IL_08ab_2;
																														case 189:
																															goto IL_08c7_2;
																														case 14:
																														case 126:
																															goto IL_08d5_2;
																														case 168:
																															goto IL_08e3_2;
																														case 74:
																														case 202:
																															goto IL_08f1_2;
																														case 117:
																															goto IL_08ff_2;
																														case 25:
																														case 52:
																															goto IL_090a_2;
																														case 65:
																															goto IL_0918_2;
																														case 75:
																														case 173:
																															goto IL_0926_2;
																														case 139:
																															goto IL_0934_2;
																														case 13:
																															goto IL_0957_2;
																														case 100:
																															goto IL_0961_2;
																														case 116:
																															goto IL_096f_2;
																														case 5:
																															goto IL_0982_2;
																														case 23:
																														case 205:
																															goto IL_0999_2;
																														case 11:
																															goto IL_09c2_2;
																														case 181:
																															goto IL_09d0_2;
																														case 120:
																															goto IL_09ec_2;
																														case 69:
																															goto IL_09f7_2;
																														case 8:
																															goto IL_0a05_2;
																														case 91:
																														case 123:
																															goto IL_0a21_2;
																														case 96:
																															goto IL_0a61_2;
																														case 95:
																															goto IL_0a75_2;
																														case 56:
																														case 90:
																															goto IL_0a88_2;
																														case 105:
																															goto IL_0ad1_2;
																														case 162:
																															goto IL_0ae5_2;
																														case 140:
																															goto IL_0af8_2;
																														case 28:
																															goto IL_0b06_2;
																														case 39:
																														case 103:
																															goto IL_0b11_2;
																														case 61:
																														case 194:
																															goto IL_0b24_2;
																														case 142:
																															goto IL_0b32_2;
																														case 44:
																														case 216:
																															goto IL_0b40_2;
																														case 50:
																															goto IL_0b89_2;
																														case 37:
																															goto IL_0b9d_2;
																														case 212:
																															goto IL_0bb9_2;
																														case 85:
																															goto IL_0bc7_2;
																														case 102:
																														case 177:
																															goto IL_0bd5_2;
																														case 163:
																															goto IL_0c15_2;
																														case 210:
																															goto IL_0c29_2;
																														case 188:
																															goto IL_0c45_2;
																														case 46:
																														case 128:
																															goto IL_0c53_2;
																														case 97:
																															goto IL_0c61_2;
																														case 152:
																														case 193:
																															goto IL_0c6f_2;
																														case 59:
																															goto IL_0cd1_2;
																														case 158:
																															goto IL_0ced_2;
																														case 1:
																														case 179:
																															goto IL_0cfb_2;
																														case 138:
																															goto IL_0d3b_2;
																														case 161:
																															goto IL_0d4f_2;
																														case 55:
																														case 180:
																															goto IL_0d62_2;
																														case 67:
																															goto IL_0d76_2;
																														case 122:
																															goto IL_0dca_2;
																														case 148:
																															goto IL_0dd8_2;
																														case 9:
																														case 15:
																														case 16:
																														case 19:
																														case 27:
																														case 42:
																														case 51:
																														case 57:
																														case 60:
																														case 71:
																														case 77:
																														case 78:
																														case 82:
																														case 83:
																														case 84:
																														case 86:
																														case 93:
																														case 98:
																														case 101:
																														case 107:
																														case 109:
																														case 112:
																														case 114:
																														case 115:
																														case 130:
																														case 132:
																														case 141:
																														case 145:
																														case 150:
																														case 154:
																														case 167:
																														case 174:
																														case 203:
																														case 204:
																														case 206:
																														case 208:
																														case 211:
																														case 213:
																															goto end_IL_03cb_2;
																														case 64:
																															goto IL_0e0a_2;
																														case 92:
																															goto IL_0e18_2;
																														case 38:
																															goto IL_0e26_2;
																														case 6:
																														case 24:
																														case 32:
																														case 43:
																														case 47:
																														case 49:
																														case 58:
																														case 68:
																														case 72:
																														case 79:
																														case 106:
																														case 108:
																														case 118:
																														case 119:
																														case 124:
																														case 136:
																														case 143:
																														case 144:
																														case 146:
																														case 171:
																														case 172:
																														case 183:
																														case 195:
																														case 201:
																														case 215:
																															goto IL_0e34_2;
																														case 156:
																															ptr2 = ptr;
																															goto IL_0e34_2;
																														case 176:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FrameworkCulturesPermissionSetSection.getGroupsThreadPoolCallBack);
																															goto case 156;
																														case 30:
																															array7 = new object[11];
																															goto case 176;
																														case 160:
																															array6 = new long[4];
																															goto case 30;
																														case 34:
																															array5 = new int[6];
																															goto case 160;
																														case 113:
																															array4 = new int[4];
																															goto case 34;
																														case 87:
																															array3 = new object[4];
																															goto case 113;
																														case 18:
																															array2 = new byte[4];
																															goto case 87;
																														case 131:
																															num4 = num2 * 8;
																															num = 18;
																															goto case 18;
																														case 45:
																															num3 = num2 * 4;
																															goto case 131;
																														case 184:
																															num2 = 1;
																															goto case 45;
																														case 185:
																															goto end_IL_0709;
																														case 35:
																														case 80:
																															goto IL_0f00_2;
																														}
																														continue;
																													}
																													array3[num6 - 1] = ((delegate*<string[], string>)EnsureCapacitySequentialScan[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																													goto IL_0522_2;
																													IL_0522_2:
																													ptr2 += 8;
																													goto IL_0e34_2;
																													continue;
																													end_IL_0399_2:
																													break;
																												}
																												break;
																											}
																											goto IL_0877_2;
																											continue;
																											end_IL_03cb_2:
																											break;
																											IL_03cb_2:;
																										}
																										break;
																										IL_03db_2:;
																									}
																									break;
																								}
																								num = 182;
																								goto IL_053e_2;
																								IL_054c_2:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_058a_2;
																								IL_058a_2:
																								num6 -= 3;
																								goto IL_0e34_2;
																								IL_053e_2:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_054c_2;
																							}
																							break;
																						}
																						goto IL_059d_2;
																						IL_05d2_2:
																						ptr2 += 16;
																						goto IL_0e34_2;
																						IL_059d_2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						goto IL_05b6_2;
																						IL_05b6_2:
																						array2[num6] = 1;
																						goto IL_05c4_2;
																						IL_05c4_2:
																						num6++;
																						goto IL_05d2_2;
																					}
																					break;
																				}
																				goto IL_047f_2;
																				IL_04b6_2:
																				num7 = ptr2;
																				num8 = -200;
																				num5 = 1;
																				ptr2 = num7 + num8;
																				goto IL_0e34_2;
																				IL_047f_2:
																				if (21 >= b)
																				{
																					goto IL_048a_2;
																				}
																				goto IL_049a_2;
																				IL_048a_2:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_04d2_2;
																				IL_04d2_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_0e34_2;
																				IL_049a_2:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_04a8_2;
																				IL_04a8_2:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_04b6_2;
																			}
																			break;
																		}
																		goto IL_05e5_2;
																		IL_0877_2:
																		array2[num6] = 5;
																		goto IL_0885_2;
																		IL_05e5_2:
																		if (17 > b)
																		{
																			goto IL_05f3_2;
																		}
																		goto IL_0877_2;
																		IL_05f3_2:
																		if (14 >= b)
																		{
																			goto IL_0601_2;
																		}
																		goto IL_0772_2;
																		IL_0601_2:
																		if (14 > b)
																		{
																			goto IL_060f_2;
																		}
																		num = 192;
																		goto IL_0733_2;
																		IL_060f_2:
																		if (12 >= b)
																		{
																			goto IL_061a_2;
																		}
																		num = 88;
																		goto IL_0636_2;
																		IL_061a_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0e34_2;
																		IL_089d_2:
																		num6++;
																		goto IL_08ab_2;
																		IL_0636_2:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_0644_2;
																		IL_0644_2:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_0652_2;
																		IL_0652_2:
																		array8 = array3;
																		num9 = num6;
																		if (array == null)
																		{
																			goto IL_0661_2;
																		}
																		goto IL_066f;
																		IL_0885_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_089d_2;
																		IL_0733_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_0751_2;
																		IL_0751_2:
																		ptr2 += 8;
																		goto IL_075f_2;
																		IL_075f_2:
																		num6--;
																		goto IL_0e34_2;
																		IL_0772_2:
																		if (15 >= b)
																		{
																			goto IL_077d_2;
																		}
																		num = 54;
																		goto IL_07d6_2;
																		IL_077d_2:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_078b_2;
																		IL_078b_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_07b4_2;
																		IL_07b4_2:
																		array2[num6 - 1] = 5;
																		goto IL_0e34_2;
																		IL_08ab_2:
																		ptr2 += 8;
																		num = 43;
																		goto IL_0e34_2;
																		IL_07d6_2:
																		if (16 < b)
																		{
																			break;
																		}
																		goto IL_07e4_2;
																		IL_07e4_2:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_07f2_2;
																		IL_07f2_2:
																		array2[num6] = array2[num6 - 1];
																		goto IL_080a_2;
																		IL_080a_2:
																		array4[num6 - 0] = array4[num6 - 1];
																		goto IL_0828_2;
																		IL_0828_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_084c_2;
																		IL_084c_2:
																		array3[num6] = array3[num6 - 1];
																		goto IL_0864_2;
																		IL_0864_2:
																		num6++;
																		goto IL_0e34_2;
																	}
																	break;
																}
																goto IL_08c7_2;
																IL_0d4f_2:
																num6--;
																goto IL_0e34_2;
																IL_0d62_2:
																array2[num6 - 2] = 0;
																goto IL_0d76_2;
																IL_08c7_2:
																if (11 > b)
																{
																	goto IL_08d5_2;
																}
																goto IL_0d62_2;
																IL_08d5_2:
																if (5 >= b)
																{
																	goto IL_08e3_2;
																}
																goto IL_0af8_2;
																IL_08e3_2:
																if (5 > b)
																{
																	goto IL_08f1_2;
																}
																goto IL_0a88_2;
																IL_08f1_2:
																if (2 < b)
																{
																	goto IL_08ff_2;
																}
																num = 120;
																goto IL_09ec_2;
																IL_08ff_2:
																if (3 < b)
																{
																	goto IL_090a_2;
																}
																goto IL_0982_2;
																IL_090a_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_0918_2;
																IL_0918_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_0926_2;
																IL_0926_2:
																array2[num6] = 0;
																goto IL_0934_2;
																IL_0934_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0957_2;
																IL_0957_2:
																array3[num6] = null;
																goto IL_0961_2;
																IL_0961_2:
																num6++;
																goto IL_096f_2;
																IL_096f_2:
																ptr2 += 8;
																goto IL_0e34_2;
																IL_0982_2:
																if (3 > b)
																{
																	break;
																}
																num = 23;
																goto IL_0999_2;
																IL_0dca_2:
																num6--;
																goto IL_0dd8_2;
																IL_0999_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_09c2_2;
																IL_09c2_2:
																ptr2 += 8;
																goto IL_09d0_2;
																IL_09d0_2:
																num6--;
																goto IL_0e34_2;
																IL_0d76_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)EnsureCapacitySequentialScan[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_0dca_2;
																IL_09ec_2:
																if (2 > b)
																{
																	goto IL_09f7_2;
																}
																num = 91;
																goto IL_0a21_2;
																IL_09f7_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_0a05_2;
																IL_0a05_2:
																if (1 <= b)
																{
																}
																break;
																IL_0dd8_2:
																ptr2 += 8;
																goto IL_0e34_2;
																IL_0a21_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0a61_2;
																IL_0a61_2:
																array2[num6 - 2] = 0;
																goto IL_0a75_2;
																IL_0a75_2:
																num6--;
																goto IL_0e34_2;
																IL_0a88_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																num = 105;
																goto IL_0ad1_2;
																IL_0ad1_2:
																array2[num6 - 2] = 0;
																goto IL_0ae5_2;
																IL_0ae5_2:
																num6--;
																goto IL_0e34_2;
																IL_0af8_2:
																if (8 >= b)
																{
																	goto IL_0b06_2;
																}
																goto IL_0c45_2;
																IL_0b06_2:
																if (8 <= b)
																{
																	goto IL_0b11_2;
																}
																goto IL_0b24_2;
																IL_0b11_2:
																num6--;
																goto IL_0e34_2;
																IL_0b24_2:
																if (6 >= b)
																{
																	goto IL_0b32_2;
																}
																goto IL_0bb9_2;
																IL_0b32_2:
																if (6 > b)
																{
																	break;
																}
																goto IL_0b40_2;
																IL_0b40_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																num = 50;
																goto IL_0b89_2;
																IL_0b89_2:
																array2[num6 - 2] = 0;
																goto IL_0b9d_2;
																IL_0b9d_2:
																num6--;
																num = 72;
																goto IL_0e34_2;
																IL_0bb9_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_0bc7_2;
																IL_0bc7_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_0bd5_2;
																IL_0bd5_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0c15_2;
																IL_0c15_2:
																array2[num6 - 2] = 0;
																goto IL_0c29_2;
																IL_0c29_2:
																num6--;
																num = 124;
																goto IL_0e34_2;
																IL_0c45_2:
																if (9 < b)
																{
																	goto IL_0c53_2;
																}
																goto IL_0ced_2;
																IL_0c53_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_0c61_2;
																IL_0c61_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_0c6f_2;
																IL_0c6f_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0cd1_2;
																IL_0cd1_2:
																num6 -= 2;
																num = 143;
																goto IL_0e34_2;
																IL_0ced_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_0cfb_2;
																IL_0cfb_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0d3b_2;
																IL_0d3b_2:
																array2[num6 - 2] = 0;
																goto IL_0d4f_2;
															}
															break;
															IL_043b_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													num = 64;
													goto IL_0e0a_2;
													IL_0e26_2:
													ptr2 += 8;
													goto IL_0e34_2;
													IL_0e18_2:
													num6++;
													goto IL_0e26_2;
													IL_0e0a_2:
													array2[num6] = 0;
													goto IL_0e18_2;
													continue;
													end_IL_044b_2:
													break;
												}
												continue;
												end_IL_045b:
												break;
											}
											continue;
											end_IL_0474:
											break;
										}
										break;
									}
									goto IL_0f00_2;
									IL_0f00_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0709:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_038d, IL_03a0, IL_03b0, IL_03c0, IL_03d0, IL_03e0, IL_03f0, IL_0400, IL_040b, IL_0419, IL_0431, IL_043f, IL_0452, IL_0460, IL_046b, IL_0484, IL_0492, IL_04a0, IL_04b3, IL_04c1, IL_04ca, IL_04d8, IL_04e6, IL_04fa, IL_0532, IL_0545, IL_0553, IL_0591, IL_05ad, IL_05b8, IL_05c6, IL_05de, IL_05e7, IL_05f5, IL_0603, IL_061f, IL_062d, IL_0638, IL_0646, IL_066f, IL_0688, IL_0696, IL_06a4, IL_06bc, IL_06da, IL_06fe, IL_0716, IL_0729, IL_0734, IL_0752, IL_0760, IL_0773, IL_0781, IL_078f, IL_07ac, IL_07fb, IL_0805, IL_0832, IL_0846, IL_0854, IL_0867, IL_0875, IL_0883, IL_0891, IL_089c, IL_08af, IL_08bd, IL_08cb, IL_08d9, IL_0919, IL_092d, IL_0940, IL_094b, IL_098b, IL_099f, IL_09b2, IL_09c0, IL_09cb, IL_09d9, IL_0a19, IL_0a2d, IL_0a40, IL_0a4e, IL_0a5c, IL_0ac7, IL_0ae3, IL_0aee, IL_0b2e, IL_0b42, IL_0b55, IL_0b5e, IL_0b6c, IL_0b77, IL_0bb7, IL_0bcb, IL_0bde, IL_0bec, IL_0bff, IL_0c0a, IL_0c15, IL_0c20, IL_0c2e, IL_0c51, IL_0c5b, IL_0c69, IL_0c7c, IL_0c87, IL_0ca0, IL_0cae, IL_0cbc, IL_0ccc, IL_0cf5, IL_0d03, IL_0d11, IL_0d24, IL_0d2e, IL_0d39, IL_0d49, IL_0d59, IL_0d69, IL_0d79, IL_0d89, IL_0d99, IL_0da9, IL_0db9, IL_0dd4 are reachable both inside and outside the pinned region starting at IL_0dce. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 6;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				int __rxRef17 = default(int);
				ref int reference = ref __rxRef17;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0db9:
						num2 = 1;
						while (true)
						{
							IL_0da9:
							num3 = num2 * 4;
							while (true)
							{
								IL_0d99:
								num4 = num2 * 8;
								while (true)
								{
									IL_0d89:
									array2 = new byte[4];
									while (true)
									{
										IL_0d79:
										array3 = new object[4];
										while (true)
										{
											IL_0d69:
											array4 = new int[4];
											while (true)
											{
												IL_0d59:
												array5 = new int[6];
												while (true)
												{
													IL_0d49:
													array6 = new long[4];
													while (true)
													{
														IL_0d39:
														array7 = new object[17];
														while (true)
														{
															IL_0d2e:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BeginScopesetRNG.idldescgetOpCodeType);
															while (true)
															{
																IL_0d24:
																ptr2 = ptr;
																while (true)
																{
																	IL_0d11:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0400:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_03f0:
																				ptr2++;
																				while (true)
																				{
																					IL_03e0:
																					if (b >= 1)
																					{
																						while (b <= 21)
																						{
																							while (true)
																							{
																								IL_03c0:
																								if (11 >= b)
																								{
																									goto IL_0867;
																								}
																								while (true)
																								{
																									IL_03b0:
																									if (16 >= b)
																									{
																										while (true)
																										{
																											IL_03a0:
																											if (16 > b)
																											{
																												num = 220;
																												while (true)
																												{
																													if (num != 220)
																													{
																														if (num != 1201)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 6:
																															break;
																														default:
																															continue;
																														case 69:
																															goto IL_03a0;
																														case 187:
																														case 209:
																															goto IL_03b0;
																														case 53:
																															goto IL_03c0;
																														case 119:
																															goto IL_03d0;
																														case 117:
																															goto IL_03e0;
																														case 30:
																															goto IL_03f0;
																														case 141:
																														case 208:
																															goto IL_0400;
																														case 18:
																														case 190:
																															goto IL_040b;
																														case 116:
																															goto IL_0419;
																														case 27:
																															goto IL_0431;
																														case 111:
																															goto IL_043f;
																														case 101:
																														case 204:
																															goto IL_0452;
																														case 17:
																															goto IL_0460;
																														case 144:
																														case 148:
																															goto IL_046b;
																														case 113:
																															goto IL_0484;
																														case 138:
																															goto IL_0492;
																														case 12:
																															goto IL_04a0;
																														case 10:
																														case 95:
																															goto IL_04b3;
																														case 3:
																														case 65:
																															goto IL_04ca;
																														case 194:
																															goto IL_04d8;
																														case 33:
																														case 176:
																															goto IL_04e6;
																														case 84:
																															goto IL_04fa;
																														case 181:
																															goto IL_0532;
																														case 201:
																															goto IL_0545;
																														case 167:
																														case 175:
																															goto IL_0553;
																														case 9:
																															goto IL_0591;
																														case 35:
																														case 173:
																															goto IL_05ad;
																														case 139:
																															goto IL_05b8;
																														case 66:
																														case 157:
																															goto IL_05c6;
																														case 78:
																														case 126:
																															goto IL_05e7;
																														case 26:
																															goto IL_05f5;
																														case 22:
																														case 174:
																															goto IL_0603;
																														case 182:
																															goto IL_061f;
																														case 0:
																														case 153:
																															goto IL_062d;
																														case 21:
																															goto IL_0638;
																														case 67:
																														case 184:
																															goto IL_0646;
																														case 15:
																															goto IL_066f;
																														case 75:
																															goto IL_0688;
																														case 2:
																															goto IL_0696;
																														case 106:
																														case 165:
																															goto IL_06a4;
																														case 36:
																															goto IL_06bc;
																														case 96:
																															goto IL_06da;
																														case 180:
																															goto IL_06fe;
																														case 80:
																															goto IL_0716;
																														case 152:
																															goto IL_0729;
																														case 191:
																														case 197:
																															goto IL_0734;
																														case 212:
																															goto IL_0752;
																														case 34:
																															goto IL_0760;
																														case 183:
																															goto IL_0773;
																														case 210:
																															goto IL_0781;
																														case 64:
																														case 164:
																															goto IL_078f;
																														case 89:
																															goto IL_0846;
																														case 134:
																															goto IL_0854;
																														case 211:
																															goto IL_0867;
																														case 169:
																															goto IL_0875;
																														case 72:
																														case 145:
																															goto IL_0883;
																														case 94:
																															goto IL_0891;
																														case 13:
																														case 48:
																															goto IL_089c;
																														case 43:
																															goto IL_08af;
																														case 100:
																														case 104:
																															goto end_IL_038d;
																														case 47:
																															goto IL_08cb;
																														case 196:
																														case 200:
																															goto IL_08d9;
																														case 38:
																															goto IL_0919;
																														case 44:
																															goto IL_092d;
																														case 23:
																															goto IL_0940;
																														case 110:
																														case 160:
																															goto IL_094b;
																														case 52:
																															goto IL_098b;
																														case 68:
																															goto IL_099f;
																														case 40:
																														case 168:
																															goto IL_09c0;
																														case 88:
																															goto IL_09cb;
																														case 62:
																														case 151:
																															goto IL_09d9;
																														case 1:
																															goto IL_0a19;
																														case 140:
																															goto IL_0a2d;
																														case 19:
																														case 122:
																															goto IL_0a40;
																														case 203:
																															goto IL_0a4e;
																														case 54:
																														case 198:
																															goto IL_0a5c;
																														case 120:
																															goto IL_0ac7;
																														case 121:
																															goto IL_0ae3;
																														case 92:
																														case 171:
																															goto IL_0aee;
																														case 118:
																															goto IL_0b2e;
																														case 63:
																															goto IL_0b42;
																														case 102:
																														case 103:
																															goto IL_0b5e;
																														case 74:
																															goto IL_0b6c;
																														case 4:
																														case 86:
																															goto IL_0b77;
																														case 99:
																															goto IL_0bb7;
																														case 115:
																															goto IL_0bcb;
																														case 189:
																															goto IL_0bde;
																														case 41:
																															goto IL_0bec;
																														case 98:
																															goto IL_0bff;
																														case 8:
																														case 20:
																															goto IL_0c0a;
																														case 114:
																															goto IL_0c15;
																														case 55:
																														case 90:
																															goto IL_0c20;
																														case 193:
																															goto IL_0c2e;
																														case 51:
																															goto IL_0c51;
																														case 205:
																															goto IL_0c5b;
																														case 124:
																															goto IL_0c69;
																														case 109:
																															goto IL_0c7c;
																														case 7:
																														case 11:
																														case 24:
																														case 28:
																														case 29:
																														case 49:
																														case 50:
																														case 58:
																														case 61:
																														case 70:
																														case 76:
																														case 79:
																														case 81:
																														case 82:
																														case 91:
																														case 93:
																														case 105:
																														case 108:
																														case 112:
																														case 125:
																														case 127:
																														case 131:
																														case 132:
																														case 137:
																														case 143:
																														case 147:
																														case 149:
																														case 154:
																														case 162:
																														case 163:
																														case 166:
																														case 170:
																														case 172:
																														case 177:
																														case 178:
																														case 179:
																														case 188:
																														case 195:
																														case 207:
																														case 213:
																															goto end_IL_03d0;
																														case 202:
																															goto IL_0ca0;
																														case 56:
																															goto IL_0cae;
																														case 16:
																															goto IL_0cbc;
																														case 71:
																														case 186:
																															goto IL_0ccc;
																														case 142:
																															goto IL_0cf5;
																														case 57:
																															goto IL_0d03;
																														case 14:
																														case 31:
																														case 39:
																														case 45:
																														case 46:
																														case 59:
																														case 60:
																														case 83:
																														case 87:
																														case 97:
																														case 107:
																														case 128:
																														case 130:
																														case 133:
																														case 135:
																														case 136:
																														case 146:
																														case 150:
																														case 155:
																														case 156:
																														case 158:
																														case 159:
																														case 192:
																														case 199:
																															goto IL_0d11;
																														case 73:
																															goto IL_0d24;
																														case 129:
																															goto IL_0d2e;
																														case 123:
																															goto IL_0d39;
																														case 25:
																															goto IL_0d49;
																														case 37:
																															goto IL_0d59;
																														case 42:
																															goto IL_0d69;
																														case 32:
																															goto IL_0d79;
																														case 206:
																															goto IL_0d89;
																														case 77:
																															goto IL_0d99;
																														case 185:
																															goto IL_0da9;
																														case 5:
																															goto IL_0db9;
																														case 85:
																														case 161:
																															goto IL_0dd4;
																														}
																														goto end_IL_03c0;
																													}
																													goto IL_061f;
																													IL_0854:
																													num6++;
																													goto IL_0d11;
																													IL_0846:
																													array2[num6] = 5;
																													goto IL_0854;
																													IL_061f:
																													if (13 < b)
																													{
																														goto IL_062d;
																													}
																													goto IL_0729;
																													IL_062d:
																													if (14 >= b)
																													{
																														goto IL_0638;
																													}
																													goto IL_0688;
																													IL_0638:
																													if (14 > b)
																													{
																														goto end_IL_03d0;
																													}
																													goto IL_0646;
																													IL_0646:
																													array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																													goto IL_066f;
																													IL_066f:
																													array2[num6 - 1] = 5;
																													goto IL_0d11;
																													IL_0688:
																													if (15 < b)
																													{
																														goto end_IL_03d0;
																													}
																													goto IL_0696;
																													IL_0696:
																													if (15 > b)
																													{
																														goto end_IL_03d0;
																													}
																													goto IL_06a4;
																													IL_06a4:
																													array2[num6] = array2[num6 - 1];
																													goto IL_06bc;
																													IL_06bc:
																													array4[num6 - 0] = array4[num6 - 1];
																													goto IL_06da;
																													IL_06da:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_06fe;
																													IL_06fe:
																													array3[num6] = array3[num6 - 1];
																													goto IL_0716;
																													IL_0716:
																													num6++;
																													goto IL_0d11;
																													IL_0729:
																													if (13 <= b)
																													{
																														goto IL_0734;
																													}
																													goto IL_0773;
																													IL_0734:
																													array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																													goto IL_0752;
																													IL_0752:
																													ptr2 += 8;
																													goto IL_0760;
																													IL_0760:
																													num6--;
																													goto IL_0d11;
																													IL_0773:
																													if (12 < b)
																													{
																														goto end_IL_03d0;
																													}
																													goto IL_0781;
																													IL_0781:
																													if (12 > b)
																													{
																														goto end_IL_03d0;
																													}
																													goto IL_078f;
																													IL_078f:
																													array8 = array3;
																													num7 = num6;
																													if (array == null)
																													{
																														goto IL_079e;
																													}
																													num8 = ptr2;
																													byte b2 = *num8;
																													ptr2 = num8 + 4;
																													int num9 = *(int*)(ptr2 + num3);
																													ptr2 += 8;
																													byte* ptr3 = ptr2 + num9;
																													byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																													while (ptr2 != ptr3)
																													{
																														*ptr4 = (byte)(*ptr2 ^ b2);
																														ptr2++;
																														ptr4++;
																													}
																													array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																													goto IL_0846;
																													continue;
																													end_IL_038d:
																													break;
																												}
																												break;
																											}
																											goto IL_040b;
																											IL_0431:
																											num6++;
																											goto IL_043f;
																											IL_043f:
																											ptr2 += 8;
																											goto IL_0d11;
																											IL_040b:
																											array2[num6] = 5;
																											goto IL_0419;
																											IL_0419:
																											array3[num6] = array7[*(int*)(ptr2 + num3)];
																											goto IL_0431;
																										}
																										break;
																									}
																									goto IL_0452;
																									IL_05e7:
																									if (21 < b)
																									{
																										goto end_IL_03d0;
																									}
																									goto IL_05f5;
																									IL_0452:
																									if (19 >= b)
																									{
																										goto IL_0460;
																									}
																									goto IL_05ad;
																									IL_0460:
																									if (19 <= b)
																									{
																										goto IL_046b;
																									}
																									goto IL_04b3;
																									IL_046b:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0484;
																									IL_0484:
																									array2[num6] = 1;
																									goto IL_0492;
																									IL_0492:
																									num6++;
																									goto IL_04a0;
																									IL_04a0:
																									ptr2 += 16;
																									goto IL_0d11;
																									IL_04b3:
																									if (17 < b)
																									{
																										num = 3;
																										goto IL_04ca;
																									}
																									goto IL_0545;
																									IL_05f5:
																									if (21 > b)
																									{
																										goto end_IL_03d0;
																									}
																									goto IL_0603;
																									IL_04ca:
																									if (18 < b)
																									{
																										goto end_IL_03d0;
																									}
																									goto IL_04d8;
																									IL_04d8:
																									if (18 > b)
																									{
																										goto end_IL_03d0;
																									}
																									goto IL_04e6;
																									IL_04e6:
																									array2[num6 - 1] = 5;
																									goto IL_04fa;
																									IL_04fa:
																									array3[num6 - 1] = ((delegate*<string[], string>)OtherLetterREQUIRESNEW[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_0532;
																									IL_0532:
																									ptr2 += 8;
																									goto IL_0d11;
																									IL_0545:
																									if (17 > b)
																									{
																										goto end_IL_03d0;
																									}
																									goto IL_0553;
																									IL_0553:
																									((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																									goto IL_0591;
																									IL_0591:
																									num6 -= 3;
																									num = 156;
																									goto IL_0d11;
																									IL_05ad:
																									if (20 >= b)
																									{
																										goto IL_05b8;
																									}
																									num = 126;
																									goto IL_05e7;
																									IL_05b8:
																									if (20 > b)
																									{
																										goto end_IL_03d0;
																									}
																									goto IL_05c6;
																									IL_05c6:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_0d11;
																									IL_0603:
																									num10 = ptr2;
																									num11 = -200;
																									num5 = 1;
																									ptr2 = num10 + num11;
																									goto IL_0d11;
																								}
																								goto IL_08bd;
																								IL_0ccc:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0cf5;
																								IL_0867:
																								if (11 <= b)
																								{
																									goto IL_0d11;
																								}
																								goto IL_0875;
																								IL_0875:
																								if (5 < b)
																								{
																									goto IL_0883;
																								}
																								goto IL_0ae3;
																								IL_0883:
																								if (8 >= b)
																								{
																									goto IL_0891;
																								}
																								goto IL_09c0;
																								IL_0891:
																								if (8 <= b)
																								{
																									goto IL_089c;
																								}
																								goto IL_08af;
																								IL_089c:
																								num6--;
																								goto IL_0d11;
																								IL_08af:
																								if (6 < b)
																								{
																									goto IL_08bd;
																								}
																								goto IL_0940;
																								IL_08bd:
																								if (7 < b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_08cb;
																								IL_08cb:
																								if (7 > b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_08d9;
																								IL_08d9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0919;
																								IL_0919:
																								array2[num6 - 2] = 0;
																								goto IL_092d;
																								IL_092d:
																								num6--;
																								goto IL_0d11;
																								IL_0940:
																								if (6 > b)
																								{
																									num = 162;
																									goto end_IL_03d0;
																								}
																								goto IL_094b;
																								IL_094b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_098b;
																								IL_098b:
																								array2[num6 - 2] = 0;
																								goto IL_099f;
																								IL_099f:
																								num6--;
																								goto IL_0d11;
																								IL_0cf5:
																								ptr2 += 8;
																								goto IL_0d03;
																								IL_09c0:
																								if (9 >= b)
																								{
																									goto IL_09cb;
																								}
																								goto IL_0a40;
																								IL_09cb:
																								if (9 > b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_09d9;
																								IL_09d9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a19;
																								IL_0a19:
																								array2[num6 - 2] = 0;
																								goto IL_0a2d;
																								IL_0a2d:
																								num6--;
																								goto IL_0d11;
																								IL_0a40:
																								if (10 < b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_0a4e;
																								IL_0a4e:
																								if (10 > b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_0a5c;
																								IL_0a5c:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								num = 120;
																								goto IL_0ac7;
																								IL_0ac7:
																								num6 -= 2;
																								num = 135;
																								goto IL_0d11;
																								IL_0ae3:
																								if (5 <= b)
																								{
																									goto IL_0aee;
																								}
																								num = 102;
																								goto IL_0b5e;
																								IL_0aee:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0b2e;
																								IL_0b2e:
																								array2[num6 - 2] = 0;
																								goto IL_0b42;
																								IL_0b42:
																								num6--;
																								goto IL_0d11;
																								IL_0d03:
																								num6--;
																								goto IL_0d11;
																								IL_0b5e:
																								if (2 >= b)
																								{
																									goto IL_0b6c;
																								}
																								goto IL_0bff;
																								IL_0b6c:
																								if (2 <= b)
																								{
																									goto IL_0b77;
																								}
																								goto IL_0bde;
																								IL_0b77:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0bb7;
																								IL_0bb7:
																								array2[num6 - 2] = 0;
																								goto IL_0bcb;
																								IL_0bcb:
																								num6--;
																								goto IL_0d11;
																								IL_0bde:
																								if (1 < b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_0bec;
																								IL_0bec:
																								if (1 <= b)
																								{
																								}
																								goto end_IL_03d0;
																								IL_0bff:
																								if (3 < b)
																								{
																									goto IL_0c0a;
																								}
																								goto IL_0c7c;
																								IL_0c0a:
																								if (4 < b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_0c15;
																								IL_0c15:
																								if (4 > b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_0c20;
																								IL_0c20:
																								array2[num6] = 0;
																								goto IL_0c2e;
																								IL_0c2e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0c51;
																								IL_0c51:
																								array3[num6] = null;
																								goto IL_0c5b;
																								IL_0c5b:
																								num6++;
																								goto IL_0c69;
																								IL_0c69:
																								ptr2 += 8;
																								goto IL_0d11;
																								IL_0c7c:
																								if (3 > b)
																								{
																									goto end_IL_03d0;
																								}
																								goto IL_0ccc;
																								continue;
																								end_IL_03c0:
																								break;
																							}
																							goto end_IL_03e0;
																							continue;
																							end_IL_03d0:
																							break;
																							IL_03d0:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0ca0;
																					IL_0cbc:
																					ptr2 += 8;
																					goto IL_0d11;
																					IL_0cae:
																					num6++;
																					goto IL_0cbc;
																					IL_0ca0:
																					array2[num6] = 0;
																					goto IL_0cae;
																					continue;
																					end_IL_03e0:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0dd4;
																	IL_0dd4:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_079e:
				while (true)
				{
					IL_079e_2:
					array = new byte[4];
					while (true)
					{
						IL_07ac:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0854_2:
								num6++;
								while (true)
								{
									IL_0d11_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_03e0_2:
													if (b >= 1)
													{
														while (b <= 21)
														{
															while (true)
															{
																IL_03c0_2:
																if (11 >= b)
																{
																	goto IL_0867_2;
																}
																while (true)
																{
																	IL_03b0_2:
																	if (16 >= b)
																	{
																		while (true)
																		{
																			IL_03a0_2:
																			if (16 > b)
																			{
																				num = 220;
																				while (true)
																				{
																					if (num != 220)
																					{
																						if (num != 1201)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 69:
																							goto IL_03a0_2;
																						case 187:
																						case 209:
																							goto IL_03b0_2;
																						case 53:
																							goto IL_03c0_2;
																						case 119:
																							goto end_IL_03c0_2;
																						case 117:
																							goto IL_03e0_2;
																						case 30:
																							goto end_IL_03e0_2;
																						case 141:
																						case 208:
																							goto end_IL_03f0;
																						case 18:
																						case 190:
																							goto IL_040b_2;
																						case 116:
																							goto IL_0419_2;
																						case 27:
																							goto IL_0431_2;
																						case 111:
																							goto IL_043f_2;
																						case 101:
																						case 204:
																							goto IL_0452_2;
																						case 17:
																							goto IL_0460_2;
																						case 144:
																						case 148:
																							goto IL_046b_2;
																						case 113:
																							goto IL_0484_2;
																						case 138:
																							goto IL_0492_2;
																						case 12:
																							goto IL_04a0_2;
																						case 10:
																						case 95:
																							goto IL_04b3_2;
																						case 3:
																						case 65:
																							goto IL_04ca_2;
																						case 194:
																							goto IL_04d8_2;
																						case 33:
																						case 176:
																							goto IL_04e6_2;
																						case 84:
																							goto IL_04fa_2;
																						case 181:
																							goto IL_0532_2;
																						case 201:
																							goto IL_0545_2;
																						case 167:
																						case 175:
																							goto IL_0553_2;
																						case 9:
																							goto IL_0591_2;
																						case 35:
																						case 173:
																							goto IL_05ad_2;
																						case 139:
																							goto IL_05b8_2;
																						case 66:
																						case 157:
																							goto IL_05c6_2;
																						case 78:
																						case 126:
																							goto IL_05e7_2;
																						case 26:
																							goto IL_05f5_2;
																						case 22:
																						case 174:
																							goto IL_0603_2;
																						case 182:
																							goto IL_061f_2;
																						case 0:
																						case 153:
																							goto IL_062d_2;
																						case 21:
																							goto IL_0638_2;
																						case 67:
																						case 184:
																							goto IL_0646_2;
																						case 15:
																							goto IL_066f_2;
																						case 75:
																							goto IL_0688_2;
																						case 2:
																							goto IL_0696_2;
																						case 106:
																						case 165:
																							goto IL_06a4_2;
																						case 36:
																							goto IL_06bc_2;
																						case 96:
																							goto IL_06da_2;
																						case 180:
																							goto IL_06fe_2;
																						case 80:
																							goto IL_0716_2;
																						case 152:
																							goto IL_0729_2;
																						case 191:
																						case 197:
																							goto IL_0734_2;
																						case 212:
																							goto IL_0752_2;
																						case 34:
																							goto IL_0760_2;
																						case 183:
																							goto IL_0773_2;
																						case 210:
																							goto IL_0781_2;
																						case 64:
																						case 164:
																							goto IL_078f_2;
																						case 89:
																							goto end_IL_0400;
																						case 134:
																							goto IL_0854_2;
																						case 211:
																							goto IL_0867_2;
																						case 169:
																							goto IL_0875_2;
																						case 72:
																						case 145:
																							goto IL_0883_2;
																						case 94:
																							goto IL_0891_2;
																						case 13:
																						case 48:
																							goto IL_089c_2;
																						case 43:
																							goto IL_08af_2;
																						case 100:
																						case 104:
																							goto end_IL_038d_2;
																						case 47:
																							goto IL_08cb_2;
																						case 196:
																						case 200:
																							goto IL_08d9_2;
																						case 38:
																							goto IL_0919_2;
																						case 44:
																							goto IL_092d_2;
																						case 23:
																							goto IL_0940_2;
																						case 110:
																						case 160:
																							goto IL_094b_2;
																						case 52:
																							goto IL_098b_2;
																						case 68:
																							goto IL_099f_2;
																						case 40:
																						case 168:
																							goto IL_09c0_2;
																						case 88:
																							goto IL_09cb_2;
																						case 62:
																						case 151:
																							goto IL_09d9_2;
																						case 1:
																							goto IL_0a19_2;
																						case 140:
																							goto IL_0a2d_2;
																						case 19:
																						case 122:
																							goto IL_0a40_2;
																						case 203:
																							goto IL_0a4e_2;
																						case 54:
																						case 198:
																							goto IL_0a5c_2;
																						case 120:
																							goto IL_0ac7_2;
																						case 121:
																							goto IL_0ae3_2;
																						case 92:
																						case 171:
																							goto IL_0aee_2;
																						case 118:
																							goto IL_0b2e_2;
																						case 63:
																							goto IL_0b42_2;
																						case 102:
																						case 103:
																							goto IL_0b5e_2;
																						case 74:
																							goto IL_0b6c_2;
																						case 4:
																						case 86:
																							goto IL_0b77_2;
																						case 99:
																							goto IL_0bb7_2;
																						case 115:
																							goto IL_0bcb_2;
																						case 189:
																							goto IL_0bde_2;
																						case 41:
																							goto IL_0bec_2;
																						case 98:
																							goto IL_0bff_2;
																						case 8:
																						case 20:
																							goto IL_0c0a_2;
																						case 114:
																							goto IL_0c15_2;
																						case 55:
																						case 90:
																							goto IL_0c20_2;
																						case 193:
																							goto IL_0c2e_2;
																						case 51:
																							goto IL_0c51_2;
																						case 205:
																							goto IL_0c5b_2;
																						case 124:
																							goto IL_0c69_2;
																						case 109:
																							goto IL_0c7c_2;
																						case 7:
																						case 11:
																						case 24:
																						case 28:
																						case 29:
																						case 49:
																						case 50:
																						case 58:
																						case 61:
																						case 70:
																						case 76:
																						case 79:
																						case 81:
																						case 82:
																						case 91:
																						case 93:
																						case 105:
																						case 108:
																						case 112:
																						case 125:
																						case 127:
																						case 131:
																						case 132:
																						case 137:
																						case 143:
																						case 147:
																						case 149:
																						case 154:
																						case 162:
																						case 163:
																						case 166:
																						case 170:
																						case 172:
																						case 177:
																						case 178:
																						case 179:
																						case 188:
																						case 195:
																						case 207:
																						case 213:
																							goto end_IL_03d0_2;
																						case 202:
																							goto IL_0ca0_2;
																						case 56:
																							goto IL_0cae_2;
																						case 16:
																							goto IL_0cbc_2;
																						case 71:
																						case 186:
																							goto IL_0ccc_2;
																						case 142:
																							goto IL_0cf5_2;
																						case 57:
																							goto IL_0d03_2;
																						case 14:
																						case 31:
																						case 39:
																						case 45:
																						case 46:
																						case 59:
																						case 60:
																						case 83:
																						case 87:
																						case 97:
																						case 107:
																						case 128:
																						case 130:
																						case 133:
																						case 135:
																						case 136:
																						case 146:
																						case 150:
																						case 155:
																						case 156:
																						case 158:
																						case 159:
																						case 192:
																						case 199:
																							goto IL_0d11_2;
																						case 73:
																							ptr2 = ptr;
																							goto IL_0d11_2;
																						case 129:
																							ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BeginScopesetRNG.idldescgetOpCodeType);
																							goto case 73;
																						case 123:
																							array7 = new object[17];
																							goto case 129;
																						case 25:
																							array6 = new long[4];
																							goto case 123;
																						case 37:
																							array5 = new int[6];
																							goto case 25;
																						case 42:
																							array4 = new int[4];
																							goto case 37;
																						case 32:
																							array3 = new object[4];
																							goto case 42;
																						case 206:
																							array2 = new byte[4];
																							goto case 32;
																						case 77:
																							num4 = num2 * 8;
																							goto case 206;
																						case 185:
																							num3 = num2 * 4;
																							goto case 77;
																						case 5:
																							num2 = 1;
																							goto case 185;
																						case 6:
																							goto end_IL_0846;
																						case 85:
																						case 161:
																							goto IL_0dd4_2;
																						}
																						continue;
																					}
																					goto IL_061f_2;
																					IL_0781_2:
																					if (12 > b)
																					{
																						goto end_IL_03d0_2;
																					}
																					goto IL_078f_2;
																					IL_078f_2:
																					array8 = array3;
																					num7 = num6;
																					if (array == null)
																					{
																						goto IL_079e_2;
																					}
																					goto IL_07ac;
																					IL_061f_2:
																					if (13 < b)
																					{
																						goto IL_062d_2;
																					}
																					goto IL_0729_2;
																					IL_062d_2:
																					if (14 >= b)
																					{
																						goto IL_0638_2;
																					}
																					goto IL_0688_2;
																					IL_0638_2:
																					if (14 > b)
																					{
																						goto end_IL_03d0_2;
																					}
																					goto IL_0646_2;
																					IL_0646_2:
																					array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					goto IL_066f_2;
																					IL_066f_2:
																					array2[num6 - 1] = 5;
																					goto IL_0d11_2;
																					IL_0688_2:
																					if (15 < b)
																					{
																						goto end_IL_03d0_2;
																					}
																					goto IL_0696_2;
																					IL_0696_2:
																					if (15 > b)
																					{
																						goto end_IL_03d0_2;
																					}
																					goto IL_06a4_2;
																					IL_06a4_2:
																					array2[num6] = array2[num6 - 1];
																					goto IL_06bc_2;
																					IL_06bc_2:
																					array4[num6 - 0] = array4[num6 - 1];
																					goto IL_06da_2;
																					IL_06da_2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_06fe_2;
																					IL_06fe_2:
																					array3[num6] = array3[num6 - 1];
																					goto IL_0716_2;
																					IL_0716_2:
																					num6++;
																					goto IL_0d11_2;
																					IL_0729_2:
																					if (13 <= b)
																					{
																						goto IL_0734_2;
																					}
																					goto IL_0773_2;
																					IL_0734_2:
																					array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																					goto IL_0752_2;
																					IL_0752_2:
																					ptr2 += 8;
																					goto IL_0760_2;
																					IL_0760_2:
																					num6--;
																					goto IL_0d11_2;
																					IL_0773_2:
																					if (12 < b)
																					{
																						goto end_IL_03d0_2;
																					}
																					goto IL_0781_2;
																					continue;
																					end_IL_038d_2:
																					break;
																				}
																				break;
																			}
																			goto IL_040b_2;
																			IL_0431_2:
																			num6++;
																			goto IL_043f_2;
																			IL_043f_2:
																			ptr2 += 8;
																			goto IL_0d11_2;
																			IL_040b_2:
																			array2[num6] = 5;
																			goto IL_0419_2;
																			IL_0419_2:
																			array3[num6] = array7[*(int*)(ptr2 + num3)];
																			goto IL_0431_2;
																		}
																		break;
																	}
																	goto IL_0452_2;
																	IL_05e7_2:
																	if (21 < b)
																	{
																		goto end_IL_03d0_2;
																	}
																	goto IL_05f5_2;
																	IL_0452_2:
																	if (19 >= b)
																	{
																		goto IL_0460_2;
																	}
																	goto IL_05ad_2;
																	IL_0460_2:
																	if (19 <= b)
																	{
																		goto IL_046b_2;
																	}
																	goto IL_04b3_2;
																	IL_046b_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																	goto IL_0484_2;
																	IL_0484_2:
																	array2[num6] = 1;
																	goto IL_0492_2;
																	IL_0492_2:
																	num6++;
																	goto IL_04a0_2;
																	IL_04a0_2:
																	ptr2 += 16;
																	goto IL_0d11_2;
																	IL_04b3_2:
																	if (17 < b)
																	{
																		num = 3;
																		goto IL_04ca_2;
																	}
																	goto IL_0545_2;
																	IL_05f5_2:
																	if (21 > b)
																	{
																		goto end_IL_03d0_2;
																	}
																	goto IL_0603_2;
																	IL_04ca_2:
																	if (18 < b)
																	{
																		goto end_IL_03d0_2;
																	}
																	goto IL_04d8_2;
																	IL_04d8_2:
																	if (18 > b)
																	{
																		goto end_IL_03d0_2;
																	}
																	goto IL_04e6_2;
																	IL_04e6_2:
																	array2[num6 - 1] = 5;
																	goto IL_04fa_2;
																	IL_04fa_2:
																	array3[num6 - 1] = ((delegate*<string[], string>)OtherLetterREQUIRESNEW[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																	goto IL_0532_2;
																	IL_0532_2:
																	ptr2 += 8;
																	goto IL_0d11_2;
																	IL_0545_2:
																	if (17 > b)
																	{
																		goto end_IL_03d0_2;
																	}
																	goto IL_0553_2;
																	IL_0553_2:
																	((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																	goto IL_0591_2;
																	IL_0591_2:
																	num6 -= 3;
																	num = 156;
																	goto IL_0d11_2;
																	IL_05ad_2:
																	if (20 >= b)
																	{
																		goto IL_05b8_2;
																	}
																	num = 126;
																	goto IL_05e7_2;
																	IL_05b8_2:
																	if (20 > b)
																	{
																		goto end_IL_03d0_2;
																	}
																	goto IL_05c6_2;
																	IL_05c6_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_0d11_2;
																	IL_0603_2:
																	num10 = ptr2;
																	num11 = -200;
																	num5 = 1;
																	ptr2 = num10 + num11;
																	goto IL_0d11_2;
																}
																goto IL_08bd_2;
																IL_0ccc_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0cf5_2;
																IL_0867_2:
																if (11 <= b)
																{
																	goto IL_0d11_2;
																}
																goto IL_0875_2;
																IL_0875_2:
																if (5 < b)
																{
																	goto IL_0883_2;
																}
																goto IL_0ae3_2;
																IL_0883_2:
																if (8 >= b)
																{
																	goto IL_0891_2;
																}
																goto IL_09c0_2;
																IL_0891_2:
																if (8 <= b)
																{
																	goto IL_089c_2;
																}
																goto IL_08af_2;
																IL_089c_2:
																num6--;
																goto IL_0d11_2;
																IL_08af_2:
																if (6 < b)
																{
																	goto IL_08bd_2;
																}
																goto IL_0940_2;
																IL_08bd_2:
																if (7 < b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_08cb_2;
																IL_08cb_2:
																if (7 > b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_08d9_2;
																IL_08d9_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0919_2;
																IL_0919_2:
																array2[num6 - 2] = 0;
																goto IL_092d_2;
																IL_092d_2:
																num6--;
																goto IL_0d11_2;
																IL_0940_2:
																if (6 > b)
																{
																	num = 162;
																	goto end_IL_03d0_2;
																}
																goto IL_094b_2;
																IL_094b_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_098b_2;
																IL_098b_2:
																array2[num6 - 2] = 0;
																goto IL_099f_2;
																IL_099f_2:
																num6--;
																goto IL_0d11_2;
																IL_0cf5_2:
																ptr2 += 8;
																goto IL_0d03_2;
																IL_09c0_2:
																if (9 >= b)
																{
																	goto IL_09cb_2;
																}
																goto IL_0a40_2;
																IL_09cb_2:
																if (9 > b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_09d9_2;
																IL_09d9_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0a19_2;
																IL_0a19_2:
																array2[num6 - 2] = 0;
																goto IL_0a2d_2;
																IL_0a2d_2:
																num6--;
																goto IL_0d11_2;
																IL_0a40_2:
																if (10 < b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_0a4e_2;
																IL_0a4e_2:
																if (10 > b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_0a5c_2;
																IL_0a5c_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																num = 120;
																goto IL_0ac7_2;
																IL_0ac7_2:
																num6 -= 2;
																num = 135;
																goto IL_0d11_2;
																IL_0ae3_2:
																if (5 <= b)
																{
																	goto IL_0aee_2;
																}
																num = 102;
																goto IL_0b5e_2;
																IL_0aee_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0b2e_2;
																IL_0b2e_2:
																array2[num6 - 2] = 0;
																goto IL_0b42_2;
																IL_0b42_2:
																num6--;
																goto IL_0d11_2;
																IL_0d03_2:
																num6--;
																goto IL_0d11_2;
																IL_0b5e_2:
																if (2 >= b)
																{
																	goto IL_0b6c_2;
																}
																goto IL_0bff_2;
																IL_0b6c_2:
																if (2 <= b)
																{
																	goto IL_0b77_2;
																}
																goto IL_0bde_2;
																IL_0b77_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0bb7_2;
																IL_0bb7_2:
																array2[num6 - 2] = 0;
																goto IL_0bcb_2;
																IL_0bcb_2:
																num6--;
																goto IL_0d11_2;
																IL_0bde_2:
																if (1 < b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_0bec_2;
																IL_0bec_2:
																if (1 <= b)
																{
																}
																goto end_IL_03d0_2;
																IL_0bff_2:
																if (3 < b)
																{
																	goto IL_0c0a_2;
																}
																goto IL_0c7c_2;
																IL_0c0a_2:
																if (4 < b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_0c15_2;
																IL_0c15_2:
																if (4 > b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_0c20_2;
																IL_0c20_2:
																array2[num6] = 0;
																goto IL_0c2e_2;
																IL_0c2e_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0c51_2;
																IL_0c51_2:
																array3[num6] = null;
																goto IL_0c5b_2;
																IL_0c5b_2:
																num6++;
																goto IL_0c69_2;
																IL_0c69_2:
																ptr2 += 8;
																goto IL_0d11_2;
																IL_0c7c_2:
																if (3 > b)
																{
																	goto end_IL_03d0_2;
																}
																goto IL_0ccc_2;
																continue;
																end_IL_03c0_2:
																break;
															}
															continue;
															end_IL_03d0_2:
															break;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0ca0_2;
													IL_0cbc_2:
													ptr2 += 8;
													goto IL_0d11_2;
													IL_0cae_2:
													num6++;
													goto IL_0cbc_2;
													IL_0ca0_2:
													array2[num6] = 0;
													goto IL_0cae_2;
													continue;
													end_IL_03e0_2:
													break;
												}
												continue;
												end_IL_03f0:
												break;
											}
											continue;
											end_IL_0400:
											break;
										}
										break;
									}
									goto IL_0dd4_2;
									IL_0dd4_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0846:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class107()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13()
	{
		int num = 70;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RunClassConstructorUsedSize.StrongNameKeyGenExCheckDemand);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 154;
												while (true)
												{
													if (num == 154)
													{
														goto IL_0315;
													}
													if (num != 1135)
													{
														goto IL_065d;
													}
													switch (num)
													{
													case 104:
														goto end_IL_0277;
													case 28:
														goto end_IL_028a;
													case 134:
														goto end_IL_0295;
													case 103:
														goto end_IL_029f;
													case 52:
														goto end_IL_02aa;
													case 12:
													case 96:
														goto end_IL_02ba;
													case 133:
														goto end_IL_02ca;
													case 51:
													case 77:
														goto end_IL_02da;
													case 69:
														goto end_IL_02ea;
													case 70:
														goto end_IL_02fa;
													case 15:
													case 25:
													case 42:
													case 50:
													case 61:
													case 65:
													case 74:
													case 80:
													case 84:
													case 87:
													case 92:
													case 97:
													case 99:
													case 109:
													case 113:
													case 142:
														goto IL_0315;
													case 13:
													case 86:
														goto IL_0325;
													case 5:
														goto IL_032e;
													case 94:
														goto IL_033c;
													case 116:
														goto IL_034a;
													case 64:
														goto IL_0358;
													case 83:
														goto IL_0366;
													case 6:
													case 128:
														goto IL_0374;
													case 100:
													case 122:
														goto IL_0382;
													case 102:
														goto IL_0390;
													case 54:
													case 147:
														goto IL_039b;
													case 3:
														goto IL_03a9;
													case 10:
													case 120:
														goto IL_03b7;
													case 130:
														goto IL_03c5;
													case 8:
														goto IL_03dd;
													case 76:
														goto IL_03eb;
													case 53:
													case 132:
														goto IL_03fe;
													case 55:
														goto IL_0446;
													case 16:
													case 145:
														goto IL_0459;
													case 41:
														goto IL_0467;
													case 73:
													case 127:
														goto IL_0475;
													case 93:
														goto IL_049e;
													case 131:
														goto IL_04ac;
													case 137:
														goto IL_04bf;
													case 67:
														goto IL_04cd;
													case 48:
														goto IL_04d8;
													case 68:
														goto IL_04e6;
													case 24:
													case 98:
														goto IL_04f4;
													case 20:
														goto IL_051d;
													case 36:
														goto IL_0536;
													case 123:
														goto IL_0541;
													case 107:
														goto IL_054f;
													case 43:
													case 106:
														goto IL_055d;
													case 117:
														goto IL_0576;
													case 38:
														goto IL_0584;
													case 57:
														goto IL_0592;
													case 135:
													case 139:
														goto IL_05a5;
													case 140:
														goto IL_05e5;
													case 138:
														goto IL_05f9;
													case 22:
													case 79:
														goto IL_060c;
													case 9:
														goto IL_0633;
													case 17:
														goto IL_0641;
													case 7:
													case 91:
														goto IL_065d;
													case 88:
													case 89:
														goto IL_067e;
													case 21:
													case 121:
														goto IL_068c;
													case 40:
														goto IL_069a;
													case 1:
													case 143:
														goto IL_06a8;
													case 44:
														goto IL_06b6;
													case 26:
													case 60:
														goto IL_06c4;
													case 72:
														goto IL_0726;
													case 66:
													case 101:
														goto IL_0739;
													case 114:
													case 146:
														goto IL_0755;
													case 2:
														goto IL_0763;
													case 56:
														goto IL_0776;
													case 108:
													case 118:
														goto IL_0784;
													case 19:
													case 110:
														goto IL_0792;
													case 4:
														goto IL_07a0;
													case 34:
													case 119:
														goto IL_07ae;
													case 18:
														goto IL_07f2;
													case 90:
														goto IL_0806;
													case 32:
														goto IL_0819;
													case 75:
													case 78:
														goto IL_0824;
													case 71:
														goto IL_0832;
													case 81:
														goto IL_085e;
													case 111:
														goto IL_0871;
													case 33:
														goto IL_087f;
													case 125:
														goto IL_089b;
													case 112:
														goto IL_08a6;
													case 30:
													case 126:
														goto IL_08b6;
													case 58:
														goto IL_08f6;
													case 0:
														goto IL_090a;
													case 23:
													case 27:
													case 29:
													case 31:
													case 35:
													case 37:
													case 39:
													case 45:
													case 46:
													case 47:
													case 49:
													case 59:
													case 62:
													case 63:
													case 82:
													case 85:
													case 95:
													case 105:
													case 115:
													case 124:
													case 129:
													case 136:
													case 141:
													case 144:
														goto IL_091d;
													case 11:
													case 14:
														goto IL_093e;
													}
													continue;
													IL_08f6:
													array[num4 - 2] = 0;
													goto IL_090a;
													IL_090a:
													num4--;
													goto IL_0315;
													IL_0315:
													if (num5 != 1)
													{
														goto IL_0325;
													}
													goto IL_093e;
													IL_093e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_0325:
													b = *ptr2;
													goto IL_032e;
													IL_032e:
													ptr2++;
													goto IL_033c;
													IL_033c:
													if (b >= 1)
													{
														goto IL_034a;
													}
													goto IL_091d;
													IL_034a:
													if (b <= 15)
													{
														goto IL_0358;
													}
													goto IL_091d;
													IL_0358:
													if (8 >= b)
													{
														goto IL_0366;
													}
													num = 88;
													goto IL_067e;
													IL_0366:
													if (8 > b)
													{
														goto IL_0374;
													}
													goto IL_065d;
													IL_0374:
													if (4 < b)
													{
														goto IL_0382;
													}
													goto IL_04bf;
													IL_0382:
													if (6 >= b)
													{
														goto IL_0390;
													}
													goto IL_0459;
													IL_0390:
													if (6 > b)
													{
														goto IL_039b;
													}
													goto IL_03fe;
													IL_039b:
													if (5 >= b)
													{
														goto IL_03a9;
													}
													goto IL_091d;
													IL_03a9:
													if (5 <= b)
													{
														goto IL_03b7;
													}
													goto IL_091d;
													IL_03b7:
													array[num4] = 5;
													goto IL_03c5;
													IL_03c5:
													array2[num4] = array5[*(int*)(ptr2 + num3)];
													goto IL_03dd;
													IL_03dd:
													num4++;
													goto IL_03eb;
													IL_03eb:
													ptr2 += 8;
													goto IL_0315;
													IL_03fe:
													((int[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													num = 55;
													goto IL_0446;
													IL_0446:
													num4 -= 3;
													goto IL_0315;
													IL_0459:
													if (7 >= b)
													{
														goto IL_0467;
													}
													goto IL_091d;
													IL_0467:
													if (7 <= b)
													{
														goto IL_0475;
													}
													goto IL_091d;
													IL_0475:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_049e;
													IL_049e:
													ptr2 += 8;
													goto IL_04ac;
													IL_04ac:
													num4--;
													goto IL_0315;
													IL_04bf:
													if (4 > b)
													{
														goto IL_04cd;
													}
													goto IL_060c;
													IL_04cd:
													if (2 < b)
													{
														goto IL_04d8;
													}
													goto IL_0536;
													IL_04d8:
													if (3 >= b)
													{
														goto IL_04e6;
													}
													goto IL_091d;
													IL_04e6:
													if (3 <= b)
													{
														goto IL_04f4;
													}
													goto IL_091d;
													IL_04f4:
													array2[num4 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
													goto IL_051d;
													IL_051d:
													array[num4 - 1] = 5;
													goto IL_0315;
													IL_0536:
													if (2 > b)
													{
														goto IL_0541;
													}
													goto IL_05a5;
													IL_0541:
													if (1 >= b)
													{
														goto IL_054f;
													}
													goto IL_091d;
													IL_054f:
													if (1 <= b)
													{
														goto IL_055d;
													}
													goto IL_091d;
													IL_055d:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
													goto IL_0576;
													IL_0576:
													array[num4] = 0;
													goto IL_0584;
													IL_0584:
													num4++;
													goto IL_0592;
													IL_0592:
													ptr2 += 8;
													goto IL_0315;
													IL_05a5:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_05e5;
													IL_05e5:
													array[num4 - 2] = 0;
													goto IL_05f9;
													IL_05f9:
													num4--;
													goto IL_0315;
													IL_060c:
													array5[*(int*)(ptr2 + num3)] = array2[num4 - 1];
													num = 9;
													goto IL_0633;
													IL_0633:
													ptr2 += 8;
													goto IL_0641;
													IL_0641:
													num4--;
													num = 50;
													goto IL_0315;
													IL_065d:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0315;
													IL_091d:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													num = 113;
													goto IL_0315;
													IL_067e:
													if (12 < b)
													{
														goto IL_068c;
													}
													goto IL_0776;
													IL_068c:
													if (14 >= b)
													{
														goto IL_069a;
													}
													goto IL_0755;
													IL_069a:
													if (14 > b)
													{
														goto IL_06a8;
													}
													goto IL_0739;
													IL_06a8:
													if (13 >= b)
													{
														goto IL_06b6;
													}
													goto IL_091d;
													IL_06b6:
													if (13 <= b)
													{
														goto IL_06c4;
													}
													goto IL_091d;
													IL_06c4:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_0726;
													IL_0726:
													num4 -= 2;
													goto IL_0315;
													IL_0739:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_0315;
													IL_0755:
													if (15 >= b)
													{
														goto IL_0763;
													}
													goto IL_091d;
													IL_0763:
													if (15 <= b)
													{
													}
													goto IL_091d;
													IL_0776:
													if (12 > b)
													{
														goto IL_0784;
													}
													goto IL_08b6;
													IL_0784:
													if (10 < b)
													{
														goto IL_0792;
													}
													goto IL_0819;
													IL_0792:
													if (11 >= b)
													{
														goto IL_07a0;
													}
													goto IL_091d;
													IL_07a0:
													if (11 <= b)
													{
														goto IL_07ae;
													}
													goto IL_091d;
													IL_07ae:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((int[])array2[num4 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
													goto IL_07f2;
													IL_07f2:
													array[num4 - 2] = 0;
													goto IL_0806;
													IL_0806:
													num4--;
													goto IL_0315;
													IL_0819:
													if (10 <= b)
													{
														goto IL_0824;
													}
													goto IL_089b;
													IL_0824:
													array[num4] = 0;
													goto IL_0832;
													IL_0832:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													num = 81;
													goto IL_085e;
													IL_085e:
													array2[num4] = null;
													num = 111;
													goto IL_0871;
													IL_0871:
													num4++;
													goto IL_087f;
													IL_087f:
													ptr2 += 8;
													num = 92;
													goto IL_0315;
													IL_089b:
													if (9 >= b)
													{
														goto IL_08a6;
													}
													goto IL_091d;
													IL_08a6:
													if (9 <= b)
													{
														goto IL_0315;
													}
													goto IL_091d;
													IL_08b6:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_08f6;
													continue;
													end_IL_0277:
													break;
												}
												continue;
												end_IL_028a:
												break;
											}
											continue;
											end_IL_0295:
											break;
										}
										continue;
										end_IL_029f:
										break;
									}
									continue;
									end_IL_02aa:
									break;
								}
								continue;
								end_IL_02ba:
								break;
							}
							continue;
							end_IL_02ca:
							break;
						}
						continue;
						end_IL_02da:
						break;
					}
					continue;
					end_IL_02ea:
					break;
				}
				continue;
				end_IL_02fa:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_4, int int_5)
	{
		int num = 59;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 58;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AutoDualsetPermissionSet.CTSGetPEKind);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 46;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0239:
																byte b = *ptr2;
																while (true)
																{
																	IL_0220:
																	ptr2++;
																	num = 38;
																	while (true)
																	{
																		IL_0210:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01f0:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01e3:
																							if (6 >= b)
																							{
																								while (6 > b)
																								{
																									while (5 >= b)
																									{
																										while (true)
																										{
																											IL_01b0:
																											if (5 > b)
																											{
																												num = 96;
																												while (num != 96)
																												{
																													if (num != 1077)
																													{
																														goto end_IL_01d3;
																													}
																													switch (num)
																													{
																													case 15:
																														goto IL_01b0;
																													case 6:
																													case 67:
																														goto IL_01c3;
																													case 14:
																														goto IL_01d3;
																													case 5:
																													case 19:
																														goto IL_01e3;
																													case 57:
																														goto IL_01f0;
																													case 87:
																														goto IL_0200;
																													case 38:
																														goto IL_0210;
																													case 53:
																														goto IL_0220;
																													case 21:
																													case 81:
																														goto IL_0239;
																													case 34:
																														goto IL_0244;
																													case 12:
																														goto IL_024f;
																													case 9:
																													case 74:
																														goto IL_025d;
																													case 50:
																														goto IL_026b;
																													case 33:
																														goto IL_028e;
																													case 8:
																														goto IL_02a1;
																													case 11:
																														goto IL_02af;
																													case 42:
																													case 75:
																														goto IL_02c2;
																													case 44:
																														goto IL_02d0;
																													case 32:
																													case 76:
																														goto IL_02de;
																													case 22:
																													case 68:
																														goto IL_02fa;
																													case 23:
																														goto IL_0312;
																													case 10:
																													case 86:
																														goto IL_0320;
																													case 66:
																														goto IL_032e;
																													case 36:
																													case 69:
																														goto IL_033c;
																													case 83:
																														goto IL_03aa;
																													case 65:
																														goto IL_03bd;
																													case 82:
																														goto IL_03cb;
																													case 40:
																														goto IL_03de;
																													case 27:
																														goto IL_03ec;
																													case 29:
																													case 56:
																														goto IL_03fa;
																													case 3:
																														goto IL_043a;
																													case 47:
																														goto IL_044e;
																													case 2:
																													case 28:
																														goto IL_0461;
																													case 24:
																														goto IL_048a;
																													case 88:
																														goto IL_0498;
																													case 0:
																													case 13:
																													case 16:
																													case 17:
																													case 20:
																													case 25:
																													case 26:
																													case 30:
																													case 37:
																													case 39:
																													case 43:
																													case 45:
																													case 51:
																													case 64:
																													case 70:
																													case 85:
																														goto end_IL_019d;
																													case 63:
																														goto IL_04d4;
																													case 52:
																														goto IL_04e2;
																													case 49:
																														goto IL_04f9;
																													case 4:
																													case 7:
																													case 18:
																													case 41:
																													case 46:
																													case 48:
																													case 55:
																													case 62:
																													case 71:
																													case 79:
																														goto end_IL_01d3;
																													case 1:
																														goto end_IL_0507;
																													case 61:
																														goto end_IL_051a;
																													case 35:
																														goto end_IL_0525;
																													case 73:
																														goto end_IL_052f;
																													case 77:
																														goto end_IL_053a;
																													case 72:
																														goto end_IL_054f;
																													case 54:
																													case 78:
																														goto end_IL_0564;
																													case 89:
																														goto end_IL_0574;
																													case 60:
																													case 80:
																														goto end_IL_0584;
																													case 58:
																														goto end_IL_0594;
																													case 59:
																														goto end_IL_05a4;
																													case 31:
																													case 84:
																														goto IL_05c8;
																													}
																													continue;
																													end_IL_019d:
																													break;
																												}
																												break;
																											}
																											goto IL_02fa;
																											IL_02fa:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto end_IL_01d3;
																										}
																										break;
																										IL_01c3:;
																									}
																									goto end_IL_0200;
																									continue;
																									end_IL_01d3:
																									break;
																									IL_01d3:;
																								}
																								break;
																							}
																							goto IL_0244;
																							IL_02de:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							break;
																							IL_0244:
																							if (7 >= b)
																							{
																								goto IL_024f;
																							}
																							goto IL_02c2;
																							IL_024f:
																							if (7 > b)
																							{
																								goto end_IL_0200;
																							}
																							goto IL_025d;
																							IL_025d:
																							array[num6] = 0;
																							goto IL_026b;
																							IL_026b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_028e;
																							IL_028e:
																							array2[num6] = null;
																							num = 8;
																							goto IL_02a1;
																							IL_02a1:
																							num6++;
																							goto IL_02af;
																							IL_02af:
																							ptr2 += 8;
																							break;
																							IL_02c2:
																							if (8 < b)
																							{
																								goto end_IL_0200;
																							}
																							goto IL_02d0;
																							IL_02d0:
																							if (8 > b)
																							{
																								goto end_IL_0200;
																							}
																							goto IL_02de;
																						}
																						break;
																					}
																					goto IL_0312;
																					IL_0498:
																					num6--;
																					break;
																					IL_0312:
																					if (4 > b)
																					{
																						goto IL_0320;
																					}
																					goto IL_0461;
																					IL_0320:
																					if (2 >= b)
																					{
																						goto IL_032e;
																					}
																					goto IL_03de;
																					IL_032e:
																					if (2 <= b)
																					{
																						goto IL_033c;
																					}
																					goto IL_03bd;
																					IL_033c:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03aa;
																					IL_03aa:
																					num6 -= 2;
																					break;
																					IL_03bd:
																					if (1 < b)
																					{
																						goto end_IL_0200;
																					}
																					goto IL_03cb;
																					IL_03cb:
																					if (1 > b)
																					{
																					}
																					goto end_IL_0200;
																					IL_03de:
																					if (3 < b)
																					{
																						goto end_IL_0200;
																					}
																					goto IL_03ec;
																					IL_03ec:
																					if (3 > b)
																					{
																						goto end_IL_0200;
																					}
																					goto IL_03fa;
																					IL_03fa:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_043a;
																					IL_043a:
																					array[num6 - 2] = 0;
																					goto IL_044e;
																					IL_044e:
																					num6--;
																					break;
																					IL_0461:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_048a;
																					IL_048a:
																					ptr2 += 8;
																					goto IL_0498;
																				}
																				goto end_IL_0210;
																				continue;
																				end_IL_0200:
																				break;
																				IL_0200:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		num = 63;
																		goto IL_04d4;
																		IL_04f9:
																		ptr2 += 8;
																		break;
																		IL_04e2:
																		num6++;
																		num = 49;
																		goto IL_04f9;
																		IL_04d4:
																		array[num6] = 0;
																		goto IL_04e2;
																		continue;
																		end_IL_0210:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_05c8;
														IL_05c8:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														continue;
														end_IL_0507:
														break;
													}
													continue;
													end_IL_051a:
													break;
												}
												continue;
												end_IL_0525:
												break;
											}
											continue;
											end_IL_052f:
											break;
										}
										continue;
										end_IL_053a:
										break;
									}
									continue;
									end_IL_054f:
									break;
								}
								continue;
								end_IL_0564:
								break;
							}
							continue;
							end_IL_0574:
							break;
						}
						continue;
						end_IL_0584:
						break;
					}
					continue;
					end_IL_0594:
					break;
				}
				continue;
				end_IL_05a4:
				break;
			}
		}
	}

	private unsafe static int smethod_15()
	{
		int num = 52;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 12;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UpdateKwdTriggersgetParamTypes.getMajorIsFinal);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02fd:
															byte b = *ptr2;
															while (true)
															{
																IL_02ed:
																ptr2++;
																while (true)
																{
																	IL_02dd:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02bd:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02b0:
																						if (8 <= b)
																						{
																							while (true)
																							{
																								IL_0292:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								num = 156;
																								while (num != 156)
																								{
																									if (num != 1137)
																									{
																										goto IL_06f2;
																									}
																									switch (num)
																									{
																									case 39:
																									case 45:
																										goto IL_0292;
																									case 88:
																										goto IL_02b0;
																									case 74:
																										goto IL_02bd;
																									case 23:
																										goto IL_02cd;
																									case 35:
																										goto IL_02dd;
																									case 136:
																										goto IL_02ed;
																									case 44:
																									case 119:
																										goto IL_02fd;
																									case 8:
																									case 14:
																										goto IL_0308;
																									case 27:
																										goto IL_0313;
																									case 22:
																									case 80:
																										goto IL_031e;
																									case 87:
																										goto IL_0337;
																									case 19:
																									case 91:
																										goto IL_034a;
																									case 67:
																										goto IL_0368;
																									case 7:
																										goto IL_0376;
																									case 120:
																										goto IL_0389;
																									case 111:
																										goto IL_0394;
																									case 36:
																										goto IL_03a2;
																									case 41:
																									case 113:
																										goto IL_03b0;
																									case 71:
																										goto IL_03db;
																									case 121:
																										goto IL_03eb;
																									case 30:
																									case 81:
																										goto IL_03f9;
																									case 106:
																										goto IL_0422;
																									case 125:
																										goto IL_043b;
																									case 10:
																										goto IL_0449;
																									case 126:
																									case 133:
																										goto IL_045c;
																									case 146:
																										goto IL_04a0;
																									case 48:
																									case 104:
																										goto IL_04ab;
																									case 31:
																										goto IL_04b9;
																									case 34:
																									case 50:
																										goto IL_04c7;
																									case 66:
																										goto IL_04e9;
																									case 38:
																										goto IL_04f7;
																									case 70:
																										goto IL_050e;
																									case 17:
																									case 110:
																										goto IL_0521;
																									case 18:
																										goto IL_0561;
																									case 40:
																										goto IL_0575;
																									case 147:
																										goto IL_0588;
																									case 122:
																									case 149:
																										goto IL_059b;
																									case 59:
																										goto IL_05a6;
																									case 20:
																									case 97:
																										goto IL_05b4;
																									case 49:
																										goto IL_05c2;
																									case 128:
																										goto IL_05da;
																									case 6:
																										goto IL_05e8;
																									case 29:
																										goto IL_0609;
																									case 93:
																										goto IL_0617;
																									case 102:
																										goto IL_0625;
																									case 46:
																									case 138:
																										goto IL_0633;
																									case 11:
																										goto IL_064a;
																									case 3:
																									case 69:
																										goto IL_0658;
																									case 9:
																										goto IL_06ba;
																									case 99:
																									case 118:
																										goto IL_06cd;
																									case 33:
																									case 107:
																										goto IL_06f2;
																									case 123:
																										goto IL_0700;
																									case 148:
																										goto IL_0713;
																									case 77:
																									case 95:
																										goto IL_071e;
																									case 140:
																										goto IL_075e;
																									case 117:
																										goto IL_0772;
																									case 129:
																										goto IL_0785;
																									case 0:
																										goto IL_0793;
																									case 85:
																									case 143:
																										goto IL_079e;
																									case 112:
																										goto IL_07ac;
																									case 2:
																									case 109:
																										goto IL_07bf;
																									case 134:
																										goto IL_07cd;
																									case 100:
																										goto IL_07f0;
																									case 132:
																										goto IL_0803;
																									case 145:
																										goto IL_0811;
																									case 37:
																										goto IL_0824;
																									case 96:
																										goto IL_082f;
																									case 26:
																									case 86:
																										goto IL_083a;
																									case 32:
																										goto IL_087e;
																									case 60:
																										goto IL_0892;
																									case 4:
																									case 13:
																									case 15:
																									case 21:
																									case 24:
																									case 25:
																									case 42:
																									case 43:
																									case 55:
																									case 58:
																									case 61:
																									case 62:
																									case 68:
																									case 73:
																									case 78:
																									case 89:
																									case 92:
																									case 108:
																									case 114:
																									case 115:
																									case 116:
																									case 124:
																									case 127:
																									case 130:
																									case 135:
																									case 137:
																									case 141:
																									case 142:
																									case 144:
																										goto end_IL_02cd;
																									case 1:
																									case 5:
																									case 28:
																									case 53:
																									case 54:
																									case 57:
																									case 63:
																									case 72:
																									case 82:
																									case 83:
																									case 84:
																									case 98:
																									case 101:
																									case 103:
																									case 105:
																									case 131:
																									case 139:
																										goto end_IL_027f;
																									case 75:
																										goto end_IL_08b5;
																									case 64:
																										goto end_IL_08c8;
																									case 79:
																										goto end_IL_08d2;
																									case 47:
																										goto end_IL_08dd;
																									case 16:
																									case 56:
																										goto end_IL_08ed;
																									case 94:
																										goto end_IL_08fd;
																									case 12:
																										goto end_IL_090d;
																									case 65:
																										goto end_IL_091d;
																									case 51:
																										goto end_IL_092d;
																									case 52:
																										goto end_IL_0938;
																									case 76:
																									case 90:
																										goto IL_0953;
																									}
																									continue;
																									end_IL_027f:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0308;
																						IL_0588:
																						num5 -= 3;
																						break;
																						IL_0308:
																						if (4 >= b)
																						{
																							goto IL_0313;
																						}
																						goto IL_0389;
																						IL_0313:
																						if (4 > b)
																						{
																							goto IL_031e;
																						}
																						goto IL_034a;
																						IL_031e:
																						if (2 < b)
																						{
																							goto IL_0337;
																						}
																						num = 146;
																						goto IL_04a0;
																						IL_045c:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0588;
																						IL_04a0:
																						if (2 > b)
																						{
																							goto IL_04ab;
																						}
																						goto IL_0521;
																						IL_04ab:
																						if (1 < b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_04b9;
																						IL_04b9:
																						if (1 > b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_04c7;
																						IL_04c7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						num = 66;
																						goto IL_04e9;
																						IL_04e9:
																						array[num5] = 0;
																						goto IL_04f7;
																						IL_04f7:
																						num5++;
																						num = 70;
																						goto IL_050e;
																						IL_050e:
																						ptr2 += 8;
																						break;
																						IL_0521:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0561;
																						IL_0561:
																						array[num5 - 2] = 0;
																						goto IL_0575;
																						IL_0575:
																						num5--;
																						break;
																						IL_0337:
																						if (3 < b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_03eb;
																						IL_03eb:
																						if (3 > b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_03f9;
																						IL_03f9:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_0422;
																						IL_0422:
																						array[num5 - 1] = 5;
																						break;
																						IL_034a:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_0368;
																						IL_0368:
																						ptr2 += 8;
																						goto IL_0376;
																						IL_0376:
																						num5--;
																						break;
																						IL_0389:
																						if (6 < b)
																						{
																							goto IL_0394;
																						}
																						goto IL_03db;
																						IL_0394:
																						if (7 < b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_03a2;
																						IL_03a2:
																						if (7 > b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_03b0;
																						IL_03b0:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_043b;
																						IL_043b:
																						ptr2 += 8;
																						goto IL_0449;
																						IL_0449:
																						num5--;
																						break;
																						IL_03db:
																						if (6 <= b)
																						{
																							goto IL_045c;
																						}
																						goto IL_059b;
																						IL_059b:
																						if (5 < b)
																						{
																							num = 61;
																							goto end_IL_02cd;
																						}
																						goto IL_05a6;
																						IL_05a6:
																						if (5 > b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_05b4;
																						IL_05b4:
																						array[num5] = 5;
																						goto IL_05c2;
																						IL_05c2:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_05da;
																						IL_05da:
																						num5++;
																						goto IL_05e8;
																						IL_05e8:
																						ptr2 += 8;
																						break;
																					}
																					break;
																				}
																				goto IL_0609;
																				IL_083a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_087e;
																				IL_0609:
																				if (12 < b)
																				{
																					goto IL_0617;
																				}
																				goto IL_0713;
																				IL_0617:
																				if (14 >= b)
																				{
																					goto IL_0625;
																				}
																				num = 107;
																				goto IL_06f2;
																				IL_0625:
																				if (14 > b)
																				{
																					goto IL_0633;
																				}
																				goto IL_06cd;
																				IL_0633:
																				if (13 < b)
																				{
																					goto end_IL_02cd;
																				}
																				num = 11;
																				goto IL_064a;
																				IL_0892:
																				num5--;
																				break;
																				IL_064a:
																				if (13 > b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_0658;
																				IL_0658:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06ba;
																				IL_06ba:
																				num5 -= 2;
																				break;
																				IL_06cd:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_087e:
																				array[num5 - 2] = 0;
																				goto IL_0892;
																				IL_06f2:
																				if (15 < b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_0700;
																				IL_0700:
																				if (15 <= b)
																				{
																				}
																				goto end_IL_02cd;
																				IL_0713:
																				if (12 <= b)
																				{
																					goto IL_071e;
																				}
																				goto IL_0785;
																				IL_071e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_075e;
																				IL_075e:
																				array[num5 - 2] = 0;
																				goto IL_0772;
																				IL_0772:
																				num5--;
																				break;
																				IL_0785:
																				if (10 >= b)
																				{
																					goto IL_0793;
																				}
																				goto IL_0824;
																				IL_0793:
																				if (10 > b)
																				{
																					goto IL_079e;
																				}
																				goto IL_07bf;
																				IL_079e:
																				if (9 < b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_07ac;
																				IL_07ac:
																				if (9 <= b)
																				{
																					break;
																				}
																				goto end_IL_02cd;
																				IL_07bf:
																				array[num5] = 0;
																				goto IL_07cd;
																				IL_07cd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_07f0;
																				IL_07f0:
																				array2[num5] = null;
																				num = 132;
																				goto IL_0803;
																				IL_0803:
																				num5++;
																				goto IL_0811;
																				IL_0811:
																				ptr2 += 8;
																				break;
																				IL_0824:
																				if (11 < b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_082f;
																				IL_082f:
																				if (11 > b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_083a;
																			}
																			goto end_IL_02dd;
																			continue;
																			end_IL_02cd:
																			break;
																			IL_02cd:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02dd:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0953;
													IL_0953:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08b5:
													break;
												}
												continue;
												end_IL_08c8:
												break;
											}
											continue;
											end_IL_08d2:
											break;
										}
										continue;
										end_IL_08dd:
										break;
									}
									continue;
									end_IL_08ed:
									break;
								}
								continue;
								end_IL_08fd:
								break;
							}
							continue;
							end_IL_090d:
							break;
						}
						continue;
						end_IL_091d:
						break;
					}
					continue;
					end_IL_092d:
					break;
				}
				continue;
				end_IL_0938:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_4)
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SymLanguageTypeAssemblyPathLock.invkindsetClipboard);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0224:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_0214:
																		if (b <= 10)
																		{
																			while (true)
																			{
																				IL_0204:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_01f4:
																						if (5 <= b)
																						{
																							num = 113;
																							while (true)
																							{
																								if (num != 113)
																								{
																									if (num != 1094)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 71:
																										goto IL_01f4;
																									case 74:
																										goto IL_0204;
																									case 8:
																										goto IL_0214;
																									case 77:
																										goto IL_0224;
																									case 63:
																										goto end_IL_0224;
																									case 9:
																									case 90:
																										goto end_IL_0234;
																									case 58:
																										goto IL_024f;
																									case 15:
																										goto IL_025a;
																									case 54:
																										goto IL_0265;
																									case 64:
																										goto IL_0273;
																									case 79:
																										goto IL_0286;
																									case 39:
																										goto IL_0291;
																									case 2:
																									case 75:
																										goto IL_029f;
																									case 46:
																									case 81:
																										goto IL_02b7;
																									case 83:
																										goto IL_02c5;
																									case 47:
																									case 92:
																										goto IL_02d8;
																									case 6:
																									case 98:
																										goto IL_030c;
																									case 56:
																										goto IL_0325;
																									case 82:
																										goto IL_0333;
																									case 1:
																										goto IL_0341;
																									case 105:
																										goto IL_0354;
																									case 38:
																										goto IL_0362;
																									case 100:
																										goto IL_0375;
																									case 40:
																										goto IL_0383;
																									case 62:
																										goto IL_03a6;
																									case 51:
																										goto IL_03b0;
																									case 84:
																										goto IL_03be;
																									case 55:
																									case 106:
																										goto IL_03d1;
																									case 25:
																									case 80:
																										goto IL_03dc;
																									case 52:
																										goto IL_03e7;
																									case 22:
																									case 61:
																										goto IL_03f5;
																									case 76:
																										goto IL_0411;
																									case 69:
																										goto IL_041f;
																									case 18:
																										goto IL_0432;
																									case 30:
																									case 31:
																										goto IL_0440;
																									case 70:
																										goto IL_044b;
																									case 36:
																									case 73:
																										goto IL_0459;
																									case 17:
																										goto IL_0499;
																									case 49:
																										goto IL_04ad;
																									case 89:
																									case 99:
																										goto IL_04c0;
																									case 87:
																										goto IL_04ce;
																									case 21:
																									case 35:
																										goto IL_04dc;
																									case 57:
																										goto IL_04ff;
																									case 65:
																										goto IL_050d;
																									case 85:
																										goto IL_051b;
																									case 34:
																									case 37:
																										goto IL_052e;
																									case 16:
																										goto IL_0590;
																									case 0:
																									case 4:
																									case 5:
																									case 11:
																									case 12:
																									case 13:
																									case 14:
																									case 26:
																									case 41:
																									case 43:
																									case 44:
																									case 45:
																									case 78:
																									case 86:
																									case 93:
																									case 95:
																									case 96:
																									case 97:
																									case 101:
																									case 102:
																									case 103:
																										goto end_IL_01e1;
																									case 3:
																									case 7:
																									case 23:
																									case 24:
																									case 27:
																									case 28:
																									case 32:
																									case 48:
																									case 68:
																									case 72:
																									case 91:
																									case 94:
																									case 104:
																										goto end_IL_0244;
																									case 59:
																										goto end_IL_05c5;
																									case 60:
																										goto end_IL_05d8;
																									case 50:
																										goto end_IL_05e2;
																									case 10:
																										goto end_IL_05ed;
																									case 33:
																									case 42:
																										goto end_IL_0602;
																									case 88:
																										goto end_IL_0612;
																									case 66:
																									case 67:
																										goto end_IL_0622;
																									case 19:
																										goto end_IL_0632;
																									case 20:
																										goto end_IL_0642;
																									case 29:
																									case 53:
																										goto IL_065d;
																									}
																									continue;
																								}
																								goto IL_0375;
																								IL_03b0:
																								num5++;
																								goto IL_03be;
																								IL_03be:
																								ptr2 += 8;
																								goto end_IL_0244;
																								IL_0375:
																								array[num5] = 0;
																								goto IL_0383;
																								IL_0383:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03a6;
																								IL_03a6:
																								array2[num5] = null;
																								goto IL_03b0;
																								continue;
																								end_IL_01e1:
																								break;
																							}
																							break;
																						}
																						goto IL_024f;
																						IL_02b7:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_02c5;
																						IL_02c5:
																						if (4 > b)
																						{
																							break;
																						}
																						goto end_IL_0244;
																						IL_024f:
																						if (2 >= b)
																						{
																							goto IL_025a;
																						}
																						goto IL_0286;
																						IL_025a:
																						if (2 > b)
																						{
																							goto IL_0265;
																						}
																						goto IL_02d8;
																						IL_0265:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_0273;
																						IL_0273:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_030c;
																						IL_030c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0325;
																						IL_0325:
																						array[num5] = 0;
																						goto IL_0333;
																						IL_0333:
																						num5++;
																						goto IL_0341;
																						IL_0341:
																						ptr2 += 8;
																						goto end_IL_0244;
																						IL_02d8:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 105;
																						goto IL_0354;
																						IL_0354:
																						ptr2 += 8;
																						goto IL_0362;
																						IL_0362:
																						num5--;
																						goto end_IL_0244;
																						IL_0286:
																						if (3 >= b)
																						{
																							goto IL_0291;
																						}
																						goto IL_02b7;
																						IL_0291:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_029f;
																						IL_029f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0244;
																					}
																					break;
																				}
																				goto IL_03d1;
																				IL_0590:
																				num5 -= 2;
																				num = 72;
																				goto end_IL_0244;
																				IL_03d1:
																				if (8 < b)
																				{
																					goto IL_03dc;
																				}
																				goto IL_0432;
																				IL_03dc:
																				if (9 >= b)
																				{
																					goto IL_03e7;
																				}
																				goto IL_0411;
																				IL_03e7:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_03f5;
																				IL_03f5:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0244;
																				IL_0411:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_041f;
																				IL_041f:
																				if (10 > b)
																				{
																				}
																				break;
																				IL_0432:
																				if (8 > b)
																				{
																					goto IL_0440;
																				}
																				goto IL_052e;
																				IL_0440:
																				if (6 >= b)
																				{
																					goto IL_044b;
																				}
																				goto IL_04c0;
																				IL_044b:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0459;
																				IL_0459:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0499;
																				IL_0499:
																				array[num5 - 2] = 0;
																				goto IL_04ad;
																				IL_04ad:
																				num5--;
																				goto end_IL_0244;
																				IL_04c0:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_04ce;
																				IL_04ce:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04dc;
																				IL_04dc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04ff;
																				IL_04ff:
																				array[num5] = 0;
																				goto IL_050d;
																				IL_050d:
																				num5++;
																				goto IL_051b;
																				IL_051b:
																				ptr2 += 8;
																				goto end_IL_0244;
																				IL_052e:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0590;
																			}
																		}
																		else
																		{
																			num = 43;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0244;
																continue;
																end_IL_0224:
																break;
															}
															continue;
															end_IL_0234:
															break;
														}
														continue;
														end_IL_0244:
														break;
													}
													continue;
												}
												goto IL_065d;
												IL_065d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05c5:
												break;
											}
											continue;
											end_IL_05d8:
											break;
										}
										continue;
										end_IL_05e2:
										break;
									}
									continue;
									end_IL_05ed:
									break;
								}
								continue;
								end_IL_0602:
								break;
							}
							continue;
							end_IL_0612:
							break;
						}
						continue;
						end_IL_0622:
						break;
					}
					continue;
					end_IL_0632:
					break;
				}
				continue;
				end_IL_0642:
				break;
			}
		}
	}

	private static int smethod_17(int int_4)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_4;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_18()
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 8;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MetadataSectionCompatibleFrameworksDataIEnumSTORECATEGORYSUBCATEGORY.FUNCSTATICForegroundGreen);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03a3:
														byte b = *ptr2;
														while (true)
														{
															IL_0393:
															ptr2++;
															while (true)
															{
																IL_0380:
																if (b >= 1)
																{
																	num = 93;
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0360:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_0343:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_0333:
																								if (6 >= b)
																								{
																									while (true)
																									{
																										IL_0323:
																										if (6 > b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_02f3:
																														array[num5] = 5;
																														while (true)
																														{
																															IL_02d0:
																															array2[num5] = array5[*(int*)(ptr2 + num3)];
																															num = 168;
																															while (true)
																															{
																																if (num != 168)
																																{
																																	if (num != 1149)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 76:
																																		goto IL_02d0;
																																	case 147:
																																	case 150:
																																		goto IL_02f3;
																																	case 72:
																																		goto IL_0303;
																																	case 74:
																																	case 126:
																																		goto IL_0313;
																																	case 161:
																																		goto IL_0323;
																																	case 129:
																																		goto IL_0333;
																																	case 3:
																																	case 85:
																																		goto IL_0343;
																																	case 127:
																																		goto IL_0350;
																																	case 139:
																																		goto IL_0360;
																																	case 93:
																																		goto IL_0370;
																																	case 7:
																																		goto IL_0380;
																																	case 91:
																																		goto IL_0393;
																																	case 83:
																																	case 92:
																																		goto end_IL_02bd;
																																	case 44:
																																		goto IL_03ae;
																																	case 57:
																																		goto IL_03bc;
																																	case 89:
																																		goto IL_03d3;
																																	case 14:
																																	case 56:
																																		goto IL_03e1;
																																	case 96:
																																		goto IL_0421;
																																	case 73:
																																		goto IL_0435;
																																	case 101:
																																		goto IL_0448;
																																	case 40:
																																		goto IL_0453;
																																	case 62:
																																		goto IL_0466;
																																	case 81:
																																		goto IL_0474;
																																	case 98:
																																	case 103:
																																		goto IL_0487;
																																	case 110:
																																		goto IL_04aa;
																																	case 88:
																																		goto IL_04c1;
																																	case 69:
																																	case 115:
																																		goto IL_04d4;
																																	case 16:
																																		goto IL_04e2;
																																	case 59:
																																	case 99:
																																		goto IL_04ed;
																																	case 47:
																																	case 67:
																																		goto IL_0500;
																																	case 46:
																																	case 117:
																																		goto IL_0564;
																																	case 18:
																																		goto IL_0572;
																																	case 60:
																																	case 112:
																																		goto IL_0580;
																																	case 87:
																																	case 119:
																																		goto IL_0593;
																																	case 122:
																																		goto IL_05ba;
																																	case 128:
																																		goto IL_05cd;
																																	case 45:
																																		goto IL_05db;
																																	case 125:
																																		goto IL_05e6;
																																	case 42:
																																	case 100:
																																		goto IL_05f1;
																																	case 43:
																																		goto IL_05ff;
																																	case 64:
																																		goto IL_0622;
																																	case 116:
																																		goto IL_062c;
																																	case 50:
																																		goto IL_0643;
																																	case 79:
																																	case 107:
																																		goto IL_0672;
																																	case 133:
																																		goto IL_06b6;
																																	case 95:
																																		goto IL_06d3;
																																	case 39:
																																	case 134:
																																		goto IL_06e6;
																																	case 130:
																																		goto IL_06f4;
																																	case 141:
																																		goto IL_0707;
																																	case 66:
																																		goto IL_0715;
																																	case 32:
																																		goto IL_0723;
																																	case 144:
																																		goto IL_073f;
																																	case 123:
																																		goto IL_074d;
																																	case 145:
																																		goto IL_0760;
																																	case 35:
																																		goto IL_076e;
																																	case 49:
																																	case 146:
																																		goto IL_0781;
																																	case 28:
																																		goto IL_07aa;
																																	case 36:
																																		goto IL_07b8;
																																	case 148:
																																		goto IL_07cb;
																																	case 22:
																																		goto IL_07d9;
																																	case 9:
																																	case 114:
																																		goto IL_07e7;
																																	case 1:
																																		goto IL_0810;
																																	case 106:
																																	case 149:
																																		goto IL_0829;
																																	case 52:
																																		goto IL_0837;
																																	case 31:
																																	case 151:
																																		goto IL_084a;
																																	case 109:
																																	case 152:
																																		goto IL_0862;
																																	case 143:
																																		goto IL_0870;
																																	case 41:
																																	case 58:
																																		goto IL_087e;
																																	case 30:
																																		goto IL_0892;
																																	case 13:
																																		goto IL_08d1;
																																	case 24:
																																	case 157:
																																		goto IL_08e4;
																																	case 105:
																																	case 160:
																																		goto IL_0900;
																																	case 156:
																																		goto IL_0940;
																																	case 2:
																																		goto IL_0954;
																																	case 68:
																																		goto IL_0975;
																																	case 19:
																																	case 70:
																																		goto IL_0985;
																																	case 135:
																																		goto IL_09c4;
																																	case 4:
																																	case 5:
																																	case 10:
																																	case 11:
																																	case 12:
																																	case 17:
																																	case 26:
																																	case 33:
																																	case 37:
																																	case 53:
																																	case 54:
																																	case 65:
																																	case 80:
																																	case 82:
																																	case 84:
																																	case 94:
																																	case 102:
																																	case 104:
																																	case 111:
																																	case 113:
																																	case 118:
																																	case 120:
																																	case 132:
																																	case 136:
																																	case 137:
																																	case 138:
																																	case 142:
																																	case 155:
																																		goto end_IL_0303;
																																	case 0:
																																	case 15:
																																	case 20:
																																	case 21:
																																	case 25:
																																	case 27:
																																	case 38:
																																	case 48:
																																	case 51:
																																	case 55:
																																	case 61:
																																	case 71:
																																	case 75:
																																	case 90:
																																	case 108:
																																	case 121:
																																	case 124:
																																	case 131:
																																	case 140:
																																	case 159:
																																		goto end_IL_0350;
																																	case 153:
																																		goto end_IL_09e7;
																																	case 34:
																																		goto end_IL_09fa;
																																	case 23:
																																		goto end_IL_0a04;
																																	case 97:
																																		goto end_IL_0a0f;
																																	case 8:
																																	case 63:
																																		goto end_IL_0a1f;
																																	case 86:
																																		goto end_IL_0a2f;
																																	case 6:
																																	case 154:
																																		goto end_IL_0a3f;
																																	case 77:
																																		goto end_IL_0a58;
																																	case 78:
																																		goto end_IL_0a68;
																																	case 29:
																																	case 158:
																																		goto IL_0a83;
																																	}
																																	continue;
																																}
																																num5++;
																																goto IL_0975;
																																IL_0975:
																																ptr2 += 8;
																																goto end_IL_0350;
																																continue;
																																end_IL_02bd:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_03a3;
																													continue;
																													end_IL_0303:
																													break;
																													IL_0303:;
																												}
																												break;
																												IL_0313:;
																											}
																											break;
																										}
																										goto IL_0985;
																										IL_09c4:
																										num5 -= 3;
																										goto end_IL_0350;
																										IL_0985:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_09c4;
																									}
																									break;
																								}
																								goto IL_0448;
																								IL_084a:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0350;
																								IL_0448:
																								if (7 >= b)
																								{
																									goto IL_0453;
																								}
																								goto IL_0466;
																								IL_0453:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0781;
																								IL_0781:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_07aa;
																								IL_07aa:
																								ptr2 += 8;
																								goto IL_07b8;
																								IL_07b8:
																								num5--;
																								goto end_IL_0350;
																								IL_0466:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_0474;
																								IL_0474:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_084a;
																							}
																							break;
																						}
																						goto IL_03ae;
																						IL_0487:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_073f;
																						IL_03ae:
																						if (4 > b)
																						{
																							goto IL_03bc;
																						}
																						goto IL_0487;
																						IL_03bc:
																						if (2 >= b)
																						{
																							num = 89;
																							goto IL_03d3;
																						}
																						goto IL_07cb;
																						IL_073f:
																						ptr2 += 8;
																						goto IL_074d;
																						IL_03d3:
																						if (2 <= b)
																						{
																							goto IL_03e1;
																						}
																						goto IL_04aa;
																						IL_03e1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0421;
																						IL_0421:
																						array[num5 - 2] = 0;
																						goto IL_0435;
																						IL_0435:
																						num5--;
																						goto end_IL_0350;
																						IL_04aa:
																						if (1 < b)
																						{
																							break;
																						}
																						num = 88;
																						goto IL_04c1;
																						IL_074d:
																						num5--;
																						goto end_IL_0350;
																						IL_04c1:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_0593;
																						IL_0593:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						num = 141;
																						goto IL_0707;
																						IL_0707:
																						array[num5] = 0;
																						goto IL_0715;
																						IL_0715:
																						num5++;
																						goto IL_0723;
																						IL_0723:
																						ptr2 += 8;
																						num = 48;
																						goto end_IL_0350;
																						IL_07cb:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_07d9;
																						IL_07d9:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_07e7;
																						IL_07e7:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_0810;
																						IL_0810:
																						array[num5 - 1] = 5;
																						goto end_IL_0350;
																					}
																					goto end_IL_0370;
																					continue;
																					end_IL_0350:
																					break;
																					IL_0350:;
																				}
																				break;
																			}
																			goto IL_04d4;
																			IL_08e4:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_04d4:
																			if (13 >= b)
																			{
																				goto IL_04e2;
																			}
																			goto IL_0564;
																			IL_04e2:
																			if (13 > b)
																			{
																				goto IL_04ed;
																			}
																			goto IL_0500;
																			IL_04ed:
																			if (11 >= b)
																			{
																				goto IL_05cd;
																			}
																			goto IL_0760;
																			IL_05cd:
																			if (11 > b)
																			{
																				goto IL_05db;
																			}
																			goto IL_0672;
																			IL_05db:
																			if (10 < b)
																			{
																				num = 5;
																				goto end_IL_0370;
																			}
																			goto IL_05e6;
																			IL_05e6:
																			if (10 > b)
																			{
																				num = 104;
																				goto end_IL_0370;
																			}
																			goto IL_05f1;
																			IL_05f1:
																			array[num5] = 0;
																			goto IL_05ff;
																			IL_05ff:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0622;
																			IL_0622:
																			array2[num5] = null;
																			goto IL_062c;
																			IL_062c:
																			num5++;
																			num = 50;
																			goto IL_0643;
																			IL_0643:
																			ptr2 += 8;
																			break;
																			IL_0837:
																			if (17 <= b)
																			{
																			}
																			goto end_IL_0370;
																			IL_0829:
																			if (17 < b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_0837;
																			IL_0672:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06b6;
																			IL_06b6:
																			array[num5 - 2] = 0;
																			num = 95;
																			goto IL_06d3;
																			IL_06d3:
																			num5--;
																			break;
																			IL_0760:
																			if (12 < b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_076e;
																			IL_076e:
																			if (12 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_0900;
																			IL_0900:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0940;
																			IL_0940:
																			array[num5 - 2] = 0;
																			goto IL_0954;
																			IL_0954:
																			num5--;
																			break;
																			IL_0500:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05ba;
																			IL_05ba:
																			num5 -= 2;
																			break;
																			IL_0564:
																			if (15 >= b)
																			{
																				goto IL_0572;
																			}
																			goto IL_06e6;
																			IL_0572:
																			if (15 <= b)
																			{
																				goto IL_0580;
																			}
																			goto IL_0862;
																			IL_0580:
																			num5--;
																			break;
																			IL_0862:
																			if (14 < b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_0870;
																			IL_0870:
																			if (14 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_087e;
																			IL_087e:
																			array[num5 - 1] = 0;
																			goto IL_0892;
																			IL_0892:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ProcessingModegetFullTypeName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_08d1;
																			IL_08d1:
																			ptr2 += 8;
																			break;
																			IL_06e6:
																			if (16 >= b)
																			{
																				goto IL_06f4;
																			}
																			goto IL_0829;
																			IL_06f4:
																			if (16 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_08e4;
																		}
																		goto end_IL_0380;
																		continue;
																		end_IL_0370:
																		break;
																		IL_0370:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0380:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a83;
												IL_0a83:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09e7:
												break;
											}
											continue;
											end_IL_09fa:
											break;
										}
										continue;
										end_IL_0a04:
										break;
									}
									continue;
									end_IL_0a0f:
									break;
								}
								continue;
								end_IL_0a1f:
								break;
							}
							continue;
							end_IL_0a2f:
							break;
						}
						continue;
						end_IL_0a3f:
						break;
					}
					continue;
					end_IL_0a58:
					break;
				}
				continue;
				end_IL_0a68:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_4, int int_5)
	{
		int num = 90;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 26;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_4;
										while (true)
										{
											array3[1] = int_5;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref sourceBytesToCopygetOpaqueLength.ISecurityElementFactoryFileIOPermission);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_025b:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_023b:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_022e:
																							if (6 < b)
																							{
																								while (true)
																								{
																									IL_0221:
																									if (7 >= b)
																									{
																										while (7 <= b)
																										{
																											num = 14;
																											while (true)
																											{
																												array[num5] = 0;
																												while (true)
																												{
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													while (true)
																													{
																														array2[num5] = null;
																														while (true)
																														{
																															IL_01b4:
																															num5++;
																															num = 97;
																															while (true)
																															{
																																if (num != 97)
																																{
																																	if (num != 1078)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 12:
																																		goto IL_01b4;
																																	case 68:
																																		goto end_IL_01a1;
																																	case 31:
																																		goto end_IL_01cd;
																																	case 14:
																																	case 58:
																																		goto end_IL_01d9;
																																	case 52:
																																		goto end_IL_01fe;
																																	case 82:
																																		goto IL_0221;
																																	case 17:
																																		goto IL_022e;
																																	case 76:
																																		goto IL_023b;
																																	case 46:
																																		goto IL_024b;
																																	case 62:
																																		goto IL_025b;
																																	case 63:
																																		goto end_IL_025b;
																																	case 36:
																																	case 80:
																																		goto end_IL_026b;
																																	case 27:
																																	case 28:
																																		goto IL_0286;
																																	case 40:
																																		goto IL_0299;
																																	case 37:
																																	case 42:
																																		goto IL_02b0;
																																	case 35:
																																		goto IL_02be;
																																	case 3:
																																	case 56:
																																		goto IL_02d7;
																																	case 70:
																																		goto IL_02f8;
																																	case 30:
																																	case 78:
																																		goto IL_0303;
																																	case 44:
																																		goto IL_032c;
																																	case 50:
																																		goto IL_033a;
																																	case 79:
																																		goto IL_0356;
																																	case 0:
																																	case 86:
																																		goto IL_0369;
																																	case 69:
																																		goto IL_0377;
																																	case 34:
																																	case 48:
																																		goto IL_0385;
																																	case 8:
																																		goto IL_03f3;
																																	case 66:
																																		goto IL_0406;
																																	case 75:
																																		goto IL_0411;
																																	case 7:
																																	case 47:
																																		goto IL_0432;
																																	case 20:
																																		goto IL_0440;
																																	case 32:
																																	case 73:
																																		goto IL_044e;
																																	case 16:
																																		goto IL_048e;
																																	case 22:
																																		goto IL_04a2;
																																	case 21:
																																	case 87:
																																		goto IL_04b5;
																																	case 1:
																																	case 2:
																																	case 4:
																																	case 6:
																																	case 9:
																																	case 10:
																																	case 13:
																																	case 19:
																																	case 23:
																																	case 24:
																																	case 49:
																																	case 53:
																																	case 60:
																																	case 61:
																																	case 65:
																																	case 71:
																																	case 74:
																																	case 81:
																																		goto end_IL_020e;
																																	case 64:
																																		goto IL_050a;
																																	case 54:
																																		goto IL_0518;
																																	case 85:
																																		goto IL_052f;
																																	case 5:
																																	case 11:
																																	case 18:
																																	case 25:
																																	case 38:
																																	case 39:
																																	case 41:
																																	case 45:
																																	case 59:
																																	case 72:
																																	case 77:
																																		goto end_IL_027b;
																																	case 51:
																																		goto end_IL_053d;
																																	case 83:
																																		goto end_IL_0550;
																																	case 57:
																																		goto end_IL_055a;
																																	case 67:
																																		goto end_IL_0565;
																																	case 43:
																																		goto end_IL_057a;
																																	case 29:
																																	case 33:
																																		goto end_IL_058f;
																																	case 84:
																																		goto end_IL_059f;
																																	case 26:
																																		goto end_IL_05af;
																																	case 15:
																																		goto end_IL_05bf;
																																	case 89:
																																		goto end_IL_05cf;
																																	case 90:
																																		goto end_IL_05da;
																																	case 55:
																																	case 88:
																																		goto IL_05f5;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto end_IL_027b;
																																continue;
																																end_IL_01a1:
																																break;
																															}
																															break;
																														}
																														continue;
																														end_IL_01cd:
																														break;
																													}
																													continue;
																													end_IL_01d9:
																													break;
																												}
																												continue;
																												end_IL_01fe:
																												break;
																											}
																											continue;
																											end_IL_020e:
																											break;
																										}
																										break;
																									}
																									goto IL_0286;
																									IL_04b5:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_027b;
																									IL_0286:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_0356;
																									IL_0356:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_04b5;
																								}
																								break;
																							}
																							goto IL_0299;
																							IL_02be:
																							if (5 > b)
																							{
																								num = 49;
																								break;
																							}
																							goto IL_02d7;
																							IL_0299:
																							if (6 <= b)
																							{
																								goto end_IL_027b;
																							}
																							num = 42;
																							goto IL_02b0;
																							IL_02d7:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 41;
																							goto end_IL_027b;
																							IL_02b0:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_02be;
																						}
																						break;
																					}
																					goto IL_02f8;
																					IL_048e:
																					array[num5 - 2] = 0;
																					goto IL_04a2;
																					IL_02f8:
																					if (4 <= b)
																					{
																						goto IL_0303;
																					}
																					goto IL_0369;
																					IL_0303:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_032c;
																					IL_032c:
																					ptr2 += 8;
																					goto IL_033a;
																					IL_033a:
																					num5--;
																					num = 72;
																					goto end_IL_027b;
																					IL_0369:
																					if (2 >= b)
																					{
																						goto IL_0377;
																					}
																					goto IL_0432;
																					IL_0377:
																					if (2 <= b)
																					{
																						goto IL_0385;
																					}
																					goto IL_0406;
																					IL_0385:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03f3;
																					IL_03f3:
																					num5 -= 2;
																					goto end_IL_027b;
																					IL_0406:
																					if (1 < b)
																					{
																						num = 2;
																						break;
																					}
																					goto IL_0411;
																					IL_0411:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_04a2:
																					num5--;
																					goto end_IL_027b;
																					IL_0432:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_0440;
																					IL_0440:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_044e;
																					IL_044e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_048e;
																				}
																				break;
																				IL_024b:;
																			}
																		}
																		else
																		{
																			num = 9;
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_050a;
																		IL_0518:
																		num5++;
																		num = 85;
																		goto IL_052f;
																		IL_052f:
																		ptr2 += 8;
																		goto end_IL_027b;
																		IL_050a:
																		array[num5] = 0;
																		goto IL_0518;
																		continue;
																		end_IL_025b:
																		break;
																	}
																	continue;
																	end_IL_026b:
																	break;
																}
																continue;
																end_IL_027b:
																break;
															}
															continue;
														}
														goto IL_05f5;
														IL_05f5:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_053d:
														break;
													}
													continue;
													end_IL_0550:
													break;
												}
												continue;
												end_IL_055a:
												break;
											}
											continue;
											end_IL_0565:
											break;
										}
										continue;
										end_IL_057a:
										break;
									}
									continue;
									end_IL_058f:
									break;
								}
								continue;
								end_IL_059f:
								break;
							}
							continue;
							end_IL_05af:
							break;
						}
						continue;
						end_IL_05bf:
						break;
					}
					continue;
					end_IL_05cf:
					break;
				}
				continue;
				end_IL_05da:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_4, int int_5)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 90;
								while (true)
								{
									array3[0] = int_4;
									num = 33;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EndNoGCRegionRemotingTimeoutException.IAssemblyRequestEntryContainsValue);
											num = 65;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_024d:
															byte b = *ptr2;
															while (true)
															{
																IL_023d:
																ptr2++;
																while (true)
																{
																	IL_022d:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_020a:
																				if (4 < b)
																				{
																					num = 68;
																					while (true)
																					{
																						IL_01fd:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (5 >= b)
																								{
																									while (true)
																									{
																										IL_01ca:
																										if (5 > b)
																										{
																											num = 99;
																											while (num != 99)
																											{
																												if (num != 1080)
																												{
																													goto end_IL_01ed;
																												}
																												switch (num)
																												{
																												case 84:
																													goto IL_01ca;
																												case 55:
																													goto IL_01dd;
																												case 26:
																													goto IL_01ed;
																												case 61:
																												case 68:
																													goto IL_01fd;
																												case 69:
																													goto IL_020a;
																												case 30:
																													goto IL_021d;
																												case 81:
																													goto IL_022d;
																												case 20:
																													goto IL_023d;
																												case 11:
																												case 15:
																													goto IL_024d;
																												case 22:
																												case 66:
																													goto IL_0258;
																												case 67:
																												case 70:
																													goto IL_0270;
																												case 42:
																													goto IL_027b;
																												case 50:
																													goto IL_0289;
																												case 10:
																												case 82:
																													goto IL_0297;
																												case 17:
																													goto IL_02bc;
																												case 14:
																												case 41:
																													goto IL_02ca;
																												case 76:
																													goto IL_02d8;
																												case 74:
																													goto IL_02fb;
																												case 32:
																													goto IL_0305;
																												case 58:
																													goto IL_0313;
																												case 85:
																													goto IL_0326;
																												case 2:
																												case 23:
																													goto IL_0334;
																												case 89:
																												case 92:
																													goto IL_0342;
																												case 9:
																													goto IL_0350;
																												case 1:
																												case 18:
																													goto IL_035e;
																												case 31:
																													goto IL_039e;
																												case 0:
																													goto IL_03b2;
																												case 75:
																													goto IL_03c5;
																												case 19:
																												case 56:
																													goto IL_03d0;
																												case 43:
																													goto IL_03de;
																												case 6:
																												case 88:
																													goto IL_03f1;
																												case 12:
																													goto IL_045f;
																												case 39:
																												case 47:
																													goto IL_0472;
																												case 24:
																													goto IL_049b;
																												case 78:
																													goto IL_04a9;
																												case 3:
																												case 8:
																												case 25:
																												case 28:
																												case 34:
																												case 38:
																												case 40:
																												case 49:
																												case 51:
																												case 52:
																												case 53:
																												case 54:
																												case 57:
																												case 59:
																												case 77:
																												case 80:
																												case 87:
																												case 91:
																													goto end_IL_01b7;
																												case 21:
																													goto IL_04dc;
																												case 62:
																													goto IL_04ea;
																												case 86:
																													goto IL_04f8;
																												case 4:
																												case 5:
																												case 16:
																												case 36:
																												case 44:
																												case 45:
																												case 46:
																												case 48:
																												case 72:
																												case 73:
																												case 79:
																													goto end_IL_01ed;
																												case 65:
																													goto end_IL_0506;
																												case 37:
																													goto end_IL_0519;
																												case 33:
																													goto end_IL_0523;
																												case 90:
																													goto end_IL_0537;
																												case 60:
																													goto end_IL_054c;
																												case 13:
																												case 71:
																													goto end_IL_056a;
																												case 7:
																													goto end_IL_0583;
																												case 35:
																												case 83:
																													goto end_IL_0593;
																												case 63:
																													goto end_IL_05a3;
																												case 64:
																													goto end_IL_05b3;
																												case 27:
																												case 29:
																													goto IL_05ce;
																												}
																												continue;
																												end_IL_01b7:
																												break;
																											}
																											break;
																										}
																										goto IL_0258;
																										IL_0258:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_01ed;
																									}
																									break;
																									IL_01dd:;
																								}
																								goto end_IL_021d;
																								continue;
																								end_IL_01ed:
																								break;
																								IL_01ed:;
																							}
																							break;
																						}
																						goto IL_0270;
																						IL_0305:
																						num5++;
																						goto IL_0313;
																						IL_0270:
																						if (7 < b)
																						{
																							goto IL_027b;
																						}
																						num = 17;
																						goto IL_02bc;
																						IL_027b:
																						if (8 < b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_0289;
																						IL_0289:
																						if (8 > b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_0297;
																						IL_0297:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_0313:
																						ptr2 += 8;
																						break;
																						IL_02bc:
																						if (7 > b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_02ca;
																						IL_02ca:
																						array[num5] = 0;
																						goto IL_02d8;
																						IL_02d8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02fb;
																						IL_02fb:
																						array2[num5] = null;
																						goto IL_0305;
																					}
																					break;
																				}
																				goto IL_0326;
																				IL_049b:
																				ptr2 += 8;
																				goto IL_04a9;
																				IL_04a9:
																				num5--;
																				break;
																				IL_0326:
																				if (4 > b)
																				{
																					goto IL_0334;
																				}
																				goto IL_0472;
																				IL_0334:
																				if (2 < b)
																				{
																					goto IL_0342;
																				}
																				goto IL_03c5;
																				IL_0342:
																				if (3 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_0350;
																				IL_0350:
																				if (3 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_035e;
																				IL_035e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_039e;
																				IL_039e:
																				array[num5 - 2] = 0;
																				goto IL_03b2;
																				IL_03b2:
																				num5--;
																				break;
																				IL_03c5:
																				if (2 > b)
																				{
																					goto IL_03d0;
																				}
																				goto IL_03f1;
																				IL_03d0:
																				if (1 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_03de;
																				IL_03de:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_021d;
																				IL_03f1:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_045f;
																				IL_045f:
																				num5 -= 2;
																				break;
																				IL_0472:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_049b;
																			}
																			goto end_IL_022d;
																			continue;
																			end_IL_021d:
																			break;
																			IL_021d:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04dc;
																	IL_04f8:
																	ptr2 += 8;
																	break;
																	IL_04ea:
																	num5++;
																	goto IL_04f8;
																	IL_04dc:
																	array[num5] = 0;
																	goto IL_04ea;
																	continue;
																	end_IL_022d:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05ce;
													IL_05ce:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0506:
													break;
												}
												continue;
												end_IL_0519:
												break;
											}
											continue;
											end_IL_0523:
											break;
										}
										continue;
										end_IL_0537:
										break;
									}
									continue;
									end_IL_054c:
									break;
								}
								continue;
								end_IL_056a:
								break;
							}
							continue;
							end_IL_0583:
							break;
						}
						continue;
						end_IL_0593:
						break;
					}
					continue;
					end_IL_05a3:
					break;
				}
				continue;
				end_IL_05b3:
				break;
			}
		}
	}

	static Class107()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0064:
				Class300.smethod_0();
				while (true)
				{
					IL_0058:
					num = 2;
					while (true)
					{
						IL_0046:
						num = 12;
						while (true)
						{
							if (num != 12)
							{
								if (num != 993)
								{
									break;
								}
								switch (num)
								{
								case 0:
								case 1:
								case 2:
									goto IL_0046;
								case 5:
									goto IL_0058;
								case 3:
									goto IL_0064;
								case 4:
									goto end_IL_0039;
								}
								continue;
							}
							return;
							continue;
							end_IL_0039:
							break;
						}
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
