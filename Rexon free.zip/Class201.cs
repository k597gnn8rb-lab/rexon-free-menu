using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Silent Hand Taps", "Rig", "Others can't hear your hand taps.", false, 39, ModType.const_0, false)]
internal class Class201 : MonoBehaviour
{
	private bool bool_0;

	private static float float_0;

	private static int int_0;

	private static int int_1;

	private static int int_2;

	private static IntPtr[] NativeCppClassAttributeLeaseState;

	private static IntPtr[] TailStreamPersist;

	private static IntPtr[] ThaiBuddhistCalendarIEnumerable;

	private unsafe void Update()
	{
		int num = 25;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						num = 231;
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FileLocationRemainder.getItemPermissionSetAttribute);
												num = 116;
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_04bd:
																	if (b >= 1)
																	{
																		while (b <= 29)
																		{
																			while (true)
																			{
																				IL_04a0:
																				if (15 < b)
																				{
																					while (true)
																					{
																						IL_048d:
																						if (22 >= b)
																						{
																							num = 234;
																							while (true)
																							{
																								IL_047d:
																								if (22 > b)
																								{
																									while (true)
																									{
																										IL_046d:
																										if (18 >= b)
																										{
																											while (true)
																											{
																												IL_045d:
																												if (18 > b)
																												{
																													while (true)
																													{
																														IL_044d:
																														if (16 < b)
																														{
																															while (17 >= b)
																															{
																																while (17 <= b)
																																{
																																	num = 251;
																																	while (true)
																																	{
																																		if (num != 251)
																																		{
																																			if (num != 1232)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 148:
																																				goto IL_042a;
																																			case 38:
																																				goto IL_043d;
																																			case 159:
																																				goto IL_044d;
																																			case 92:
																																				goto IL_045d;
																																			case 87:
																																				goto IL_046d;
																																			case 234:
																																				goto IL_047d;
																																			case 202:
																																				goto IL_048d;
																																			case 217:
																																				goto IL_04a0;
																																			case 189:
																																				goto IL_04ad;
																																			case 141:
																																				goto IL_04bd;
																																			case 157:
																																				goto end_IL_04bd;
																																			case 17:
																																			case 188:
																																				goto end_IL_04cd;
																																			case 20:
																																				goto IL_04e8;
																																			case 37:
																																			case 40:
																																				goto IL_04f6;
																																			case 54:
																																				goto IL_054d;
																																			case 80:
																																				goto IL_055b;
																																			case 89:
																																			case 102:
																																				goto IL_056e;
																																			case 70:
																																				goto IL_0582;
																																			case 34:
																																				goto IL_05c1;
																																			case 114:
																																				goto IL_05d4;
																																			case 64:
																																				goto IL_05df;
																																			case 53:
																																				goto IL_05ea;
																																			case 35:
																																				goto IL_05fd;
																																			case 71:
																																				goto IL_060b;
																																			case 39:
																																				goto IL_0619;
																																			case 121:
																																			case 132:
																																				goto IL_0630;
																																			case 3:
																																			case 135:
																																				goto IL_0651;
																																			case 51:
																																				goto IL_0691;
																																			case 112:
																																				goto IL_06ae;
																																			case 172:
																																				goto IL_06c1;
																																			case 176:
																																				goto IL_06d4;
																																			case 15:
																																			case 58:
																																				goto IL_06df;
																																			case 23:
																																				goto IL_071f;
																																			case 147:
																																				goto IL_0733;
																																			case 137:
																																				goto IL_0746;
																																			case 26:
																																				goto IL_0751;
																																			case 126:
																																				goto IL_0764;
																																			case 61:
																																				goto IL_077b;
																																			case 187:
																																				goto IL_078e;
																																			case 60:
																																			case 97:
																																				goto IL_0799;
																																			case 67:
																																				goto IL_07c2;
																																			case 168:
																																				goto IL_07d0;
																																			case 163:
																																				goto IL_07e3;
																																			case 111:
																																				goto IL_07ee;
																																			case 167:
																																				goto IL_07fc;
																																			case 9:
																																			case 160:
																																				goto IL_080a;
																																			case 179:
																																				goto IL_084f;
																																			case 18:
																																			case 158:
																																				goto IL_085d;
																																			case 133:
																																				goto IL_0876;
																																			case 139:
																																			case 190:
																																				goto IL_0886;
																																			case 140:
																																				goto IL_08b4;
																																			case 193:
																																				goto IL_08c7;
																																			case 91:
																																				goto IL_08d5;
																																			case 194:
																																				goto IL_08e8;
																																			case 13:
																																				goto IL_08f3;
																																			case 181:
																																				goto IL_0901;
																																			case 55:
																																			case 104:
																																				goto IL_090f;
																																			case 94:
																																				goto IL_093d;
																																			case 201:
																																				goto IL_095e;
																																			case 48:
																																				goto IL_096c;
																																			case 203:
																																				goto IL_097f;
																																			case 77:
																																				goto IL_098d;
																																			case 143:
																																			case 186:
																																				goto IL_099b;
																																			case 144:
																																				goto IL_09b3;
																																			case 46:
																																				goto IL_09c1;
																																			case 108:
																																				goto IL_09cf;
																																			case 205:
																																				goto IL_09e2;
																																			case 5:
																																				goto IL_09f0;
																																			case 29:
																																				goto IL_09fb;
																																			case 107:
																																			case 127:
																																				goto IL_0a09;
																																			case 100:
																																				goto IL_0a49;
																																			case 76:
																																				goto IL_0a62;
																																			case 198:
																																				goto IL_0a70;
																																			case 49:
																																			case 182:
																																				goto IL_0a7e;
																																			case 206:
																																				goto IL_0af3;
																																			case 79:
																																				goto IL_0b01;
																																			case 12:
																																			case 74:
																																				goto IL_0b0c;
																																			case 101:
																																				goto IL_0b4c;
																																			case 120:
																																				goto IL_0b60;
																																			case 4:
																																				goto IL_0b73;
																																			case 130:
																																				goto IL_0b81;
																																			case 86:
																																			case 95:
																																				goto IL_0b8f;
																																			case 166:
																																				goto IL_0b9d;
																																			case 180:
																																				goto IL_0bc0;
																																			case 68:
																																				goto IL_0bcf;
																																			case 153:
																																				goto IL_0bdd;
																																			case 209:
																																				goto IL_0bf0;
																																			case 85:
																																				goto IL_0bfe;
																																			case 19:
																																			case 56:
																																				goto IL_0c0c;
																																			case 150:
																																			case 210:
																																				goto IL_0c2a;
																																			case 220:
																																				goto IL_0c46;
																																			case 221:
																																				goto IL_0c59;
																																			case 50:
																																				goto IL_0c67;
																																			case 184:
																																			case 208:
																																				goto IL_0c75;
																																			case 191:
																																				goto IL_0cb6;
																																			case 45:
																																				goto IL_0cca;
																																			case 222:
																																				goto IL_0cdd;
																																			case 156:
																																				goto IL_0ceb;
																																			case 14:
																																			case 65:
																																				goto IL_0cf9;
																																			case 146:
																																			case 224:
																																				goto IL_0d0c;
																																			case 124:
																																				goto IL_0d43;
																																			case 225:
																																				goto IL_0d56;
																																			case 33:
																																				goto IL_0d6a;
																																			case 199:
																																			case 227:
																																				goto end_IL_0417;
																																			case 129:
																																				goto IL_0dbd;
																																			case 228:
																																				goto IL_0dd6;
																																			case 211:
																																				goto IL_0de4;
																																			case 32:
																																			case 229:
																																				goto IL_0e00;
																																			case 165:
																																				goto IL_0e14;
																																			case 98:
																																				goto IL_0e5c;
																																			case 232:
																																				goto IL_0e6f;
																																			case 136:
																																				goto IL_0e7d;
																																			case 145:
																																				goto IL_0e94;
																																			case 236:
																																				goto IL_0ea7;
																																			case 238:
																																				goto IL_0eba;
																																			case 200:
																																				goto IL_0ecd;
																																			case 134:
																																				goto IL_0ee7;
																																			case 83:
																																				goto IL_0ef5;
																																			case 185:
																																				goto IL_0f03;
																																			case 219:
																																				goto IL_0f16;
																																			case 1:
																																			case 81:
																																				goto IL_0f24;
																																			case 106:
																																				goto IL_0f32;
																																			case 226:
																																				goto IL_0f50;
																																			case 239:
																																				goto IL_0f5e;
																																			case 109:
																																				goto IL_0f71;
																																			case 69:
																																				goto IL_0f7f;
																																			case 142:
																																				goto IL_0f8d;
																																			case 125:
																																			case 192:
																																				goto IL_0f9b;
																																			case 131:
																																				goto IL_0fdb;
																																			case 151:
																																				goto IL_0fef;
																																			case 244:
																																				goto IL_1002;
																																			case 162:
																																			case 215:
																																				goto IL_100d;
																																			case 152:
																																				goto IL_1021;
																																			case 88:
																																				goto IL_1060;
																																			case 170:
																																				goto IL_1070;
																																			case 103:
																																				goto IL_107b;
																																			case 59:
																																			case 218:
																																				goto IL_1086;
																																			case 122:
																																				goto IL_109f;
																																			case 138:
																																				goto IL_10ad;
																																			case 117:
																																				goto IL_10bb;
																																			case 2:
																																			case 6:
																																			case 7:
																																			case 8:
																																			case 10:
																																			case 22:
																																			case 28:
																																			case 30:
																																			case 31:
																																			case 36:
																																			case 44:
																																			case 47:
																																			case 62:
																																			case 73:
																																			case 82:
																																			case 84:
																																			case 96:
																																			case 115:
																																			case 149:
																																			case 155:
																																			case 169:
																																			case 171:
																																			case 174:
																																			case 175:
																																			case 178:
																																			case 207:
																																			case 213:
																																			case 214:
																																			case 230:
																																			case 233:
																																			case 235:
																																			case 242:
																																				goto end_IL_042a;
																																			case 0:
																																			case 11:
																																			case 27:
																																			case 42:
																																			case 43:
																																			case 57:
																																			case 63:
																																			case 66:
																																			case 72:
																																			case 75:
																																			case 78:
																																			case 90:
																																			case 93:
																																			case 99:
																																			case 113:
																																			case 118:
																																			case 119:
																																			case 128:
																																			case 154:
																																			case 161:
																																			case 173:
																																			case 177:
																																			case 183:
																																			case 195:
																																			case 196:
																																			case 197:
																																			case 204:
																																			case 223:
																																			case 237:
																																			case 240:
																																			case 241:
																																			case 243:
																																				goto end_IL_04dd;
																																			case 116:
																																				goto end_IL_10de;
																																			case 123:
																																				goto end_IL_10f1;
																																			case 164:
																																				goto end_IL_10fb;
																																			case 110:
																																				goto end_IL_110f;
																																			case 216:
																																				goto end_IL_111f;
																																			case 21:
																																			case 212:
																																				goto end_IL_112f;
																																			case 231:
																																				goto end_IL_113f;
																																			case 105:
																																				goto end_IL_114f;
																																			case 41:
																																				goto end_IL_115f;
																																			case 24:
																																				goto end_IL_1178;
																																			case 25:
																																				goto end_IL_1188;
																																			case 16:
																																			case 52:
																																				return;
																																			}
																																			continue;
																																		}
																																		goto IL_0ecd;
																																		IL_0ef5:
																																		num6++;
																																		goto IL_0f03;
																																		IL_0f03:
																																		ptr2 += 8;
																																		goto end_IL_04dd;
																																		IL_0ecd:
																																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																																		goto IL_0ee7;
																																		IL_0ee7:
																																		array[num6] = 3;
																																		goto IL_0ef5;
																																		continue;
																																		end_IL_0417:
																																		break;
																																	}
																																	goto IL_0d7d;
																																	continue;
																																	end_IL_042a:
																																	break;
																																	IL_042a:;
																																}
																																break;
																																IL_043d:;
																															}
																															break;
																														}
																														goto IL_0f16;
																														IL_0f5e:
																														ptr2 += 8;
																														goto end_IL_04dd;
																														IL_0f16:
																														if (16 > b)
																														{
																															break;
																														}
																														goto IL_0f24;
																														IL_0f24:
																														array[num6] = 5;
																														goto IL_0f32;
																														IL_0f32:
																														array2[num6] = ((delegate*<GorillaTagger>)NativeCppClassAttributeLeaseState[*(int*)(ptr2 + num3)])();
																														goto IL_0f50;
																														IL_0f50:
																														num6++;
																														goto IL_0f5e;
																													}
																													break;
																												}
																												goto IL_0d0c;
																												IL_0d43:
																												num6 -= 2;
																												goto end_IL_04dd;
																												IL_0d0c:
																												((GorillaTagger)array2[num6 - 2]).lastLeftTap = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																												num = 124;
																												goto IL_0d43;
																											}
																											break;
																										}
																										goto IL_0f71;
																										IL_10bb:
																										ptr2 += 16;
																										goto end_IL_04dd;
																										IL_0f71:
																										if (20 < b)
																										{
																											goto IL_0f7f;
																										}
																										goto IL_1002;
																										IL_0f7f:
																										if (21 < b)
																										{
																											break;
																										}
																										goto IL_0f8d;
																										IL_0f8d:
																										if (21 > b)
																										{
																											break;
																										}
																										goto IL_0f9b;
																										IL_0f9b:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0fdb;
																										IL_0fdb:
																										array[num6 - 2] = 3;
																										goto IL_0fef;
																										IL_0fef:
																										num6--;
																										goto end_IL_04dd;
																										IL_1002:
																										if (20 <= b)
																										{
																											goto IL_100d;
																										}
																										goto IL_1070;
																										IL_100d:
																										array[num6 - 1] = 3;
																										goto IL_1021;
																										IL_1021:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)NativeCppClassAttributeLeaseState[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_1060;
																										IL_1060:
																										ptr2 += 8;
																										goto end_IL_04dd;
																										IL_1070:
																										if (19 < b)
																										{
																											break;
																										}
																										goto IL_107b;
																										IL_107b:
																										if (19 > b)
																										{
																											break;
																										}
																										goto IL_1086;
																										IL_1086:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_109f;
																										IL_109f:
																										array[num6] = 3;
																										goto IL_10ad;
																										IL_10ad:
																										num6++;
																										goto IL_10bb;
																									}
																									break;
																								}
																								goto IL_056e;
																								IL_05c1:
																								ptr2 += 8;
																								goto end_IL_04dd;
																								IL_056e:
																								array[num6 - 1] = 0;
																								goto IL_0582;
																								IL_0582:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)NativeCppClassAttributeLeaseState[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_05c1;
																							}
																							break;
																						}
																						goto IL_054d;
																						IL_077b:
																						if (25 > b)
																						{
																							break;
																						}
																						goto IL_0e00;
																						IL_0e00:
																						array[num6 - 1] = 3;
																						goto IL_0e14;
																						IL_054d:
																						if (26 < b)
																						{
																							goto IL_055b;
																						}
																						goto IL_06d4;
																						IL_055b:
																						if (28 >= b)
																						{
																							goto IL_08e8;
																						}
																						goto IL_095e;
																						IL_08e8:
																						if (28 > b)
																						{
																							goto IL_08f3;
																						}
																						num = 210;
																						goto IL_0c2a;
																						IL_08f3:
																						if (27 < b)
																						{
																							break;
																						}
																						goto IL_0901;
																						IL_0901:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_090f;
																						IL_090f:
																						((GorillaTagger)array2[num6 - 2]).lastRightTap = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_093d;
																						IL_093d:
																						num6 -= 2;
																						goto end_IL_04dd;
																						IL_0e14:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)NativeCppClassAttributeLeaseState[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						num = 98;
																						goto IL_0e5c;
																						IL_0c2a:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_04dd;
																						IL_095e:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_096c;
																						IL_096c:
																						if (29 > b)
																						{
																						}
																						break;
																						IL_06d4:
																						if (26 <= b)
																						{
																							goto IL_06df;
																						}
																						goto IL_0746;
																						IL_06df:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_071f;
																						IL_071f:
																						array[num6 - 2] = 3;
																						goto IL_0733;
																						IL_0733:
																						num6--;
																						goto end_IL_04dd;
																						IL_0746:
																						if (24 >= b)
																						{
																							goto IL_0751;
																						}
																						goto IL_0764;
																						IL_0751:
																						if (24 <= b)
																						{
																							goto IL_0886;
																						}
																						goto IL_097f;
																						IL_097f:
																						if (23 < b)
																						{
																							break;
																						}
																						goto IL_098d;
																						IL_098d:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_099b;
																						IL_099b:
																						array2[num6] = array5[*(int*)(ptr2 + num3)];
																						goto IL_09b3;
																						IL_09b3:
																						array[num6] = 5;
																						goto IL_09c1;
																						IL_09c1:
																						num6++;
																						goto IL_09cf;
																						IL_09cf:
																						ptr2 += 8;
																						goto end_IL_04dd;
																						IL_0886:
																						((Class201)array2[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																						goto IL_08b4;
																						IL_08b4:
																						num6 -= 2;
																						goto end_IL_04dd;
																						IL_0764:
																						if (25 < b)
																						{
																							break;
																						}
																						num = 61;
																						goto IL_077b;
																						IL_0e5c:
																						ptr2 += 8;
																						goto end_IL_04dd;
																					}
																					break;
																				}
																				goto IL_04e8;
																				IL_0a7e:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0eba;
																				IL_04e8:
																				if (15 <= b)
																				{
																					goto IL_04f6;
																				}
																				goto IL_05d4;
																				IL_04f6:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06c1;
																				IL_06c1:
																				num6--;
																				goto end_IL_04dd;
																				IL_05d4:
																				if (7 >= b)
																				{
																					goto IL_05df;
																				}
																				goto IL_05fd;
																				IL_05df:
																				if (7 > b)
																				{
																					goto IL_05ea;
																				}
																				goto IL_0651;
																				IL_05ea:
																				if (3 >= b)
																				{
																					goto IL_078e;
																				}
																				goto IL_0af3;
																				IL_078e:
																				if (3 <= b)
																				{
																					goto IL_0799;
																				}
																				goto IL_07e3;
																				IL_0799:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_07c2;
																				IL_07c2:
																				ptr2 += 8;
																				goto IL_07d0;
																				IL_07d0:
																				num6--;
																				goto end_IL_04dd;
																				IL_07e3:
																				if (1 < b)
																				{
																					goto IL_07ee;
																				}
																				goto IL_084f;
																				IL_07ee:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_07fc;
																				IL_07fc:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_080a;
																				IL_080a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0d56;
																				IL_0d56:
																				array[num6 - 2] = 0;
																				goto IL_0d6a;
																				IL_0d6a:
																				num6--;
																				goto end_IL_04dd;
																				IL_084f:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_085d;
																				IL_085d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0876;
																				IL_0876:
																				array[num6] = 0;
																				goto IL_08c7;
																				IL_08c7:
																				num6++;
																				goto IL_08d5;
																				IL_08d5:
																				ptr2 += 8;
																				goto end_IL_04dd;
																				IL_0af3:
																				if (5 >= b)
																				{
																					goto IL_0b01;
																				}
																				goto IL_0bcf;
																				IL_0b01:
																				if (5 <= b)
																				{
																					goto IL_0b0c;
																				}
																				goto IL_0b73;
																				IL_0b0c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0b4c;
																				IL_0b4c:
																				array[num6 - 2] = 0;
																				goto IL_0b60;
																				IL_0b60:
																				num6--;
																				goto end_IL_04dd;
																				IL_0b73:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0b81;
																				IL_0b81:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0b8f;
																				IL_0b8f:
																				array[num6] = 0;
																				goto IL_0b9d;
																				IL_0b9d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0bc0;
																				IL_0bc0:
																				array2[num6] = null;
																				goto IL_0dd6;
																				IL_0dd6:
																				num6++;
																				goto IL_0de4;
																				IL_0de4:
																				ptr2 += 8;
																				num = 240;
																				goto end_IL_04dd;
																				IL_0bcf:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0bdd;
																				IL_0bdd:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0d7d;
																				IL_0d7d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0dbd;
																				IL_0dbd:
																				array[num6 - 2] = 0;
																				goto IL_0ea7;
																				IL_0ea7:
																				num6--;
																				goto end_IL_04dd;
																				IL_0651:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0691;
																				IL_0691:
																				array[num6 - 2] = 0;
																				num = 112;
																				goto IL_06ae;
																				IL_06ae:
																				num6--;
																				goto end_IL_04dd;
																				IL_05fd:
																				if (11 < b)
																				{
																					goto IL_060b;
																				}
																				goto IL_09e2;
																				IL_060b:
																				if (13 >= b)
																				{
																					goto IL_0619;
																				}
																				goto IL_0c59;
																				IL_0619:
																				if (13 <= b)
																				{
																					num = 121;
																					goto IL_0630;
																				}
																				goto IL_0bf0;
																				IL_0eba:
																				num6 -= 2;
																				goto end_IL_04dd;
																				IL_0630:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 119;
																				goto end_IL_04dd;
																				IL_0bf0:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_0bfe;
																				IL_0bfe:
																				if (12 > b)
																				{
																					break;
																				}
																				goto IL_0c0c;
																				IL_0c0c:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0e6f;
																				IL_0e6f:
																				array[num6] = 1;
																				goto IL_0e7d;
																				IL_0e7d:
																				num6++;
																				num = 145;
																				goto IL_0e94;
																				IL_0e94:
																				ptr2 += 16;
																				goto end_IL_04dd;
																				IL_0c59:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_0c67;
																				IL_0c67:
																				if (14 > b)
																				{
																					break;
																				}
																				goto IL_0c75;
																				IL_0c75:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_0cb6;
																				IL_0cb6:
																				array[num6 - 2] = 0;
																				goto IL_0cca;
																				IL_0cca:
																				num6--;
																				goto end_IL_04dd;
																				IL_09e2:
																				if (11 <= b)
																				{
																					num = 42;
																					goto end_IL_04dd;
																				}
																				goto IL_09f0;
																				IL_09f0:
																				if (9 >= b)
																				{
																					goto IL_09fb;
																				}
																				goto IL_0a62;
																				IL_09fb:
																				if (9 <= b)
																				{
																					goto IL_0a09;
																				}
																				goto IL_0cdd;
																				IL_0a09:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0a49;
																				IL_0a49:
																				array[num6 - 2] = 0;
																				goto IL_0c46;
																				IL_0c46:
																				num6--;
																				goto end_IL_04dd;
																				IL_0cdd:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0ceb;
																				IL_0ceb:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0cf9;
																				IL_0cf9:
																				num6--;
																				goto end_IL_04dd;
																				IL_0a62:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0a70;
																				IL_0a70:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0a7e;
																			}
																			break;
																			IL_04ad:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_04dd;
																	continue;
																	end_IL_04bd:
																	break;
																}
																continue;
																end_IL_04cd:
																break;
															}
															continue;
															end_IL_04dd:
															break;
														}
														continue;
														end_IL_10de:
														break;
													}
													continue;
													end_IL_10f1:
													break;
												}
												continue;
												end_IL_10fb:
												break;
											}
											continue;
											end_IL_110f:
											break;
										}
										continue;
										end_IL_111f:
										break;
									}
									continue;
									end_IL_112f:
									break;
								}
								continue;
								end_IL_113f:
								break;
							}
							continue;
							end_IL_114f:
							break;
						}
						continue;
						end_IL_115f:
						break;
					}
					continue;
					end_IL_1178:
					break;
				}
				continue;
				end_IL_1188:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 125;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getInArgsgetInArgs.UnboxCodeAccessPermission);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_0390:
														byte b = *ptr2;
														while (true)
														{
															IL_0380:
															ptr2++;
															while (true)
															{
																IL_0370:
																if (b >= 1)
																{
																	while (b <= 22)
																	{
																		while (true)
																		{
																			IL_0350:
																			if (11 >= b)
																			{
																				while (true)
																				{
																					IL_0340:
																					if (11 <= b)
																					{
																						num = 196;
																						while (true)
																						{
																							if (num != 196)
																							{
																								if (num != 1177)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 74:
																									goto IL_0340;
																								case 100:
																									goto IL_0350;
																								case 21:
																									goto IL_0360;
																								case 73:
																									goto IL_0370;
																								case 140:
																									goto IL_0380;
																								case 162:
																								case 183:
																									goto IL_0390;
																								case 36:
																									goto IL_039b;
																								case 53:
																									goto IL_03a6;
																								case 24:
																									goto IL_03b4;
																								case 15:
																									goto IL_03bf;
																								case 4:
																									goto IL_03ca;
																								case 6:
																									goto IL_03d8;
																								case 64:
																									goto IL_03f4;
																								case 86:
																									goto IL_0407;
																								case 51:
																								case 106:
																									goto IL_041a;
																								case 111:
																									goto IL_045a;
																								case 26:
																									goto IL_046e;
																								case 94:
																								case 114:
																									goto IL_0481;
																								case 31:
																									goto IL_049a;
																								case 78:
																									goto IL_04a8;
																								case 2:
																									goto IL_04b6;
																								case 113:
																								case 137:
																									goto IL_04c9;
																								case 131:
																									goto IL_0509;
																								case 7:
																									goto IL_051d;
																								case 153:
																									goto IL_0539;
																								case 96:
																									goto IL_0550;
																								case 0:
																								case 88:
																									goto IL_055e;
																								case 70:
																									goto IL_056c;
																								case 62:
																									goto IL_058f;
																								case 151:
																									goto IL_0599;
																								case 154:
																									goto IL_05ac;
																								case 38:
																									goto IL_05b7;
																								case 81:
																								case 138:
																									goto IL_05ce;
																								case 14:
																									goto IL_060e;
																								case 9:
																									goto IL_0622;
																								case 136:
																									goto IL_0635;
																								case 110:
																									goto IL_0643;
																								case 156:
																									goto IL_0653;
																								case 146:
																								case 159:
																									goto IL_0666;
																								case 107:
																									goto IL_06c8;
																								case 169:
																									goto IL_06db;
																								case 18:
																								case 47:
																									goto IL_06e6;
																								case 148:
																									goto IL_06f9;
																								case 102:
																									goto IL_0707;
																								case 120:
																									goto IL_0715;
																								case 12:
																								case 37:
																									goto IL_0723;
																								case 129:
																									goto IL_0763;
																								case 132:
																									goto IL_0777;
																								case 175:
																									goto IL_078a;
																								case 41:
																								case 60:
																									goto IL_0798;
																								case 147:
																									goto IL_07c1;
																								case 178:
																									goto IL_07cf;
																								case 180:
																									goto IL_07e2;
																								case 91:
																								case 167:
																									goto IL_07f0;
																								case 85:
																									goto IL_0830;
																								case 134:
																									goto IL_0844;
																								case 185:
																									goto IL_0857;
																								case 149:
																									goto IL_086b;
																								case 3:
																									goto IL_08bf;
																								case 119:
																									goto IL_08cd;
																								case 79:
																									goto IL_08e0;
																								case 44:
																									goto IL_08ee;
																								case 141:
																									goto IL_08fc;
																								case 8:
																								case 170:
																									goto IL_0907;
																								case 173:
																									goto IL_0935;
																								case 145:
																									goto IL_0948;
																								case 43:
																									goto IL_0953;
																								case 54:
																								case 117:
																									goto IL_0961;
																								case 16:
																									goto IL_097b;
																								case 116:
																									goto IL_0989;
																								case 187:
																									goto IL_0997;
																								case 157:
																									goto IL_09aa;
																								case 11:
																									goto IL_09b8;
																								case 32:
																								case 57:
																									goto IL_09c6;
																								case 13:
																									goto IL_09f4;
																								case 22:
																									goto IL_0a07;
																								case 42:
																									goto IL_0a12;
																								case 72:
																									goto IL_0a20;
																								case 142:
																									goto IL_0a33;
																								case 165:
																								case 168:
																									goto IL_0a41;
																								case 150:
																									goto IL_0a66;
																								case 135:
																								case 179:
																									goto IL_0a71;
																								case 127:
																									goto IL_0a7f;
																								case 188:
																									goto IL_0a9d;
																								case 83:
																									goto IL_0aab;
																								case 121:
																									goto IL_0abe;
																								case 1:
																									goto IL_0acc;
																								case 19:
																								case 90:
																									goto IL_0ad7;
																								case 99:
																									goto IL_0b15;
																								case 40:
																									goto IL_0b29;
																								case 163:
																									goto IL_0b3c;
																								case 87:
																									goto IL_0b47;
																								case 67:
																									goto IL_0b5a;
																								case 89:
																									goto IL_0b68;
																								case 30:
																								case 172:
																									goto IL_0b76;
																								case 77:
																									goto IL_0b8e;
																								case 52:
																									goto IL_0b9c;
																								case 126:
																									goto IL_0baa;
																								case 160:
																									goto IL_0bbd;
																								case 152:
																									goto IL_0bc8;
																								case 65:
																								case 177:
																									goto IL_0bd6;
																								case 97:
																									goto IL_0c34;
																								case 189:
																									goto IL_0c44;
																								case 76:
																									goto IL_0c4f;
																								case 143:
																								case 181:
																									goto IL_0c5a;
																								case 184:
																									goto IL_0c88;
																								case 27:
																								case 34:
																								case 39:
																								case 45:
																								case 46:
																								case 49:
																								case 56:
																								case 58:
																								case 61:
																								case 68:
																								case 80:
																								case 82:
																								case 95:
																								case 98:
																								case 105:
																								case 112:
																								case 118:
																								case 123:
																								case 128:
																								case 130:
																								case 139:
																								case 144:
																								case 161:
																								case 171:
																								case 174:
																									goto end_IL_0360;
																								case 10:
																								case 17:
																								case 20:
																								case 23:
																								case 25:
																								case 28:
																								case 35:
																								case 48:
																								case 66:
																								case 69:
																								case 71:
																								case 75:
																								case 84:
																								case 93:
																								case 103:
																								case 104:
																								case 108:
																								case 115:
																								case 122:
																								case 133:
																								case 158:
																								case 164:
																								case 166:
																								case 182:
																								case 186:
																									goto end_IL_032d;
																								case 176:
																									goto end_IL_0cab;
																								case 55:
																									goto end_IL_0cbe;
																								case 50:
																									goto end_IL_0cc8;
																								case 59:
																									goto end_IL_0cd3;
																								case 101:
																									goto end_IL_0ce3;
																								case 92:
																								case 109:
																									goto end_IL_0cf3;
																								case 155:
																									goto end_IL_0d03;
																								case 5:
																								case 63:
																									goto end_IL_0d13;
																								case 124:
																									goto end_IL_0d23;
																								case 125:
																									goto end_IL_0d33;
																								case 29:
																								case 33:
																									return;
																								}
																								continue;
																							}
																							goto IL_0857;
																							IL_08bf:
																							num5--;
																							goto IL_08cd;
																							IL_08cd:
																							ptr2 += 8;
																							break;
																							IL_0857:
																							array[num5 - 2] = 0;
																							goto IL_086b;
																							IL_086b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)TailStreamPersist[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_08bf;
																							continue;
																							end_IL_032d:
																							break;
																						}
																						break;
																					}
																					goto IL_039b;
																					IL_0622:
																					num5--;
																					break;
																					IL_0635:
																					if (10 < b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_0643;
																					IL_039b:
																					if (5 >= b)
																					{
																						goto IL_03a6;
																					}
																					goto IL_03f4;
																					IL_03a6:
																					if (5 > b)
																					{
																						goto IL_03b4;
																					}
																					goto IL_04c9;
																					IL_03b4:
																					if (2 >= b)
																					{
																						goto IL_03bf;
																					}
																					goto IL_0407;
																					IL_03bf:
																					if (2 > b)
																					{
																						goto IL_03ca;
																					}
																					goto IL_041a;
																					IL_03ca:
																					if (1 < b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_03d8;
																					IL_03d8:
																					if (1 > b)
																					{
																						goto end_IL_0360;
																					}
																					num = 94;
																					goto IL_0481;
																					IL_0643:
																					if (10 > b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_0666;
																					IL_0481:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_049a;
																					IL_049a:
																					array[num5] = 0;
																					goto IL_04a8;
																					IL_04a8:
																					num5++;
																					goto IL_04b6;
																					IL_04b6:
																					ptr2 += 8;
																					break;
																					IL_041a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_045a;
																					IL_045a:
																					array[num5 - 2] = 0;
																					goto IL_046e;
																					IL_046e:
																					num5--;
																					break;
																					IL_0407:
																					if (3 < b)
																					{
																						goto IL_0539;
																					}
																					goto IL_078a;
																					IL_078a:
																					if (3 > b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_0798;
																					IL_0798:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_07c1;
																					IL_07c1:
																					ptr2 += 8;
																					goto IL_07cf;
																					IL_07cf:
																					num5--;
																					break;
																					IL_0539:
																					if (4 < b)
																					{
																						goto end_IL_0360;
																					}
																					num = 96;
																					goto IL_0550;
																					IL_0666:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_06c8;
																					IL_0550:
																					if (4 > b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_055e;
																					IL_055e:
																					array[num5] = 0;
																					goto IL_056c;
																					IL_056c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_058f;
																					IL_058f:
																					array2[num5] = null;
																					goto IL_0599;
																					IL_0599:
																					num5++;
																					goto IL_0653;
																					IL_0653:
																					ptr2 += 8;
																					break;
																					IL_04c9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0509;
																					IL_0509:
																					array[num5 - 2] = 0;
																					goto IL_051d;
																					IL_051d:
																					num5--;
																					num = 20;
																					break;
																					IL_03f4:
																					if (8 < b)
																					{
																						goto IL_05ac;
																					}
																					goto IL_06db;
																					IL_06db:
																					if (8 <= b)
																					{
																						goto IL_06e6;
																					}
																					goto IL_06f9;
																					IL_06e6:
																					num5--;
																					break;
																					IL_06f9:
																					if (6 < b)
																					{
																						goto IL_0707;
																					}
																					goto IL_07e2;
																					IL_0707:
																					if (7 < b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_0715;
																					IL_0715:
																					if (7 > b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_0723;
																					IL_0723:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0763;
																					IL_0763:
																					array[num5 - 2] = 0;
																					goto IL_0777;
																					IL_0777:
																					num5--;
																					break;
																					IL_07e2:
																					if (6 > b)
																					{
																						goto end_IL_0360;
																					}
																					goto IL_07f0;
																					IL_07f0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0830;
																					IL_0830:
																					array[num5 - 2] = 0;
																					goto IL_0844;
																					IL_0844:
																					num5--;
																					break;
																					IL_05ac:
																					if (9 >= b)
																					{
																						goto IL_05b7;
																					}
																					goto IL_0635;
																					IL_05b7:
																					if (9 > b)
																					{
																						goto end_IL_0360;
																					}
																					num = 81;
																					goto IL_05ce;
																					IL_06c8:
																					num5 -= 2;
																					break;
																					IL_05ce:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_060e;
																					IL_060e:
																					array[num5 - 2] = 0;
																					goto IL_0622;
																				}
																				break;
																			}
																			goto IL_08e0;
																			IL_0c88:
																			num5 -= 2;
																			break;
																			IL_08e0:
																			if (17 < b)
																			{
																				goto IL_08ee;
																			}
																			goto IL_0a66;
																			IL_08ee:
																			if (20 >= b)
																			{
																				goto IL_08fc;
																			}
																			goto IL_0a07;
																			IL_08fc:
																			if (20 <= b)
																			{
																				goto IL_0907;
																			}
																			goto IL_0948;
																			IL_0907:
																			((GorillaTagger)array2[num5 - 2]).lastRightTap = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0935;
																			IL_0935:
																			num5 -= 2;
																			break;
																			IL_0948:
																			if (18 >= b)
																			{
																				goto IL_0953;
																			}
																			goto IL_09aa;
																			IL_0953:
																			if (18 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0961;
																			IL_0961:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																			goto IL_097b;
																			IL_097b:
																			array[num5] = 3;
																			goto IL_0989;
																			IL_0989:
																			num5++;
																			goto IL_0997;
																			IL_0997:
																			ptr2 += 8;
																			break;
																			IL_09aa:
																			if (19 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_09b8;
																			IL_09b8:
																			if (19 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_09c6;
																			IL_09c6:
																			((GorillaTagger)array2[num5 - 2]).lastLeftTap = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_09f4;
																			IL_09f4:
																			num5 -= 2;
																			break;
																			IL_0a07:
																			if (21 < b)
																			{
																				goto IL_0a12;
																			}
																			goto IL_0a33;
																			IL_0a12:
																			if (22 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0a20;
																			IL_0a20:
																			if (22 > b)
																			{
																			}
																			goto end_IL_0360;
																			IL_0a33:
																			if (21 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0a41;
																			IL_0a41:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 69;
																			break;
																			IL_0a66:
																			if (17 <= b)
																			{
																				goto IL_0a71;
																			}
																			goto IL_0abe;
																			IL_0a71:
																			array[num5] = 5;
																			goto IL_0a7f;
																			IL_0a7f:
																			array2[num5] = ((delegate*<GorillaTagger>)TailStreamPersist[*(int*)(ptr2 + num3)])();
																			goto IL_0a9d;
																			IL_0a9d:
																			num5++;
																			goto IL_0aab;
																			IL_0aab:
																			ptr2 += 8;
																			break;
																			IL_0abe:
																			if (14 >= b)
																			{
																				goto IL_0acc;
																			}
																			goto IL_0bbd;
																			IL_0acc:
																			if (14 <= b)
																			{
																				goto IL_0ad7;
																			}
																			goto IL_0b3c;
																			IL_0ad7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<Class201, bool>)TailStreamPersist[*(int*)(ptr2 + num3)])((Class201)array2[num5 - 1]) ? 1 : 0);
																			goto IL_0b15;
																			IL_0b15:
																			array[num5 - 1] = 0;
																			goto IL_0b29;
																			IL_0b29:
																			ptr2 += 8;
																			break;
																			IL_0b3c:
																			if (12 >= b)
																			{
																				goto IL_0b47;
																			}
																			goto IL_0b5a;
																			IL_0b47:
																			if (12 > b)
																			{
																				goto end_IL_0360;
																			}
																			break;
																			IL_0b5a:
																			if (13 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0b68;
																			IL_0b68:
																			if (13 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0b76;
																			IL_0b76:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0b8e;
																			IL_0b8e:
																			array[num5] = 5;
																			goto IL_0b9c;
																			IL_0b9c:
																			num5++;
																			goto IL_0baa;
																			IL_0baa:
																			ptr2 += 8;
																			break;
																			IL_0bbd:
																			if (15 >= b)
																			{
																				goto IL_0bc8;
																			}
																			goto IL_0c44;
																			IL_0bc8:
																			if (15 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0bd6;
																			IL_0bd6:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0c34;
																			IL_0c34:
																			num5--;
																			break;
																			IL_0c44:
																			if (16 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0c4f;
																			IL_0c4f:
																			if (16 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0c5a;
																			IL_0c5a:
																			((Class201)array2[num5 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_0c88;
																		}
																		goto end_IL_0370;
																		continue;
																		end_IL_0360:
																		break;
																		IL_0360:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0370:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_0cab:
													break;
												}
												continue;
												end_IL_0cbe:
												break;
											}
											continue;
											end_IL_0cc8:
											break;
										}
										continue;
										end_IL_0cd3:
										break;
									}
									continue;
									end_IL_0ce3:
									break;
								}
								continue;
								end_IL_0cf3:
								break;
							}
							continue;
							end_IL_0d03:
							break;
						}
						continue;
						end_IL_0d13:
						break;
					}
					continue;
					end_IL_0d23:
					break;
				}
				continue;
				end_IL_0d33:
				break;
			}
		}
	}

	public Class201()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3, int int_4)
	{
		int num = 71;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 12;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											array3[1] = int_4;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NotContentIndexedFalse.ShutdowngetActivationContext);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																num = 14;
																while (true)
																{
																	ptr2++;
																	num = 113;
																	while (true)
																	{
																		if (num != 113)
																		{
																			if (num != 1094)
																			{
																				goto IL_046c;
																			}
																			switch (num)
																			{
																			case 14:
																				goto end_IL_01d3;
																			case 3:
																			case 32:
																				goto end_IL_01e3;
																			case 26:
																				goto IL_021e;
																			case 55:
																				goto IL_022c;
																			case 6:
																				goto IL_023a;
																			case 13:
																				goto IL_0248;
																			case 47:
																				goto IL_0256;
																			case 72:
																				goto IL_0264;
																			case 96:
																				goto IL_0272;
																			case 19:
																			case 50:
																				goto IL_0280;
																			case 11:
																				goto IL_02c0;
																			case 30:
																				goto IL_02d4;
																			case 100:
																				goto IL_02f0;
																			case 48:
																			case 87:
																				goto IL_02fe;
																			case 9:
																				goto IL_0327;
																			case 35:
																				goto IL_0335;
																			case 104:
																				goto IL_0348;
																			case 65:
																			case 98:
																				goto IL_0353;
																			case 0:
																				goto IL_0361;
																			case 16:
																			case 24:
																				goto IL_0374;
																			case 74:
																				goto IL_03b4;
																			case 1:
																				goto IL_03c8;
																			case 44:
																			case 94:
																				goto IL_03db;
																			case 25:
																				goto IL_03e9;
																			case 88:
																				goto IL_040c;
																			case 37:
																				goto IL_0416;
																			case 93:
																				goto IL_0424;
																			case 86:
																				goto IL_0437;
																			case 4:
																			case 41:
																				goto IL_0445;
																			case 7:
																			case 23:
																				goto IL_0450;
																			case 68:
																				goto IL_045e;
																			case 34:
																			case 92:
																				goto IL_046c;
																			case 82:
																				goto IL_0491;
																			case 60:
																			case 102:
																				goto IL_049f;
																			case 56:
																				goto IL_04df;
																			case 43:
																				goto IL_04f3;
																			case 97:
																				goto IL_0506;
																			case 45:
																			case 103:
																				goto IL_051d;
																			case 75:
																				goto IL_0528;
																			case 21:
																			case 90:
																				goto IL_0533;
																			case 10:
																				goto IL_0573;
																			case 80:
																				goto IL_0587;
																			case 15:
																			case 17:
																			case 28:
																			case 31:
																			case 36:
																			case 42:
																			case 46:
																			case 53:
																			case 54:
																			case 59:
																			case 61:
																			case 64:
																			case 73:
																			case 78:
																			case 79:
																			case 81:
																			case 83:
																			case 84:
																			case 85:
																			case 91:
																				goto IL_059a;
																			case 52:
																				goto IL_05bd;
																			case 27:
																				goto IL_05cb;
																			case 95:
																				goto IL_05d9;
																			case 67:
																			case 105:
																				goto IL_05f2;
																			case 66:
																				goto IL_060b;
																			case 106:
																				goto IL_0619;
																			case 29:
																				goto IL_0627;
																			case 2:
																			case 5:
																			case 8:
																			case 18:
																			case 38:
																			case 39:
																			case 40:
																			case 49:
																			case 57:
																			case 76:
																			case 77:
																				goto end_IL_01fc;
																			case 33:
																				goto end_IL_0635;
																			case 22:
																				goto end_IL_0648;
																			case 51:
																				goto end_IL_0652;
																			case 101:
																				goto end_IL_065d;
																			case 63:
																				goto end_IL_0672;
																			case 69:
																			case 99:
																				goto end_IL_0687;
																			case 20:
																				goto end_IL_0697;
																			case 12:
																				goto end_IL_06a7;
																			case 89:
																				goto end_IL_06b7;
																			case 70:
																				goto end_IL_06c7;
																			case 71:
																				goto end_IL_06d2;
																			case 58:
																			case 62:
																				goto IL_06ed;
																			}
																			continue;
																		}
																		if (b >= 1)
																		{
																			goto IL_021e;
																		}
																		goto IL_059a;
																		IL_0627:
																		ptr2 += 8;
																		goto end_IL_01fc;
																		IL_05bd:
																		array[num5] = 0;
																		goto IL_05cb;
																		IL_059a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05bd;
																		IL_021e:
																		if (b <= 9)
																		{
																			goto IL_022c;
																		}
																		goto IL_059a;
																		IL_022c:
																		if (5 >= b)
																		{
																			goto IL_023a;
																		}
																		goto IL_0437;
																		IL_023a:
																		if (5 > b)
																		{
																			goto IL_0248;
																		}
																		goto IL_03db;
																		IL_0248:
																		if (2 < b)
																		{
																			goto IL_0256;
																		}
																		goto IL_0348;
																		IL_0256:
																		if (3 < b)
																		{
																			goto IL_0264;
																		}
																		num = 100;
																		goto IL_02f0;
																		IL_0264:
																		if (4 >= b)
																		{
																			goto IL_0272;
																		}
																		goto IL_059a;
																		IL_0272:
																		if (4 <= b)
																		{
																			goto IL_0280;
																		}
																		goto IL_059a;
																		IL_0280:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_02c0;
																		IL_02c0:
																		array[num5 - 2] = 0;
																		goto IL_02d4;
																		IL_02d4:
																		num5--;
																		goto end_IL_01fc;
																		IL_05cb:
																		num5++;
																		goto IL_05d9;
																		IL_02f0:
																		if (3 <= b)
																		{
																			goto IL_02fe;
																		}
																		goto IL_059a;
																		IL_02fe:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0327;
																		IL_0327:
																		ptr2 += 8;
																		goto IL_0335;
																		IL_0335:
																		num5--;
																		goto end_IL_01fc;
																		IL_0348:
																		if (2 > b)
																		{
																			goto IL_0353;
																		}
																		goto IL_0374;
																		IL_0353:
																		if (1 >= b)
																		{
																			goto IL_0361;
																		}
																		goto IL_059a;
																		IL_0361:
																		if (1 <= b)
																		{
																		}
																		goto IL_059a;
																		IL_0374:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_03b4;
																		IL_03b4:
																		array[num5 - 2] = 0;
																		goto IL_03c8;
																		IL_03c8:
																		num5--;
																		goto end_IL_01fc;
																		IL_03db:
																		array[num5] = 0;
																		goto IL_03e9;
																		IL_03e9:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_040c;
																		IL_040c:
																		array2[num5] = null;
																		goto IL_0416;
																		IL_0416:
																		num5++;
																		goto IL_0424;
																		IL_0424:
																		ptr2 += 8;
																		goto end_IL_01fc;
																		IL_0437:
																		if (7 < b)
																		{
																			goto IL_0445;
																		}
																		goto IL_0506;
																		IL_0445:
																		if (8 < b)
																		{
																			goto IL_0450;
																		}
																		goto IL_0491;
																		IL_0450:
																		if (9 >= b)
																		{
																			goto IL_045e;
																		}
																		goto IL_059a;
																		IL_045e:
																		if (9 <= b)
																		{
																			goto IL_046c;
																		}
																		goto IL_059a;
																		IL_046c:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		num = 18;
																		goto end_IL_01fc;
																		IL_0491:
																		if (8 <= b)
																		{
																			goto IL_049f;
																		}
																		goto IL_059a;
																		IL_049f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_04df;
																		IL_04df:
																		array[num5 - 2] = 0;
																		goto IL_04f3;
																		IL_04f3:
																		num5--;
																		goto end_IL_01fc;
																		IL_0506:
																		if (7 > b)
																		{
																			num = 103;
																			goto IL_051d;
																		}
																		goto IL_05f2;
																		IL_05d9:
																		ptr2 += 8;
																		num = 76;
																		goto end_IL_01fc;
																		IL_051d:
																		if (6 >= b)
																		{
																			goto IL_0528;
																		}
																		goto IL_059a;
																		IL_0528:
																		if (6 <= b)
																		{
																			goto IL_0533;
																		}
																		goto IL_059a;
																		IL_0533:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0573;
																		IL_0573:
																		array[num5 - 2] = 0;
																		goto IL_0587;
																		IL_0587:
																		num5--;
																		goto end_IL_01fc;
																		IL_05f2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		goto IL_060b;
																		IL_060b:
																		array[num5] = 0;
																		goto IL_0619;
																		IL_0619:
																		num5++;
																		goto IL_0627;
																		continue;
																		end_IL_01d3:
																		break;
																	}
																	continue;
																	end_IL_01e3:
																	break;
																}
																continue;
																end_IL_01fc:
																break;
															}
															continue;
														}
														goto IL_06ed;
														IL_06ed:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0635:
														break;
													}
													continue;
													end_IL_0648:
													break;
												}
												continue;
												end_IL_0652:
												break;
											}
											continue;
											end_IL_065d:
											break;
										}
										continue;
										end_IL_0672:
										break;
									}
									continue;
									end_IL_0687:
									break;
								}
								continue;
								end_IL_0697:
								break;
							}
							continue;
							end_IL_06a7:
							break;
						}
						continue;
						end_IL_06b7:
						break;
					}
					continue;
					end_IL_06c7:
					break;
				}
				continue;
				end_IL_06d2:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 54;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_0919:
					byte[] array = new byte[4];
					while (true)
					{
						IL_0909:
						object[] array2 = new object[4];
						while (true)
						{
							IL_08f0:
							int[] array3 = new int[2];
							num = 40;
							while (true)
							{
								IL_08e0:
								long[] array4 = new long[4];
								while (true)
								{
									IL_08c7:
									object[] array5 = new object[1];
									num = 60;
									while (true)
									{
										IL_08bc:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EtwEnableCallbacksetMonthGenitiveNames.CreateFlagsIsSerializable);
										while (true)
										{
											IL_08b2:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_089f:
												if (num4 != 1)
												{
													while (true)
													{
														IL_0311:
														byte b = *ptr2;
														while (true)
														{
															IL_0301:
															ptr2++;
															while (true)
															{
																IL_02f1:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02d4:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02c4:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02b7:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02a7:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_0297:
																											if (10 > b)
																											{
																												while (9 >= b)
																												{
																													num = 149;
																													while (true)
																													{
																														if (num != 149)
																														{
																															if (num != 1130)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 9:
																																goto IL_0284;
																															case 101:
																																goto IL_0297;
																															case 74:
																																goto IL_02a7;
																															case 116:
																																goto IL_02b7;
																															case 109:
																																goto IL_02c4;
																															case 129:
																																goto IL_02d4;
																															case 141:
																																goto IL_02e1;
																															case 122:
																																goto IL_02f1;
																															case 117:
																																goto IL_0301;
																															case 16:
																															case 96:
																																goto IL_0311;
																															case 29:
																																goto IL_031c;
																															case 12:
																															case 55:
																																goto IL_032c;
																															case 31:
																																goto IL_036c;
																															case 38:
																																goto IL_0380;
																															case 103:
																																goto IL_0393;
																															case 19:
																															case 99:
																																goto IL_039e;
																															case 59:
																																goto IL_03ac;
																															case 83:
																																goto IL_03ba;
																															case 6:
																															case 18:
																																goto IL_03c8;
																															case 87:
																																goto IL_03f1;
																															case 84:
																																goto IL_03ff;
																															case 71:
																																goto IL_0412;
																															case 36:
																																goto IL_0420;
																															case 41:
																															case 66:
																																goto IL_042b;
																															case 102:
																																goto IL_0439;
																															case 70:
																															case 85:
																																goto IL_0447;
																															case 82:
																																goto IL_0470;
																															case 13:
																																goto IL_0489;
																															case 30:
																															case 65:
																																goto IL_0497;
																															case 95:
																																goto IL_04a5;
																															case 46:
																															case 52:
																																goto IL_04b3;
																															case 75:
																																goto IL_04cc;
																															case 45:
																																goto IL_04e3;
																															case 17:
																																goto IL_04f1;
																															case 5:
																															case 110:
																																goto IL_0504;
																															case 106:
																																goto IL_0522;
																															case 93:
																															case 112:
																																goto IL_053e;
																															case 135:
																																goto IL_055f;
																															case 8:
																															case 37:
																																goto IL_056a;
																															case 39:
																																goto IL_0578;
																															case 68:
																															case 127:
																																goto IL_0586;
																															case 15:
																																goto IL_0594;
																															case 2:
																																goto IL_05b5;
																															case 89:
																																goto IL_05c3;
																															case 25:
																															case 118:
																																goto IL_05d6;
																															case 111:
																																goto IL_0615;
																															case 137:
																																goto IL_0631;
																															case 128:
																															case 142:
																																goto IL_0644;
																															case 140:
																																goto IL_0684;
																															case 114:
																																goto IL_06a1;
																															case 80:
																															case 104:
																																goto IL_06c7;
																															case 134:
																																goto IL_06d5;
																															case 79:
																																goto IL_0701;
																															case 21:
																																goto IL_070b;
																															case 7:
																																goto IL_0719;
																															case 90:
																															case 132:
																																goto IL_072c;
																															case 73:
																																goto IL_073a;
																															case 81:
																															case 107:
																																goto IL_0748;
																															case 35:
																																goto IL_078c;
																															case 121:
																																goto IL_07a0;
																															case 136:
																																goto IL_07b3;
																															case 115:
																																goto IL_07c1;
																															case 32:
																															case 47:
																																goto IL_07cc;
																															case 34:
																																goto IL_07e8;
																															case 23:
																																goto IL_07f6;
																															case 88:
																															case 125:
																																goto IL_0804;
																															case 3:
																																goto IL_0866;
																															case 94:
																																goto IL_0876;
																															case 78:
																																goto IL_0881;
																															case 1:
																															case 4:
																															case 10:
																															case 11:
																															case 14:
																															case 22:
																															case 28:
																															case 43:
																															case 49:
																															case 51:
																															case 56:
																															case 57:
																															case 58:
																															case 61:
																															case 62:
																															case 64:
																															case 69:
																															case 98:
																															case 100:
																															case 108:
																															case 113:
																															case 119:
																															case 120:
																															case 133:
																																goto end_IL_0284;
																															case 0:
																															case 20:
																															case 26:
																															case 27:
																															case 33:
																															case 44:
																															case 48:
																															case 50:
																															case 67:
																															case 77:
																															case 91:
																															case 92:
																															case 105:
																															case 124:
																															case 126:
																															case 130:
																															case 138:
																															case 139:
																																goto IL_089f;
																															case 86:
																																goto IL_08b2;
																															case 60:
																																goto IL_08bc;
																															case 72:
																																goto IL_08c7;
																															case 40:
																																goto IL_08e0;
																															case 97:
																															case 123:
																																goto IL_08f0;
																															case 76:
																																goto IL_0909;
																															case 24:
																															case 63:
																																goto IL_0919;
																															case 53:
																																goto end_IL_0271;
																															case 54:
																																goto end_IL_0929;
																															case 42:
																															case 131:
																																goto IL_0944;
																															}
																															continue;
																														}
																														if (9 > b)
																														{
																															goto end_IL_0284;
																														}
																														goto IL_089f;
																														continue;
																														end_IL_0271:
																														break;
																													}
																													goto end_IL_02f1;
																													continue;
																													end_IL_0284:
																													break;
																													IL_0284:;
																												}
																												break;
																											}
																											goto IL_06c7;
																											IL_0719:
																											ptr2 += 8;
																											goto IL_089f;
																											IL_06c7:
																											array[num5] = 0;
																											goto IL_06d5;
																											IL_06d5:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											num = 79;
																											goto IL_0701;
																											IL_0701:
																											array2[num5] = null;
																											goto IL_070b;
																											IL_070b:
																											num5++;
																											goto IL_0719;
																										}
																										break;
																									}
																									goto IL_072c;
																									IL_07a0:
																									num5--;
																									goto IL_089f;
																									IL_072c:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_073a;
																									IL_073a:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_0748;
																									IL_0748:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_078c;
																									IL_078c:
																									array[num5 - 2] = 0;
																									goto IL_07a0;
																								}
																								break;
																							}
																							goto IL_032c;
																							IL_0380:
																							num5--;
																							goto IL_089f;
																							IL_032c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_036c;
																							IL_036c:
																							array[num5 - 2] = 0;
																							goto IL_0380;
																						}
																						break;
																					}
																					goto IL_07b3;
																					IL_0881:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_07b3:
																					if (14 >= b)
																					{
																						goto IL_07c1;
																					}
																					goto IL_0876;
																					IL_07c1:
																					if (14 <= b)
																					{
																						goto IL_07cc;
																					}
																					goto IL_07e8;
																					IL_07cc:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_089f;
																					IL_07e8:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_07f6;
																					IL_07f6:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0804;
																					IL_0804:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0866;
																					IL_0866:
																					num5 -= 2;
																					goto IL_089f;
																					IL_0876:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_0881;
																				}
																				break;
																			}
																			goto IL_031c;
																			IL_053e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 48;
																			goto IL_089f;
																			IL_031c:
																			if (8 > b)
																			{
																				goto IL_0393;
																			}
																			goto IL_053e;
																			IL_0393:
																			if (4 < b)
																			{
																				goto IL_039e;
																			}
																			goto IL_0412;
																			IL_039e:
																			if (6 < b)
																			{
																				goto IL_03ac;
																			}
																			goto IL_055f;
																			IL_03ac:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_03ba;
																			IL_03ba:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_03c8;
																			IL_03c8:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03f1;
																			IL_03f1:
																			ptr2 += 8;
																			goto IL_03ff;
																			IL_03ff:
																			num5--;
																			goto IL_089f;
																			IL_055f:
																			if (6 > b)
																			{
																				goto IL_056a;
																			}
																			goto IL_05d6;
																			IL_056a:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0578;
																			IL_0578:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0586;
																			IL_0586:
																			array[num5] = 5;
																			goto IL_0594;
																			IL_0594:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			num = 2;
																			goto IL_05b5;
																			IL_05b5:
																			num5++;
																			goto IL_05c3;
																			IL_05c3:
																			ptr2 += 8;
																			goto IL_089f;
																			IL_05d6:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0615;
																			IL_0615:
																			num5 -= 3;
																			num = 44;
																			goto IL_089f;
																			IL_0412:
																			if (4 > b)
																			{
																				goto IL_0420;
																			}
																			goto IL_0504;
																			IL_0420:
																			if (2 < b)
																			{
																				goto IL_042b;
																			}
																			goto IL_0489;
																			IL_042b:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0439;
																			IL_0439:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0447;
																			IL_0447:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0470;
																			IL_0470:
																			array[num5 - 1] = 5;
																			goto IL_089f;
																			IL_0489:
																			if (2 > b)
																			{
																				goto IL_0497;
																			}
																			goto IL_0644;
																			IL_0497:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04a5;
																			IL_04a5:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04b3;
																			IL_04b3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04cc;
																			IL_04cc:
																			array[num5] = 0;
																			num = 45;
																			goto IL_04e3;
																			IL_04e3:
																			num5++;
																			goto IL_04f1;
																			IL_04f1:
																			ptr2 += 8;
																			goto IL_089f;
																			IL_0644:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0684;
																			IL_0684:
																			array[num5 - 2] = 0;
																			num = 114;
																			goto IL_06a1;
																			IL_06a1:
																			num5--;
																			goto IL_089f;
																			IL_0504:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0522;
																			IL_0522:
																			ptr2 += 8;
																			num = 137;
																			goto IL_0631;
																			IL_0631:
																			num5--;
																			goto IL_089f;
																		}
																		break;
																		IL_02e1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_089f;
																continue;
																end_IL_02f1:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0944;
												IL_0944:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_0929:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3)
	{
		int num = 17;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 42;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UniversalTimeBindableVectorToListAdapter.getDisplayNameSTORECATEGORY);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_028f:
																	if (b >= 1)
																	{
																		num = 39;
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_026f:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0262:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0252:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_023f:
																										if (3 > b)
																										{
																											num = 29;
																											while (true)
																											{
																												IL_022f:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														num = 116;
																														while (true)
																														{
																															if (num != 116)
																															{
																																if (num != 1097)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 82:
																																	goto IL_021c;
																																case 29:
																																case 80:
																																	goto IL_022f;
																																case 4:
																																	goto IL_023f;
																																case 88:
																																	goto IL_0252;
																																case 85:
																																	goto IL_0262;
																																case 84:
																																	goto IL_026f;
																																case 39:
																																	goto IL_027f;
																																case 92:
																																	goto IL_028f;
																																case 75:
																																	goto end_IL_028f;
																																case 56:
																																case 71:
																																	goto end_IL_02a2;
																																case 7:
																																case 23:
																																	goto IL_02bd;
																																case 38:
																																	goto IL_02fd;
																																case 19:
																																	goto IL_0311;
																																case 43:
																																	goto IL_0324;
																																case 10:
																																case 58:
																																	goto IL_0332;
																																case 14:
																																	goto IL_034b;
																																case 6:
																																	goto IL_0359;
																																case 52:
																																	goto IL_0367;
																																case 50:
																																case 94:
																																	goto IL_0388;
																																case 59:
																																	goto IL_03b1;
																																case 44:
																																	goto IL_03bf;
																																case 46:
																																case 76:
																																	goto IL_03d2;
																																case 18:
																																	goto IL_03ea;
																																case 68:
																																	goto IL_03f5;
																																case 87:
																																	goto IL_0408;
																																case 25:
																																	goto IL_0416;
																																case 47:
																																case 64:
																																	goto IL_0424;
																																case 81:
																																	goto IL_0432;
																																case 83:
																																	goto IL_0455;
																																case 0:
																																	goto IL_045f;
																																case 22:
																																	goto IL_046d;
																																case 70:
																																	goto IL_0480;
																																case 36:
																																case 74:
																																	goto IL_048b;
																																case 13:
																																	goto IL_0496;
																																case 15:
																																case 41:
																																	goto IL_04a4;
																																case 66:
																																	goto IL_04c0;
																																case 55:
																																	goto IL_04ce;
																																case 78:
																																	goto IL_04e1;
																																case 20:
																																case 35:
																																	goto IL_04ef;
																																case 37:
																																case 51:
																																	goto IL_04fa;
																																case 53:
																																	goto IL_0508;
																																case 30:
																																case 48:
																																	goto IL_0516;
																																case 3:
																																	goto IL_0539;
																																case 33:
																																	goto IL_0550;
																																case 79:
																																	goto end_IL_0209;
																																case 2:
																																	goto IL_0571;
																																case 12:
																																case 95:
																																	goto IL_057f;
																																case 109:
																																	goto IL_05bf;
																																case 100:
																																	goto IL_05d3;
																																case 21:
																																case 63:
																																	goto IL_05e6;
																																case 45:
																																	goto IL_0648;
																																case 1:
																																case 8:
																																case 9:
																																case 27:
																																case 28:
																																case 34:
																																case 40:
																																case 65:
																																case 67:
																																case 73:
																																case 90:
																																case 91:
																																case 98:
																																case 101:
																																case 102:
																																case 103:
																																case 105:
																																case 106:
																																	goto end_IL_021c;
																																case 11:
																																case 24:
																																case 31:
																																case 32:
																																case 49:
																																case 62:
																																case 72:
																																case 77:
																																case 86:
																																case 93:
																																case 96:
																																case 97:
																																case 99:
																																case 108:
																																	goto end_IL_02b2;
																																case 107:
																																	goto end_IL_066b;
																																case 60:
																																	goto end_IL_067e;
																																case 54:
																																	goto end_IL_0688;
																																case 26:
																																	goto end_IL_0693;
																																case 69:
																																case 89:
																																	goto end_IL_06a8;
																																case 61:
																																	goto end_IL_06b8;
																																case 42:
																																	goto end_IL_06c8;
																																case 5:
																																	goto end_IL_06d8;
																																case 16:
																																	goto end_IL_06e8;
																																case 17:
																																	goto end_IL_06f3;
																																case 57:
																																case 104:
																																	goto IL_070e;
																																}
																																continue;
																															}
																															if (2 > b)
																															{
																																goto end_IL_021c;
																															}
																															goto IL_0388;
																															IL_0388:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_03b1;
																															IL_03bf:
																															num5--;
																															goto end_IL_02b2;
																															IL_03b1:
																															ptr2 += 8;
																															goto IL_03bf;
																															continue;
																															end_IL_0209:
																															break;
																														}
																														goto IL_055e;
																														continue;
																														end_IL_021c:
																														break;
																														IL_021c:;
																													}
																													break;
																												}
																												goto IL_0324;
																												IL_0367:
																												ptr2 += 8;
																												goto end_IL_02b2;
																												IL_0324:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_0332;
																												IL_0332:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_034b;
																												IL_034b:
																												array[num5] = 0;
																												goto IL_0359;
																												IL_0359:
																												num5++;
																												goto IL_0367;
																											}
																											break;
																										}
																										goto IL_03d2;
																										IL_03d2:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02b2;
																									}
																									break;
																								}
																								goto IL_03ea;
																								IL_046d:
																								ptr2 += 8;
																								goto end_IL_02b2;
																								IL_03ea:
																								if (4 >= b)
																								{
																									goto IL_03f5;
																								}
																								goto IL_0408;
																								IL_03f5:
																								if (4 > b)
																								{
																									break;
																								}
																								goto end_IL_02b2;
																								IL_0408:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_0416;
																								IL_0416:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_0424;
																								IL_0424:
																								array[num5] = 0;
																								goto IL_0432;
																								IL_0432:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0455;
																								IL_0455:
																								array2[num5] = null;
																								goto IL_045f;
																								IL_045f:
																								num5++;
																								goto IL_046d;
																							}
																							break;
																						}
																						goto IL_02bd;
																						IL_0311:
																						num5--;
																						goto end_IL_02b2;
																						IL_02bd:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02fd;
																						IL_02fd:
																						array[num5 - 2] = 0;
																						goto IL_0311;
																					}
																					break;
																				}
																				goto IL_0480;
																				IL_0648:
																				num5 -= 2;
																				goto end_IL_02b2;
																				IL_0480:
																				if (9 < b)
																				{
																					goto IL_048b;
																				}
																				goto IL_04e1;
																				IL_048b:
																				if (10 >= b)
																				{
																					goto IL_0496;
																				}
																				goto IL_04c0;
																				IL_0496:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_04a4;
																				IL_04a4:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02b2;
																				IL_04c0:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_04ce;
																				IL_04ce:
																				if (11 > b)
																				{
																				}
																				break;
																				IL_04e1:
																				if (9 > b)
																				{
																					goto IL_04ef;
																				}
																				goto IL_05e6;
																				IL_04ef:
																				if (7 < b)
																				{
																					goto IL_04fa;
																				}
																				goto IL_0571;
																				IL_04fa:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0508;
																				IL_0508:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0516;
																				IL_0516:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0539;
																				IL_0539:
																				array[num5] = 0;
																				num = 33;
																				goto IL_0550;
																				IL_0550:
																				num5++;
																				goto IL_055e;
																				IL_055e:
																				ptr2 += 8;
																				goto end_IL_02b2;
																				IL_0571:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_057f;
																				IL_057f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05bf;
																				IL_05bf:
																				array[num5 - 2] = 0;
																				goto IL_05d3;
																				IL_05d3:
																				num5--;
																				goto end_IL_02b2;
																				IL_05e6:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0648;
																			}
																			break;
																			IL_027f:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02b2;
																	continue;
																	end_IL_028f:
																	break;
																}
																continue;
																end_IL_02a2:
																break;
															}
															continue;
															end_IL_02b2:
															break;
														}
														continue;
													}
													goto IL_070e;
													IL_070e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_066b:
													break;
												}
												continue;
												end_IL_067e:
												break;
											}
											continue;
											end_IL_0688:
											break;
										}
										continue;
										end_IL_0693:
										break;
									}
									continue;
									end_IL_06a8:
									break;
								}
								continue;
								end_IL_06b8:
								break;
							}
							continue;
							end_IL_06c8:
							break;
						}
						continue;
						end_IL_06d8:
						break;
					}
					continue;
					end_IL_06e8:
					break;
				}
				continue;
				end_IL_06f3:
				break;
			}
		}
	}

	private static int smethod_3(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_3;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_4(int int_3, int int_4)
	{
		int num = 95;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 107;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											array3[1] = int_4;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetSizeArrayMuiResourceMapEntryFieldId.EnvoyTerminatorSinkIAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGIGNOREVERSION);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_03ec:
																byte b = *ptr2;
																while (true)
																{
																	IL_03dc:
																	ptr2++;
																	while (true)
																	{
																		IL_03cf:
																		if (b >= 1)
																		{
																			num = 47;
																			goto IL_0254;
																		}
																		goto IL_0399;
																		IL_044b:
																		num5--;
																		break;
																		IL_0399:
																		while (true)
																		{
																			IL_0399_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			while (true)
																			{
																				IL_0244:
																				array[num5] = 0;
																				while (true)
																				{
																					IL_022b:
																					num5++;
																					num = 30;
																					while (true)
																					{
																						IL_0212:
																						ptr2 += 8;
																						num = 124;
																						while (num != 124)
																						{
																							if (num != 1105)
																							{
																								goto IL_0489;
																							}
																							switch (num)
																							{
																							case 30:
																								goto IL_0212;
																							case 103:
																								goto IL_022b;
																							case 78:
																								goto IL_0244;
																							case 47:
																								goto IL_0254;
																							case 89:
																								goto IL_0262;
																							case 80:
																							case 81:
																								goto IL_026d;
																							case 11:
																								goto IL_0278;
																							case 2:
																								goto IL_0286;
																							case 60:
																								goto IL_0299;
																							case 28:
																								goto IL_02a7;
																							case 48:
																								goto IL_02b5;
																							case 73:
																								goto IL_02c8;
																							case 45:
																								goto IL_02d6;
																							case 15:
																								goto IL_02e1;
																							case 51:
																								goto IL_02ef;
																							case 85:
																								goto IL_02fa;
																							case 31:
																								goto IL_030d;
																							case 5:
																								goto IL_031a;
																							case 57:
																								goto IL_0325;
																							case 77:
																							case 100:
																								goto IL_0335;
																							case 61:
																								goto IL_0340;
																							case 109:
																								goto IL_0350;
																							case 25:
																							case 113:
																								goto IL_0360;
																							case 92:
																								goto IL_036b;
																							case 115:
																								goto IL_037b;
																							case 117:
																								goto IL_038b;
																							case 7:
																							case 8:
																							case 9:
																							case 33:
																							case 35:
																							case 41:
																							case 42:
																							case 43:
																							case 53:
																							case 56:
																							case 58:
																							case 63:
																							case 64:
																							case 65:
																							case 66:
																							case 76:
																							case 86:
																							case 96:
																							case 99:
																							case 101:
																								goto IL_0399_2;
																							case 91:
																								goto IL_03cf;
																							case 26:
																								goto IL_03dc;
																							case 68:
																							case 84:
																								goto IL_03ec;
																							case 27:
																							case 74:
																								goto IL_03f7;
																							case 23:
																								goto IL_0437;
																							case 24:
																								goto IL_044b;
																							case 3:
																							case 38:
																								goto IL_045e;
																							case 40:
																							case 90:
																								goto IL_0489;
																							case 97:
																								goto IL_049d;
																							case 98:
																								goto IL_04de;
																							case 79:
																							case 93:
																								goto IL_04ee;
																							case 44:
																								goto IL_052e;
																							case 20:
																								goto IL_0542;
																							case 105:
																								goto IL_0555;
																							case 106:
																								goto IL_0568;
																							case 13:
																							case 16:
																								goto IL_057b;
																							case 108:
																							case 110:
																								goto IL_058e;
																							case 70:
																								goto IL_05ce;
																							case 75:
																								goto IL_05eb;
																							case 6:
																							case 111:
																								goto IL_05fe;
																							case 4:
																							case 14:
																								goto IL_061a;
																							case 18:
																								goto IL_0628;
																							case 37:
																								goto IL_064b;
																							case 22:
																								goto IL_0655;
																							case 67:
																								goto IL_0663;
																							case 1:
																							case 69:
																								goto IL_067f;
																							case 114:
																								goto IL_06bf;
																							case 62:
																								goto IL_06d3;
																							case 34:
																							case 54:
																								goto IL_06e3;
																							case 55:
																								goto IL_06fc;
																							case 46:
																								goto IL_070a;
																							case 0:
																								goto IL_0718;
																							case 12:
																							case 19:
																							case 21:
																							case 32:
																							case 39:
																							case 49:
																							case 52:
																							case 71:
																							case 72:
																							case 88:
																							case 102:
																							case 116:
																								goto end_IL_01ff;
																							case 83:
																								goto end_IL_0726;
																							case 36:
																								goto end_IL_0739;
																							case 87:
																								goto end_IL_0743;
																							case 59:
																								goto end_IL_074e;
																							case 50:
																								goto end_IL_0763;
																							case 107:
																								goto end_IL_0778;
																							case 104:
																								goto end_IL_0788;
																							case 17:
																								goto end_IL_0798;
																							case 10:
																							case 29:
																								goto end_IL_07a3;
																							case 94:
																								goto end_IL_07b3;
																							case 95:
																								goto end_IL_07c3;
																							case 82:
																							case 112:
																								goto IL_07de;
																							}
																							continue;
																							end_IL_01ff:
																							break;
																						}
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																		IL_0254:
																		if (b <= 11)
																		{
																			goto IL_0262;
																		}
																		goto IL_0399;
																		IL_0262:
																		if (6 < b)
																		{
																			goto IL_026d;
																		}
																		goto IL_02c8;
																		IL_026d:
																		if (9 >= b)
																		{
																			goto IL_0278;
																		}
																		goto IL_0299;
																		IL_0278:
																		if (9 > b)
																		{
																			goto IL_0286;
																		}
																		goto IL_0489;
																		IL_0286:
																		if (7 < b)
																		{
																			goto IL_0335;
																		}
																		goto IL_038b;
																		IL_0335:
																		if (8 >= b)
																		{
																			goto IL_0340;
																		}
																		goto IL_0399;
																		IL_0340:
																		if (8 > b)
																		{
																			goto IL_0399;
																		}
																		goto IL_04ee;
																		IL_04ee:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_052e;
																		IL_052e:
																		array[num5 - 2] = 0;
																		goto IL_0542;
																		IL_0542:
																		num5--;
																		break;
																		IL_038b:
																		if (7 > b)
																		{
																			goto IL_0399;
																		}
																		goto IL_06e3;
																		IL_06e3:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		goto IL_06fc;
																		IL_06fc:
																		array[num5] = 0;
																		goto IL_070a;
																		IL_070a:
																		num5++;
																		goto IL_0718;
																		IL_0718:
																		ptr2 += 8;
																		break;
																		IL_0489:
																		array[num5 - 1] = 0;
																		goto IL_049d;
																		IL_049d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ThaiBuddhistCalendarIEnumerable[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																		goto IL_0555;
																		IL_0555:
																		ptr2 += 8;
																		break;
																		IL_0299:
																		if (10 < b)
																		{
																			goto IL_02a7;
																		}
																		goto IL_0350;
																		IL_02a7:
																		if (11 >= b)
																		{
																			goto IL_02b5;
																		}
																		goto IL_0399;
																		IL_02b5:
																		if (11 > b)
																		{
																			goto IL_0399;
																		}
																		goto IL_05fe;
																		IL_05fe:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		break;
																		IL_0350:
																		if (10 > b)
																		{
																			goto IL_0399;
																		}
																		goto IL_057b;
																		IL_057b:
																		num5--;
																		break;
																		IL_02c8:
																		if (6 > b)
																		{
																			goto IL_02d6;
																		}
																		goto IL_03f7;
																		IL_02d6:
																		if (3 >= b)
																		{
																			goto IL_02e1;
																		}
																		goto IL_031a;
																		IL_02e1:
																		if (3 > b)
																		{
																			goto IL_02ef;
																		}
																		goto IL_045e;
																		IL_02ef:
																		if (1 >= b)
																		{
																			goto IL_02fa;
																		}
																		goto IL_030d;
																		IL_02fa:
																		if (1 > b)
																		{
																		}
																		goto IL_0399;
																		IL_030d:
																		if (2 >= b)
																		{
																			goto IL_037b;
																		}
																		goto IL_0399;
																		IL_037b:
																		if (2 > b)
																		{
																			goto IL_0399;
																		}
																		goto IL_067f;
																		IL_067f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_06bf;
																		IL_06bf:
																		array[num5 - 2] = 0;
																		goto IL_06d3;
																		IL_06d3:
																		num5--;
																		break;
																		IL_045e:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_04de;
																		IL_04de:
																		ptr2 += 8;
																		goto IL_0568;
																		IL_0568:
																		num5--;
																		break;
																		IL_031a:
																		if (4 >= b)
																		{
																			goto IL_0325;
																		}
																		goto IL_0360;
																		IL_0325:
																		if (4 > b)
																		{
																			goto IL_0399;
																		}
																		goto IL_058e;
																		IL_058e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_05ce;
																		IL_05ce:
																		array[num5 - 2] = 0;
																		num = 75;
																		goto IL_05eb;
																		IL_05eb:
																		num5--;
																		break;
																		IL_0360:
																		if (5 >= b)
																		{
																			goto IL_036b;
																		}
																		goto IL_0399;
																		IL_036b:
																		if (5 > b)
																		{
																			goto IL_0399;
																		}
																		goto IL_061a;
																		IL_061a:
																		array[num5] = 0;
																		goto IL_0628;
																		IL_0628:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_064b;
																		IL_064b:
																		array2[num5] = null;
																		goto IL_0655;
																		IL_0655:
																		num5++;
																		goto IL_0663;
																		IL_0663:
																		ptr2 += 8;
																		num = 71;
																		break;
																		IL_03f7:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0437;
																		IL_0437:
																		array[num5 - 2] = 0;
																		goto IL_044b;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_07de;
														IL_07de:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0726:
														break;
													}
													continue;
													end_IL_0739:
													break;
												}
												continue;
												end_IL_0743:
												break;
											}
											continue;
											end_IL_074e:
											break;
										}
										continue;
										end_IL_0763:
										break;
									}
									continue;
									end_IL_0778:
									break;
								}
								continue;
								end_IL_0788:
								break;
							}
							continue;
							end_IL_0798:
							break;
						}
						continue;
						end_IL_07a3:
						break;
					}
					continue;
					end_IL_07b3:
					break;
				}
				continue;
				end_IL_07c3:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3)
	{
		int num = 48;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 37;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								IL_0645:
								long[] array4 = new long[2];
								while (true)
								{
									IL_0630:
									array3[0] = int_3;
									while (true)
									{
										IL_061c:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FixupHolderMutex.ModifyMethodBody);
										num = 90;
										while (true)
										{
											IL_0612:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_05ff:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02b7:
														byte b = *ptr2;
														while (true)
														{
															IL_02a7:
															ptr2++;
															while (true)
															{
																IL_0297:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		num = 23;
																		while (true)
																		{
																			IL_0274:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0264:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0254:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_0244:
																									if (2 > b)
																									{
																										num = 20;
																										while (1 >= b)
																										{
																											num = 58;
																											while (true)
																											{
																												IL_021e:
																												if (1 > b)
																												{
																													num = 113;
																													while (num != 113)
																													{
																														if (num != 1094)
																														{
																															goto end_IL_0297;
																														}
																														switch (num)
																														{
																														case 58:
																															goto IL_021e;
																														case 20:
																														case 35:
																															goto IL_0231;
																														case 105:
																															goto IL_0244;
																														case 14:
																														case 87:
																															goto IL_0254;
																														case 92:
																															goto IL_0264;
																														case 23:
																															goto IL_0274;
																														case 60:
																															goto IL_0284;
																														case 45:
																															goto IL_0297;
																														case 104:
																															goto IL_02a7;
																														case 71:
																														case 97:
																															goto IL_02b7;
																														case 44:
																														case 59:
																															goto IL_02c2;
																														case 15:
																															goto IL_02eb;
																														case 61:
																															goto IL_02f9;
																														case 50:
																														case 68:
																															goto IL_030c;
																														case 33:
																															goto IL_0317;
																														case 17:
																														case 98:
																															goto IL_0325;
																														case 1:
																														case 102:
																															goto IL_033d;
																														case 53:
																															goto IL_034b;
																														case 34:
																														case 76:
																															goto IL_035e;
																														case 49:
																															goto IL_0377;
																														case 93:
																															goto IL_0385;
																														case 52:
																															goto IL_0393;
																														case 10:
																														case 64:
																															goto IL_03a6;
																														case 72:
																															goto IL_03b4;
																														case 2:
																															goto IL_03d7;
																														case 101:
																															goto IL_03e1;
																														case 63:
																															goto IL_03ef;
																														case 41:
																															goto IL_0402;
																														case 66:
																															goto IL_040d;
																														case 19:
																														case 62:
																															goto IL_0418;
																														case 9:
																															goto IL_0426;
																														case 36:
																															goto IL_0439;
																														case 28:
																														case 85:
																															goto IL_0447;
																														case 67:
																															goto IL_046c;
																														case 79:
																														case 88:
																															goto IL_047a;
																														case 46:
																															goto IL_0485;
																														case 5:
																														case 73:
																															goto IL_0493;
																														case 99:
																															goto IL_04d3;
																														case 39:
																															goto IL_04e7;
																														case 69:
																															goto IL_0503;
																														case 43:
																															goto IL_0511;
																														case 22:
																														case 80:
																															goto IL_051f;
																														case 70:
																															goto IL_0542;
																														case 11:
																															goto IL_0550;
																														case 40:
																															goto IL_055e;
																														case 0:
																														case 56:
																															goto IL_0571;
																														case 32:
																															goto IL_05d3;
																														case 3:
																														case 6:
																														case 8:
																														case 24:
																														case 25:
																														case 26:
																														case 31:
																														case 51:
																														case 54:
																														case 74:
																														case 75:
																														case 81:
																														case 84:
																														case 86:
																														case 89:
																														case 91:
																														case 94:
																														case 103:
																														case 106:
																															goto end_IL_020b;
																														case 12:
																														case 16:
																														case 18:
																														case 21:
																														case 27:
																														case 30:
																														case 38:
																														case 42:
																														case 77:
																														case 82:
																														case 83:
																														case 95:
																														case 96:
																															goto IL_05ff;
																														case 90:
																															goto IL_0612;
																														case 55:
																															goto IL_061c;
																														case 78:
																															goto IL_0630;
																														case 100:
																															goto IL_0645;
																														case 29:
																														case 37:
																															goto end_IL_0297;
																														case 7:
																															goto end_IL_0655;
																														case 13:
																														case 57:
																															goto end_IL_0665;
																														case 47:
																															goto end_IL_067e;
																														case 48:
																															goto end_IL_068e;
																														case 4:
																														case 65:
																															goto IL_06a9;
																														}
																														continue;
																														end_IL_020b:
																														break;
																													}
																													break;
																												}
																												goto IL_035e;
																												IL_0385:
																												num5++;
																												goto IL_0393;
																												IL_0393:
																												ptr2 += 8;
																												goto IL_05ff;
																												IL_035e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_0377;
																												IL_0377:
																												array[num5] = 0;
																												goto IL_0385;
																											}
																											break;
																											IL_0231:;
																										}
																										break;
																									}
																									goto IL_02c2;
																									IL_02eb:
																									ptr2 += 8;
																									goto IL_02f9;
																									IL_02f9:
																									num5--;
																									goto IL_05ff;
																									IL_02c2:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_02eb;
																								}
																								break;
																							}
																							goto IL_030c;
																							IL_034b:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_05ff;
																							IL_030c:
																							if (3 >= b)
																							{
																								goto IL_0317;
																							}
																							goto IL_033d;
																							IL_0317:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0325;
																							IL_0325:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_05ff;
																							IL_033d:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_034b;
																						}
																						break;
																					}
																					goto IL_03a6;
																					IL_03ef:
																					ptr2 += 8;
																					goto IL_05ff;
																					IL_03a6:
																					array[num5] = 0;
																					goto IL_03b4;
																					IL_03b4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03d7;
																					IL_03d7:
																					array2[num5] = null;
																					goto IL_03e1;
																					IL_03e1:
																					num5++;
																					goto IL_03ef;
																				}
																				break;
																			}
																			goto IL_0402;
																			IL_05d3:
																			num5 -= 2;
																			num = 38;
																			goto IL_05ff;
																			IL_0402:
																			if (8 < b)
																			{
																				goto IL_040d;
																			}
																			goto IL_046c;
																			IL_040d:
																			if (9 < b)
																			{
																				goto IL_0418;
																			}
																			goto IL_0439;
																			IL_0418:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0426;
																			IL_0426:
																			if (10 > b)
																			{
																			}
																			break;
																			IL_0439:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0447;
																			IL_0447:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 30;
																			goto IL_05ff;
																			IL_046c:
																			if (8 > b)
																			{
																				goto IL_047a;
																			}
																			goto IL_0571;
																			IL_047a:
																			if (6 >= b)
																			{
																				goto IL_0485;
																			}
																			goto IL_0503;
																			IL_0485:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0493;
																			IL_0493:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04d3;
																			IL_04d3:
																			array[num5 - 2] = 0;
																			goto IL_04e7;
																			IL_04e7:
																			num5--;
																			num = 82;
																			goto IL_05ff;
																			IL_0503:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0511;
																			IL_0511:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_051f;
																			IL_051f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0542;
																			IL_0542:
																			array[num5] = 0;
																			goto IL_0550;
																			IL_0550:
																			num5++;
																			goto IL_055e;
																			IL_055e:
																			ptr2 += 8;
																			goto IL_05ff;
																			IL_0571:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05d3;
																		}
																		break;
																		IL_0284:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_05ff;
																continue;
																end_IL_0297:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_06a9;
												IL_06a9:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_0655:
							break;
						}
						continue;
						end_IL_0665:
						break;
					}
					continue;
					end_IL_067e:
					break;
				}
				continue;
				end_IL_068e:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 44;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetAppDomainPolicyLoose.FindTokenDoNotExpandEnvironmentNames);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 105;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0305:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02e5:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02d5:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02c8:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02bb:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02a8:
																											if (2 < b)
																											{
																												num = 158;
																												while (true)
																												{
																													if (num != 158)
																													{
																														if (num != 1139)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 96:
																															goto IL_02a8;
																														case 123:
																															goto IL_02bb;
																														case 59:
																														case 70:
																															goto IL_02c8;
																														case 48:
																															goto IL_02d5;
																														case 73:
																															goto IL_02e5;
																														case 147:
																															goto IL_02f5;
																														case 54:
																															goto IL_0305;
																														case 136:
																															goto end_IL_0305;
																														case 109:
																														case 112:
																															goto end_IL_0315;
																														case 95:
																														case 97:
																															goto IL_033b;
																														case 81:
																															goto IL_0359;
																														case 4:
																														case 119:
																															goto IL_036c;
																														case 103:
																															goto IL_0377;
																														case 75:
																														case 98:
																															goto IL_0382;
																														case 92:
																															goto IL_0390;
																														case 37:
																														case 106:
																															goto IL_039e;
																														case 89:
																															goto IL_03b5;
																														case 113:
																														case 126:
																															goto IL_03d2;
																														case 124:
																															goto IL_03e0;
																														case 118:
																														case 129:
																															goto IL_03f0;
																														case 15:
																															goto IL_042f;
																														case 85:
																														case 135:
																															goto IL_044b;
																														case 122:
																															goto IL_0474;
																														case 66:
																															goto IL_048b;
																														case 139:
																															goto IL_049e;
																														case 134:
																															goto IL_04ac;
																														case 144:
																															goto IL_04bf;
																														case 34:
																															goto IL_04d2;
																														case 24:
																															goto IL_04e0;
																														case 57:
																														case 79:
																															goto IL_04ee;
																														case 101:
																															goto IL_0517;
																														case 149:
																															goto IL_0530;
																														case 35:
																														case 142:
																															goto IL_053b;
																														case 121:
																															goto IL_0549;
																														case 18:
																														case 65:
																															goto IL_0560;
																														case 14:
																															goto IL_0579;
																														case 55:
																															goto IL_0587;
																														case 102:
																															goto IL_0595;
																														case 11:
																														case 61:
																															goto IL_05a8;
																														case 38:
																															goto IL_05e8;
																														case 120:
																															goto IL_05fc;
																														case 13:
																														case 30:
																															goto IL_060f;
																														case 100:
																														case 145:
																															goto IL_0627;
																														case 3:
																															goto IL_0635;
																														case 60:
																														case 110:
																															goto IL_0640;
																														case 31:
																															goto IL_0680;
																														case 69:
																															goto IL_0694;
																														case 25:
																															goto IL_06a7;
																														case 116:
																														case 141:
																															goto IL_06be;
																														case 58:
																															goto IL_06cc;
																														case 50:
																														case 86:
																															goto IL_06da;
																														case 21:
																															goto IL_071e;
																														case 5:
																															goto IL_0732;
																														case 151:
																															goto IL_0745;
																														case 9:
																														case 87:
																															goto IL_0750;
																														case 7:
																															goto IL_075b;
																														case 29:
																														case 127:
																															goto IL_077c;
																														case 12:
																															goto IL_078a;
																														case 8:
																															goto IL_07ad;
																														case 52:
																															goto IL_07b7;
																														case 108:
																															goto IL_07c5;
																														case 63:
																															goto IL_07d8;
																														case 26:
																															goto IL_07e6;
																														case 56:
																														case 78:
																															goto IL_07f4;
																														case 16:
																															goto IL_0802;
																														case 53:
																														case 125:
																															goto IL_0810;
																														case 17:
																															goto IL_0872;
																														case 19:
																														case 23:
																															goto IL_0882;
																														case 90:
																															goto IL_089b;
																														case 76:
																															goto IL_08a6;
																														case 0:
																														case 6:
																														case 10:
																														case 20:
																														case 28:
																														case 40:
																														case 41:
																														case 46:
																														case 47:
																														case 67:
																														case 72:
																														case 77:
																														case 82:
																														case 83:
																														case 84:
																														case 88:
																														case 91:
																														case 93:
																														case 94:
																														case 107:
																														case 115:
																														case 130:
																														case 133:
																														case 137:
																														case 138:
																														case 140:
																														case 143:
																														case 150:
																															goto end_IL_0295;
																														case 1:
																														case 2:
																														case 33:
																														case 36:
																														case 39:
																														case 42:
																														case 49:
																														case 51:
																														case 62:
																														case 64:
																														case 68:
																														case 71:
																														case 104:
																														case 105:
																														case 111:
																														case 128:
																														case 131:
																														case 146:
																															goto end_IL_0325;
																														case 80:
																															goto end_IL_08c4;
																														case 132:
																															goto end_IL_08d7;
																														case 27:
																															goto end_IL_08ea;
																														case 99:
																															goto end_IL_08f5;
																														case 22:
																														case 74:
																															goto end_IL_0905;
																														case 148:
																															goto end_IL_0915;
																														case 114:
																														case 117:
																															goto end_IL_0925;
																														case 43:
																															goto end_IL_0935;
																														case 44:
																															goto end_IL_0945;
																														case 32:
																														case 45:
																															goto IL_0960;
																														}
																														continue;
																													}
																													goto IL_04d2;
																													IL_04ee:
																													array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													goto IL_0517;
																													IL_0517:
																													array[num5 - 1] = 5;
																													goto end_IL_0325;
																													IL_04d2:
																													if (3 < b)
																													{
																														break;
																													}
																													goto IL_04e0;
																													IL_04e0:
																													if (3 > b)
																													{
																														break;
																													}
																													goto IL_04ee;
																													continue;
																													end_IL_0295:
																													break;
																												}
																												break;
																											}
																											goto IL_0530;
																											IL_05a8:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_05e8;
																											IL_05e8:
																											array[num5 - 2] = 0;
																											goto IL_05fc;
																											IL_0530:
																											if (2 > b)
																											{
																												goto IL_053b;
																											}
																											goto IL_05a8;
																											IL_053b:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_0549;
																											IL_0549:
																											if (1 > b)
																											{
																												break;
																											}
																											num = 18;
																											goto IL_0560;
																											IL_05fc:
																											num5--;
																											goto end_IL_0325;
																											IL_0560:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0579;
																											IL_0579:
																											array[num5] = 0;
																											goto IL_0587;
																											IL_0587:
																											num5++;
																											goto IL_0595;
																											IL_0595:
																											ptr2 += 8;
																											goto end_IL_0325;
																										}
																										break;
																									}
																									goto IL_033b;
																									IL_04bf:
																									num5--;
																									goto end_IL_0325;
																									IL_033b:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_0359;
																									IL_0359:
																									ptr2 += 8;
																									goto IL_04bf;
																								}
																								break;
																							}
																							num = 119;
																							goto IL_036c;
																							IL_0474:
																							ptr2 += 8;
																							num = 66;
																							goto IL_048b;
																							IL_048b:
																							num5--;
																							goto end_IL_0325;
																							IL_036c:
																							if (6 >= b)
																							{
																								goto IL_0377;
																							}
																							goto IL_03d2;
																							IL_0377:
																							if (6 > b)
																							{
																								goto IL_0382;
																							}
																							goto IL_03f0;
																							IL_0382:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0390;
																							IL_0390:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_039e;
																							IL_039e:
																							array[num5] = 5;
																							num = 89;
																							goto IL_03b5;
																							IL_03b5:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_049e;
																							IL_049e:
																							num5++;
																							goto IL_04ac;
																							IL_04ac:
																							ptr2 += 8;
																							goto end_IL_0325;
																							IL_03f0:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_042f;
																							IL_042f:
																							num5 -= 3;
																							num = 33;
																							goto end_IL_0325;
																							IL_03d2:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_03e0;
																							IL_03e0:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_044b;
																							IL_044b:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0474;
																						}
																						break;
																					}
																					goto IL_060f;
																					IL_060f:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0325;
																				}
																				break;
																			}
																			goto IL_0627;
																			IL_0882:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0325;
																			IL_0627:
																			if (12 >= b)
																			{
																				goto IL_0635;
																			}
																			goto IL_07d8;
																			IL_0635:
																			if (12 <= b)
																			{
																				goto IL_0640;
																			}
																			goto IL_06a7;
																			IL_0640:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0680;
																			IL_0680:
																			array[num5 - 2] = 0;
																			goto IL_0694;
																			IL_0694:
																			num5--;
																			goto end_IL_0325;
																			IL_06a7:
																			if (10 < b)
																			{
																				num = 141;
																				goto IL_06be;
																			}
																			goto IL_0745;
																			IL_089b:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_08a6;
																			IL_06be:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_06cc;
																			IL_06cc:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_06da;
																			IL_06da:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_071e;
																			IL_071e:
																			array[num5 - 2] = 0;
																			goto IL_0732;
																			IL_0732:
																			num5--;
																			goto end_IL_0325;
																			IL_0745:
																			if (10 > b)
																			{
																				goto IL_0750;
																			}
																			goto IL_077c;
																			IL_0750:
																			if (9 < b)
																			{
																				num = 84;
																				break;
																			}
																			goto IL_075b;
																			IL_075b:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_0325;
																			IL_08a6:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_077c:
																			array[num5] = 0;
																			goto IL_078a;
																			IL_078a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_07ad;
																			IL_07ad:
																			array2[num5] = null;
																			goto IL_07b7;
																			IL_07b7:
																			num5++;
																			goto IL_07c5;
																			IL_07c5:
																			ptr2 += 8;
																			goto end_IL_0325;
																			IL_07d8:
																			if (14 >= b)
																			{
																				goto IL_07e6;
																			}
																			goto IL_089b;
																			IL_07e6:
																			if (14 > b)
																			{
																				goto IL_07f4;
																			}
																			goto IL_0882;
																			IL_07f4:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0802;
																			IL_0802:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0810;
																			IL_0810:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0872;
																			IL_0872:
																			num5 -= 2;
																			goto end_IL_0325;
																		}
																		break;
																		IL_02f5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0325;
																continue;
																end_IL_0305:
																break;
															}
															continue;
															end_IL_0315:
															break;
														}
														continue;
														end_IL_0325:
														break;
													}
													continue;
												}
												goto IL_0960;
												IL_0960:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c4:
												break;
											}
											continue;
											end_IL_08d7:
											break;
										}
										continue;
										end_IL_08ea:
										break;
									}
									continue;
									end_IL_08f5:
									break;
								}
								continue;
								end_IL_0905:
								break;
							}
							continue;
							end_IL_0915:
							break;
						}
						continue;
						end_IL_0925:
						break;
					}
					continue;
					end_IL_0935:
					break;
				}
				continue;
				end_IL_0945:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3)
	{
		int num = 102;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SynchronizationContextNoFlowGetCurrentDirectory.DTTHostSecurityManagerOptions);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0252:
														byte b = *ptr2;
														while (true)
														{
															IL_0242:
															ptr2++;
															while (true)
															{
																IL_0232:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0215:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0208:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_01fb:
																							if (9 >= b)
																							{
																								while (9 <= b)
																								{
																									num = 110;
																									while (true)
																									{
																										if (num != 110)
																										{
																											if (num != 1091)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 7:
																												goto IL_01e8;
																											case 33:
																												goto IL_01fb;
																											case 42:
																												goto IL_0208;
																											case 28:
																												goto IL_0215;
																											case 4:
																												goto IL_0222;
																											case 96:
																												goto IL_0232;
																											case 14:
																												goto IL_0242;
																											case 82:
																											case 89:
																												goto IL_0252;
																											case 8:
																											case 9:
																												goto IL_025d;
																											case 15:
																												goto IL_026d;
																											case 30:
																												goto IL_0280;
																											case 34:
																												goto IL_028b;
																											case 35:
																												goto IL_029b;
																											case 40:
																											case 55:
																												goto IL_02ae;
																											case 59:
																												goto IL_0315;
																											case 5:
																											case 22:
																												goto IL_0323;
																											case 3:
																												goto IL_0363;
																											case 38:
																											case 67:
																												goto IL_0379;
																											case 12:
																												goto IL_0387;
																											case 72:
																												goto IL_0394;
																											case 26:
																												goto IL_03a2;
																											case 73:
																												goto IL_03b5;
																											case 77:
																												goto IL_03c8;
																											case 86:
																												goto IL_03d8;
																											case 48:
																											case 87:
																												goto IL_03eb;
																											case 64:
																												goto IL_0414;
																											case 43:
																												goto IL_0422;
																											case 90:
																												goto IL_0435;
																											case 41:
																											case 92:
																												goto IL_0443;
																											case 60:
																												goto IL_0465;
																											case 66:
																												goto IL_0473;
																											case 39:
																												goto IL_0481;
																											case 46:
																											case 94:
																												goto IL_0494;
																											case 57:
																											case 95:
																												goto IL_04a4;
																											case 17:
																												goto IL_04b2;
																											case 27:
																												goto IL_04d5;
																											case 20:
																												goto IL_04df;
																											case 52:
																												goto IL_04ed;
																											case 1:
																											case 98:
																												goto IL_0500;
																											case 78:
																												goto IL_050e;
																											case 71:
																											case 99:
																												goto IL_0521;
																											case 32:
																												goto IL_0544;
																											case 100:
																												goto IL_0552;
																											case 50:
																												goto IL_0560;
																											case 103:
																												goto IL_0570;
																											case 0:
																											case 16:
																												goto IL_057b;
																											case 81:
																												goto IL_0590;
																											case 10:
																											case 11:
																											case 19:
																											case 24:
																											case 31:
																											case 36:
																											case 37:
																											case 45:
																											case 47:
																											case 51:
																											case 56:
																											case 58:
																											case 62:
																											case 65:
																											case 68:
																											case 74:
																											case 84:
																											case 85:
																											case 93:
																												goto end_IL_01e8;
																											case 2:
																											case 13:
																											case 23:
																											case 29:
																											case 44:
																											case 49:
																											case 54:
																											case 61:
																											case 63:
																											case 69:
																											case 70:
																											case 76:
																											case 83:
																												goto end_IL_01d5;
																											case 97:
																												goto end_IL_05c5;
																											case 53:
																												goto end_IL_05d8;
																											case 6:
																												goto end_IL_05e2;
																											case 25:
																												goto end_IL_05ed;
																											case 18:
																											case 21:
																												goto end_IL_0602;
																											case 75:
																												goto end_IL_0612;
																											case 80:
																											case 88:
																												goto end_IL_0622;
																											case 101:
																												goto end_IL_0632;
																											case 102:
																												goto end_IL_0642;
																											case 79:
																											case 91:
																												goto IL_065d;
																											}
																											continue;
																										}
																										goto IL_0590;
																										IL_0590:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										break;
																										continue;
																										end_IL_01d5:
																										break;
																									}
																									goto end_IL_0232;
																									continue;
																									end_IL_01e8:
																									break;
																									IL_01e8:;
																								}
																								break;
																							}
																							goto IL_025d;
																							IL_029b:
																							if (10 <= b)
																							{
																							}
																							break;
																							IL_025d:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_029b;
																						}
																						break;
																					}
																					goto IL_0280;
																					IL_03b5:
																					num6 -= 2;
																					goto end_IL_0232;
																					IL_0280:
																					if (8 > b)
																					{
																						goto IL_028b;
																					}
																					goto IL_02ae;
																					IL_028b:
																					if (6 >= b)
																					{
																						goto IL_0315;
																					}
																					goto IL_0394;
																					IL_0315:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0323;
																					IL_0323:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0363;
																					IL_0363:
																					array[num6 - 2] = 0;
																					goto IL_03d8;
																					IL_03d8:
																					num6--;
																					goto end_IL_0232;
																					IL_0394:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_03a2;
																					IL_03a2:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0521;
																					IL_0521:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0544;
																					IL_0544:
																					array[num6] = 0;
																					goto IL_0552;
																					IL_0552:
																					num6++;
																					goto IL_0560;
																					IL_0560:
																					ptr2 += 8;
																					goto end_IL_0232;
																					IL_02ae:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03b5;
																				}
																				break;
																			}
																			goto IL_026d;
																			IL_057b:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0232;
																			IL_026d:
																			if (5 > b)
																			{
																				goto IL_0379;
																			}
																			goto IL_04a4;
																			IL_04a4:
																			array[num6] = 0;
																			goto IL_04b2;
																			IL_04b2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04d5;
																			IL_04d5:
																			array2[num6] = null;
																			goto IL_04df;
																			IL_04df:
																			num6++;
																			goto IL_04ed;
																			IL_04ed:
																			ptr2 += 8;
																			goto end_IL_0232;
																			IL_0379:
																			if (2 >= b)
																			{
																				goto IL_0387;
																			}
																			goto IL_0494;
																			IL_0387:
																			if (2 > b)
																			{
																				goto IL_03c8;
																			}
																			goto IL_03eb;
																			IL_03eb:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0414;
																			IL_0414:
																			ptr2 += 8;
																			goto IL_0422;
																			IL_0422:
																			num6--;
																			goto end_IL_0232;
																			IL_03c8:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0435;
																			IL_0435:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0443;
																			IL_0443:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			num = 60;
																			goto IL_0465;
																			IL_0465:
																			array[num6] = 0;
																			goto IL_0473;
																			IL_0473:
																			num6++;
																			goto IL_0481;
																			IL_0481:
																			ptr2 += 8;
																			goto end_IL_0232;
																			IL_0494:
																			if (3 < b)
																			{
																				goto IL_0500;
																			}
																			goto IL_0570;
																			IL_0500:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_050e;
																			IL_050e:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0232;
																			IL_0570:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_057b;
																		}
																		break;
																		IL_0222:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 13;
																break;
																continue;
																end_IL_0232:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_065d;
												IL_065d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05c5:
												break;
											}
											continue;
											end_IL_05d8:
											break;
										}
										continue;
										end_IL_05e2:
										break;
									}
									continue;
									end_IL_05ed:
									break;
								}
								continue;
								end_IL_0602:
								break;
							}
							continue;
							end_IL_0612:
							break;
						}
						continue;
						end_IL_0622:
						break;
					}
					continue;
					end_IL_0632:
					break;
				}
				continue;
				end_IL_0642:
				break;
			}
		}
	}

	static Class201()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0064:
				Class300.smethod_0();
				while (true)
				{
					IL_0052:
					num = 3;
					while (true)
					{
						IL_0046:
						num = 12;
						while (true)
						{
							if (num != 12)
							{
								if (num != 993)
								{
									break;
								}
								switch (num)
								{
								case 3:
									goto IL_0046;
								case 0:
								case 1:
								case 2:
									goto IL_0052;
								case 4:
									goto IL_0064;
								case 5:
									goto end_IL_0039;
								}
								continue;
							}
							return;
							continue;
							end_IL_0039:
							break;
						}
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
