using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Reset Steam Long Arms", "Rig", "", false, 48, ModType.const_1, false)]
internal class Class197 : MonoBehaviour
{
	private static bool bool_0;

	private static float float_0;

	private static double double_0;

	private static float float_1;

	private static double double_1;

	private static double double_2;

	private static float float_2;

	private static IntPtr[] GetMopsMDStreamVersion;

	private unsafe void OnEnable()
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSkipVerificationSynchronizationContextNoFlow.TargetedPatchBandStandard);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_032d:
															byte b = *ptr2;
															num = 26;
															while (true)
															{
																IL_031d:
																ptr2++;
																while (true)
																{
																	IL_030d:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_02ed:
																				if (8 >= b)
																				{
																					num = 22;
																					while (true)
																					{
																						IL_02dd:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02cd:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02bd:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													num = 151;
																													while (true)
																													{
																														if (num != 151)
																														{
																															if (num != 1132)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 39:
																																goto IL_029a;
																															case 47:
																																goto IL_02ad;
																															case 95:
																																goto IL_02bd;
																															case 143:
																																goto IL_02cd;
																															case 22:
																																goto IL_02dd;
																															case 85:
																																goto IL_02ed;
																															case 86:
																																goto IL_02fd;
																															case 128:
																																goto IL_030d;
																															case 26:
																																goto IL_031d;
																															case 9:
																															case 21:
																																goto IL_032d;
																															case 44:
																																goto IL_0341;
																															case 73:
																																goto IL_034f;
																															case 88:
																																goto IL_0362;
																															case 52:
																															case 90:
																																goto IL_0372;
																															case 97:
																																goto IL_0385;
																															case 48:
																																goto IL_0390;
																															case 28:
																																goto IL_039e;
																															case 31:
																															case 98:
																																goto IL_03b1;
																															case 10:
																																goto IL_03bf;
																															case 58:
																																goto IL_03e2;
																															case 89:
																															case 106:
																																goto IL_03ee;
																															case 56:
																																goto IL_042e;
																															case 115:
																																goto IL_0442;
																															case 117:
																																goto IL_0455;
																															case 82:
																																goto IL_0463;
																															case 64:
																															case 122:
																																goto IL_0476;
																															case 66:
																																goto IL_0490;
																															case 110:
																																goto IL_049e;
																															case 109:
																																goto IL_04ac;
																															case 123:
																																goto IL_04bf;
																															case 83:
																																goto IL_04cd;
																															case 12:
																															case 120:
																																goto IL_04d8;
																															case 13:
																																goto IL_0518;
																															case 121:
																																goto IL_052c;
																															case 17:
																																goto IL_053f;
																															case 42:
																																goto IL_054d;
																															case 124:
																																goto IL_0560;
																															case 32:
																																goto IL_056b;
																															case 23:
																															case 114:
																																goto IL_0576;
																															case 8:
																																goto IL_058e;
																															case 5:
																																goto IL_05a1;
																															case 94:
																																goto IL_05b4;
																															case 45:
																																goto IL_05bf;
																															case 63:
																																goto IL_05cd;
																															case 41:
																															case 74:
																																goto IL_05db;
																															case 101:
																																goto IL_05f7;
																															case 11:
																															case 76:
																																goto IL_0605;
																															case 51:
																																goto IL_0637;
																															case 55:
																																goto IL_0645;
																															case 129:
																																goto IL_0658;
																															case 38:
																																goto IL_0666;
																															case 136:
																																goto IL_0679;
																															case 108:
																																goto IL_0687;
																															case 112:
																															case 125:
																																goto IL_0692;
																															case 77:
																																goto IL_06f4;
																															case 119:
																																goto IL_0707;
																															case 93:
																																goto IL_0715;
																															case 75:
																															case 99:
																																goto IL_0723;
																															case 96:
																																goto IL_0763;
																															case 103:
																																goto IL_0780;
																															case 53:
																																goto IL_0793;
																															case 43:
																																goto IL_07a1;
																															case 137:
																																goto IL_07b4;
																															case 67:
																															case 72:
																																goto IL_07c2;
																															case 140:
																																goto IL_07dc;
																															case 37:
																															case 141:
																																goto IL_07ef;
																															case 84:
																																goto IL_082f;
																															case 91:
																																goto IL_0843;
																															case 144:
																																goto IL_0856;
																															case 50:
																																goto IL_0864;
																															case 111:
																															case 132:
																																goto IL_0872;
																															case 36:
																																goto IL_089b;
																															case 2:
																																goto IL_08a9;
																															case 65:
																																goto IL_08bc;
																															case 24:
																																goto IL_08fc;
																															case 139:
																																goto IL_0910;
																															case 3:
																															case 4:
																															case 7:
																															case 14:
																															case 16:
																															case 25:
																															case 29:
																															case 46:
																															case 49:
																															case 57:
																															case 70:
																															case 71:
																															case 78:
																															case 80:
																															case 104:
																															case 113:
																															case 116:
																															case 133:
																															case 142:
																																goto end_IL_029a;
																															case 102:
																																goto IL_0939;
																															case 100:
																																goto IL_0947;
																															case 92:
																																goto IL_095e;
																															case 6:
																															case 15:
																															case 30:
																															case 34:
																															case 40:
																															case 54:
																															case 60:
																															case 61:
																															case 68:
																															case 79:
																															case 81:
																															case 87:
																															case 105:
																															case 107:
																															case 126:
																															case 127:
																															case 130:
																															case 135:
																															case 138:
																																goto end_IL_0287;
																															case 62:
																																goto end_IL_096c;
																															case 27:
																																goto end_IL_097f;
																															case 0:
																																goto end_IL_0989;
																															case 134:
																																goto end_IL_0994;
																															case 131:
																																goto end_IL_09a4;
																															case 35:
																															case 69:
																																goto end_IL_09b4;
																															case 59:
																																goto end_IL_09c4;
																															case 1:
																															case 18:
																																goto end_IL_09d4;
																															case 19:
																																goto end_IL_09e4;
																															case 20:
																																goto end_IL_09f4;
																															case 33:
																															case 118:
																																return;
																															}
																															continue;
																														}
																														goto IL_08bc;
																														IL_08fc:
																														array[num5 - 2] = 0;
																														goto IL_0910;
																														IL_0910:
																														num5--;
																														break;
																														IL_08bc:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_08fc;
																														continue;
																														end_IL_0287:
																														break;
																													}
																													goto end_IL_030d;
																													continue;
																													end_IL_029a:
																													break;
																													IL_029a:;
																												}
																												break;
																												IL_02ad:;
																											}
																											break;
																										}
																										goto IL_0385;
																										IL_0442:
																										num5--;
																										goto end_IL_030d;
																										IL_0385:
																										if (6 > b)
																										{
																											goto IL_0390;
																										}
																										goto IL_03ee;
																										IL_0390:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_039e;
																										IL_039e:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_07ef;
																										IL_07ef:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_082f;
																										IL_082f:
																										array[num5 - 2] = 0;
																										goto IL_0843;
																										IL_0843:
																										num5--;
																										goto end_IL_030d;
																										IL_03ee:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_042e;
																										IL_042e:
																										array[num5 - 2] = 0;
																										goto IL_0442;
																									}
																									break;
																								}
																								goto IL_0362;
																								IL_08a9:
																								num5--;
																								goto end_IL_030d;
																								IL_0362:
																								if (4 <= b)
																								{
																									goto IL_03b1;
																								}
																								goto IL_04bf;
																								IL_03b1:
																								array[num5] = 0;
																								goto IL_03bf;
																								IL_03bf:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03e2;
																								IL_03e2:
																								array2[num5] = null;
																								goto IL_0455;
																								IL_0455:
																								num5++;
																								goto IL_0463;
																								IL_0463:
																								ptr2 += 8;
																								goto end_IL_030d;
																								IL_04bf:
																								if (2 >= b)
																								{
																									goto IL_04cd;
																								}
																								goto IL_0856;
																								IL_04cd:
																								if (2 <= b)
																								{
																									goto IL_04d8;
																								}
																								goto IL_053f;
																								IL_04d8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0518;
																								IL_0518:
																								array[num5 - 2] = 0;
																								goto IL_052c;
																								IL_052c:
																								num5--;
																								goto end_IL_030d;
																								IL_053f:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_054d;
																								IL_054d:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0856:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0864;
																								IL_0864:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0872;
																								IL_0872:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_089b;
																								IL_089b:
																								ptr2 += 8;
																								goto IL_08a9;
																							}
																							break;
																						}
																						goto IL_0372;
																						IL_0372:
																						num5--;
																						goto end_IL_030d;
																					}
																					break;
																				}
																				goto IL_0341;
																				IL_0637:
																				num5--;
																				goto IL_0645;
																				IL_0645:
																				ptr2 += 8;
																				goto end_IL_030d;
																				IL_0341:
																				if (12 >= b)
																				{
																					goto IL_034f;
																				}
																				goto IL_0560;
																				IL_034f:
																				if (12 <= b)
																				{
																					goto IL_0476;
																				}
																				goto IL_0679;
																				IL_0476:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																				goto IL_0490;
																				IL_0490:
																				array[num5] = 3;
																				goto IL_049e;
																				IL_049e:
																				num5++;
																				goto IL_04ac;
																				IL_04ac:
																				ptr2 += 8;
																				goto end_IL_030d;
																				IL_0679:
																				if (10 >= b)
																				{
																					goto IL_0687;
																				}
																				goto IL_0793;
																				IL_0687:
																				if (10 <= b)
																				{
																					goto IL_0692;
																				}
																				goto IL_0707;
																				IL_0692:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06f4;
																				IL_06f4:
																				num5 -= 2;
																				goto end_IL_030d;
																				IL_0707:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0715;
																				IL_0715:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0723;
																				IL_0723:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0763;
																				IL_0763:
																				array[num5 - 2] = 0;
																				num = 103;
																				goto IL_0780;
																				IL_0780:
																				num5--;
																				goto end_IL_030d;
																				IL_0793:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_07a1;
																				IL_07a1:
																				if (11 > b)
																				{
																					break;
																				}
																				goto end_IL_030d;
																				IL_0560:
																				if (14 >= b)
																				{
																					goto IL_056b;
																				}
																				goto IL_05b4;
																				IL_056b:
																				if (14 <= b)
																				{
																					goto IL_0576;
																				}
																				goto IL_05a1;
																				IL_0576:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_058e;
																				IL_058e:
																				array[num5] = 5;
																				goto IL_0658;
																				IL_0658:
																				num5++;
																				goto IL_0666;
																				IL_0666:
																				ptr2 += 8;
																				goto end_IL_030d;
																				IL_05a1:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_07b4;
																				IL_07b4:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_07c2;
																				IL_07c2:
																				Class207.float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_07dc;
																				IL_07dc:
																				num5--;
																				goto end_IL_030d;
																				IL_05b4:
																				if (15 < b)
																				{
																					goto IL_05bf;
																				}
																				goto IL_05f7;
																				IL_05bf:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_05cd;
																				IL_05cd:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_05db;
																				IL_05db:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_030d;
																				IL_05f7:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_0605;
																				IL_0605:
																				((delegate*<UnityEngine.Object, void>)GetMopsMDStreamVersion[*(int*)(ptr2 + num3)])((Class197)array2[num5 - 1]);
																				num = 51;
																				goto IL_0637;
																			}
																			break;
																			IL_02fd:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0939;
																	IL_095e:
																	ptr2 += 8;
																	break;
																	IL_0947:
																	num5++;
																	num = 92;
																	goto IL_095e;
																	IL_0939:
																	array[num5] = 0;
																	goto IL_0947;
																	continue;
																	end_IL_030d:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 33;
													return;
													continue;
													end_IL_096c:
													break;
												}
												continue;
												end_IL_097f:
												break;
											}
											continue;
											end_IL_0989:
											break;
										}
										continue;
										end_IL_0994:
										break;
									}
									continue;
									end_IL_09a4:
									break;
								}
								continue;
								end_IL_09b4:
								break;
							}
							continue;
							end_IL_09c4:
							break;
						}
						continue;
						end_IL_09d4:
						break;
					}
					continue;
					end_IL_09e4:
					break;
				}
				continue;
				end_IL_09f4:
				break;
			}
		}
	}

	public Class197()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 52;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 105;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 127;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setRefusedSetgetStringValue.MuiResourceTypeIdStringStringIdsSizeFullTrustZoneUntrusted);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0360:
														byte b = *ptr2;
														while (true)
														{
															IL_0350:
															ptr2++;
															while (true)
															{
																IL_0340:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0323:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0316:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0306:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02f6:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_02ab:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_029b:
																														ptr2 += 8;
																														while (true)
																														{
																															IL_0282:
																															num5--;
																															num = 152;
																															while (num != 152)
																															{
																																if (num != 1133)
																																{
																																	goto IL_04d9;
																																}
																																switch (num)
																																{
																																case 95:
																																	goto IL_0282;
																																case 140:
																																	goto IL_029b;
																																case 2:
																																case 77:
																																	goto IL_02ab;
																																case 47:
																																	goto IL_02d6;
																																case 111:
																																case 119:
																																	goto IL_02e6;
																																case 71:
																																case 130:
																																	goto IL_02f6;
																																case 78:
																																	goto IL_0306;
																																case 123:
																																	goto IL_0316;
																																case 3:
																																	goto IL_0323;
																																case 0:
																																	goto IL_0330;
																																case 133:
																																	goto IL_0340;
																																case 101:
																																	goto IL_0350;
																																case 65:
																																case 126:
																																	goto IL_0360;
																																case 55:
																																case 86:
																																	goto IL_036b;
																																case 30:
																																case 117:
																																	goto IL_0383;
																																case 109:
																																	goto IL_0391;
																																case 9:
																																case 38:
																																	goto IL_039f;
																																case 91:
																																	goto IL_03aa;
																																case 44:
																																	goto IL_03b8;
																																case 94:
																																	goto IL_03cf;
																																case 29:
																																	goto IL_03e2;
																																case 115:
																																	goto IL_03f0;
																																case 110:
																																case 112:
																																	goto IL_03fe;
																																case 84:
																																	goto IL_0442;
																																case 120:
																																	goto IL_0456;
																																case 36:
																																case 128:
																																	goto IL_0469;
																																case 90:
																																	goto IL_04a9;
																																case 21:
																																	goto IL_04c6;
																																case 83:
																																case 135:
																																	goto IL_04d9;
																																case 96:
																																	goto IL_04e7;
																																case 89:
																																	goto IL_050a;
																																case 104:
																																	goto IL_0514;
																																case 61:
																																	goto IL_0522;
																																case 138:
																																	goto IL_0535;
																																case 73:
																																case 100:
																																	goto IL_0540;
																																case 59:
																																	goto IL_054e;
																																case 34:
																																	goto IL_0561;
																																case 56:
																																case 66:
																																	goto IL_056c;
																																case 23:
																																	goto IL_0588;
																																case 68:
																																	goto IL_0596;
																																case 8:
																																case 63:
																																	goto IL_05a4;
																																case 141:
																																	goto IL_0606;
																																case 15:
																																	goto IL_0619;
																																case 60:
																																case 75:
																																	goto IL_0624;
																																case 12:
																																	goto IL_0663;
																																case 32:
																																	goto IL_0676;
																																case 97:
																																	goto IL_0684;
																																case 69:
																																case 70:
																																	goto IL_0692;
																																case 82:
																																	goto IL_06a0;
																																case 129:
																																	goto IL_06b8;
																																case 74:
																																	goto IL_06c6;
																																case 113:
																																	goto IL_06d9;
																																case 14:
																																case 28:
																																	goto IL_06e7;
																																case 50:
																																	goto IL_06f5;
																																case 49:
																																	goto IL_0700;
																																case 139:
																																	goto IL_070e;
																																case 92:
																																case 132:
																																	goto IL_071c;
																																case 76:
																																	goto IL_0735;
																																case 134:
																																	goto IL_0743;
																																case 87:
																																	goto IL_0751;
																																case 7:
																																case 143:
																																	goto IL_0764;
																																case 106:
																																	goto IL_07a4;
																																case 31:
																																	goto IL_07b8;
																																case 81:
																																	goto IL_07cb;
																																case 142:
																																	goto IL_07d9;
																																case 13:
																																case 145:
																																	goto IL_07e7;
																																case 124:
																																	goto IL_0819;
																																case 118:
																																case 125:
																																	goto IL_082f;
																																case 24:
																																	goto IL_0856;
																																case 4:
																																	goto IL_0864;
																																case 1:
																																case 5:
																																case 10:
																																case 11:
																																case 16:
																																case 18:
																																case 20:
																																case 25:
																																case 26:
																																case 37:
																																case 39:
																																case 41:
																																case 45:
																																case 54:
																																case 72:
																																case 80:
																																case 88:
																																case 93:
																																case 99:
																																case 108:
																																case 114:
																																case 121:
																																case 122:
																																case 131:
																																case 137:
																																case 144:
																																	goto end_IL_02d6;
																																case 6:
																																case 17:
																																case 22:
																																case 27:
																																case 33:
																																case 35:
																																case 40:
																																case 43:
																																case 53:
																																case 57:
																																case 58:
																																case 62:
																																case 67:
																																case 85:
																																case 98:
																																case 107:
																																case 116:
																																	goto end_IL_026f;
																																case 48:
																																	goto end_IL_0887;
																																case 127:
																																	goto end_IL_089a;
																																case 79:
																																	goto end_IL_08a4;
																																case 64:
																																	goto end_IL_08af;
																																case 42:
																																case 46:
																																	goto end_IL_08c8;
																																case 105:
																																	goto end_IL_08d8;
																																case 19:
																																case 102:
																																	goto end_IL_08e8;
																																case 51:
																																	goto end_IL_08f8;
																																case 52:
																																	goto end_IL_0911;
																																case 103:
																																case 136:
																																	goto IL_092c;
																																}
																																continue;
																																end_IL_026f:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_0340;
																												continue;
																												end_IL_02d6:
																												break;
																												IL_02d6:;
																											}
																											break;
																											IL_02e6:;
																										}
																										break;
																									}
																									goto IL_0619;
																									IL_06c6:
																									ptr2 += 8;
																									goto end_IL_0340;
																									IL_0619:
																									if (6 <= b)
																									{
																										goto IL_0624;
																									}
																									goto IL_0676;
																									IL_0624:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0663;
																									IL_0663:
																									num5 -= 3;
																									goto end_IL_0340;
																									IL_0676:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_0684;
																									IL_0684:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_0692;
																									IL_0692:
																									array[num5] = 5;
																									goto IL_06a0;
																									IL_06a0:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_06b8;
																									IL_06b8:
																									num5++;
																									goto IL_06c6;
																								}
																								break;
																							}
																							goto IL_06d9;
																							IL_0864:
																							num5--;
																							goto end_IL_0340;
																							IL_06d9:
																							if (4 > b)
																							{
																								goto IL_06e7;
																							}
																							goto IL_082f;
																							IL_06e7:
																							if (2 >= b)
																							{
																								goto IL_06f5;
																							}
																							goto IL_07cb;
																							IL_06f5:
																							if (2 > b)
																							{
																								goto IL_0700;
																							}
																							goto IL_0764;
																							IL_0700:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_070e;
																							IL_070e:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_071c;
																							IL_071c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0735;
																							IL_0735:
																							array[num5] = 0;
																							goto IL_0743;
																							IL_0743:
																							num5++;
																							goto IL_0751;
																							IL_0751:
																							ptr2 += 8;
																							goto end_IL_0340;
																							IL_0764:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07a4;
																							IL_07a4:
																							array[num5 - 2] = 0;
																							goto IL_07b8;
																							IL_07b8:
																							num5--;
																							goto end_IL_0340;
																							IL_07cb:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_07d9;
																							IL_07d9:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_07e7;
																							IL_07e7:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							num = 124;
																							goto IL_0819;
																							IL_0819:
																							array[num5 - 1] = 5;
																							goto end_IL_0340;
																							IL_082f:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							num = 24;
																							goto IL_0856;
																							IL_0856:
																							ptr2 += 8;
																							goto IL_0864;
																						}
																						break;
																					}
																					goto IL_036b;
																					IL_036b:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0340;
																				}
																				break;
																			}
																			goto IL_0383;
																			IL_05a4:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0606;
																			IL_0383:
																			if (12 >= b)
																			{
																				goto IL_0391;
																			}
																			goto IL_0535;
																			IL_0391:
																			if (12 > b)
																			{
																				goto IL_039f;
																			}
																			goto IL_0469;
																			IL_039f:
																			if (10 >= b)
																			{
																				goto IL_03aa;
																			}
																			goto IL_03e2;
																			IL_03aa:
																			if (10 > b)
																			{
																				goto IL_03b8;
																			}
																			goto IL_04d9;
																			IL_03b8:
																			if (9 < b)
																			{
																				break;
																			}
																			num = 94;
																			goto IL_03cf;
																			IL_0606:
																			num5 -= 2;
																			goto end_IL_0340;
																			IL_03cf:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_0340;
																			IL_04d9:
																			array[num5] = 0;
																			goto IL_04e7;
																			IL_04e7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_050a;
																			IL_050a:
																			array2[num5] = null;
																			goto IL_0514;
																			IL_0514:
																			num5++;
																			goto IL_0522;
																			IL_0522:
																			ptr2 += 8;
																			goto end_IL_0340;
																			IL_03e2:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_03f0;
																			IL_03f0:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_03fe;
																			IL_03fe:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0442;
																			IL_0442:
																			array[num5 - 2] = 0;
																			goto IL_0456;
																			IL_0456:
																			num5--;
																			goto end_IL_0340;
																			IL_0469:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04a9;
																			IL_04a9:
																			array[num5 - 2] = 0;
																			num = 21;
																			goto IL_04c6;
																			IL_04c6:
																			num5--;
																			goto end_IL_0340;
																			IL_0535:
																			if (14 < b)
																			{
																				goto IL_0540;
																			}
																			goto IL_0561;
																			IL_0540:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_054e;
																			IL_054e:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_0561:
																			if (14 <= b)
																			{
																				goto IL_056c;
																			}
																			goto IL_0588;
																			IL_056c:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0340;
																			IL_0588:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0596;
																			IL_0596:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_05a4;
																		}
																		break;
																		IL_0330:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0340:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_092c;
												IL_092c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0887:
												break;
											}
											continue;
											end_IL_089a:
											break;
										}
										continue;
										end_IL_08a4:
										break;
									}
									continue;
									end_IL_08af:
									break;
								}
								continue;
								end_IL_08c8:
								break;
							}
							continue;
							end_IL_08d8:
							break;
						}
						continue;
						end_IL_08e8:
						break;
					}
					continue;
					end_IL_08f8:
					break;
				}
				continue;
				end_IL_0911:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_0)
	{
		int num = 27;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 23;
				while (true)
				{
					byte[] array = new byte[2];
					num = 51;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 99;
							while (true)
							{
								long[] array4 = new long[2];
								num = 15;
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRawCertDataStringSetMethodSourceRange.CalendarDataOpenText);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 96;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_021d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 >= b)
																			{
																				while (true)
																				{
																					if (5 <= b)
																					{
																						num = 112;
																						while (true)
																						{
																							if (num == 112)
																							{
																								goto IL_056d;
																							}
																							if (num != 1093)
																							{
																								goto IL_05a8;
																							}
																							switch (num)
																							{
																							case 55:
																								goto end_IL_01dd;
																							case 13:
																								goto end_IL_01f0;
																							case 29:
																								goto end_IL_0200;
																							case 104:
																								goto IL_021d;
																							case 41:
																								goto end_IL_021d;
																							case 32:
																							case 43:
																								goto end_IL_022d;
																							case 22:
																								goto IL_0248;
																							case 10:
																								goto IL_0253;
																							case 35:
																								goto IL_0261;
																							case 49:
																								goto IL_027d;
																							case 9:
																								goto IL_028b;
																							case 53:
																								goto IL_029e;
																							case 38:
																							case 68:
																								goto IL_02b4;
																							case 62:
																								goto IL_02dd;
																							case 6:
																							case 73:
																								goto IL_02f0;
																							case 69:
																							case 82:
																								goto IL_0308;
																							case 14:
																							case 84:
																								goto IL_031b;
																							case 34:
																							case 86:
																								goto IL_0382;
																							case 37:
																								goto IL_038d;
																							case 0:
																							case 57:
																								goto IL_039b;
																							case 83:
																								goto IL_03db;
																							case 8:
																								goto IL_03f4;
																							case 1:
																								goto IL_0402;
																							case 72:
																							case 79:
																								goto IL_0410;
																							case 7:
																								goto IL_0433;
																							case 88:
																								goto IL_0443;
																							case 89:
																								goto IL_0456;
																							case 90:
																								goto IL_0469;
																							case 39:
																								goto IL_0477;
																							case 94:
																								goto IL_048a;
																							case 47:
																							case 65:
																								goto IL_0498;
																							case 12:
																								goto IL_04b1;
																							case 78:
																								goto IL_04c8;
																							case 36:
																								goto IL_04d6;
																							case 95:
																								goto IL_04e9;
																							case 50:
																								goto IL_04f7;
																							case 18:
																							case 97:
																								goto IL_050a;
																							case 58:
																							case 80:
																								goto IL_0515;
																							case 45:
																								goto IL_0523;
																							case 98:
																								goto IL_0536;
																							case 3:
																							case 20:
																								goto IL_0544;
																							case 101:
																								goto IL_055d;
																							case 4:
																								goto IL_056d;
																							case 91:
																								goto IL_057b;
																							case 31:
																								goto IL_059e;
																							case 93:
																								goto IL_05a8;
																							case 102:
																								goto IL_05b6;
																							case 2:
																							case 19:
																							case 21:
																							case 28:
																							case 40:
																							case 42:
																							case 48:
																							case 52:
																							case 54:
																							case 59:
																							case 64:
																							case 66:
																							case 67:
																							case 70:
																							case 71:
																							case 76:
																							case 77:
																							case 81:
																							case 85:
																							case 87:
																							case 103:
																								goto end_IL_020d;
																							case 5:
																							case 11:
																							case 16:
																							case 17:
																							case 24:
																							case 56:
																							case 61:
																							case 63:
																							case 74:
																							case 92:
																							case 96:
																							case 100:
																							case 105:
																								goto end_IL_023d;
																							case 75:
																								goto end_IL_05d9;
																							case 25:
																								goto end_IL_05ec;
																							case 15:
																								goto end_IL_05ff;
																							case 99:
																								goto end_IL_060a;
																							case 44:
																							case 60:
																								goto end_IL_061f;
																							case 51:
																								goto end_IL_0638;
																							case 23:
																							case 33:
																								goto end_IL_0651;
																							case 26:
																								goto end_IL_0661;
																							case 27:
																								goto end_IL_067a;
																							case 30:
																							case 46:
																								goto IL_069e;
																							}
																							continue;
																							IL_05a8:
																							num5++;
																							goto IL_05b6;
																							IL_05b6:
																							ptr2 += 8;
																							goto end_IL_023d;
																							IL_056d:
																							array[num5] = 0;
																							goto IL_057b;
																							IL_057b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_059e;
																							IL_059e:
																							array2[num5] = null;
																							goto IL_05a8;
																							continue;
																							end_IL_01dd:
																							break;
																						}
																						continue;
																					}
																					goto IL_0248;
																					IL_04d6:
																					ptr2 += 8;
																					goto end_IL_023d;
																					IL_02b4:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_02dd;
																					IL_0248:
																					if (2 < b)
																					{
																						goto IL_0253;
																					}
																					goto IL_029e;
																					IL_0253:
																					if (3 >= b)
																					{
																						goto IL_0261;
																					}
																					goto IL_04e9;
																					IL_0261:
																					if (3 > b)
																					{
																						num = 48;
																						goto end_IL_020d;
																					}
																					goto IL_02f0;
																					IL_02dd:
																					ptr2 += 8;
																					goto IL_0443;
																					IL_02f0:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_023d;
																					IL_04e9:
																					if (4 < b)
																					{
																						goto end_IL_020d;
																					}
																					goto IL_04f7;
																					IL_04f7:
																					if (4 > b)
																					{
																						goto end_IL_020d;
																					}
																					goto end_IL_023d;
																					IL_029e:
																					if (2 <= b)
																					{
																						goto IL_02b4;
																					}
																					num = 82;
																					goto IL_0308;
																					IL_0443:
																					num5--;
																					goto end_IL_023d;
																					IL_0308:
																					if (1 < b)
																					{
																						goto end_IL_020d;
																					}
																					goto IL_048a;
																					IL_048a:
																					if (1 > b)
																					{
																						goto end_IL_020d;
																					}
																					goto IL_0498;
																					IL_0498:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_04b1;
																					IL_04b1:
																					array[num5] = 0;
																					num = 78;
																					goto IL_04c8;
																					IL_04c8:
																					num5++;
																					goto IL_04d6;
																					continue;
																					end_IL_01f0:
																					break;
																				}
																				continue;
																			}
																			goto IL_027d;
																			IL_0544:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_023d;
																			IL_027d:
																			if (8 >= b)
																			{
																				goto IL_028b;
																			}
																			goto IL_050a;
																			IL_028b:
																			if (8 <= b)
																			{
																				goto IL_031b;
																			}
																			goto IL_0382;
																			IL_0382:
																			if (6 >= b)
																			{
																				goto IL_038d;
																			}
																			goto IL_03f4;
																			IL_038d:
																			if (6 > b)
																			{
																				goto end_IL_020d;
																			}
																			goto IL_039b;
																			IL_039b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03db;
																			IL_03db:
																			array[num5 - 2] = 0;
																			goto IL_055d;
																			IL_055d:
																			num5--;
																			goto end_IL_023d;
																			IL_03f4:
																			if (7 < b)
																			{
																				goto end_IL_020d;
																			}
																			goto IL_0402;
																			IL_0402:
																			if (7 > b)
																			{
																				goto end_IL_020d;
																			}
																			goto IL_0410;
																			IL_0410:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0433;
																			IL_0433:
																			array[num5] = 0;
																			goto IL_0469;
																			IL_0469:
																			num5++;
																			goto IL_0477;
																			IL_0477:
																			ptr2 += 8;
																			goto end_IL_023d;
																			IL_031b:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0456;
																			IL_0456:
																			num5 -= 2;
																			goto end_IL_023d;
																			IL_050a:
																			if (9 < b)
																			{
																				goto IL_0515;
																			}
																			goto IL_0536;
																			IL_0515:
																			if (10 < b)
																			{
																				goto end_IL_020d;
																			}
																			goto IL_0523;
																			IL_0523:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_020d;
																			IL_0536:
																			if (9 > b)
																			{
																				goto end_IL_020d;
																			}
																			goto IL_0544;
																			continue;
																			end_IL_0200:
																			break;
																		}
																		continue;
																		end_IL_020d:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_023d;
																continue;
																end_IL_021d:
																break;
															}
															continue;
															end_IL_022d:
															break;
														}
														continue;
														end_IL_023d:
														break;
													}
													continue;
												}
												goto IL_069e;
												IL_069e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d9:
												break;
											}
											continue;
											end_IL_05ec:
											break;
										}
										continue;
										end_IL_05ff:
										break;
									}
									continue;
									end_IL_060a:
									break;
								}
								continue;
								end_IL_061f:
								break;
							}
							continue;
							end_IL_0638:
							break;
						}
						continue;
						end_IL_0651:
						break;
					}
					continue;
					end_IL_0661:
					break;
				}
				continue;
				end_IL_067a:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_0)
	{
		int num = 88;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 30;
					while (true)
					{
						object[] array2 = new object[2];
						num = 67;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BaseBinaryAppendAllLines.RsaAnyIMapViewToIReadOnlyDictionaryAdapter);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b3:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02a6:
																		if (b <= 10)
																		{
																			while (true)
																			{
																				IL_0296:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0289:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_0279:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_0269:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_0224:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_020b:
																															array[num5] = 0;
																															num = 68;
																															while (true)
																															{
																																IL_01f2:
																																num5++;
																																num = 116;
																																while (true)
																																{
																																	if (num != 116)
																																	{
																																		if (num != 1097)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 68:
																																			goto IL_01f2;
																																		case 56:
																																			goto IL_020b;
																																		case 96:
																																		case 97:
																																			goto IL_0224;
																																		case 54:
																																			goto IL_0249;
																																		case 33:
																																			goto IL_0259;
																																		case 70:
																																		case 104:
																																			goto IL_0269;
																																		case 49:
																																			goto IL_0279;
																																		case 42:
																																			goto IL_0289;
																																		case 7:
																																			goto end_IL_01df;
																																		case 52:
																																			goto IL_02a6;
																																		case 32:
																																			goto IL_02b3;
																																		case 65:
																																			goto end_IL_02b3;
																																		case 62:
																																		case 84:
																																			goto end_IL_02c0;
																																		case 4:
																																			goto IL_02f7;
																																		case 12:
																																			goto IL_0304;
																																		case 21:
																																			goto IL_0314;
																																		case 36:
																																			goto IL_0324;
																																		case 11:
																																			goto IL_0332;
																																		case 40:
																																		case 48:
																																			goto IL_0345;
																																		case 47:
																																			goto IL_0385;
																																		case 18:
																																		case 57:
																																			goto IL_039e;
																																		case 81:
																																			goto IL_03ba;
																																		case 24:
																																		case 53:
																																			goto IL_03c8;
																																		case 83:
																																			goto IL_03d3;
																																		case 58:
																																		case 77:
																																			goto IL_03de;
																																		case 60:
																																			goto IL_0407;
																																		case 50:
																																			goto IL_0415;
																																		case 86:
																																			goto IL_0433;
																																		case 9:
																																		case 17:
																																			goto IL_043e;
																																		case 1:
																																			goto IL_0457;
																																		case 26:
																																		case 93:
																																			goto IL_0465;
																																		case 98:
																																			goto IL_047d;
																																		case 102:
																																			goto IL_0490;
																																		case 45:
																																		case 105:
																																			goto IL_04ac;
																																		case 100:
																																			goto IL_04ba;
																																		case 16:
																																		case 43:
																																			goto IL_04c8;
																																		case 94:
																																			goto IL_04e1;
																																		case 25:
																																			goto IL_04ef;
																																		case 74:
																																			goto IL_04fd;
																																		case 34:
																																		case 106:
																																			goto IL_0510;
																																		case 35:
																																			goto IL_051e;
																																		case 90:
																																			goto IL_0541;
																																		case 15:
																																			goto IL_054b;
																																		case 38:
																																			goto IL_0559;
																																		case 13:
																																		case 14:
																																		case 19:
																																		case 20:
																																		case 23:
																																		case 27:
																																		case 28:
																																		case 37:
																																		case 39:
																																		case 41:
																																		case 46:
																																		case 61:
																																		case 64:
																																		case 66:
																																		case 69:
																																		case 71:
																																		case 73:
																																		case 75:
																																		case 76:
																																		case 78:
																																		case 80:
																																		case 82:
																																		case 89:
																																		case 107:
																																		case 109:
																																			goto end_IL_0249;
																																		case 55:
																																		case 63:
																																			goto IL_0594;
																																		case 3:
																																			goto IL_05f6;
																																		case 0:
																																		case 5:
																																		case 6:
																																		case 8:
																																		case 10:
																																		case 29:
																																		case 44:
																																		case 51:
																																		case 59:
																																		case 91:
																																		case 99:
																																		case 101:
																																		case 108:
																																			goto end_IL_02d0;
																																		case 2:
																																			goto end_IL_0604;
																																		case 103:
																																			goto end_IL_0617;
																																		case 95:
																																			goto end_IL_0621;
																																		case 22:
																																			goto end_IL_062c;
																																		case 31:
																																		case 67:
																																			goto end_IL_0641;
																																		case 30:
																																			goto end_IL_0651;
																																		case 72:
																																		case 92:
																																			goto end_IL_0661;
																																		case 87:
																																			goto end_IL_067a;
																																		case 88:
																																			goto end_IL_0693;
																																		case 79:
																																		case 85:
																																			goto IL_06ae;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_02d0;
																																	continue;
																																	end_IL_01df:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0296;
																													continue;
																													end_IL_0249:
																													break;
																													IL_0249:;
																												}
																												break;
																												IL_0259:;
																											}
																											break;
																										}
																										goto IL_0304;
																										IL_047d:
																										num5--;
																										goto end_IL_02d0;
																										IL_0304:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_0345;
																										IL_0345:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0385;
																										IL_0385:
																										array[num5 - 2] = 0;
																										goto IL_047d;
																									}
																									break;
																								}
																								goto IL_0594;
																								IL_05f6:
																								num5 -= 2;
																								goto end_IL_02d0;
																								IL_0594:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_05f6;
																							}
																							break;
																						}
																						goto IL_02f7;
																						IL_0332:
																						if (10 > b)
																						{
																						}
																						break;
																						IL_02f7:
																						if (9 >= b)
																						{
																							goto IL_0314;
																						}
																						goto IL_0324;
																						IL_0314:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_039e;
																						IL_039e:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02d0;
																						IL_0324:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0332;
																					}
																					break;
																				}
																				goto IL_03ba;
																				IL_051e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0541;
																				IL_03ba:
																				if (5 > b)
																				{
																					goto IL_03c8;
																				}
																				goto IL_0510;
																				IL_03c8:
																				if (2 >= b)
																				{
																					goto IL_03d3;
																				}
																				goto IL_0433;
																				IL_03d3:
																				if (2 <= b)
																				{
																					goto IL_03de;
																				}
																				num = 45;
																				goto IL_04ac;
																				IL_03de:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0407;
																				IL_0407:
																				ptr2 += 8;
																				goto IL_0415;
																				IL_0415:
																				num5--;
																				goto end_IL_02d0;
																				IL_0541:
																				array2[num5] = null;
																				goto IL_054b;
																				IL_04ac:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_04ba;
																				IL_04ba:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_04c8;
																				IL_04c8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04e1;
																				IL_04e1:
																				array[num5] = 0;
																				goto IL_04ef;
																				IL_04ef:
																				num5++;
																				goto IL_04fd;
																				IL_04fd:
																				ptr2 += 8;
																				goto end_IL_02d0;
																				IL_0433:
																				if (3 < b)
																				{
																					goto IL_043e;
																				}
																				goto IL_0457;
																				IL_043e:
																				if (4 < b)
																				{
																					num = 82;
																					break;
																				}
																				goto IL_0490;
																				IL_054b:
																				num5++;
																				goto IL_0559;
																				IL_0490:
																				if (4 <= b)
																				{
																					goto end_IL_02d0;
																				}
																				num = 20;
																				break;
																				IL_0559:
																				ptr2 += 8;
																				goto end_IL_02d0;
																				IL_0457:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0465;
																				IL_0465:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02d0;
																				IL_0510:
																				array[num5] = 0;
																				goto IL_051e;
																			}
																		}
																		else
																		{
																			num = 61;
																		}
																		break;
																	}
																}
																else
																{
																	num = 64;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d0;
																continue;
																end_IL_02b3:
																break;
															}
															continue;
															end_IL_02c0:
															break;
														}
														continue;
														end_IL_02d0:
														break;
													}
													continue;
												}
												goto IL_06ae;
												IL_06ae:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0604:
												break;
											}
											continue;
											end_IL_0617:
											break;
										}
										continue;
										end_IL_0621:
										break;
									}
									continue;
									end_IL_062c:
									break;
								}
								continue;
								end_IL_0641:
								break;
							}
							continue;
							end_IL_0651:
							break;
						}
						continue;
						end_IL_0661:
						break;
					}
					continue;
					end_IL_067a:
					break;
				}
				continue;
				end_IL_0693:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_0)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref indexConfigEvents.ReadWriteTaskIMethodMessage);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 121;
											while (true)
											{
												if (num == 121)
												{
													goto IL_0294;
												}
												if (num != 1102)
												{
													goto IL_0531;
												}
												switch (num)
												{
												case 55:
													goto end_IL_01f3;
												case 8:
													goto end_IL_0206;
												case 20:
													goto end_IL_0219;
												case 60:
													goto end_IL_0224;
												case 33:
												case 42:
													goto end_IL_0239;
												case 92:
													goto end_IL_0249;
												case 30:
												case 35:
													goto end_IL_0259;
												case 5:
													goto end_IL_0269;
												case 6:
													goto end_IL_0279;
												case 3:
												case 11:
												case 14:
												case 28:
												case 34:
												case 36:
												case 37:
												case 64:
												case 82:
												case 83:
												case 91:
												case 100:
												case 103:
													goto IL_0294;
												case 9:
												case 22:
													goto IL_02a4;
												case 79:
													goto IL_02b6;
												case 81:
													goto IL_02c4;
												case 95:
													goto IL_02d2;
												case 93:
													goto IL_02e0;
												case 24:
												case 97:
													goto IL_02ee;
												case 105:
													goto IL_02fc;
												case 13:
												case 89:
													goto IL_0307;
												case 56:
													goto IL_0369;
												case 58:
													goto IL_037c;
												case 40:
													goto IL_0387;
												case 1:
												case 84:
													goto IL_0395;
												case 110:
													goto IL_03d5;
												case 63:
													goto IL_03e9;
												case 113:
													goto IL_0405;
												case 4:
													goto IL_0413;
												case 10:
												case 26:
													goto IL_0421;
												case 108:
													goto IL_044d;
												case 44:
													goto IL_045b;
												case 66:
													goto IL_0469;
												case 16:
													goto IL_047c;
												case 41:
												case 114:
													goto IL_0490;
												case 46:
													goto IL_049e;
												case 73:
													goto IL_04b1;
												case 76:
												case 78:
													goto IL_04bf;
												case 101:
													goto IL_04db;
												case 38:
												case 85:
													goto IL_04e9;
												case 32:
												case 50:
													goto IL_04f7;
												case 71:
													goto IL_0502;
												case 96:
													goto IL_0515;
												case 61:
													goto IL_0523;
												case 31:
												case 65:
													goto IL_0531;
												case 102:
													goto IL_053f;
												case 70:
													goto IL_0562;
												case 52:
													goto IL_056c;
												case 12:
													goto IL_057a;
												case 2:
													goto IL_058d;
												case 43:
												case 111:
													goto IL_0598;
												case 88:
													goto IL_05b0;
												case 45:
												case 48:
													goto IL_05bb;
												case 106:
													goto IL_05c9;
												case 17:
												case 19:
													goto IL_05d7;
												case 51:
													goto IL_0600;
												case 107:
													goto IL_060e;
												case 47:
													goto IL_0621;
												case 7:
												case 59:
													goto IL_062f;
												case 39:
													goto IL_0648;
												case 72:
													goto IL_0656;
												case 86:
													goto IL_0664;
												case 57:
												case 99:
													goto IL_0677;
												case 90:
													goto IL_06b7;
												case 0:
													goto IL_06cb;
												case 15:
												case 18:
												case 21:
												case 23:
												case 25:
												case 27:
												case 29:
												case 49:
												case 53:
												case 54:
												case 67:
												case 68:
												case 69:
												case 74:
												case 75:
												case 77:
												case 87:
												case 94:
												case 98:
												case 104:
												case 109:
												case 112:
													goto IL_06e7;
												case 62:
												case 80:
													goto IL_0711;
												}
												continue;
												IL_0677:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_06b7;
												IL_06b7:
												array[num4 - 2] = 0;
												goto IL_06cb;
												IL_0294:
												if (num5 != 1)
												{
													goto IL_02a4;
												}
												num = 80;
												goto IL_0711;
												IL_06cb:
												num4--;
												num = 82;
												goto IL_0294;
												IL_0711:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_02a4:
												b = *ptr2;
												num = 79;
												goto IL_02b6;
												IL_02b6:
												ptr2++;
												goto IL_02c4;
												IL_02c4:
												if (b >= 1)
												{
													goto IL_02d2;
												}
												goto IL_06e7;
												IL_02d2:
												if (b <= 11)
												{
													goto IL_02e0;
												}
												goto IL_06e7;
												IL_02e0:
												if (6 < b)
												{
													goto IL_02ee;
												}
												goto IL_04db;
												IL_02ee:
												if (9 >= b)
												{
													goto IL_02fc;
												}
												goto IL_047c;
												IL_02fc:
												if (9 <= b)
												{
													goto IL_0307;
												}
												goto IL_037c;
												IL_0307:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0369;
												IL_0369:
												num4 -= 2;
												goto IL_0294;
												IL_037c:
												if (7 >= b)
												{
													goto IL_0387;
												}
												goto IL_0405;
												IL_0387:
												if (7 <= b)
												{
													goto IL_0395;
												}
												goto IL_06e7;
												IL_0395:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_03d5;
												IL_03d5:
												array[num4 - 2] = 0;
												goto IL_03e9;
												IL_03e9:
												num4--;
												num = 14;
												goto IL_0294;
												IL_0405:
												if (8 >= b)
												{
													goto IL_0413;
												}
												goto IL_06e7;
												IL_0413:
												if (8 <= b)
												{
													goto IL_0421;
												}
												goto IL_06e7;
												IL_0421:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												num = 108;
												goto IL_044d;
												IL_044d:
												array[num4] = 0;
												goto IL_045b;
												IL_045b:
												num4++;
												goto IL_0469;
												IL_0469:
												ptr2 += 8;
												goto IL_0294;
												IL_047c:
												if (10 < b)
												{
													num = 41;
													goto IL_0490;
												}
												goto IL_04b1;
												IL_06e7:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 103;
												goto IL_0294;
												IL_0490:
												if (11 >= b)
												{
													goto IL_049e;
												}
												goto IL_06e7;
												IL_049e:
												if (11 > b)
												{
												}
												goto IL_06e7;
												IL_04b1:
												if (10 <= b)
												{
													goto IL_04bf;
												}
												goto IL_06e7;
												IL_04bf:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												goto IL_0294;
												IL_04db:
												if (6 > b)
												{
													goto IL_04e9;
												}
												goto IL_0677;
												IL_04e9:
												if (3 < b)
												{
													goto IL_04f7;
												}
												goto IL_058d;
												IL_04f7:
												if (4 >= b)
												{
													goto IL_0502;
												}
												goto IL_0515;
												IL_0502:
												if (4 <= b)
												{
													goto IL_0294;
												}
												goto IL_06e7;
												IL_0515:
												if (5 >= b)
												{
													goto IL_0523;
												}
												goto IL_06e7;
												IL_0523:
												if (5 <= b)
												{
													goto IL_0531;
												}
												goto IL_06e7;
												IL_0531:
												array[num4] = 0;
												goto IL_053f;
												IL_053f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0562;
												IL_0562:
												array2[num4] = null;
												goto IL_056c;
												IL_056c:
												num4++;
												goto IL_057a;
												IL_057a:
												ptr2 += 8;
												goto IL_0294;
												IL_058d:
												if (3 <= b)
												{
													goto IL_0598;
												}
												goto IL_05b0;
												IL_0598:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0294;
												IL_05b0:
												if (1 < b)
												{
													goto IL_05bb;
												}
												goto IL_0621;
												IL_05bb:
												if (2 >= b)
												{
													goto IL_05c9;
												}
												goto IL_06e7;
												IL_05c9:
												if (2 <= b)
												{
													goto IL_05d7;
												}
												goto IL_06e7;
												IL_05d7:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0600;
												IL_0600:
												ptr2 += 8;
												goto IL_060e;
												IL_060e:
												num4--;
												goto IL_0294;
												IL_0621:
												if (1 <= b)
												{
													goto IL_062f;
												}
												goto IL_06e7;
												IL_062f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												goto IL_0648;
												IL_0648:
												array[num4] = 0;
												goto IL_0656;
												IL_0656:
												num4++;
												goto IL_0664;
												IL_0664:
												ptr2 += 8;
												goto IL_0294;
												continue;
												end_IL_01f3:
												break;
											}
											continue;
											end_IL_0206:
											break;
										}
										continue;
										end_IL_0219:
										break;
									}
									continue;
									end_IL_0224:
									break;
								}
								continue;
								end_IL_0239:
								break;
							}
							continue;
							end_IL_0249:
							break;
						}
						continue;
						end_IL_0259:
						break;
					}
					continue;
					end_IL_0269:
					break;
				}
				continue;
				end_IL_0279:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 23;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 22;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDeltagetByteLength.IFileAssociationEntryHasProperties);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0246:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0229:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_0219:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_0209:
																								if (7 >= b)
																								{
																									while (7 <= b)
																									{
																										num = 83;
																										while (true)
																										{
																											IL_01e6:
																											array[num5] = 0;
																											while (true)
																											{
																												IL_01c1:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												while (true)
																												{
																													IL_01b5:
																													array2[num5] = null;
																													while (true)
																													{
																														IL_019c:
																														num5++;
																														num = 91;
																														while (true)
																														{
																															if (num != 91)
																															{
																																if (num != 1072)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 53:
																																	goto IL_019c;
																																case 70:
																																	goto IL_01b5;
																																case 0:
																																	goto IL_01c1;
																																case 48:
																																case 83:
																																	goto IL_01e6;
																																case 43:
																																	goto IL_01f6;
																																case 30:
																																case 77:
																																	goto IL_0209;
																																case 1:
																																	goto IL_0219;
																																case 49:
																																	goto IL_0229;
																																case 15:
																																	goto IL_0236;
																																case 66:
																																	goto IL_0246;
																																case 35:
																																	goto end_IL_0246;
																																case 4:
																																case 69:
																																	goto end_IL_0256;
																																case 64:
																																	goto IL_0271;
																																case 6:
																																	goto IL_027f;
																																case 21:
																																	goto IL_028d;
																																case 25:
																																case 47:
																																	goto IL_029b;
																																case 34:
																																	goto IL_0309;
																																case 45:
																																	goto IL_031c;
																																case 58:
																																	goto IL_032a;
																																case 7:
																																case 32:
																																	goto IL_033a;
																																case 33:
																																	goto IL_0363;
																																case 54:
																																	goto IL_0371;
																																case 13:
																																case 73:
																																	goto IL_0384;
																																case 11:
																																	goto IL_03c4;
																																case 78:
																																	goto IL_03da;
																																case 9:
																																	goto IL_03e8;
																																case 84:
																																	goto IL_03fb;
																																case 31:
																																	goto IL_0421;
																																case 61:
																																	goto IL_042c;
																																case 57:
																																case 80:
																																	goto IL_0437;
																																case 37:
																																	goto IL_0453;
																																case 19:
																																	goto IL_045e;
																																case 62:
																																	goto IL_0469;
																																case 3:
																																case 20:
																																	goto IL_0474;
																																case 2:
																																case 5:
																																case 10:
																																case 12:
																																case 26:
																																case 27:
																																case 28:
																																case 36:
																																case 46:
																																case 56:
																																case 59:
																																case 63:
																																case 74:
																																case 75:
																																case 76:
																																	goto end_IL_0189;
																																case 67:
																																	goto IL_04ac;
																																case 79:
																																	goto IL_04ba;
																																case 72:
																																	goto IL_04c8;
																																case 14:
																																case 17:
																																case 18:
																																case 24:
																																case 29:
																																case 38:
																																case 40:
																																case 44:
																																case 50:
																																case 68:
																																case 81:
																																	goto end_IL_0266;
																																case 16:
																																	goto end_IL_04d6;
																																case 55:
																																	goto end_IL_04e9;
																																case 42:
																																	goto end_IL_04f3;
																																case 71:
																																	goto end_IL_04fe;
																																case 82:
																																	goto end_IL_0513;
																																case 51:
																																case 52:
																																	goto end_IL_0528;
																																case 60:
																																	goto end_IL_0538;
																																case 39:
																																case 41:
																																	goto end_IL_0548;
																																case 22:
																																	goto end_IL_0558;
																																case 23:
																																	goto end_IL_0568;
																																case 8:
																																case 65:
																																	goto IL_058c;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															goto end_IL_0266;
																															continue;
																															end_IL_0189:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																										IL_01f6:;
																									}
																									break;
																								}
																								goto IL_0421;
																								IL_0437:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_0266;
																								IL_0421:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_042c;
																								IL_042c:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_0437;
																							}
																							break;
																						}
																						goto IL_0453;
																						IL_0474:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0266;
																						IL_0453:
																						if (6 <= b)
																						{
																							goto end_IL_0266;
																						}
																						goto IL_045e;
																						IL_045e:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_0469;
																						IL_0469:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0474;
																					}
																					break;
																				}
																				goto IL_0271;
																				IL_0371:
																				num5--;
																				goto end_IL_0266;
																				IL_0271:
																				if (4 > b)
																				{
																					goto IL_027f;
																				}
																				goto IL_033a;
																				IL_027f:
																				if (2 >= b)
																				{
																					goto IL_028d;
																				}
																				goto IL_031c;
																				IL_028d:
																				if (2 <= b)
																				{
																					goto IL_029b;
																				}
																				goto IL_03da;
																				IL_029b:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0309;
																				IL_0309:
																				num5 -= 2;
																				goto end_IL_0266;
																				IL_03da:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_03e8;
																				IL_03e8:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_031c:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_032a;
																				IL_032a:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0384;
																				IL_0384:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03c4;
																				IL_03c4:
																				array[num5 - 2] = 0;
																				goto IL_03fb;
																				IL_03fb:
																				num5--;
																				goto end_IL_0266;
																				IL_033a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0363;
																				IL_0363:
																				ptr2 += 8;
																				goto IL_0371;
																			}
																			break;
																			IL_0236:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04ac;
																	IL_04c8:
																	ptr2 += 8;
																	goto end_IL_0266;
																	IL_04ba:
																	num5++;
																	goto IL_04c8;
																	IL_04ac:
																	array[num5] = 0;
																	goto IL_04ba;
																	continue;
																	end_IL_0246:
																	break;
																}
																continue;
																end_IL_0256:
																break;
															}
															continue;
															end_IL_0266:
															break;
														}
														continue;
													}
													goto IL_058c;
													IL_058c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04d6:
													break;
												}
												continue;
												end_IL_04e9:
												break;
											}
											continue;
											end_IL_04f3:
											break;
										}
										continue;
										end_IL_04fe:
										break;
									}
									continue;
									end_IL_0513:
									break;
								}
								continue;
								end_IL_0528:
								break;
							}
							continue;
							end_IL_0538:
							break;
						}
						continue;
						end_IL_0548:
						break;
					}
					continue;
					end_IL_0558:
					break;
				}
				continue;
				end_IL_0568:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 107;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 87;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadBufferAsyncdgetAsError.StringToCoTaskMemAutogetIsEvent);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02e8:
															byte b = *ptr2;
															while (true)
															{
																IL_02cf:
																ptr2++;
																num = 63;
																while (true)
																{
																	IL_02bf:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02a2:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0292:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0282:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0272:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0262:
																												if (1 >= b)
																												{
																													while (1 <= b)
																													{
																														while (true)
																														{
																															IL_0237:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_0227:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_0217:
																																	num5++;
																																	while (true)
																																	{
																																		IL_01fe:
																																		ptr2 += 8;
																																		num = 119;
																																		while (num != 119)
																																		{
																																			if (num != 1100)
																																			{
																																				goto IL_0227;
																																			}
																																			switch (num)
																																			{
																																			case 42:
																																				goto IL_01fe;
																																			case 33:
																																				goto IL_0217;
																																			case 59:
																																				goto IL_0227;
																																			case 62:
																																			case 75:
																																				goto IL_0237;
																																			case 78:
																																				goto IL_0252;
																																			case 100:
																																				goto IL_0262;
																																			case 32:
																																				goto IL_0272;
																																			case 35:
																																			case 39:
																																				goto IL_0282;
																																			case 20:
																																				goto IL_0292;
																																			case 79:
																																				goto IL_02a2;
																																			case 45:
																																				goto IL_02af;
																																			case 63:
																																				goto IL_02bf;
																																			case 93:
																																				goto IL_02cf;
																																			case 1:
																																			case 8:
																																				goto IL_02e8;
																																			case 85:
																																				goto IL_02f3;
																																			case 90:
																																				goto IL_030c;
																																			case 9:
																																			case 86:
																																				goto IL_031a;
																																			case 14:
																																			case 26:
																																				goto IL_0325;
																																			case 89:
																																				goto IL_0333;
																																			case 58:
																																				goto IL_0346;
																																			case 36:
																																			case 84:
																																				goto IL_0354;
																																			case 28:
																																				goto IL_0394;
																																			case 37:
																																				goto IL_03b1;
																																			case 60:
																																			case 70:
																																				goto IL_03c4;
																																			case 80:
																																				goto IL_042f;
																																			case 40:
																																			case 97:
																																				goto IL_0442;
																																			case 24:
																																				goto IL_046e;
																																			case 77:
																																				goto IL_047c;
																																			case 43:
																																				goto IL_048a;
																																			case 95:
																																			case 102:
																																				goto IL_049d;
																																			case 21:
																																				goto IL_04ab;
																																			case 67:
																																			case 94:
																																				goto IL_04b9;
																																			case 88:
																																				goto IL_04e2;
																																			case 52:
																																			case 103:
																																				goto IL_04f2;
																																			case 23:
																																			case 72:
																																				goto IL_04fd;
																																			case 68:
																																				goto IL_050b;
																																			case 50:
																																				goto IL_0527;
																																			case 10:
																																			case 73:
																																				goto IL_0535;
																																			case 112:
																																				goto IL_0551;
																																			case 5:
																																			case 11:
																																				goto IL_0564;
																																			case 19:
																																				goto IL_057c;
																																			case 7:
																																				goto IL_0587;
																																			case 109:
																																				goto IL_059a;
																																			case 96:
																																				goto IL_05a8;
																																			case 34:
																																			case 69:
																																				goto IL_05bf;
																																			case 76:
																																				goto IL_05d6;
																																			case 81:
																																				goto IL_05f9;
																																			case 54:
																																				goto IL_0603;
																																			case 48:
																																				goto IL_0611;
																																			case 27:
																																			case 55:
																																				goto IL_0621;
																																			case 101:
																																				goto IL_0661;
																																			case 17:
																																				goto IL_0675;
																																			case 6:
																																			case 15:
																																			case 16:
																																			case 31:
																																			case 41:
																																			case 44:
																																			case 47:
																																			case 51:
																																			case 61:
																																			case 64:
																																			case 65:
																																			case 66:
																																			case 71:
																																			case 74:
																																			case 83:
																																			case 98:
																																			case 99:
																																			case 105:
																																			case 108:
																																				goto end_IL_0252;
																																			case 4:
																																			case 12:
																																			case 18:
																																			case 22:
																																			case 25:
																																			case 30:
																																			case 38:
																																			case 46:
																																			case 49:
																																			case 53:
																																			case 56:
																																			case 91:
																																			case 92:
																																				goto end_IL_01eb;
																																			case 111:
																																				goto end_IL_0698;
																																			case 13:
																																				goto end_IL_06ab;
																																			case 110:
																																				goto end_IL_06b5;
																																			case 2:
																																				goto end_IL_06c0;
																																			case 29:
																																			case 104:
																																				goto end_IL_06d5;
																																			case 57:
																																				goto end_IL_06e5;
																																			case 87:
																																				goto end_IL_06f5;
																																			case 3:
																																				goto end_IL_0705;
																																			case 106:
																																				goto end_IL_0715;
																																			case 107:
																																				goto end_IL_0720;
																																			case 0:
																																			case 82:
																																				goto IL_073b;
																																			}
																																			continue;
																																			end_IL_01eb:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02bf;
																														continue;
																														end_IL_0252:
																														break;
																														IL_0252:;
																													}
																													break;
																												}
																												goto IL_049d;
																												IL_0551:
																												num5--;
																												goto end_IL_02bf;
																												IL_049d:
																												if (2 < b)
																												{
																													break;
																												}
																												goto IL_04ab;
																												IL_04ab:
																												if (2 > b)
																												{
																													break;
																												}
																												goto IL_04b9;
																												IL_04b9:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_04e2;
																												IL_04e2:
																												ptr2 += 8;
																												goto IL_0551;
																											}
																											break;
																										}
																										goto IL_0564;
																										IL_0564:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02bf;
																									}
																									break;
																								}
																								goto IL_057c;
																								IL_0603:
																								num5++;
																								goto IL_0611;
																								IL_057c:
																								if (4 >= b)
																								{
																									goto IL_0587;
																								}
																								goto IL_059a;
																								IL_0587:
																								if (4 > b)
																								{
																									break;
																								}
																								goto end_IL_02bf;
																								IL_059a:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_05a8;
																								IL_05a8:
																								if (5 > b)
																								{
																									break;
																								}
																								num = 69;
																								goto IL_05bf;
																								IL_0611:
																								ptr2 += 8;
																								goto end_IL_02bf;
																								IL_05bf:
																								array[num5] = 0;
																								num = 76;
																								goto IL_05d6;
																								IL_05d6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_05f9;
																								IL_05f9:
																								array2[num5] = null;
																								goto IL_0603;
																							}
																							break;
																						}
																						goto IL_0621;
																						IL_0675:
																						num5--;
																						goto end_IL_02bf;
																						IL_0621:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0661;
																						IL_0661:
																						array[num5 - 2] = 0;
																						goto IL_0675;
																					}
																					break;
																				}
																				goto IL_02f3;
																				IL_03b1:
																				num5--;
																				goto end_IL_02bf;
																				IL_02f3:
																				if (9 >= b)
																				{
																					goto IL_030c;
																				}
																				num = 103;
																				goto IL_04f2;
																				IL_03c4:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 80;
																				goto IL_042f;
																				IL_04f2:
																				if (10 < b)
																				{
																					goto IL_04fd;
																				}
																				goto IL_0527;
																				IL_04fd:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_050b;
																				IL_050b:
																				if (11 > b)
																				{
																					num = 65;
																				}
																				break;
																				IL_042f:
																				num5 -= 2;
																				goto end_IL_02bf;
																				IL_0527:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0535;
																				IL_0535:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02bf;
																				IL_030c:
																				if (9 > b)
																				{
																					goto IL_031a;
																				}
																				goto IL_03c4;
																				IL_031a:
																				if (7 < b)
																				{
																					goto IL_0325;
																				}
																				goto IL_0346;
																				IL_0325:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0333;
																				IL_0333:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0442;
																				IL_0442:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 24;
																				goto IL_046e;
																				IL_046e:
																				array[num5] = 0;
																				goto IL_047c;
																				IL_047c:
																				num5++;
																				goto IL_048a;
																				IL_048a:
																				ptr2 += 8;
																				goto end_IL_02bf;
																				IL_0346:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0354;
																				IL_0354:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0394;
																				IL_0394:
																				array[num5 - 2] = 0;
																				num = 37;
																				goto IL_03b1;
																			}
																			break;
																			IL_02af:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02bf:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_073b;
													IL_073b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0698:
													break;
												}
												continue;
												end_IL_06ab:
												break;
											}
											continue;
											end_IL_06b5:
											break;
										}
										continue;
										end_IL_06c0:
										break;
									}
									continue;
									end_IL_06d5:
									break;
								}
								continue;
								end_IL_06e5:
								break;
							}
							continue;
							end_IL_06f5:
							break;
						}
						continue;
						end_IL_0705:
						break;
					}
					continue;
					end_IL_0715:
					break;
				}
				continue;
				end_IL_0720:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_0)
	{
		int num = 95;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 94;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRuleSetIsThreadOwnerTrackingEnabled.SwitchWrappersFromDefaultContext);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02c6:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02a6:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0296:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0286:
																							if (9 > b)
																							{
																								num = 110;
																								while (true)
																								{
																									IL_0276:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											while (8 <= b)
																											{
																												while (true)
																												{
																													IL_0231:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													while (true)
																													{
																														IL_0218:
																														array[num5] = 0;
																														num = 122;
																														while (true)
																														{
																															if (num != 122)
																															{
																																if (num != 1103)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 3:
																																	goto IL_0218;
																																case 28:
																																case 106:
																																	goto IL_0231;
																																case 7:
																																	goto IL_0256;
																																case 45:
																																case 51:
																																	goto IL_0266;
																																case 9:
																																case 110:
																																	goto end_IL_0205;
																																case 18:
																																	goto IL_0286;
																																case 100:
																																	goto IL_0296;
																																case 72:
																																	goto IL_02a6;
																																case 92:
																																	goto IL_02b6;
																																case 70:
																																	goto IL_02c6;
																																case 65:
																																	goto end_IL_02c6;
																																case 44:
																																case 74:
																																	goto end_IL_02d6;
																																case 22:
																																case 41:
																																	goto IL_02f1;
																																case 8:
																																	goto IL_0353;
																																case 80:
																																case 86:
																																	goto IL_0366;
																																case 89:
																																	goto IL_0379;
																																case 47:
																																case 63:
																																	goto IL_0387;
																																case 57:
																																	goto IL_0395;
																																case 10:
																																case 33:
																																	goto IL_03ac;
																																case 66:
																																	goto IL_03ba;
																																case 12:
																																case 35:
																																	goto IL_03c8;
																																case 32:
																																	goto IL_03e1;
																																case 78:
																																	goto IL_03ef;
																																case 38:
																																	goto IL_03fd;
																																case 23:
																																case 68:
																																	goto IL_0410;
																																case 34:
																																	goto IL_0450;
																																case 77:
																																	goto IL_046d;
																																case 24:
																																case 96:
																																	goto IL_0480;
																																case 99:
																																case 101:
																																	goto IL_0498;
																																case 97:
																																	goto IL_04a6;
																																case 46:
																																case 58:
																																	goto IL_04bd;
																																case 73:
																																	goto IL_04e6;
																																case 6:
																																	goto IL_04fd;
																																case 105:
																																	goto IL_0510;
																																case 31:
																																	goto IL_051e;
																																case 109:
																																	goto IL_0531;
																																case 30:
																																case 39:
																																	goto IL_053f;
																																case 67:
																																case 115:
																																	goto IL_0564;
																																case 25:
																																case 82:
																																	goto IL_0572;
																																case 17:
																																	goto IL_0589;
																																case 43:
																																case 107:
																																	goto IL_0597;
																																case 13:
																																	goto IL_05ae;
																																case 20:
																																	goto IL_05d1;
																																case 2:
																																	goto IL_05db;
																																case 50:
																																	goto IL_05e9;
																																case 14:
																																	goto IL_05fc;
																																case 15:
																																	goto IL_061d;
																																case 98:
																																	goto IL_0630;
																																case 88:
																																case 90:
																																	goto IL_0644;
																																case 69:
																																	goto IL_0684;
																																case 5:
																																	goto IL_0698;
																																case 0:
																																case 19:
																																case 27:
																																case 29:
																																case 36:
																																case 37:
																																case 48:
																																case 49:
																																case 56:
																																case 59:
																																case 64:
																																case 71:
																																case 76:
																																case 79:
																																case 81:
																																case 83:
																																case 91:
																																case 93:
																																case 104:
																																case 111:
																																	goto end_IL_0256;
																																case 11:
																																case 40:
																																case 42:
																																case 52:
																																case 53:
																																case 54:
																																case 55:
																																case 60:
																																case 61:
																																case 62:
																																case 75:
																																case 102:
																																case 112:
																																case 113:
																																	goto end_IL_02e6;
																																case 114:
																																	goto end_IL_06bb;
																																case 108:
																																	goto end_IL_06ce;
																																case 4:
																																	goto end_IL_06d8;
																																case 26:
																																	goto end_IL_06e3;
																																case 16:
																																case 87:
																																	goto end_IL_06f8;
																																case 103:
																																	goto end_IL_0708;
																																case 1:
																																case 85:
																																	goto end_IL_0718;
																																case 94:
																																	goto end_IL_0728;
																																case 95:
																																	goto end_IL_0738;
																																case 21:
																																case 84:
																																	goto IL_075c;
																																}
																																continue;
																															}
																															num5++;
																															goto IL_061d;
																															IL_061d:
																															ptr2 += 8;
																															goto end_IL_02e6;
																															continue;
																															end_IL_0205:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0276;
																												continue;
																												end_IL_0256:
																												break;
																												IL_0256:;
																											}
																											break;
																											IL_0266:;
																										}
																										break;
																									}
																									goto IL_0630;
																									IL_0684:
																									array[num5 - 2] = 0;
																									goto IL_0698;
																									IL_0630:
																									if (7 > b)
																									{
																										break;
																									}
																									num = 90;
																									goto IL_0644;
																									IL_0698:
																									num5--;
																									goto end_IL_02e6;
																									IL_0644:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0684;
																								}
																								break;
																							}
																							goto IL_02f1;
																							IL_02f1:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0353;
																							IL_0353:
																							num5 -= 2;
																							goto end_IL_02e6;
																						}
																						break;
																					}
																					goto IL_0366;
																					IL_051e:
																					if (11 <= b)
																					{
																					}
																					break;
																					IL_0366:
																					if (10 < b)
																					{
																						goto IL_0510;
																					}
																					goto IL_0531;
																					IL_0531:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_053f;
																					IL_053f:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 75;
																					goto end_IL_02e6;
																					IL_0510:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_051e;
																				}
																				break;
																			}
																			goto IL_0379;
																			IL_05fc:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02e6;
																			IL_0379:
																			if (6 > b)
																			{
																				goto IL_0387;
																			}
																			goto IL_0410;
																			IL_0387:
																			if (3 >= b)
																			{
																				goto IL_0395;
																			}
																			goto IL_0564;
																			IL_0395:
																			if (3 > b)
																			{
																				num = 33;
																				goto IL_03ac;
																			}
																			goto IL_0480;
																			IL_0410:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0450;
																			IL_03ac:
																			if (1 >= b)
																			{
																				goto IL_03ba;
																			}
																			goto IL_0498;
																			IL_03ba:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_03c8;
																			IL_03c8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_03e1;
																			IL_03e1:
																			array[num5] = 0;
																			goto IL_03ef;
																			IL_03ef:
																			num5++;
																			goto IL_03fd;
																			IL_03fd:
																			ptr2 += 8;
																			goto end_IL_02e6;
																			IL_0498:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04a6;
																			IL_04a6:
																			if (2 > b)
																			{
																				break;
																			}
																			num = 58;
																			goto IL_04bd;
																			IL_0450:
																			array[num5 - 2] = 0;
																			num = 77;
																			goto IL_046d;
																			IL_04bd:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e6;
																			IL_04e6:
																			ptr2 += 8;
																			num = 6;
																			goto IL_04fd;
																			IL_04fd:
																			num5--;
																			goto end_IL_02e6;
																			IL_0480:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02e6;
																			IL_0564:
																			if (4 < b)
																			{
																				goto IL_0572;
																			}
																			goto IL_05fc;
																			IL_0572:
																			if (5 < b)
																			{
																				break;
																			}
																			num = 17;
																			goto IL_0589;
																			IL_046d:
																			num5--;
																			goto end_IL_02e6;
																			IL_0589:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0597;
																			IL_0597:
																			array[num5] = 0;
																			num = 13;
																			goto IL_05ae;
																			IL_05ae:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05d1;
																			IL_05d1:
																			array2[num5] = null;
																			goto IL_05db;
																			IL_05db:
																			num5++;
																			goto IL_05e9;
																			IL_05e9:
																			ptr2 += 8;
																			goto end_IL_02e6;
																		}
																		break;
																		IL_02b6:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02e6;
																continue;
																end_IL_02c6:
																break;
															}
															continue;
															end_IL_02d6:
															break;
														}
														continue;
														end_IL_02e6:
														break;
													}
													continue;
												}
												goto IL_075c;
												IL_075c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06bb:
												break;
											}
											continue;
											end_IL_06ce:
											break;
										}
										continue;
										end_IL_06d8:
										break;
									}
									continue;
									end_IL_06e3:
									break;
								}
								continue;
								end_IL_06f8:
								break;
							}
							continue;
							end_IL_0708:
							break;
						}
						continue;
						end_IL_0718:
						break;
					}
					continue;
					end_IL_0728:
					break;
				}
				continue;
				end_IL_0738:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0, int int_1)
	{
		int num = 45;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 44;
			while (true)
			{
				int num3 = num2 * 4;
				num = 15;
				while (true)
				{
					IL_06c0:
					byte[] array = new byte[3];
					while (true)
					{
						IL_06b0:
						object[] array2 = new object[3];
						while (true)
						{
							IL_06a0:
							int[] array3 = new int[5];
							while (true)
							{
								IL_0690:
								long[] array4 = new long[3];
								while (true)
								{
									IL_067b:
									array3[0] = int_0;
									while (true)
									{
										IL_0666:
										array3[1] = int_1;
										while (true)
										{
											IL_065b:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CommonProgramFilesXTypeFilter.EventPayloadOutputBlockSize);
											while (true)
											{
												IL_0651:
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_038c:
															byte b = *ptr2;
															while (true)
															{
																IL_037c:
																ptr2++;
																while (true)
																{
																	IL_036f:
																	if (b < 1)
																	{
																		goto IL_0337;
																	}
																	goto IL_035f;
																	IL_035f:
																	if (b <= 9)
																	{
																		goto IL_000e;
																	}
																	goto IL_0337;
																	IL_000e:
																	if (5 >= b)
																	{
																		num = 17;
																		goto IL_0025;
																	}
																	goto IL_0283;
																	IL_049a:
																	array[num5] = 0;
																	goto IL_04a8;
																	IL_0283:
																	if (7 < b)
																	{
																		goto IL_028e;
																	}
																	num = 95;
																	goto IL_02f5;
																	IL_04a8:
																	num5++;
																	goto IL_04b6;
																	IL_02f5:
																	if (7 > b)
																	{
																		goto IL_0303;
																	}
																	goto IL_0481;
																	IL_0303:
																	if (6 >= b)
																	{
																		goto IL_030e;
																	}
																	goto IL_0337;
																	IL_0337:
																	while (true)
																	{
																		IL_0337_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_0263:
																			array[num5] = 0;
																			while (true)
																			{
																				IL_0253:
																				num5++;
																				while (true)
																				{
																					IL_023a:
																					ptr2 += 8;
																					num = 113;
																					while (num != 113)
																					{
																						if (num != 1094)
																						{
																							goto end_IL_063e;
																						}
																						switch (num)
																						{
																						case 78:
																							break;
																						case 17:
																							goto IL_0025;
																						case 57:
																						case 63:
																							goto IL_0033;
																						case 20:
																						case 80:
																							goto IL_0041;
																						case 37:
																							goto IL_004f;
																						default:
																							continue;
																						case 59:
																							goto IL_023a;
																						case 73:
																							goto IL_0253;
																						case 6:
																							goto IL_0263;
																						case 28:
																							goto IL_0273;
																						case 74:
																							goto IL_0283;
																						case 8:
																							goto IL_028e;
																						case 36:
																						case 77:
																							goto IL_02a6;
																						case 51:
																							goto IL_02b4;
																						case 33:
																						case 82:
																							goto IL_02ca;
																						case 25:
																							goto IL_02d5;
																						case 94:
																							goto IL_02e5;
																						case 95:
																							goto IL_02f5;
																						case 23:
																						case 85:
																							goto IL_0303;
																						case 89:
																							goto IL_030e;
																						case 18:
																						case 103:
																							goto IL_031e;
																						case 101:
																							goto IL_0329;
																						case 0:
																						case 3:
																						case 4:
																						case 7:
																						case 14:
																						case 21:
																						case 31:
																						case 35:
																						case 48:
																						case 49:
																						case 52:
																						case 67:
																						case 72:
																						case 76:
																						case 84:
																						case 86:
																						case 91:
																						case 92:
																							goto IL_0337_2;
																						case 93:
																							goto IL_035f;
																						case 12:
																							goto IL_036f;
																						case 40:
																							goto IL_037c;
																						case 41:
																						case 90:
																							goto IL_038c;
																						case 53:
																						case 75:
																							goto IL_0397;
																						case 64:
																							goto IL_03d7;
																						case 11:
																							goto IL_03eb;
																						case 1:
																						case 13:
																							goto IL_03fe;
																						case 5:
																						case 87:
																							goto IL_041a;
																						case 38:
																							goto IL_045a;
																						case 43:
																							goto IL_046e;
																						case 27:
																						case 65:
																							goto IL_0481;
																						case 34:
																							goto IL_049a;
																						case 68:
																							goto IL_04a8;
																						case 29:
																							goto IL_04b6;
																						case 2:
																						case 96:
																							goto IL_04d2;
																						case 104:
																							goto IL_0512;
																						case 71:
																							goto IL_0526;
																						case 105:
																						case 106:
																							goto IL_0539;
																						case 98:
																							goto IL_0579;
																						case 54:
																							goto IL_058d;
																						case 42:
																						case 61:
																							goto IL_05a0;
																						case 47:
																							goto IL_05c9;
																						case 56:
																							goto IL_05d7;
																						case 60:
																						case 100:
																							goto IL_05e7;
																						case 102:
																							goto IL_05f5;
																						case 16:
																							goto IL_0618;
																						case 55:
																							goto IL_0622;
																						case 69:
																							goto IL_0630;
																						case 9:
																						case 19:
																						case 24:
																						case 30:
																						case 32:
																						case 62:
																						case 66:
																						case 79:
																						case 81:
																						case 99:
																							goto end_IL_0227;
																						case 10:
																							goto IL_0651;
																						case 50:
																							goto IL_065b;
																						case 22:
																							goto IL_0666;
																						case 97:
																							goto IL_067b;
																						case 26:
																							goto IL_0690;
																						case 39:
																						case 88:
																							goto IL_06a0;
																						case 83:
																							goto IL_06b0;
																						case 15:
																						case 58:
																							goto IL_06c0;
																						case 44:
																							goto end_IL_063e;
																						case 45:
																							goto end_IL_06d0;
																						case 46:
																						case 70:
																							goto IL_06fd;
																						}
																						goto IL_000e;
																						continue;
																						end_IL_0227:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																	IL_030e:
																	if (6 > b)
																	{
																		goto IL_0337;
																	}
																	goto IL_041a;
																	IL_041a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_045a;
																	IL_045a:
																	array[num5 - 2] = 0;
																	goto IL_046e;
																	IL_046e:
																	num5--;
																	break;
																	IL_028e:
																	if (8 < b)
																	{
																		goto IL_02ca;
																	}
																	goto IL_02e5;
																	IL_02ca:
																	if (9 >= b)
																	{
																		goto IL_02d5;
																	}
																	goto IL_0337;
																	IL_02d5:
																	if (9 > b)
																	{
																		goto IL_0337;
																	}
																	goto IL_03fe;
																	IL_03fe:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_02e5:
																	if (8 > b)
																	{
																		goto IL_0337;
																	}
																	goto IL_0539;
																	IL_0539:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0579;
																	IL_0579:
																	array[num5 - 2] = 0;
																	goto IL_058d;
																	IL_058d:
																	num5--;
																	break;
																	IL_0025:
																	if (5 > b)
																	{
																		goto IL_0033;
																	}
																	goto IL_05e7;
																	IL_0033:
																	if (2 < b)
																	{
																		goto IL_0041;
																	}
																	goto IL_0273;
																	IL_0041:
																	if (3 >= b)
																	{
																		goto IL_004f;
																	}
																	goto IL_031e;
																	IL_004f:
																	if (3 > b)
																	{
																		goto IL_0337;
																	}
																	goto IL_05a0;
																	IL_05a0:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05c9;
																	IL_05c9:
																	ptr2 += 8;
																	goto IL_05d7;
																	IL_05d7:
																	num5--;
																	break;
																	IL_031e:
																	if (4 >= b)
																	{
																		goto IL_0329;
																	}
																	goto IL_0337;
																	IL_0329:
																	if (4 > b)
																	{
																		goto IL_0337;
																	}
																	goto IL_04d2;
																	IL_04d2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0512;
																	IL_0512:
																	array[num5 - 2] = 0;
																	goto IL_0526;
																	IL_0526:
																	num5--;
																	break;
																	IL_0273:
																	if (2 > b)
																	{
																		goto IL_02a6;
																	}
																	goto IL_0397;
																	IL_02a6:
																	if (1 >= b)
																	{
																		goto IL_02b4;
																	}
																	goto IL_0337;
																	IL_02b4:
																	if (1 <= b)
																	{
																		num = 14;
																	}
																	goto IL_0337;
																	IL_04b6:
																	ptr2 += 8;
																	num = 9;
																	break;
																	IL_0397:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_03d7;
																	IL_03d7:
																	array[num5 - 2] = 0;
																	goto IL_03eb;
																	IL_03eb:
																	num5--;
																	break;
																	IL_05e7:
																	array[num5] = 0;
																	goto IL_05f5;
																	IL_05f5:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0618;
																	IL_0618:
																	array2[num5] = null;
																	goto IL_0622;
																	IL_0622:
																	num5++;
																	goto IL_0630;
																	IL_0630:
																	ptr2 += 8;
																	break;
																	IL_0481:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_049a;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06fd;
													IL_06fd:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_063e:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_06d0:
				break;
			}
		}
	}

	static Class197()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 10;
				while (true)
				{
					if (num == 10 || num != 991)
					{
						return;
					}
					switch (num)
					{
					case 1:
						goto end_IL_0031;
					case 2:
						goto end_IL_003e;
					case 0:
						return;
					case 3:
						return;
					}
					continue;
					end_IL_0031:
					break;
				}
				continue;
				end_IL_003e:
				break;
			}
		}
	}
}
