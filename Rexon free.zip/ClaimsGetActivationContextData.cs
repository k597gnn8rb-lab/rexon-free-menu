using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1)]
internal struct ClaimsGetActivationContextData
{
	internal static ClaimsGetActivationContextData CausalityTraceLevelConstructorCallMessage/* Not supported: data(01) */;
}
