using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using Rexon_Menu.Core.Attributes;
using Steamworks;
using UnityEngine;

[Mod("Experimental Report Antiban", "Safety", "Cycles your identity to avoid report bans.", false, 16, ModType.const_0, false)]
internal class Class152 : MonoBehaviour
{
	[Serializable]
	internal sealed class _003C_003Ec
	{
		public static _003C_003Ec _003C_003Ec_0;

		public static Action<LoginResult> action_0;

		public static Action<PlayFabError> action_1;

		public static Action<PlayFabError> action_2;

		public static Action<string> action_3;

		public static Action<EResult> action_4;

		private static IntPtr[] getMinorVersionRequireFull;

		static _003C_003Ec()
		{
			_003C_003Ec _003C_003Ec = new _003C_003Ec();
			object obj = _003C_003Ec;
			_003C_003Ec_0 = (_003C_003Ec)obj;
		}

		public _003C_003Ec()
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
		}

		internal unsafe void method_0(string string_0)
		{
			//The blocks IL_000e, IL_001e, IL_04f7, IL_050a, IL_0533, IL_0543, IL_0553, IL_0563, IL_0573, IL_0583, IL_0593, IL_05a0, IL_05ad, IL_05bd, IL_05cd, IL_05dd, IL_05e8, IL_05f8, IL_0625, IL_0638, IL_064b, IL_0659, IL_0667, IL_0685, IL_0698, IL_06a3, IL_06b3, IL_06c1, IL_06ca, IL_06d8, IL_06e6, IL_06f9, IL_0707, IL_071a, IL_072d, IL_073b, IL_0746, IL_0778, IL_0786, IL_0791, IL_079f, IL_07bc, IL_07f4, IL_0807, IL_0815, IL_0823, IL_0836, IL_088a, IL_089d, IL_08b0, IL_08c3, IL_08ce, IL_08dd, IL_08eb, IL_08fe, IL_0912, IL_0964, IL_0972, IL_097d, IL_0988, IL_0996, IL_09a4, IL_09b7, IL_09c5, IL_09d8, IL_0a21, IL_0a35, IL_0a48, IL_0a53, IL_0a61, IL_0a6f, IL_0a82, IL_0a95, IL_0aae, IL_0ac1, IL_0acc, IL_0aea, IL_0af8, IL_0b0b, IL_0b19, IL_0b24, IL_0b37, IL_0b4b, IL_0b98, IL_0ba6, IL_0bb9, IL_0bd1, IL_0bdf, IL_0bf2, IL_0c0a, IL_0c2d, IL_0c52, IL_0c5d, IL_0c7b, IL_0c89, IL_0c9c, IL_0caa, IL_0cb8, IL_0ccb, IL_0d09, IL_0d1c, IL_0d35, IL_0d43, IL_0d51, IL_0d64, IL_0d72, IL_0d85, IL_0d98, IL_0dad, IL_0dbb, IL_0dce, IL_0ddc, IL_0e4b, IL_0e59, IL_0e75, IL_0e93, IL_0ea1, IL_0eb4, IL_0ebf, IL_0ef7, IL_0f19, IL_0f27, IL_0f32, IL_0f40, IL_0f5e, IL_0f6c, IL_0f83, IL_0f9f, IL_0fb2, IL_0fc5, IL_0fd8, IL_0fe6, IL_0ff9, IL_1007, IL_101c, IL_102a, IL_1046, IL_106a, IL_1082, IL_1095, IL_10a3, IL_10b1, IL_10e3, IL_10fc, IL_110a, IL_1126, IL_1134, IL_1142, IL_1156, IL_118e, IL_11a1, IL_11af, IL_11c7, IL_11d5, IL_11e8, IL_11f6, IL_1201, IL_120f, IL_121d, IL_1235, IL_124c, IL_125a, IL_126d, IL_129a, IL_12ad, IL_12b8, IL_12c3, IL_12d1, IL_12ef, IL_12fd, IL_1310, IL_132d, IL_137c, IL_1386, IL_13b3, IL_13d0, IL_13de, IL_13ec, IL_13ff, IL_1409, IL_1414, IL_1424, IL_1434, IL_1444, IL_1454, IL_146d, IL_147d, IL_148d are reachable both inside and outside the pinned region starting at IL_14a2. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 24;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2;
				int num3;
				byte[] array2;
				object[] array3;
				int[] array4;
				long[] array5;
				object[] array6;
				byte* ptr;
				byte* num6;
				int num7;
				object[] array7;
				int num8;
				byte* num9;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_148d:
						num2 = 1;
						while (true)
						{
							IL_147d:
							num3 = num2 * 4;
							while (true)
							{
								IL_146d:
								array2 = new byte[5];
								while (true)
								{
									IL_1454:
									array3 = new object[5];
									num = 218;
									while (true)
									{
										IL_1444:
										array4 = new int[5];
										while (true)
										{
											IL_1434:
											array5 = new long[5];
											while (true)
											{
												IL_1424:
												array6 = new object[15];
												while (true)
												{
													IL_1414:
													array6[0] = string_0;
													while (true)
													{
														IL_1409:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IIteratorVARKIND.AddTaskAreAuditRulesCanonical);
														while (true)
														{
															IL_13ff:
															ptr2 = ptr;
															while (true)
															{
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_05dd:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_05cd:
																		ptr2++;
																		while (true)
																		{
																			IL_05bd:
																			if (b >= 1)
																			{
																				while (b <= 32)
																				{
																					while (true)
																					{
																						IL_05a0:
																						if (16 >= b)
																						{
																							while (true)
																							{
																								IL_0593:
																								if (16 > b)
																								{
																									while (true)
																									{
																										IL_0583:
																										if (8 < b)
																										{
																											while (true)
																											{
																												IL_0573:
																												if (12 >= b)
																												{
																													while (true)
																													{
																														IL_0563:
																														if (12 > b)
																														{
																															while (true)
																															{
																																IL_0553:
																																if (10 >= b)
																																{
																																	while (true)
																																	{
																																		IL_0543:
																																		if (10 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_0533:
																																				array2[num5] = 5;
																																				while (true)
																																				{
																																					IL_050a:
																																					array3[num5] = ((delegate*<_003C_003Ec__DisplayClass1_0>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
																																					num = 314;
																																					while (true)
																																					{
																																						if (num != 314)
																																						{
																																							if (num != 1295)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 24:
																																								break;
																																							default:
																																								continue;
																																							case 48:
																																								goto IL_050a;
																																							case 175:
																																							case 265:
																																								goto IL_0533;
																																							case 65:
																																								goto IL_0543;
																																							case 68:
																																								goto IL_0553;
																																							case 272:
																																								goto IL_0563;
																																							case 197:
																																							case 276:
																																								goto IL_0573;
																																							case 40:
																																								goto IL_0583;
																																							case 232:
																																								goto IL_0593;
																																							case 225:
																																								goto IL_05a0;
																																							case 202:
																																								goto IL_05ad;
																																							case 12:
																																								goto IL_05bd;
																																							case 19:
																																								goto IL_05cd;
																																							case 9:
																																							case 102:
																																								goto IL_05dd;
																																							case 37:
																																								goto IL_05e8;
																																							case 17:
																																							case 111:
																																								goto IL_05f8;
																																							case 0:
																																								goto IL_0625;
																																							case 141:
																																								goto IL_0638;
																																							case 22:
																																							case 162:
																																								goto IL_064b;
																																							case 80:
																																								goto IL_0659;
																																							case 81:
																																							case 136:
																																								goto IL_0667;
																																							case 135:
																																								goto IL_0685;
																																							case 38:
																																							case 199:
																																								goto IL_0698;
																																							case 69:
																																								goto IL_06a3;
																																							case 106:
																																								goto IL_06b3;
																																							case 18:
																																							case 114:
																																								goto IL_06ca;
																																							case 107:
																																							case 164:
																																								goto IL_06d8;
																																							case 74:
																																								goto IL_06e6;
																																							case 200:
																																								goto IL_06f9;
																																							case 47:
																																								goto IL_0707;
																																							case 211:
																																								goto IL_071a;
																																							case 214:
																																								goto IL_072d;
																																							case 43:
																																								goto IL_073b;
																																							case 39:
																																							case 183:
																																								goto IL_0746;
																																							case 70:
																																								goto IL_0778;
																																							case 71:
																																							case 160:
																																								goto IL_0786;
																																							case 14:
																																								goto IL_0791;
																																							case 2:
																																							case 203:
																																								goto IL_079f;
																																							case 188:
																																								goto IL_07bc;
																																							case 77:
																																								goto IL_07f4;
																																							case 149:
																																								goto IL_0815;
																																							case 222:
																																								goto IL_0823;
																																							case 10:
																																							case 226:
																																								goto IL_0836;
																																							case 205:
																																								goto IL_088a;
																																							case 228:
																																								goto IL_089d;
																																							case 237:
																																								goto IL_08b0;
																																							case 239:
																																								goto IL_08c3;
																																							case 87:
																																							case 121:
																																								goto IL_08ce;
																																							case 240:
																																								goto IL_08dd;
																																							case 83:
																																								goto IL_08eb;
																																							case 220:
																																							case 254:
																																								goto IL_08fe;
																																							case 148:
																																								goto IL_0912;
																																							case 255:
																																								goto IL_0964;
																																							case 241:
																																								goto IL_0972;
																																							case 146:
																																							case 216:
																																								goto IL_097d;
																																							case 215:
																																								goto IL_0988;
																																							case 139:
																																								goto IL_0996;
																																							case 140:
																																								goto IL_09a4;
																																							case 124:
																																								goto IL_09b7;
																																							case 173:
																																								goto IL_09c5;
																																							case 51:
																																							case 184:
																																								goto IL_09d8;
																																							case 98:
																																								goto IL_0a21;
																																							case 120:
																																								goto IL_0a35;
																																							case 11:
																																								goto IL_0a48;
																																							case 109:
																																							case 156:
																																								goto IL_0a53;
																																							case 16:
																																								goto IL_0a61;
																																							case 201:
																																							case 210:
																																								goto IL_0a6f;
																																							case 212:
																																								goto IL_0a82;
																																							case 78:
																																							case 257:
																																								goto IL_0a95;
																																							case 137:
																																								goto IL_0aae;
																																							case 259:
																																								goto IL_0ac1;
																																							case 45:
																																							case 252:
																																								goto IL_0acc;
																																							case 92:
																																								goto IL_0aea;
																																							case 138:
																																								goto IL_0af8;
																																							case 269:
																																								goto IL_0b19;
																																							case 103:
																																							case 153:
																																								goto IL_0b24;
																																							case 67:
																																							case 128:
																																								goto IL_0b37;
																																							case 28:
																																								goto IL_0b4b;
																																							case 6:
																																								goto IL_0b98;
																																							case 56:
																																								goto IL_0ba6;
																																							case 277:
																																								goto IL_0bb9;
																																							case 248:
																																								goto IL_0bd1;
																																							case 190:
																																								goto IL_0bdf;
																																							case 20:
																																							case 278:
																																								goto IL_0bf2;
																																							case 274:
																																								goto IL_0c0a;
																																							case 93:
																																							case 279:
																																								goto IL_0c2d;
																																							case 280:
																																								goto IL_0c52;
																																							case 117:
																																							case 119:
																																								goto IL_0c5d;
																																							case 5:
																																								goto IL_0c7b;
																																							case 123:
																																								goto IL_0c89;
																																							case 264:
																																								goto IL_0c9c;
																																							case 151:
																																								goto IL_0caa;
																																							case 42:
																																							case 213:
																																								goto IL_0cb8;
																																							case 171:
																																							case 281:
																																								goto IL_0ccb;
																																							case 198:
																																								goto IL_0d09;
																																							case 219:
																																							case 284:
																																								goto IL_0d1c;
																																							case 79:
																																								goto IL_0d35;
																																							case 13:
																																								goto IL_0d43;
																																							case 122:
																																								goto IL_0d51;
																																							case 285:
																																								goto IL_0d64;
																																							case 181:
																																								goto IL_0d72;
																																							case 286:
																																								goto IL_0d85;
																																							case 268:
																																							case 287:
																																								goto IL_0d98;
																																							case 238:
																																								goto IL_0dad;
																																							case 150:
																																								goto IL_0dbb;
																																							case 293:
																																								goto IL_0dce;
																																							case 91:
																																							case 221:
																																								goto IL_0ddc;
																																							case 66:
																																								goto IL_0e4b;
																																							case 163:
																																								goto IL_0e59;
																																							case 233:
																																							case 294:
																																								goto IL_0e75;
																																							case 31:
																																								goto IL_0e93;
																																							case 90:
																																								goto IL_0ea1;
																																							case 295:
																																								goto IL_0eb4;
																																							case 247:
																																							case 261:
																																								goto IL_0ebf;
																																							case 244:
																																								goto IL_0ef7;
																																							case 174:
																																							case 236:
																																								goto IL_0f19;
																																							case 131:
																																								goto IL_0f27;
																																							case 132:
																																							case 191:
																																								goto IL_0f40;
																																							case 251:
																																								goto IL_0f5e;
																																							case 143:
																																								goto IL_0f6c;
																																							case 250:
																																								goto IL_0f83;
																																							case 296:
																																								goto IL_0f9f;
																																							case 297:
																																								goto IL_0fb2;
																																							case 300:
																																								goto IL_0fc5;
																																							case 302:
																																								goto IL_0fd8;
																																							case 229:
																																								goto IL_0fe6;
																																							case 303:
																																								goto IL_0ff9;
																																							case 41:
																																							case 182:
																																								goto IL_1007;
																																							case 84:
																																								goto IL_101c;
																																							case 73:
																																								goto IL_102a;
																																							case 304:
																																								goto IL_1046;
																																							case 30:
																																								goto IL_106a;
																																							case 76:
																																								goto IL_1082;
																																							case 185:
																																							case 306:
																																								goto IL_1095;
																																							case 36:
																																								goto IL_10a3;
																																							case 145:
																																							case 253:
																																								goto IL_10b1;
																																							case 59:
																																								goto IL_10e3;
																																							case 118:
																																								goto IL_110a;
																																							case 208:
																																								goto IL_1126;
																																							case 195:
																																								goto IL_1134;
																																							case 172:
																																							case 177:
																																								goto IL_1142;
																																							case 72:
																																								goto IL_1156;
																																							case 125:
																																								goto IL_118e;
																																							case 243:
																																							case 299:
																																								goto IL_11a1;
																																							case 53:
																																								goto IL_11af;
																																							case 134:
																																								goto IL_11c7;
																																							case 158:
																																								goto IL_11d5;
																																							case 113:
																																								goto IL_11e8;
																																							case 186:
																																								goto IL_11f6;
																																							case 54:
																																							case 116:
																																								goto IL_1201;
																																							case 189:
																																								goto IL_120f;
																																							case 169:
																																							case 262:
																																								goto IL_121d;
																																							case 168:
																																								goto IL_1235;
																																							case 298:
																																								goto IL_124c;
																																							case 133:
																																								goto IL_125a;
																																							case 97:
																																							case 105:
																																								goto IL_126d;
																																							case 33:
																																								goto IL_129a;
																																							case 55:
																																								goto IL_12ad;
																																							case 166:
																																								goto IL_12b8;
																																							case 110:
																																							case 305:
																																								goto IL_12c3;
																																							case 275:
																																								goto IL_12d1;
																																							case 165:
																																								goto IL_12ef;
																																							case 207:
																																								goto IL_12fd;
																																							case 1:
																																							case 3:
																																							case 4:
																																							case 7:
																																							case 15:
																																							case 26:
																																							case 49:
																																							case 50:
																																							case 52:
																																							case 58:
																																							case 60:
																																							case 62:
																																							case 63:
																																							case 75:
																																							case 86:
																																							case 89:
																																							case 94:
																																							case 99:
																																							case 100:
																																							case 104:
																																							case 108:
																																							case 112:
																																							case 115:
																																							case 130:
																																							case 142:
																																							case 152:
																																							case 157:
																																							case 159:
																																							case 161:
																																							case 167:
																																							case 176:
																																							case 178:
																																							case 179:
																																							case 180:
																																							case 192:
																																							case 193:
																																							case 196:
																																							case 209:
																																							case 223:
																																							case 227:
																																							case 230:
																																							case 235:
																																							case 245:
																																							case 249:
																																							case 258:
																																							case 260:
																																							case 267:
																																							case 270:
																																							case 282:
																																							case 283:
																																							case 291:
																																							case 307:
																																								goto end_IL_05ad;
																																							case 290:
																																								goto IL_13d0;
																																							case 35:
																																								goto IL_13de;
																																							case 8:
																																							case 21:
																																							case 25:
																																							case 29:
																																							case 32:
																																							case 44:
																																							case 46:
																																							case 57:
																																							case 64:
																																							case 82:
																																							case 85:
																																							case 88:
																																							case 95:
																																							case 101:
																																							case 126:
																																							case 127:
																																							case 129:
																																							case 144:
																																							case 147:
																																							case 154:
																																							case 170:
																																							case 187:
																																							case 204:
																																							case 206:
																																							case 217:
																																							case 224:
																																							case 231:
																																							case 234:
																																							case 242:
																																							case 256:
																																							case 263:
																																							case 288:
																																							case 292:
																																							case 301:
																																								goto end_IL_04f7;
																																							case 266:
																																								goto IL_13ff;
																																							case 246:
																																								goto IL_1409;
																																							case 273:
																																								goto IL_1414;
																																							case 27:
																																								goto IL_1424;
																																							case 61:
																																								goto IL_1434;
																																							case 218:
																																								goto IL_1444;
																																							case 34:
																																								goto IL_1454;
																																							case 155:
																																							case 194:
																																								goto IL_146d;
																																							case 271:
																																								goto IL_147d;
																																							case 23:
																																								goto IL_148d;
																																							case 96:
																																							case 289:
																																								return;
																																							}
																																							goto end_IL_13ec;
																																						}
																																						num5++;
																																						goto IL_110a;
																																						IL_110a:
																																						ptr2 += 8;
																																						num = 46;
																																						break;
																																						continue;
																																						end_IL_04f7:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_1126;
																																		IL_118e:
																																		ptr2 += 8;
																																		break;
																																		IL_1126:
																																		if (9 < b)
																																		{
																																			goto end_IL_05ad;
																																		}
																																		goto IL_1134;
																																		IL_1134:
																																		if (9 > b)
																																		{
																																			goto end_IL_05ad;
																																		}
																																		goto IL_1142;
																																		IL_1142:
																																		array2[num5 - 1] = 5;
																																		goto IL_1156;
																																		IL_1156:
																																		array3[num5 - 1] = ((delegate*<string[], string>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																																		goto IL_118e;
																																	}
																																	break;
																																}
																																goto IL_064b;
																																IL_071a:
																																num5--;
																																break;
																																IL_064b:
																																if (11 < b)
																																{
																																	goto end_IL_05ad;
																																}
																																goto IL_0659;
																																IL_0659:
																																if (11 > b)
																																{
																																	goto end_IL_05ad;
																																}
																																goto IL_0667;
																																IL_0667:
																																array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																																goto IL_0685;
																																IL_0685:
																																ptr2 += 8;
																																goto IL_071a;
																															}
																															break;
																														}
																														goto IL_11a1;
																														IL_11d5:
																														ptr2 += 8;
																														break;
																														IL_11a1:
																														array2[num5] = 5;
																														goto IL_11af;
																														IL_11af:
																														array3[num5] = array6[*(int*)(ptr2 + num3)];
																														goto IL_11c7;
																														IL_11c7:
																														num5++;
																														goto IL_11d5;
																													}
																													break;
																												}
																												goto IL_11e8;
																												IL_12fd:
																												ptr2 += 8;
																												break;
																												IL_11e8:
																												if (14 >= b)
																												{
																													goto IL_11f6;
																												}
																												goto IL_12ad;
																												IL_11f6:
																												if (14 > b)
																												{
																													goto IL_1201;
																												}
																												goto IL_126d;
																												IL_1201:
																												if (13 < b)
																												{
																													goto end_IL_05ad;
																												}
																												goto IL_120f;
																												IL_120f:
																												if (13 > b)
																												{
																													goto end_IL_05ad;
																												}
																												goto IL_121d;
																												IL_121d:
																												array3[num5] = array6[*(int*)(ptr2 + num3)];
																												goto IL_1235;
																												IL_1235:
																												array2[num5] = 5;
																												num = 298;
																												goto IL_124c;
																												IL_124c:
																												num5++;
																												goto IL_125a;
																												IL_125a:
																												ptr2 += 8;
																												break;
																												IL_126d:
																												((_003C_003Ec__DisplayClass1_0)array3[num5 - 2]).string_0 = (string)array3[num5 - 1];
																												goto IL_129a;
																												IL_129a:
																												num5 -= 2;
																												break;
																												IL_12ad:
																												if (15 < b)
																												{
																													goto end_IL_05ad;
																												}
																												goto IL_12b8;
																												IL_12b8:
																												if (15 > b)
																												{
																													goto end_IL_05ad;
																												}
																												goto IL_12c3;
																												IL_12c3:
																												array2[num5] = 5;
																												goto IL_12d1;
																												IL_12d1:
																												array3[num5] = ((delegate*<ExecuteCloudScriptRequest>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
																												goto IL_12ef;
																												IL_12ef:
																												num5++;
																												goto IL_12fd;
																											}
																											break;
																										}
																										goto IL_089d;
																										IL_1082:
																										num5++;
																										break;
																										IL_089d:
																										if (8 > b)
																										{
																											goto IL_0964;
																										}
																										goto IL_0ccb;
																										IL_0ccb:
																										((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																										goto IL_0d09;
																										IL_0d09:
																										num5 -= 3;
																										break;
																										IL_0964:
																										if (4 >= b)
																										{
																											goto IL_0972;
																										}
																										goto IL_0a48;
																										IL_0972:
																										if (4 > b)
																										{
																											goto IL_097d;
																										}
																										goto IL_09d8;
																										IL_097d:
																										if (2 >= b)
																										{
																											goto IL_0988;
																										}
																										goto IL_09b7;
																										IL_0988:
																										if (2 > b)
																										{
																											goto IL_0996;
																										}
																										goto IL_0e75;
																										IL_0996:
																										if (1 < b)
																										{
																											goto end_IL_05ad;
																										}
																										goto IL_09a4;
																										IL_09a4:
																										if (1 <= b)
																										{
																										}
																										goto end_IL_05ad;
																										IL_0e75:
																										array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																										goto IL_0e93;
																										IL_0e93:
																										ptr2 += 8;
																										goto IL_0ea1;
																										IL_0ea1:
																										num5--;
																										break;
																										IL_09b7:
																										if (3 < b)
																										{
																											goto end_IL_05ad;
																										}
																										goto IL_09c5;
																										IL_09c5:
																										if (3 > b)
																										{
																											goto end_IL_05ad;
																										}
																										goto IL_0d1c;
																										IL_0d1c:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																										goto IL_0d35;
																										IL_0d35:
																										array2[num5] = 0;
																										goto IL_0d43;
																										IL_0d43:
																										num5++;
																										goto IL_0d51;
																										IL_0d51:
																										ptr2 += 8;
																										break;
																										IL_09d8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																										num = 98;
																										goto IL_0a21;
																										IL_0a21:
																										array2[num5 - 2] = 0;
																										goto IL_0a35;
																										IL_0a35:
																										num5--;
																										break;
																										IL_0a48:
																										if (6 < b)
																										{
																											goto IL_0a53;
																										}
																										goto IL_0a82;
																										IL_0a53:
																										if (7 < b)
																										{
																											goto end_IL_05ad;
																										}
																										goto IL_0a61;
																										IL_0a61:
																										if (7 > b)
																										{
																											goto end_IL_05ad;
																										}
																										goto IL_0a6f;
																										IL_0a6f:
																										array2[num5] = 5;
																										goto IL_0bb9;
																										IL_0bb9:
																										array3[num5] = array6[*(int*)(ptr2 + num3)];
																										goto IL_0bd1;
																										IL_0bd1:
																										num5++;
																										goto IL_0bdf;
																										IL_0bdf:
																										ptr2 += 8;
																										break;
																										IL_0a82:
																										if (6 <= b)
																										{
																											goto IL_0bf2;
																										}
																										goto IL_1095;
																										IL_1095:
																										if (5 < b)
																										{
																											goto end_IL_05ad;
																										}
																										goto IL_10a3;
																										IL_10a3:
																										if (5 > b)
																										{
																											goto end_IL_05ad;
																										}
																										goto IL_10b1;
																										IL_10b1:
																										array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																										num = 59;
																										goto IL_10e3;
																										IL_10e3:
																										array2[num5 - 1] = 5;
																										break;
																										IL_0bf2:
																										array2[num5] = array2[num5 - 1];
																										goto IL_0c0a;
																										IL_0c0a:
																										array4[num5 - 0] = array4[num5 - 1];
																										goto IL_1046;
																										IL_1046:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																										goto IL_106a;
																										IL_106a:
																										array3[num5] = array3[num5 - 1];
																										goto IL_1082;
																									}
																									break;
																								}
																								goto IL_05f8;
																								IL_0625:
																								num5 -= 2;
																								break;
																								IL_05f8:
																								((ExecuteCloudScriptRequest)array3[num5 - 2]).FunctionName = (string)array3[num5 - 1];
																								goto IL_0625;
																							}
																							break;
																						}
																						goto IL_05e8;
																						IL_102a:
																						num5++;
																						num = 170;
																						break;
																						IL_05e8:
																						if (24 >= b)
																						{
																							goto IL_0638;
																						}
																						goto IL_0698;
																						IL_0698:
																						if (28 >= b)
																						{
																							goto IL_06a3;
																						}
																						goto IL_06b3;
																						IL_06a3:
																						if (28 > b)
																						{
																							goto IL_06f9;
																						}
																						goto IL_08fe;
																						IL_08fe:
																						array2[num5 - 2] = 5;
																						goto IL_0912;
																						IL_0912:
																						array3[num5 - 2] = ((delegate*<object, IntPtr, Action<PlayFabError>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((_003C_003Ec)array3[num5 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																						goto IL_0fd8;
																						IL_0fd8:
																						num5--;
																						goto IL_0fe6;
																						IL_0fe6:
																						ptr2 += 8;
																						break;
																						IL_06f9:
																						if (26 < b)
																						{
																							goto IL_0707;
																						}
																						goto IL_0c52;
																						IL_0707:
																						if (27 < b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_08b0;
																						IL_08b0:
																						if (27 > b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0d98;
																						IL_0d98:
																						*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (void*)0;
																						goto IL_0dad;
																						IL_0dad:
																						array2[num5] = 2;
																						goto IL_0dbb;
																						IL_0dbb:
																						num5++;
																						break;
																						IL_0c52:
																						if (26 <= b)
																						{
																							goto IL_0c5d;
																						}
																						goto IL_0c9c;
																						IL_0c5d:
																						array3[num5] = ((delegate*<_003C_003Ec>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
																						goto IL_0c7b;
																						IL_0c7b:
																						array2[num5] = 5;
																						goto IL_0c89;
																						IL_0c89:
																						num5++;
																						goto IL_0fb2;
																						IL_0fb2:
																						ptr2 += 8;
																						break;
																						IL_0c9c:
																						if (25 < b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0caa;
																						IL_0caa:
																						if (25 > b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0cb8;
																						IL_0cb8:
																						num5--;
																						break;
																						IL_06b3:
																						if (30 < b)
																						{
																							num = 114;
																							goto IL_06ca;
																						}
																						goto IL_08c3;
																						IL_0b37:
																						array2[num5 - 2] = 5;
																						goto IL_0b4b;
																						IL_06ca:
																						if (31 < b)
																						{
																							goto IL_06d8;
																						}
																						goto IL_0dce;
																						IL_06d8:
																						if (32 < b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_06e6;
																						IL_06e6:
																						if (32 > b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0c2d;
																						IL_0c2d:
																						num6 = ptr2;
																						num7 = -200;
																						num4 = 1;
																						ptr2 = num6 + num7;
																						num = 129;
																						break;
																						IL_0dce:
																						if (31 > b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0ddc;
																						IL_0ddc:
																						((delegate*<ExecuteCloudScriptRequest, Action<ExecuteCloudScriptResult>, Action<PlayFabError>, object, Dictionary<string, string>, void>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((ExecuteCloudScriptRequest)array3[num5 - 5], (Action<ExecuteCloudScriptResult>)array3[num5 - 4], (Action<PlayFabError>)array3[num5 - 3], array3[num5 - 2], (Dictionary<string, string>)array3[num5 - 1]);
																						goto IL_0e4b;
																						IL_0e4b:
																						num5 -= 5;
																						goto IL_0e59;
																						IL_0e59:
																						ptr2 += 8;
																						num = 256;
																						break;
																						IL_08c3:
																						if (30 <= b)
																						{
																							goto IL_08ce;
																						}
																						goto IL_08dd;
																						IL_08ce:
																						array3[num5] = null;
																						goto IL_0d64;
																						IL_0d64:
																						array2[num5] = 5;
																						goto IL_0d72;
																						IL_0d72:
																						num5++;
																						break;
																						IL_08dd:
																						if (29 < b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_08eb;
																						IL_08eb:
																						if (29 > b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0a95;
																						IL_0a95:
																						action_2 = (Action<PlayFabError>)array3[num5 - 1];
																						goto IL_0aae;
																						IL_0aae:
																						num5--;
																						break;
																						IL_0638:
																						if (24 > b)
																						{
																							goto IL_072d;
																						}
																						goto IL_0836;
																						IL_0836:
																						ptr2 = (((array3[num5 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_088a;
																						IL_088a:
																						num5--;
																						break;
																						IL_072d:
																						if (20 >= b)
																						{
																							goto IL_073b;
																						}
																						goto IL_0815;
																						IL_073b:
																						if (20 <= b)
																						{
																							goto IL_0746;
																						}
																						goto IL_0778;
																						IL_0746:
																						((ExecuteCloudScriptRequest)array3[num5 - 2]).FunctionParameter = (_003C_003Ef__AnonymousType0<string>)array3[num5 - 1];
																						goto IL_0d85;
																						IL_0d85:
																						num5 -= 2;
																						break;
																						IL_0778:
																						if (18 < b)
																						{
																							goto IL_0786;
																						}
																						goto IL_0eb4;
																						IL_0786:
																						if (19 < b)
																						{
																							num = 258;
																							goto end_IL_05ad;
																						}
																						goto IL_0791;
																						IL_0791:
																						if (19 > b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_079f;
																						IL_079f:
																						array2[num5 - 1] = 5;
																						num = 188;
																						goto IL_07bc;
																						IL_07bc:
																						array3[num5 - 1] = ((delegate*<string, _003C_003Ef__AnonymousType0<string>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																						goto IL_07f4;
																						IL_07f4:
																						ptr2 += 8;
																						break;
																						IL_0b4b:
																						array3[num5 - 2] = ((delegate*<object, IntPtr, Action<ExecuteCloudScriptResult>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((_003C_003Ec__DisplayClass1_0)array3[num5 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																						goto IL_0b98;
																						IL_0eb4:
																						if (18 <= b)
																						{
																							goto IL_0ebf;
																						}
																						goto IL_0f19;
																						IL_0ebf:
																						array3[num5 - 1] = ((delegate*<PlayFabAuthenticationContext, string>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((PlayFabAuthenticationContext)array3[num5 - 1]);
																						goto IL_0ef7;
																						IL_0ef7:
																						array2[num5 - 1] = 5;
																						num = 296;
																						goto IL_0f9f;
																						IL_0f9f:
																						ptr2 += 8;
																						break;
																						IL_0f19:
																						if (17 < b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0f27;
																						IL_0f27:
																						if (17 > b)
																						{
																							num = 267;
																							goto end_IL_05ad;
																						}
																						goto IL_0f40;
																						IL_0b98:
																						num5--;
																						goto IL_0ba6;
																						IL_0f40:
																						array3[num5] = ((delegate*<PlayFabAuthenticationContext>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
																						goto IL_0f5e;
																						IL_0f5e:
																						array2[num5] = 5;
																						goto IL_0f6c;
																						IL_0f6c:
																						num5++;
																						num = 250;
																						goto IL_0f83;
																						IL_0f83:
																						ptr2 += 8;
																						num = 82;
																						break;
																						IL_0815:
																						if (22 < b)
																						{
																							goto IL_0823;
																						}
																						goto IL_0b19;
																						IL_0823:
																						if (23 < b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0ac1;
																						IL_0ac1:
																						if (23 > b)
																						{
																							num = 75;
																							goto end_IL_05ad;
																						}
																						goto IL_0acc;
																						IL_0acc:
																						array3[num5] = ((delegate*<Action<PlayFabError>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
																						goto IL_0aea;
																						IL_0aea:
																						array2[num5] = 5;
																						goto IL_0af8;
																						IL_0af8:
																						num5++;
																						goto IL_0fc5;
																						IL_0fc5:
																						ptr2 += 8;
																						break;
																						IL_0ba6:
																						ptr2 += 8;
																						break;
																						IL_0b19:
																						if (22 > b)
																						{
																							goto IL_0b24;
																						}
																						goto IL_0b37;
																						IL_0b24:
																						if (21 < b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_0ff9;
																						IL_0ff9:
																						if (21 > b)
																						{
																							goto end_IL_05ad;
																						}
																						goto IL_1007;
																						IL_1007:
																						*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (void*)0;
																						goto IL_101c;
																						IL_101c:
																						array2[num5] = 2;
																						goto IL_102a;
																					}
																					goto end_IL_05bd;
																					continue;
																					end_IL_05ad:
																					break;
																					IL_05ad:;
																				}
																			}
																			array7 = array3;
																			num8 = num5;
																			if (array == null)
																			{
																				goto IL_131f;
																			}
																			num9 = ptr2;
																			byte b2 = *num9;
																			ptr2 = num9 + 4;
																			int num10 = *(int*)(ptr2 + num3);
																			ptr2 += 8;
																			byte* ptr3 = ptr2 + num10;
																			byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																			while (ptr2 != ptr3)
																			{
																				*ptr4 = (byte)(*ptr2 ^ b2);
																				ptr2++;
																				ptr4++;
																			}
																			array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																			num = 290;
																			goto IL_13d0;
																			IL_13d0:
																			array2[num5] = 5;
																			goto IL_13de;
																			IL_13de:
																			num5++;
																			break;
																			continue;
																			end_IL_05bd:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
																end_IL_13ec:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_131f:
				while (true)
				{
					IL_131f_2:
					array = new byte[4];
					while (true)
					{
						num9 = ptr2;
						byte b2 = *num9;
						ptr2 = num9 + 4;
						int num10 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num10;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						num = 290;
						while (true)
						{
							IL_13d0_2:
							array2[num5] = 5;
							while (true)
							{
								IL_13de_2:
								num5++;
								while (true)
								{
									IL_13ec_2:
									if (num4 == 1)
									{
										return;
									}
									while (true)
									{
										IL_05dd_2:
										byte b = *ptr2;
										while (true)
										{
											IL_05cd_2:
											ptr2++;
											while (b >= 1)
											{
												while (b <= 32)
												{
													while (true)
													{
														IL_05a0_2:
														if (16 >= b)
														{
															while (true)
															{
																IL_0593_2:
																if (16 > b)
																{
																	while (true)
																	{
																		IL_0583_2:
																		if (8 < b)
																		{
																			while (true)
																			{
																				IL_0573_2:
																				if (12 >= b)
																				{
																					while (true)
																					{
																						IL_0563_2:
																						if (12 > b)
																						{
																							while (true)
																							{
																								IL_0553_2:
																								if (10 >= b)
																								{
																									while (true)
																									{
																										IL_0543_2:
																										if (10 <= b)
																										{
																											while (true)
																											{
																												IL_0533_2:
																												array2[num5] = 5;
																												while (true)
																												{
																													IL_050a_2:
																													array3[num5] = ((delegate*<_003C_003Ec__DisplayClass1_0>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
																													num = 314;
																													while (true)
																													{
																														if (num != 314)
																														{
																															if (num != 1295)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 48:
																																goto IL_050a_2;
																															case 175:
																															case 265:
																																goto IL_0533_2;
																															case 65:
																																goto IL_0543_2;
																															case 68:
																																goto IL_0553_2;
																															case 272:
																																goto IL_0563_2;
																															case 197:
																															case 276:
																																goto IL_0573_2;
																															case 40:
																																goto IL_0583_2;
																															case 232:
																																goto IL_0593_2;
																															case 225:
																																goto IL_05a0_2;
																															case 202:
																																goto IL_05ad_2;
																															case 12:
																																goto IL_05bd_2;
																															case 19:
																																goto IL_05cd_2;
																															case 9:
																															case 102:
																																goto IL_05dd_2;
																															case 37:
																																goto IL_05e8_2;
																															case 17:
																															case 111:
																																goto IL_05f8_2;
																															case 0:
																																goto IL_0625_2;
																															case 141:
																																goto IL_0638_2;
																															case 22:
																															case 162:
																																goto IL_064b_2;
																															case 80:
																																goto IL_0659_2;
																															case 81:
																															case 136:
																																goto IL_0667_2;
																															case 135:
																																goto IL_0685_2;
																															case 38:
																															case 199:
																																goto IL_0698_2;
																															case 69:
																																goto IL_06a3_2;
																															case 106:
																																goto IL_06b3_2;
																															case 18:
																															case 114:
																																goto IL_06ca_2;
																															case 107:
																															case 164:
																																goto IL_06d8_2;
																															case 74:
																																goto IL_06e6_2;
																															case 200:
																																goto IL_06f9_2;
																															case 47:
																																goto IL_0707_2;
																															case 211:
																																goto IL_071a_2;
																															case 214:
																																goto IL_072d_2;
																															case 43:
																																goto IL_073b_2;
																															case 39:
																															case 183:
																																goto IL_0746_2;
																															case 70:
																																goto IL_0778_2;
																															case 71:
																															case 160:
																																goto IL_0786_2;
																															case 14:
																																goto IL_0791_2;
																															case 2:
																															case 203:
																																goto IL_079f_2;
																															case 188:
																																goto IL_07bc_2;
																															case 77:
																																goto IL_07f4_2;
																															case 149:
																																goto IL_0815_2;
																															case 222:
																																goto IL_0823_2;
																															case 10:
																															case 226:
																																goto IL_0836_2;
																															case 205:
																																goto IL_088a_2;
																															case 228:
																																goto IL_089d_2;
																															case 237:
																																goto IL_08b0_2;
																															case 239:
																																goto IL_08c3_2;
																															case 87:
																															case 121:
																																goto IL_08ce_2;
																															case 240:
																																goto IL_08dd_2;
																															case 83:
																																goto IL_08eb_2;
																															case 220:
																															case 254:
																																goto IL_08fe_2;
																															case 148:
																																goto IL_0912_2;
																															case 255:
																																goto IL_0964_2;
																															case 241:
																																goto IL_0972_2;
																															case 146:
																															case 216:
																																goto IL_097d_2;
																															case 215:
																																goto IL_0988_2;
																															case 139:
																																goto IL_0996_2;
																															case 140:
																																goto IL_09a4_2;
																															case 124:
																																goto IL_09b7_2;
																															case 173:
																																goto IL_09c5_2;
																															case 51:
																															case 184:
																																goto IL_09d8_2;
																															case 98:
																																goto IL_0a21_2;
																															case 120:
																																goto IL_0a35_2;
																															case 11:
																																goto IL_0a48_2;
																															case 109:
																															case 156:
																																goto IL_0a53_2;
																															case 16:
																																goto IL_0a61_2;
																															case 201:
																															case 210:
																																goto IL_0a6f_2;
																															case 212:
																																goto IL_0a82_2;
																															case 78:
																															case 257:
																																goto IL_0a95_2;
																															case 137:
																																goto IL_0aae_2;
																															case 259:
																																goto IL_0ac1_2;
																															case 45:
																															case 252:
																																goto IL_0acc_2;
																															case 92:
																																goto IL_0aea_2;
																															case 138:
																																goto IL_0af8_2;
																															case 269:
																																goto IL_0b19_2;
																															case 103:
																															case 153:
																																goto IL_0b24_2;
																															case 67:
																															case 128:
																																goto IL_0b37_2;
																															case 28:
																																goto IL_0b4b_2;
																															case 6:
																																goto IL_0b98_2;
																															case 56:
																																goto IL_0ba6_2;
																															case 277:
																																goto IL_0bb9_2;
																															case 248:
																																goto IL_0bd1_2;
																															case 190:
																																goto IL_0bdf_2;
																															case 20:
																															case 278:
																																goto IL_0bf2_2;
																															case 274:
																																goto IL_0c0a_2;
																															case 93:
																															case 279:
																																goto IL_0c2d_2;
																															case 280:
																																goto IL_0c52_2;
																															case 117:
																															case 119:
																																goto IL_0c5d_2;
																															case 5:
																																goto IL_0c7b_2;
																															case 123:
																																goto IL_0c89_2;
																															case 264:
																																goto IL_0c9c_2;
																															case 151:
																																goto IL_0caa_2;
																															case 42:
																															case 213:
																																goto IL_0cb8_2;
																															case 171:
																															case 281:
																																goto IL_0ccb_2;
																															case 198:
																																goto IL_0d09_2;
																															case 219:
																															case 284:
																																goto IL_0d1c_2;
																															case 79:
																																goto IL_0d35_2;
																															case 13:
																																goto IL_0d43_2;
																															case 122:
																																goto IL_0d51_2;
																															case 285:
																																goto IL_0d64_2;
																															case 181:
																																goto IL_0d72_2;
																															case 286:
																																goto IL_0d85_2;
																															case 268:
																															case 287:
																																goto IL_0d98_2;
																															case 238:
																																goto IL_0dad_2;
																															case 150:
																																goto IL_0dbb_2;
																															case 293:
																																goto IL_0dce_2;
																															case 91:
																															case 221:
																																goto IL_0ddc_2;
																															case 66:
																																goto IL_0e4b_2;
																															case 163:
																																goto IL_0e59_2;
																															case 233:
																															case 294:
																																goto IL_0e75_2;
																															case 31:
																																goto IL_0e93_2;
																															case 90:
																																goto IL_0ea1_2;
																															case 295:
																																goto IL_0eb4_2;
																															case 247:
																															case 261:
																																goto IL_0ebf_2;
																															case 244:
																																goto IL_0ef7_2;
																															case 174:
																															case 236:
																																goto IL_0f19_2;
																															case 131:
																																goto IL_0f27_2;
																															case 132:
																															case 191:
																																goto IL_0f40_2;
																															case 251:
																																goto IL_0f5e_2;
																															case 143:
																																goto IL_0f6c_2;
																															case 250:
																																goto IL_0f83_2;
																															case 296:
																																goto IL_0f9f_2;
																															case 297:
																																goto IL_0fb2_2;
																															case 300:
																																goto IL_0fc5_2;
																															case 302:
																																goto IL_0fd8_2;
																															case 229:
																																goto IL_0fe6_2;
																															case 303:
																																goto IL_0ff9_2;
																															case 41:
																															case 182:
																																goto IL_1007_2;
																															case 84:
																																goto IL_101c_2;
																															case 73:
																																goto IL_102a_2;
																															case 304:
																																goto IL_1046_2;
																															case 30:
																																goto IL_106a_2;
																															case 76:
																																goto IL_1082_2;
																															case 185:
																															case 306:
																																goto IL_1095_2;
																															case 36:
																																goto IL_10a3_2;
																															case 145:
																															case 253:
																																goto IL_10b1_2;
																															case 59:
																																goto IL_10e3_2;
																															case 118:
																																goto IL_110a_2;
																															case 208:
																																goto IL_1126_2;
																															case 195:
																																goto IL_1134_2;
																															case 172:
																															case 177:
																																goto IL_1142_2;
																															case 72:
																																goto IL_1156_2;
																															case 125:
																																goto IL_118e_2;
																															case 243:
																															case 299:
																																goto IL_11a1_2;
																															case 53:
																																goto IL_11af_2;
																															case 134:
																																goto IL_11c7_2;
																															case 158:
																																goto IL_11d5_2;
																															case 113:
																																goto IL_11e8_2;
																															case 186:
																																goto IL_11f6_2;
																															case 54:
																															case 116:
																																goto IL_1201_2;
																															case 189:
																																goto IL_120f_2;
																															case 169:
																															case 262:
																																goto IL_121d_2;
																															case 168:
																																goto IL_1235_2;
																															case 298:
																																goto IL_124c_2;
																															case 133:
																																goto IL_125a_2;
																															case 97:
																															case 105:
																																goto IL_126d_2;
																															case 33:
																																goto IL_129a_2;
																															case 55:
																																goto IL_12ad_2;
																															case 166:
																																goto IL_12b8_2;
																															case 110:
																															case 305:
																																goto IL_12c3_2;
																															case 275:
																																goto IL_12d1_2;
																															case 165:
																																goto IL_12ef_2;
																															case 207:
																																goto IL_12fd_2;
																															case 1:
																															case 3:
																															case 4:
																															case 7:
																															case 15:
																															case 26:
																															case 49:
																															case 50:
																															case 52:
																															case 58:
																															case 60:
																															case 62:
																															case 63:
																															case 75:
																															case 86:
																															case 89:
																															case 94:
																															case 99:
																															case 100:
																															case 104:
																															case 108:
																															case 112:
																															case 115:
																															case 130:
																															case 142:
																															case 152:
																															case 157:
																															case 159:
																															case 161:
																															case 167:
																															case 176:
																															case 178:
																															case 179:
																															case 180:
																															case 192:
																															case 193:
																															case 196:
																															case 209:
																															case 223:
																															case 227:
																															case 230:
																															case 235:
																															case 245:
																															case 249:
																															case 258:
																															case 260:
																															case 267:
																															case 270:
																															case 282:
																															case 283:
																															case 291:
																															case 307:
																																goto end_IL_05ad_2;
																															case 290:
																																goto IL_13d0_2;
																															case 35:
																																goto IL_13de_2;
																															case 8:
																															case 21:
																															case 25:
																															case 29:
																															case 32:
																															case 44:
																															case 46:
																															case 57:
																															case 64:
																															case 82:
																															case 85:
																															case 88:
																															case 95:
																															case 101:
																															case 126:
																															case 127:
																															case 129:
																															case 144:
																															case 147:
																															case 154:
																															case 170:
																															case 187:
																															case 204:
																															case 206:
																															case 217:
																															case 224:
																															case 231:
																															case 234:
																															case 242:
																															case 256:
																															case 263:
																															case 288:
																															case 292:
																															case 301:
																																goto end_IL_04f7_2;
																															case 266:
																																ptr2 = ptr;
																																goto end_IL_04f7_2;
																															case 246:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IIteratorVARKIND.AddTaskAreAuditRulesCanonical);
																																goto case 266;
																															case 273:
																																array6[0] = string_0;
																																goto case 246;
																															case 27:
																																array6 = new object[15];
																																goto case 273;
																															case 61:
																																array5 = new long[5];
																																goto case 27;
																															case 218:
																																array4 = new int[5];
																																goto case 61;
																															case 34:
																																array3 = new object[5];
																																num = 218;
																																goto case 218;
																															case 155:
																															case 194:
																																array2 = new byte[5];
																																goto case 34;
																															case 271:
																																num3 = num2 * 4;
																																goto case 155;
																															case 23:
																																num2 = 1;
																																goto case 271;
																															case 24:
																																goto end_IL_132d;
																															case 96:
																															case 289:
																																return;
																															}
																															continue;
																														}
																														num5++;
																														goto IL_110a_2;
																														IL_110a_2:
																														ptr2 += 8;
																														num = 46;
																														break;
																														continue;
																														end_IL_04f7_2:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_1126_2;
																										IL_118e_2:
																										ptr2 += 8;
																										break;
																										IL_1126_2:
																										if (9 < b)
																										{
																											goto end_IL_05ad_2;
																										}
																										goto IL_1134_2;
																										IL_1134_2:
																										if (9 > b)
																										{
																											goto end_IL_05ad_2;
																										}
																										goto IL_1142_2;
																										IL_1142_2:
																										array2[num5 - 1] = 5;
																										goto IL_1156_2;
																										IL_1156_2:
																										array3[num5 - 1] = ((delegate*<string[], string>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																										goto IL_118e_2;
																									}
																									break;
																								}
																								goto IL_064b_2;
																								IL_071a_2:
																								num5--;
																								break;
																								IL_064b_2:
																								if (11 < b)
																								{
																									goto end_IL_05ad_2;
																								}
																								goto IL_0659_2;
																								IL_0659_2:
																								if (11 > b)
																								{
																									goto end_IL_05ad_2;
																								}
																								goto IL_0667_2;
																								IL_0667_2:
																								array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																								goto IL_0685_2;
																								IL_0685_2:
																								ptr2 += 8;
																								goto IL_071a_2;
																							}
																							break;
																						}
																						goto IL_11a1_2;
																						IL_11d5_2:
																						ptr2 += 8;
																						break;
																						IL_11a1_2:
																						array2[num5] = 5;
																						goto IL_11af_2;
																						IL_11af_2:
																						array3[num5] = array6[*(int*)(ptr2 + num3)];
																						goto IL_11c7_2;
																						IL_11c7_2:
																						num5++;
																						goto IL_11d5_2;
																					}
																					break;
																				}
																				goto IL_11e8_2;
																				IL_12fd_2:
																				ptr2 += 8;
																				break;
																				IL_11e8_2:
																				if (14 >= b)
																				{
																					goto IL_11f6_2;
																				}
																				goto IL_12ad_2;
																				IL_11f6_2:
																				if (14 > b)
																				{
																					goto IL_1201_2;
																				}
																				goto IL_126d_2;
																				IL_1201_2:
																				if (13 < b)
																				{
																					goto end_IL_05ad_2;
																				}
																				goto IL_120f_2;
																				IL_120f_2:
																				if (13 > b)
																				{
																					goto end_IL_05ad_2;
																				}
																				goto IL_121d_2;
																				IL_121d_2:
																				array3[num5] = array6[*(int*)(ptr2 + num3)];
																				goto IL_1235_2;
																				IL_1235_2:
																				array2[num5] = 5;
																				num = 298;
																				goto IL_124c_2;
																				IL_124c_2:
																				num5++;
																				goto IL_125a_2;
																				IL_125a_2:
																				ptr2 += 8;
																				break;
																				IL_126d_2:
																				((_003C_003Ec__DisplayClass1_0)array3[num5 - 2]).string_0 = (string)array3[num5 - 1];
																				goto IL_129a_2;
																				IL_129a_2:
																				num5 -= 2;
																				break;
																				IL_12ad_2:
																				if (15 < b)
																				{
																					goto end_IL_05ad_2;
																				}
																				goto IL_12b8_2;
																				IL_12b8_2:
																				if (15 > b)
																				{
																					goto end_IL_05ad_2;
																				}
																				goto IL_12c3_2;
																				IL_12c3_2:
																				array2[num5] = 5;
																				goto IL_12d1_2;
																				IL_12d1_2:
																				array3[num5] = ((delegate*<ExecuteCloudScriptRequest>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
																				goto IL_12ef_2;
																				IL_12ef_2:
																				num5++;
																				goto IL_12fd_2;
																			}
																			break;
																		}
																		goto IL_089d_2;
																		IL_1082_2:
																		num5++;
																		break;
																		IL_089d_2:
																		if (8 > b)
																		{
																			goto IL_0964_2;
																		}
																		goto IL_0ccb_2;
																		IL_0ccb_2:
																		((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																		goto IL_0d09_2;
																		IL_0d09_2:
																		num5 -= 3;
																		break;
																		IL_0964_2:
																		if (4 >= b)
																		{
																			goto IL_0972_2;
																		}
																		goto IL_0a48_2;
																		IL_0972_2:
																		if (4 > b)
																		{
																			goto IL_097d_2;
																		}
																		goto IL_09d8_2;
																		IL_097d_2:
																		if (2 >= b)
																		{
																			goto IL_0988_2;
																		}
																		goto IL_09b7_2;
																		IL_0988_2:
																		if (2 > b)
																		{
																			goto IL_0996_2;
																		}
																		goto IL_0e75_2;
																		IL_0996_2:
																		if (1 < b)
																		{
																			goto end_IL_05ad_2;
																		}
																		goto IL_09a4_2;
																		IL_09a4_2:
																		if (1 <= b)
																		{
																		}
																		goto end_IL_05ad_2;
																		IL_0e75_2:
																		array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																		goto IL_0e93_2;
																		IL_0e93_2:
																		ptr2 += 8;
																		goto IL_0ea1_2;
																		IL_0ea1_2:
																		num5--;
																		break;
																		IL_09b7_2:
																		if (3 < b)
																		{
																			goto end_IL_05ad_2;
																		}
																		goto IL_09c5_2;
																		IL_09c5_2:
																		if (3 > b)
																		{
																			goto end_IL_05ad_2;
																		}
																		goto IL_0d1c_2;
																		IL_0d1c_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																		goto IL_0d35_2;
																		IL_0d35_2:
																		array2[num5] = 0;
																		goto IL_0d43_2;
																		IL_0d43_2:
																		num5++;
																		goto IL_0d51_2;
																		IL_0d51_2:
																		ptr2 += 8;
																		break;
																		IL_09d8_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																		num = 98;
																		goto IL_0a21_2;
																		IL_0a21_2:
																		array2[num5 - 2] = 0;
																		goto IL_0a35_2;
																		IL_0a35_2:
																		num5--;
																		break;
																		IL_0a48_2:
																		if (6 < b)
																		{
																			goto IL_0a53_2;
																		}
																		goto IL_0a82_2;
																		IL_0a53_2:
																		if (7 < b)
																		{
																			goto end_IL_05ad_2;
																		}
																		goto IL_0a61_2;
																		IL_0a61_2:
																		if (7 > b)
																		{
																			goto end_IL_05ad_2;
																		}
																		goto IL_0a6f_2;
																		IL_0a6f_2:
																		array2[num5] = 5;
																		goto IL_0bb9_2;
																		IL_0bb9_2:
																		array3[num5] = array6[*(int*)(ptr2 + num3)];
																		goto IL_0bd1_2;
																		IL_0bd1_2:
																		num5++;
																		goto IL_0bdf_2;
																		IL_0bdf_2:
																		ptr2 += 8;
																		break;
																		IL_0a82_2:
																		if (6 <= b)
																		{
																			goto IL_0bf2_2;
																		}
																		goto IL_1095_2;
																		IL_1095_2:
																		if (5 < b)
																		{
																			goto end_IL_05ad_2;
																		}
																		goto IL_10a3_2;
																		IL_10a3_2:
																		if (5 > b)
																		{
																			goto end_IL_05ad_2;
																		}
																		goto IL_10b1_2;
																		IL_10b1_2:
																		array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																		num = 59;
																		goto IL_10e3_2;
																		IL_10e3_2:
																		array2[num5 - 1] = 5;
																		break;
																		IL_0bf2_2:
																		array2[num5] = array2[num5 - 1];
																		goto IL_0c0a_2;
																		IL_0c0a_2:
																		array4[num5 - 0] = array4[num5 - 1];
																		goto IL_1046_2;
																		IL_1046_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																		goto IL_106a_2;
																		IL_106a_2:
																		array3[num5] = array3[num5 - 1];
																		goto IL_1082_2;
																	}
																	break;
																}
																goto IL_05f8_2;
																IL_0625_2:
																num5 -= 2;
																break;
																IL_05f8_2:
																((ExecuteCloudScriptRequest)array3[num5 - 2]).FunctionName = (string)array3[num5 - 1];
																goto IL_0625_2;
															}
															break;
														}
														goto IL_05e8_2;
														IL_102a_2:
														num5++;
														num = 170;
														break;
														IL_05e8_2:
														if (24 >= b)
														{
															goto IL_0638_2;
														}
														goto IL_0698_2;
														IL_0698_2:
														if (28 >= b)
														{
															goto IL_06a3_2;
														}
														goto IL_06b3_2;
														IL_06a3_2:
														if (28 > b)
														{
															goto IL_06f9_2;
														}
														goto IL_08fe_2;
														IL_08fe_2:
														array2[num5 - 2] = 5;
														goto IL_0912_2;
														IL_0912_2:
														array3[num5 - 2] = ((delegate*<object, IntPtr, Action<PlayFabError>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((_003C_003Ec)array3[num5 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
														goto IL_0fd8_2;
														IL_0fd8_2:
														num5--;
														goto IL_0fe6_2;
														IL_0fe6_2:
														ptr2 += 8;
														break;
														IL_06f9_2:
														if (26 < b)
														{
															goto IL_0707_2;
														}
														goto IL_0c52_2;
														IL_0707_2:
														if (27 < b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_08b0_2;
														IL_08b0_2:
														if (27 > b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0d98_2;
														IL_0d98_2:
														*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (void*)0;
														goto IL_0dad_2;
														IL_0dad_2:
														array2[num5] = 2;
														goto IL_0dbb_2;
														IL_0dbb_2:
														num5++;
														break;
														IL_0c52_2:
														if (26 <= b)
														{
															goto IL_0c5d_2;
														}
														goto IL_0c9c_2;
														IL_0c5d_2:
														array3[num5] = ((delegate*<_003C_003Ec>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
														goto IL_0c7b_2;
														IL_0c7b_2:
														array2[num5] = 5;
														goto IL_0c89_2;
														IL_0c89_2:
														num5++;
														goto IL_0fb2_2;
														IL_0fb2_2:
														ptr2 += 8;
														break;
														IL_0c9c_2:
														if (25 < b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0caa_2;
														IL_0caa_2:
														if (25 > b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0cb8_2;
														IL_0cb8_2:
														num5--;
														break;
														IL_06b3_2:
														if (30 < b)
														{
															num = 114;
															goto IL_06ca_2;
														}
														goto IL_08c3_2;
														IL_0b37_2:
														array2[num5 - 2] = 5;
														goto IL_0b4b_2;
														IL_06ca_2:
														if (31 < b)
														{
															goto IL_06d8_2;
														}
														goto IL_0dce_2;
														IL_06d8_2:
														if (32 < b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_06e6_2;
														IL_06e6_2:
														if (32 > b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0c2d_2;
														IL_0c2d_2:
														num6 = ptr2;
														num7 = -200;
														num4 = 1;
														ptr2 = num6 + num7;
														num = 129;
														break;
														IL_0dce_2:
														if (31 > b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0ddc_2;
														IL_0ddc_2:
														((delegate*<ExecuteCloudScriptRequest, Action<ExecuteCloudScriptResult>, Action<PlayFabError>, object, Dictionary<string, string>, void>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((ExecuteCloudScriptRequest)array3[num5 - 5], (Action<ExecuteCloudScriptResult>)array3[num5 - 4], (Action<PlayFabError>)array3[num5 - 3], array3[num5 - 2], (Dictionary<string, string>)array3[num5 - 1]);
														goto IL_0e4b_2;
														IL_0e4b_2:
														num5 -= 5;
														goto IL_0e59_2;
														IL_0e59_2:
														ptr2 += 8;
														num = 256;
														break;
														IL_08c3_2:
														if (30 <= b)
														{
															goto IL_08ce_2;
														}
														goto IL_08dd_2;
														IL_08ce_2:
														array3[num5] = null;
														goto IL_0d64_2;
														IL_0d64_2:
														array2[num5] = 5;
														goto IL_0d72_2;
														IL_0d72_2:
														num5++;
														break;
														IL_08dd_2:
														if (29 < b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_08eb_2;
														IL_08eb_2:
														if (29 > b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0a95_2;
														IL_0a95_2:
														action_2 = (Action<PlayFabError>)array3[num5 - 1];
														goto IL_0aae_2;
														IL_0aae_2:
														num5--;
														break;
														IL_0638_2:
														if (24 > b)
														{
															goto IL_072d_2;
														}
														goto IL_0836_2;
														IL_0836_2:
														ptr2 = (((array3[num5 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_088a_2;
														IL_088a_2:
														num5--;
														break;
														IL_072d_2:
														if (20 >= b)
														{
															goto IL_073b_2;
														}
														goto IL_0815_2;
														IL_073b_2:
														if (20 <= b)
														{
															goto IL_0746_2;
														}
														goto IL_0778_2;
														IL_0746_2:
														((ExecuteCloudScriptRequest)array3[num5 - 2]).FunctionParameter = (_003C_003Ef__AnonymousType0<string>)array3[num5 - 1];
														goto IL_0d85_2;
														IL_0d85_2:
														num5 -= 2;
														break;
														IL_0778_2:
														if (18 < b)
														{
															goto IL_0786_2;
														}
														goto IL_0eb4_2;
														IL_0786_2:
														if (19 < b)
														{
															num = 258;
															goto end_IL_05ad_2;
														}
														goto IL_0791_2;
														IL_0791_2:
														if (19 > b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_079f_2;
														IL_079f_2:
														array2[num5 - 1] = 5;
														num = 188;
														goto IL_07bc_2;
														IL_07bc_2:
														array3[num5 - 1] = ((delegate*<string, _003C_003Ef__AnonymousType0<string>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
														goto IL_07f4_2;
														IL_07f4_2:
														ptr2 += 8;
														break;
														IL_0b4b_2:
														array3[num5 - 2] = ((delegate*<object, IntPtr, Action<ExecuteCloudScriptResult>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((_003C_003Ec__DisplayClass1_0)array3[num5 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
														goto IL_0b98_2;
														IL_0eb4_2:
														if (18 <= b)
														{
															goto IL_0ebf_2;
														}
														goto IL_0f19_2;
														IL_0ebf_2:
														array3[num5 - 1] = ((delegate*<PlayFabAuthenticationContext, string>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])((PlayFabAuthenticationContext)array3[num5 - 1]);
														goto IL_0ef7_2;
														IL_0ef7_2:
														array2[num5 - 1] = 5;
														num = 296;
														goto IL_0f9f_2;
														IL_0f9f_2:
														ptr2 += 8;
														break;
														IL_0f19_2:
														if (17 < b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0f27_2;
														IL_0f27_2:
														if (17 > b)
														{
															num = 267;
															goto end_IL_05ad_2;
														}
														goto IL_0f40_2;
														IL_0b98_2:
														num5--;
														goto IL_0ba6_2;
														IL_0f40_2:
														array3[num5] = ((delegate*<PlayFabAuthenticationContext>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
														goto IL_0f5e_2;
														IL_0f5e_2:
														array2[num5] = 5;
														goto IL_0f6c_2;
														IL_0f6c_2:
														num5++;
														num = 250;
														goto IL_0f83_2;
														IL_0f83_2:
														ptr2 += 8;
														num = 82;
														break;
														IL_0815_2:
														if (22 < b)
														{
															goto IL_0823_2;
														}
														goto IL_0b19_2;
														IL_0823_2:
														if (23 < b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0ac1_2;
														IL_0ac1_2:
														if (23 > b)
														{
															num = 75;
															goto end_IL_05ad_2;
														}
														goto IL_0acc_2;
														IL_0acc_2:
														array3[num5] = ((delegate*<Action<PlayFabError>>)getMinorVersionRequireFull[*(int*)(ptr2 + num3)])();
														goto IL_0aea_2;
														IL_0aea_2:
														array2[num5] = 5;
														goto IL_0af8_2;
														IL_0af8_2:
														num5++;
														goto IL_0fc5_2;
														IL_0fc5_2:
														ptr2 += 8;
														break;
														IL_0ba6_2:
														ptr2 += 8;
														break;
														IL_0b19_2:
														if (22 > b)
														{
															goto IL_0b24_2;
														}
														goto IL_0b37_2;
														IL_0b24_2:
														if (21 < b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_0ff9_2;
														IL_0ff9_2:
														if (21 > b)
														{
															goto end_IL_05ad_2;
														}
														goto IL_1007_2;
														IL_1007_2:
														*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (void*)0;
														goto IL_101c_2;
														IL_101c_2:
														array2[num5] = 2;
														goto IL_102a_2;
													}
													goto IL_13ec_2;
													continue;
													end_IL_05ad_2:
													break;
													IL_05ad_2:;
												}
												break;
												IL_05bd_2:;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						array7 = array3;
						num8 = num5;
						if (array == null)
						{
							goto IL_131f_2;
						}
						continue;
						end_IL_132d:
						break;
					}
					break;
				}
			}
		}

		internal unsafe void method_1(LoginResult loginResult_0)
		{
			int num = 15;
			int num2 = default(int);
			while (true)
			{
				byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WindowObjectEventSourceActivity.setPrimaryIdentitySelectorFullTrust);
				while (true)
				{
					byte* ptr2 = ptr;
					while (true)
					{
						if (num2 == 1)
						{
							return;
						}
						while (true)
						{
							IL_0108:
							byte b = *ptr2;
							while (true)
							{
								IL_00f8:
								ptr2++;
								while (true)
								{
									IL_00eb:
									if (b >= 1)
									{
										goto IL_009f;
									}
									goto IL_00c9;
									IL_00c9:
									while (true)
									{
										IL_00c9_2:
										byte* num3 = ptr2;
										num2 = 1;
										ptr2 = num3 + -200;
										num = 32;
										while (num != 32)
										{
											if (num != 1013)
											{
												goto IL_00f8;
											}
											switch (num)
											{
											case 18:
												goto IL_009f;
											case 19:
												goto IL_00aa;
											case 21:
												goto IL_00b5;
											case 4:
											case 5:
											case 7:
											case 10:
											case 17:
											case 22:
											case 25:
												goto IL_00c9_2;
											case 11:
												goto IL_00eb;
											case 1:
												goto IL_00f8;
											case 9:
											case 24:
												goto IL_0108;
											case 6:
											case 12:
												goto end_IL_008f;
											case 2:
												goto end_IL_0113;
											case 0:
											case 3:
											case 13:
											case 14:
											case 15:
											case 16:
											case 23:
												goto end_IL_0120;
											case 8:
											case 20:
												return;
											}
											continue;
											end_IL_008f:
											break;
										}
										break;
									}
									break;
									IL_009f:
									if (b <= 1)
									{
										goto IL_00aa;
									}
									goto IL_00c9;
									IL_00aa:
									if (1 >= b)
									{
										goto IL_00b5;
									}
									goto IL_00c9;
									IL_00b5:
									if (1 > b)
									{
										num = 10;
									}
									goto IL_00c9;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0113:
						break;
					}
					continue;
					end_IL_0120:
					break;
				}
			}
		}

		internal unsafe void method_2(PlayFabError playFabError_0)
		{
			int num = 23;
			int num2 = default(int);
			while (true)
			{
				num = 11;
				while (true)
				{
					byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setUseStdAsciiRulesgetLocalType.setServerIdentityObjectpermissionSetID);
					while (true)
					{
						byte* ptr2 = ptr;
						while (true)
						{
							if (num2 == 1)
							{
								return;
							}
							while (true)
							{
								byte b = *ptr2;
								while (true)
								{
									ptr2++;
									while (true)
									{
										IL_00d7:
										if (b >= 1)
										{
											while (true)
											{
												IL_00ca:
												if (b <= 1)
												{
													while (1 >= b)
													{
														while (1 > b)
														{
															num = 32;
															while (num != 32)
															{
																if (num != 1013)
																{
																	return;
																}
																switch (num)
																{
																case 7:
																	goto IL_00ad;
																case 18:
																	goto IL_00bd;
																case 24:
																	goto IL_00ca;
																case 0:
																	goto IL_00d7;
																case 8:
																	goto end_IL_00d7;
																case 1:
																case 9:
																	goto end_IL_00e4;
																case 5:
																case 13:
																case 16:
																case 17:
																case 20:
																case 21:
																	goto end_IL_009d;
																case 4:
																case 6:
																case 12:
																	goto end_IL_00f4;
																case 19:
																	goto end_IL_011f;
																case 10:
																case 11:
																case 14:
																case 15:
																case 25:
																	goto end_IL_012c;
																case 22:
																case 23:
																	goto end_IL_0136;
																case 2:
																case 3:
																	return;
																}
																continue;
																end_IL_009d:
																break;
															}
															break;
															IL_00ad:;
														}
														break;
														IL_00bd:;
													}
												}
												else
												{
													num = 5;
												}
												break;
											}
										}
										byte* num3 = ptr2;
										num2 = 1;
										ptr2 = num3 + -200;
										goto end_IL_00f4;
										continue;
										end_IL_00d7:
										break;
									}
									continue;
									end_IL_00e4:
									break;
								}
								continue;
								end_IL_00f4:
								break;
							}
							continue;
							end_IL_011f:
							break;
						}
						continue;
						end_IL_012c:
						break;
					}
					continue;
					end_IL_0136:
					break;
				}
			}
		}

		internal unsafe void method_3(PlayFabError playFabError_0)
		{
			int num = 10;
			int num2 = default(int);
			while (true)
			{
				byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClaimsGetActivationContextData.CausalityTraceLevelConstructorCallMessage);
				while (true)
				{
					byte* ptr2 = ptr;
					while (true)
					{
						if (num2 == 1)
						{
							return;
						}
						while (true)
						{
							byte b = *ptr2;
							while (true)
							{
								ptr2++;
								while (true)
								{
									IL_00c3:
									if (b >= 1)
									{
										while (b <= 1)
										{
											while (1 >= b)
											{
												num = 31;
												while (true)
												{
													if (num != 31)
													{
														if (num != 1012)
														{
															break;
														}
														switch (num)
														{
														case 2:
															goto IL_00a6;
														case 8:
															goto IL_00b6;
														case 15:
															goto IL_00c3;
														case 22:
															goto end_IL_00c3;
														case 17:
														case 23:
															goto end_IL_00d0;
														case 1:
														case 3:
														case 4:
														case 12:
														case 18:
														case 24:
															goto end_IL_0096;
														case 0:
														case 5:
														case 19:
															goto end_IL_00e0;
														case 13:
															goto end_IL_010d;
														case 6:
														case 7:
														case 9:
														case 10:
														case 14:
														case 16:
														case 21:
															goto end_IL_011a;
														case 11:
														case 20:
															return;
														}
														continue;
													}
													if (1 <= b)
													{
													}
													break;
													continue;
													end_IL_0096:
													break;
												}
												break;
												IL_00a6:;
											}
											break;
											IL_00b6:;
										}
									}
									byte* num3 = ptr2;
									num2 = 1;
									ptr2 = num3 + -200;
									goto end_IL_00e0;
									continue;
									end_IL_00c3:
									break;
								}
								continue;
								end_IL_00d0:
								break;
							}
							continue;
							end_IL_00e0:
							break;
						}
						continue;
						end_IL_010d:
						break;
					}
					continue;
					end_IL_011a:
					break;
				}
			}
		}

		internal void method_4(EResult eresult_0)
		{
		}
	}

	internal sealed class _003C_003Ec__DisplayClass1_0
	{
		public string string_0;

		private static IntPtr[] GreenGetSurrogateForCyclicalReference;

		private static Action<LoginResult> ClaimValueTypesGetArguments()
		{
			return _003C_003Ec.action_0;
		}

		private static string MarshalAsAttributeEmail(string[] string_1)
		{
			return string.Concat(string_1);
		}

		private static Action<PlayFabError> RuntimeFieldInfoStubUninstallDeployment(object object_0, IntPtr intptr_0)
		{
			return default(Action<PlayFabError>);
		}

		private static object SetPermissiongetIsMethodDef(bool bool_0)
		{
			return new bool?[1] { bool_0 };
		}

		private static int CreateFloatingDateRulegetCondition(int int_0, int int_1)
		{
			return UnityEngine.Random.Range(int_0, int_1);
		}

		private static bool IsLeapMonthStrongNameMembershipCondition()
		{
			return PhotonNetwork.ReconnectAndRejoin();
		}

		private static GorillaComputer GetGuidgetANSICodePage()
		{
			return GorillaComputer.instance;
		}

		static _003C_003Ec__DisplayClass1_0()
		{
			int num = 2;
			while (true)
			{
				Class296.Aw4EYyy3h();
				num = 10;
				while (true)
				{
					if (num != 10)
					{
						if (num == 991)
						{
							switch (num)
							{
							default:
								continue;
							case 2:
								break;
							case 0:
								return;
							case 1:
								return;
							case 3:
								return;
							}
							break;
						}
					}
					else
					{
						Class300.smethod_0();
					}
					return;
				}
			}
		}

		private static LoginWithSteamRequest GetUserStoreForSiteCSlocals()
		{
			return new LoginWithSteamRequest();
		}

		private static _003C_003Ec GetCallTypeEventDescriptor()
		{
			return _003C_003Ec._003C_003Ec_0;
		}

		private static void FileIOPermissionAccessIsJITTrackingEnabled()
		{
			Class9.smethod_82();
		}

		private static void GetNumericValueConsoleStream(Player player_0, string string_1)
		{
			player_0.NickName = string_1;
		}

		private static void setVersionCompatibilityAddArguments(LoginWithSteamRequest loginWithSteamRequest_0, Action<LoginResult> action_0, Action<PlayFabError> action_1, object object_0, Dictionary<string, string> dictionary_0)
		{
			PlayFabClientAPI.LoginWithSteam(loginWithSteamRequest_0, action_0, action_1, object_0, dictionary_0);
		}

		private static Player MLangDecodergetUseSalt()
		{
			return PhotonNetwork.LocalPlayer;
		}

		public _003C_003Ec__DisplayClass1_0()
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
		}

		private static string PropertiesToTestReadBufferAsyncd(string string_1, string string_2)
		{
			return string_1 + string_2;
		}

		private static void getWaitHandlegetMutex()
		{
			PlayerPrefs.Save();
		}

		private static Action<PlayFabError> ReAllocCoTaskMemgetEventMapSection()
		{
			return _003C_003Ec.action_1;
		}

		private static Action<LoginResult> SetCOMIUnknownIterableToEnumerableAdapter(object object_0, IntPtr intptr_0)
		{
			return default(Action<LoginResult>);
		}

		private static void PausedRSAPKCSSHASignatureDescription(string string_1, string string_2)
		{
			PlayerPrefs.SetString(string_1, string_2);
		}

		private static void InstallIO(GorillaComputer gorillaComputer_0, string string_1)
		{
			gorillaComputer_0.SetLocalNameTagText(string_1);
		}

		private static string ReturnXmlElementNamegetImpersonationLevel(_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_0_1)
		{
			return _003C_003Ec__DisplayClass1_0_1.string_0;
		}

		internal unsafe void method_0(ExecuteCloudScriptResult executeCloudScriptResult_0)
		{
			int num = 3;
			int num3 = default(int);
			int num4 = default(int);
			object obj = default(object);
			string text = default(string);
			string text2 = default(string);
			string text3 = default(string);
			string text4 = default(string);
			string text5 = default(string);
			string text6 = default(string);
			string text7 = default(string);
			string text8 = default(string);
			string text9 = default(string);
			string text10 = default(string);
			string text11 = default(string);
			string text12 = default(string);
			string text13 = default(string);
			string text14 = default(string);
			string text15 = default(string);
			string text16 = default(string);
			string text17 = default(string);
			string text18 = default(string);
			string text19 = default(string);
			string text20 = default(string);
			string text21 = default(string);
			string text22 = default(string);
			string text23 = default(string);
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 0;
				num = 14;
				while (true)
				{
					if (num != 14)
					{
						if (num != 995)
						{
							goto IL_00b8;
						}
						switch (num)
						{
						case 3:
							goto end_IL_0044;
						case 6:
							goto IL_0062;
						case 4:
							goto IL_0070;
						case 0:
						case 2:
							goto IL_00b8;
						case 1:
							goto IL_00bd;
						case 5:
						case 7:
							return;
						}
						continue;
					}
					num3 = 0;
					goto IL_0062;
					IL_00b8:
					if (num3 != 4)
					{
						goto IL_0070;
					}
					goto IL_00bd;
					IL_0070:
					((delegate*<ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, ref int, _003C_003Ec__DisplayClass1_0, void>)GreenGetSurrogateForCyclicalReference[num2])(ref num2, ref num3, ref num4, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref num5, ref num6, this);
					goto IL_00b8;
					IL_00bd:
					num3 = 0;
					return;
					IL_0062:
					num3 = 0;
					num = 2;
					goto IL_00b8;
					continue;
					end_IL_0044:
					break;
				}
			}
		}

		private static string LdelemUSTOREASSEMBLYSTATUSFLAGS(ref int int_0)
		{
			return int_0.ToString();
		}
	}

	private float float_0;

	private static double double_0;

	private static double double_1;

	private static float float_1;

	private static double double_2;

	private static int int_0;

	private static int int_1;

	private static IntPtr[] GCHandleTypeNotNullableValueTypeConstraint;

	private static IntPtr[] UpnNameCompareInfo;

	private static IntPtr[] EffectiveKeySizeTypeNameBuilder;

	private unsafe static int smethod_0(int int_2)
	{
		int num = 36;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 35;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									num = 6;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsFixedDateRuleFaultCode.CultureFallbackListMCMWrapperDictionary);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 50;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0224:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_01f4:
																					if (5 <= b)
																					{
																						goto IL_036c;
																					}
																					while (true)
																					{
																						IL_01e4:
																						if (2 >= b)
																						{
																							num = 109;
																							while (true)
																							{
																								if (num != 109)
																								{
																									if (num != 1090)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 29:
																										goto IL_01e4;
																									case 59:
																										goto IL_01f4;
																									case 40:
																										goto end_IL_01f4;
																									case 22:
																										goto end_IL_0204;
																									case 46:
																										goto IL_0224;
																									case 50:
																										goto end_IL_0224;
																									case 21:
																									case 37:
																										goto end_IL_0234;
																									case 15:
																										goto IL_0258;
																									case 14:
																										goto IL_0263;
																									case 11:
																										goto IL_0271;
																									case 53:
																										goto IL_0284;
																									case 16:
																									case 31:
																										goto IL_0292;
																									case 30:
																									case 54:
																										goto IL_02b5;
																									case 93:
																										goto IL_02c3;
																									case 77:
																									case 86:
																										goto IL_02d1;
																									case 45:
																										goto IL_02ea;
																									case 91:
																										goto IL_02f8;
																									case 98:
																										goto IL_0306;
																									case 33:
																									case 100:
																										goto IL_0319;
																									case 64:
																										goto IL_0342;
																									case 101:
																										goto IL_0350;
																									case 25:
																									case 58:
																										goto IL_036c;
																									case 76:
																										goto end_IL_01d1;
																									case 70:
																										goto IL_039d;
																									case 28:
																										goto IL_03b0;
																									case 57:
																										goto IL_03be;
																									case 99:
																										goto IL_03d1;
																									case 67:
																										goto IL_03df;
																									case 72:
																									case 85:
																										goto IL_03ea;
																									case 78:
																										goto IL_044c;
																									case 94:
																										goto IL_045f;
																									case 2:
																									case 81:
																										goto IL_046a;
																									case 79:
																										goto IL_0478;
																									case 19:
																									case 74:
																										goto IL_0486;
																									case 7:
																										goto IL_04a9;
																									case 63:
																										goto IL_04b7;
																									case 5:
																										goto IL_04c5;
																									case 23:
																										goto IL_04d8;
																									case 3:
																									case 102:
																										goto IL_04e6;
																									case 66:
																										goto IL_052f;
																									case 4:
																										goto IL_0543;
																									case 12:
																										goto IL_0553;
																									case 1:
																									case 84:
																										goto IL_055e;
																									case 10:
																										goto IL_0569;
																									case 41:
																										goto IL_0576;
																									case 24:
																									case 48:
																										goto IL_0581;
																									case 8:
																									case 9:
																									case 17:
																									case 20:
																									case 32:
																									case 34:
																									case 38:
																									case 42:
																									case 43:
																									case 47:
																									case 49:
																									case 52:
																									case 56:
																									case 65:
																									case 73:
																									case 80:
																									case 82:
																									case 90:
																									case 95:
																										goto end_IL_0214;
																									case 0:
																									case 13:
																									case 26:
																									case 39:
																									case 44:
																									case 55:
																									case 62:
																									case 68:
																									case 69:
																									case 71:
																									case 87:
																									case 89:
																									case 92:
																										goto end_IL_0244;
																									case 60:
																										goto end_IL_05ad;
																									case 6:
																										goto end_IL_05c0;
																									case 27:
																										goto end_IL_05ca;
																									case 83:
																										goto end_IL_05d5;
																									case 18:
																									case 88:
																										goto end_IL_05f3;
																									case 51:
																										goto end_IL_0603;
																									case 61:
																									case 75:
																										goto end_IL_0613;
																									case 35:
																										goto end_IL_0623;
																									case 36:
																										goto end_IL_0633;
																									case 96:
																									case 97:
																										goto IL_0657;
																									}
																									continue;
																								}
																								if (2 > b)
																								{
																									goto IL_02b5;
																								}
																								goto IL_0319;
																								IL_0319:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0342;
																								IL_0350:
																								num5--;
																								num = 87;
																								goto end_IL_0244;
																								IL_0342:
																								ptr2 += 8;
																								goto IL_0350;
																								IL_02b5:
																								if (1 < b)
																								{
																									goto end_IL_0214;
																								}
																								goto IL_02c3;
																								IL_02c3:
																								if (1 > b)
																								{
																									goto end_IL_0214;
																								}
																								goto IL_02d1;
																								IL_02d1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_02ea;
																								IL_02ea:
																								array[num5] = 0;
																								goto IL_02f8;
																								IL_02f8:
																								num5++;
																								goto IL_0306;
																								IL_0306:
																								ptr2 += 8;
																								goto end_IL_0244;
																								continue;
																								end_IL_01d1:
																								break;
																							}
																							break;
																						}
																						goto IL_0258;
																						IL_0284:
																						if (3 > b)
																						{
																							goto end_IL_0214;
																						}
																						goto IL_0292;
																						IL_0292:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0244;
																						IL_0258:
																						if (3 < b)
																						{
																							goto IL_0263;
																						}
																						goto IL_0284;
																						IL_0263:
																						if (4 < b)
																						{
																							goto end_IL_0214;
																						}
																						goto IL_0271;
																						IL_0271:
																						if (4 <= b)
																						{
																							goto end_IL_0244;
																						}
																						goto end_IL_0214;
																					}
																					goto IL_037a;
																					IL_03be:
																					ptr2 += 8;
																					goto end_IL_0244;
																					IL_036c:
																					array[num5] = 0;
																					goto IL_037a;
																					IL_037a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_039d;
																					IL_039d:
																					array2[num5] = null;
																					num = 28;
																					goto IL_03b0;
																					IL_03b0:
																					num5++;
																					goto IL_03be;
																					continue;
																					end_IL_01f4:
																					break;
																				}
																				continue;
																			}
																			goto IL_03d1;
																			IL_0581:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0244;
																			IL_03d1:
																			if (8 >= b)
																			{
																				goto IL_03df;
																			}
																			goto IL_0553;
																			IL_03df:
																			if (8 <= b)
																			{
																				goto IL_03ea;
																			}
																			goto IL_045f;
																			IL_03ea:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_044c;
																			IL_044c:
																			num5 -= 2;
																			goto end_IL_0244;
																			IL_045f:
																			if (6 < b)
																			{
																				goto IL_046a;
																			}
																			goto IL_04d8;
																			IL_046a:
																			if (7 < b)
																			{
																				goto end_IL_0214;
																			}
																			goto IL_0478;
																			IL_0478:
																			if (7 > b)
																			{
																				goto end_IL_0214;
																			}
																			goto IL_0486;
																			IL_0486:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04a9;
																			IL_04a9:
																			array[num5] = 0;
																			goto IL_04b7;
																			IL_04b7:
																			num5++;
																			goto IL_04c5;
																			IL_04c5:
																			ptr2 += 8;
																			goto end_IL_0244;
																			IL_04d8:
																			if (6 > b)
																			{
																				goto end_IL_0214;
																			}
																			goto IL_04e6;
																			IL_04e6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 66;
																			goto IL_052f;
																			IL_052f:
																			array[num5 - 2] = 0;
																			goto IL_0543;
																			IL_0543:
																			num5--;
																			goto end_IL_0244;
																			IL_0553:
																			if (9 < b)
																			{
																				goto IL_055e;
																			}
																			goto IL_0576;
																			IL_055e:
																			if (10 < b)
																			{
																				goto end_IL_0214;
																			}
																			goto IL_0569;
																			IL_0569:
																			if (10 > b)
																			{
																			}
																			goto end_IL_0214;
																			IL_0576:
																			if (9 > b)
																			{
																				goto end_IL_0214;
																			}
																			goto IL_0581;
																			continue;
																			end_IL_0204:
																			break;
																		}
																		continue;
																		end_IL_0214:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0244;
																continue;
																end_IL_0224:
																break;
															}
															continue;
															end_IL_0234:
															break;
														}
														continue;
														end_IL_0244:
														break;
													}
													continue;
												}
												goto IL_0657;
												IL_0657:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ad:
												break;
											}
											continue;
											end_IL_05c0:
											break;
										}
										continue;
										end_IL_05ca:
										break;
									}
									continue;
									end_IL_05d5:
									break;
								}
								continue;
								end_IL_05f3:
								break;
							}
							continue;
							end_IL_0603:
							break;
						}
						continue;
						end_IL_0613:
						break;
					}
					continue;
					end_IL_0623:
					break;
				}
				continue;
				end_IL_0633:
				break;
			}
		}
	}

	private static SteamAuthTicket getNaNSymbolXKeyStorageFlags(HAuthTicket hauthTicket_0)
	{
		return new SteamAuthTicket(hauthTicket_0);
	}

	private static HAuthTicket GetProgIdForTypePrivateUse(SteamAuthenticator steamAuthenticator_0, Action<string> action_0, Action<EResult> action_1)
	{
		return steamAuthenticator_0.GetAuthTicket(action_0, action_1);
	}

	private static SteamAuthenticator PrepareMethodEVENTINFOCLASS(PlayFabAuthenticator playFabAuthenticator_0)
	{
		return playFabAuthenticator_0.steamAuthenticator;
	}

	private static object getDeclaredNestedTypessetXCertificate(uint uint_0)
	{
		return new HAuthTicket(uint_0);
	}

	private static string AclRevisionDSUseAttribute(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 67;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									num = 82;
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InternetSiteAuthorityIDictionaryEnumerator.XsdStringTextElementEnumerator);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02e0:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_02c0:
																				if (7 < b)
																				{
																					while (true)
																					{
																						IL_02b3:
																						if (11 >= b)
																						{
																							while (true)
																							{
																								IL_02a3:
																								if (11 > b)
																								{
																									while (true)
																									{
																										IL_0293:
																										if (9 < b)
																										{
																											while (10 >= b)
																											{
																												while (10 <= b)
																												{
																													num = 144;
																													while (true)
																													{
																														if (num != 144)
																														{
																															if (num != 1125)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 4:
																																goto IL_0270;
																															case 26:
																															case 123:
																																goto IL_0283;
																															case 119:
																																goto IL_0293;
																															case 30:
																																goto IL_02a3;
																															case 0:
																															case 73:
																																goto IL_02b3;
																															case 18:
																																goto IL_02c0;
																															case 118:
																																goto IL_02d0;
																															case 131:
																																goto IL_02e0;
																															case 9:
																																goto end_IL_02e0;
																															case 39:
																															case 126:
																																goto end_IL_02f0;
																															case 106:
																															case 117:
																																goto end_IL_025d;
																															case 19:
																															case 46:
																																goto IL_0316;
																															case 104:
																																goto IL_0324;
																															case 108:
																																goto IL_0337;
																															case 41:
																																goto IL_0342;
																															case 55:
																															case 122:
																																goto IL_0355;
																															case 36:
																															case 135:
																																goto IL_0371;
																															case 52:
																																goto IL_0385;
																															case 98:
																																goto IL_03c4;
																															case 136:
																																goto IL_03d7;
																															case 3:
																															case 29:
																																goto IL_03e5;
																															case 71:
																																goto IL_03f8;
																															case 107:
																																goto IL_0438;
																															case 129:
																																goto IL_044c;
																															case 59:
																																goto IL_045f;
																															case 5:
																															case 124:
																																goto IL_046a;
																															case 15:
																																goto IL_04cc;
																															case 56:
																																goto IL_04df;
																															case 121:
																																goto IL_04ed;
																															case 12:
																															case 22:
																																goto IL_04fb;
																															case 105:
																																goto IL_051e;
																															case 111:
																																goto IL_052c;
																															case 64:
																																goto IL_053a;
																															case 27:
																																goto IL_054d;
																															case 38:
																															case 86:
																																goto IL_0558;
																															case 32:
																																goto IL_0598;
																															case 99:
																																goto IL_05ac;
																															case 43:
																																goto IL_05bf;
																															case 10:
																																goto IL_05cd;
																															case 72:
																															case 85:
																																goto IL_05db;
																															case 116:
																																goto IL_05e6;
																															case 47:
																															case 83:
																																goto IL_05f4;
																															case 54:
																																goto IL_060d;
																															case 53:
																																goto IL_061b;
																															case 25:
																																goto IL_0629;
																															case 87:
																																goto IL_063c;
																															case 34:
																																goto IL_0653;
																															case 42:
																															case 112:
																																goto IL_0661;
																															case 134:
																																goto IL_0693;
																															case 101:
																																goto IL_06a1;
																															case 11:
																															case 95:
																																goto IL_06b4;
																															case 127:
																															case 133:
																																goto IL_06cc;
																															case 45:
																															case 81:
																																goto IL_06da;
																															case 78:
																																goto IL_06e8;
																															case 17:
																															case 66:
																																goto IL_06f6;
																															case 128:
																																goto IL_0736;
																															case 16:
																																goto IL_074a;
																															case 75:
																																goto IL_075d;
																															case 33:
																															case 109:
																																goto IL_0768;
																															case 137:
																																goto IL_0773;
																															case 70:
																															case 90:
																																goto IL_078c;
																															case 50:
																																goto IL_07a3;
																															case 130:
																																goto IL_07c6;
																															case 40:
																																goto IL_07d0;
																															case 125:
																																goto IL_07de;
																															case 2:
																															case 20:
																															case 23:
																															case 35:
																															case 49:
																															case 57:
																															case 58:
																															case 60:
																															case 74:
																															case 79:
																															case 84:
																															case 89:
																															case 91:
																															case 93:
																															case 96:
																															case 97:
																															case 103:
																															case 110:
																															case 113:
																															case 114:
																															case 115:
																															case 120:
																															case 132:
																																goto end_IL_0270;
																															case 1:
																															case 6:
																															case 14:
																															case 21:
																															case 28:
																															case 37:
																															case 44:
																															case 48:
																															case 51:
																															case 61:
																															case 68:
																															case 69:
																															case 88:
																															case 92:
																															case 94:
																															case 100:
																															case 102:
																																goto end_IL_0300;
																															case 63:
																																goto end_IL_0801;
																															case 13:
																																goto end_IL_0814;
																															case 82:
																																goto end_IL_081e;
																															case 24:
																																goto end_IL_0829;
																															case 7:
																															case 31:
																																goto end_IL_083e;
																															case 80:
																																goto end_IL_0857;
																															case 67:
																																goto end_IL_0867;
																															case 62:
																																goto end_IL_0877;
																															case 76:
																																goto end_IL_0887;
																															case 77:
																																goto end_IL_0892;
																															case 8:
																															case 65:
																																goto IL_08ad;
																															}
																															continue;
																														}
																														goto IL_03f8;
																														IL_0438:
																														array[num5 - 2] = 0;
																														goto IL_044c;
																														IL_044c:
																														num5--;
																														goto end_IL_0300;
																														IL_03f8:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_0438;
																														continue;
																														end_IL_025d:
																														break;
																													}
																													goto IL_030b;
																													continue;
																													end_IL_0270:
																													break;
																													IL_0270:;
																												}
																												break;
																												IL_0283:;
																											}
																											break;
																										}
																										goto IL_045f;
																										IL_053a:
																										ptr2 += 8;
																										goto end_IL_0300;
																										IL_045f:
																										if (9 <= b)
																										{
																											goto IL_046a;
																										}
																										goto IL_04df;
																										IL_046a:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_04cc;
																										IL_04cc:
																										num5 -= 2;
																										goto end_IL_0300;
																										IL_04df:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_04ed;
																										IL_04ed:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_04fb;
																										IL_04fb:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_051e;
																										IL_051e:
																										array[num5] = 0;
																										goto IL_052c;
																										IL_052c:
																										num5++;
																										goto IL_053a;
																									}
																									break;
																								}
																								goto IL_0371;
																								IL_03c4:
																								ptr2 += 8;
																								goto end_IL_0300;
																								IL_0371:
																								array[num5 - 1] = 0;
																								goto IL_0385;
																								IL_0385:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)EffectiveKeySizeTypeNameBuilder[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_03c4;
																							}
																							break;
																						}
																						goto IL_030b;
																						IL_0355:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0300;
																						IL_030b:
																						if (13 < b)
																						{
																							goto IL_0316;
																						}
																						goto IL_0337;
																						IL_0316:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_0324;
																						IL_0324:
																						if (14 > b)
																						{
																						}
																						break;
																						IL_0337:
																						if (13 > b)
																						{
																							goto IL_0342;
																						}
																						goto IL_0355;
																						IL_0342:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_03d7;
																						IL_03d7:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_03e5;
																						IL_03e5:
																						num5--;
																						goto end_IL_0300;
																					}
																					break;
																				}
																				goto IL_054d;
																				IL_07c6:
																				array2[num5] = null;
																				goto IL_07d0;
																				IL_054d:
																				if (7 <= b)
																				{
																					goto IL_0558;
																				}
																				goto IL_05bf;
																				IL_0558:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0598;
																				IL_0598:
																				array[num5 - 2] = 0;
																				goto IL_05ac;
																				IL_05ac:
																				num5--;
																				goto end_IL_0300;
																				IL_05bf:
																				if (3 >= b)
																				{
																					goto IL_05cd;
																				}
																				goto IL_06cc;
																				IL_05cd:
																				if (3 > b)
																				{
																					goto IL_05db;
																				}
																				goto IL_06b4;
																				IL_05db:
																				if (1 >= b)
																				{
																					goto IL_05e6;
																				}
																				goto IL_063c;
																				IL_05e6:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_05f4;
																				IL_05f4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_060d;
																				IL_060d:
																				array[num5] = 0;
																				goto IL_061b;
																				IL_061b:
																				num5++;
																				goto IL_0629;
																				IL_0629:
																				ptr2 += 8;
																				goto end_IL_0300;
																				IL_063c:
																				if (2 < b)
																				{
																					break;
																				}
																				num = 34;
																				goto IL_0653;
																				IL_07d0:
																				num5++;
																				goto IL_07de;
																				IL_0653:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0661;
																				IL_0661:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 134;
																				goto IL_0693;
																				IL_0693:
																				ptr2 += 8;
																				goto IL_06a1;
																				IL_06a1:
																				num5--;
																				goto end_IL_0300;
																				IL_06b4:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0300;
																				IL_06cc:
																				if (5 < b)
																				{
																					goto IL_06da;
																				}
																				goto IL_075d;
																				IL_06da:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_06e8;
																				IL_06e8:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_06f6;
																				IL_06f6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0736;
																				IL_0736:
																				array[num5 - 2] = 0;
																				goto IL_074a;
																				IL_074a:
																				num5--;
																				goto end_IL_0300;
																				IL_075d:
																				if (5 > b)
																				{
																					goto IL_0768;
																				}
																				goto IL_078c;
																				IL_0768:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0773;
																				IL_0773:
																				if (4 <= b)
																				{
																					goto end_IL_0300;
																				}
																				num = 60;
																				break;
																				IL_07de:
																				ptr2 += 8;
																				goto end_IL_0300;
																				IL_078c:
																				array[num5] = 0;
																				num = 50;
																				goto IL_07a3;
																				IL_07a3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_07c6;
																			}
																			break;
																			IL_02d0:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0300;
																	continue;
																	end_IL_02e0:
																	break;
																}
																continue;
																end_IL_02f0:
																break;
															}
															continue;
															end_IL_0300:
															break;
														}
														continue;
													}
													goto IL_08ad;
													IL_08ad:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0801:
													break;
												}
												continue;
												end_IL_0814:
												break;
											}
											continue;
											end_IL_081e:
											break;
										}
										continue;
										end_IL_0829:
										break;
									}
									continue;
									end_IL_083e:
									break;
								}
								continue;
								end_IL_0857:
								break;
							}
							continue;
							end_IL_0867:
							break;
						}
						continue;
						end_IL_0877:
						break;
					}
					continue;
					end_IL_0887:
					break;
				}
				continue;
				end_IL_0892:
				break;
			}
		}
	}

	private static Player smethod_2()
	{
		return PhotonNetwork.LocalPlayer;
	}

	private static int WriteTimeoutPackageSimpleName(double double_3)
	{
		return Convert.ToInt32(double_3);
	}

	private static NetworkSystem AppendStringResult()
	{
		return NetworkSystem.Instance;
	}

	private unsafe static string smethod_3(int int_2)
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_05fb, IL_060e, IL_0621, IL_0631, IL_0641, IL_0651, IL_0661, IL_0671, IL_0681, IL_068e, IL_069e, IL_06ae, IL_06be, IL_06c9, IL_06d9, IL_06ec, IL_06fa, IL_0705, IL_0713, IL_0726, IL_0736, IL_0744, IL_074f, IL_0762, IL_0770, IL_0783, IL_0791, IL_079f, IL_07b2, IL_07bd, IL_07d6, IL_07e4, IL_07ef, IL_0802, IL_0810, IL_0823, IL_0831, IL_084b, IL_085e, IL_086c, IL_087a, IL_0890, IL_089e, IL_08bb, IL_08fa, IL_090d, IL_094c, IL_095f, IL_096a, IL_0983, IL_0991, IL_099f, IL_09b2, IL_09c0, IL_09ce, IL_09e1, IL_0a4b, IL_0a5e, IL_0a6c, IL_0a77, IL_0a85, IL_0a93, IL_0aa6, IL_0aaf, IL_0aba, IL_0aff, IL_0b0d, IL_0b1b, IL_0b34, IL_0b42, IL_0b55, IL_0b95, IL_0ba9, IL_0bbc, IL_0bcf, IL_0be8, IL_0bfb, IL_0c06, IL_0c29, IL_0c37, IL_0c45, IL_0c58, IL_0c66, IL_0c74, IL_0c82, IL_0ca6, IL_0cb4, IL_0cc7, IL_0ce5, IL_0cf8, IL_0d11, IL_0d25, IL_0d38, IL_0d60, IL_0d7c, IL_0d8a, IL_0da4, IL_0dc0, IL_0dcb, IL_0dde, IL_0dec, IL_0dfc, IL_0e0a, IL_0e1d, IL_0e2b, IL_0e3e, IL_0e7e, IL_0e92, IL_0ea5, IL_0eb3, IL_0ed0, IL_0f1f, IL_0f29, IL_0f56, IL_0f6a, IL_0f78, IL_0f8b, IL_0f95, IL_0fac, IL_0fbf, IL_0fcd, IL_0fdb, IL_0fe9, IL_104b, IL_105e, IL_106c, IL_107a, IL_10ba, IL_10ce, IL_10e1, IL_10ef, IL_10fd, IL_1108, IL_111c, IL_115b, IL_116e, IL_117c, IL_118a, IL_11ae, IL_11bc, IL_11ca, IL_11dd, IL_11e8, IL_11fb, IL_1209, IL_1217, IL_1260, IL_1274, IL_1287, IL_1290, IL_12c4, IL_12dd, IL_12eb, IL_12fe, IL_131a, IL_1328, IL_1368, IL_137c, IL_138f, IL_139a, IL_13ec, IL_13ff, IL_140a, IL_1418, IL_1426, IL_1439, IL_1444, IL_1457, IL_1465, IL_148e, IL_149c, IL_14af, IL_14bd, IL_14cb, IL_150c, IL_1520, IL_1533, IL_153e, IL_154c, IL_158c, IL_15a0, IL_15bc, IL_15ca, IL_15d3, IL_15e1, IL_160c, IL_1625, IL_163d, IL_1650, IL_166a, IL_167d, IL_168b, IL_1694, IL_16a8, IL_16f4, IL_1702, IL_1715, IL_172e, IL_173c, IL_174a, IL_175d, IL_1771, IL_17b0, IL_17c3, IL_1803, IL_1817, IL_182a, IL_183e, IL_1892, IL_18a0, IL_18b3, IL_18c7, IL_1906, IL_1919, IL_1924, IL_1932, IL_1946, IL_1985, IL_1998, IL_19a6, IL_19b4, IL_19bd, IL_19d1, IL_1a10, IL_1a23, IL_1a2c, IL_1a40, IL_1a7f, IL_1a8f, IL_1aab, IL_1abe, IL_1ac8, IL_1adc, IL_1af1, IL_1b01, IL_1b11, IL_1b21, IL_1b31, IL_1b41, IL_1b51, IL_1b61, IL_1b7c are reachable both inside and outside the pinned region starting at IL_1b76. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 146;
		int num5 = default(int);
		int num6 = default(int);
		object[] array7 = default(object[]);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef66 = default(int);
			ref int reference = ref __rxRef66;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[2];
			if (true)
			{
				while (true)
				{
					IL_1b61:
					num2 = 1;
					while (true)
					{
						IL_1b51:
						num3 = num2 * 4;
						while (true)
						{
							IL_1b41:
							num4 = num2 * 8;
							while (true)
							{
								IL_1b31:
								array2 = new byte[4];
								while (true)
								{
									IL_1b21:
									array3 = new object[4];
									while (true)
									{
										IL_1b11:
										array4 = new int[4];
										while (true)
										{
											IL_1b01:
											array5 = new int[8];
											while (true)
											{
												IL_1af1:
												array6 = new long[4];
												while (true)
												{
													IL_1adc:
													array5[0] = int_2;
													while (true)
													{
														IL_1ac8:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PurgeAccessControlITupleInternal.SegmentStateTimeSpan);
														num = 319;
														while (true)
														{
															IL_1abe:
															ptr2 = ptr;
															while (true)
															{
																IL_1aab:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_06be:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_06ae:
																			ptr2++;
																			while (true)
																			{
																				IL_069e:
																				if (b >= 1)
																				{
																					while (b <= 44)
																					{
																						while (true)
																						{
																							IL_0681:
																							if (22 < b)
																							{
																								while (true)
																								{
																									IL_0671:
																									if (33 >= b)
																									{
																										num = 185;
																										while (true)
																										{
																											IL_0661:
																											if (33 > b)
																											{
																												while (true)
																												{
																													IL_0651:
																													if (27 < b)
																													{
																														while (true)
																														{
																															IL_0641:
																															if (30 >= b)
																															{
																																while (true)
																																{
																																	IL_0631:
																																	if (30 > b)
																																	{
																																		while (true)
																																		{
																																			IL_0621:
																																			if (28 >= b)
																																			{
																																				while (28 <= b)
																																				{
																																					num = 372;
																																					while (true)
																																					{
																																						if (num != 372)
																																						{
																																							if (num != 1353)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 146:
																																								break;
																																							default:
																																								continue;
																																							case 28:
																																								goto IL_060e;
																																							case 136:
																																								goto IL_0621;
																																							case 270:
																																								goto IL_0631;
																																							case 226:
																																								goto IL_0641;
																																							case 86:
																																								goto IL_0651;
																																							case 185:
																																								goto IL_0661;
																																							case 162:
																																								goto IL_0671;
																																							case 304:
																																								goto IL_0681;
																																							case 31:
																																								goto IL_068e;
																																							case 353:
																																								goto IL_069e;
																																							case 274:
																																								goto IL_06ae;
																																							case 59:
																																							case 187:
																																								goto IL_06be;
																																							case 63:
																																								goto IL_06c9;
																																							case 97:
																																								goto IL_06d9;
																																							case 123:
																																								goto IL_06ec;
																																							case 37:
																																								goto IL_06fa;
																																							case 81:
																																								goto IL_0705;
																																							case 43:
																																								goto IL_0713;
																																							case 50:
																																								goto IL_0726;
																																							case 154:
																																								goto IL_0736;
																																							case 60:
																																								goto IL_0744;
																																							case 80:
																																								goto IL_074f;
																																							case 11:
																																								goto IL_0762;
																																							case 101:
																																								goto IL_0770;
																																							case 158:
																																								goto IL_0783;
																																							case 176:
																																								goto IL_0791;
																																							case 166:
																																								goto IL_079f;
																																							case 227:
																																								goto IL_07b2;
																																							case 137:
																																							case 153:
																																								goto IL_07bd;
																																							case 164:
																																								goto IL_07d6;
																																							case 119:
																																								goto IL_07e4;
																																							case 89:
																																								goto IL_07ef;
																																							case 204:
																																								goto IL_0802;
																																							case 38:
																																								goto IL_0810;
																																							case 228:
																																								goto IL_0823;
																																							case 20:
																																							case 213:
																																								goto IL_0831;
																																							case 23:
																																								goto IL_084b;
																																							case 231:
																																								goto IL_085e;
																																							case 247:
																																							case 258:
																																								goto IL_087a;
																																							case 259:
																																								goto IL_0890;
																																							case 24:
																																							case 124:
																																								goto IL_089e;
																																							case 217:
																																								goto IL_08bb;
																																							case 175:
																																								goto IL_08fa;
																																							case 260:
																																								goto IL_090d;
																																							case 61:
																																								goto IL_094c;
																																							case 267:
																																								goto IL_095f;
																																							case 179:
																																							case 196:
																																								goto IL_096a;
																																							case 249:
																																								goto IL_0983;
																																							case 172:
																																								goto IL_0991;
																																							case 160:
																																								goto IL_099f;
																																							case 205:
																																								goto IL_09b2;
																																							case 233:
																																								goto IL_09c0;
																																							case 149:
																																								goto IL_09ce;
																																							case 271:
																																								goto IL_09e1;
																																							case 222:
																																								goto IL_0a4b;
																																							case 282:
																																								goto IL_0a5e;
																																							case 44:
																																								goto IL_0a6c;
																																							case 244:
																																								goto IL_0a77;
																																							case 13:
																																								goto IL_0a85;
																																							case 278:
																																								goto IL_0a93;
																																							case 253:
																																								goto IL_0aaf;
																																							case 91:
																																							case 248:
																																								goto IL_0aba;
																																							case 25:
																																								goto IL_0aff;
																																							case 99:
																																								goto IL_0b0d;
																																							case 17:
																																							case 82:
																																								goto IL_0b1b;
																																							case 157:
																																								goto IL_0b34;
																																							case 120:
																																								goto IL_0b42;
																																							case 229:
																																							case 285:
																																								goto IL_0b55;
																																							case 156:
																																								goto IL_0b95;
																																							case 181:
																																								goto IL_0ba9;
																																							case 289:
																																								goto IL_0bbc;
																																							case 257:
																																							case 295:
																																								goto IL_0bcf;
																																							case 173:
																																								goto IL_0be8;
																																							case 298:
																																								goto IL_0bfb;
																																							case 58:
																																							case 246:
																																								goto IL_0c06;
																																							case 188:
																																								goto IL_0c29;
																																							case 193:
																																								goto IL_0c37;
																																							case 8:
																																								goto IL_0c45;
																																							case 32:
																																								goto IL_0c58;
																																							case 21:
																																								goto IL_0c66;
																																							case 45:
																																								goto IL_0c74;
																																							case 52:
																																							case 292:
																																								goto IL_0c82;
																																							case 252:
																																								goto IL_0ca6;
																																							case 170:
																																								goto IL_0cb4;
																																							case 100:
																																							case 299:
																																								goto IL_0cc7;
																																							case 55:
																																								goto IL_0ce5;
																																							case 221:
																																							case 300:
																																								goto IL_0cf8;
																																							case 301:
																																								goto IL_0d11;
																																							case 110:
																																								goto IL_0d25;
																																							case 310:
																																								goto IL_0d38;
																																							case 311:
																																								goto IL_0d60;
																																							case 312:
																																								goto IL_0d7c;
																																							case 3:
																																							case 178:
																																								goto IL_0d8a;
																																							case 171:
																																								goto IL_0da4;
																																							case 313:
																																								goto IL_0dc0;
																																							case 200:
																																							case 297:
																																								goto IL_0dcb;
																																							case 48:
																																								goto IL_0dde;
																																							case 243:
																																								goto IL_0dec;
																																							case 169:
																																							case 316:
																																								goto IL_0dfc;
																																							case 79:
																																								goto IL_0e0a;
																																							case 73:
																																								goto IL_0e1d;
																																							case 242:
																																								goto IL_0e2b;
																																							case 232:
																																							case 323:
																																								goto IL_0e3e;
																																							case 168:
																																								goto IL_0e7e;
																																							case 151:
																																								goto IL_0e92;
																																							case 325:
																																								goto IL_0ea5;
																																							case 36:
																																							case 125:
																																								goto IL_0eb3;
																																							case 235:
																																								goto IL_0f6a;
																																							case 276:
																																								goto IL_0f78;
																																							case 326:
																																								goto IL_0f8b;
																																							case 147:
																																								goto IL_0f95;
																																							case 314:
																																								goto IL_0fac;
																																							case 329:
																																								goto IL_0fbf;
																																							case 163:
																																								goto IL_0fcd;
																																							case 127:
																																								goto IL_0fdb;
																																							case 67:
																																							case 320:
																																								goto IL_0fe9;
																																							case 95:
																																								goto IL_104b;
																																							case 336:
																																								goto IL_105e;
																																							case 15:
																																								goto IL_106c;
																																							case 75:
																																							case 318:
																																								goto IL_107a;
																																							case 34:
																																								goto IL_10ba;
																																							case 121:
																																								goto IL_10ce;
																																							case 338:
																																								goto IL_10e1;
																																							case 287:
																																								goto IL_10ef;
																																							case 142:
																																								goto IL_10fd;
																																							case 203:
																																							case 309:
																																								goto IL_1108;
																																							case 328:
																																								goto IL_111c;
																																							case 273:
																																								goto IL_115b;
																																							case 306:
																																								goto IL_116e;
																																							case 250:
																																								goto IL_117c;
																																							case 236:
																																							case 245:
																																								goto IL_118a;
																																							case 129:
																																								goto IL_11ae;
																																							case 234:
																																								goto IL_11bc;
																																							case 288:
																																								goto IL_11ca;
																																							case 220:
																																								goto IL_11dd;
																																							case 155:
																																								goto IL_11e8;
																																							case 269:
																																								goto IL_11fb;
																																							case 262:
																																								goto IL_1209;
																																							case 54:
																																							case 272:
																																								goto IL_1217;
																																							case 40:
																																								goto IL_1260;
																																							case 0:
																																								goto IL_1274;
																																							case 9:
																																							case 130:
																																								goto IL_1290;
																																							case 190:
																																								goto IL_12c4;
																																							case 341:
																																								goto IL_12dd;
																																							case 65:
																																								goto IL_12eb;
																																							case 296:
																																							case 342:
																																								goto IL_12fe;
																																							case 344:
																																								goto IL_131a;
																																							case 71:
																																							case 115:
																																								goto IL_1328;
																																							case 191:
																																								goto IL_1368;
																																							case 224:
																																								goto IL_137c;
																																							case 347:
																																								goto IL_138f;
																																							case 66:
																																							case 230:
																																								goto IL_139a;
																																							case 139:
																																								goto IL_13ec;
																																							case 116:
																																								goto IL_13ff;
																																							case 6:
																																								goto IL_140a;
																																							case 161:
																																								goto IL_1418;
																																							case 114:
																																								goto IL_1426;
																																							case 57:
																																								goto IL_1439;
																																							case 118:
																																								goto IL_1444;
																																							case 348:
																																								goto IL_1457;
																																							case 64:
																																							case 74:
																																								goto IL_1465;
																																							case 98:
																																								goto IL_148e;
																																							case 117:
																																								goto IL_149c;
																																							case 349:
																																								goto IL_14af;
																																							case 18:
																																								goto IL_14bd;
																																							case 16:
																																							case 159:
																																								goto IL_14cb;
																																							case 103:
																																								goto IL_150c;
																																							case 144:
																																								goto IL_1520;
																																							case 351:
																																								goto IL_1533;
																																							case 111:
																																								goto IL_153e;
																																							case 2:
																																							case 184:
																																								goto IL_154c;
																																							case 223:
																																								goto IL_158c;
																																							case 211:
																																								goto IL_15a0;
																																							case 197:
																																								goto IL_15bc;
																																							case 317:
																																								goto IL_15d3;
																																							case 19:
																																							case 70:
																																								goto IL_15e1;
																																							case 96:
																																								goto IL_160c;
																																							case 113:
																																							case 352:
																																								goto IL_1625;
																																							case 354:
																																								goto IL_163d;
																																							case 112:
																																							case 356:
																																								goto IL_1650;
																																							case 152:
																																								goto IL_166a;
																																							case 357:
																																								goto IL_167d;
																																							case 46:
																																							case 76:
																																								goto IL_1694;
																																							case 126:
																																								goto IL_16a8;
																																							case 1:
																																								goto IL_16f4;
																																							case 183:
																																								goto IL_1702;
																																							case 254:
																																							case 363:
																																								goto IL_1715;
																																							case 208:
																																								goto IL_172e;
																																							case 264:
																																								goto IL_173c;
																																							case 47:
																																								goto IL_174a;
																																							case 199:
																																							case 364:
																																								goto IL_175d;
																																							case 68:
																																								goto IL_1771;
																																							case 174:
																																								goto IL_17b0;
																																							case 22:
																																							case 365:
																																								goto IL_17c3;
																																							case 308:
																																								goto IL_1803;
																																							case 279:
																																								goto IL_1817;
																																							case 165:
																																								goto IL_182a;
																																							case 90:
																																								goto IL_183e;
																																							case 294:
																																								goto IL_1892;
																																							case 360:
																																								goto IL_18a0;
																																							case 327:
																																							case 362:
																																								goto IL_18b3;
																																							case 182:
																																								goto IL_18c7;
																																							case 216:
																																								goto IL_1906;
																																							case 334:
																																								goto end_IL_05fb;
																																							case 107:
																																								goto IL_1924;
																																							case 53:
																																							case 138:
																																								goto IL_1932;
																																							case 26:
																																								goto IL_1946;
																																							case 210:
																																								goto IL_1985;
																																							case 240:
																																								goto IL_1998;
																																							case 102:
																																								goto IL_19a6;
																																							case 42:
																																							case 268:
																																								goto IL_19bd;
																																							case 281:
																																								goto IL_19d1;
																																							case 14:
																																								goto IL_1a10;
																																							case 128:
																																							case 277:
																																								goto IL_1a2c;
																																							case 78:
																																								goto IL_1a40;
																																							case 361:
																																								goto IL_1a7f;
																																							case 5:
																																							case 10:
																																							case 30:
																																							case 62:
																																							case 69:
																																							case 72:
																																							case 77:
																																							case 84:
																																							case 85:
																																							case 88:
																																							case 93:
																																							case 104:
																																							case 106:
																																							case 109:
																																							case 122:
																																							case 131:
																																							case 132:
																																							case 133:
																																							case 141:
																																							case 148:
																																							case 189:
																																							case 192:
																																							case 194:
																																							case 195:
																																							case 198:
																																							case 212:
																																							case 214:
																																							case 215:
																																							case 225:
																																							case 239:
																																							case 255:
																																							case 256:
																																							case 266:
																																							case 286:
																																							case 290:
																																							case 293:
																																							case 302:
																																							case 305:
																																							case 321:
																																							case 330:
																																							case 332:
																																							case 333:
																																							case 335:
																																							case 340:
																																							case 343:
																																							case 346:
																																							case 359:
																																								goto end_IL_060e;
																																							case 4:
																																							case 7:
																																							case 12:
																																							case 27:
																																							case 29:
																																							case 33:
																																							case 39:
																																							case 41:
																																							case 49:
																																							case 56:
																																							case 83:
																																							case 87:
																																							case 94:
																																							case 134:
																																							case 135:
																																							case 140:
																																							case 143:
																																							case 150:
																																							case 167:
																																							case 177:
																																							case 180:
																																							case 186:
																																							case 201:
																																							case 202:
																																							case 209:
																																							case 218:
																																							case 219:
																																							case 237:
																																							case 238:
																																							case 251:
																																							case 261:
																																							case 263:
																																							case 265:
																																							case 275:
																																							case 280:
																																							case 283:
																																							case 284:
																																							case 291:
																																							case 307:
																																							case 315:
																																							case 322:
																																							case 324:
																																							case 331:
																																							case 339:
																																							case 345:
																																							case 350:
																																							case 358:
																																								goto IL_1aab;
																																							case 319:
																																								goto IL_1abe;
																																							case 51:
																																								goto IL_1ac8;
																																							case 92:
																																								goto IL_1adc;
																																							case 355:
																																								goto IL_1af1;
																																							case 105:
																																								goto IL_1b01;
																																							case 206:
																																								goto IL_1b11;
																																							case 207:
																																								goto IL_1b21;
																																							case 241:
																																								goto IL_1b31;
																																							case 35:
																																								goto IL_1b41;
																																							case 337:
																																								goto IL_1b51;
																																							case 145:
																																								goto IL_1b61;
																																							case 108:
																																							case 303:
																																								goto IL_1b7c;
																																							}
																																							goto end_IL_069e;
																																						}
																																						goto IL_182a;
																																						IL_1892:
																																						num6--;
																																						goto IL_18a0;
																																						IL_18a0:
																																						ptr2 += 8;
																																						goto IL_1aab;
																																						IL_182a:
																																						array2[num6 - 2] = 0;
																																						goto IL_183e;
																																						IL_183e:
																																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																						goto IL_1892;
																																						continue;
																																						end_IL_05fb:
																																						break;
																																					}
																																					goto IL_1919;
																																					continue;
																																					end_IL_060e:
																																					break;
																																					IL_060e:;
																																				}
																																				break;
																																			}
																																			goto IL_06d9;
																																			IL_084b:
																																			num6--;
																																			goto IL_1aab;
																																			IL_06d9:
																																			if (29 < b)
																																			{
																																				break;
																																			}
																																			goto IL_0823;
																																			IL_0823:
																																			if (29 > b)
																																			{
																																				break;
																																			}
																																			goto IL_0831;
																																			IL_0831:
																																			global::_003CModule_003E.int_204 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																			goto IL_084b;
																																		}
																																		break;
																																	}
																																	goto IL_18b3;
																																	IL_1906:
																																	ptr2 += 8;
																																	goto IL_1aab;
																																	IL_18b3:
																																	array2[num6 - 1] = 3;
																																	goto IL_18c7;
																																	IL_18c7:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																	goto IL_1906;
																																}
																																break;
																															}
																															goto IL_1919;
																															IL_19d1:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																															goto IL_1a10;
																															IL_1919:
																															if (31 >= b)
																															{
																																goto IL_1924;
																															}
																															goto IL_1998;
																															IL_1924:
																															if (31 > b)
																															{
																																break;
																															}
																															goto IL_1932;
																															IL_1932:
																															array2[num6 - 1] = 3;
																															goto IL_1946;
																															IL_1946:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																															goto IL_1985;
																															IL_1985:
																															ptr2 += 8;
																															goto IL_1aab;
																															IL_1998:
																															if (32 < b)
																															{
																																break;
																															}
																															goto IL_19a6;
																															IL_19a6:
																															if (32 > b)
																															{
																																break;
																															}
																															num = 42;
																															goto IL_19bd;
																															IL_1a10:
																															ptr2 += 8;
																															goto IL_1aab;
																															IL_19bd:
																															array2[num6 - 1] = 3;
																															goto IL_19d1;
																														}
																														break;
																													}
																													goto IL_10e1;
																													IL_1290:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													num = 190;
																													goto IL_12c4;
																													IL_10e1:
																													if (27 > b)
																													{
																														goto IL_10ef;
																													}
																													num = 9;
																													goto IL_1290;
																													IL_10ef:
																													if (24 >= b)
																													{
																														goto IL_10fd;
																													}
																													goto IL_11dd;
																													IL_10fd:
																													if (24 <= b)
																													{
																														goto IL_1108;
																													}
																													goto IL_116e;
																													IL_1108:
																													array2[num6 - 1] = 3;
																													goto IL_111c;
																													IL_111c:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_115b;
																													IL_115b:
																													ptr2 += 8;
																													goto IL_1aab;
																													IL_116e:
																													if (23 < b)
																													{
																														break;
																													}
																													goto IL_117c;
																													IL_117c:
																													if (23 > b)
																													{
																														break;
																													}
																													goto IL_118a;
																													IL_118a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])();
																													goto IL_11ae;
																													IL_11ae:
																													array2[num6] = 0;
																													goto IL_11bc;
																													IL_11bc:
																													num6++;
																													goto IL_11ca;
																													IL_11ca:
																													ptr2 += 8;
																													goto IL_1aab;
																													IL_11dd:
																													if (25 >= b)
																													{
																														goto IL_11e8;
																													}
																													goto IL_11fb;
																													IL_11e8:
																													if (25 > b)
																													{
																														break;
																													}
																													goto IL_1650;
																													IL_1650:
																													global::_003CModule_003E.int_205 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_166a;
																													IL_166a:
																													num6--;
																													goto IL_1aab;
																													IL_11fb:
																													if (26 < b)
																													{
																														break;
																													}
																													goto IL_1209;
																													IL_1209:
																													if (26 > b)
																													{
																														break;
																													}
																													goto IL_1217;
																													IL_1217:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													num = 40;
																													goto IL_1260;
																													IL_1260:
																													array2[num6 - 2] = 3;
																													goto IL_1274;
																													IL_1274:
																													num6--;
																													goto IL_1aab;
																													IL_12c4:
																													array2[num6 - 1] = 0;
																													goto IL_1aab;
																												}
																												break;
																											}
																											num = 277;
																											goto IL_1a2c;
																											IL_1a40:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_1a7f;
																											IL_1a7f:
																											ptr2 += 8;
																											goto IL_1aab;
																											IL_1a2c:
																											array2[num6 - 1] = 0;
																											goto IL_1a40;
																										}
																										break;
																									}
																									goto IL_06c9;
																									IL_1694:
																									array2[num6 - 2] = 5;
																									goto IL_16a8;
																									IL_16a8:
																									array3[num6 - 2] = ((delegate*<string, string, string>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																									goto IL_16f4;
																									IL_06c9:
																									if (39 < b)
																									{
																										goto IL_0736;
																									}
																									goto IL_07b2;
																									IL_07b2:
																									if (39 <= b)
																									{
																										goto IL_07bd;
																									}
																									goto IL_07d6;
																									IL_07bd:
																									array2[num6 - 1] = 5;
																									goto IL_09e1;
																									IL_09e1:
																									array3[num6 - 1] = ((delegate*<ref char, string>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref char>)UpnNameCompareInfo[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																									goto IL_0a4b;
																									IL_0a4b:
																									ptr2 += 8;
																									goto IL_1aab;
																									IL_07d6:
																									if (36 < b)
																									{
																										goto IL_07e4;
																									}
																									goto IL_0d7c;
																									IL_07e4:
																									if (37 >= b)
																									{
																										goto IL_07ef;
																									}
																									goto IL_0802;
																									IL_07ef:
																									if (37 > b)
																									{
																										break;
																									}
																									goto IL_0cc7;
																									IL_0cc7:
																									array3[num6] = ((delegate*<string>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])();
																									goto IL_0ce5;
																									IL_0ce5:
																									array2[num6] = 5;
																									goto IL_12dd;
																									IL_12dd:
																									num6++;
																									goto IL_12eb;
																									IL_12eb:
																									ptr2 += 8;
																									goto IL_1aab;
																									IL_0802:
																									if (38 < b)
																									{
																										break;
																									}
																									goto IL_0810;
																									IL_0810:
																									if (38 > b)
																									{
																										break;
																									}
																									goto IL_0dfc;
																									IL_0dfc:
																									array2[num6] = 15;
																									goto IL_0e0a;
																									IL_0e0a:
																									array4[num6] = *(int*)(ptr2 + num3);
																									goto IL_0e1d;
																									IL_0e1d:
																									ptr2 += 8;
																									goto IL_0e2b;
																									IL_0e2b:
																									num6++;
																									goto IL_1aab;
																									IL_0d7c:
																									if (36 <= b)
																									{
																										goto IL_0d8a;
																									}
																									goto IL_1533;
																									IL_0d8a:
																									global::_003CModule_003E.char_4 = (char)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_0da4;
																									IL_0da4:
																									num6--;
																									num = 315;
																									goto IL_1aab;
																									IL_1533:
																									if (34 >= b)
																									{
																										goto IL_153e;
																									}
																									goto IL_15bc;
																									IL_153e:
																									if (34 > b)
																									{
																										break;
																									}
																									goto IL_154c;
																									IL_154c:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_158c;
																									IL_158c:
																									array2[num6 - 2] = 0;
																									goto IL_15a0;
																									IL_15a0:
																									num6--;
																									num = 201;
																									goto IL_1aab;
																									IL_15bc:
																									if (35 < b)
																									{
																										break;
																									}
																									num = 317;
																									goto IL_15d3;
																									IL_16f4:
																									num6--;
																									goto IL_1702;
																									IL_15d3:
																									if (35 > b)
																									{
																										break;
																									}
																									goto IL_15e1;
																									IL_15e1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (ushort)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_160c;
																									IL_160c:
																									array2[num6 - 1] = 0;
																									goto IL_1aab;
																									IL_0736:
																									if (42 < b)
																									{
																										goto IL_0744;
																									}
																									goto IL_0bfb;
																									IL_0744:
																									if (43 >= b)
																									{
																										goto IL_074f;
																									}
																									goto IL_0762;
																									IL_074f:
																									if (43 > b)
																									{
																										break;
																									}
																									goto IL_12fe;
																									IL_12fe:
																									num7 = ptr2;
																									num8 = -200;
																									num5 = 1;
																									ptr2 = num7 + num8;
																									goto IL_1aab;
																									IL_0762:
																									if (44 < b)
																									{
																										break;
																									}
																									goto IL_0770;
																									IL_0770:
																									if (44 > b)
																									{
																									}
																									break;
																									IL_0bfb:
																									if (42 <= b)
																									{
																										goto IL_0c06;
																									}
																									goto IL_0c58;
																									IL_0c06:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																									goto IL_0c29;
																									IL_0c29:
																									array2[num6] = 0;
																									goto IL_0c37;
																									IL_0c37:
																									num6++;
																									goto IL_0c45;
																									IL_0c45:
																									ptr2 += 8;
																									goto IL_1aab;
																									IL_0c58:
																									if (40 < b)
																									{
																										goto IL_0c66;
																									}
																									goto IL_167d;
																									IL_0c66:
																									if (41 < b)
																									{
																										break;
																									}
																									goto IL_0c74;
																									IL_0c74:
																									if (41 > b)
																									{
																										break;
																									}
																									goto IL_0c82;
																									IL_0c82:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])();
																									goto IL_0ca6;
																									IL_0ca6:
																									array2[num6] = 0;
																									goto IL_0cb4;
																									IL_0cb4:
																									num6++;
																									goto IL_0d60;
																									IL_0d60:
																									ptr2 += 8;
																									num = 251;
																									goto IL_1aab;
																									IL_167d:
																									if (40 > b)
																									{
																										break;
																									}
																									num = 46;
																									goto IL_1694;
																									IL_1702:
																									ptr2 += 8;
																									goto IL_1aab;
																								}
																								break;
																							}
																							goto IL_06ec;
																							IL_14cb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_150c;
																							IL_06ec:
																							if (22 > b)
																							{
																								goto IL_06fa;
																							}
																							goto IL_087a;
																							IL_06fa:
																							if (11 >= b)
																							{
																								goto IL_0705;
																							}
																							goto IL_0726;
																							IL_0705:
																							if (11 > b)
																							{
																								goto IL_0713;
																							}
																							goto IL_175d;
																							IL_0713:
																							if (5 < b)
																							{
																								goto IL_085e;
																							}
																							goto IL_0a5e;
																							IL_0a5e:
																							if (5 > b)
																							{
																								goto IL_0a6c;
																							}
																							goto IL_0b55;
																							IL_0a6c:
																							if (2 < b)
																							{
																								goto IL_0a77;
																							}
																							num = 253;
																							goto IL_0aaf;
																							IL_0a77:
																							if (3 < b)
																							{
																								goto IL_0a85;
																							}
																							goto IL_1457;
																							IL_0a85:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0a93;
																							IL_0a93:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0cf8;
																							IL_0cf8:
																							array2[num6] = 0;
																							num = 310;
																							goto IL_0d38;
																							IL_0d38:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0f8b;
																							IL_0f8b:
																							array3[num6] = null;
																							goto IL_0f95;
																							IL_0f95:
																							num6++;
																							num = 314;
																							goto IL_0fac;
																							IL_0fac:
																							ptr2 += 8;
																							goto IL_1aab;
																							IL_1457:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_1465;
																							IL_1465:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_148e;
																							IL_148e:
																							ptr2 += 8;
																							goto IL_149c;
																							IL_149c:
																							num6--;
																							goto IL_1aab;
																							IL_150c:
																							array2[num6 - 2] = 0;
																							goto IL_1520;
																							IL_0aaf:
																							if (2 <= b)
																							{
																								goto IL_0aba;
																							}
																							goto IL_0aff;
																							IL_0aba:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0d11;
																							IL_0d11:
																							array2[num6 - 2] = 0;
																							goto IL_0d25;
																							IL_0d25:
																							num6--;
																							goto IL_1aab;
																							IL_0aff:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0b0d;
																							IL_0b0d:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0b1b;
																							IL_0b1b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_0b34;
																							IL_0b34:
																							array2[num6] = 0;
																							goto IL_0b42;
																							IL_0b42:
																							num6++;
																							goto IL_163d;
																							IL_163d:
																							ptr2 += 8;
																							goto IL_1aab;
																							IL_0b55:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0b95;
																							IL_0b95:
																							array2[num6 - 2] = 0;
																							goto IL_0ba9;
																							IL_0ba9:
																							num6--;
																							goto IL_1aab;
																							IL_085e:
																							if (8 >= b)
																							{
																								num = 313;
																								goto IL_0dc0;
																							}
																							goto IL_0fbf;
																							IL_1520:
																							num6--;
																							goto IL_1aab;
																							IL_0dc0:
																							if (8 <= b)
																							{
																								goto IL_0dcb;
																							}
																							goto IL_0dde;
																							IL_0dcb:
																							num6--;
																							goto IL_1aab;
																							IL_0dde:
																							if (6 >= b)
																							{
																								goto IL_0dec;
																							}
																							goto IL_105e;
																							IL_0dec:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_0e3e;
																							IL_0e3e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0e7e;
																							IL_0e7e:
																							array2[num6 - 2] = 0;
																							goto IL_0e92;
																							IL_0e92:
																							num6--;
																							goto IL_1aab;
																							IL_105e:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_106c;
																							IL_106c:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_107a;
																							IL_107a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_10ba;
																							IL_10ba:
																							array2[num6 - 2] = 0;
																							goto IL_10ce;
																							IL_10ce:
																							num6--;
																							goto IL_1aab;
																							IL_0fbf:
																							if (9 < b)
																							{
																								goto IL_0fcd;
																							}
																							goto IL_131a;
																							IL_0fcd:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0fdb;
																							IL_0fdb:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0fe9;
																							IL_0fe9:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_104b;
																							IL_104b:
																							num6 -= 2;
																							goto IL_1aab;
																							IL_131a:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_1328;
																							IL_1328:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1368;
																							IL_1368:
																							array2[num6 - 2] = 0;
																							goto IL_137c;
																							IL_137c:
																							num6--;
																							goto IL_1aab;
																							IL_175d:
																							array2[num6 - 1] = 0;
																							goto IL_1771;
																							IL_1771:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_17b0;
																							IL_17b0:
																							ptr2 += 8;
																							goto IL_1aab;
																							IL_0726:
																							if (16 < b)
																							{
																								goto IL_0783;
																							}
																							goto IL_138f;
																							IL_0783:
																							if (19 < b)
																							{
																								goto IL_0791;
																							}
																							goto IL_095f;
																							IL_0791:
																							if (20 < b)
																							{
																								goto IL_079f;
																							}
																							goto IL_0890;
																							IL_079f:
																							if (21 < b)
																							{
																								break;
																							}
																							goto IL_0bbc;
																							IL_0bbc:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_17c3;
																							IL_17c3:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1803;
																							IL_1803:
																							array2[num6 - 2] = 3;
																							goto IL_1817;
																							IL_1817:
																							num6--;
																							goto IL_1aab;
																							IL_0890:
																							if (20 > b)
																							{
																								break;
																							}
																							goto IL_089e;
																							IL_089e:
																							array2[num6 - 1] = 3;
																							num = 217;
																							goto IL_08bb;
																							IL_08bb:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_08fa;
																							IL_08fa:
																							ptr2 += 8;
																							goto IL_1aab;
																							IL_095f:
																							if (19 <= b)
																							{
																								goto IL_096a;
																							}
																							goto IL_09b2;
																							IL_096a:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							goto IL_0983;
																							IL_0983:
																							array2[num6] = 3;
																							goto IL_0991;
																							IL_0991:
																							num6++;
																							goto IL_099f;
																							IL_099f:
																							ptr2 += 16;
																							goto IL_1aab;
																							IL_09b2:
																							if (17 < b)
																							{
																								goto IL_09c0;
																							}
																							goto IL_0ea5;
																							IL_09c0:
																							if (18 < b)
																							{
																								break;
																							}
																							goto IL_09ce;
																							IL_09ce:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0bcf;
																							IL_0bcf:
																							global::_003CModule_003E.string_45 = (string)array3[num6 - 1];
																							goto IL_0be8;
																							IL_0be8:
																							num6--;
																							goto IL_1aab;
																							IL_0ea5:
																							if (17 > b)
																							{
																								break;
																							}
																							goto IL_0eb3;
																							IL_0eb3:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_0ec2;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_0f6a;
																							IL_087a:
																							array2[num6 - 1] = 0;
																							goto IL_090d;
																							IL_090d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_094c;
																							IL_094c:
																							ptr2 += 8;
																							goto IL_1aab;
																							IL_0f6a:
																							array2[num6] = 5;
																							goto IL_0f78;
																							IL_0f78:
																							num6++;
																							goto IL_1aab;
																							IL_138f:
																							if (16 <= b)
																							{
																								goto IL_139a;
																							}
																							goto IL_13ff;
																							IL_139a:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_13ec;
																							IL_13ec:
																							num6--;
																							goto IL_1aab;
																							IL_13ff:
																							if (13 >= b)
																							{
																								goto IL_140a;
																							}
																							goto IL_1439;
																							IL_140a:
																							if (13 > b)
																							{
																								goto IL_1418;
																							}
																							goto IL_1715;
																							IL_1418:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_1426;
																							IL_1426:
																							if (12 > b)
																							{
																								break;
																							}
																							goto IL_1aab;
																							IL_1715:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_172e;
																							IL_172e:
																							array2[num6] = 1;
																							goto IL_173c;
																							IL_173c:
																							num6++;
																							goto IL_174a;
																							IL_174a:
																							ptr2 += 16;
																							goto IL_1aab;
																							IL_1439:
																							if (14 >= b)
																							{
																								goto IL_1444;
																							}
																							goto IL_14af;
																							IL_1444:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_1625;
																							IL_1625:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_1aab;
																							IL_14af:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_14bd;
																							IL_14bd:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_14cb;
																						}
																						break;
																						IL_068e:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 140;
																				goto IL_1aab;
																				continue;
																				end_IL_069e:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																goto IL_1b7c;
																IL_1b7c:
																return (string)array3[num6 - 1];
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0ec2:
			while (true)
			{
				IL_0ec2_2:
				array = new byte[2];
				while (true)
				{
					IL_0ed0:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_0f78_2:
							num6++;
							while (true)
							{
								IL_1aab_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_069e_2:
												if (b >= 1)
												{
													while (b <= 44)
													{
														while (true)
														{
															IL_0681_2:
															if (22 < b)
															{
																while (true)
																{
																	IL_0671_2:
																	if (33 >= b)
																	{
																		num = 185;
																		while (true)
																		{
																			IL_0661_2:
																			if (33 > b)
																			{
																				while (true)
																				{
																					IL_0651_2:
																					if (27 < b)
																					{
																						while (true)
																						{
																							IL_0641_2:
																							if (30 >= b)
																							{
																								while (true)
																								{
																									IL_0631_2:
																									if (30 > b)
																									{
																										while (true)
																										{
																											IL_0621_2:
																											if (28 >= b)
																											{
																												while (28 <= b)
																												{
																													num = 372;
																													while (true)
																													{
																														if (num != 372)
																														{
																															if (num != 1353)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 28:
																																goto IL_060e_2;
																															case 136:
																																goto IL_0621_2;
																															case 270:
																																goto IL_0631_2;
																															case 226:
																																goto IL_0641_2;
																															case 86:
																																goto IL_0651_2;
																															case 185:
																																goto IL_0661_2;
																															case 162:
																																goto IL_0671_2;
																															case 304:
																																goto IL_0681_2;
																															case 31:
																																goto IL_068e_2;
																															case 353:
																																goto IL_069e_2;
																															case 274:
																																goto end_IL_069e_2;
																															case 59:
																															case 187:
																																goto end_IL_06ae;
																															case 63:
																																goto IL_06c9_2;
																															case 97:
																																goto IL_06d9_2;
																															case 123:
																																goto IL_06ec_2;
																															case 37:
																																goto IL_06fa_2;
																															case 81:
																																goto IL_0705_2;
																															case 43:
																																goto IL_0713_2;
																															case 50:
																																goto IL_0726_2;
																															case 154:
																																goto IL_0736_2;
																															case 60:
																																goto IL_0744_2;
																															case 80:
																																goto IL_074f_2;
																															case 11:
																																goto IL_0762_2;
																															case 101:
																																goto IL_0770_2;
																															case 158:
																																goto IL_0783_2;
																															case 176:
																																goto IL_0791_2;
																															case 166:
																																goto IL_079f_2;
																															case 227:
																																goto IL_07b2_2;
																															case 137:
																															case 153:
																																goto IL_07bd_2;
																															case 164:
																																goto IL_07d6_2;
																															case 119:
																																goto IL_07e4_2;
																															case 89:
																																goto IL_07ef_2;
																															case 204:
																																goto IL_0802_2;
																															case 38:
																																goto IL_0810_2;
																															case 228:
																																goto IL_0823_2;
																															case 20:
																															case 213:
																																goto IL_0831_2;
																															case 23:
																																goto IL_084b_2;
																															case 231:
																																goto IL_085e_2;
																															case 247:
																															case 258:
																																goto IL_087a_2;
																															case 259:
																																goto IL_0890_2;
																															case 24:
																															case 124:
																																goto IL_089e_2;
																															case 217:
																																goto IL_08bb_2;
																															case 175:
																																goto IL_08fa_2;
																															case 260:
																																goto IL_090d_2;
																															case 61:
																																goto IL_094c_2;
																															case 267:
																																goto IL_095f_2;
																															case 179:
																															case 196:
																																goto IL_096a_2;
																															case 249:
																																goto IL_0983_2;
																															case 172:
																																goto IL_0991_2;
																															case 160:
																																goto IL_099f_2;
																															case 205:
																																goto IL_09b2_2;
																															case 233:
																																goto IL_09c0_2;
																															case 149:
																																goto IL_09ce_2;
																															case 271:
																																goto IL_09e1_2;
																															case 222:
																																goto IL_0a4b_2;
																															case 282:
																																goto IL_0a5e_2;
																															case 44:
																																goto IL_0a6c_2;
																															case 244:
																																goto IL_0a77_2;
																															case 13:
																																goto IL_0a85_2;
																															case 278:
																																goto IL_0a93_2;
																															case 253:
																																goto IL_0aaf_2;
																															case 91:
																															case 248:
																																goto IL_0aba_2;
																															case 25:
																																goto IL_0aff_2;
																															case 99:
																																goto IL_0b0d_2;
																															case 17:
																															case 82:
																																goto IL_0b1b_2;
																															case 157:
																																goto IL_0b34_2;
																															case 120:
																																goto IL_0b42_2;
																															case 229:
																															case 285:
																																goto IL_0b55_2;
																															case 156:
																																goto IL_0b95_2;
																															case 181:
																																goto IL_0ba9_2;
																															case 289:
																																goto IL_0bbc_2;
																															case 257:
																															case 295:
																																goto IL_0bcf_2;
																															case 173:
																																goto IL_0be8_2;
																															case 298:
																																goto IL_0bfb_2;
																															case 58:
																															case 246:
																																goto IL_0c06_2;
																															case 188:
																																goto IL_0c29_2;
																															case 193:
																																goto IL_0c37_2;
																															case 8:
																																goto IL_0c45_2;
																															case 32:
																																goto IL_0c58_2;
																															case 21:
																																goto IL_0c66_2;
																															case 45:
																																goto IL_0c74_2;
																															case 52:
																															case 292:
																																goto IL_0c82_2;
																															case 252:
																																goto IL_0ca6_2;
																															case 170:
																																goto IL_0cb4_2;
																															case 100:
																															case 299:
																																goto IL_0cc7_2;
																															case 55:
																																goto IL_0ce5_2;
																															case 221:
																															case 300:
																																goto IL_0cf8_2;
																															case 301:
																																goto IL_0d11_2;
																															case 110:
																																goto IL_0d25_2;
																															case 310:
																																goto IL_0d38_2;
																															case 311:
																																goto IL_0d60_2;
																															case 312:
																																goto IL_0d7c_2;
																															case 3:
																															case 178:
																																goto IL_0d8a_2;
																															case 171:
																																goto IL_0da4_2;
																															case 313:
																																goto IL_0dc0_2;
																															case 200:
																															case 297:
																																goto IL_0dcb_2;
																															case 48:
																																goto IL_0dde_2;
																															case 243:
																																goto IL_0dec_2;
																															case 169:
																															case 316:
																																goto IL_0dfc_2;
																															case 79:
																																goto IL_0e0a_2;
																															case 73:
																																goto IL_0e1d_2;
																															case 242:
																																goto IL_0e2b_2;
																															case 232:
																															case 323:
																																goto IL_0e3e_2;
																															case 168:
																																goto IL_0e7e_2;
																															case 151:
																																goto IL_0e92_2;
																															case 325:
																																goto IL_0ea5_2;
																															case 36:
																															case 125:
																																goto IL_0eb3_2;
																															case 235:
																																goto end_IL_06be;
																															case 276:
																																goto IL_0f78_2;
																															case 326:
																																goto IL_0f8b_2;
																															case 147:
																																goto IL_0f95_2;
																															case 314:
																																goto IL_0fac_2;
																															case 329:
																																goto IL_0fbf_2;
																															case 163:
																																goto IL_0fcd_2;
																															case 127:
																																goto IL_0fdb_2;
																															case 67:
																															case 320:
																																goto IL_0fe9_2;
																															case 95:
																																goto IL_104b_2;
																															case 336:
																																goto IL_105e_2;
																															case 15:
																																goto IL_106c_2;
																															case 75:
																															case 318:
																																goto IL_107a_2;
																															case 34:
																																goto IL_10ba_2;
																															case 121:
																																goto IL_10ce_2;
																															case 338:
																																goto IL_10e1_2;
																															case 287:
																																goto IL_10ef_2;
																															case 142:
																																goto IL_10fd_2;
																															case 203:
																															case 309:
																																goto IL_1108_2;
																															case 328:
																																goto IL_111c_2;
																															case 273:
																																goto IL_115b_2;
																															case 306:
																																goto IL_116e_2;
																															case 250:
																																goto IL_117c_2;
																															case 236:
																															case 245:
																																goto IL_118a_2;
																															case 129:
																																goto IL_11ae_2;
																															case 234:
																																goto IL_11bc_2;
																															case 288:
																																goto IL_11ca_2;
																															case 220:
																																goto IL_11dd_2;
																															case 155:
																																goto IL_11e8_2;
																															case 269:
																																goto IL_11fb_2;
																															case 262:
																																goto IL_1209_2;
																															case 54:
																															case 272:
																																goto IL_1217_2;
																															case 40:
																																goto IL_1260_2;
																															case 0:
																																goto IL_1274_2;
																															case 9:
																															case 130:
																																goto IL_1290_2;
																															case 190:
																																goto IL_12c4_2;
																															case 341:
																																goto IL_12dd_2;
																															case 65:
																																goto IL_12eb_2;
																															case 296:
																															case 342:
																																goto IL_12fe_2;
																															case 344:
																																goto IL_131a_2;
																															case 71:
																															case 115:
																																goto IL_1328_2;
																															case 191:
																																goto IL_1368_2;
																															case 224:
																																goto IL_137c_2;
																															case 347:
																																goto IL_138f_2;
																															case 66:
																															case 230:
																																goto IL_139a_2;
																															case 139:
																																goto IL_13ec_2;
																															case 116:
																																goto IL_13ff_2;
																															case 6:
																																goto IL_140a_2;
																															case 161:
																																goto IL_1418_2;
																															case 114:
																																goto IL_1426_2;
																															case 57:
																																goto IL_1439_2;
																															case 118:
																																goto IL_1444_2;
																															case 348:
																																goto IL_1457_2;
																															case 64:
																															case 74:
																																goto IL_1465_2;
																															case 98:
																																goto IL_148e_2;
																															case 117:
																																goto IL_149c_2;
																															case 349:
																																goto IL_14af_2;
																															case 18:
																																goto IL_14bd_2;
																															case 16:
																															case 159:
																																goto IL_14cb_2;
																															case 103:
																																goto IL_150c_2;
																															case 144:
																																goto IL_1520_2;
																															case 351:
																																goto IL_1533_2;
																															case 111:
																																goto IL_153e_2;
																															case 2:
																															case 184:
																																goto IL_154c_2;
																															case 223:
																																goto IL_158c_2;
																															case 211:
																																goto IL_15a0_2;
																															case 197:
																																goto IL_15bc_2;
																															case 317:
																																goto IL_15d3_2;
																															case 19:
																															case 70:
																																goto IL_15e1_2;
																															case 96:
																																goto IL_160c_2;
																															case 113:
																															case 352:
																																goto IL_1625_2;
																															case 354:
																																goto IL_163d_2;
																															case 112:
																															case 356:
																																goto IL_1650_2;
																															case 152:
																																goto IL_166a_2;
																															case 357:
																																goto IL_167d_2;
																															case 46:
																															case 76:
																																goto IL_1694_2;
																															case 126:
																																goto IL_16a8_2;
																															case 1:
																																goto IL_16f4_2;
																															case 183:
																																goto IL_1702_2;
																															case 254:
																															case 363:
																																goto IL_1715_2;
																															case 208:
																																goto IL_172e_2;
																															case 264:
																																goto IL_173c_2;
																															case 47:
																																goto IL_174a_2;
																															case 199:
																															case 364:
																																goto IL_175d_2;
																															case 68:
																																goto IL_1771_2;
																															case 174:
																																goto IL_17b0_2;
																															case 22:
																															case 365:
																																goto IL_17c3_2;
																															case 308:
																																goto IL_1803_2;
																															case 279:
																																goto IL_1817_2;
																															case 165:
																																goto IL_182a_2;
																															case 90:
																																goto IL_183e_2;
																															case 294:
																																goto IL_1892_2;
																															case 360:
																																goto IL_18a0_2;
																															case 327:
																															case 362:
																																goto IL_18b3_2;
																															case 182:
																																goto IL_18c7_2;
																															case 216:
																																goto IL_1906_2;
																															case 334:
																																goto end_IL_05fb_2;
																															case 107:
																																goto IL_1924_2;
																															case 53:
																															case 138:
																																goto IL_1932_2;
																															case 26:
																																goto IL_1946_2;
																															case 210:
																																goto IL_1985_2;
																															case 240:
																																goto IL_1998_2;
																															case 102:
																																goto IL_19a6_2;
																															case 42:
																															case 268:
																																goto IL_19bd_2;
																															case 281:
																																goto IL_19d1_2;
																															case 14:
																																goto IL_1a10_2;
																															case 128:
																															case 277:
																																goto IL_1a2c_2;
																															case 78:
																																goto IL_1a40_2;
																															case 361:
																																goto IL_1a7f_2;
																															case 5:
																															case 10:
																															case 30:
																															case 62:
																															case 69:
																															case 72:
																															case 77:
																															case 84:
																															case 85:
																															case 88:
																															case 93:
																															case 104:
																															case 106:
																															case 109:
																															case 122:
																															case 131:
																															case 132:
																															case 133:
																															case 141:
																															case 148:
																															case 189:
																															case 192:
																															case 194:
																															case 195:
																															case 198:
																															case 212:
																															case 214:
																															case 215:
																															case 225:
																															case 239:
																															case 255:
																															case 256:
																															case 266:
																															case 286:
																															case 290:
																															case 293:
																															case 302:
																															case 305:
																															case 321:
																															case 330:
																															case 332:
																															case 333:
																															case 335:
																															case 340:
																															case 343:
																															case 346:
																															case 359:
																																goto end_IL_060e_2;
																															case 4:
																															case 7:
																															case 12:
																															case 27:
																															case 29:
																															case 33:
																															case 39:
																															case 41:
																															case 49:
																															case 56:
																															case 83:
																															case 87:
																															case 94:
																															case 134:
																															case 135:
																															case 140:
																															case 143:
																															case 150:
																															case 167:
																															case 177:
																															case 180:
																															case 186:
																															case 201:
																															case 202:
																															case 209:
																															case 218:
																															case 219:
																															case 237:
																															case 238:
																															case 251:
																															case 261:
																															case 263:
																															case 265:
																															case 275:
																															case 280:
																															case 283:
																															case 284:
																															case 291:
																															case 307:
																															case 315:
																															case 322:
																															case 324:
																															case 331:
																															case 339:
																															case 345:
																															case 350:
																															case 358:
																																goto IL_1aab_2;
																															case 319:
																																ptr2 = ptr;
																																goto IL_1aab_2;
																															case 51:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PurgeAccessControlITupleInternal.SegmentStateTimeSpan);
																																num = 319;
																																goto case 319;
																															case 92:
																																array5[0] = int_2;
																																goto case 51;
																															case 355:
																																array6 = new long[4];
																																goto case 92;
																															case 105:
																																array5 = new int[8];
																																goto case 355;
																															case 206:
																																array4 = new int[4];
																																goto case 105;
																															case 207:
																																array3 = new object[4];
																																goto case 206;
																															case 241:
																																array2 = new byte[4];
																																goto case 207;
																															case 35:
																																num4 = num2 * 8;
																																goto case 241;
																															case 337:
																																num3 = num2 * 4;
																																goto case 35;
																															case 145:
																																num2 = 1;
																																goto case 337;
																															case 146:
																																goto end_IL_0f6a;
																															case 108:
																															case 303:
																																goto IL_1b7c_2;
																															}
																															continue;
																														}
																														goto IL_182a_2;
																														IL_1892_2:
																														num6--;
																														goto IL_18a0_2;
																														IL_18a0_2:
																														ptr2 += 8;
																														goto IL_1aab_2;
																														IL_182a_2:
																														array2[num6 - 2] = 0;
																														goto IL_183e_2;
																														IL_183e_2:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_1892_2;
																														continue;
																														end_IL_05fb_2:
																														break;
																													}
																													goto IL_1919_2;
																													continue;
																													end_IL_060e_2:
																													break;
																													IL_060e_2:;
																												}
																												break;
																											}
																											goto IL_06d9_2;
																											IL_084b_2:
																											num6--;
																											goto IL_1aab_2;
																											IL_06d9_2:
																											if (29 < b)
																											{
																												break;
																											}
																											goto IL_0823_2;
																											IL_0823_2:
																											if (29 > b)
																											{
																												break;
																											}
																											goto IL_0831_2;
																											IL_0831_2:
																											global::_003CModule_003E.int_204 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_084b_2;
																										}
																										break;
																									}
																									goto IL_18b3_2;
																									IL_1906_2:
																									ptr2 += 8;
																									goto IL_1aab_2;
																									IL_18b3_2:
																									array2[num6 - 1] = 3;
																									goto IL_18c7_2;
																									IL_18c7_2:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1906_2;
																								}
																								break;
																							}
																							goto IL_1919_2;
																							IL_19d1_2:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1a10_2;
																							IL_1919_2:
																							if (31 >= b)
																							{
																								goto IL_1924_2;
																							}
																							goto IL_1998_2;
																							IL_1924_2:
																							if (31 > b)
																							{
																								break;
																							}
																							goto IL_1932_2;
																							IL_1932_2:
																							array2[num6 - 1] = 3;
																							goto IL_1946_2;
																							IL_1946_2:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1985_2;
																							IL_1985_2:
																							ptr2 += 8;
																							goto IL_1aab_2;
																							IL_1998_2:
																							if (32 < b)
																							{
																								break;
																							}
																							goto IL_19a6_2;
																							IL_19a6_2:
																							if (32 > b)
																							{
																								break;
																							}
																							num = 42;
																							goto IL_19bd_2;
																							IL_1a10_2:
																							ptr2 += 8;
																							goto IL_1aab_2;
																							IL_19bd_2:
																							array2[num6 - 1] = 3;
																							goto IL_19d1_2;
																						}
																						break;
																					}
																					goto IL_10e1_2;
																					IL_1290_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					num = 190;
																					goto IL_12c4_2;
																					IL_10e1_2:
																					if (27 > b)
																					{
																						goto IL_10ef_2;
																					}
																					num = 9;
																					goto IL_1290_2;
																					IL_10ef_2:
																					if (24 >= b)
																					{
																						goto IL_10fd_2;
																					}
																					goto IL_11dd_2;
																					IL_10fd_2:
																					if (24 <= b)
																					{
																						goto IL_1108_2;
																					}
																					goto IL_116e_2;
																					IL_1108_2:
																					array2[num6 - 1] = 3;
																					goto IL_111c_2;
																					IL_111c_2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																					goto IL_115b_2;
																					IL_115b_2:
																					ptr2 += 8;
																					goto IL_1aab_2;
																					IL_116e_2:
																					if (23 < b)
																					{
																						break;
																					}
																					goto IL_117c_2;
																					IL_117c_2:
																					if (23 > b)
																					{
																						break;
																					}
																					goto IL_118a_2;
																					IL_118a_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])();
																					goto IL_11ae_2;
																					IL_11ae_2:
																					array2[num6] = 0;
																					goto IL_11bc_2;
																					IL_11bc_2:
																					num6++;
																					goto IL_11ca_2;
																					IL_11ca_2:
																					ptr2 += 8;
																					goto IL_1aab_2;
																					IL_11dd_2:
																					if (25 >= b)
																					{
																						goto IL_11e8_2;
																					}
																					goto IL_11fb_2;
																					IL_11e8_2:
																					if (25 > b)
																					{
																						break;
																					}
																					goto IL_1650_2;
																					IL_1650_2:
																					global::_003CModule_003E.int_205 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_166a_2;
																					IL_166a_2:
																					num6--;
																					goto IL_1aab_2;
																					IL_11fb_2:
																					if (26 < b)
																					{
																						break;
																					}
																					goto IL_1209_2;
																					IL_1209_2:
																					if (26 > b)
																					{
																						break;
																					}
																					goto IL_1217_2;
																					IL_1217_2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					num = 40;
																					goto IL_1260_2;
																					IL_1260_2:
																					array2[num6 - 2] = 3;
																					goto IL_1274_2;
																					IL_1274_2:
																					num6--;
																					goto IL_1aab_2;
																					IL_12c4_2:
																					array2[num6 - 1] = 0;
																					goto IL_1aab_2;
																				}
																				break;
																			}
																			num = 277;
																			goto IL_1a2c_2;
																			IL_1a40_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_1a7f_2;
																			IL_1a7f_2:
																			ptr2 += 8;
																			goto IL_1aab_2;
																			IL_1a2c_2:
																			array2[num6 - 1] = 0;
																			goto IL_1a40_2;
																		}
																		break;
																	}
																	goto IL_06c9_2;
																	IL_1694_2:
																	array2[num6 - 2] = 5;
																	goto IL_16a8_2;
																	IL_16a8_2:
																	array3[num6 - 2] = ((delegate*<string, string, string>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																	goto IL_16f4_2;
																	IL_06c9_2:
																	if (39 < b)
																	{
																		goto IL_0736_2;
																	}
																	goto IL_07b2_2;
																	IL_07b2_2:
																	if (39 <= b)
																	{
																		goto IL_07bd_2;
																	}
																	goto IL_07d6_2;
																	IL_07bd_2:
																	array2[num6 - 1] = 5;
																	goto IL_09e1_2;
																	IL_09e1_2:
																	array3[num6 - 1] = ((delegate*<ref char, string>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref char>)UpnNameCompareInfo[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																	goto IL_0a4b_2;
																	IL_0a4b_2:
																	ptr2 += 8;
																	goto IL_1aab_2;
																	IL_07d6_2:
																	if (36 < b)
																	{
																		goto IL_07e4_2;
																	}
																	goto IL_0d7c_2;
																	IL_07e4_2:
																	if (37 >= b)
																	{
																		goto IL_07ef_2;
																	}
																	goto IL_0802_2;
																	IL_07ef_2:
																	if (37 > b)
																	{
																		break;
																	}
																	goto IL_0cc7_2;
																	IL_0cc7_2:
																	array3[num6] = ((delegate*<string>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])();
																	goto IL_0ce5_2;
																	IL_0ce5_2:
																	array2[num6] = 5;
																	goto IL_12dd_2;
																	IL_12dd_2:
																	num6++;
																	goto IL_12eb_2;
																	IL_12eb_2:
																	ptr2 += 8;
																	goto IL_1aab_2;
																	IL_0802_2:
																	if (38 < b)
																	{
																		break;
																	}
																	goto IL_0810_2;
																	IL_0810_2:
																	if (38 > b)
																	{
																		break;
																	}
																	goto IL_0dfc_2;
																	IL_0dfc_2:
																	array2[num6] = 15;
																	goto IL_0e0a_2;
																	IL_0e0a_2:
																	array4[num6] = *(int*)(ptr2 + num3);
																	goto IL_0e1d_2;
																	IL_0e1d_2:
																	ptr2 += 8;
																	goto IL_0e2b_2;
																	IL_0e2b_2:
																	num6++;
																	goto IL_1aab_2;
																	IL_0d7c_2:
																	if (36 <= b)
																	{
																		goto IL_0d8a_2;
																	}
																	goto IL_1533_2;
																	IL_0d8a_2:
																	global::_003CModule_003E.char_4 = (char)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_0da4_2;
																	IL_0da4_2:
																	num6--;
																	num = 315;
																	goto IL_1aab_2;
																	IL_1533_2:
																	if (34 >= b)
																	{
																		goto IL_153e_2;
																	}
																	goto IL_15bc_2;
																	IL_153e_2:
																	if (34 > b)
																	{
																		break;
																	}
																	goto IL_154c_2;
																	IL_154c_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_158c_2;
																	IL_158c_2:
																	array2[num6 - 2] = 0;
																	goto IL_15a0_2;
																	IL_15a0_2:
																	num6--;
																	num = 201;
																	goto IL_1aab_2;
																	IL_15bc_2:
																	if (35 < b)
																	{
																		break;
																	}
																	num = 317;
																	goto IL_15d3_2;
																	IL_16f4_2:
																	num6--;
																	goto IL_1702_2;
																	IL_15d3_2:
																	if (35 > b)
																	{
																		break;
																	}
																	goto IL_15e1_2;
																	IL_15e1_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (ushort)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_160c_2;
																	IL_160c_2:
																	array2[num6 - 1] = 0;
																	goto IL_1aab_2;
																	IL_0736_2:
																	if (42 < b)
																	{
																		goto IL_0744_2;
																	}
																	goto IL_0bfb_2;
																	IL_0744_2:
																	if (43 >= b)
																	{
																		goto IL_074f_2;
																	}
																	goto IL_0762_2;
																	IL_074f_2:
																	if (43 > b)
																	{
																		break;
																	}
																	goto IL_12fe_2;
																	IL_12fe_2:
																	num7 = ptr2;
																	num8 = -200;
																	num5 = 1;
																	ptr2 = num7 + num8;
																	goto IL_1aab_2;
																	IL_0762_2:
																	if (44 < b)
																	{
																		break;
																	}
																	goto IL_0770_2;
																	IL_0770_2:
																	if (44 > b)
																	{
																	}
																	break;
																	IL_0bfb_2:
																	if (42 <= b)
																	{
																		goto IL_0c06_2;
																	}
																	goto IL_0c58_2;
																	IL_0c06_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																	goto IL_0c29_2;
																	IL_0c29_2:
																	array2[num6] = 0;
																	goto IL_0c37_2;
																	IL_0c37_2:
																	num6++;
																	goto IL_0c45_2;
																	IL_0c45_2:
																	ptr2 += 8;
																	goto IL_1aab_2;
																	IL_0c58_2:
																	if (40 < b)
																	{
																		goto IL_0c66_2;
																	}
																	goto IL_167d_2;
																	IL_0c66_2:
																	if (41 < b)
																	{
																		break;
																	}
																	goto IL_0c74_2;
																	IL_0c74_2:
																	if (41 > b)
																	{
																		break;
																	}
																	goto IL_0c82_2;
																	IL_0c82_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])();
																	goto IL_0ca6_2;
																	IL_0ca6_2:
																	array2[num6] = 0;
																	goto IL_0cb4_2;
																	IL_0cb4_2:
																	num6++;
																	goto IL_0d60_2;
																	IL_0d60_2:
																	ptr2 += 8;
																	num = 251;
																	goto IL_1aab_2;
																	IL_167d_2:
																	if (40 > b)
																	{
																		break;
																	}
																	num = 46;
																	goto IL_1694_2;
																	IL_1702_2:
																	ptr2 += 8;
																	goto IL_1aab_2;
																}
																break;
															}
															goto IL_06ec_2;
															IL_087a_2:
															array2[num6 - 1] = 0;
															goto IL_090d_2;
															IL_06ec_2:
															if (22 > b)
															{
																goto IL_06fa_2;
															}
															goto IL_087a_2;
															IL_06fa_2:
															if (11 >= b)
															{
																goto IL_0705_2;
															}
															goto IL_0726_2;
															IL_0705_2:
															if (11 > b)
															{
																goto IL_0713_2;
															}
															goto IL_175d_2;
															IL_0713_2:
															if (5 < b)
															{
																goto IL_085e_2;
															}
															goto IL_0a5e_2;
															IL_0a5e_2:
															if (5 > b)
															{
																goto IL_0a6c_2;
															}
															goto IL_0b55_2;
															IL_0a6c_2:
															if (2 < b)
															{
																goto IL_0a77_2;
															}
															num = 253;
															goto IL_0aaf_2;
															IL_0a77_2:
															if (3 < b)
															{
																goto IL_0a85_2;
															}
															goto IL_1457_2;
															IL_0a85_2:
															if (4 < b)
															{
																break;
															}
															goto IL_0a93_2;
															IL_0a93_2:
															if (4 > b)
															{
																break;
															}
															goto IL_0cf8_2;
															IL_0cf8_2:
															array2[num6] = 0;
															num = 310;
															goto IL_0d38_2;
															IL_0d38_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0f8b_2;
															IL_0f8b_2:
															array3[num6] = null;
															goto IL_0f95_2;
															IL_0f95_2:
															num6++;
															num = 314;
															goto IL_0fac_2;
															IL_0fac_2:
															ptr2 += 8;
															goto IL_1aab_2;
															IL_1457_2:
															if (3 > b)
															{
																break;
															}
															goto IL_1465_2;
															IL_1465_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_148e_2;
															IL_148e_2:
															ptr2 += 8;
															goto IL_149c_2;
															IL_149c_2:
															num6--;
															goto IL_1aab_2;
															IL_090d_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_094c_2;
															IL_0aaf_2:
															if (2 <= b)
															{
																goto IL_0aba_2;
															}
															goto IL_0aff_2;
															IL_0aba_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0d11_2;
															IL_0d11_2:
															array2[num6 - 2] = 0;
															goto IL_0d25_2;
															IL_0d25_2:
															num6--;
															goto IL_1aab_2;
															IL_0aff_2:
															if (1 < b)
															{
																break;
															}
															goto IL_0b0d_2;
															IL_0b0d_2:
															if (1 > b)
															{
																break;
															}
															goto IL_0b1b_2;
															IL_0b1b_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_0b34_2;
															IL_0b34_2:
															array2[num6] = 0;
															goto IL_0b42_2;
															IL_0b42_2:
															num6++;
															goto IL_163d_2;
															IL_163d_2:
															ptr2 += 8;
															goto IL_1aab_2;
															IL_0b55_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0b95_2;
															IL_0b95_2:
															array2[num6 - 2] = 0;
															goto IL_0ba9_2;
															IL_0ba9_2:
															num6--;
															goto IL_1aab_2;
															IL_085e_2:
															if (8 >= b)
															{
																num = 313;
																goto IL_0dc0_2;
															}
															goto IL_0fbf_2;
															IL_094c_2:
															ptr2 += 8;
															goto IL_1aab_2;
															IL_0dc0_2:
															if (8 <= b)
															{
																goto IL_0dcb_2;
															}
															goto IL_0dde_2;
															IL_0dcb_2:
															num6--;
															goto IL_1aab_2;
															IL_0dde_2:
															if (6 >= b)
															{
																goto IL_0dec_2;
															}
															goto IL_105e_2;
															IL_0dec_2:
															if (6 > b)
															{
																break;
															}
															goto IL_0e3e_2;
															IL_0e3e_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0e7e_2;
															IL_0e7e_2:
															array2[num6 - 2] = 0;
															goto IL_0e92_2;
															IL_0e92_2:
															num6--;
															goto IL_1aab_2;
															IL_105e_2:
															if (7 < b)
															{
																break;
															}
															goto IL_106c_2;
															IL_106c_2:
															if (7 > b)
															{
																break;
															}
															goto IL_107a_2;
															IL_107a_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_10ba_2;
															IL_10ba_2:
															array2[num6 - 2] = 0;
															goto IL_10ce_2;
															IL_10ce_2:
															num6--;
															goto IL_1aab_2;
															IL_0fbf_2:
															if (9 < b)
															{
																goto IL_0fcd_2;
															}
															goto IL_131a_2;
															IL_0fcd_2:
															if (10 < b)
															{
																break;
															}
															goto IL_0fdb_2;
															IL_0fdb_2:
															if (10 > b)
															{
																break;
															}
															goto IL_0fe9_2;
															IL_0fe9_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_104b_2;
															IL_104b_2:
															num6 -= 2;
															goto IL_1aab_2;
															IL_131a_2:
															if (9 > b)
															{
																break;
															}
															goto IL_1328_2;
															IL_1328_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1368_2;
															IL_1368_2:
															array2[num6 - 2] = 0;
															goto IL_137c_2;
															IL_137c_2:
															num6--;
															goto IL_1aab_2;
															IL_175d_2:
															array2[num6 - 1] = 0;
															goto IL_1771_2;
															IL_1771_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_17b0_2;
															IL_17b0_2:
															ptr2 += 8;
															goto IL_1aab_2;
															IL_0726_2:
															if (16 < b)
															{
																goto IL_0783_2;
															}
															goto IL_138f_2;
															IL_0783_2:
															if (19 < b)
															{
																goto IL_0791_2;
															}
															goto IL_095f_2;
															IL_0791_2:
															if (20 < b)
															{
																goto IL_079f_2;
															}
															goto IL_0890_2;
															IL_079f_2:
															if (21 < b)
															{
																break;
															}
															goto IL_0bbc_2;
															IL_0bbc_2:
															if (21 > b)
															{
																break;
															}
															goto IL_17c3_2;
															IL_17c3_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1803_2;
															IL_1803_2:
															array2[num6 - 2] = 3;
															goto IL_1817_2;
															IL_1817_2:
															num6--;
															goto IL_1aab_2;
															IL_0890_2:
															if (20 > b)
															{
																break;
															}
															goto IL_089e_2;
															IL_089e_2:
															array2[num6 - 1] = 3;
															num = 217;
															goto IL_08bb_2;
															IL_08bb_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UpnNameCompareInfo[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_08fa_2;
															IL_08fa_2:
															ptr2 += 8;
															goto IL_1aab_2;
															IL_095f_2:
															if (19 <= b)
															{
																goto IL_096a_2;
															}
															goto IL_09b2_2;
															IL_096a_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
															goto IL_0983_2;
															IL_0983_2:
															array2[num6] = 3;
															goto IL_0991_2;
															IL_0991_2:
															num6++;
															goto IL_099f_2;
															IL_099f_2:
															ptr2 += 16;
															goto IL_1aab_2;
															IL_09b2_2:
															if (17 < b)
															{
																goto IL_09c0_2;
															}
															goto IL_0ea5_2;
															IL_09c0_2:
															if (18 < b)
															{
																break;
															}
															goto IL_09ce_2;
															IL_09ce_2:
															if (18 > b)
															{
																break;
															}
															goto IL_0bcf_2;
															IL_0bcf_2:
															global::_003CModule_003E.string_45 = (string)array3[num6 - 1];
															goto IL_0be8_2;
															IL_0be8_2:
															num6--;
															goto IL_1aab_2;
															IL_0ea5_2:
															if (17 > b)
															{
																break;
															}
															goto IL_0eb3_2;
															IL_0eb3_2:
															array8 = array3;
															num9 = num6;
															if (array == null)
															{
																goto IL_0ec2_2;
															}
															goto IL_0ed0;
															IL_138f_2:
															if (16 <= b)
															{
																goto IL_139a_2;
															}
															goto IL_13ff_2;
															IL_139a_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_13ec_2;
															IL_13ec_2:
															num6--;
															goto IL_1aab_2;
															IL_13ff_2:
															if (13 >= b)
															{
																goto IL_140a_2;
															}
															goto IL_1439_2;
															IL_140a_2:
															if (13 > b)
															{
																goto IL_1418_2;
															}
															goto IL_1715_2;
															IL_1418_2:
															if (12 < b)
															{
																break;
															}
															goto IL_1426_2;
															IL_1426_2:
															if (12 > b)
															{
																break;
															}
															goto IL_1aab_2;
															IL_1715_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
															goto IL_172e_2;
															IL_172e_2:
															array2[num6] = 1;
															goto IL_173c_2;
															IL_173c_2:
															num6++;
															goto IL_174a_2;
															IL_174a_2:
															ptr2 += 16;
															goto IL_1aab_2;
															IL_1439_2:
															if (14 >= b)
															{
																goto IL_1444_2;
															}
															goto IL_14af_2;
															IL_1444_2:
															if (14 > b)
															{
																break;
															}
															goto IL_1625_2;
															IL_1625_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_1aab_2;
															IL_14af_2:
															if (15 < b)
															{
																break;
															}
															goto IL_14bd_2;
															IL_14bd_2:
															if (15 > b)
															{
																break;
															}
															goto IL_14cb_2;
															IL_14cb_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
															goto IL_150c_2;
															IL_150c_2:
															array2[num6 - 2] = 0;
															goto IL_1520_2;
															IL_1520_2:
															num6--;
															goto IL_1aab_2;
														}
														break;
														IL_068e_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 140;
												goto IL_1aab_2;
												continue;
												end_IL_069e_2:
												break;
											}
											continue;
											end_IL_06ae:
											break;
										}
										continue;
										end_IL_06be:
										break;
									}
									break;
								}
								goto IL_1b7c_2;
								IL_1b7c_2:
								return (string)array3[num6 - 1];
							}
							break;
						}
						continue;
						end_IL_0f6a:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private static string SiteIdentityPermissionIChannelSinkBase(int int_2)
	{
		return smethod_3(int_2);
	}

	private static void setUserQuotaAccountDomainAdminsSid(string string_0, string string_1)
	{
		PlayerPrefs.SetString(string_0, string_1);
	}

	private static int AddBinaryputSubscriptionId(int int_2)
	{
		return smethod_7(int_2);
	}

	private static _003C_003Ec setSafeWaitHandleSByte()
	{
		return _003C_003Ec._003C_003Ec_0;
	}

	private static void getDeclaredMembersConsole(GorillaComputer gorillaComputer_0, string string_0)
	{
		gorillaComputer_0.SetLocalNameTagText(string_0);
	}

	private unsafe void Update()
	{
		RuntimeTypeHandle[] array = new RuntimeTypeHandle[4];
		Type[] array2 = new Type[4];
		array[0] = typeof(object).TypeHandle;
		array[1] = typeof(object).TypeHandle;
		array[2] = typeof(object).TypeHandle;
		array[3] = typeof(object).TypeHandle;
		byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LocalSigGetRegistrableTypesInAssembly.InitialCountIDLFLAGFLCID);
		int num = 4;
		int num2 = 0;
		int num3 = 0;
		num3 = 0;
		int try0057_dispatch = -1;
		object[] array3 = default(object[]);
		Exception ex = default(Exception);
		int num22 = default(int);
		Exception ex2 = default(Exception);
		int num23 = default(int);
		int num24 = default(int);
		int num25 = default(int);
		int num26 = default(int);
		int num27 = default(int);
		int num28 = default(int);
		int num29 = default(int);
		int num30 = default(int);
		object obj3 = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		string text22 = default(string);
		string text23 = default(string);
		string text24 = default(string);
		string text25 = default(string);
		string text26 = default(string);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0057_dispatch)
				{
				case 2059:
					while (true)
					{
						int num4 = num2;
						int num5 = num4;
						int num6 = 0;
						int num7 = 8;
						int num10;
						int num9;
						int num8;
						while (true)
						{
							num8 = (num6 + num7) / 2;
							num9 = *(int*)(ptr + 576 + num8 * 56 + 32 + num);
							num10 = *(int*)(ptr + 576 + num8 * 56 + num);
							if (num5 >= num9 + num10)
							{
								num6 = num8 + 1;
								continue;
							}
							if (num9 <= num5)
							{
								break;
							}
							num7 = num8 - 1;
						}
						int num11 = num8;
						int num12 = *(int*)(ptr + 576 + num11 * 56 + 24 + num);
						int num13 = num12;
						int num14 = num13;
						int num21;
						int num17;
						while (true)
						{
							if (array3 != null)
							{
								if ((int)array3[5] == 1)
								{
									int num15 = (int)array3[3];
									int num16;
									if (num13 == -1)
									{
										num16 = -1;
									}
									else
									{
										num17 = *(int*)(ptr + num13 + 24 + num);
										num10 = 0;
										num9 = 8;
										while (true)
										{
											num8 = (num10 + num9) / 2;
											num7 = *(int*)(ptr + 1080 + num8 * 48 + 32 + num);
											num6 = *(int*)(ptr + 1080 + num8 * 48 + num);
											if (num17 < num7 + num6)
											{
												if (num7 <= num17)
												{
													break;
												}
												num9 = num8 - 1;
											}
											else
											{
												num10 = num8 + 1;
											}
										}
										num12 = num8;
										num11 = *(int*)(ptr + 1080 + num12 * 48 + 16 + num);
										num16 = num11;
									}
									if (num15 != num16)
									{
										array3 = (object[])array3[0];
										continue;
									}
								}
								else
								{
									int num18 = (int)array3[2];
									if (num18 != 1 && num18 != 2 && num18 == 0)
									{
										break;
									}
									int num19 = (int)array3[3];
									int num20;
									if (num13 == -1)
									{
										num20 = -1;
									}
									else
									{
										num5 = *(int*)(ptr + num13 + 24 + num);
										num6 = 0;
										num7 = 8;
										while (true)
										{
											num8 = (num6 + num7) / 2;
											num9 = *(int*)(ptr + 1080 + num8 * 48 + 32 + num);
											num10 = *(int*)(ptr + 1080 + num8 * 48 + num);
											if (num5 >= num9 + num10)
											{
												num6 = num8 + 1;
												continue;
											}
											if (num9 <= num5)
											{
												break;
											}
											num7 = num8 - 1;
										}
										num11 = num8;
										num12 = *(int*)(ptr + 1080 + num11 * 48 + 16 + num);
										num20 = num12;
									}
									if (num19 != num20)
									{
										array3 = (object[])array3[0];
										continue;
									}
								}
							}
							if (-1 == num13)
							{
								goto IL_081e;
							}
							num21 = *(int*)(ptr + num13 + num);
							num5 = num21;
							while (num5 != -1)
							{
								num7 = *(int*)(ptr + num5 + num);
								if (3 != num7)
								{
									goto IL_0764;
								}
								num6 = *(int*)(ptr + num5 + 24 + num);
								if (num6 != -1)
								{
									object obj = array2[num6];
									if (obj == null)
									{
										array2[num6] = Type.GetTypeFromHandle(array[num6]);
										obj = array2[num6];
									}
									if (!((Type)obj).IsInstanceOfType((object)ex))
									{
										num5 = *(int*)(ptr + num5 + 48 + num);
										continue;
									}
								}
								goto IL_08ad;
							}
							num13 = *(int*)(ptr + num13 + 48 + num);
							continue;
							IL_0764:
							if (0 != num7)
							{
								num13 = *(int*)(ptr + num13 + 48 + num);
								continue;
							}
							goto IL_0855;
						}
						object[] array4 = array3;
						num4 = *(int*)(ptr + (int)array4[3] + 48 + num);
						while (num4 != -1)
						{
							num21 = *(int*)(ptr + num4 + num);
							if (3 != num21)
							{
								goto IL_04b2;
							}
							num13 = *(int*)(ptr + num4 + 24 + num);
							if (num13 != -1)
							{
								object obj2 = array2[num13];
								if (obj2 == null)
								{
									array2[num13] = Type.GetTypeFromHandle(array[num13]);
									obj2 = array2[num13];
								}
								if (!((Type)obj2).IsInstanceOfType(array4[1]))
								{
									num4 = *(int*)(ptr + num4 + 48 + num);
									continue;
								}
							}
							goto IL_0a38;
						}
						goto IL_04ba;
						IL_04ba:
						array3 = (object[])array3[0];
						ex = (Exception)array4[1];
						num22 = (int)array4[6];
						continue;
						IL_08ad:
						num17 = num5;
						num10 = *(int*)(ptr + *(int*)(ptr + num17 + 40 + num) + 48 + num);
						num9 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
						while (true)
						{
							if (num9 != num10)
							{
								num8 = *(int*)(ptr + num9 + 32 + num);
								if (num8 == -1)
								{
									num9 = *(int*)(ptr + num9 + 48 + num);
									continue;
								}
								array4 = new object[8];
								array4[5] = 0;
								array4[0] = array3;
								array4[1] = ex;
								array4[6] = num14;
								array4[3] = num8;
								array4[7] = num17;
								array4[2] = 2;
								array3 = array4;
								num2 = *(int*)(ptr + num8 + 16 + num);
								break;
							}
							ex2 = ex;
							array4 = new object[8];
							array4[5] = 0;
							array4[0] = array3;
							array4[1] = ex;
							array4[6] = num14;
							array4[3] = num17;
							array4[2] = 1;
							array3 = array4;
							num2 = *(int*)(ptr + num17 + 16 + num);
							break;
						}
						break;
						IL_0a38:
						num12 = num4;
						num11 = *(int*)(ptr + *(int*)(ptr + num12 + 40 + num) + 48 + num);
						num14 = (int)array4[6];
						while (true)
						{
							object[] array5;
							if (num14 != num11)
							{
								int num18 = *(int*)(ptr + num14 + 32 + num);
								if (num18 == -1)
								{
									num14 = *(int*)(ptr + num14 + 48 + num);
									continue;
								}
								num5 = *(int*)(ptr + num18 + 16 + num);
								array3 = (object[])array3[0];
								array5 = new object[8];
								array5[5] = 0;
								array5[0] = array3;
								array5[1] = array4[1];
								array5[6] = (int)array4[6];
								array5[3] = num18;
								array5[7] = num12;
								array5[2] = 2;
								array3 = array5;
								num2 = *(int*)(ptr + num18 + 16 + num);
								break;
							}
							num5 = *(int*)(ptr + num12 + 16 + num);
							ex2 = (Exception)array4[1];
							array3 = (object[])array3[0];
							array5 = new object[8];
							array5[5] = 0;
							array5[0] = array3;
							array5[1] = array4[1];
							array5[6] = (int)array4[6];
							array5[3] = num12;
							array5[2] = 1;
							array3 = array5;
							num2 = *(int*)(ptr + num12 + 16 + num);
							break;
						}
						break;
						IL_0855:
						ex2 = ex;
						array4 = new object[8];
						array4[5] = 0;
						array4[0] = array3;
						array4[1] = ex;
						array4[6] = num14;
						array4[3] = num5;
						array4[2] = 0;
						array3 = array4;
						num2 = *(int*)(ptr + num5 + 8 + num);
						break;
						IL_081e:
						num12 = num14;
						while (true)
						{
							if (num12 != -1)
							{
								num11 = *(int*)(ptr + num12 + 32 + num);
								if (num11 != -1)
								{
									break;
								}
								num12 = *(int*)(ptr + num12 + 48 + num);
								continue;
							}
							num23 = 1;
							throw ex;
						}
						num17 = *(int*)(ptr + num11 + 16 + num);
						array4 = new object[8];
						array4[5] = 0;
						array4[0] = array3;
						array4[1] = ex;
						array4[6] = num14;
						array4[3] = -1;
						array4[7] = -1;
						array4[2] = 1;
						array3 = array4;
						num2 = *(int*)(ptr + num11 + 16 + num);
						break;
						IL_04b2:
						if (0 == num21)
						{
							num5 = *(int*)(ptr + num4 + 8 + num);
							ex2 = (Exception)array4[1];
							array3 = (object[])array3[0];
							object[] array5 = new object[8];
							array5[5] = 0;
							array5[0] = array3;
							array5[1] = array4[1];
							array5[6] = (int)array4[6];
							array5[3] = num4;
							array5[2] = 0;
							array3 = array5;
							num2 = *(int*)(ptr + num4 + 8 + num);
							break;
						}
						goto IL_04ba;
					}
					break;
				}
				while (true)
				{
					switch (num3)
					{
					case 37:
					{
						num3 = 0;
						int num13 = num24;
						int num31 = num13;
						int num11 = num2;
						int num21 = num11;
						num13 = 0;
						int num4 = 8;
						int num7;
						int num6;
						int num5;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 576 + num5 * 56 + 32 + num);
							num7 = *(int*)(ptr + 576 + num5 * 56 + num);
							if (num21 >= num6 + num7)
							{
								num13 = num5 + 1;
								continue;
							}
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						int num14 = num5;
						int num18 = *(int*)(ptr + 576 + num14 * 56 + 24 + num);
						int num12 = num18;
						num7 = num31;
						num6 = 0;
						num5 = 8;
						while (true)
						{
							num4 = (num6 + num5) / 2;
							num13 = *(int*)(ptr + 576 + num4 * 56 + 32 + num);
							num21 = *(int*)(ptr + 576 + num4 * 56 + num);
							if (num7 >= num13 + num21)
							{
								num6 = num4 + 1;
								continue;
							}
							if (num13 <= num7)
							{
								break;
							}
							num5 = num4 - 1;
						}
						num14 = num4;
						int num8 = *(int*)(ptr + 576 + num14 * 56 + 24 + num);
						num18 = num8;
						num21 = num31;
						num13 = 0;
						num4 = 8;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 1080 + num5 * 48 + 32 + num);
							num7 = *(int*)(ptr + 1080 + num5 * 48 + num);
							if (num21 >= num6 + num7)
							{
								num13 = num5 + 1;
								continue;
							}
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						num14 = num5;
						int num9 = *(int*)(ptr + 1080 + num14 * 48 + 16 + num);
						num8 = num9;
						while (true)
						{
							if (array3 == null || (int)array3[5] == 1)
							{
								num21 = num18;
								while (num21 != num12)
								{
									if (num21 != -1)
									{
										num21 = *(int*)(ptr + num21 + 48 + num);
										continue;
									}
									goto IL_021d;
								}
								num2 = num31;
								break;
							}
							int num32 = (int)array3[3];
							int num33;
							if (num12 == -1)
							{
								num33 = -1;
							}
							else
							{
								int num10 = *(int*)(ptr + num12 + 24 + num);
								num7 = 0;
								num6 = 8;
								while (true)
								{
									num5 = (num7 + num6) / 2;
									num4 = *(int*)(ptr + 1080 + num5 * 48 + 32 + num);
									num13 = *(int*)(ptr + 1080 + num5 * 48 + num);
									if (num10 < num4 + num13)
									{
										if (num4 <= num10)
										{
											break;
										}
										num6 = num5 - 1;
									}
									else
									{
										num7 = num5 + 1;
									}
								}
								num9 = num5;
								num14 = *(int*)(ptr + 1080 + num9 * 48 + 16 + num);
								num33 = num14;
							}
							if (num32 == num33)
							{
								num14 = num18;
								while (num14 != num12)
								{
									if (num14 != -1)
									{
										num14 = *(int*)(ptr + num14 + 48 + num);
										continue;
									}
									goto IL_0312;
								}
								num2 = num31;
								break;
							}
							if ((int)array3[3] != num8)
							{
								array3 = (object[])array3[0];
								continue;
							}
							num2 = num31;
							break;
							IL_0312:
							num9 = *(int*)(ptr + num12 + 32 + num);
							if (num9 == -1)
							{
								num12 = *(int*)(ptr + num12 + 48 + num);
								continue;
							}
							num21 = *(int*)(ptr + num9 + 16 + num);
							object[] array4 = new object[8];
							array4[5] = 1;
							array4[0] = array3;
							array4[4] = num31;
							array4[3] = num9;
							array4[2] = 2;
							array3 = array4;
							num2 = *(int*)(ptr + num9 + 16 + num);
							break;
							IL_021d:
							num13 = *(int*)(ptr + num12 + 32 + num);
							if (num13 == -1)
							{
								num12 = *(int*)(ptr + num12 + 48 + num);
								continue;
							}
							num4 = *(int*)(ptr + num13 + 16 + num);
							array4 = new object[8];
							array4[5] = 1;
							array4[0] = array3;
							array4[4] = num31;
							array4[3] = num13;
							array4[2] = 2;
							array3 = array4;
							num2 = *(int*)(ptr + num13 + 16 + num);
							break;
						}
						break;
					}
					default:
						((delegate*<ref int, ref int, ref int, Exception, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, Class152, void>)GCHandleTypeNotNullableValueTypeConstraint[num2])(ref num2, ref num3, ref num24, ex2, ref num25, ref num26, ref num27, ref num28, ref num29, ref num30, ref obj3, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref text24, ref text25, ref text26, this);
						break;
					case 32:
						num3 = 0;
						return;
					}
				}
			}
			catch (Exception ex3)
			{
				if (num23 == 1)
				{
					throw ex3;
				}
				ex = ex3;
				num22 = -1;
				try0057_dispatch = 2059;
			}
		}
	}

	private static bool OpcodeSTOREASSEMBLYSTATUSFLAGS(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	public Class152()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static void getImageRuntimeVersionBgeUn()
	{
		PlayerPrefs.Save();
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 40;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 37;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RCUsedSize.NewIDsetUnicodeEncoded);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02ea:
															byte b = *ptr2;
															while (true)
															{
																IL_02da:
																ptr2++;
																while (true)
																{
																	IL_02ca:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02aa:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_029d:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_028d:
																								if (9 <= b)
																								{
																									num = 72;
																									while (true)
																									{
																										IL_0229:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										while (true)
																										{
																											IL_0210:
																											num5 -= 2;
																											num = 120;
																											while (num != 120)
																											{
																												if (num != 1101)
																												{
																													goto end_IL_02ba;
																												}
																												switch (num)
																												{
																												case 48:
																													goto IL_0210;
																												case 72:
																												case 93:
																													goto IL_0229;
																												case 6:
																													goto IL_028d;
																												case 100:
																												case 106:
																													goto IL_029d;
																												case 68:
																													goto IL_02aa;
																												case 14:
																													goto IL_02ba;
																												case 95:
																													goto IL_02ca;
																												case 102:
																													goto IL_02da;
																												case 27:
																												case 109:
																													goto IL_02ea;
																												case 65:
																													goto IL_02f5;
																												case 49:
																												case 91:
																													goto IL_0305;
																												case 23:
																												case 84:
																													goto IL_0310;
																												case 47:
																													goto IL_031e;
																												case 70:
																													goto IL_0331;
																												case 34:
																												case 51:
																													goto IL_033f;
																												case 10:
																												case 110:
																													goto IL_035b;
																												case 20:
																													goto IL_0369;
																												case 35:
																												case 50:
																													goto IL_0377;
																												case 82:
																													goto IL_039a;
																												case 22:
																													goto IL_03a8;
																												case 67:
																													goto IL_03b6;
																												case 111:
																													goto IL_03c9;
																												case 7:
																												case 113:
																													goto IL_03d7;
																												case 3:
																													goto IL_0417;
																												case 92:
																													goto IL_042b;
																												case 88:
																													goto IL_043e;
																												case 45:
																												case 101:
																													goto IL_0449;
																												case 108:
																													goto IL_0489;
																												case 104:
																													goto IL_049d;
																												case 96:
																													goto IL_04b0;
																												case 79:
																													goto IL_04be;
																												case 71:
																													goto IL_04c9;
																												case 94:
																													goto IL_04dc;
																												case 58:
																													goto IL_04ea;
																												case 33:
																												case 52:
																													goto IL_04f8;
																												case 36:
																													goto IL_0506;
																												case 24:
																													goto IL_0529;
																												case 55:
																													goto IL_0533;
																												case 53:
																													goto IL_0541;
																												case 28:
																													goto IL_0554;
																												case 5:
																												case 31:
																													goto IL_0562;
																												case 4:
																												case 56:
																													goto IL_0576;
																												case 62:
																													goto IL_0584;
																												case 18:
																												case 86:
																													goto IL_0592;
																												case 59:
																													goto IL_05bb;
																												case 0:
																													goto IL_05c9;
																												case 99:
																													goto IL_05dc;
																												case 43:
																												case 77:
																													goto IL_05e7;
																												case 32:
																													goto IL_0600;
																												case 46:
																													goto IL_060e;
																												case 11:
																													goto IL_061c;
																												case 26:
																												case 74:
																													goto IL_062c;
																												case 1:
																												case 2:
																												case 9:
																												case 12:
																												case 15:
																												case 16:
																												case 19:
																												case 29:
																												case 42:
																												case 44:
																												case 54:
																												case 57:
																												case 60:
																												case 64:
																												case 73:
																												case 80:
																												case 85:
																												case 89:
																												case 90:
																												case 105:
																													goto end_IL_02ba;
																												case 17:
																												case 21:
																												case 30:
																												case 38:
																												case 41:
																												case 66:
																												case 69:
																												case 75:
																												case 76:
																												case 87:
																												case 97:
																												case 103:
																												case 107:
																													goto end_IL_01fd;
																												case 25:
																													goto end_IL_065d;
																												case 13:
																													goto end_IL_0670;
																												case 98:
																													goto end_IL_067a;
																												case 112:
																													goto end_IL_0685;
																												case 37:
																													goto end_IL_069a;
																												case 61:
																													goto end_IL_06aa;
																												case 81:
																													goto end_IL_06ba;
																												case 8:
																												case 83:
																													goto end_IL_06c5;
																												case 39:
																													goto end_IL_06d5;
																												case 40:
																													goto end_IL_06e5;
																												case 63:
																												case 78:
																													goto IL_0700;
																												}
																												continue;
																												end_IL_01fd:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02f5;
																								IL_03a8:
																								num5++;
																								goto IL_03b6;
																								IL_03b6:
																								ptr2 += 8;
																								break;
																								IL_02f5:
																								if (7 < b)
																								{
																									goto IL_035b;
																								}
																								goto IL_03c9;
																								IL_03c9:
																								if (7 > b)
																								{
																									goto end_IL_02ba;
																								}
																								goto IL_03d7;
																								IL_03d7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0417;
																								IL_0417:
																								array[num5 - 2] = 0;
																								goto IL_042b;
																								IL_042b:
																								num5--;
																								break;
																								IL_035b:
																								if (8 < b)
																								{
																									goto end_IL_02ba;
																								}
																								goto IL_0369;
																								IL_0369:
																								if (8 > b)
																								{
																									goto end_IL_02ba;
																								}
																								goto IL_0377;
																								IL_0377:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_039a;
																								IL_039a:
																								array[num5] = 0;
																								goto IL_03a8;
																							}
																							break;
																						}
																						goto IL_0305;
																						IL_033f:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_0305:
																						if (10 < b)
																						{
																							goto IL_0310;
																						}
																						goto IL_0331;
																						IL_0310:
																						if (11 < b)
																						{
																							goto end_IL_02ba;
																						}
																						goto IL_031e;
																						IL_031e:
																						if (11 <= b)
																						{
																						}
																						goto end_IL_02ba;
																						IL_0331:
																						if (10 > b)
																						{
																							goto end_IL_02ba;
																						}
																						goto IL_033f;
																					}
																					break;
																				}
																				goto IL_043e;
																				IL_061c:
																				ptr2 += 8;
																				break;
																				IL_043e:
																				if (6 <= b)
																				{
																					goto IL_0449;
																				}
																				goto IL_04b0;
																				IL_0449:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0489;
																				IL_0489:
																				array[num5 - 2] = 0;
																				goto IL_049d;
																				IL_049d:
																				num5--;
																				break;
																				IL_04b0:
																				if (3 < b)
																				{
																					goto IL_04be;
																				}
																				goto IL_0554;
																				IL_04be:
																				if (4 >= b)
																				{
																					goto IL_04c9;
																				}
																				goto IL_04dc;
																				IL_04c9:
																				if (4 <= b)
																				{
																					break;
																				}
																				goto end_IL_02ba;
																				IL_04dc:
																				if (5 < b)
																				{
																					goto end_IL_02ba;
																				}
																				goto IL_04ea;
																				IL_04ea:
																				if (5 > b)
																				{
																					goto end_IL_02ba;
																				}
																				goto IL_04f8;
																				IL_04f8:
																				array[num5] = 0;
																				goto IL_0506;
																				IL_0506:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0529;
																				IL_0529:
																				array2[num5] = null;
																				goto IL_0533;
																				IL_0533:
																				num5++;
																				goto IL_0541;
																				IL_0541:
																				ptr2 += 8;
																				break;
																				IL_0554:
																				if (3 > b)
																				{
																					goto IL_0562;
																				}
																				goto IL_062c;
																				IL_0562:
																				if (1 < b)
																				{
																					num = 4;
																					goto IL_0576;
																				}
																				goto IL_05dc;
																				IL_062c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_0576:
																				if (2 < b)
																				{
																					goto end_IL_02ba;
																				}
																				goto IL_0584;
																				IL_0584:
																				if (2 > b)
																				{
																					goto end_IL_02ba;
																				}
																				goto IL_0592;
																				IL_0592:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05bb;
																				IL_05bb:
																				ptr2 += 8;
																				goto IL_05c9;
																				IL_05c9:
																				num5--;
																				break;
																				IL_05dc:
																				if (1 > b)
																				{
																					goto end_IL_02ba;
																				}
																				goto IL_05e7;
																				IL_05e7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0600;
																				IL_0600:
																				array[num5] = 0;
																				goto IL_060e;
																				IL_060e:
																				num5++;
																				goto IL_061c;
																			}
																			goto end_IL_02ca;
																			continue;
																			end_IL_02ba:
																			break;
																			IL_02ba:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 87;
																	break;
																	continue;
																	end_IL_02ca:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0700;
													IL_0700:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_065d:
													break;
												}
												continue;
												end_IL_0670:
												break;
											}
											continue;
											end_IL_067a:
											break;
										}
										continue;
										end_IL_0685:
										break;
									}
									continue;
									end_IL_069a:
									break;
								}
								continue;
								end_IL_06aa:
								break;
							}
							continue;
							end_IL_06ba:
							break;
						}
						continue;
						end_IL_06c5:
						break;
					}
					continue;
					end_IL_06d5:
					break;
				}
				continue;
				end_IL_06e5:
				break;
			}
		}
	}

	private static bool ARMSystemLazyDebugView()
	{
		return PhotonNetwork.ReconnectAndRejoin();
	}

	private static double IsFinalNetCodeGroup(double double_3)
	{
		return Math.Log(double_3);
	}

	private static int MyMusicSoapLanguage(int int_2, int int_3)
	{
		return UnityEngine.Random.Range(int_2, int_3);
	}

	private static Action<EResult> MetadataSectionMvidValueSizeIsConst(object object_0, IntPtr intptr_1)
	{
		return default(Action<EResult>);
	}

	private static Action<string> PrivilegeOffsetHigh()
	{
		return _003C_003Ec.action_3;
	}

	private static bool setControlPrincipalFoundMonthPatternFlag(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 2;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 86;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SystemTimegetMuiMapping.ISurrogateSelectorSubKeyCount);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 84;
																while (true)
																{
																	IL_0258:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0238:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_022b:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_021e:
																								if (7 <= b)
																								{
																									while (true)
																									{
																										IL_0203:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										while (true)
																										{
																											IL_01f3:
																											array[num5] = 0;
																											while (true)
																											{
																												IL_01da:
																												num5++;
																												num = 110;
																												while (true)
																												{
																													if (num != 110)
																													{
																														if (num != 1091)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 26:
																															goto IL_01da;
																														case 93:
																															goto IL_01f3;
																														case 71:
																														case 77:
																															goto IL_0203;
																														case 52:
																															goto IL_021e;
																														case 55:
																														case 83:
																															goto IL_022b;
																														case 34:
																															goto IL_0238;
																														case 64:
																															goto IL_0248;
																														case 84:
																															goto IL_0258;
																														case 88:
																															goto end_IL_0258;
																														case 33:
																														case 35:
																															goto end_IL_0268;
																														case 29:
																														case 49:
																															goto IL_028c;
																														case 7:
																															goto IL_0297;
																														case 51:
																														case 61:
																															goto IL_02a7;
																														case 13:
																															goto IL_02b5;
																														case 65:
																															goto IL_02c5;
																														case 14:
																														case 20:
																															goto IL_02d0;
																														case 67:
																															goto IL_02fa;
																														case 48:
																														case 76:
																															goto IL_030a;
																														case 11:
																															goto IL_034a;
																														case 72:
																															goto IL_035e;
																														case 69:
																														case 79:
																															goto IL_037a;
																														case 42:
																															goto IL_03ba;
																														case 54:
																															goto IL_03ce;
																														case 73:
																															goto IL_03f4;
																														case 9:
																															goto IL_0402;
																														case 25:
																															goto IL_0410;
																														case 22:
																														case 27:
																															goto IL_041b;
																														case 39:
																															goto IL_045b;
																														case 98:
																															goto IL_046f;
																														case 56:
																															goto IL_0482;
																														case 101:
																															goto IL_0490;
																														case 74:
																															goto IL_04a3;
																														case 8:
																															goto IL_04ae;
																														case 36:
																														case 75:
																															goto IL_04bc;
																														case 68:
																															goto IL_04e5;
																														case 10:
																															goto IL_04f3;
																														case 99:
																															goto IL_0506;
																														case 41:
																															goto IL_0514;
																														case 24:
																														case 28:
																															goto IL_0522;
																														case 94:
																															goto IL_0562;
																														case 63:
																															goto IL_0576;
																														case 12:
																														case 91:
																															goto IL_0589;
																														case 31:
																															goto IL_0597;
																														case 92:
																															goto IL_05ba;
																														case 30:
																															goto IL_05c4;
																														case 97:
																															goto IL_05d2;
																														case 5:
																														case 6:
																														case 17:
																														case 18:
																														case 21:
																														case 37:
																														case 45:
																														case 46:
																														case 53:
																														case 58:
																														case 59:
																														case 66:
																														case 78:
																														case 81:
																														case 82:
																														case 89:
																														case 95:
																														case 102:
																															goto end_IL_0248;
																														case 62:
																															goto IL_0605;
																														case 4:
																															goto end_IL_01c7;
																														case 47:
																															goto IL_0621;
																														case 0:
																														case 3:
																														case 19:
																														case 40:
																														case 43:
																														case 50:
																														case 57:
																														case 60:
																														case 85:
																														case 90:
																														case 100:
																															goto end_IL_0281;
																														case 80:
																															goto end_IL_062f;
																														case 103:
																															goto end_IL_0642;
																														case 23:
																															goto end_IL_064c;
																														case 15:
																															goto end_IL_0657;
																														case 38:
																															goto end_IL_066c;
																														case 44:
																														case 86:
																															goto end_IL_0681;
																														case 16:
																															goto end_IL_0691;
																														case 32:
																														case 87:
																															goto end_IL_06a1;
																														case 1:
																															goto end_IL_06ba;
																														case 2:
																															goto end_IL_06ca;
																														case 70:
																														case 96:
																															goto IL_06e5;
																														}
																														continue;
																													}
																													ptr2 += 8;
																													goto end_IL_0281;
																													continue;
																													end_IL_01c7:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02a7;
																								IL_035e:
																								num5--;
																								num = 50;
																								goto end_IL_0281;
																								IL_02a7:
																								if (6 < b)
																								{
																									goto end_IL_0248;
																								}
																								goto IL_02b5;
																								IL_02b5:
																								if (6 > b)
																								{
																									goto end_IL_0248;
																								}
																								goto IL_030a;
																								IL_030a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_034a;
																								IL_034a:
																								array[num5 - 2] = 0;
																								goto IL_035e;
																							}
																							break;
																						}
																						goto IL_028c;
																						IL_03ba:
																						array[num5 - 2] = 0;
																						goto IL_03ce;
																						IL_028c:
																						if (8 < b)
																						{
																							goto IL_0297;
																						}
																						goto IL_02fa;
																						IL_0297:
																						if (9 < b)
																						{
																							goto end_IL_0248;
																						}
																						goto IL_02c5;
																						IL_02c5:
																						if (9 > b)
																						{
																							num = 46;
																							goto end_IL_0248;
																						}
																						goto IL_02d0;
																						IL_02d0:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0281;
																						IL_03ce:
																						num5--;
																						goto end_IL_0281;
																						IL_02fa:
																						if (8 > b)
																						{
																							goto end_IL_0248;
																						}
																						goto IL_037a;
																						IL_037a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03ba;
																					}
																					break;
																				}
																				goto IL_03f4;
																				IL_05d2:
																				ptr2 += 8;
																				goto end_IL_0281;
																				IL_03f4:
																				if (5 > b)
																				{
																					goto IL_0402;
																				}
																				goto IL_0589;
																				IL_0402:
																				if (2 >= b)
																				{
																					goto IL_0410;
																				}
																				goto IL_04a3;
																				IL_0410:
																				if (2 <= b)
																				{
																					goto IL_041b;
																				}
																				goto IL_0482;
																				IL_041b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_045b;
																				IL_045b:
																				array[num5 - 2] = 0;
																				goto IL_046f;
																				IL_046f:
																				num5--;
																				goto end_IL_0281;
																				IL_0482:
																				if (1 < b)
																				{
																					goto end_IL_0248;
																				}
																				goto IL_0490;
																				IL_0490:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0248;
																				IL_04a3:
																				if (3 >= b)
																				{
																					goto IL_04ae;
																				}
																				goto IL_0506;
																				IL_04ae:
																				if (3 > b)
																				{
																					goto end_IL_0248;
																				}
																				goto IL_04bc;
																				IL_04bc:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e5;
																				IL_04e5:
																				ptr2 += 8;
																				goto IL_04f3;
																				IL_04f3:
																				num5--;
																				goto end_IL_0281;
																				IL_0506:
																				if (4 < b)
																				{
																					goto end_IL_0248;
																				}
																				goto IL_0514;
																				IL_0514:
																				if (4 > b)
																				{
																					goto end_IL_0248;
																				}
																				goto IL_0522;
																				IL_0522:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0562;
																				IL_0562:
																				array[num5 - 2] = 0;
																				goto IL_0576;
																				IL_0576:
																				num5--;
																				goto end_IL_0281;
																				IL_0589:
																				array[num5] = 0;
																				goto IL_0597;
																				IL_0597:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05ba;
																				IL_05ba:
																				array2[num5] = null;
																				goto IL_05c4;
																				IL_05c4:
																				num5++;
																				goto IL_05d2;
																			}
																			goto IL_0613;
																			continue;
																			end_IL_0248:
																			break;
																			IL_0248:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0605;
																	IL_0621:
																	ptr2 += 8;
																	goto end_IL_0281;
																	IL_0613:
																	num5++;
																	goto IL_0621;
																	IL_0605:
																	array[num5] = 0;
																	goto IL_0613;
																	continue;
																	end_IL_0258:
																	break;
																}
																continue;
																end_IL_0268:
																break;
															}
															continue;
															end_IL_0281:
															break;
														}
														continue;
													}
													goto IL_06e5;
													IL_06e5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062f:
													break;
												}
												continue;
												end_IL_0642:
												break;
											}
											continue;
											end_IL_064c:
											break;
										}
										continue;
										end_IL_0657:
										break;
									}
									continue;
									end_IL_066c:
									break;
								}
								continue;
								end_IL_0681:
								break;
							}
							continue;
							end_IL_0691:
							break;
						}
						continue;
						end_IL_06a1:
						break;
					}
					continue;
					end_IL_06ba:
					break;
				}
				continue;
				end_IL_06ca:
				break;
			}
		}
	}

	private static NetworkSystemPUN.InternalState ThreadPoolEnqueueWorkRuntimeFieldHandle(NetworkSystemPUN networkSystemPUN_0)
	{
		return networkSystemPUN_0.internalState;
	}

	private static double getDefaultGrantSetIFileAssociationEntry(double double_3)
	{
		return Math.Floor(double_3);
	}

	private static float EncryptionAlgorithmgetPropagationFlags(Class152 class152_1)
	{
		return class152_1.float_0;
	}

	private static Action<string> RsaSignMDStreamVersion(object object_0, IntPtr intptr_1)
	{
		return default(Action<string>);
	}

	private static PlayFabAuthenticator InternCreateDefaultTypeInfo()
	{
		return PlayFabAuthenticator.instance;
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setKeyContainerNameWindowsRuntime.PackageSimpleNameEnsureCharCapacity);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_024c:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_022f:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_021f:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_020f:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_01ff:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											num = 111;
																											while (true)
																											{
																												if (num != 111)
																												{
																													if (num != 1092)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 61:
																														goto IL_01ec;
																													case 40:
																													case 87:
																														goto IL_01ff;
																													case 20:
																														goto IL_020f;
																													case 52:
																														goto IL_021f;
																													case 1:
																														goto IL_022f;
																													case 66:
																														goto IL_023c;
																													case 0:
																														goto IL_024c;
																													case 92:
																														goto end_IL_024c;
																													case 97:
																													case 104:
																														goto end_IL_025c;
																													case 6:
																														goto IL_0277;
																													case 3:
																														goto IL_0282;
																													case 15:
																														goto IL_0290;
																													case 11:
																													case 30:
																														goto IL_029e;
																													case 45:
																													case 51:
																														goto IL_02c9;
																													case 47:
																														goto IL_02d7;
																													case 56:
																														goto end_IL_01d9;
																													case 36:
																														goto IL_030d;
																													case 85:
																														goto IL_0320;
																													case 44:
																														goto IL_032e;
																													case 12:
																													case 83:
																														goto IL_033c;
																													case 50:
																														goto IL_0355;
																													case 14:
																														goto IL_0363;
																													case 18:
																														goto IL_0371;
																													case 86:
																														goto IL_0384;
																													case 8:
																													case 26:
																														goto IL_038f;
																													case 55:
																														goto IL_039d;
																													case 57:
																														goto IL_03b0;
																													case 88:
																														goto IL_03c3;
																													case 37:
																														goto IL_03cd;
																													case 32:
																														goto IL_03db;
																													case 10:
																													case 94:
																														goto IL_03f7;
																													case 82:
																														goto IL_0402;
																													case 7:
																													case 49:
																														goto IL_0410;
																													case 77:
																														goto IL_0428;
																													case 21:
																														goto IL_0436;
																													case 13:
																													case 98:
																														goto IL_0452;
																													case 48:
																													case 103:
																														goto IL_046e;
																													case 19:
																														goto IL_047c;
																													case 17:
																													case 70:
																														goto IL_048a;
																													case 23:
																														goto IL_04ad;
																													case 74:
																														goto IL_04bb;
																													case 67:
																														goto IL_04d2;
																													case 63:
																														goto IL_04e5;
																													case 22:
																														goto IL_0525;
																													case 81:
																														goto IL_0539;
																													case 53:
																													case 72:
																														goto IL_0555;
																													case 71:
																														goto IL_05c0;
																													case 4:
																													case 5:
																													case 9:
																													case 24:
																													case 27:
																													case 28:
																													case 33:
																													case 34:
																													case 38:
																													case 54:
																													case 58:
																													case 68:
																													case 78:
																													case 84:
																													case 89:
																													case 91:
																													case 95:
																													case 96:
																													case 100:
																													case 101:
																														goto end_IL_01ec;
																													case 16:
																													case 25:
																													case 29:
																													case 35:
																													case 43:
																													case 46:
																													case 59:
																													case 62:
																													case 73:
																													case 75:
																													case 76:
																													case 90:
																													case 93:
																														goto end_IL_026c;
																													case 102:
																														goto end_IL_05ec;
																													case 39:
																														goto end_IL_05ff;
																													case 65:
																														goto end_IL_0609;
																													case 31:
																														goto end_IL_0614;
																													case 60:
																													case 64:
																														goto end_IL_0629;
																													case 80:
																														goto end_IL_0639;
																													case 69:
																													case 99:
																														goto end_IL_0649;
																													case 41:
																														goto end_IL_0659;
																													case 42:
																														goto end_IL_0669;
																													case 2:
																													case 79:
																														goto IL_0684;
																													}
																													continue;
																												}
																												goto IL_04e5;
																												IL_0525:
																												array[num5 - 2] = 0;
																												goto IL_0539;
																												IL_0539:
																												num5--;
																												num = 75;
																												goto end_IL_026c;
																												IL_04e5:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0525;
																												continue;
																												end_IL_01d9:
																												break;
																											}
																											goto IL_02ff;
																											continue;
																											end_IL_01ec:
																											break;
																											IL_01ec:;
																										}
																										break;
																									}
																									goto IL_046e;
																									IL_04d2:
																									ptr2 += 8;
																									goto end_IL_026c;
																									IL_046e:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_047c;
																									IL_047c:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_048a;
																									IL_048a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_04ad;
																									IL_04ad:
																									array[num5] = 0;
																									goto IL_04bb;
																									IL_04bb:
																									num5++;
																									num = 67;
																									goto IL_04d2;
																								}
																								break;
																							}
																							goto IL_0555;
																							IL_05c0:
																							num5 -= 2;
																							num = 90;
																							goto end_IL_026c;
																							IL_0555:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 71;
																							goto IL_05c0;
																						}
																						break;
																					}
																					goto IL_0384;
																					IL_0452:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_026c;
																					IL_0384:
																					if (9 < b)
																					{
																						goto IL_038f;
																					}
																					goto IL_03b0;
																					IL_038f:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_039d;
																					IL_039d:
																					if (10 <= b)
																					{
																					}
																					break;
																					IL_03b0:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0452;
																				}
																				break;
																			}
																			goto IL_0277;
																			IL_03cd:
																			num5++;
																			goto IL_03db;
																			IL_0277:
																			if (5 > b)
																			{
																				goto IL_0282;
																			}
																			goto IL_02c9;
																			IL_0282:
																			if (2 >= b)
																			{
																				goto IL_0290;
																			}
																			goto IL_03f7;
																			IL_0290:
																			if (2 <= b)
																			{
																				goto IL_029e;
																			}
																			goto IL_0320;
																			IL_029e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_02ff;
																			IL_02ff:
																			ptr2 += 8;
																			goto IL_030d;
																			IL_030d:
																			num5--;
																			goto end_IL_026c;
																			IL_0320:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_032e;
																			IL_032e:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_033c;
																			IL_033c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0355;
																			IL_0355:
																			array[num5] = 0;
																			goto IL_0363;
																			IL_0363:
																			num5++;
																			goto IL_0371;
																			IL_0371:
																			ptr2 += 8;
																			goto end_IL_026c;
																			IL_03f7:
																			if (3 >= b)
																			{
																				goto IL_0402;
																			}
																			goto IL_0428;
																			IL_0402:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0410;
																			IL_0410:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_026c;
																			IL_0428:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0436;
																			IL_0436:
																			if (4 > b)
																			{
																				break;
																			}
																			num = 25;
																			goto end_IL_026c;
																			IL_03db:
																			ptr2 += 8;
																			num = 59;
																			goto end_IL_026c;
																			IL_02c9:
																			array[num5] = 0;
																			goto IL_02d7;
																			IL_02d7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03c3;
																			IL_03c3:
																			array2[num5] = null;
																			goto IL_03cd;
																		}
																		break;
																		IL_023c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_026c;
																continue;
																end_IL_024c:
																break;
															}
															continue;
															end_IL_025c:
															break;
														}
														continue;
														end_IL_026c:
														break;
													}
													continue;
												}
												goto IL_0684;
												IL_0684:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ec:
												break;
											}
											continue;
											end_IL_05ff:
											break;
										}
										continue;
										end_IL_0609:
										break;
									}
									continue;
									end_IL_0614:
									break;
								}
								continue;
								end_IL_0629:
								break;
							}
							continue;
							end_IL_0639:
							break;
						}
						continue;
						end_IL_0649:
						break;
					}
					continue;
					end_IL_0659:
					break;
				}
				continue;
				end_IL_0669:
				break;
			}
		}
	}

	private static PlatformTagJoin getResourceTypeResourcesDependencyGUID(PlayFabAuthenticator playFabAuthenticator_0)
	{
		return playFabAuthenticator_0.platform;
	}

	private static void getIsAppEarlierThanSilverlightIntern(Player player_0, string string_0)
	{
		player_0.NickName = string_0;
	}

	private static int EtwSessiongetCondition(double double_3)
	{
		return Convert.ToInt32(double_3);
	}

	private static GorillaComputer LoadFilegetWindowTop()
	{
		return GorillaComputer.instance;
	}

	private static float getAreAuditRulesCanonicalChunkNumber()
	{
		return Time.time;
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 18;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VersionAddedMakeVersionSafeName.CreateDefaultTypeInfoWindowClassfVersioned);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0293:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0273:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0266:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0256:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0246:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_020b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_01fb:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_01e2:
																																num5++;
																																num = 112;
																																while (true)
																																{
																																	if (num != 112)
																																	{
																																		if (num != 1093)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 38:
																																			goto IL_01e2;
																																		case 82:
																																			goto IL_01fb;
																																		case 9:
																																		case 64:
																																			goto IL_020b;
																																		case 69:
																																			goto IL_0226;
																																		case 44:
																																			goto IL_0236;
																																		case 19:
																																			goto IL_0246;
																																		case 4:
																																		case 12:
																																			goto IL_0256;
																																		case 42:
																																			goto IL_0266;
																																		case 29:
																																			goto IL_0273;
																																		case 13:
																																			goto IL_0283;
																																		case 88:
																																			goto IL_0293;
																																		case 43:
																																			goto end_IL_0293;
																																		case 66:
																																		case 87:
																																			goto end_IL_02a3;
																																		case 31:
																																		case 36:
																																			goto IL_02be;
																																		case 56:
																																			goto IL_02cc;
																																		case 40:
																																			goto IL_02ef;
																																		case 79:
																																			goto IL_02f9;
																																		case 3:
																																			goto IL_0307;
																																		case 16:
																																		case 90:
																																			goto IL_032d;
																																		case 22:
																																			goto IL_0356;
																																		case 57:
																																			goto IL_0364;
																																		case 74:
																																		case 89:
																																			goto IL_0377;
																																		case 5:
																																			goto IL_0382;
																																		case 32:
																																		case 100:
																																			goto IL_039b;
																																		case 27:
																																		case 95:
																																			goto end_IL_01cf;
																																		case 67:
																																			goto IL_03c1;
																																		case 75:
																																		case 97:
																																			goto IL_03d4;
																																		case 86:
																																			goto IL_03e2;
																																		case 1:
																																		case 71:
																																			goto IL_03ed;
																																		case 8:
																																			goto IL_044f;
																																		case 25:
																																		case 94:
																																			goto IL_046b;
																																		case 59:
																																			goto IL_0476;
																																		case 49:
																																		case 50:
																																			goto IL_0484;
																																		case 41:
																																			goto IL_04c4;
																																		case 85:
																																			goto IL_04d8;
																																		case 2:
																																			goto IL_04eb;
																																		case 33:
																																			goto IL_0502;
																																		case 14:
																																		case 96:
																																			goto IL_0510;
																																		case 83:
																																			goto IL_0533;
																																		case 30:
																																			goto IL_0541;
																																		case 77:
																																			goto IL_054f;
																																		case 37:
																																			goto IL_055f;
																																		case 17:
																																		case 93:
																																			goto IL_056a;
																																		case 99:
																																			goto IL_0575;
																																		case 58:
																																			goto IL_0582;
																																		case 26:
																																		case 73:
																																			goto IL_058d;
																																		case 0:
																																		case 7:
																																		case 10:
																																		case 15:
																																		case 20:
																																		case 21:
																																		case 24:
																																		case 34:
																																		case 35:
																																		case 45:
																																		case 46:
																																		case 48:
																																		case 55:
																																		case 62:
																																		case 63:
																																		case 65:
																																		case 68:
																																		case 72:
																																		case 78:
																																			goto end_IL_0226;
																																		case 6:
																																		case 11:
																																		case 47:
																																		case 52:
																																		case 54:
																																		case 70:
																																		case 91:
																																		case 98:
																																		case 101:
																																		case 102:
																																		case 103:
																																		case 104:
																																		case 105:
																																			goto end_IL_02b3;
																																		case 28:
																																			goto end_IL_05b9;
																																		case 23:
																																			goto end_IL_05cc;
																																		case 92:
																																			goto end_IL_05d6;
																																		case 76:
																																			goto end_IL_05e1;
																																		case 39:
																																		case 81:
																																			goto end_IL_05f6;
																																		case 51:
																																			goto end_IL_0606;
																																		case 18:
																																			goto end_IL_0616;
																																		case 84:
																																			goto end_IL_0626;
																																		case 60:
																																			goto end_IL_0636;
																																		case 61:
																																			goto end_IL_0641;
																																		case 53:
																																		case 80:
																																			goto IL_065c;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_02b3;
																																	continue;
																																	end_IL_01cf:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_03b3;
																													continue;
																													end_IL_0226:
																													break;
																													IL_0226:;
																												}
																												break;
																												IL_0236:;
																											}
																											break;
																										}
																										goto IL_032d;
																										IL_0364:
																										num5--;
																										goto end_IL_02b3;
																										IL_032d:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0356;
																										IL_0356:
																										ptr2 += 8;
																										goto IL_0364;
																									}
																									break;
																								}
																								goto IL_0377;
																								IL_03b3:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_03c1;
																								IL_0377:
																								if (3 >= b)
																								{
																									goto IL_0382;
																								}
																								goto IL_03b3;
																								IL_0382:
																								if (3 > b)
																								{
																									num = 45;
																									break;
																								}
																								goto IL_039b;
																								IL_03c1:
																								if (4 <= b)
																								{
																									goto end_IL_02b3;
																								}
																								break;
																								IL_039b:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02b3;
																							}
																							break;
																						}
																						goto IL_02be;
																						IL_0307:
																						ptr2 += 8;
																						goto end_IL_02b3;
																						IL_02be:
																						array[num5] = 0;
																						goto IL_02cc;
																						IL_02cc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02ef;
																						IL_02ef:
																						array2[num5] = null;
																						goto IL_02f9;
																						IL_02f9:
																						num5++;
																						goto IL_0307;
																					}
																					break;
																				}
																				goto IL_03d4;
																				IL_0575:
																				if (10 > b)
																				{
																				}
																				break;
																				IL_03d4:
																				if (8 >= b)
																				{
																					goto IL_03e2;
																				}
																				goto IL_055f;
																				IL_03e2:
																				if (8 <= b)
																				{
																					goto IL_03ed;
																				}
																				num = 94;
																				goto IL_046b;
																				IL_03ed:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_044f;
																				IL_044f:
																				num5 -= 2;
																				goto end_IL_02b3;
																				IL_0582:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_058d;
																				IL_046b:
																				if (6 >= b)
																				{
																					goto IL_0476;
																				}
																				goto IL_04eb;
																				IL_0476:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0484;
																				IL_0484:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c4;
																				IL_04c4:
																				array[num5 - 2] = 0;
																				goto IL_04d8;
																				IL_04d8:
																				num5--;
																				goto end_IL_02b3;
																				IL_04eb:
																				if (7 < b)
																				{
																					break;
																				}
																				num = 33;
																				goto IL_0502;
																				IL_058d:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02b3;
																				IL_0502:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0510;
																				IL_0510:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0533;
																				IL_0533:
																				array[num5] = 0;
																				goto IL_0541;
																				IL_0541:
																				num5++;
																				goto IL_054f;
																				IL_054f:
																				ptr2 += 8;
																				goto end_IL_02b3;
																				IL_055f:
																				if (9 < b)
																				{
																					goto IL_056a;
																				}
																				goto IL_0582;
																				IL_056a:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0575;
																			}
																			break;
																			IL_0283:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02b3;
																	continue;
																	end_IL_0293:
																	break;
																}
																continue;
																end_IL_02a3:
																break;
															}
															continue;
															end_IL_02b3:
															break;
														}
														continue;
													}
													goto IL_065c;
													IL_065c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05b9:
													break;
												}
												continue;
												end_IL_05cc:
												break;
											}
											continue;
											end_IL_05d6:
											break;
										}
										continue;
										end_IL_05e1:
										break;
									}
									continue;
									end_IL_05f6:
									break;
								}
								continue;
								end_IL_0606:
								break;
							}
							continue;
							end_IL_0616:
							break;
						}
						continue;
						end_IL_0626:
						break;
					}
					continue;
					end_IL_0636:
					break;
				}
				continue;
				end_IL_0641:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_2)
	{
		int num = 60;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 78;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRawCertDatamvalue.getCanWriteReleaseMutex);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															IL_0224:
															ptr2++;
															while (true)
															{
																IL_0214:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_01f4:
																			if (5 < b)
																			{
																				num = 113;
																				while (true)
																				{
																					if (num != 113)
																					{
																						if (num != 1094)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 72:
																							goto IL_01f4;
																						case 43:
																							goto IL_0204;
																						case 77:
																							goto IL_0214;
																						case 73:
																							goto IL_0224;
																						case 9:
																						case 100:
																							goto end_IL_01e1;
																						case 46:
																							goto IL_023f;
																						case 83:
																						case 96:
																							goto IL_0253;
																						case 58:
																							goto IL_0261;
																						case 41:
																							goto IL_0284;
																						case 82:
																							goto IL_028e;
																						case 23:
																							goto IL_029c;
																						case 99:
																							goto IL_02af;
																						case 57:
																						case 75:
																							goto IL_02ba;
																						case 76:
																						case 91:
																							goto IL_02c5;
																						case 52:
																							goto IL_02d3;
																						case 53:
																							goto IL_02e6;
																						case 2:
																						case 11:
																							goto IL_02f4;
																						case 26:
																							goto IL_030c;
																						case 0:
																						case 12:
																							goto IL_0317;
																						case 8:
																							goto IL_0325;
																						case 1:
																						case 24:
																							goto IL_0333;
																						case 84:
																							goto IL_034c;
																						case 85:
																							goto IL_035a;
																						case 92:
																							goto IL_0368;
																						case 13:
																						case 28:
																							goto IL_037b;
																						case 14:
																							goto IL_03a4;
																						case 69:
																							goto IL_03b2;
																						case 37:
																							goto IL_03ce;
																						case 22:
																							goto IL_03d9;
																						case 27:
																							goto IL_03e4;
																						case 15:
																						case 93:
																							goto IL_03fb;
																						case 68:
																							goto IL_0417;
																						case 7:
																							goto IL_0425;
																						case 70:
																							goto IL_0438;
																						case 89:
																						case 104:
																							goto IL_0446;
																						case 16:
																							goto IL_0451;
																						case 3:
																							goto IL_045f;
																						case 47:
																						case 71:
																							goto IL_046d;
																						case 34:
																							goto IL_0490;
																						case 4:
																							goto IL_049e;
																						case 63:
																							goto IL_04ac;
																						case 55:
																							goto IL_04bf;
																						case 30:
																						case 62:
																							goto IL_04cd;
																						case 50:
																							goto IL_050d;
																						case 45:
																							goto IL_0521;
																						case 20:
																						case 21:
																							goto IL_0534;
																						case 6:
																							goto IL_0596;
																						case 19:
																						case 25:
																						case 32:
																						case 35:
																						case 36:
																						case 38:
																						case 40:
																						case 51:
																						case 54:
																						case 65:
																						case 67:
																						case 79:
																						case 86:
																						case 87:
																						case 94:
																						case 95:
																						case 98:
																						case 101:
																						case 102:
																						case 105:
																						case 106:
																							goto end_IL_0204;
																						case 5:
																						case 10:
																						case 31:
																						case 33:
																						case 42:
																						case 44:
																						case 48:
																						case 49:
																						case 61:
																						case 64:
																						case 66:
																						case 90:
																						case 97:
																							goto end_IL_0234;
																						case 39:
																							goto end_IL_05b9;
																						case 88:
																							goto end_IL_05cc;
																						case 18:
																							goto end_IL_05d6;
																						case 56:
																							goto end_IL_05e1;
																						case 74:
																						case 80:
																							goto end_IL_05f6;
																						case 29:
																							goto end_IL_0606;
																						case 78:
																						case 103:
																							goto end_IL_0616;
																						case 59:
																							goto end_IL_0626;
																						case 60:
																							goto end_IL_0636;
																						case 17:
																						case 81:
																							goto IL_065a;
																						}
																						continue;
																					}
																					goto IL_03ce;
																					IL_0521:
																					num5--;
																					goto end_IL_0234;
																					IL_0534:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0596;
																					IL_03ce:
																					if (8 < b)
																					{
																						goto IL_03d9;
																					}
																					goto IL_0438;
																					IL_03d9:
																					if (9 >= b)
																					{
																						goto IL_03e4;
																					}
																					goto IL_0417;
																					IL_03e4:
																					if (9 > b)
																					{
																						goto end_IL_0204;
																					}
																					num = 93;
																					goto IL_03fb;
																					IL_0596:
																					num5 -= 2;
																					goto end_IL_0234;
																					IL_03fb:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0234;
																					IL_0417:
																					if (10 < b)
																					{
																						goto end_IL_0204;
																					}
																					goto IL_0425;
																					IL_0425:
																					if (10 > b)
																					{
																					}
																					goto end_IL_0204;
																					IL_0438:
																					if (8 > b)
																					{
																						goto IL_0446;
																					}
																					goto IL_0534;
																					IL_0446:
																					if (6 < b)
																					{
																						goto IL_0451;
																					}
																					goto IL_04bf;
																					IL_0451:
																					if (7 < b)
																					{
																						goto end_IL_0204;
																					}
																					goto IL_045f;
																					IL_045f:
																					if (7 > b)
																					{
																						goto end_IL_0204;
																					}
																					goto IL_046d;
																					IL_046d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0490;
																					IL_0490:
																					array[num5] = 0;
																					goto IL_049e;
																					IL_049e:
																					num5++;
																					goto IL_04ac;
																					IL_04ac:
																					ptr2 += 8;
																					goto end_IL_0234;
																					IL_04bf:
																					if (6 > b)
																					{
																						goto end_IL_0204;
																					}
																					goto IL_04cd;
																					IL_04cd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_050d;
																					IL_050d:
																					array[num5 - 2] = 0;
																					goto IL_0521;
																					continue;
																					end_IL_01e1:
																					break;
																				}
																				break;
																			}
																			goto IL_023f;
																			IL_037b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03a4;
																			IL_03a4:
																			ptr2 += 8;
																			goto IL_03b2;
																			IL_023f:
																			if (5 <= b)
																			{
																				num = 83;
																				goto IL_0253;
																			}
																			goto IL_02af;
																			IL_03b2:
																			num5--;
																			num = 10;
																			goto end_IL_0234;
																			IL_0253:
																			array[num5] = 0;
																			goto IL_0261;
																			IL_0261:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0284;
																			IL_0284:
																			array2[num5] = null;
																			goto IL_028e;
																			IL_028e:
																			num5++;
																			goto IL_029c;
																			IL_029c:
																			ptr2 += 8;
																			goto end_IL_0234;
																			IL_02af:
																			if (2 < b)
																			{
																				goto IL_02ba;
																			}
																			goto IL_030c;
																			IL_02ba:
																			if (3 < b)
																			{
																				goto IL_02c5;
																			}
																			goto IL_02e6;
																			IL_02c5:
																			if (4 < b)
																			{
																				goto end_IL_0204;
																			}
																			goto IL_02d3;
																			IL_02d3:
																			if (4 > b)
																			{
																				goto end_IL_0204;
																			}
																			goto end_IL_0234;
																			IL_02e6:
																			if (3 > b)
																			{
																				goto end_IL_0204;
																			}
																			goto IL_02f4;
																			IL_02f4:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0234;
																			IL_030c:
																			if (2 > b)
																			{
																				goto IL_0317;
																			}
																			goto IL_037b;
																			IL_0317:
																			if (1 < b)
																			{
																				goto end_IL_0204;
																			}
																			goto IL_0325;
																			IL_0325:
																			if (1 > b)
																			{
																				goto end_IL_0204;
																			}
																			goto IL_0333;
																			IL_0333:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_034c;
																			IL_034c:
																			array[num5] = 0;
																			goto IL_035a;
																			IL_035a:
																			num5++;
																			goto IL_0368;
																			IL_0368:
																			ptr2 += 8;
																			goto end_IL_0234;
																		}
																		goto end_IL_0214;
																		continue;
																		end_IL_0204:
																		break;
																		IL_0204:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0234;
																continue;
																end_IL_0214:
																break;
															}
															break;
														}
														continue;
														end_IL_0234:
														break;
													}
													continue;
												}
												goto IL_065a;
												IL_065a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b9:
												break;
											}
											continue;
											end_IL_05cc:
											break;
										}
										continue;
										end_IL_05d6:
										break;
									}
									continue;
									end_IL_05e1:
									break;
								}
								continue;
								end_IL_05f6:
								break;
							}
							continue;
							end_IL_0606:
							break;
						}
						continue;
						end_IL_0616:
						break;
					}
					continue;
					end_IL_0626:
					break;
				}
				continue;
				end_IL_0636:
				break;
			}
		}
	}

	private static float setProduceLegacyHmacValuesPrivate()
	{
		return Time.time;
	}

	private static bool DirectoryNotFoundExceptionHasFlag()
	{
		return PhotonNetwork.InRoom;
	}

	private unsafe static int smethod_9(int int_2)
	{
		int num = 113;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 11;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setConfigurationFilegetDeclaringType.EvidenceTypeGeneratedFreeHGlobal);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0310:
														num = 61;
														while (true)
														{
															IL_0305:
															byte b = *ptr2;
															while (true)
															{
																IL_02f5:
																ptr2++;
																while (true)
																{
																	IL_02e2:
																	if (b >= 1)
																	{
																		num = 65;
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02c2:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_02b5:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_02a5:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0298:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0288:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														while (2 <= b)
																														{
																															while (true)
																															{
																																IL_023d:
																																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																while (true)
																																{
																																	IL_022d:
																																	ptr2 += 8;
																																	while (true)
																																	{
																																		IL_0214:
																																		num5--;
																																		num = 121;
																																		while (num != 121)
																																		{
																																			if (num != 1102)
																																			{
																																				goto end_IL_0268;
																																			}
																																			switch (num)
																																			{
																																			case 8:
																																				goto IL_0214;
																																			case 26:
																																				goto IL_022d;
																																			case 84:
																																			case 110:
																																				goto IL_023d;
																																			case 42:
																																				goto IL_0268;
																																			case 95:
																																			case 96:
																																				goto IL_0278;
																																			case 83:
																																				goto IL_0288;
																																			case 18:
																																				goto IL_0298;
																																			case 40:
																																				goto IL_02a5;
																																			case 2:
																																				goto IL_02b5;
																																			case 82:
																																				goto IL_02c2;
																																			case 65:
																																				goto IL_02d2;
																																			case 97:
																																				goto IL_02e2;
																																			case 9:
																																				goto IL_02f5;
																																			case 61:
																																				goto IL_0305;
																																			case 66:
																																				goto IL_0310;
																																			case 19:
																																			case 43:
																																				goto IL_031b;
																																			case 10:
																																			case 75:
																																				goto IL_0333;
																																			case 77:
																																				goto IL_0373;
																																			case 33:
																																				goto IL_0387;
																																			case 64:
																																			case 93:
																																				goto IL_039a;
																																			case 49:
																																				goto IL_03a5;
																																			case 16:
																																				goto IL_03b8;
																																			case 51:
																																				goto IL_03c6;
																																			case 59:
																																			case 104:
																																				goto IL_03df;
																																			case 54:
																																				goto IL_03f6;
																																			case 53:
																																				goto IL_0419;
																																			case 67:
																																				goto IL_0423;
																																			case 7:
																																				goto IL_0431;
																																			case 90:
																																				goto IL_0444;
																																			case 28:
																																			case 29:
																																				goto IL_0452;
																																			case 4:
																																				goto IL_046b;
																																			case 37:
																																				goto IL_0479;
																																			case 107:
																																				goto IL_0487;
																																			case 78:
																																				goto IL_049a;
																																			case 73:
																																				goto IL_04a8;
																																			case 22:
																																			case 70:
																																				goto IL_04b3;
																																			case 111:
																																				goto IL_0515;
																																			case 36:
																																				goto IL_0528;
																																			case 17:
																																			case 92:
																																				goto IL_0533;
																																			case 76:
																																				goto IL_0541;
																																			case 0:
																																			case 31:
																																				goto IL_054f;
																																			case 3:
																																				goto IL_0572;
																																			case 13:
																																				goto IL_0580;
																																			case 30:
																																				goto IL_058e;
																																			case 99:
																																				goto IL_05a1;
																																			case 12:
																																			case 63:
																																				goto IL_05af;
																																			case 21:
																																				goto IL_05ef;
																																			case 81:
																																				goto IL_0603;
																																			case 25:
																																				goto IL_0613;
																																			case 41:
																																			case 102:
																																				goto IL_061e;
																																			case 69:
																																				goto IL_0629;
																																			case 88:
																																				goto IL_0636;
																																			case 46:
																																			case 103:
																																				goto IL_0641;
																																			case 6:
																																			case 14:
																																			case 20:
																																			case 23:
																																			case 27:
																																			case 32:
																																			case 35:
																																			case 38:
																																			case 44:
																																			case 45:
																																			case 47:
																																			case 52:
																																			case 56:
																																			case 60:
																																			case 68:
																																			case 80:
																																			case 87:
																																			case 94:
																																			case 100:
																																			case 101:
																																			case 106:
																																			case 109:
																																			case 114:
																																				goto end_IL_0268;
																																			case 1:
																																			case 15:
																																			case 48:
																																			case 55:
																																			case 57:
																																			case 74:
																																			case 79:
																																			case 86:
																																			case 89:
																																			case 91:
																																			case 98:
																																			case 105:
																																			case 108:
																																				goto end_IL_0201;
																																			case 5:
																																				goto end_IL_066d;
																																			case 50:
																																				goto end_IL_0680;
																																			case 85:
																																				goto end_IL_068a;
																																			case 24:
																																				goto end_IL_0695;
																																			case 58:
																																			case 72:
																																				goto end_IL_06aa;
																																			case 11:
																																				goto end_IL_06ba;
																																			case 34:
																																			case 39:
																																				goto end_IL_06ca;
																																			case 112:
																																				goto end_IL_06da;
																																			case 113:
																																				goto end_IL_06f3;
																																			case 62:
																																			case 71:
																																				goto IL_070e;
																																			}
																																			continue;
																																			end_IL_0201:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_02e2;
																															continue;
																															end_IL_0268:
																															break;
																															IL_0268:;
																														}
																														break;
																														IL_0278:;
																													}
																													break;
																												}
																												goto IL_0444;
																												IL_0487:
																												ptr2 += 8;
																												goto end_IL_02e2;
																												IL_0444:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_0452;
																												IL_0452:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_046b;
																												IL_046b:
																												array[num5] = 0;
																												goto IL_0479;
																												IL_0479:
																												num5++;
																												goto IL_0487;
																											}
																											break;
																										}
																										goto IL_031b;
																										IL_031b:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02e2;
																									}
																									break;
																								}
																								goto IL_039a;
																								IL_0423:
																								num5++;
																								goto IL_0431;
																								IL_039a:
																								if (4 >= b)
																								{
																									goto IL_03a5;
																								}
																								goto IL_03b8;
																								IL_03a5:
																								if (4 > b)
																								{
																									break;
																								}
																								goto end_IL_02e2;
																								IL_03b8:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_03c6;
																								IL_03c6:
																								if (5 > b)
																								{
																									num = 87;
																									break;
																								}
																								goto IL_03df;
																								IL_0431:
																								ptr2 += 8;
																								goto end_IL_02e2;
																								IL_03df:
																								array[num5] = 0;
																								num = 54;
																								goto IL_03f6;
																								IL_03f6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0419;
																								IL_0419:
																								array2[num5] = null;
																								goto IL_0423;
																							}
																							break;
																						}
																						goto IL_0333;
																						IL_0387:
																						num5--;
																						goto end_IL_02e2;
																						IL_0333:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0373;
																						IL_0373:
																						array[num5 - 2] = 0;
																						goto IL_0387;
																					}
																					break;
																				}
																				goto IL_049a;
																				IL_0641:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02e2;
																				IL_049a:
																				if (9 >= b)
																				{
																					goto IL_04a8;
																				}
																				goto IL_0613;
																				IL_04a8:
																				if (9 <= b)
																				{
																					goto IL_04b3;
																				}
																				goto IL_0528;
																				IL_04b3:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0515;
																				IL_0515:
																				num5 -= 2;
																				goto end_IL_02e2;
																				IL_0528:
																				if (7 < b)
																				{
																					goto IL_0533;
																				}
																				goto IL_05a1;
																				IL_0533:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0541;
																				IL_0541:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_054f;
																				IL_054f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0572;
																				IL_0572:
																				array[num5] = 0;
																				goto IL_0580;
																				IL_0580:
																				num5++;
																				goto IL_058e;
																				IL_058e:
																				ptr2 += 8;
																				goto end_IL_02e2;
																				IL_05a1:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05af;
																				IL_05af:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05ef;
																				IL_05ef:
																				array[num5 - 2] = 0;
																				goto IL_0603;
																				IL_0603:
																				num5--;
																				goto end_IL_02e2;
																				IL_0613:
																				if (10 < b)
																				{
																					goto IL_061e;
																				}
																				goto IL_0636;
																				IL_061e:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0629;
																				IL_0629:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_0636:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0641;
																			}
																			break;
																			IL_02d2:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02e2:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_070e;
												IL_070e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_066d:
												break;
											}
											continue;
											end_IL_0680:
											break;
										}
										continue;
										end_IL_068a:
										break;
									}
									continue;
									end_IL_0695:
									break;
								}
								continue;
								end_IL_06aa:
								break;
							}
							continue;
							end_IL_06ba:
							break;
						}
						continue;
						end_IL_06ca:
						break;
					}
					continue;
					end_IL_06da:
					break;
				}
				continue;
				end_IL_06f3:
				break;
			}
		}
	}

	private static void getManifestHashConstructionCall()
	{
		Class9.smethod_82();
	}

	private static bool CheckKeyReadPermissionAbsentOriginScheme(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private static bool SByteTypeInfoAddAccessRule(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private static Action<EResult> smethod_10()
	{
		return _003C_003Ec.action_4;
	}

	private static double FiltersgetAbbreviatedDayNames(double double_3)
	{
		return Math.Tan(double_3);
	}

	static Class152()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 3;
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 3:
							case 4:
							case 5:
								goto end_IL_0039;
							case 0:
								goto end_IL_0046;
							case 1:
								goto end_IL_0058;
							case 2:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_0058:
				break;
			}
		}
	}
}
