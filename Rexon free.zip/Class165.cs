using System;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Join Random", "Room", "Joins a random public lobby.", false, 6, ModType.const_1, false)]
internal class Class165 : MonoBehaviour
{
	private static double double_0;

	private static int int_0;

	private static double double_1;

	private static double double_2;

	private static bool bool_0;

	private static float float_0;

	private static double double_3;

	private static IntPtr[] GetEnumNamescallback;

	private static IntPtr[] getIsThreadOwnerTrackingEnabledVTEMPTY;

	private static IntPtr[] AsyncStateMachineAttributeNULLPUBLICKEY;

	private void OnEnable()
	{
		bool flag = PhotonNetwork.JoinRandomRoom();
	}

	public Class165()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 13;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 69;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemoveNamedPermissionSetDemand.ControlFlagsHexBinary);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0364:
																if (b >= 1)
																{
																	num = 100;
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0344:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0334:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0324:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_0317:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_0307:
																											if (6 > b)
																											{
																												while (5 >= b)
																												{
																													while (5 <= b)
																													{
																														while (true)
																														{
																															array[num5] = 5;
																															while (true)
																															{
																																IL_02bd:
																																array2[num5] = array5[*(int*)(ptr2 + num3)];
																																while (true)
																																{
																																	IL_02a4:
																																	num5++;
																																	num = 157;
																																	while (true)
																																	{
																																		if (num != 157)
																																		{
																																			if (num != 1138)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 140:
																																				goto IL_02a4;
																																			case 146:
																																				goto IL_02bd;
																																			case 35:
																																			case 126:
																																				goto end_IL_0291;
																																			case 59:
																																				goto end_IL_02d7;
																																			case 121:
																																				goto IL_02f7;
																																			case 65:
																																				goto IL_0307;
																																			case 95:
																																				goto IL_0317;
																																			case 124:
																																				goto IL_0324;
																																			case 15:
																																				goto IL_0334;
																																			case 23:
																																				goto IL_0344;
																																			case 100:
																																				goto IL_0354;
																																			case 139:
																																				goto IL_0364;
																																			case 90:
																																				goto end_IL_0364;
																																			case 81:
																																			case 88:
																																				goto end_IL_0377;
																																			case 42:
																																			case 50:
																																				goto IL_0392;
																																			case 38:
																																			case 67:
																																				goto IL_03a2;
																																			case 92:
																																				goto IL_03e1;
																																			case 22:
																																			case 103:
																																				goto IL_03f4;
																																			case 113:
																																				goto IL_040c;
																																			case 41:
																																			case 57:
																																				goto IL_041a;
																																			case 144:
																																				goto IL_0443;
																																			case 3:
																																				goto IL_0451;
																																			case 96:
																																				goto IL_0480;
																																			case 29:
																																			case 74:
																																				goto IL_048e;
																																			case 28:
																																			case 98:
																																				goto IL_0499;
																																			case 70:
																																				goto IL_04a7;
																																			case 66:
																																			case 129:
																																				goto IL_04b5;
																																			case 72:
																																				goto IL_04de;
																																			case 125:
																																				goto IL_04f7;
																																			case 5:
																																			case 97:
																																				goto IL_0502;
																																			case 123:
																																				goto IL_0542;
																																			case 106:
																																				goto IL_0556;
																																			case 122:
																																				goto IL_0569;
																																			case 60:
																																				goto IL_0577;
																																			case 117:
																																			case 133:
																																				goto IL_0585;
																																			case 73:
																																				goto IL_059e;
																																			case 32:
																																				goto IL_05ac;
																																			case 111:
																																				goto IL_05c3;
																																			case 16:
																																			case 51:
																																				goto IL_05d6;
																																			case 134:
																																				goto IL_05f4;
																																			case 138:
																																				goto IL_0602;
																																			case 101:
																																				goto IL_0615;
																																			case 119:
																																				goto IL_0623;
																																			case 58:
																																				goto IL_0631;
																																			case 30:
																																				goto IL_063f;
																																			case 71:
																																			case 86:
																																				goto IL_064a;
																																			case 99:
																																				goto IL_0658;
																																			case 141:
																																				goto IL_067b;
																																			case 9:
																																				goto IL_0685;
																																			case 142:
																																				goto IL_0693;
																																			case 4:
																																				goto IL_06a6;
																																			case 1:
																																				goto IL_06b4;
																																			case 7:
																																			case 148:
																																				goto IL_06c7;
																																			case 114:
																																				goto IL_06d5;
																																			case 20:
																																			case 147:
																																				goto IL_06e3;
																																			case 36:
																																				goto IL_0727;
																																			case 62:
																																				goto IL_073b;
																																			case 10:
																																			case 143:
																																				goto IL_074e;
																																			case 43:
																																				goto IL_078e;
																																			case 64:
																																				goto IL_07a2;
																																			case 110:
																																				goto IL_07b5;
																																			case 26:
																																			case 137:
																																				goto IL_07c0;
																																			case 120:
																																				goto IL_07ce;
																																			case 131:
																																				goto IL_07ea;
																																			case 53:
																																			case 80:
																																				goto IL_07f8;
																																			case 107:
																																				goto IL_0806;
																																			case 47:
																																			case 78:
																																				goto IL_0814;
																																			case 112:
																																				goto IL_0876;
																																			case 46:
																																			case 149:
																																				goto IL_0886;
																																			case 6:
																																			case 8:
																																			case 17:
																																			case 19:
																																			case 21:
																																			case 25:
																																			case 27:
																																			case 33:
																																			case 34:
																																			case 39:
																																			case 40:
																																			case 44:
																																			case 49:
																																			case 54:
																																			case 55:
																																			case 68:
																																			case 79:
																																			case 83:
																																			case 85:
																																			case 87:
																																			case 89:
																																			case 102:
																																			case 105:
																																			case 108:
																																			case 109:
																																			case 115:
																																			case 116:
																																			case 127:
																																			case 128:
																																			case 132:
																																			case 145:
																																				goto end_IL_02e7;
																																			case 11:
																																			case 12:
																																			case 14:
																																			case 45:
																																			case 48:
																																			case 52:
																																			case 56:
																																			case 61:
																																			case 63:
																																			case 75:
																																			case 82:
																																			case 91:
																																			case 93:
																																			case 94:
																																			case 118:
																																			case 130:
																																			case 135:
																																			case 150:
																																				goto end_IL_0387;
																																			case 136:
																																				goto end_IL_08b2;
																																			case 69:
																																				goto end_IL_08c5;
																																			case 0:
																																				goto end_IL_08cf;
																																			case 13:
																																				goto end_IL_08da;
																																			case 2:
																																			case 18:
																																				goto end_IL_08f3;
																																			case 31:
																																				goto end_IL_0903;
																																			case 24:
																																			case 104:
																																				goto end_IL_091c;
																																			case 76:
																																				goto end_IL_092c;
																																			case 77:
																																				goto end_IL_093c;
																																			case 37:
																																			case 84:
																																				goto IL_0957;
																																			}
																																			continue;
																																		}
																																		ptr2 += 8;
																																		goto end_IL_0387;
																																		continue;
																																		end_IL_0291:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															continue;
																															end_IL_02d7:
																															break;
																														}
																														continue;
																														end_IL_02e7:
																														break;
																													}
																													break;
																													IL_02f7:;
																												}
																												break;
																											}
																											goto IL_03a2;
																											IL_03e1:
																											num5 -= 3;
																											goto end_IL_0387;
																											IL_03a2:
																											((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_03e1;
																										}
																										break;
																									}
																									goto IL_0392;
																									IL_0451:
																									num5--;
																									goto end_IL_0387;
																									IL_0392:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_040c;
																									IL_040c:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_041a;
																									IL_041a:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0443;
																									IL_0443:
																									ptr2 += 8;
																									goto IL_0451;
																								}
																								break;
																							}
																							num = 96;
																							goto IL_0480;
																							IL_05f4:
																							ptr2 += 8;
																							goto IL_0602;
																							IL_0602:
																							num5--;
																							goto end_IL_0387;
																							IL_0480:
																							if (4 > b)
																							{
																								goto IL_048e;
																							}
																							goto IL_05d6;
																							IL_048e:
																							if (2 < b)
																							{
																								goto IL_0499;
																							}
																							goto IL_04f7;
																							IL_0499:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_04a7;
																							IL_04a7:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_04b5;
																							IL_04b5:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_04de;
																							IL_04de:
																							array[num5 - 1] = 5;
																							goto end_IL_0387;
																							IL_04f7:
																							if (2 <= b)
																							{
																								goto IL_0502;
																							}
																							goto IL_0569;
																							IL_0502:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0542;
																							IL_0542:
																							array[num5 - 2] = 0;
																							goto IL_0556;
																							IL_0556:
																							num5--;
																							goto end_IL_0387;
																							IL_0569:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0577;
																							IL_0577:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0585;
																							IL_0585:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_059e;
																							IL_059e:
																							array[num5] = 0;
																							goto IL_05ac;
																							IL_05ac:
																							num5++;
																							num = 111;
																							goto IL_05c3;
																							IL_05c3:
																							ptr2 += 8;
																							goto end_IL_0387;
																							IL_05d6:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_05f4;
																						}
																						break;
																					}
																					goto IL_03f4;
																					IL_03f4:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0387;
																				}
																				break;
																			}
																			goto IL_0615;
																			IL_0876:
																			num5 -= 2;
																			goto end_IL_0387;
																			IL_0615:
																			if (12 >= b)
																			{
																				goto IL_0623;
																			}
																			goto IL_07b5;
																			IL_0623:
																			if (12 > b)
																			{
																				goto IL_0631;
																			}
																			goto IL_074e;
																			IL_0631:
																			if (10 >= b)
																			{
																				goto IL_063f;
																			}
																			goto IL_06c7;
																			IL_063f:
																			if (10 <= b)
																			{
																				goto IL_064a;
																			}
																			goto IL_06a6;
																			IL_064a:
																			array[num5] = 0;
																			goto IL_0658;
																			IL_0658:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_067b;
																			IL_067b:
																			array2[num5] = null;
																			goto IL_0685;
																			IL_0685:
																			num5++;
																			goto IL_0693;
																			IL_0693:
																			ptr2 += 8;
																			goto end_IL_0387;
																			IL_06a6:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06b4;
																			IL_06b4:
																			if (9 <= b)
																			{
																				goto end_IL_0387;
																			}
																			break;
																			IL_06c7:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_06d5;
																			IL_06d5:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_06e3;
																			IL_06e3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0727;
																			IL_0727:
																			array[num5 - 2] = 0;
																			goto IL_073b;
																			IL_073b:
																			num5--;
																			goto end_IL_0387;
																			IL_074e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_078e;
																			IL_078e:
																			array[num5 - 2] = 0;
																			goto IL_07a2;
																			IL_07a2:
																			num5--;
																			goto end_IL_0387;
																			IL_07b5:
																			if (14 < b)
																			{
																				goto IL_07c0;
																			}
																			goto IL_07ea;
																			IL_07c0:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_07ce;
																			IL_07ce:
																			if (15 > b)
																			{
																				num = 8;
																			}
																			break;
																			IL_0886:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0387;
																			IL_07ea:
																			if (14 > b)
																			{
																				goto IL_07f8;
																			}
																			goto IL_0886;
																			IL_07f8:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0806;
																			IL_0806:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0814;
																			IL_0814:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0876;
																		}
																		break;
																		IL_0354:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0387;
																continue;
																end_IL_0364:
																break;
															}
															continue;
															end_IL_0377:
															break;
														}
														continue;
														end_IL_0387:
														break;
													}
													continue;
												}
												goto IL_0957;
												IL_0957:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b2:
												break;
											}
											continue;
											end_IL_08c5:
											break;
										}
										continue;
										end_IL_08cf:
										break;
									}
									continue;
									end_IL_08da:
									break;
								}
								continue;
								end_IL_08f3:
								break;
							}
							continue;
							end_IL_0903:
							break;
						}
						continue;
						end_IL_091c:
						break;
					}
					continue;
					end_IL_092c:
					break;
				}
				continue;
				end_IL_093c:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 73;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FCanCreateGetFileColumnNumber.UnmgdInternalEncoderBestFitFallbackBuffer);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0348:
															byte b = *ptr2;
															while (true)
															{
																IL_0338:
																ptr2++;
																while (true)
																{
																	IL_0328:
																	if (b >= 1)
																	{
																		goto IL_01d2;
																	}
																	goto IL_0307;
																	IL_0307:
																	while (true)
																	{
																		IL_0307_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 108;
																		while (num != 108)
																		{
																			if (num != 1089)
																			{
																				goto IL_0348;
																			}
																			switch (num)
																			{
																			case 29:
																				goto IL_01d2;
																			case 99:
																				goto IL_01e0;
																			case 27:
																				goto IL_01ee;
																			case 8:
																				goto IL_01fc;
																			case 66:
																				goto IL_0207;
																			case 32:
																				goto IL_0212;
																			case 70:
																				goto IL_0225;
																			case 63:
																				goto IL_0233;
																			case 38:
																				goto IL_0246;
																			case 71:
																			case 96:
																				goto IL_0254;
																			case 11:
																				goto IL_026b;
																			case 5:
																				goto IL_027e;
																			case 36:
																				goto IL_0289;
																			case 2:
																				goto IL_0297;
																			case 17:
																				goto IL_02a2;
																			case 24:
																			case 90:
																				goto IL_02bb;
																			case 23:
																				goto IL_02c6;
																			case 89:
																				goto IL_02d6;
																			case 56:
																				goto IL_02e1;
																			case 98:
																				goto IL_02f1;
																			case 47:
																				goto IL_02fc;
																			case 0:
																			case 6:
																			case 10:
																			case 15:
																			case 22:
																			case 31:
																			case 40:
																			case 49:
																			case 50:
																			case 52:
																			case 53:
																			case 62:
																			case 74:
																			case 76:
																			case 79:
																			case 80:
																			case 92:
																			case 93:
																			case 101:
																				goto IL_0307_2;
																			case 75:
																				goto IL_0328;
																			case 18:
																				goto IL_0338;
																			case 33:
																			case 85:
																				goto IL_0348;
																			case 39:
																			case 45:
																				goto IL_0353;
																			case 64:
																			case 82:
																				goto IL_036b;
																			case 26:
																				goto IL_0384;
																			case 54:
																				goto IL_0392;
																			case 48:
																				goto IL_03a0;
																			case 51:
																			case 78:
																				goto IL_03b3;
																			case 65:
																				goto IL_03e5;
																			case 95:
																				goto IL_03f3;
																			case 3:
																			case 7:
																				goto IL_0406;
																			case 77:
																				goto IL_041d;
																			case 9:
																				goto IL_0440;
																			case 97:
																				goto IL_044a;
																			case 91:
																				goto IL_0461;
																			case 16:
																			case 55:
																				goto IL_0474;
																			case 94:
																				goto IL_04b4;
																			case 21:
																				goto IL_04c8;
																			case 1:
																			case 57:
																				goto IL_04db;
																			case 88:
																				goto IL_04fe;
																			case 4:
																				goto IL_0515;
																			case 30:
																				goto IL_0523;
																			case 44:
																			case 67:
																				goto IL_0536;
																			case 42:
																			case 100:
																				goto IL_054f;
																			case 12:
																				goto IL_05b1;
																			case 13:
																			case 25:
																			case 28:
																			case 43:
																			case 46:
																			case 58:
																			case 59:
																			case 60:
																			case 61:
																			case 83:
																			case 84:
																			case 86:
																				goto end_IL_01bf;
																			case 14:
																				goto end_IL_05bf;
																			case 41:
																				goto end_IL_05d2;
																			case 37:
																				goto end_IL_05dc;
																			case 87:
																				goto end_IL_05e7;
																			case 34:
																			case 69:
																				goto end_IL_05fc;
																			case 68:
																				goto end_IL_060c;
																			case 73:
																				goto end_IL_061c;
																			case 72:
																				goto end_IL_062c;
																			case 19:
																				goto end_IL_063c;
																			case 20:
																				goto end_IL_0647;
																			case 35:
																			case 81:
																				goto IL_0662;
																			}
																			continue;
																			end_IL_01bf:
																			break;
																		}
																		break;
																	}
																	break;
																	IL_01d2:
																	if (b <= 10)
																	{
																		goto IL_01e0;
																	}
																	goto IL_0307;
																	IL_01e0:
																	if (5 >= b)
																	{
																		goto IL_01ee;
																	}
																	goto IL_027e;
																	IL_01ee:
																	if (5 > b)
																	{
																		goto IL_01fc;
																	}
																	goto IL_0406;
																	IL_01fc:
																	if (2 < b)
																	{
																		goto IL_0207;
																	}
																	goto IL_0246;
																	IL_0207:
																	if (3 >= b)
																	{
																		goto IL_0212;
																	}
																	goto IL_0225;
																	IL_0212:
																	if (3 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_0353;
																	IL_0353:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	IL_0225:
																	if (4 >= b)
																	{
																		goto IL_0233;
																	}
																	goto IL_0307;
																	IL_0233:
																	if (4 <= b)
																	{
																		break;
																	}
																	goto IL_0307;
																	IL_0246:
																	if (2 > b)
																	{
																		goto IL_0254;
																	}
																	goto IL_03b3;
																	IL_0254:
																	if (1 >= b)
																	{
																		num = 11;
																		goto IL_026b;
																	}
																	goto IL_0307;
																	IL_02f1:
																	if (10 >= b)
																	{
																		goto IL_02fc;
																	}
																	goto IL_0307;
																	IL_026b:
																	if (1 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_036b;
																	IL_036b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0384;
																	IL_0384:
																	array[num5] = 0;
																	goto IL_0392;
																	IL_0392:
																	num5++;
																	goto IL_03a0;
																	IL_03a0:
																	ptr2 += 8;
																	break;
																	IL_03b3:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	num = 65;
																	goto IL_03e5;
																	IL_03e5:
																	ptr2 += 8;
																	goto IL_03f3;
																	IL_03f3:
																	num5--;
																	break;
																	IL_0406:
																	array[num5] = 0;
																	num = 77;
																	goto IL_041d;
																	IL_041d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0440;
																	IL_0440:
																	array2[num5] = null;
																	goto IL_044a;
																	IL_044a:
																	num5++;
																	num = 91;
																	goto IL_0461;
																	IL_0461:
																	ptr2 += 8;
																	break;
																	IL_027e:
																	if (8 >= b)
																	{
																		goto IL_0289;
																	}
																	goto IL_02d6;
																	IL_0289:
																	if (8 > b)
																	{
																		goto IL_0297;
																	}
																	goto IL_054f;
																	IL_0297:
																	if (6 >= b)
																	{
																		goto IL_02a2;
																	}
																	num = 90;
																	goto IL_02bb;
																	IL_02a2:
																	if (6 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_0474;
																	IL_0474:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04b4;
																	IL_04b4:
																	array[num5 - 2] = 0;
																	goto IL_04c8;
																	IL_04c8:
																	num5--;
																	break;
																	IL_02fc:
																	if (10 > b)
																	{
																	}
																	goto IL_0307;
																	IL_02bb:
																	if (7 >= b)
																	{
																		goto IL_02c6;
																	}
																	goto IL_0307;
																	IL_02c6:
																	if (7 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_04db;
																	IL_04db:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04fe;
																	IL_04fe:
																	array[num5] = 0;
																	num = 4;
																	goto IL_0515;
																	IL_0515:
																	num5++;
																	goto IL_0523;
																	IL_0523:
																	ptr2 += 8;
																	break;
																	IL_054f:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_05b1;
																	IL_05b1:
																	num5 -= 2;
																	break;
																	IL_02d6:
																	if (9 >= b)
																	{
																		goto IL_02e1;
																	}
																	goto IL_02f1;
																	IL_02e1:
																	if (9 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_0536;
																	IL_0536:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0662;
													IL_0662:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05bf:
													break;
												}
												continue;
												end_IL_05d2:
												break;
											}
											continue;
											end_IL_05dc:
											break;
										}
										continue;
										end_IL_05e7:
										break;
									}
									continue;
									end_IL_05fc:
									break;
								}
								continue;
								end_IL_060c:
								break;
							}
							continue;
							end_IL_061c:
							break;
						}
						continue;
						end_IL_062c:
						break;
					}
					continue;
					end_IL_063c:
					break;
				}
				continue;
				end_IL_0647:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 84;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 23;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetUnmanagedThunkForManagedMethodPtrMuiResourceTypeIdStringIntegerIdsSize.SkipSizeDaylightTime);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02e8:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02c8:
																			if (8 < b)
																			{
																				goto IL_0601;
																			}
																			while (true)
																			{
																				IL_02b8:
																				if (8 > b)
																				{
																					while (true)
																					{
																						IL_02a8:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_0298:
																								if (6 >= b)
																								{
																									num = 154;
																									while (true)
																									{
																										if (num != 154)
																										{
																											if (num != 1135)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 17:
																											case 119:
																												goto IL_0298;
																											case 40:
																											case 50:
																												goto IL_02a8;
																											case 88:
																												goto IL_02b8;
																											case 136:
																												goto IL_02c8;
																											case 12:
																												goto end_IL_02c8;
																											case 141:
																												goto IL_02e8;
																											case 4:
																												goto end_IL_02e8;
																											case 39:
																											case 95:
																												goto end_IL_02f8;
																											case 16:
																												goto IL_0313;
																											case 41:
																												goto IL_0321;
																											case 85:
																											case 132:
																												goto IL_032f;
																											case 131:
																												goto IL_0358;
																											case 138:
																												goto IL_0366;
																											case 49:
																											case 57:
																												goto IL_0384;
																											case 20:
																												goto IL_0392;
																											case 1:
																											case 121:
																												goto IL_03a0;
																											case 70:
																												goto IL_03ae;
																											case 110:
																												goto IL_03c6;
																											case 90:
																												goto IL_03d4;
																											case 58:
																											case 93:
																												goto IL_03e7;
																											case 31:
																												goto IL_0426;
																											case 102:
																												goto IL_0439;
																											case 37:
																												goto IL_0447;
																											case 26:
																											case 78:
																												goto IL_0452;
																											case 67:
																												goto IL_0460;
																											case 11:
																											case 13:
																												goto IL_046e;
																											case 21:
																												goto IL_04a0;
																											case 60:
																												goto IL_04c2;
																											case 71:
																											case 100:
																												goto IL_04cd;
																											case 15:
																												goto IL_050d;
																											case 43:
																												goto IL_0521;
																											case 139:
																											case 144:
																												goto IL_0534;
																											case 120:
																												goto IL_0542;
																											case 75:
																											case 81:
																												goto IL_0550;
																											case 22:
																												goto IL_0569;
																											case 8:
																												goto IL_0577;
																											case 126:
																												goto IL_0585;
																											case 14:
																											case 89:
																												goto IL_0598;
																											case 99:
																												goto IL_05bf;
																											case 63:
																												goto IL_05cd;
																											case 25:
																											case 128:
																												goto IL_05e0;
																											case 34:
																												goto IL_0601;
																											case 114:
																												goto IL_060f;
																											case 36:
																											case 122:
																												goto IL_061d;
																											case 35:
																											case 65:
																												goto IL_062b;
																											case 73:
																												goto IL_0639;
																											case 42:
																											case 62:
																												goto IL_0652;
																											case 9:
																												goto IL_0696;
																											case 117:
																												goto IL_06aa;
																											case 129:
																												goto IL_06bd;
																											case 51:
																											case 97:
																												goto IL_06c8;
																											case 111:
																												goto IL_06d6;
																											case 59:
																											case 133:
																												goto end_IL_0285;
																											case 0:
																												goto IL_06f7;
																											case 24:
																												goto IL_071a;
																											case 52:
																												goto IL_0724;
																											case 140:
																												goto IL_073b;
																											case 2:
																											case 38:
																												goto IL_074e;
																											case 33:
																												goto IL_078e;
																											case 135:
																												goto IL_07a2;
																											case 113:
																												goto IL_07b5;
																											case 77:
																												goto IL_07c3;
																											case 54:
																											case 134:
																												goto IL_07d1;
																											case 101:
																												goto IL_07df;
																											case 96:
																											case 109:
																												goto IL_07ed;
																											case 147:
																												goto IL_084f;
																											case 29:
																											case 124:
																												goto IL_085f;
																											case 66:
																												goto IL_0878;
																											case 68:
																												goto IL_0883;
																											case 3:
																											case 7:
																											case 19:
																											case 27:
																											case 30:
																											case 32:
																											case 44:
																											case 45:
																											case 48:
																											case 55:
																											case 61:
																											case 64:
																											case 74:
																											case 86:
																											case 87:
																											case 94:
																											case 98:
																											case 103:
																											case 105:
																											case 106:
																											case 118:
																											case 123:
																											case 127:
																											case 143:
																											case 146:
																												goto end_IL_02d8;
																											case 10:
																											case 18:
																											case 28:
																											case 46:
																											case 72:
																											case 76:
																											case 79:
																											case 80:
																											case 92:
																											case 104:
																											case 107:
																											case 108:
																											case 112:
																											case 115:
																											case 116:
																											case 137:
																											case 142:
																											case 145:
																												goto end_IL_0308;
																											case 56:
																												goto end_IL_08ac;
																											case 6:
																												goto end_IL_08bf;
																											case 5:
																												goto end_IL_08c9;
																											case 23:
																												goto end_IL_08d4;
																											case 125:
																											case 130:
																												goto end_IL_08e4;
																											case 47:
																												goto end_IL_08f4;
																											case 53:
																											case 82:
																												goto end_IL_090d;
																											case 83:
																												goto end_IL_091d;
																											case 84:
																												goto end_IL_092d;
																											case 69:
																											case 91:
																												goto IL_0948;
																											}
																											continue;
																										}
																										if (6 > b)
																										{
																											goto IL_0384;
																										}
																										goto IL_03e7;
																										IL_03d4:
																										ptr2 += 8;
																										goto end_IL_0308;
																										IL_0426:
																										num5 -= 3;
																										goto end_IL_0308;
																										IL_03e7:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0426;
																										IL_0384:
																										if (5 < b)
																										{
																											goto end_IL_02d8;
																										}
																										goto IL_0392;
																										IL_0392:
																										if (5 > b)
																										{
																											goto end_IL_02d8;
																										}
																										goto IL_03a0;
																										IL_03a0:
																										array[num5] = 5;
																										goto IL_03ae;
																										IL_03ae:
																										array2[num5] = array5[*(int*)(ptr2 + num3)];
																										goto IL_03c6;
																										IL_03c6:
																										num5++;
																										goto IL_03d4;
																										continue;
																										end_IL_0285:
																										break;
																									}
																									break;
																								}
																								goto IL_0313;
																								IL_0358:
																								ptr2 += 8;
																								goto IL_0366;
																								IL_0366:
																								num5--;
																								goto end_IL_0308;
																								IL_0313:
																								if (7 < b)
																								{
																									goto end_IL_02d8;
																								}
																								goto IL_0321;
																								IL_0321:
																								if (7 > b)
																								{
																									goto end_IL_02d8;
																								}
																								goto IL_032f;
																								IL_032f:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0358;
																							}
																							break;
																						}
																						goto IL_0439;
																						IL_05cd:
																						num5--;
																						goto end_IL_0308;
																						IL_0439:
																						if (4 > b)
																						{
																							goto IL_0447;
																						}
																						goto IL_0598;
																						IL_0447:
																						if (2 < b)
																						{
																							goto IL_0452;
																						}
																						goto IL_04c2;
																						IL_0452:
																						if (3 < b)
																						{
																							goto end_IL_02d8;
																						}
																						goto IL_0460;
																						IL_0460:
																						if (3 > b)
																						{
																							goto end_IL_02d8;
																						}
																						goto IL_046e;
																						IL_046e:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						num = 21;
																						goto IL_04a0;
																						IL_04a0:
																						array[num5 - 1] = 5;
																						num = 107;
																						goto end_IL_0308;
																						IL_04c2:
																						if (2 <= b)
																						{
																							goto IL_04cd;
																						}
																						goto IL_0534;
																						IL_04cd:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_050d;
																						IL_050d:
																						array[num5 - 2] = 0;
																						goto IL_0521;
																						IL_0521:
																						num5--;
																						goto end_IL_0308;
																						IL_0534:
																						if (1 < b)
																						{
																							goto end_IL_02d8;
																						}
																						goto IL_0542;
																						IL_0542:
																						if (1 > b)
																						{
																							goto end_IL_02d8;
																						}
																						goto IL_0550;
																						IL_0550:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0569;
																						IL_0569:
																						array[num5] = 0;
																						goto IL_0577;
																						IL_0577:
																						num5++;
																						goto IL_0585;
																						IL_0585:
																						ptr2 += 8;
																						goto end_IL_0308;
																						IL_0598:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						num = 99;
																						goto IL_05bf;
																						IL_05bf:
																						ptr2 += 8;
																						goto IL_05cd;
																					}
																					break;
																				}
																				goto IL_05e0;
																				IL_05e0:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 92;
																				goto end_IL_0308;
																			}
																			goto IL_06e9;
																			IL_0878:
																			if (15 < b)
																			{
																				goto end_IL_02d8;
																			}
																			goto IL_0883;
																			IL_0601:
																			if (12 >= b)
																			{
																				goto IL_060f;
																			}
																			goto IL_07b5;
																			IL_060f:
																			if (12 > b)
																			{
																				goto IL_061d;
																			}
																			goto IL_074e;
																			IL_061d:
																			if (10 < b)
																			{
																				goto IL_062b;
																			}
																			goto IL_06bd;
																			IL_062b:
																			if (11 < b)
																			{
																				goto end_IL_02d8;
																			}
																			goto IL_0639;
																			IL_0639:
																			if (11 > b)
																			{
																				num = 106;
																				goto end_IL_02d8;
																			}
																			goto IL_0652;
																			IL_0883:
																			if (15 <= b)
																			{
																			}
																			goto end_IL_02d8;
																			IL_0652:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0696;
																			IL_0696:
																			array[num5 - 2] = 0;
																			goto IL_06aa;
																			IL_06aa:
																			num5--;
																			goto end_IL_0308;
																			IL_06bd:
																			if (10 > b)
																			{
																				goto IL_06c8;
																			}
																			goto IL_06e9;
																			IL_06c8:
																			if (9 < b)
																			{
																				goto end_IL_02d8;
																			}
																			goto IL_06d6;
																			IL_06d6:
																			if (9 <= b)
																			{
																				goto end_IL_0308;
																			}
																			goto end_IL_02d8;
																			IL_06e9:
																			array[num5] = 0;
																			goto IL_06f7;
																			IL_06f7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_071a;
																			IL_071a:
																			array2[num5] = null;
																			goto IL_0724;
																			IL_0724:
																			num5++;
																			num = 140;
																			goto IL_073b;
																			IL_073b:
																			ptr2 += 8;
																			goto end_IL_0308;
																			IL_074e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_078e;
																			IL_078e:
																			array[num5 - 2] = 0;
																			goto IL_07a2;
																			IL_07a2:
																			num5--;
																			goto end_IL_0308;
																			IL_07b5:
																			if (14 >= b)
																			{
																				goto IL_07c3;
																			}
																			goto IL_0878;
																			IL_07c3:
																			if (14 > b)
																			{
																				goto IL_07d1;
																			}
																			goto IL_085f;
																			IL_07d1:
																			if (13 < b)
																			{
																				goto end_IL_02d8;
																			}
																			goto IL_07df;
																			IL_07df:
																			if (13 > b)
																			{
																				goto end_IL_02d8;
																			}
																			goto IL_07ed;
																			IL_07ed:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_084f;
																			IL_084f:
																			num5 -= 2;
																			goto end_IL_0308;
																			IL_085f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0308;
																			continue;
																			end_IL_02c8:
																			break;
																		}
																		continue;
																		end_IL_02d8:
																		break;
																	}
																}
																else
																{
																	num = 7;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0308;
																continue;
																end_IL_02e8:
																break;
															}
															continue;
															end_IL_02f8:
															break;
														}
														continue;
														end_IL_0308:
														break;
													}
													continue;
												}
												goto IL_0948;
												IL_0948:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08ac:
												break;
											}
											continue;
											end_IL_08bf:
											break;
										}
										continue;
										end_IL_08c9:
										break;
									}
									continue;
									end_IL_08d4:
									break;
								}
								continue;
								end_IL_08e4:
								break;
							}
							continue;
							end_IL_08f4:
							break;
						}
						continue;
						end_IL_090d:
						break;
					}
					continue;
					end_IL_091d:
					break;
				}
				continue;
				end_IL_092d:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									num = 8;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setMonthNamesValueClassMarshaler.NextDoubleCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGPREREQUISITE);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 46;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 85;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02d5:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02b5:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_02a8:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0298:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0288:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_0258:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_022a:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															num = 130;
																															while (true)
																															{
																																if (num != 130)
																																{
																																	if (num != 1111)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 29:
																																		goto IL_022a;
																																	case 7:
																																	case 92:
																																		goto IL_0258;
																																	case 118:
																																		goto IL_0268;
																																	case 122:
																																		goto IL_0278;
																																	case 30:
																																	case 60:
																																		goto IL_0288;
																																	case 13:
																																	case 111:
																																		goto IL_0298;
																																	case 88:
																																		goto IL_02a8;
																																	case 69:
																																		goto IL_02b5;
																																	case 86:
																																		goto IL_02c5;
																																	case 120:
																																		goto IL_02d5;
																																	case 21:
																																		goto end_IL_02d5;
																																	case 85:
																																		goto end_IL_02e5;
																																	case 103:
																																		goto end_IL_02f5;
																																	case 48:
																																	case 95:
																																		goto IL_030b;
																																	case 45:
																																		goto IL_034b;
																																	case 17:
																																		goto IL_035f;
																																	case 114:
																																		goto IL_0372;
																																	case 79:
																																		goto IL_038f;
																																	case 25:
																																		goto IL_039d;
																																	case 76:
																																		goto IL_03b9;
																																	case 57:
																																	case 61:
																																		goto IL_03c7;
																																	case 5:
																																	case 93:
																																		goto IL_03d2;
																																	case 81:
																																		goto IL_03e0;
																																	case 6:
																																	case 121:
																																		goto end_IL_0217;
																																	case 34:
																																		goto IL_0420;
																																	case 22:
																																		goto IL_0437;
																																	case 63:
																																		goto IL_044a;
																																	case 35:
																																	case 91:
																																		goto IL_0455;
																																	case 73:
																																		goto IL_046e;
																																	case 108:
																																		goto IL_047c;
																																	case 64:
																																		goto IL_048a;
																																	case 11:
																																	case 51:
																																		goto IL_04ab;
																																	case 71:
																																		goto IL_04c3;
																																	case 31:
																																		goto IL_04d1;
																																	case 62:
																																	case 82:
																																		goto IL_04dc;
																																	case 84:
																																		goto IL_04ea;
																																	case 72:
																																		goto IL_050e;
																																	case 55:
																																		goto IL_051c;
																																	case 3:
																																		goto IL_052f;
																																	case 74:
																																	case 77:
																																		goto IL_053d;
																																	case 33:
																																		goto IL_054b;
																																	case 16:
																																	case 67:
																																		goto IL_0559;
																																	case 56:
																																		goto IL_05bb;
																																	case 44:
																																		goto IL_05ce;
																																	case 24:
																																	case 43:
																																		goto IL_05e5;
																																	case 116:
																																		goto IL_0608;
																																	case 100:
																																		goto IL_0616;
																																	case 2:
																																		goto IL_062d;
																																	case 123:
																																		goto IL_0640;
																																	case 15:
																																		goto IL_064b;
																																	case 23:
																																		goto IL_0656;
																																	case 109:
																																		goto IL_066c;
																																	case 68:
																																	case 97:
																																		goto IL_0677;
																																	case 70:
																																		goto IL_0682;
																																	case 28:
																																	case 96:
																																		goto IL_068d;
																																	case 101:
																																	case 112:
																																		goto IL_06a8;
																																	case 1:
																																	case 4:
																																	case 10:
																																	case 14:
																																	case 26:
																																	case 27:
																																	case 36:
																																	case 38:
																																	case 47:
																																	case 49:
																																	case 52:
																																	case 65:
																																	case 75:
																																	case 78:
																																	case 83:
																																	case 87:
																																	case 94:
																																	case 98:
																																	case 102:
																																	case 104:
																																	case 105:
																																	case 115:
																																	case 117:
																																	case 119:
																																		goto end_IL_0268;
																																	case 0:
																																	case 9:
																																	case 12:
																																	case 19:
																																	case 20:
																																	case 32:
																																	case 39:
																																	case 46:
																																	case 54:
																																	case 80:
																																	case 89:
																																	case 99:
																																	case 107:
																																	case 110:
																																	case 113:
																																		goto end_IL_0300;
																																	case 66:
																																		goto end_IL_06d4;
																																	case 8:
																																		goto end_IL_06e7;
																																	case 106:
																																		goto end_IL_06fa;
																																	case 53:
																																		goto end_IL_0705;
																																	case 18:
																																	case 50:
																																		goto end_IL_0723;
																																	case 58:
																																		goto end_IL_0733;
																																	case 37:
																																	case 40:
																																		goto end_IL_0743;
																																	case 41:
																																		goto end_IL_0753;
																																	case 42:
																																		goto end_IL_0763;
																																	case 59:
																																	case 90:
																																		goto IL_077e;
																																	}
																																	continue;
																																}
																																array2[num5] = null;
																																goto IL_038f;
																																IL_038f:
																																num5++;
																																goto IL_039d;
																																IL_039d:
																																ptr2 += 8;
																																num = 12;
																																goto end_IL_0300;
																																continue;
																																end_IL_0217:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_03ee;
																													continue;
																													end_IL_0268:
																													break;
																													IL_0268:;
																												}
																												break;
																												IL_0278:;
																											}
																											break;
																										}
																										goto IL_0372;
																										IL_0372:
																										if (4 > b)
																										{
																											break;
																										}
																										goto end_IL_0300;
																									}
																									break;
																								}
																								goto IL_03b9;
																								IL_04ab:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0300;
																								IL_03b9:
																								if (3 > b)
																								{
																									goto IL_03c7;
																								}
																								goto IL_04ab;
																								IL_03c7:
																								if (1 < b)
																								{
																									goto IL_03d2;
																								}
																								goto IL_044a;
																								IL_03d2:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_03e0;
																								IL_03e0:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_03ee;
																								IL_03ee:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 34;
																								goto IL_0420;
																								IL_0420:
																								ptr2 += 8;
																								num = 22;
																								goto IL_0437;
																								IL_0437:
																								num5--;
																								goto end_IL_0300;
																								IL_044a:
																								if (1 > b)
																								{
																									num = 65;
																									break;
																								}
																								goto IL_0455;
																								IL_0455:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_046e;
																								IL_046e:
																								array[num5] = 0;
																								goto IL_047c;
																								IL_047c:
																								num5++;
																								goto IL_048a;
																								IL_048a:
																								ptr2 += 8;
																								goto end_IL_0300;
																							}
																							break;
																						}
																						goto IL_030b;
																						IL_035f:
																						num5--;
																						goto end_IL_0300;
																						IL_030b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_034b;
																						IL_034b:
																						array[num5 - 2] = 0;
																						goto IL_035f;
																					}
																					break;
																				}
																				goto IL_04c3;
																				IL_0682:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_068d;
																				IL_04c3:
																				if (9 >= b)
																				{
																					goto IL_04d1;
																				}
																				goto IL_0640;
																				IL_04d1:
																				if (9 <= b)
																				{
																					goto IL_04dc;
																				}
																				goto IL_052f;
																				IL_04dc:
																				array[num5] = 0;
																				goto IL_04ea;
																				IL_04ea:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)GetEnumNamescallback[*(int*)(ptr2 + num3)])();
																				goto IL_050e;
																				IL_050e:
																				num5++;
																				goto IL_051c;
																				IL_051c:
																				ptr2 += 8;
																				goto end_IL_0300;
																				IL_052f:
																				if (7 < b)
																				{
																					goto IL_053d;
																				}
																				goto IL_05ce;
																				IL_053d:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_054b;
																				IL_054b:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0559;
																				IL_0559:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05bb;
																				IL_05bb:
																				num5 -= 2;
																				goto end_IL_0300;
																				IL_05ce:
																				if (7 > b)
																				{
																					break;
																				}
																				num = 24;
																				goto IL_05e5;
																				IL_068d:
																				num5--;
																				goto end_IL_0300;
																				IL_05e5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0608;
																				IL_0608:
																				array[num5] = 0;
																				goto IL_0616;
																				IL_0616:
																				num5++;
																				num = 2;
																				goto IL_062d;
																				IL_062d:
																				ptr2 += 8;
																				goto end_IL_0300;
																				IL_0640:
																				if (11 < b)
																				{
																					goto IL_064b;
																				}
																				num = 109;
																				goto IL_066c;
																				IL_064b:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_0656;
																				IL_0656:
																				if (12 > b)
																				{
																				}
																				break;
																				IL_06a8:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0300;
																				IL_066c:
																				if (11 > b)
																				{
																					goto IL_0677;
																				}
																				goto IL_06a8;
																				IL_0677:
																				if (10 < b)
																				{
																					num = 117;
																					break;
																				}
																				goto IL_0682;
																			}
																			break;
																			IL_02c5:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0300;
																	continue;
																	end_IL_02d5:
																	break;
																}
																continue;
																end_IL_02e5:
																break;
															}
															continue;
															end_IL_02f5:
															break;
														}
														continue;
														end_IL_0300:
														break;
													}
													continue;
												}
												goto IL_077e;
												IL_077e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06d4:
												break;
											}
											continue;
											end_IL_06e7:
											break;
										}
										continue;
										end_IL_06fa:
										break;
									}
									continue;
									end_IL_0705:
									break;
								}
								continue;
								end_IL_0723:
								break;
							}
							continue;
							end_IL_0733:
							break;
						}
						continue;
						end_IL_0743:
						break;
					}
					continue;
					end_IL_0753:
					break;
				}
				continue;
				end_IL_0763:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 7;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 103;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComposedOfAllVirtualMethodsGetBaseException.getStreamingContextKeyContainerName);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 31;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0210:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_01f0:
																				if (5 < b)
																				{
																					num = 112;
																					while (true)
																					{
																						if (num != 112)
																						{
																							if (num != 1093)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 80:
																								goto IL_01f0;
																							case 57:
																								goto IL_0200;
																							case 59:
																								goto IL_0210;
																							case 45:
																								goto end_IL_0210;
																							case 33:
																							case 70:
																								goto end_IL_0220;
																							case 29:
																								goto IL_023b;
																							case 35:
																								goto IL_0249;
																							case 67:
																								goto IL_0257;
																							case 0:
																							case 50:
																								goto IL_0265;
																							case 8:
																								goto IL_02d3;
																							case 86:
																							case 87:
																								goto IL_02e6;
																							case 63:
																								goto IL_02f1;
																							case 75:
																							case 79:
																								goto IL_02ff;
																							case 58:
																								goto IL_033f;
																							case 9:
																								goto IL_0355;
																							case 65:
																								goto IL_0363;
																							case 69:
																							case 72:
																								goto IL_0371;
																							case 48:
																								goto IL_039a;
																							case 17:
																								goto IL_03a8;
																							case 91:
																								goto IL_03bb;
																							case 53:
																							case 96:
																								goto IL_03ce;
																							case 73:
																							case 105:
																								goto IL_03e6;
																							case 10:
																								goto IL_03fd;
																							case 95:
																								goto IL_0410;
																							case 55:
																								goto IL_041e;
																							case 54:
																							case 68:
																								goto IL_042c;
																							case 12:
																								goto IL_0437;
																							case 89:
																							case 101:
																								goto IL_044a;
																							case 1:
																								goto IL_0458;
																							case 28:
																							case 64:
																								goto IL_0466;
																							case 43:
																								goto IL_0474;
																							case 18:
																								goto IL_0497;
																							case 49:
																								goto IL_04a1;
																							case 62:
																								goto IL_04af;
																							case 21:
																							case 60:
																								goto IL_04c2;
																							case 104:
																								goto IL_04d0;
																							case 88:
																								goto IL_04f4;
																							case 90:
																								goto IL_0502;
																							case 20:
																								goto IL_0515;
																							case 97:
																								goto IL_0520;
																							case 4:
																							case 15:
																								goto IL_052b;
																							case 93:
																								goto IL_053b;
																							case 2:
																								goto IL_0546;
																							case 13:
																							case 92:
																								goto IL_0551;
																							case 5:
																							case 14:
																							case 22:
																							case 25:
																							case 32:
																							case 41:
																							case 46:
																							case 47:
																							case 52:
																							case 61:
																							case 66:
																							case 74:
																							case 76:
																							case 77:
																							case 81:
																							case 82:
																							case 83:
																							case 84:
																							case 85:
																								goto end_IL_01dd;
																							case 102:
																								goto IL_058d;
																							case 36:
																								goto IL_059b;
																							case 24:
																								goto IL_05a9;
																							case 16:
																							case 19:
																							case 23:
																							case 26:
																							case 27:
																							case 30:
																							case 31:
																							case 34:
																							case 39:
																							case 40:
																							case 98:
																							case 99:
																							case 100:
																								goto end_IL_0230;
																							case 37:
																								goto end_IL_05b7;
																							case 71:
																								goto end_IL_05ca;
																							case 78:
																								goto end_IL_05dd;
																							case 11:
																								goto end_IL_05e8;
																							case 103:
																								goto end_IL_05fd;
																							case 38:
																							case 94:
																								goto end_IL_0612;
																							case 44:
																								goto end_IL_0622;
																							case 3:
																							case 42:
																								goto end_IL_063b;
																							case 6:
																								goto end_IL_064b;
																							case 7:
																								goto end_IL_065b;
																							case 51:
																							case 56:
																								goto IL_0676;
																							}
																							continue;
																						}
																						goto IL_0410;
																						IL_0546:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0551;
																						IL_0551:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						goto end_IL_0230;
																						IL_0410:
																						if (8 >= b)
																						{
																							goto IL_041e;
																						}
																						goto IL_0515;
																						IL_041e:
																						if (8 > b)
																						{
																							goto IL_042c;
																						}
																						goto IL_04c2;
																						IL_042c:
																						if (6 >= b)
																						{
																							goto IL_0437;
																						}
																						goto IL_044a;
																						IL_0437:
																						if (6 <= b)
																						{
																							goto end_IL_0230;
																						}
																						break;
																						IL_044a:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0458;
																						IL_0458:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0466;
																						IL_0466:
																						array[num6] = 0;
																						goto IL_0474;
																						IL_0474:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0497;
																						IL_0497:
																						array2[num6] = null;
																						goto IL_04a1;
																						IL_04a1:
																						num6++;
																						goto IL_04af;
																						IL_04af:
																						ptr2 += 8;
																						goto end_IL_0230;
																						IL_04c2:
																						array[num6] = 0;
																						goto IL_04d0;
																						IL_04d0:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getIsThreadOwnerTrackingEnabledVTEMPTY[*(int*)(ptr2 + num3)])();
																						goto IL_04f4;
																						IL_04f4:
																						num6++;
																						goto IL_0502;
																						IL_0502:
																						ptr2 += 8;
																						goto end_IL_0230;
																						IL_0515:
																						if (9 >= b)
																						{
																							goto IL_0520;
																						}
																						goto IL_053b;
																						IL_0520:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_052b;
																						IL_052b:
																						num6--;
																						goto end_IL_0230;
																						IL_053b:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0546;
																						continue;
																						end_IL_01dd:
																						break;
																					}
																					break;
																				}
																				goto IL_023b;
																				IL_039a:
																				ptr2 += 8;
																				goto IL_03a8;
																				IL_03a8:
																				num6--;
																				goto end_IL_0230;
																				IL_023b:
																				if (5 > b)
																				{
																					goto IL_0249;
																				}
																				goto IL_03ce;
																				IL_0249:
																				if (2 >= b)
																				{
																					goto IL_0257;
																				}
																				goto IL_02e6;
																				IL_0257:
																				if (2 <= b)
																				{
																					goto IL_0265;
																				}
																				goto IL_03e6;
																				IL_0265:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_02d3;
																				IL_02d3:
																				num6 -= 2;
																				goto end_IL_0230;
																				IL_03e6:
																				if (1 < b)
																				{
																					break;
																				}
																				num = 10;
																				goto IL_03fd;
																				IL_03ce:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0230;
																				IL_03fd:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_02e6:
																				if (3 >= b)
																				{
																					goto IL_02f1;
																				}
																				goto IL_0355;
																				IL_02f1:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_02ff;
																				IL_02ff:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_033f;
																				IL_033f:
																				array[num6 - 2] = 0;
																				goto IL_03bb;
																				IL_03bb:
																				num6--;
																				goto end_IL_0230;
																				IL_0355:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0363;
																				IL_0363:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0371;
																				IL_0371:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_039a;
																			}
																			break;
																			IL_0200:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_058d;
																	IL_05a9:
																	ptr2 += 8;
																	goto end_IL_0230;
																	IL_059b:
																	num6++;
																	goto IL_05a9;
																	IL_058d:
																	array[num6] = 0;
																	goto IL_059b;
																	continue;
																	end_IL_0210:
																	break;
																}
																continue;
																end_IL_0220:
																break;
															}
															continue;
															end_IL_0230:
															break;
														}
														continue;
													}
													goto IL_0676;
													IL_0676:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_05b7:
													break;
												}
												continue;
												end_IL_05ca:
												break;
											}
											continue;
											end_IL_05dd:
											break;
										}
										continue;
										end_IL_05e8:
										break;
									}
									continue;
									end_IL_05fd:
									break;
								}
								continue;
								end_IL_0612:
								break;
							}
							continue;
							end_IL_0622:
							break;
						}
						continue;
						end_IL_063b:
						break;
					}
					continue;
					end_IL_064b:
					break;
				}
				continue;
				end_IL_065b:
				break;
			}
		}
	}

	private static int smethod_5(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		num += num2;
		int num3 = num;
		num = int_1;
		num2 = int_2;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 360;
		num2 = 90;
		return num + 90;
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 88;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 31;
					while (true)
					{
						object[] array2 = new object[3];
						num = 69;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getOSXGetObjRefForProxy.ByteEqualityComparerFoundYMDPatternFlag);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02c2:
															byte b = *ptr2;
															while (true)
															{
																IL_02b2:
																ptr2++;
																while (true)
																{
																	IL_02a2:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			num = 13;
																			while (true)
																			{
																				IL_0282:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0272:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_0262:
																								if (10 < b)
																								{
																									while (11 >= b)
																									{
																										while (11 <= b)
																										{
																											while (true)
																											{
																												IL_0220:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												num = 124;
																												while (num != 124)
																												{
																													if (num != 1105)
																													{
																														goto end_IL_0242;
																													}
																													switch (num)
																													{
																													case 15:
																													case 94:
																														goto IL_0220;
																													case 89:
																														goto IL_0242;
																													case 16:
																													case 93:
																														goto IL_0252;
																													case 100:
																														goto IL_0262;
																													case 17:
																														goto IL_0272;
																													case 13:
																														goto IL_0282;
																													case 56:
																														goto IL_028f;
																													case 1:
																														goto IL_02a2;
																													case 53:
																														goto IL_02b2;
																													case 34:
																													case 49:
																														goto IL_02c2;
																													case 20:
																														goto IL_02d6;
																													case 5:
																														goto IL_02e4;
																													case 7:
																														goto IL_02ef;
																													case 10:
																														goto IL_02fa;
																													case 62:
																														goto IL_030d;
																													case 24:
																													case 32:
																														goto IL_031b;
																													case 6:
																														goto IL_0344;
																													case 38:
																														goto IL_035b;
																													case 70:
																														goto IL_036e;
																													case 3:
																														goto IL_037c;
																													case 25:
																													case 45:
																														goto IL_038a;
																													case 28:
																													case 73:
																														goto IL_039a;
																													case 82:
																														goto IL_03df;
																													case 84:
																														goto IL_0402;
																													case 96:
																														goto IL_0415;
																													case 57:
																														goto IL_042c;
																													case 14:
																													case 109:
																														goto IL_0448;
																													case 50:
																														goto IL_0488;
																													case 36:
																														goto IL_049c;
																													case 110:
																														goto IL_04af;
																													case 26:
																														goto IL_04c3;
																													case 114:
																														goto IL_04df;
																													case 108:
																														goto IL_04ea;
																													case 37:
																														goto IL_04fd;
																													case 99:
																														goto IL_050b;
																													case 18:
																													case 80:
																														goto IL_0519;
																													case 76:
																														goto IL_0562;
																													case 68:
																														goto IL_0576;
																													case 117:
																														goto IL_0589;
																													case 39:
																													case 91:
																														goto IL_0594;
																													case 95:
																														goto IL_05a2;
																													case 27:
																														goto IL_05c6;
																													case 43:
																														goto IL_05d4;
																													case 85:
																														goto IL_05e7;
																													case 111:
																														goto IL_05f2;
																													case 12:
																													case 101:
																														goto IL_0600;
																													case 33:
																														goto IL_0622;
																													case 77:
																														goto IL_0630;
																													case 60:
																														goto IL_063e;
																													case 30:
																													case 55:
																														goto IL_0663;
																													case 8:
																														goto IL_0671;
																													case 21:
																													case 103:
																														goto IL_0687;
																													case 107:
																														goto IL_06c7;
																													case 9:
																														goto IL_06db;
																													case 72:
																														goto IL_06eb;
																													case 2:
																													case 44:
																														goto IL_06f6;
																													case 23:
																													case 29:
																													case 35:
																													case 42:
																													case 46:
																													case 48:
																													case 51:
																													case 64:
																													case 66:
																													case 67:
																													case 75:
																													case 81:
																													case 83:
																													case 86:
																													case 92:
																													case 97:
																													case 104:
																													case 105:
																													case 113:
																													case 116:
																														goto end_IL_0242;
																													case 79:
																														goto IL_0729;
																													case 71:
																														goto IL_0737;
																													case 11:
																														goto IL_0745;
																													case 40:
																													case 41:
																													case 47:
																													case 54:
																													case 58:
																													case 63:
																													case 65:
																													case 74:
																													case 90:
																													case 98:
																													case 102:
																													case 115:
																														goto end_IL_020d;
																													case 106:
																														goto end_IL_0753;
																													case 59:
																														goto end_IL_0766;
																													case 61:
																														goto end_IL_0770;
																													case 4:
																														goto end_IL_077b;
																													case 112:
																														goto end_IL_0790;
																													case 0:
																													case 69:
																														goto end_IL_07a5;
																													case 31:
																														goto end_IL_07b5;
																													case 19:
																													case 22:
																														goto end_IL_07c5;
																													case 87:
																														goto end_IL_07de;
																													case 88:
																														goto end_IL_07f7;
																													case 52:
																													case 78:
																														goto IL_0812;
																													}
																													continue;
																													end_IL_020d:
																													break;
																												}
																												break;
																											}
																											goto end_IL_02a2;
																											continue;
																											end_IL_0242:
																											break;
																											IL_0242:;
																										}
																										break;
																										IL_0252:;
																									}
																									break;
																								}
																								goto IL_06eb;
																								IL_06f6:
																								num6--;
																								goto end_IL_02a2;
																								IL_06eb:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_06f6;
																							}
																							break;
																						}
																						goto IL_0589;
																						IL_0687:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_06c7;
																						IL_0589:
																						if (9 <= b)
																						{
																							goto IL_0594;
																						}
																						goto IL_05e7;
																						IL_0594:
																						array[num6] = 0;
																						goto IL_05a2;
																						IL_05a2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)AsyncStateMachineAttributeNULLPUBLICKEY[*(int*)(ptr2 + num3)])();
																						goto IL_05c6;
																						IL_05c6:
																						num6++;
																						goto IL_05d4;
																						IL_05d4:
																						ptr2 += 8;
																						goto end_IL_02a2;
																						IL_05e7:
																						if (7 >= b)
																						{
																							goto IL_05f2;
																						}
																						num = 55;
																						goto IL_0663;
																						IL_05f2:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0600;
																						IL_0600:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						num = 33;
																						goto IL_0622;
																						IL_0622:
																						array[num6] = 0;
																						goto IL_0630;
																						IL_0630:
																						num6++;
																						goto IL_063e;
																						IL_063e:
																						ptr2 += 8;
																						num = 40;
																						goto end_IL_02a2;
																						IL_06c7:
																						array[num6 - 2] = 0;
																						goto IL_06db;
																						IL_0663:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_0671;
																						IL_0671:
																						if (8 > b)
																						{
																							num = 42;
																							break;
																						}
																						goto IL_0687;
																						IL_06db:
																						num6--;
																						goto end_IL_02a2;
																					}
																					break;
																				}
																				num = 20;
																				goto IL_02d6;
																				IL_0488:
																				array[num6 - 2] = 0;
																				goto IL_049c;
																				IL_049c:
																				num6--;
																				goto end_IL_02a2;
																				IL_02d6:
																				if (6 > b)
																				{
																					goto IL_02e4;
																				}
																				goto IL_0448;
																				IL_02e4:
																				if (3 < b)
																				{
																					goto IL_02ef;
																				}
																				goto IL_030d;
																				IL_02ef:
																				if (4 >= b)
																				{
																					goto IL_02fa;
																				}
																				goto IL_036e;
																				IL_02fa:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_039a;
																				IL_039a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04af;
																				IL_04af:
																				array[num6 - 2] = 0;
																				goto IL_04c3;
																				IL_04c3:
																				num6--;
																				num = 65;
																				goto end_IL_02a2;
																				IL_036e:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_037c;
																				IL_037c:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_038a;
																				IL_038a:
																				array[num6] = 0;
																				goto IL_03df;
																				IL_03df:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0402;
																				IL_0402:
																				array2[num6] = null;
																				num = 96;
																				goto IL_0415;
																				IL_0415:
																				num6++;
																				num = 57;
																				goto IL_042c;
																				IL_042c:
																				ptr2 += 8;
																				num = 102;
																				goto end_IL_02a2;
																				IL_030d:
																				if (3 <= b)
																				{
																					goto IL_031b;
																				}
																				goto IL_04df;
																				IL_031b:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0344;
																				IL_0344:
																				ptr2 += 8;
																				num = 38;
																				goto IL_035b;
																				IL_035b:
																				num6--;
																				goto end_IL_02a2;
																				IL_04df:
																				if (1 >= b)
																				{
																					goto IL_04ea;
																				}
																				goto IL_04fd;
																				IL_04ea:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_04fd:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_050b;
																				IL_050b:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0519;
																				IL_0519:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 76;
																				goto IL_0562;
																				IL_0562:
																				array[num6 - 2] = 0;
																				goto IL_0576;
																				IL_0576:
																				num6--;
																				goto end_IL_02a2;
																				IL_0448:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0488;
																			}
																			break;
																			IL_028f:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0729;
																	IL_0745:
																	ptr2 += 8;
																	break;
																	IL_0737:
																	num6++;
																	goto IL_0745;
																	IL_0729:
																	array[num6] = 0;
																	goto IL_0737;
																	continue;
																	end_IL_02a2:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0812;
													IL_0812:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0753:
													break;
												}
												continue;
												end_IL_0766:
												break;
											}
											continue;
											end_IL_0770:
											break;
										}
										continue;
										end_IL_077b:
										break;
									}
									continue;
									end_IL_0790:
									break;
								}
								continue;
								end_IL_07a5:
								break;
							}
							continue;
							end_IL_07b5:
							break;
						}
						continue;
						end_IL_07c5:
						break;
					}
					continue;
					end_IL_07de:
					break;
				}
				continue;
				end_IL_07f7:
				break;
			}
		}
	}

	private static int smethod_7()
	{
		int num = 15;
		int num2 = 5;
		num = 3;
		object obj = new int[3];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 64;
		num3 = 32;
		((int[])obj)[0] = 32;
		obj = obj2;
		num2 = 1;
		num3 = 81;
		num3 = 27;
		((int[])obj)[1] = 27;
		obj = obj2;
		num2 = 4;
		num3 = 2;
		num2 = 2;
		num3 = 15;
		num3 = 3;
		((int[])obj)[2] = 3;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 39;
			num3 = 13;
			num2 = 3;
			if (num >= 3)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	static Class165()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 13;
			while (true)
			{
				if (num != 13)
				{
					if (num == 994)
					{
						switch (num)
						{
						default:
							continue;
						case 3:
							break;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 4:
							return;
						case 5:
							return;
						case 6:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				return;
			}
		}
	}
}
