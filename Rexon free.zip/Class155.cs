using System;
using System.Runtime.CompilerServices;
using HarmonyLib;

[HarmonyPatch(typeof(SlingshotProjectile), "CheckForAOEKnockback")]
internal class Class155
{
	private static float float_0;

	private static double double_0;

	private static bool bool_0;

	private static int int_0;

	private static bool bool_1;

	private static float float_1;

	private static IntPtr[] CancellationPendingNOTIFTYPECONVERTED;

	private unsafe static bool Prefix()
	{
		int num = 112;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetResourceSetOperatingSystem.UCOMIPersistFilegetIsDynamic);
									num = 83;
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 != 1)
											{
												while (true)
												{
													IL_0380:
													byte b = *ptr2;
													while (true)
													{
														IL_0370:
														ptr2++;
														while (true)
														{
															IL_0360:
															if (b >= 1)
															{
																while (b <= 14)
																{
																	while (true)
																	{
																		IL_0340:
																		if (7 < b)
																		{
																			while (true)
																			{
																				IL_0333:
																				if (11 >= b)
																				{
																					while (11 > b)
																					{
																						while (true)
																						{
																							IL_0313:
																							if (9 < b)
																							{
																								while (10 >= b)
																								{
																									while (10 <= b)
																									{
																										while (true)
																										{
																											IL_028f:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											while (true)
																											{
																												IL_0276:
																												num5 -= 2;
																												num = 149;
																												while (num != 149)
																												{
																													if (num != 1130)
																													{
																														goto IL_05cf;
																													}
																													switch (num)
																													{
																													case 72:
																														goto IL_0276;
																													case 6:
																													case 79:
																														goto IL_028f;
																													case 96:
																														goto IL_02f3;
																													case 23:
																														goto IL_0303;
																													case 28:
																													case 78:
																														goto IL_0313;
																													case 104:
																														goto IL_0323;
																													case 11:
																													case 40:
																														goto IL_0333;
																													case 38:
																														goto IL_0340;
																													case 54:
																														goto IL_0350;
																													case 15:
																														goto IL_0360;
																													case 137:
																														goto IL_0370;
																													case 19:
																													case 48:
																														goto IL_0380;
																													case 77:
																													case 92:
																														goto IL_038b;
																													case 138:
																														goto IL_0399;
																													case 80:
																													case 118:
																														goto IL_03a4;
																													case 107:
																														goto IL_03b2;
																													case 26:
																													case 33:
																														goto IL_03c0;
																													case 82:
																														goto IL_03ed;
																													case 123:
																														goto IL_03fb;
																													case 95:
																														goto IL_0409;
																													case 18:
																													case 114:
																														goto IL_041c;
																													case 87:
																														goto IL_045d;
																													case 51:
																														goto IL_0471;
																													case 139:
																														goto IL_0484;
																													case 50:
																													case 134:
																														goto IL_048f;
																													case 16:
																														goto IL_049d;
																													case 10:
																													case 55:
																														goto IL_04ab;
																													case 67:
																													case 129:
																														goto IL_04be;
																													case 4:
																														goto IL_04fe;
																													case 131:
																														goto IL_0512;
																													case 39:
																													case 140:
																														goto IL_0525;
																													case 25:
																														goto IL_0533;
																													case 42:
																													case 97:
																														goto IL_0541;
																													case 108:
																														goto IL_055d;
																													case 73:
																													case 117:
																														goto IL_0568;
																													case 115:
																														goto IL_05a8;
																													case 12:
																														goto IL_05bc;
																													case 86:
																														goto IL_05cf;
																													case 63:
																														goto IL_05dd;
																													case 60:
																														goto IL_05eb;
																													case 98:
																													case 113:
																														goto IL_05f9;
																													case 101:
																														goto IL_0607;
																													case 9:
																													case 94:
																														goto IL_0612;
																													case 8:
																														goto IL_0652;
																													case 30:
																														goto IL_0666;
																													case 126:
																														goto IL_0687;
																													case 35:
																													case 93:
																														goto IL_069a;
																													case 20:
																														goto IL_06c3;
																													case 124:
																														goto IL_06d1;
																													case 99:
																													case 109:
																														goto IL_06ed;
																													case 66:
																													case 88:
																														goto IL_06fb;
																													case 81:
																														goto IL_0709;
																													case 119:
																													case 135:
																														goto IL_0717;
																													case 58:
																														goto IL_0757;
																													case 2:
																														goto IL_076b;
																													case 74:
																														goto IL_077e;
																													case 7:
																														goto IL_078c;
																													case 128:
																														goto IL_079a;
																													case 37:
																													case 103:
																														goto IL_07a8;
																													case 53:
																														goto IL_07b6;
																													case 44:
																														goto IL_07d9;
																													case 52:
																														goto IL_07ec;
																													case 127:
																														goto IL_07fa;
																													case 21:
																													case 130:
																														goto IL_080d;
																													case 141:
																														goto IL_084d;
																													case 49:
																														goto IL_0861;
																													case 0:
																													case 5:
																													case 14:
																													case 17:
																													case 22:
																													case 24:
																													case 34:
																													case 45:
																													case 56:
																													case 59:
																													case 61:
																													case 62:
																													case 68:
																													case 76:
																													case 84:
																													case 89:
																													case 90:
																													case 102:
																													case 120:
																													case 121:
																													case 122:
																													case 125:
																													case 133:
																													case 136:
																														goto end_IL_02f3;
																													case 105:
																														goto IL_088a;
																													case 65:
																														goto IL_0898;
																													case 106:
																														goto IL_08a6;
																													case 1:
																													case 27:
																													case 29:
																													case 31:
																													case 32:
																													case 43:
																													case 46:
																													case 47:
																													case 57:
																													case 64:
																													case 69:
																													case 70:
																													case 71:
																													case 85:
																													case 91:
																													case 142:
																														goto end_IL_0263;
																													case 83:
																														goto end_IL_08b4;
																													case 100:
																														goto end_IL_08c4;
																													case 116:
																														goto end_IL_08ce;
																													case 36:
																													case 110:
																														goto end_IL_08e2;
																													case 75:
																														goto end_IL_08f2;
																													case 3:
																													case 41:
																														goto end_IL_0902;
																													case 111:
																														goto end_IL_0912;
																													case 112:
																														goto end_IL_0922;
																													case 13:
																													case 132:
																														goto IL_093d;
																													}
																													continue;
																													end_IL_0263:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto end_IL_0323;
																										continue;
																										end_IL_02f3:
																										break;
																										IL_02f3:;
																									}
																									break;
																									IL_0303:;
																								}
																								break;
																							}
																							goto IL_0484;
																							IL_0512:
																							num5--;
																							goto end_IL_0323;
																							IL_0484:
																							if (9 > b)
																							{
																								goto IL_048f;
																							}
																							goto IL_04be;
																							IL_048f:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_049d;
																							IL_049d:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_04ab;
																							IL_04ab:
																							num5--;
																							goto end_IL_0323;
																							IL_04be:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04fe;
																							IL_04fe:
																							array[num5 - 2] = 0;
																							goto IL_0512;
																						}
																						goto end_IL_0350;
																						continue;
																						end_IL_0323:
																						break;
																						IL_0323:;
																					}
																					break;
																				}
																				goto IL_038b;
																				IL_0541:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_038b:
																				if (13 >= b)
																				{
																					goto IL_0399;
																				}
																				goto IL_0525;
																				IL_0399:
																				if (13 > b)
																				{
																					goto IL_03a4;
																				}
																				goto IL_041c;
																				IL_03a4:
																				if (12 < b)
																				{
																					goto end_IL_0350;
																				}
																				goto IL_03b2;
																				IL_03b2:
																				if (12 > b)
																				{
																					goto end_IL_0350;
																				}
																				goto IL_03c0;
																				IL_03c0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)CancellationPendingNOTIFTYPECONVERTED[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				num = 82;
																				goto IL_03ed;
																				IL_03ed:
																				array[num5] = 0;
																				goto IL_03fb;
																				IL_03fb:
																				num5++;
																				goto IL_0409;
																				IL_0409:
																				ptr2 += 8;
																				break;
																				IL_041c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0);
																				goto IL_045d;
																				IL_045d:
																				array[num5 - 2] = 0;
																				goto IL_0471;
																				IL_0471:
																				num5--;
																				break;
																				IL_0525:
																				if (14 < b)
																				{
																					goto end_IL_0350;
																				}
																				goto IL_0533;
																				IL_0533:
																				if (14 > b)
																				{
																					goto end_IL_0350;
																				}
																				goto IL_0541;
																			}
																			break;
																		}
																		goto IL_055d;
																		IL_080d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_084d;
																		IL_055d:
																		if (7 <= b)
																		{
																			goto IL_0568;
																		}
																		goto IL_05cf;
																		IL_0568:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_05a8;
																		IL_05a8:
																		array[num5 - 2] = 0;
																		goto IL_05bc;
																		IL_05bc:
																		num5--;
																		break;
																		IL_05cf:
																		if (3 >= b)
																		{
																			goto IL_05dd;
																		}
																		num = 109;
																		goto IL_06ed;
																		IL_05dd:
																		if (3 > b)
																		{
																			goto IL_05eb;
																		}
																		goto IL_069a;
																		IL_05eb:
																		if (1 < b)
																		{
																			goto IL_05f9;
																		}
																		goto IL_0687;
																		IL_05f9:
																		if (2 < b)
																		{
																			goto end_IL_0350;
																		}
																		goto IL_0607;
																		IL_0607:
																		if (2 > b)
																		{
																			num = 45;
																			goto end_IL_0350;
																		}
																		goto IL_0612;
																		IL_0612:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0652;
																		IL_0652:
																		array[num5 - 2] = 0;
																		goto IL_0666;
																		IL_0666:
																		num5--;
																		break;
																		IL_0861:
																		num5--;
																		break;
																		IL_0687:
																		if (1 > b)
																		{
																		}
																		goto end_IL_0350;
																		IL_069a:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_06c3;
																		IL_06c3:
																		ptr2 += 8;
																		goto IL_06d1;
																		IL_06d1:
																		num5--;
																		break;
																		IL_084d:
																		array[num5 - 2] = 0;
																		goto IL_0861;
																		IL_06ed:
																		if (5 < b)
																		{
																			goto IL_06fb;
																		}
																		goto IL_077e;
																		IL_06fb:
																		if (6 < b)
																		{
																			goto end_IL_0350;
																		}
																		goto IL_0709;
																		IL_0709:
																		if (6 > b)
																		{
																			goto end_IL_0350;
																		}
																		goto IL_0717;
																		IL_0717:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0757;
																		IL_0757:
																		array[num5 - 2] = 0;
																		goto IL_076b;
																		IL_076b:
																		num5--;
																		break;
																		IL_077e:
																		if (5 > b)
																		{
																			goto IL_078c;
																		}
																		goto IL_080d;
																		IL_078c:
																		if (4 < b)
																		{
																			goto end_IL_0350;
																		}
																		goto IL_079a;
																		IL_079a:
																		if (4 > b)
																		{
																			goto end_IL_0350;
																		}
																		goto IL_07a8;
																		IL_07a8:
																		array[num5] = 0;
																		goto IL_07b6;
																		IL_07b6:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_07d9;
																		IL_07d9:
																		array2[num5] = null;
																		num = 52;
																		goto IL_07ec;
																		IL_07ec:
																		num5++;
																		goto IL_07fa;
																		IL_07fa:
																		ptr2 += 8;
																		break;
																	}
																	goto end_IL_0360;
																	continue;
																	end_IL_0350:
																	break;
																	IL_0350:;
																}
															}
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_088a;
															IL_08a6:
															ptr2 += 8;
															break;
															IL_0898:
															num5++;
															goto IL_08a6;
															IL_088a:
															array[num5] = 0;
															goto IL_0898;
															continue;
															end_IL_0360:
															break;
														}
														break;
													}
													break;
												}
												continue;
											}
											goto IL_093d;
											IL_093d:
											return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
											continue;
											end_IL_08b4:
											break;
										}
										continue;
										end_IL_08c4:
										break;
									}
									continue;
									end_IL_08ce:
									break;
								}
								continue;
								end_IL_08e2:
								break;
							}
							continue;
							end_IL_08f2:
							break;
						}
						continue;
						end_IL_0902:
						break;
					}
					continue;
					end_IL_0912:
					break;
				}
				continue;
				end_IL_0922:
				break;
			}
		}
	}

	public Class155()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 73;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									num = 63;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetCheckSumHOSTED.UserDataSecurityRuntime);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0229:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_01fc:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_01ec:
																								if (7 <= b)
																								{
																									num = 111;
																									while (true)
																									{
																										if (num != 111)
																										{
																											if (num != 1092)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 83:
																												goto IL_01ec;
																											case 14:
																												goto IL_01fc;
																											case 103:
																												goto end_IL_01fc;
																											case 15:
																												goto end_IL_0209;
																											case 99:
																												goto IL_0229;
																											case 22:
																												goto end_IL_0229;
																											case 40:
																											case 71:
																												goto end_IL_0239;
																											case 49:
																												goto IL_0254;
																											case 77:
																												goto end_IL_01d9;
																											case 82:
																												goto IL_0275;
																											case 10:
																												goto IL_0283;
																											case 78:
																											case 84:
																												goto IL_0291;
																											case 33:
																												goto IL_02d1;
																											case 19:
																												goto IL_02e5;
																											case 94:
																												goto IL_02f8;
																											case 93:
																												goto IL_0306;
																											case 42:
																											case 57:
																												goto IL_0314;
																											case 98:
																												goto IL_0330;
																											case 45:
																											case 80:
																												goto IL_033e;
																											case 36:
																												goto IL_034c;
																											case 88:
																												goto IL_0357;
																											case 11:
																												goto IL_0365;
																											case 70:
																											case 74:
																												goto IL_0378;
																											case 8:
																												goto IL_03c1;
																											case 81:
																												goto IL_03d5;
																											case 47:
																												goto IL_03e8;
																											case 20:
																											case 23:
																												goto IL_03f6;
																											case 24:
																												goto IL_0404;
																											case 12:
																											case 27:
																												goto IL_0412;
																											case 53:
																												goto IL_0452;
																											case 25:
																												goto IL_0466;
																											case 43:
																												goto IL_0479;
																											case 30:
																											case 46:
																												goto IL_0490;
																											case 59:
																												goto IL_04b9;
																											case 28:
																												goto IL_04c7;
																											case 64:
																											case 92:
																												goto IL_04da;
																											case 44:
																												goto IL_04e8;
																											case 16:
																											case 100:
																												goto IL_0510;
																											case 32:
																												goto IL_0550;
																											case 76:
																												goto IL_0564;
																											case 0:
																											case 4:
																											case 6:
																											case 7:
																											case 9:
																											case 18:
																											case 26:
																											case 31:
																											case 35:
																											case 39:
																											case 51:
																											case 54:
																											case 55:
																											case 56:
																											case 79:
																											case 87:
																											case 89:
																											case 90:
																											case 95:
																											case 101:
																												goto end_IL_0219;
																											case 52:
																												goto IL_05a3;
																											case 17:
																												goto IL_05b1;
																											case 58:
																												goto IL_05bf;
																											case 104:
																												goto IL_05cf;
																											case 67:
																												goto IL_05d9;
																											case 29:
																												goto IL_05e7;
																											case 61:
																												goto IL_05f7;
																											case 13:
																												goto IL_0619;
																											case 48:
																												goto IL_0627;
																											case 68:
																												goto IL_0635;
																											case 5:
																											case 21:
																											case 34:
																											case 38:
																											case 50:
																											case 62:
																											case 69:
																											case 75:
																											case 91:
																											case 96:
																											case 97:
																												goto end_IL_0249;
																											case 102:
																												goto end_IL_064c;
																											case 66:
																												goto end_IL_065f;
																											case 63:
																												goto end_IL_0669;
																											case 86:
																												goto end_IL_0674;
																											case 2:
																												goto end_IL_0689;
																											case 37:
																											case 41:
																												goto end_IL_06a7;
																											case 3:
																												goto end_IL_06b7;
																											case 65:
																											case 85:
																												goto end_IL_06c7;
																											case 72:
																												goto end_IL_06d7;
																											case 73:
																												goto end_IL_06e7;
																											case 1:
																											case 60:
																												goto IL_0702;
																											}
																											continue;
																										}
																										goto IL_05f7;
																										IL_0627:
																										num5++;
																										goto IL_0635;
																										IL_0635:
																										ptr2 += 8;
																										num = 97;
																										goto end_IL_0249;
																										IL_05f7:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										num = 13;
																										goto IL_0619;
																										IL_0619:
																										array[num5] = 0;
																										goto IL_0627;
																										continue;
																										end_IL_01d9:
																										break;
																									}
																									break;
																								}
																								goto IL_0275;
																								IL_02d1:
																								array[num5 - 2] = 0;
																								goto IL_02e5;
																								IL_02e5:
																								num5--;
																								goto end_IL_0249;
																								IL_0275:
																								if (6 < b)
																								{
																									goto end_IL_0219;
																								}
																								goto IL_0283;
																								IL_0283:
																								if (6 > b)
																								{
																									goto end_IL_0219;
																								}
																								goto IL_0291;
																								IL_0291:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02d1;
																							}
																							goto IL_0262;
																						}
																						goto IL_0254;
																						IL_0314:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0249;
																						IL_0254:
																						if (8 >= b)
																						{
																							goto IL_0262;
																						}
																						goto IL_02f8;
																						IL_0262:
																						if (8 > b)
																						{
																							goto end_IL_0219;
																						}
																						goto IL_0510;
																						IL_0510:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0550;
																						IL_0550:
																						array[num5 - 2] = 0;
																						goto IL_0564;
																						IL_0564:
																						num5--;
																						num = 75;
																						goto end_IL_0249;
																						IL_02f8:
																						if (9 < b)
																						{
																							goto end_IL_0219;
																						}
																						goto IL_0306;
																						IL_0306:
																						if (9 > b)
																						{
																							goto end_IL_0219;
																						}
																						goto IL_0314;
																						continue;
																						end_IL_01fc:
																						break;
																					}
																					continue;
																				}
																				goto IL_0330;
																				IL_05d9:
																				num5++;
																				goto IL_05e7;
																				IL_0330:
																				if (5 > b)
																				{
																					goto IL_033e;
																				}
																				goto IL_04da;
																				IL_033e:
																				if (2 >= b)
																				{
																					goto IL_034c;
																				}
																				goto IL_03e8;
																				IL_034c:
																				if (2 > b)
																				{
																					goto IL_0357;
																				}
																				goto IL_0378;
																				IL_0357:
																				if (1 < b)
																				{
																					goto end_IL_0219;
																				}
																				goto IL_0365;
																				IL_0365:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0219;
																				IL_0378:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 8;
																				goto IL_03c1;
																				IL_03c1:
																				array[num5 - 2] = 0;
																				goto IL_03d5;
																				IL_03d5:
																				num5--;
																				goto end_IL_0249;
																				IL_03e8:
																				if (3 < b)
																				{
																					goto IL_03f6;
																				}
																				goto IL_0479;
																				IL_03f6:
																				if (4 < b)
																				{
																					goto end_IL_0219;
																				}
																				goto IL_0404;
																				IL_0404:
																				if (4 > b)
																				{
																					goto end_IL_0219;
																				}
																				goto IL_0412;
																				IL_0412:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0452;
																				IL_0452:
																				array[num5 - 2] = 0;
																				goto IL_0466;
																				IL_0466:
																				num5--;
																				goto end_IL_0249;
																				IL_0479:
																				if (3 > b)
																				{
																					goto end_IL_0219;
																				}
																				num = 30;
																				goto IL_0490;
																				IL_05e7:
																				ptr2 += 8;
																				goto end_IL_0249;
																				IL_0490:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04b9;
																				IL_04b9:
																				ptr2 += 8;
																				goto IL_04c7;
																				IL_04c7:
																				num5--;
																				goto end_IL_0249;
																				IL_04da:
																				array[num5] = 0;
																				goto IL_04e8;
																				IL_04e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05cf;
																				IL_05cf:
																				array2[num5] = null;
																				goto IL_05d9;
																				continue;
																				end_IL_0209:
																				break;
																			}
																			continue;
																			end_IL_0219:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05a3;
																	IL_05bf:
																	ptr2 += 8;
																	goto end_IL_0249;
																	IL_05b1:
																	num5++;
																	goto IL_05bf;
																	IL_05a3:
																	array[num5] = 0;
																	goto IL_05b1;
																	continue;
																	end_IL_0229:
																	break;
																}
																continue;
																end_IL_0239:
																break;
															}
															continue;
															end_IL_0249:
															break;
														}
														continue;
													}
													goto IL_0702;
													IL_0702:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_064c:
													break;
												}
												continue;
												end_IL_065f:
												break;
											}
											continue;
											end_IL_0669:
											break;
										}
										continue;
										end_IL_0674:
										break;
									}
									continue;
									end_IL_0689:
									break;
								}
								continue;
								end_IL_06a7:
								break;
							}
							continue;
							end_IL_06b7:
							break;
						}
						continue;
						end_IL_06c7:
						break;
					}
					continue;
					end_IL_06d7:
					break;
				}
				continue;
				end_IL_06e7:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MethodReturngetAsCy.ReaderWriterLockTimedOutExceptionGetNextSelector);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															IL_0269:
															ptr2++;
															while (true)
															{
																IL_0259:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_0249:
																		if (b <= 10)
																		{
																			while (true)
																			{
																				IL_0239:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0229:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_021c:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_020c:
																										if (2 > b)
																										{
																											while (true)
																											{
																												IL_01fc:
																												if (1 < b)
																												{
																													num = 115;
																													while (num != 115)
																													{
																														if (num != 1096)
																														{
																															goto end_IL_0259;
																														}
																														switch (num)
																														{
																														case 30:
																															goto IL_01fc;
																														case 2:
																															goto IL_020c;
																														case 28:
																															goto IL_021c;
																														case 8:
																															goto IL_0229;
																														case 32:
																															goto IL_0239;
																														case 88:
																															goto IL_0249;
																														case 67:
																															goto IL_0259;
																														case 13:
																															goto IL_0269;
																														case 71:
																														case 103:
																															goto end_IL_0259;
																														case 54:
																															goto IL_0284;
																														case 35:
																														case 64:
																															goto IL_0297;
																														case 46:
																															goto IL_02a2;
																														case 7:
																															goto IL_02b5;
																														case 11:
																														case 84:
																															goto IL_02c5;
																														case 91:
																															goto IL_02d8;
																														case 36:
																														case 94:
																															goto IL_02eb;
																														case 85:
																															goto IL_0314;
																														case 68:
																															goto IL_0322;
																														case 62:
																														case 95:
																															goto IL_0335;
																														case 20:
																															goto IL_034e;
																														case 69:
																															goto IL_035c;
																														case 80:
																															goto IL_0373;
																														case 89:
																														case 96:
																															goto IL_0386;
																														case 106:
																															goto IL_039e;
																														case 18:
																															goto IL_03c1;
																														case 26:
																															goto IL_03cb;
																														case 44:
																															goto IL_03d9;
																														case 52:
																														case 100:
																															goto IL_03ec;
																														case 47:
																														case 78:
																															goto IL_03f7;
																														case 5:
																														case 93:
																															goto IL_0402;
																														case 22:
																															goto IL_040d;
																														case 53:
																															goto IL_042e;
																														case 0:
																														case 81:
																															goto IL_043c;
																														case 40:
																															goto IL_0458;
																														case 41:
																														case 51:
																															goto IL_0466;
																														case 15:
																															goto IL_0471;
																														case 17:
																														case 25:
																															goto IL_047f;
																														case 49:
																															goto IL_04bf;
																														case 43:
																															goto IL_04d3;
																														case 31:
																														case 108:
																															goto IL_04ef;
																														case 12:
																															goto IL_04fd;
																														case 56:
																														case 82:
																															goto IL_0516;
																														case 104:
																															goto IL_0539;
																														case 42:
																															goto IL_0547;
																														case 86:
																															goto IL_0555;
																														case 1:
																														case 6:
																															goto IL_0568;
																														case 70:
																															goto IL_05ca;
																														case 3:
																														case 4:
																														case 14:
																														case 16:
																														case 21:
																														case 23:
																														case 27:
																														case 29:
																														case 39:
																														case 45:
																														case 48:
																														case 55:
																														case 57:
																														case 63:
																														case 66:
																														case 90:
																														case 92:
																														case 97:
																														case 98:
																														case 99:
																														case 102:
																															goto end_IL_01e9;
																														case 9:
																														case 19:
																														case 33:
																														case 34:
																														case 50:
																														case 59:
																														case 61:
																														case 65:
																														case 72:
																														case 79:
																														case 83:
																														case 101:
																														case 107:
																															goto end_IL_0279;
																														case 24:
																															goto end_IL_05ff;
																														case 105:
																															goto end_IL_0612;
																														case 77:
																															goto end_IL_061c;
																														case 58:
																															goto end_IL_0627;
																														case 37:
																														case 75:
																															goto end_IL_063c;
																														case 38:
																															goto end_IL_064c;
																														case 10:
																														case 76:
																															goto end_IL_065c;
																														case 73:
																															goto end_IL_066c;
																														case 74:
																															goto end_IL_067c;
																														case 60:
																														case 87:
																															goto IL_0697;
																														}
																														continue;
																														end_IL_01e9:
																														break;
																													}
																													break;
																												}
																												goto IL_0284;
																												IL_035c:
																												num5++;
																												num = 80;
																												goto IL_0373;
																												IL_0373:
																												ptr2 += 8;
																												goto end_IL_0279;
																												IL_0284:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_0335;
																												IL_0335:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_034e;
																												IL_034e:
																												array[num5] = 0;
																												goto IL_035c;
																											}
																											break;
																										}
																										goto IL_02eb;
																										IL_0322:
																										num5--;
																										goto end_IL_0279;
																										IL_02eb:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0314;
																										IL_0314:
																										ptr2 += 8;
																										goto IL_0322;
																									}
																									break;
																								}
																								goto IL_0297;
																								IL_02d8:
																								if (4 > b)
																								{
																									break;
																								}
																								goto end_IL_0279;
																								IL_0297:
																								if (3 >= b)
																								{
																									goto IL_02a2;
																								}
																								goto IL_02b5;
																								IL_02a2:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0386;
																								IL_0386:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0279;
																								IL_02b5:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_02d8;
																							}
																							break;
																						}
																						goto IL_02c5;
																						IL_03d9:
																						ptr2 += 8;
																						goto end_IL_0279;
																						IL_02c5:
																						array[num5] = 0;
																						goto IL_039e;
																						IL_039e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03c1;
																						IL_03c1:
																						array2[num5] = null;
																						goto IL_03cb;
																						IL_03cb:
																						num5++;
																						goto IL_03d9;
																					}
																					break;
																				}
																				goto IL_03ec;
																				IL_0547:
																				num5++;
																				goto IL_0555;
																				IL_03ec:
																				if (8 < b)
																				{
																					goto IL_03f7;
																				}
																				goto IL_0458;
																				IL_03f7:
																				if (9 < b)
																				{
																					goto IL_0402;
																				}
																				goto IL_042e;
																				IL_0402:
																				if (10 < b)
																				{
																					num = 55;
																					break;
																				}
																				goto IL_040d;
																				IL_040d:
																				if (10 <= b)
																				{
																				}
																				break;
																				IL_0555:
																				ptr2 += 8;
																				goto end_IL_0279;
																				IL_042e:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_043c;
																				IL_043c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0279;
																				IL_0458:
																				if (8 > b)
																				{
																					goto IL_0466;
																				}
																				goto IL_0568;
																				IL_0466:
																				if (6 >= b)
																				{
																					goto IL_0471;
																				}
																				num = 31;
																				goto IL_04ef;
																				IL_0471:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_047f;
																				IL_047f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04bf;
																				IL_04bf:
																				array[num5 - 2] = 0;
																				goto IL_04d3;
																				IL_04d3:
																				num5--;
																				goto end_IL_0279;
																				IL_0568:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05ca;
																				IL_04ef:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_04fd;
																				IL_04fd:
																				if (7 > b)
																				{
																					num = 3;
																					break;
																				}
																				goto IL_0516;
																				IL_05ca:
																				num5 -= 2;
																				num = 19;
																				goto end_IL_0279;
																				IL_0516:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0539;
																				IL_0539:
																				array[num5] = 0;
																				goto IL_0547;
																			}
																		}
																		else
																		{
																			num = 48;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0279;
																continue;
																end_IL_0259:
																break;
															}
															break;
														}
														continue;
														end_IL_0279:
														break;
													}
													continue;
												}
												goto IL_0697;
												IL_0697:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ff:
												break;
											}
											continue;
											end_IL_0612:
											break;
										}
										continue;
										end_IL_061c:
										break;
									}
									continue;
									end_IL_0627:
									break;
								}
								continue;
								end_IL_063c:
								break;
							}
							continue;
							end_IL_064c:
							break;
						}
						continue;
						end_IL_065c:
						break;
					}
					continue;
					end_IL_066c:
					break;
				}
				continue;
				end_IL_067c:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 74;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											num = 80;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct86.RandomAccessgetCompilationRelaxations);
												while (true)
												{
													IL_04fd:
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_029c:
																byte b = *ptr2;
																while (true)
																{
																	IL_028c:
																	ptr2++;
																	while (true)
																	{
																		IL_027c:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_025c:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_024c:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_023f:
																									if (2 < b)
																									{
																										while (3 >= b)
																										{
																											while (3 <= b)
																											{
																												while (true)
																												{
																													IL_01dd:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_01c7:
																														array[num5 - 2] = 0;
																														while (true)
																														{
																															IL_01ae:
																															num5--;
																															num = 99;
																															while (num != 99)
																															{
																																if (num != 1080)
																																{
																																	goto end_IL_04ea;
																																}
																																switch (num)
																																{
																																case 38:
																																	goto IL_01ae;
																																case 81:
																																	goto IL_01c7;
																																case 20:
																																case 56:
																																	goto IL_01dd;
																																case 0:
																																	goto IL_021f;
																																case 2:
																																case 12:
																																	goto IL_022f;
																																case 65:
																																	goto IL_023f;
																																case 11:
																																	goto IL_024c;
																																case 50:
																																	goto IL_025c;
																																case 27:
																																	goto IL_026c;
																																case 25:
																																	goto IL_027c;
																																case 68:
																																	goto IL_028c;
																																case 41:
																																case 63:
																																	goto IL_029c;
																																case 57:
																																	goto IL_02a7;
																																case 16:
																																case 39:
																																	goto IL_02b2;
																																case 22:
																																	goto IL_02c0;
																																case 64:
																																case 71:
																																	goto IL_02d3;
																																case 83:
																																	goto IL_0341;
																																case 72:
																																case 77:
																																	goto IL_0354;
																																case 24:
																																	goto IL_037d;
																																case 92:
																																	goto IL_038b;
																																case 73:
																																	goto IL_039e;
																																case 49:
																																case 66:
																																	goto IL_03ac;
																																case 59:
																																	goto IL_03b7;
																																case 8:
																																case 14:
																																	goto IL_03c5;
																																case 42:
																																	goto IL_03d3;
																																case 61:
																																	goto IL_03f6;
																																case 44:
																																	goto IL_0400;
																																case 48:
																																	goto IL_0417;
																																case 10:
																																case 67:
																																	goto IL_042a;
																																case 4:
																																	goto IL_0435;
																																case 7:
																																case 54:
																																	goto IL_0440;
																																case 85:
																																	goto IL_0467;
																																case 31:
																																case 47:
																																	goto IL_0472;
																																case 26:
																																	goto IL_047d;
																																case 17:
																																case 28:
																																	goto IL_0488;
																																case 6:
																																case 15:
																																case 18:
																																case 21:
																																case 37:
																																case 40:
																																case 43:
																																case 46:
																																case 51:
																																case 52:
																																case 53:
																																case 58:
																																case 69:
																																case 75:
																																case 76:
																																case 79:
																																case 84:
																																case 86:
																																case 90:
																																	goto end_IL_021f;
																																case 9:
																																	goto IL_04c0;
																																case 89:
																																	goto IL_04ce;
																																case 45:
																																	goto IL_04dc;
																																case 1:
																																case 3:
																																case 5:
																																case 13:
																																case 19:
																																case 23:
																																case 55:
																																case 62:
																																case 88:
																																case 91:
																																	goto end_IL_019b;
																																case 60:
																																	goto IL_04fd;
																																case 80:
																																	goto end_IL_04ea;
																																case 78:
																																	goto end_IL_0507;
																																case 32:
																																	goto end_IL_0512;
																																case 33:
																																	goto end_IL_0530;
																																case 34:
																																case 70:
																																	goto end_IL_0545;
																																case 36:
																																	goto end_IL_0555;
																																case 74:
																																	goto end_IL_0565;
																																case 82:
																																	goto end_IL_0575;
																																case 29:
																																	goto end_IL_0585;
																																case 30:
																																	goto end_IL_0590;
																																case 35:
																																case 87:
																																	goto IL_05b4;
																																}
																																continue;
																																end_IL_019b:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_027c;
																												continue;
																												end_IL_021f:
																												break;
																												IL_021f:;
																											}
																											break;
																											IL_022f:;
																										}
																										break;
																									}
																									goto IL_02a7;
																									IL_0341:
																									num5 -= 2;
																									goto end_IL_027c;
																									IL_02a7:
																									if (2 > b)
																									{
																										goto IL_02b2;
																									}
																									goto IL_02d3;
																									IL_02b2:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_02c0;
																									IL_02c0:
																									if (1 <= b)
																									{
																									}
																									break;
																									IL_02d3:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0341;
																								}
																								break;
																							}
																							goto IL_0354;
																							IL_038b:
																							num5--;
																							goto end_IL_027c;
																							IL_0354:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_037d;
																							IL_037d:
																							ptr2 += 8;
																							goto IL_038b;
																						}
																						break;
																					}
																					goto IL_039e;
																					IL_047d:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_0488;
																					IL_039e:
																					if (6 < b)
																					{
																						goto IL_03ac;
																					}
																					goto IL_0467;
																					IL_03ac:
																					if (7 >= b)
																					{
																						goto IL_03b7;
																					}
																					goto IL_042a;
																					IL_03b7:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_03c5;
																					IL_03c5:
																					array[num5] = 0;
																					goto IL_03d3;
																					IL_03d3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03f6;
																					IL_03f6:
																					array2[num5] = null;
																					goto IL_0400;
																					IL_0400:
																					num5++;
																					num = 48;
																					goto IL_0417;
																					IL_0417:
																					ptr2 += 8;
																					goto end_IL_027c;
																					IL_042a:
																					if (8 < b)
																					{
																						num = 51;
																						break;
																					}
																					goto IL_0435;
																					IL_0435:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0440;
																					IL_0440:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_027c;
																					IL_0488:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_027c;
																					IL_0467:
																					if (6 <= b)
																					{
																						goto end_IL_027c;
																					}
																					goto IL_0472;
																					IL_0472:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_047d;
																				}
																				break;
																				IL_026c:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04c0;
																		IL_04dc:
																		ptr2 += 8;
																		break;
																		IL_04ce:
																		num5++;
																		goto IL_04dc;
																		IL_04c0:
																		array[num5] = 0;
																		goto IL_04ce;
																		continue;
																		end_IL_027c:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														num = 35;
														goto IL_05b4;
														IL_05b4:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04ea:
														break;
													}
													break;
												}
												continue;
												end_IL_0507:
												break;
											}
											continue;
											end_IL_0512:
											break;
										}
										continue;
										end_IL_0530:
										break;
									}
									continue;
									end_IL_0545:
									break;
								}
								continue;
								end_IL_0555:
								break;
							}
							continue;
							end_IL_0565:
							break;
						}
						continue;
						end_IL_0575:
						break;
					}
					continue;
					end_IL_0585:
					break;
				}
				continue;
				end_IL_0590:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1, int int_2)
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 24;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											num = 91;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VTCLSIDIActivator.AssertFiltersGetRootObject);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_028f:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_0272:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0262:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_024f:
																									if (2 >= b)
																									{
																										num = 82;
																										while (true)
																										{
																											IL_023f:
																											if (2 <= b)
																											{
																												while (true)
																												{
																													IL_01f4:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 113;
																													while (true)
																													{
																														if (num != 113)
																														{
																															if (num != 1094)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 45:
																															case 94:
																																goto IL_01f4;
																															case 82:
																																goto IL_023f;
																															case 12:
																															case 22:
																																goto IL_024f;
																															case 76:
																																goto IL_0262;
																															case 25:
																																goto IL_0272;
																															case 88:
																																goto end_IL_0272;
																															case 0:
																																goto IL_028f;
																															case 26:
																																goto end_IL_028f;
																															case 66:
																															case 79:
																																goto end_IL_029f;
																															case 18:
																															case 43:
																																goto end_IL_01e1;
																															case 14:
																																goto IL_02ce;
																															case 11:
																															case 35:
																																goto IL_02e7;
																															case 8:
																																goto IL_0300;
																															case 44:
																																goto IL_0313;
																															case 23:
																															case 41:
																																goto IL_031e;
																															case 53:
																																goto IL_032c;
																															case 59:
																																goto IL_033f;
																															case 69:
																																goto IL_034f;
																															case 6:
																															case 70:
																																goto IL_0362;
																															case 56:
																																goto IL_0370;
																															case 63:
																															case 73:
																																goto IL_0383;
																															case 65:
																																goto IL_03cc;
																															case 51:
																																goto IL_03e0;
																															case 80:
																																goto IL_03f3;
																															case 28:
																															case 54:
																																goto IL_0401;
																															case 29:
																																goto IL_042a;
																															case 48:
																																goto IL_0438;
																															case 27:
																															case 90:
																																goto IL_044b;
																															case 96:
																																goto IL_0467;
																															case 87:
																																goto IL_0475;
																															case 39:
																															case 101:
																																goto IL_0488;
																															case 2:
																																goto IL_0496;
																															case 33:
																															case 49:
																																goto IL_04a4;
																															case 68:
																																goto IL_04e4;
																															case 104:
																																goto IL_04f8;
																															case 93:
																															case 106:
																																goto IL_050b;
																															case 85:
																																goto IL_0519;
																															case 15:
																															case 81:
																																goto IL_0527;
																															case 50:
																																goto IL_0567;
																															case 38:
																																goto IL_057b;
																															case 102:
																																goto IL_05a2;
																															case 46:
																															case 67:
																																goto IL_05b5;
																															case 71:
																																goto IL_05c3;
																															case 84:
																																goto IL_05e6;
																															case 103:
																																goto IL_05f0;
																															case 52:
																																goto IL_05fe;
																															case 1:
																															case 17:
																															case 19:
																															case 20:
																															case 34:
																															case 55:
																															case 58:
																															case 61:
																															case 64:
																															case 72:
																															case 77:
																															case 78:
																															case 89:
																															case 92:
																															case 95:
																															case 98:
																															case 100:
																															case 105:
																																goto end_IL_027f;
																															case 99:
																																goto IL_0631;
																															case 47:
																																goto IL_063f;
																															case 32:
																																goto IL_064d;
																															case 10:
																															case 16:
																															case 21:
																															case 31:
																															case 42:
																															case 57:
																															case 62:
																															case 74:
																															case 75:
																															case 83:
																															case 86:
																																goto end_IL_02af;
																															case 13:
																																goto end_IL_065b;
																															case 91:
																																goto end_IL_066e;
																															case 97:
																																goto end_IL_0678;
																															case 40:
																																goto end_IL_0683;
																															case 30:
																																goto end_IL_06a1;
																															case 24:
																																goto end_IL_06b6;
																															case 60:
																																goto end_IL_06c6;
																															case 5:
																																goto end_IL_06d6;
																															case 7:
																															case 36:
																																goto end_IL_06e1;
																															case 3:
																																goto end_IL_06f1;
																															case 4:
																																goto end_IL_0701;
																															case 9:
																															case 37:
																																goto IL_071c;
																															}
																															continue;
																														}
																														array[num5 - 2] = 0;
																														goto IL_05a2;
																														IL_05a2:
																														num5--;
																														goto end_IL_02af;
																														continue;
																														end_IL_01e1:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0362;
																											IL_0370:
																											if (1 > b)
																											{
																											}
																											goto end_IL_027f;
																											IL_0362:
																											if (1 < b)
																											{
																												goto end_IL_027f;
																											}
																											goto IL_0370;
																										}
																										break;
																									}
																									goto IL_034f;
																									IL_042a:
																									ptr2 += 8;
																									goto IL_0438;
																									IL_0438:
																									num5--;
																									goto end_IL_02af;
																									IL_034f:
																									if (3 >= b)
																									{
																										goto IL_03f3;
																									}
																									goto IL_050b;
																									IL_050b:
																									if (4 < b)
																									{
																										goto end_IL_027f;
																									}
																									goto IL_0519;
																									IL_0519:
																									if (4 > b)
																									{
																										goto end_IL_027f;
																									}
																									goto IL_0527;
																									IL_0527:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0567;
																									IL_0567:
																									array[num5 - 2] = 0;
																									goto IL_057b;
																									IL_057b:
																									num5--;
																									goto end_IL_02af;
																									IL_03f3:
																									if (3 > b)
																									{
																										goto end_IL_027f;
																									}
																									goto IL_0401;
																									IL_0401:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_042a;
																								}
																								break;
																							}
																							goto IL_05b5;
																							IL_05fe:
																							ptr2 += 8;
																							goto end_IL_02af;
																							IL_05b5:
																							array[num5] = 0;
																							goto IL_05c3;
																							IL_05c3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05e6;
																							IL_05e6:
																							array2[num5] = null;
																							goto IL_05f0;
																							IL_05f0:
																							num5++;
																							goto IL_05fe;
																						}
																					}
																					if (7 >= b)
																					{
																						num = 14;
																						goto IL_02ce;
																					}
																					goto IL_0313;
																					IL_0383:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 65;
																					goto IL_03cc;
																					IL_033f:
																					if (8 > b)
																					{
																						goto end_IL_027f;
																					}
																					goto IL_0383;
																					IL_03cc:
																					array[num5 - 2] = 0;
																					goto IL_03e0;
																					IL_02ce:
																					if (7 <= b)
																					{
																						goto IL_02e7;
																					}
																					num = 101;
																					goto IL_0488;
																					IL_03e0:
																					num5--;
																					goto end_IL_02af;
																					IL_0488:
																					if (6 < b)
																					{
																						goto end_IL_027f;
																					}
																					goto IL_0496;
																					IL_0496:
																					if (6 > b)
																					{
																						goto end_IL_027f;
																					}
																					goto IL_04a4;
																					IL_04a4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04e4;
																					IL_04e4:
																					array[num5 - 2] = 0;
																					goto IL_04f8;
																					IL_04f8:
																					num5--;
																					goto end_IL_02af;
																					IL_02e7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0300;
																					IL_0300:
																					array[num5] = 0;
																					goto IL_0467;
																					IL_0467:
																					num5++;
																					goto IL_0475;
																					IL_0475:
																					ptr2 += 8;
																					goto end_IL_02af;
																					IL_0313:
																					if (8 < b)
																					{
																						goto IL_031e;
																					}
																					goto IL_033f;
																					IL_031e:
																					if (9 < b)
																					{
																						goto end_IL_027f;
																					}
																					goto IL_032c;
																					IL_032c:
																					if (9 > b)
																					{
																						goto end_IL_027f;
																					}
																					goto IL_044b;
																					IL_044b:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02af;
																					continue;
																					end_IL_0272:
																					break;
																				}
																				continue;
																				end_IL_027f:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0631;
																		IL_064d:
																		ptr2 += 8;
																		goto end_IL_02af;
																		IL_063f:
																		num5++;
																		goto IL_064d;
																		IL_0631:
																		array[num5] = 0;
																		goto IL_063f;
																		continue;
																		end_IL_028f:
																		break;
																	}
																	continue;
																	end_IL_029f:
																	break;
																}
																continue;
																end_IL_02af:
																break;
															}
															continue;
														}
														goto IL_071c;
														IL_071c:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_065b:
														break;
													}
													continue;
													end_IL_066e:
													break;
												}
												continue;
												end_IL_0678:
												break;
											}
											continue;
											end_IL_0683:
											break;
										}
										continue;
										end_IL_06a1:
										break;
									}
									continue;
									end_IL_06b6:
									break;
								}
								continue;
								end_IL_06c6:
								break;
							}
							continue;
							end_IL_06d6:
							break;
						}
						continue;
						end_IL_06e1:
						break;
					}
					continue;
					end_IL_06f1:
					break;
				}
				continue;
				end_IL_0701:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 28;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 26;
						while (true)
						{
							int[] array3 = new int[3];
							num = 16;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetAttributesGetRegistrableTypesInAssembly.getIsNetFxTimeSpanLegacyFormatModeCustomAttributeBuilder);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0240:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0220:
																			if (5 >= b)
																			{
																				goto IL_0427;
																			}
																			while (true)
																			{
																				IL_0210:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_0200:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_01f0:
																								if (6 < b)
																								{
																									num = 112;
																									while (true)
																									{
																										if (num != 112)
																										{
																											if (num != 1093)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 69:
																												goto IL_01f0;
																											case 29:
																												goto IL_0200;
																											case 75:
																												goto IL_0210;
																											case 83:
																												goto IL_0220;
																											case 71:
																												goto end_IL_0220;
																											case 90:
																												goto IL_0240;
																											case 43:
																												goto end_IL_0240;
																											case 2:
																											case 44:
																												goto end_IL_0250;
																											case 21:
																												goto IL_026b;
																											case 32:
																											case 63:
																												goto IL_0279;
																											case 64:
																											case 74:
																												goto IL_02be;
																											case 39:
																												goto IL_0320;
																											case 34:
																											case 86:
																												goto IL_0333;
																											case 33:
																												goto IL_033e;
																											case 49:
																											case 52:
																												goto IL_034c;
																											case 10:
																												goto IL_0368;
																											case 58:
																												goto IL_0376;
																											case 104:
																												goto IL_0389;
																											case 45:
																												goto IL_039d;
																											case 99:
																												goto IL_03b0;
																											case 0:
																												goto IL_03be;
																											case 14:
																											case 59:
																												goto IL_03cc;
																											case 95:
																												goto IL_03ef;
																											case 3:
																												goto IL_0406;
																											case 36:
																												goto IL_0414;
																											case 101:
																												goto IL_0427;
																											case 4:
																											case 42:
																												goto IL_0432;
																											case 87:
																												goto IL_0440;
																											case 17:
																												goto IL_0463;
																											case 80:
																												goto IL_046d;
																											case 81:
																												goto IL_047b;
																											case 78:
																											case 105:
																												goto IL_0497;
																											case 76:
																												goto IL_04a5;
																											case 55:
																											case 82:
																												goto IL_04b0;
																											case 67:
																												goto IL_04be;
																											case 54:
																											case 57:
																												goto IL_04cc;
																											case 31:
																												goto IL_04e5;
																											case 89:
																												goto IL_04f3;
																											case 5:
																												goto IL_0501;
																											case 73:
																											case 96:
																												goto IL_0514;
																											case 91:
																												goto IL_053d;
																											case 53:
																												goto end_IL_01dd;
																											case 100:
																												goto IL_055b;
																											case 97:
																												goto IL_0566;
																											case 19:
																											case 37:
																												goto IL_0571;
																											case 18:
																											case 46:
																												goto IL_058f;
																											case 12:
																												goto IL_059a;
																											case 7:
																											case 9:
																											case 11:
																											case 13:
																											case 15:
																											case 22:
																											case 38:
																											case 40:
																											case 41:
																											case 48:
																											case 62:
																											case 65:
																											case 66:
																											case 77:
																											case 84:
																											case 85:
																											case 93:
																											case 94:
																											case 98:
																											case 103:
																												goto end_IL_0230;
																											case 6:
																											case 20:
																											case 23:
																											case 30:
																											case 47:
																											case 50:
																											case 51:
																											case 56:
																											case 61:
																											case 79:
																											case 88:
																											case 92:
																											case 102:
																												goto end_IL_0260;
																											case 24:
																												goto end_IL_05b8;
																											case 8:
																												goto end_IL_05cb;
																											case 35:
																												goto end_IL_05d5;
																											case 16:
																												goto end_IL_05e0;
																											case 26:
																											case 70:
																												goto end_IL_05f5;
																											case 60:
																												goto end_IL_0605;
																											case 68:
																											case 72:
																												goto end_IL_061e;
																											case 27:
																												goto end_IL_0637;
																											case 28:
																												goto end_IL_0647;
																											case 1:
																											case 25:
																												goto IL_0662;
																											}
																											continue;
																										}
																										goto IL_03b0;
																										IL_0406:
																										num5++;
																										goto IL_0414;
																										IL_0414:
																										ptr2 += 8;
																										goto end_IL_0260;
																										IL_03b0:
																										if (7 < b)
																										{
																											goto end_IL_0230;
																										}
																										goto IL_03be;
																										IL_03be:
																										if (7 > b)
																										{
																											goto end_IL_0230;
																										}
																										goto IL_03cc;
																										IL_03cc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_03ef;
																										IL_03ef:
																										array[num5] = 0;
																										num = 3;
																										goto IL_0406;
																										continue;
																										end_IL_01dd:
																										break;
																									}
																									break;
																								}
																								goto IL_026b;
																								IL_0389:
																								array[num5 - 2] = 0;
																								goto IL_039d;
																								IL_039d:
																								num5--;
																								goto end_IL_0260;
																								IL_026b:
																								if (6 > b)
																								{
																									goto end_IL_0230;
																								}
																								goto IL_0279;
																								IL_0279:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0389;
																							}
																							break;
																						}
																						goto IL_02be;
																						IL_0320:
																						num5 -= 2;
																						goto end_IL_0260;
																						IL_02be:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0320;
																					}
																					break;
																				}
																				goto IL_0333;
																				IL_0376:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_0230;
																				IL_0333:
																				if (9 >= b)
																				{
																					goto IL_033e;
																				}
																				goto IL_0368;
																				IL_033e:
																				if (9 > b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_034c;
																				IL_034c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0260;
																				IL_0368:
																				if (10 < b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_0376;
																			}
																			goto IL_054b;
																			IL_059a:
																			if (4 <= b)
																			{
																				goto end_IL_0260;
																			}
																			goto end_IL_0230;
																			IL_0427:
																			if (5 <= b)
																			{
																				goto IL_0432;
																			}
																			num = 105;
																			goto IL_0497;
																			IL_0432:
																			array[num5] = 0;
																			goto IL_0440;
																			IL_0440:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0463;
																			IL_0463:
																			array2[num5] = null;
																			goto IL_046d;
																			IL_046d:
																			num5++;
																			goto IL_047b;
																			IL_047b:
																			ptr2 += 8;
																			goto end_IL_0260;
																			IL_058f:
																			if (4 < b)
																			{
																				goto end_IL_0230;
																			}
																			goto IL_059a;
																			IL_0497:
																			if (2 >= b)
																			{
																				goto IL_04a5;
																			}
																			goto IL_055b;
																			IL_04a5:
																			if (2 > b)
																			{
																				goto IL_04b0;
																			}
																			goto IL_0514;
																			IL_04b0:
																			if (1 < b)
																			{
																				goto end_IL_0230;
																			}
																			goto IL_04be;
																			IL_04be:
																			if (1 > b)
																			{
																				goto end_IL_0230;
																			}
																			goto IL_04cc;
																			IL_04cc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04e5;
																			IL_04e5:
																			array[num5] = 0;
																			goto IL_04f3;
																			IL_04f3:
																			num5++;
																			goto IL_0501;
																			IL_0501:
																			ptr2 += 8;
																			goto end_IL_0260;
																			IL_0514:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_053d;
																			IL_053d:
																			ptr2 += 8;
																			goto IL_054b;
																			IL_054b:
																			num5--;
																			goto end_IL_0260;
																			IL_055b:
																			if (3 >= b)
																			{
																				goto IL_0566;
																			}
																			num = 18;
																			goto IL_058f;
																			IL_0566:
																			if (3 > b)
																			{
																				goto end_IL_0230;
																			}
																			goto IL_0571;
																			IL_0571:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0260;
																			continue;
																			end_IL_0220:
																			break;
																		}
																		continue;
																		end_IL_0230:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0260;
																continue;
																end_IL_0240:
																break;
															}
															continue;
															end_IL_0250:
															break;
														}
														continue;
														end_IL_0260:
														break;
													}
													continue;
												}
												goto IL_0662;
												IL_0662:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b8:
												break;
											}
											continue;
											end_IL_05cb:
											break;
										}
										continue;
										end_IL_05d5:
										break;
									}
									continue;
									end_IL_05e0:
									break;
								}
								continue;
								end_IL_05f5:
								break;
							}
							continue;
							end_IL_0605:
							break;
						}
						continue;
						end_IL_061e:
						break;
					}
					continue;
					end_IL_0637:
					break;
				}
				continue;
				end_IL_0647:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 17;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MergeParameterAttributes.SynchronizationAttributeCSTRMarshaler);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0260:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0243:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0233:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0223:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_0213:
																										if (3 < b)
																										{
																											while (4 >= b)
																											{
																												while (true)
																												{
																													IL_01f0:
																													if (4 > b)
																													{
																														num = 112;
																														while (num != 112)
																														{
																															if (num != 1093)
																															{
																																goto IL_043a;
																															}
																															switch (num)
																															{
																															case 95:
																																goto IL_01f0;
																															case 74:
																															case 80:
																																goto IL_0203;
																															case 90:
																																goto IL_0213;
																															case 64:
																															case 79:
																																goto IL_0223;
																															case 50:
																																goto IL_0233;
																															case 43:
																																goto IL_0243;
																															case 104:
																																goto IL_0250;
																															case 18:
																																goto IL_0260;
																															case 105:
																																goto end_IL_0260;
																															case 54:
																															case 55:
																																goto end_IL_0270;
																															case 11:
																															case 77:
																																goto IL_028b;
																															case 34:
																																goto IL_0299;
																															case 9:
																																goto IL_02a7;
																															case 33:
																															case 40:
																																goto IL_02b5;
																															case 20:
																																goto IL_02f5;
																															case 7:
																																goto IL_0309;
																															case 75:
																																goto IL_031c;
																															case 1:
																															case 29:
																																goto IL_032a;
																															case 38:
																																goto IL_034c;
																															case 13:
																																goto IL_035a;
																															case 78:
																																goto IL_0368;
																															case 88:
																																goto IL_037b;
																															case 65:
																																goto IL_0389;
																															case 58:
																															case 76:
																																goto IL_0397;
																															case 67:
																															case 89:
																																goto IL_03b3;
																															case 12:
																															case 97:
																																goto IL_03f5;
																															case 26:
																																goto IL_0403;
																															case 102:
																																goto IL_0413;
																															case 61:
																																goto IL_0427;
																															case 86:
																															case 103:
																																goto IL_043a;
																															case 24:
																																goto IL_047a;
																															case 98:
																																goto IL_0497;
																															case 15:
																																goto IL_04aa;
																															case 10:
																															case 81:
																																goto IL_04b8;
																															case 83:
																																goto IL_04e1;
																															case 56:
																																goto IL_04f8;
																															case 70:
																																goto IL_0514;
																															case 51:
																															case 69:
																																goto IL_051f;
																															case 66:
																																goto IL_055f;
																															case 30:
																																goto IL_0573;
																															case 100:
																																goto IL_0586;
																															case 19:
																																goto IL_0591;
																															case 48:
																															case 71:
																																goto IL_059e;
																															case 27:
																																goto IL_05ac;
																															case 5:
																																goto IL_05cf;
																															case 73:
																																goto IL_05d9;
																															case 57:
																																goto IL_05e7;
																															case 2:
																															case 6:
																															case 28:
																															case 31:
																															case 32:
																															case 35:
																															case 36:
																															case 37:
																															case 44:
																															case 45:
																															case 47:
																															case 49:
																															case 84:
																															case 85:
																															case 93:
																															case 96:
																															case 99:
																															case 101:
																																goto end_IL_01dd;
																															case 4:
																																goto IL_061a;
																															case 3:
																																goto IL_0628;
																															case 53:
																																goto IL_0636;
																															case 14:
																															case 21:
																															case 23:
																															case 41:
																															case 42:
																															case 46:
																															case 52:
																															case 68:
																															case 91:
																															case 92:
																															case 94:
																																goto end_IL_0280;
																															case 0:
																																goto end_IL_0644;
																															case 39:
																																goto end_IL_0657;
																															case 62:
																																goto end_IL_0661;
																															case 72:
																																goto end_IL_066c;
																															case 87:
																																goto end_IL_0681;
																															case 22:
																															case 59:
																																goto end_IL_0696;
																															case 25:
																																goto end_IL_06a6;
																															case 8:
																															case 63:
																																goto end_IL_06b6;
																															case 16:
																																goto end_IL_06c6;
																															case 17:
																																goto end_IL_06d6;
																															case 60:
																															case 82:
																																goto IL_06f1;
																															}
																															continue;
																															end_IL_01dd:
																															break;
																														}
																														break;
																													}
																													goto IL_03b3;
																													IL_0413:
																													array[num5 - 2] = 0;
																													goto IL_0427;
																													IL_0427:
																													num5--;
																													goto end_IL_0280;
																													IL_03b3:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0413;
																												}
																												break;
																												IL_0203:;
																											}
																											break;
																										}
																										goto IL_04aa;
																										IL_04f8:
																										num5--;
																										goto end_IL_0280;
																										IL_04aa:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_04b8;
																										IL_04b8:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_04e1;
																										IL_04e1:
																										ptr2 += 8;
																										num = 56;
																										goto IL_04f8;
																									}
																									break;
																								}
																								num = 70;
																								goto IL_0514;
																								IL_0586:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0591;
																								IL_0591:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0514:
																								if (2 <= b)
																								{
																									goto IL_051f;
																								}
																								goto IL_0586;
																								IL_051f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_055f;
																								IL_055f:
																								array[num5 - 2] = 0;
																								goto IL_0573;
																								IL_0573:
																								num5--;
																								goto end_IL_0280;
																							}
																							break;
																						}
																						goto IL_059e;
																						IL_05e7:
																						ptr2 += 8;
																						goto end_IL_0280;
																						IL_059e:
																						array[num5] = 0;
																						goto IL_05ac;
																						IL_05ac:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05cf;
																						IL_05cf:
																						array2[num5] = null;
																						goto IL_05d9;
																						IL_05d9:
																						num5++;
																						goto IL_05e7;
																					}
																					break;
																				}
																				goto IL_028b;
																				IL_0497:
																				num5--;
																				goto end_IL_0280;
																				IL_028b:
																				if (7 < b)
																				{
																					goto IL_0299;
																				}
																				goto IL_031c;
																				IL_0299:
																				if (8 >= b)
																				{
																					goto IL_02a7;
																				}
																				goto IL_037b;
																				IL_02a7:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_02b5;
																				IL_02b5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_02f5;
																				IL_02f5:
																				array[num5 - 2] = 0;
																				goto IL_0309;
																				IL_0309:
																				num5--;
																				goto end_IL_0280;
																				IL_037b:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0389;
																				IL_0389:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0397;
																				IL_0397:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0280;
																				IL_031c:
																				if (7 <= b)
																				{
																					goto IL_032a;
																				}
																				goto IL_03f5;
																				IL_032a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 38;
																				goto IL_034c;
																				IL_034c:
																				array[num5] = 0;
																				goto IL_035a;
																				IL_035a:
																				num5++;
																				goto IL_0368;
																				IL_0368:
																				ptr2 += 8;
																				goto end_IL_0280;
																				IL_03f5:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0403;
																				IL_0403:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_043a;
																				IL_043a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_047a;
																				IL_047a:
																				array[num5 - 2] = 0;
																				num = 98;
																				goto IL_0497;
																			}
																			break;
																			IL_0250:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_061a;
																	IL_0636:
																	ptr2 += 8;
																	goto end_IL_0280;
																	IL_0628:
																	num5++;
																	goto IL_0636;
																	IL_061a:
																	array[num5] = 0;
																	goto IL_0628;
																	continue;
																	end_IL_0260:
																	break;
																}
																continue;
																end_IL_0270:
																break;
															}
															continue;
															end_IL_0280:
															break;
														}
														continue;
													}
													goto IL_06f1;
													IL_06f1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0644:
													break;
												}
												continue;
												end_IL_0657:
												break;
											}
											continue;
											end_IL_0661:
											break;
										}
										continue;
										end_IL_066c:
										break;
									}
									continue;
									end_IL_0681:
									break;
								}
								continue;
								end_IL_0696:
								break;
							}
							continue;
							end_IL_06a6:
							break;
						}
						continue;
						end_IL_06b6:
						break;
					}
					continue;
					end_IL_06c6:
					break;
				}
				continue;
				end_IL_06d6:
				break;
			}
		}
	}

	private static int smethod_6()
	{
		int num = 52;
		int num2 = 13;
		num = 4;
		object obj = new int[4];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 495;
		num3 = 45;
		((int[])obj)[0] = 45;
		obj = obj2;
		num2 = 1;
		num3 = 69;
		num3 = 23;
		((int[])obj)[1] = 23;
		obj = obj2;
		num2 = 26;
		num3 = 13;
		num2 = 2;
		num3 = 442;
		num3 = 34;
		((int[])obj)[2] = 34;
		obj = obj2;
		num2 = 6;
		num3 = 2;
		num2 = 3;
		num3 = 51;
		num3 = 17;
		((int[])obj)[3] = 17;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 12;
			num3 = 3;
			num2 = 4;
			if (num >= 4)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 79;
		long[] array4 = default(long[]);
		byte* ptr = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		byte* ptr2 = default(byte*);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 15;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 110;
							while (true)
							{
								if (num != 110)
								{
									if (num != 1091)
									{
										goto IL_041c;
									}
									switch (num)
									{
									case 2:
									case 62:
										goto end_IL_01c7;
									case 15:
										goto end_IL_01d7;
									case 17:
									case 68:
										goto end_IL_01f0;
									case 78:
										goto end_IL_0200;
									case 79:
										goto end_IL_0219;
									case 70:
										goto IL_0242;
									case 14:
										goto IL_0255;
									case 97:
										goto IL_025e;
									case 12:
									case 13:
									case 21:
									case 23:
									case 30:
									case 44:
									case 54:
									case 71:
									case 77:
									case 81:
									case 85:
									case 92:
									case 94:
										goto IL_0266;
									case 36:
									case 103:
										goto IL_0276;
									case 75:
										goto IL_0288;
									case 26:
										goto IL_0296;
									case 46:
										goto IL_02a4;
									case 37:
										goto IL_02b2;
									case 61:
										goto IL_02c0;
									case 7:
									case 83:
										goto IL_02cb;
									case 64:
										goto IL_02d9;
									case 55:
										goto IL_02fc;
									case 25:
										goto IL_0306;
									case 53:
										goto IL_0314;
									case 32:
										goto IL_0327;
									case 67:
									case 69:
										goto IL_0332;
									case 63:
										goto IL_033d;
									case 34:
									case 76:
										goto IL_034b;
									case 39:
										goto IL_0363;
									case 90:
										goto IL_0371;
									case 87:
										goto IL_0384;
									case 38:
									case 60:
										goto IL_038f;
									case 35:
										goto IL_03b8;
									case 74:
										goto IL_03c6;
									case 31:
										goto IL_03d9;
									case 43:
										goto IL_03e7;
									case 4:
									case 57:
										goto IL_03f5;
									case 58:
										goto IL_040e;
									case 80:
										goto IL_041c;
									case 29:
										goto IL_042a;
									case 0:
										goto IL_043d;
									case 20:
										goto IL_044b;
									case 11:
									case 52:
										goto IL_0459;
									case 82:
										goto IL_0467;
									case 47:
									case 73:
										goto IL_0475;
									case 89:
										goto IL_04be;
									case 93:
										goto IL_04db;
									case 66:
										goto IL_04ee;
									case 3:
										goto IL_04fc;
									case 56:
									case 101:
										goto IL_050a;
									case 1:
										goto IL_052d;
									case 88:
										goto IL_053b;
									case 50:
										goto IL_0549;
									case 49:
									case 84:
										goto IL_055c;
									case 5:
										goto IL_05be;
									case 40:
									case 86:
										goto IL_05d1;
									case 9:
										goto IL_05e5;
									case 10:
									case 18:
										goto IL_05f0;
									case 91:
										goto IL_060c;
									case 22:
										goto IL_0617;
									case 6:
									case 8:
									case 16:
									case 19:
									case 24:
									case 27:
									case 28:
									case 33:
									case 41:
									case 42:
									case 45:
									case 48:
									case 59:
									case 65:
									case 72:
									case 95:
									case 96:
									case 99:
									case 100:
									case 102:
										goto IL_0622;
									case 51:
									case 98:
										goto IL_063a;
									}
									continue;
								}
								array4 = new long[2];
								goto IL_0242;
								IL_05f0:
								byte* num4 = ptr;
								num5 = 1;
								ptr = num4 + -200;
								goto IL_0266;
								IL_0617:
								if (10 > b)
								{
								}
								goto IL_0622;
								IL_060c:
								if (10 >= b)
								{
									goto IL_0617;
								}
								goto IL_0622;
								IL_0242:
								array3[0] = int_1;
								goto IL_0255;
								IL_0255:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BindToMonikerNewGuid.ConsistencyGuaranteeCreateText);
								goto IL_025e;
								IL_025e:
								ptr = ptr2;
								goto IL_0266;
								IL_0266:
								if (num5 != 1)
								{
									goto IL_0276;
								}
								goto IL_063a;
								IL_063a:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
								IL_0276:
								b = *ptr;
								num = 75;
								goto IL_0288;
								IL_0288:
								ptr++;
								goto IL_0296;
								IL_0296:
								if (b >= 1)
								{
									goto IL_02a4;
								}
								goto IL_0622;
								IL_02a4:
								if (b <= 10)
								{
									goto IL_02b2;
								}
								goto IL_0622;
								IL_02b2:
								if (5 >= b)
								{
									goto IL_02c0;
								}
								goto IL_043d;
								IL_02c0:
								if (5 <= b)
								{
									goto IL_02cb;
								}
								goto IL_0327;
								IL_02cb:
								array[num6] = 0;
								goto IL_02d9;
								IL_02d9:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr + num3)];
								goto IL_02fc;
								IL_02fc:
								array2[num6] = null;
								goto IL_0306;
								IL_0306:
								num6++;
								goto IL_0314;
								IL_0314:
								ptr += 8;
								goto IL_0266;
								IL_0327:
								if (2 < b)
								{
									goto IL_0332;
								}
								goto IL_0384;
								IL_0332:
								if (3 >= b)
								{
									goto IL_033d;
								}
								goto IL_0363;
								IL_033d:
								if (3 <= b)
								{
									goto IL_034b;
								}
								goto IL_0622;
								IL_034b:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_0266;
								IL_0363:
								if (4 >= b)
								{
									goto IL_0371;
								}
								goto IL_0622;
								IL_0371:
								if (4 <= b)
								{
									goto IL_0266;
								}
								goto IL_0622;
								IL_0384:
								if (2 <= b)
								{
									goto IL_038f;
								}
								goto IL_03d9;
								IL_038f:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
								goto IL_03b8;
								IL_03b8:
								ptr += 8;
								goto IL_03c6;
								IL_03c6:
								num6--;
								goto IL_0266;
								IL_03d9:
								if (1 >= b)
								{
									goto IL_03e7;
								}
								goto IL_0622;
								IL_03e7:
								if (1 <= b)
								{
									goto IL_03f5;
								}
								goto IL_0622;
								IL_03f5:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr + num3);
								goto IL_040e;
								IL_040e:
								array[num6] = 0;
								goto IL_041c;
								IL_041c:
								num6++;
								goto IL_042a;
								IL_042a:
								ptr += 8;
								goto IL_0266;
								IL_043d:
								if (8 >= b)
								{
									goto IL_044b;
								}
								goto IL_05d1;
								IL_044b:
								if (8 > b)
								{
									goto IL_0459;
								}
								goto IL_055c;
								IL_0459:
								if (6 >= b)
								{
									goto IL_0467;
								}
								goto IL_04ee;
								IL_0467:
								if (6 <= b)
								{
									goto IL_0475;
								}
								goto IL_0622;
								IL_0475:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
								num = 89;
								goto IL_04be;
								IL_04be:
								array[num6 - 2] = 0;
								num = 93;
								goto IL_04db;
								IL_04db:
								num6--;
								goto IL_0266;
								IL_04ee:
								if (7 >= b)
								{
									goto IL_04fc;
								}
								goto IL_0622;
								IL_04fc:
								if (7 <= b)
								{
									goto IL_050a;
								}
								goto IL_0622;
								IL_050a:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr + num3)];
								goto IL_052d;
								IL_052d:
								array[num6] = 0;
								goto IL_053b;
								IL_053b:
								num6++;
								goto IL_0549;
								IL_0549:
								ptr += 8;
								goto IL_0266;
								IL_055c:
								ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
								goto IL_05be;
								IL_05be:
								num6 -= 2;
								goto IL_0266;
								IL_05d1:
								if (9 >= b)
								{
									num = 9;
									goto IL_05e5;
								}
								goto IL_060c;
								IL_0622:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_0266;
								IL_05e5:
								if (9 <= b)
								{
									goto IL_05f0;
								}
								goto IL_0622;
								continue;
								end_IL_01c7:
								break;
							}
							continue;
							end_IL_01d7:
							break;
						}
						continue;
						end_IL_01f0:
						break;
					}
					continue;
					end_IL_0200:
					break;
				}
				continue;
				end_IL_0219:
				break;
			}
		}
	}

	static Class155()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 10;
					while (true)
					{
						if (num == 10 || num != 991)
						{
							return;
						}
						switch (num)
						{
						case 3:
							goto end_IL_0031;
						case 1:
							goto end_IL_003e;
						case 2:
							goto end_IL_004a;
						case 0:
							return;
						}
						continue;
						end_IL_0031:
						break;
					}
					continue;
					end_IL_003e:
					break;
				}
				continue;
				end_IL_004a:
				break;
			}
		}
	}
}
