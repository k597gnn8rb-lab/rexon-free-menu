using System;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Ghost Hands", "World", "Plays random hand tap sounds around you.", false, 32, ModType.const_0, false)]
internal class Class15 : MonoBehaviour
{
	private float float_0;

	private static double double_0;

	private static bool bool_0;

	private static bool bool_1;

	private static double double_1;

	private static double double_2;

	private static IntPtr[] UCOMIEnumeratorNestedPublic;

	private static IntPtr[] DSClientWellKnownEntry;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001e, IL_087f, IL_0892, IL_08b1, IL_08dc, IL_08ec, IL_08fc, IL_090c, IL_0919, IL_0929, IL_0939, IL_0949, IL_0956, IL_0966, IL_0976, IL_0986, IL_0991, IL_09ba, IL_09d3, IL_09e3, IL_09f0, IL_0a30, IL_0a44, IL_0a57, IL_0a6d, IL_0a78, IL_0a86, IL_0a96, IL_0aa9, IL_0ae8, IL_0afb, IL_0b0f, IL_0b47, IL_0b5a, IL_0b6e, IL_0be9, IL_0bf7, IL_0c0a, IL_0c18, IL_0c26, IL_0c34, IL_0c52, IL_0c60, IL_0c73, IL_0c87, IL_0cbf, IL_0cd2, IL_0ce0, IL_0ceb, IL_0cf9, IL_0d11, IL_0d1f, IL_0d32, IL_0d40, IL_0d4e, IL_0d5c, IL_0d6a, IL_0d75, IL_0dd7, IL_0dea, IL_0df8, IL_0e0b, IL_0e19, IL_0e2c, IL_0e3a, IL_0e48, IL_0e53, IL_0e7c, IL_0e95, IL_0ea3, IL_0eac, IL_0eba, IL_0ed8, IL_0ee6, IL_0ef9, IL_0f07, IL_0f15, IL_0f2d, IL_0f4b, IL_0f6f, IL_0f87, IL_0f9a, IL_0fa3, IL_0fae, IL_0fc1, IL_0fcf, IL_0fda, IL_0fe8, IL_100b, IL_1015, IL_1023, IL_1036, IL_1044, IL_104f, IL_108f, IL_10a8, IL_10b6, IL_10c4, IL_10dd, IL_10eb, IL_10f9, IL_110c, IL_111a, IL_1128, IL_1151, IL_115f, IL_1172, IL_1180, IL_118b, IL_11cb, IL_11df, IL_11f2, IL_1200, IL_120e, IL_1257, IL_126b, IL_127e, IL_128c, IL_129a, IL_12da, IL_12ee, IL_1301, IL_130f, IL_131d, IL_132b, IL_1336, IL_134e, IL_135c, IL_1367, IL_1375, IL_1383, IL_13c1, IL_13d4, IL_13f1, IL_1429, IL_1445, IL_1453, IL_1461, IL_147a, IL_1488, IL_1496, IL_14a9, IL_14b7, IL_14c2, IL_14d0, IL_14e3, IL_14ec, IL_153e, IL_1551, IL_155f, IL_156d, IL_157b, IL_1589, IL_1594, IL_15ae, IL_15c1, IL_15cf, IL_15da, IL_15f7, IL_1636, IL_1649, IL_1657, IL_1665, IL_16a5, IL_16b9, IL_16d5, IL_16e3, IL_16f1, IL_1705, IL_1759, IL_1770, IL_1783, IL_1791, IL_179c, IL_17b0, IL_17ef, IL_180b, IL_1819, IL_1827, IL_1867, IL_187b, IL_188e, IL_1899, IL_18a7, IL_18c3, IL_18d1, IL_18df, IL_18f4, IL_1907, IL_1924, IL_1973, IL_197d, IL_19aa, IL_19be, IL_19d5, IL_19e8, IL_1a28, IL_1a45, IL_1a58, IL_1a6b, IL_1aac, IL_1ac0, IL_1ad3, IL_1ae7, IL_1b26, IL_1b39, IL_1b52, IL_1b60, IL_1b6e, IL_1b81, IL_1b8f, IL_1b9d, IL_1bb1, IL_1bf0, IL_1c0c, IL_1c1a, IL_1c28, IL_1c4c, IL_1c5a, IL_1c68, IL_1c7b, IL_1c89, IL_1c94, IL_1ca8, IL_1ce7, IL_1cfa, IL_1d08, IL_1d13, IL_1d21, IL_1d2f, IL_1d68, IL_1d7b, IL_1d84, IL_1da8, IL_1db6, IL_1dc4, IL_1dd7, IL_1de5, IL_1df3, IL_1e1c, IL_1e35, IL_1e43, IL_1e51, IL_1e5f, IL_1e6d, IL_1e81, IL_1ec0, IL_1ed3, IL_1eed, IL_1efb, IL_1f12, IL_1f25, IL_1f33, IL_1f41, IL_1f6a, IL_1f83, IL_1f91, IL_1f9f, IL_1faa, IL_1fb8, IL_1fdc, IL_1fea, IL_2006, IL_2014, IL_201f, IL_204d, IL_2060, IL_206e, IL_207c, IL_208a, IL_20ae, IL_20bc, IL_20d8, IL_20e6, IL_20f4, IL_211f, IL_2138, IL_2146, IL_2154, IL_21c2, IL_21d5, IL_21e3, IL_21f1, IL_222f, IL_2243, IL_2256, IL_2261, IL_226f, IL_2283, IL_22c2, IL_22d5, IL_22e3, IL_22f6, IL_22ff, IL_230a, IL_2322, IL_2330, IL_233e, IL_2351, IL_235f, IL_236d, IL_237b, IL_2389, IL_2397, IL_23a5, IL_23b9, IL_23f8, IL_240b, IL_2422, IL_2446, IL_2454, IL_2470, IL_247e, IL_248c, IL_24cd, IL_24e1, IL_24f4, IL_24fd, IL_2517, IL_252a, IL_2538, IL_2543, IL_2551, IL_2575, IL_2583, IL_2596, IL_25a4, IL_25b2, IL_25c6, IL_2605, IL_2618, IL_2623, IL_262e, IL_268c, IL_269c, IL_26b8, IL_26cb, IL_26d5, IL_26e0, IL_26f0, IL_2700, IL_2719, IL_2729, IL_2739, IL_2749, IL_2759, IL_2769, IL_2782 are reachable both inside and outside the pinned region starting at IL_2797. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 450;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			int __rxRef65 = default(int);
			ref int reference = ref __rxRef65;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2782:
					num2 = 1;
					while (true)
					{
						IL_2769:
						num3 = num2 * 4;
						num = 43;
						while (true)
						{
							IL_2759:
							num4 = num2 * 8;
							while (true)
							{
								IL_2749:
								array2 = new byte[7];
								while (true)
								{
									IL_2739:
									array3 = new object[7];
									while (true)
									{
										IL_2729:
										array4 = new int[7];
										while (true)
										{
											IL_2719:
											array5 = new int[7];
											while (true)
											{
												IL_2700:
												array6 = new long[7];
												num = 103;
												while (true)
												{
													IL_26f0:
													array7 = new object[14];
													while (true)
													{
														IL_26e0:
														array7[0] = this;
														while (true)
														{
															IL_26d5:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UpArrowBlock.ImporterEventKindgetOffsetToStringData);
															while (true)
															{
																IL_26cb:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0986:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0976:
																			ptr2++;
																			while (true)
																			{
																				IL_0966:
																				if (b >= 1)
																				{
																					while (b <= 65)
																					{
																						while (true)
																						{
																							IL_0949:
																							if (33 < b)
																							{
																								while (true)
																								{
																									IL_0939:
																									if (49 >= b)
																									{
																										while (true)
																										{
																											IL_0929:
																											if (49 > b)
																											{
																												while (true)
																												{
																													IL_0919:
																													if (41 >= b)
																													{
																														while (true)
																														{
																															IL_090c:
																															if (41 > b)
																															{
																																while (true)
																																{
																																	IL_08fc:
																																	if (37 < b)
																																	{
																																		while (true)
																																		{
																																			IL_08ec:
																																			if (39 >= b)
																																			{
																																				while (true)
																																				{
																																					IL_08dc:
																																					if (39 <= b)
																																					{
																																						while (true)
																																						{
																																							IL_08b1:
																																							array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																							while (true)
																																							{
																																								IL_0892:
																																								array2[num6 - 1] = 5;
																																								num = 540;
																																								while (num != 540)
																																								{
																																									if (num != 1521)
																																									{
																																										goto IL_207c;
																																									}
																																									switch (num)
																																									{
																																									case 450:
																																										break;
																																									default:
																																										continue;
																																									case 176:
																																										goto IL_0892;
																																									case 27:
																																									case 116:
																																										goto IL_08b1;
																																									case 307:
																																										goto IL_08dc;
																																									case 183:
																																										goto IL_08ec;
																																									case 304:
																																										goto IL_08fc;
																																									case 11:
																																										goto IL_090c;
																																									case 396:
																																										goto IL_0919;
																																									case 351:
																																										goto IL_0929;
																																									case 303:
																																										goto IL_0939;
																																									case 75:
																																										goto IL_0949;
																																									case 484:
																																										goto IL_0956;
																																									case 57:
																																										goto IL_0966;
																																									case 297:
																																										goto IL_0976;
																																									case 393:
																																									case 465:
																																										goto IL_0986;
																																									case 13:
																																									case 26:
																																										goto IL_0991;
																																									case 49:
																																										goto IL_09ba;
																																									case 50:
																																										goto IL_09d3;
																																									case 85:
																																										goto IL_09e3;
																																									case 76:
																																									case 187:
																																										goto IL_09f0;
																																									case 111:
																																										goto IL_0a30;
																																									case 178:
																																										goto IL_0a44;
																																									case 66:
																																									case 202:
																																										goto IL_0a57;
																																									case 269:
																																										goto IL_0a6d;
																																									case 270:
																																										goto IL_0a78;
																																									case 37:
																																										goto IL_0a86;
																																									case 388:
																																										goto IL_0a96;
																																									case 392:
																																										goto IL_0aa9;
																																									case 263:
																																										goto IL_0ae8;
																																									case 163:
																																									case 462:
																																										goto IL_0afb;
																																									case 378:
																																										goto IL_0b0f;
																																									case 438:
																																										goto IL_0b47;
																																									case 262:
																																									case 466:
																																										goto IL_0b5a;
																																									case 25:
																																										goto IL_0b6e;
																																									case 299:
																																										goto IL_0be9;
																																									case 429:
																																										goto IL_0bf7;
																																									case 481:
																																										goto IL_0c0a;
																																									case 86:
																																										goto IL_0c18;
																																									case 405:
																																									case 424:
																																										goto IL_0c26;
																																									case 427:
																																										goto IL_0c34;
																																									case 237:
																																										goto IL_0c52;
																																									case 249:
																																										goto IL_0c60;
																																									case 118:
																																									case 499:
																																										goto IL_0c73;
																																									case 322:
																																										goto IL_0c87;
																																									case 83:
																																										goto IL_0cbf;
																																									case 515:
																																										goto IL_0cd2;
																																									case 7:
																																										goto IL_0ce0;
																																									case 261:
																																									case 417:
																																										goto IL_0ceb;
																																									case 180:
																																										goto IL_0cf9;
																																									case 314:
																																										goto IL_0d11;
																																									case 482:
																																										goto IL_0d1f;
																																									case 114:
																																										goto IL_0d32;
																																									case 160:
																																										goto IL_0d40;
																																									case 130:
																																										goto IL_0d4e;
																																									case 436:
																																										goto IL_0d5c;
																																									case 213:
																																										goto IL_0d6a;
																																									case 38:
																																									case 470:
																																										goto IL_0d75;
																																									case 64:
																																										goto IL_0dd7;
																																									case 240:
																																										goto IL_0dea;
																																									case 309:
																																										goto IL_0df8;
																																									case 406:
																																										goto IL_0e0b;
																																									case 315:
																																										goto IL_0e19;
																																									case 421:
																																										goto IL_0e3a;
																																									case 265:
																																										goto IL_0e48;
																																									case 193:
																																									case 486:
																																										goto IL_0e53;
																																									case 302:
																																										goto IL_0e7c;
																																									case 394:
																																										goto IL_0e95;
																																									case 216:
																																										goto IL_0eac;
																																									case 171:
																																									case 506:
																																										goto IL_0eba;
																																									case 264:
																																										goto IL_0ed8;
																																									case 204:
																																										goto IL_0ee6;
																																									case 272:
																																										goto IL_0ef9;
																																									case 140:
																																										goto IL_0f07;
																																									case 295:
																																									case 318:
																																										goto IL_0f15;
																																									case 480:
																																										goto IL_0f2d;
																																									case 149:
																																										goto IL_0f4b;
																																									case 358:
																																										goto IL_0f6f;
																																									case 179:
																																										goto IL_0f87;
																																									case 399:
																																										goto IL_0fa3;
																																									case 208:
																																									case 211:
																																										goto IL_0fae;
																																									case 247:
																																										goto IL_0fc1;
																																									case 47:
																																										goto IL_0fcf;
																																									case 218:
																																									case 319:
																																										goto IL_0fda;
																																									case 440:
																																										goto IL_0fe8;
																																									case 70:
																																										goto IL_100b;
																																									case 474:
																																										goto IL_1015;
																																									case 89:
																																										goto IL_1023;
																																									case 123:
																																										goto IL_1036;
																																									case 376:
																																										goto IL_1044;
																																									case 418:
																																									case 483:
																																										goto IL_104f;
																																									case 402:
																																										goto IL_108f;
																																									case 78:
																																										goto IL_10a8;
																																									case 127:
																																										goto IL_10b6;
																																									case 115:
																																									case 364:
																																										goto IL_10c4;
																																									case 343:
																																										goto IL_10dd;
																																									case 362:
																																										goto IL_10eb;
																																									case 371:
																																										goto IL_10f9;
																																									case 340:
																																										goto IL_110c;
																																									case 5:
																																										goto IL_111a;
																																									case 52:
																																									case 164:
																																										goto IL_1128;
																																									case 349:
																																										goto IL_1151;
																																									case 231:
																																										goto IL_115f;
																																									case 448:
																																										goto IL_1172;
																																									case 143:
																																										goto IL_1180;
																																									case 372:
																																									case 426:
																																										goto IL_118b;
																																									case 190:
																																										goto IL_11cb;
																																									case 131:
																																										goto IL_11df;
																																									case 254:
																																										goto IL_11f2;
																																									case 226:
																																										goto IL_1200;
																																									case 23:
																																									case 203:
																																										goto IL_120e;
																																									case 24:
																																										goto IL_1257;
																																									case 478:
																																										goto IL_126b;
																																									case 395:
																																										goto IL_127e;
																																									case 106:
																																										goto IL_128c;
																																									case 69:
																																									case 447:
																																										goto IL_129a;
																																									case 99:
																																										goto IL_12da;
																																									case 233:
																																										goto IL_12ee;
																																									case 46:
																																										goto IL_1301;
																																									case 290:
																																										goto IL_130f;
																																									case 281:
																																										goto IL_131d;
																																									case 390:
																																										goto IL_132b;
																																									case 31:
																																									case 456:
																																										goto IL_1336;
																																									case 18:
																																										goto IL_134e;
																																									case 458:
																																										goto IL_135c;
																																									case 144:
																																										goto IL_1367;
																																									case 313:
																																										goto IL_1375;
																																									case 154:
																																									case 398:
																																										goto IL_1383;
																																									case 369:
																																										goto IL_13c1;
																																									case 288:
																																									case 490:
																																										goto IL_13d4;
																																									case 124:
																																										goto IL_13f1;
																																									case 275:
																																										goto IL_1429;
																																									case 268:
																																										goto IL_1445;
																																									case 194:
																																										goto IL_1453;
																																									case 419:
																																									case 454:
																																										goto IL_1461;
																																									case 30:
																																										goto IL_147a;
																																									case 15:
																																										goto IL_1488;
																																									case 185:
																																										goto IL_1496;
																																									case 56:
																																										goto IL_14a9;
																																									case 212:
																																										goto IL_14b7;
																																									case 414:
																																										goto IL_14c2;
																																									case 148:
																																										goto IL_14d0;
																																									case 12:
																																									case 181:
																																										goto IL_14ec;
																																									case 334:
																																										goto IL_153e;
																																									case 445:
																																										goto IL_1551;
																																									case 374:
																																										goto IL_155f;
																																									case 232:
																																										goto IL_157b;
																																									case 44:
																																										goto IL_1589;
																																									case 132:
																																									case 479:
																																										goto IL_1594;
																																									case 271:
																																										goto IL_15ae;
																																									case 227:
																																										goto IL_15c1;
																																									case 60:
																																										goto IL_15cf;
																																									case 201:
																																									case 407:
																																										goto IL_15da;
																																									case 472:
																																										goto IL_15f7;
																																									case 379:
																																										goto IL_1636;
																																									case 80:
																																										goto IL_1649;
																																									case 42:
																																										goto IL_1657;
																																									case 241:
																																									case 381:
																																										goto IL_1665;
																																									case 476:
																																										goto IL_16a5;
																																									case 434:
																																										goto IL_16b9;
																																									case 428:
																																										goto IL_16d5;
																																									case 84:
																																										goto IL_16e3;
																																									case 156:
																																									case 189:
																																										goto IL_16f1;
																																									case 339:
																																										goto IL_1705;
																																									case 415:
																																										goto IL_1759;
																																									case 278:
																																										goto IL_1770;
																																									case 117:
																																										goto IL_1783;
																																									case 452:
																																										goto IL_1791;
																																									case 250:
																																									case 383:
																																										goto IL_179c;
																																									case 182:
																																										goto IL_17b0;
																																									case 67:
																																										goto IL_17ef;
																																									case 459:
																																										goto IL_180b;
																																									case 40:
																																										goto IL_1819;
																																									case 200:
																																									case 510:
																																										goto IL_1827;
																																									case 74:
																																										goto IL_1867;
																																									case 507:
																																										goto IL_187b;
																																									case 196:
																																										goto IL_188e;
																																									case 14:
																																										goto IL_1899;
																																									case 338:
																																									case 511:
																																										goto IL_18a7;
																																									case 285:
																																										goto IL_18c3;
																																									case 8:
																																										goto IL_18d1;
																																									case 129:
																																									case 495:
																																										goto IL_18df;
																																									case 206:
																																										goto IL_18f4;
																																									case 397:
																																									case 518:
																																										goto IL_1907;
																																									case 17:
																																										goto IL_19be;
																																									case 253:
																																										goto IL_19d5;
																																									case 346:
																																									case 519:
																																										goto IL_19e8;
																																									case 308:
																																										goto IL_1a28;
																																									case 228:
																																										goto IL_1a45;
																																									case 524:
																																										goto IL_1a58;
																																									case 55:
																																									case 526:
																																										goto IL_1a6b;
																																									case 100:
																																										goto IL_1aac;
																																									case 120:
																																										goto IL_1ac0;
																																									case 94:
																																									case 529:
																																										goto IL_1ad3;
																																									case 135:
																																										goto IL_1ae7;
																																									case 350:
																																										goto IL_1b26;
																																									case 223:
																																									case 530:
																																										goto IL_1b39;
																																									case 224:
																																										goto IL_1b52;
																																									case 354:
																																										goto IL_1b60;
																																									case 257:
																																										goto IL_1b6e;
																																									case 508:
																																										goto IL_1b81;
																																									case 501:
																																										goto IL_1b8f;
																																									case 142:
																																									case 256:
																																										goto IL_1b9d;
																																									case 375:
																																										goto IL_1bb1;
																																									case 141:
																																										goto IL_1bf0;
																																									case 382:
																																										goto IL_1c0c;
																																									case 489:
																																										goto IL_1c1a;
																																									case 53:
																																									case 366:
																																										goto IL_1c28;
																																									case 289:
																																										goto IL_1c4c;
																																									case 82:
																																										goto IL_1c5a;
																																									case 72:
																																										goto IL_1c68;
																																									case 6:
																																										goto IL_1c7b;
																																									case 355:
																																										goto IL_1c89;
																																									case 248:
																																									case 333:
																																										goto IL_1c94;
																																									case 177:
																																										goto IL_1ca8;
																																									case 175:
																																										goto IL_1ce7;
																																									case 521:
																																										goto IL_1cfa;
																																									case 348:
																																										goto IL_1d08;
																																									case 158:
																																										goto IL_1d13;
																																									case 401:
																																										goto IL_1d21;
																																									case 225:
																																									case 527:
																																										goto IL_1d2f;
																																									case 239:
																																										goto IL_1d68;
																																									case 425:
																																									case 442:
																																										goto IL_1d84;
																																									case 195:
																																										goto IL_1da8;
																																									case 244:
																																										goto IL_1db6;
																																									case 352:
																																										goto IL_1dc4;
																																									case 90:
																																										goto IL_1dd7;
																																									case 147:
																																										goto IL_1de5;
																																									case 162:
																																									case 491:
																																										goto IL_1df3;
																																									case 186:
																																										goto IL_1e1c;
																																									case 242:
																																										goto IL_1e35;
																																									case 97:
																																										goto IL_1e43;
																																									case 410:
																																										goto IL_1e51;
																																									case 68:
																																										goto IL_1e5f;
																																									case 287:
																																									case 514:
																																										goto IL_1e6d;
																																									case 477:
																																										goto IL_1e81;
																																									case 485:
																																										goto IL_1ec0;
																																									case 471:
																																									case 502:
																																										goto IL_1ed3;
																																									case 493:
																																										goto IL_1eed;
																																									case 168:
																																										goto IL_1efb;
																																									case 10:
																																										goto IL_1f12;
																																									case 113:
																																										goto IL_1f25;
																																									case 523:
																																										goto IL_1f33;
																																									case 219:
																																									case 361:
																																										goto IL_1f41;
																																									case 63:
																																										goto IL_1f6a;
																																									case 469:
																																										goto IL_1f83;
																																									case 222:
																																										goto IL_1f91;
																																									case 36:
																																										goto IL_1f9f;
																																									case 155:
																																									case 359:
																																										goto IL_1faa;
																																									case 326:
																																										goto IL_1fb8;
																																									case 32:
																																										goto IL_1fdc;
																																									case 152:
																																										goto IL_1fea;
																																									case 443:
																																										goto IL_2006;
																																									case 19:
																																										goto IL_2014;
																																									case 292:
																																									case 420:
																																										goto IL_201f;
																																									case 377:
																																										goto IL_204d;
																																									case 62:
																																										goto IL_2060;
																																									case 9:
																																										goto IL_206e;
																																									case 73:
																																									case 435:
																																										goto IL_207c;
																																									case 96:
																																										goto IL_208a;
																																									case 512:
																																										goto IL_20ae;
																																									case 403:
																																										goto IL_20bc;
																																									case 296:
																																										goto IL_20d8;
																																									case 20:
																																										goto IL_20e6;
																																									case 71:
																																									case 525:
																																										goto IL_20f4;
																																									case 531:
																																										goto IL_211f;
																																									case 497:
																																										goto IL_2138;
																																									case 61:
																																										goto IL_2146;
																																									case 35:
																																									case 251:
																																										goto IL_2154;
																																									case 505:
																																										goto IL_21c2;
																																									case 380:
																																										goto IL_21d5;
																																									case 500:
																																										goto IL_21e3;
																																									case 137:
																																									case 400:
																																										goto IL_21f1;
																																									case 107:
																																										goto IL_222f;
																																									case 441:
																																										goto IL_2243;
																																									case 277:
																																										goto IL_2256;
																																									case 363:
																																										goto IL_2261;
																																									case 91:
																																									case 209:
																																										goto IL_226f;
																																									case 325:
																																										goto IL_2283;
																																									case 229:
																																										goto IL_22c2;
																																									case 279:
																																										goto IL_22d5;
																																									case 273:
																																										goto IL_22e3;
																																									case 4:
																																										goto IL_22ff;
																																									case 169:
																																									case 520:
																																										goto IL_230a;
																																									case 161:
																																										goto IL_2322;
																																									case 16:
																																										goto IL_2330;
																																									case 503:
																																										goto IL_233e;
																																									case 51:
																																										goto IL_2351;
																																									case 412:
																																										goto IL_235f;
																																									case 101:
																																										goto IL_236d;
																																									case 356:
																																										goto IL_237b;
																																									case 373:
																																										goto IL_2389;
																																									case 342:
																																										goto IL_2397;
																																									case 45:
																																									case 199:
																																										goto IL_23a5;
																																									case 33:
																																										goto IL_23b9;
																																									case 284:
																																										goto IL_23f8;
																																									case 54:
																																									case 457:
																																										goto IL_240b;
																																									case 437:
																																										goto IL_2422;
																																									case 157:
																																										goto IL_2446;
																																									case 423:
																																										goto IL_2454;
																																									case 320:
																																										goto IL_2470;
																																									case 22:
																																										goto IL_247e;
																																									case 0:
																																									case 105:
																																										goto IL_248c;
																																									case 274:
																																										goto IL_24cd;
																																									case 153:
																																										goto IL_24e1;
																																									case 102:
																																									case 367:
																																										goto IL_24fd;
																																									case 327:
																																										goto IL_2517;
																																									case 444:
																																										goto IL_252a;
																																									case 286:
																																										goto IL_2538;
																																									case 409:
																																									case 473:
																																										goto IL_2543;
																																									case 188:
																																										goto IL_2551;
																																									case 330:
																																										goto IL_2575;
																																									case 345:
																																										goto IL_2583;
																																									case 300:
																																										goto IL_2596;
																																									case 453:
																																										goto IL_25a4;
																																									case 234:
																																									case 475:
																																										goto IL_25b2;
																																									case 58:
																																										goto IL_25c6;
																																									case 236:
																																										goto IL_2605;
																																									case 463:
																																										goto IL_2618;
																																									case 360:
																																										goto IL_2623;
																																									case 294:
																																									case 365:
																																										goto IL_262e;
																																									case 191:
																																										goto IL_268c;
																																									case 1:
																																									case 3:
																																									case 28:
																																									case 34:
																																									case 41:
																																									case 77:
																																									case 95:
																																									case 108:
																																									case 112:
																																									case 119:
																																									case 122:
																																									case 125:
																																									case 133:
																																									case 139:
																																									case 145:
																																									case 146:
																																									case 150:
																																									case 151:
																																									case 159:
																																									case 165:
																																									case 166:
																																									case 173:
																																									case 192:
																																									case 197:
																																									case 198:
																																									case 205:
																																									case 207:
																																									case 210:
																																									case 217:
																																									case 220:
																																									case 230:
																																									case 235:
																																									case 245:
																																									case 246:
																																									case 267:
																																									case 291:
																																									case 293:
																																									case 298:
																																									case 301:
																																									case 311:
																																									case 312:
																																									case 323:
																																									case 324:
																																									case 332:
																																									case 336:
																																									case 347:
																																									case 357:
																																									case 368:
																																									case 384:
																																									case 385:
																																									case 386:
																																									case 387:
																																									case 389:
																																									case 404:
																																									case 408:
																																									case 416:
																																									case 432:
																																									case 451:
																																									case 455:
																																									case 460:
																																									case 461:
																																									case 468:
																																									case 494:
																																									case 496:
																																									case 504:
																																									case 509:
																																									case 516:
																																									case 528:
																																										goto end_IL_0956;
																																									case 2:
																																									case 21:
																																									case 29:
																																									case 39:
																																									case 48:
																																									case 59:
																																									case 79:
																																									case 88:
																																									case 92:
																																									case 93:
																																									case 98:
																																									case 104:
																																									case 109:
																																									case 110:
																																									case 126:
																																									case 128:
																																									case 134:
																																									case 136:
																																									case 138:
																																									case 167:
																																									case 170:
																																									case 172:
																																									case 174:
																																									case 184:
																																									case 214:
																																									case 221:
																																									case 252:
																																									case 255:
																																									case 258:
																																									case 259:
																																									case 260:
																																									case 266:
																																									case 276:
																																									case 280:
																																									case 282:
																																									case 283:
																																									case 305:
																																									case 306:
																																									case 310:
																																									case 316:
																																									case 317:
																																									case 321:
																																									case 328:
																																									case 329:
																																									case 331:
																																									case 335:
																																									case 337:
																																									case 341:
																																									case 353:
																																									case 370:
																																									case 391:
																																									case 413:
																																									case 422:
																																									case 430:
																																									case 431:
																																									case 433:
																																									case 439:
																																									case 446:
																																									case 464:
																																									case 467:
																																									case 487:
																																									case 488:
																																									case 498:
																																									case 513:
																																									case 522:
																																									case 532:
																																									case 533:
																																										goto end_IL_087f;
																																									case 87:
																																										goto IL_26cb;
																																									case 238:
																																										goto IL_26d5;
																																									case 492:
																																										goto IL_26e0;
																																									case 103:
																																										goto IL_26f0;
																																									case 517:
																																										goto IL_2700;
																																									case 81:
																																										goto IL_2719;
																																									case 411:
																																										goto IL_2729;
																																									case 344:
																																										goto IL_2739;
																																									case 243:
																																										goto IL_2749;
																																									case 43:
																																										goto IL_2759;
																																									case 65:
																																										goto IL_2769;
																																									case 449:
																																										goto IL_2782;
																																									case 121:
																																									case 215:
																																										return;
																																									}
																																									goto end_IL_26b8;
																																									continue;
																																									end_IL_087f:
																																									break;
																																								}
																																								break;
																																							}
																																							break;
																																						}
																																						break;
																																					}
																																					goto IL_1b81;
																																					IL_1bf0:
																																					ptr2 += 8;
																																					num = 282;
																																					break;
																																					IL_1b81:
																																					if (38 < b)
																																					{
																																						goto end_IL_0956;
																																					}
																																					goto IL_1b8f;
																																					IL_1b8f:
																																					if (38 > b)
																																					{
																																						goto end_IL_0956;
																																					}
																																					goto IL_1b9d;
																																					IL_1b9d:
																																					array2[num6 - 1] = 0;
																																					goto IL_1bb1;
																																					IL_1bb1:
																																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																					goto IL_1bf0;
																																				}
																																				break;
																																			}
																																			goto IL_1c0c;
																																			IL_1c68:
																																			ptr2 += 8;
																																			break;
																																			IL_1c0c:
																																			if (40 < b)
																																			{
																																				goto end_IL_0956;
																																			}
																																			goto IL_1c1a;
																																			IL_1c1a:
																																			if (40 > b)
																																			{
																																				goto end_IL_0956;
																																			}
																																			goto IL_1c28;
																																			IL_1c28:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																																			goto IL_1c4c;
																																			IL_1c4c:
																																			array2[num6] = 0;
																																			goto IL_1c5a;
																																			IL_1c5a:
																																			num6++;
																																			goto IL_1c68;
																																		}
																																		break;
																																	}
																																	goto IL_09e3;
																																	IL_0c60:
																																	ptr2 += 8;
																																	break;
																																	IL_09e3:
																																	if (37 <= b)
																																	{
																																		goto IL_0a57;
																																	}
																																	goto IL_0a6d;
																																	IL_0a57:
																																	array2[num6 - 1] = 3;
																																	goto IL_0aa9;
																																	IL_0aa9:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																	goto IL_0ae8;
																																	IL_0ae8:
																																	ptr2 += 8;
																																	break;
																																	IL_0a6d:
																																	if (35 < b)
																																	{
																																		goto IL_0a78;
																																	}
																																	goto IL_0a96;
																																	IL_0a78:
																																	if (36 < b)
																																	{
																																		goto end_IL_0956;
																																	}
																																	goto IL_0a86;
																																	IL_0a86:
																																	if (36 > b)
																																	{
																																		goto end_IL_0956;
																																	}
																																	goto IL_0afb;
																																	IL_0afb:
																																	array2[num6 - 1] = 5;
																																	goto IL_0b0f;
																																	IL_0b0f:
																																	array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
																																	goto IL_0b47;
																																	IL_0b47:
																																	ptr2 += 8;
																																	break;
																																	IL_0a96:
																																	if (35 > b)
																																	{
																																		goto IL_0c0a;
																																	}
																																	goto IL_0c73;
																																	IL_0c73:
																																	array2[num6 - 1] = 5;
																																	goto IL_0c87;
																																	IL_0c87:
																																	array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																																	goto IL_0cbf;
																																	IL_0cbf:
																																	ptr2 += 8;
																																	break;
																																	IL_0c0a:
																																	if (34 < b)
																																	{
																																		goto end_IL_0956;
																																	}
																																	goto IL_0c18;
																																	IL_0c18:
																																	if (34 > b)
																																	{
																																		goto end_IL_0956;
																																	}
																																	goto IL_0c26;
																																	IL_0c26:
																																	array2[num6] = 5;
																																	goto IL_0c34;
																																	IL_0c34:
																																	array3[num6] = ((delegate*<GorillaTagger>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																																	goto IL_0c52;
																																	IL_0c52:
																																	num6++;
																																	goto IL_0c60;
																																}
																																break;
																															}
																															goto IL_0991;
																															IL_09ba:
																															array2[num6 - 1] = 5;
																															break;
																															IL_0991:
																															array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_09ba;
																														}
																														break;
																													}
																													goto IL_1c7b;
																													IL_1f41:
																													array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_1f6a;
																													IL_1c7b:
																													if (45 >= b)
																													{
																														goto IL_1c89;
																													}
																													goto IL_1e35;
																													IL_1c89:
																													if (45 <= b)
																													{
																														goto IL_1c94;
																													}
																													goto IL_1cfa;
																													IL_1c94:
																													array2[num6 - 1] = 3;
																													goto IL_1ca8;
																													IL_1ca8:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_1ce7;
																													IL_1ce7:
																													ptr2 += 8;
																													break;
																													IL_1cfa:
																													if (43 >= b)
																													{
																														goto IL_1d08;
																													}
																													goto IL_1dd7;
																													IL_1d08:
																													if (43 > b)
																													{
																														goto IL_1d13;
																													}
																													num = 425;
																													goto IL_1d84;
																													IL_1d13:
																													if (42 < b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1d21;
																													IL_1d21:
																													if (42 > b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1d2f;
																													IL_1d2f:
																													((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																													goto IL_1d68;
																													IL_1d68:
																													num6 -= 3;
																													break;
																													IL_1f6a:
																													array2[num6 - 1] = 5;
																													break;
																													IL_1d84:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])() ? 1 : 0);
																													goto IL_1da8;
																													IL_1da8:
																													array2[num6] = 0;
																													goto IL_1db6;
																													IL_1db6:
																													num6++;
																													goto IL_1dc4;
																													IL_1dc4:
																													ptr2 += 8;
																													break;
																													IL_1dd7:
																													if (44 < b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1de5;
																													IL_1de5:
																													if (44 > b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1df3;
																													IL_1df3:
																													array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																													goto IL_1e1c;
																													IL_1e1c:
																													array2[num6 - 1] = 5;
																													break;
																													IL_1e35:
																													if (47 >= b)
																													{
																														goto IL_1e43;
																													}
																													goto IL_1f25;
																													IL_1e43:
																													if (47 > b)
																													{
																														goto IL_1e51;
																													}
																													goto IL_1ed3;
																													IL_1e51:
																													if (46 < b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1e5f;
																													IL_1e5f:
																													if (46 > b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1e6d;
																													IL_1e6d:
																													array2[num6 - 1] = 0;
																													goto IL_1e81;
																													IL_1e81:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_1ec0;
																													IL_1ec0:
																													ptr2 += 8;
																													break;
																													IL_1ed3:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																													goto IL_1eed;
																													IL_1eed:
																													array2[num6] = 3;
																													goto IL_1efb;
																													IL_1efb:
																													num6++;
																													num = 10;
																													goto IL_1f12;
																													IL_1f12:
																													ptr2 += 8;
																													break;
																													IL_1f25:
																													if (48 < b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1f33;
																													IL_1f33:
																													if (48 > b)
																													{
																														goto end_IL_0956;
																													}
																													goto IL_1f41;
																												}
																												break;
																											}
																											goto IL_0b5a;
																											IL_0bf7:
																											ptr2 += 8;
																											break;
																											IL_0b5a:
																											array2[num6 - 4] = 0;
																											goto IL_0b6e;
																											IL_0b6e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
																											goto IL_0be9;
																											IL_0be9:
																											num6 -= 3;
																											goto IL_0bf7;
																										}
																										break;
																									}
																									goto IL_1f83;
																									IL_2623:
																									if (56 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_262e;
																									IL_1f83:
																									if (57 < b)
																									{
																										goto IL_1f91;
																									}
																									num = 4;
																									goto IL_22ff;
																									IL_1f91:
																									if (61 >= b)
																									{
																										goto IL_1f9f;
																									}
																									goto IL_2138;
																									IL_1f9f:
																									if (61 <= b)
																									{
																										goto IL_1faa;
																									}
																									goto IL_2006;
																									IL_1faa:
																									array2[num6] = 3;
																									goto IL_1fb8;
																									IL_1fb8:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																									goto IL_1fdc;
																									IL_1fdc:
																									num6++;
																									goto IL_1fea;
																									IL_1fea:
																									ptr2 += 8;
																									num = 306;
																									break;
																									IL_2006:
																									if (59 >= b)
																									{
																										goto IL_2014;
																									}
																									goto IL_20d8;
																									IL_2014:
																									if (59 <= b)
																									{
																										goto IL_201f;
																									}
																									goto IL_2060;
																									IL_201f:
																									((Class15)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_204d;
																									IL_204d:
																									num6 -= 2;
																									break;
																									IL_2060:
																									if (58 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_206e;
																									IL_206e:
																									if (58 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_207c;
																									IL_207c:
																									array2[num6] = 3;
																									goto IL_208a;
																									IL_208a:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																									goto IL_20ae;
																									IL_20ae:
																									num6++;
																									goto IL_20bc;
																									IL_20bc:
																									ptr2 += 8;
																									num = 39;
																									break;
																									IL_20d8:
																									if (60 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_20e6;
																									IL_20e6:
																									if (60 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_20f4;
																									IL_20f4:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_211f;
																									IL_211f:
																									array2[num6 - 1] = 0;
																									break;
																									IL_2138:
																									if (63 >= b)
																									{
																										goto IL_2146;
																									}
																									goto IL_2256;
																									IL_2146:
																									if (63 <= b)
																									{
																										goto IL_2154;
																									}
																									goto IL_21d5;
																									IL_2154:
																									ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_21c2;
																									IL_21c2:
																									num6 -= 2;
																									break;
																									IL_21d5:
																									if (62 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_21e3;
																									IL_21e3:
																									if (62 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_21f1;
																									IL_21f1:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class15, float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((Class15)array3[num6 - 1]);
																									goto IL_222f;
																									IL_222f:
																									array2[num6 - 1] = 3;
																									goto IL_2243;
																									IL_2243:
																									ptr2 += 8;
																									break;
																									IL_2256:
																									if (64 >= b)
																									{
																										goto IL_2261;
																									}
																									goto IL_22d5;
																									IL_2261:
																									if (64 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_226f;
																									IL_226f:
																									array2[num6 - 1] = 3;
																									goto IL_2283;
																									IL_2283:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_22c2;
																									IL_22c2:
																									ptr2 += 8;
																									break;
																									IL_22d5:
																									if (65 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_22e3;
																									IL_22e3:
																									if (65 > b)
																									{
																									}
																									goto end_IL_0956;
																									IL_262e:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_268c;
																									IL_22ff:
																									if (57 <= b)
																									{
																										goto IL_230a;
																									}
																									goto IL_2351;
																									IL_230a:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									goto IL_2322;
																									IL_2322:
																									array2[num6] = 5;
																									goto IL_2330;
																									IL_2330:
																									num6++;
																									goto IL_233e;
																									IL_233e:
																									ptr2 += 8;
																									break;
																									IL_2351:
																									if (53 >= b)
																									{
																										goto IL_235f;
																									}
																									goto IL_252a;
																									IL_235f:
																									if (53 > b)
																									{
																										goto IL_236d;
																									}
																									num = 102;
																									goto IL_24fd;
																									IL_236d:
																									if (51 >= b)
																									{
																										goto IL_237b;
																									}
																									goto IL_2470;
																									IL_237b:
																									if (51 > b)
																									{
																										goto IL_2389;
																									}
																									goto IL_240b;
																									IL_2389:
																									if (50 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_2397;
																									IL_2397:
																									if (50 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_23a5;
																									IL_23a5:
																									array2[num6 - 1] = 3;
																									goto IL_23b9;
																									IL_23b9:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_23f8;
																									IL_23f8:
																									ptr2 += 8;
																									break;
																									IL_240b:
																									array2[num6] = 3;
																									num = 437;
																									goto IL_2422;
																									IL_2422:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																									goto IL_2446;
																									IL_2446:
																									num6++;
																									goto IL_2454;
																									IL_2454:
																									ptr2 += 8;
																									num = 136;
																									break;
																									IL_2470:
																									if (52 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_247e;
																									IL_247e:
																									if (52 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_248c;
																									IL_248c:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) > *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																									goto IL_24cd;
																									IL_24cd:
																									array2[num6 - 2] = 0;
																									goto IL_24e1;
																									IL_24e1:
																									num6--;
																									break;
																									IL_268c:
																									num6--;
																									break;
																									IL_24fd:
																									global::_003CModule_003E.bool_27 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																									goto IL_2517;
																									IL_2517:
																									num6--;
																									break;
																									IL_252a:
																									if (55 >= b)
																									{
																										goto IL_2538;
																									}
																									goto IL_2618;
																									IL_2538:
																									if (55 <= b)
																									{
																										goto IL_2543;
																									}
																									goto IL_2596;
																									IL_2543:
																									array2[num6] = 0;
																									goto IL_2551;
																									IL_2551:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_2575;
																									IL_2575:
																									num6++;
																									goto IL_2583;
																									IL_2583:
																									ptr2 += 8;
																									break;
																									IL_2596:
																									if (54 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_25a4;
																									IL_25a4:
																									if (54 > b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_25b2;
																									IL_25b2:
																									array2[num6 - 1] = 3;
																									goto IL_25c6;
																									IL_25c6:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_2605;
																									IL_2605:
																									ptr2 += 8;
																									break;
																									IL_2618:
																									if (56 < b)
																									{
																										goto end_IL_0956;
																									}
																									goto IL_2623;
																								}
																								break;
																							}
																							goto IL_09d3;
																							IL_1867:
																							array2[num6 - 2] = 3;
																							goto IL_187b;
																							IL_09d3:
																							if (33 <= b)
																							{
																								goto IL_09f0;
																							}
																							goto IL_0cd2;
																							IL_09f0:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0a30;
																							IL_0a30:
																							array2[num6 - 2] = 3;
																							goto IL_0a44;
																							IL_0a44:
																							num6--;
																							break;
																							IL_0cd2:
																							if (16 >= b)
																							{
																								goto IL_0ce0;
																							}
																							goto IL_1301;
																							IL_0ce0:
																							if (16 <= b)
																							{
																								goto IL_0ceb;
																							}
																							goto IL_0d32;
																							IL_0ceb:
																							array2[num6] = 5;
																							goto IL_0cf9;
																							IL_0cf9:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_0d11;
																							IL_0d11:
																							num6++;
																							goto IL_0d1f;
																							IL_0d1f:
																							ptr2 += 8;
																							break;
																							IL_0d32:
																							if (8 < b)
																							{
																								goto IL_0d40;
																							}
																							num = 399;
																							goto IL_0fa3;
																							IL_0d40:
																							if (12 >= b)
																							{
																								goto IL_0d4e;
																							}
																							goto IL_0e3a;
																							IL_0d4e:
																							if (12 > b)
																							{
																								goto IL_0d5c;
																							}
																							num = 397;
																							goto IL_1907;
																							IL_0d5c:
																							if (10 >= b)
																							{
																								goto IL_0d6a;
																							}
																							goto IL_0e0b;
																							IL_0d6a:
																							if (10 <= b)
																							{
																								goto IL_0d75;
																							}
																							goto IL_0dea;
																							IL_0d75:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0dd7;
																							IL_0dd7:
																							num6 -= 2;
																							break;
																							IL_0dea:
																							if (9 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_0df8;
																							IL_0df8:
																							if (9 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_19e8;
																							IL_19e8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1a28;
																							IL_1a28:
																							array2[num6 - 2] = 0;
																							num = 228;
																							goto IL_1a45;
																							IL_1a45:
																							num6--;
																							break;
																							IL_0e0b:
																							if (11 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_0e19;
																							IL_0e19:
																							if (11 > b)
																							{
																								goto end_IL_0956;
																							}
																							break;
																							IL_188e:
																							if (31 >= b)
																							{
																								goto IL_1899;
																							}
																							goto IL_18c3;
																							IL_1907:
																							array8 = array3;
																							num7 = num6;
																							if (array == null)
																							{
																								goto IL_1916;
																							}
																							num8 = ptr2;
																							byte b2 = *num8;
																							ptr2 = num8 + 4;
																							int num9 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num9;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_19be;
																							IL_1899:
																							if (31 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_18a7;
																							IL_18a7:
																							num10 = ptr2;
																							num11 = -200;
																							num5 = 1;
																							ptr2 = num10 + num11;
																							break;
																							IL_18c3:
																							if (32 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_18d1;
																							IL_19be:
																							array2[num6] = 5;
																							num = 253;
																							goto IL_19d5;
																							IL_19d5:
																							num6++;
																							break;
																							IL_0e3a:
																							if (14 >= b)
																							{
																								goto IL_0e48;
																							}
																							goto IL_0ef9;
																							IL_0e48:
																							if (14 <= b)
																							{
																								goto IL_0e53;
																							}
																							goto IL_0e95;
																							IL_0e53:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_0e7c;
																							IL_0e7c:
																							array2[num6 - 1] = 5;
																							break;
																							IL_0e95:
																							if (13 < b)
																							{
																								goto end_IL_0956;
																							}
																							num = 216;
																							goto IL_0eac;
																							IL_18d1:
																							if (32 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_18df;
																							IL_0eac:
																							if (13 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_0eba;
																							IL_0eba:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_0ed8;
																							IL_0ed8:
																							ptr2 += 8;
																							goto IL_0ee6;
																							IL_0ee6:
																							num6--;
																							break;
																							IL_0ef9:
																							if (15 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_0f07;
																							IL_0f07:
																							if (15 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_0f15;
																							IL_0f15:
																							array2[num6] = array2[num6 - 1];
																							goto IL_0f2d;
																							IL_0f2d:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_0f4b;
																							IL_0f4b:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0f6f;
																							IL_0f6f:
																							array3[num6] = array3[num6 - 1];
																							goto IL_0f87;
																							IL_0f87:
																							num6++;
																							break;
																							IL_187b:
																							num6--;
																							break;
																							IL_0fa3:
																							if (8 <= b)
																							{
																								goto IL_0fae;
																							}
																							goto IL_0fc1;
																							IL_0fae:
																							num6--;
																							break;
																							IL_0fc1:
																							if (4 >= b)
																							{
																								goto IL_0fcf;
																							}
																							goto IL_1172;
																							IL_0fcf:
																							if (4 <= b)
																							{
																								goto IL_0fda;
																							}
																							goto IL_1036;
																							IL_0fda:
																							array2[num6] = 0;
																							goto IL_0fe8;
																							IL_0fe8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_100b;
																							IL_100b:
																							array3[num6] = null;
																							goto IL_1015;
																							IL_1015:
																							num6++;
																							goto IL_1023;
																							IL_1023:
																							ptr2 += 8;
																							break;
																							IL_1036:
																							if (2 >= b)
																							{
																								goto IL_1044;
																							}
																							goto IL_110c;
																							IL_1044:
																							if (2 <= b)
																							{
																								goto IL_104f;
																							}
																							goto IL_10a8;
																							IL_104f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_108f;
																							IL_108f:
																							array2[num6 - 2] = 0;
																							goto IL_1a58;
																							IL_1a58:
																							num6--;
																							break;
																							IL_10a8:
																							if (1 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_10b6;
																							IL_10b6:
																							if (1 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_10c4;
																							IL_10c4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_10dd;
																							IL_10dd:
																							array2[num6] = 0;
																							goto IL_10eb;
																							IL_10eb:
																							num6++;
																							goto IL_10f9;
																							IL_10f9:
																							ptr2 += 8;
																							break;
																							IL_110c:
																							if (3 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_111a;
																							IL_111a:
																							if (3 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1128;
																							IL_1128:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1151;
																							IL_1151:
																							ptr2 += 8;
																							goto IL_115f;
																							IL_115f:
																							num6--;
																							break;
																							IL_1172:
																							if (6 >= b)
																							{
																								goto IL_1180;
																							}
																							goto IL_127e;
																							IL_1180:
																							if (6 <= b)
																							{
																								goto IL_118b;
																							}
																							goto IL_11f2;
																							IL_118b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_11cb;
																							IL_11cb:
																							array2[num6 - 2] = 0;
																							goto IL_11df;
																							IL_11df:
																							num6--;
																							break;
																							IL_11f2:
																							if (5 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1200;
																							IL_1200:
																							if (5 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_120e;
																							IL_120e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 24;
																							goto IL_1257;
																							IL_1257:
																							array2[num6 - 2] = 0;
																							goto IL_126b;
																							IL_126b:
																							num6--;
																							break;
																							IL_127e:
																							if (7 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_128c;
																							IL_128c:
																							if (7 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_129a;
																							IL_129a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_12da;
																							IL_12da:
																							array2[num6 - 2] = 0;
																							goto IL_12ee;
																							IL_12ee:
																							num6--;
																							break;
																							IL_1301:
																							if (24 >= b)
																							{
																								goto IL_130f;
																							}
																							goto IL_157b;
																							IL_130f:
																							if (24 > b)
																							{
																								goto IL_131d;
																							}
																							goto IL_1ad3;
																							IL_131d:
																							if (20 >= b)
																							{
																								goto IL_132b;
																							}
																							goto IL_14a9;
																							IL_132b:
																							if (20 <= b)
																							{
																								goto IL_1336;
																							}
																							goto IL_134e;
																							IL_1336:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_134e:
																							if (18 >= b)
																							{
																								goto IL_135c;
																							}
																							goto IL_1445;
																							IL_135c:
																							if (18 > b)
																							{
																								goto IL_1367;
																							}
																							goto IL_13d4;
																							IL_1367:
																							if (17 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1375;
																							IL_1375:
																							if (17 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1383;
																							IL_1383:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_13c1;
																							IL_13c1:
																							num6 -= 3;
																							break;
																							IL_13d4:
																							array2[num6 - 1] = 5;
																							num = 124;
																							goto IL_13f1;
																							IL_13f1:
																							array3[num6 - 1] = ((delegate*<string[], string>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_1429;
																							IL_1429:
																							ptr2 += 8;
																							num = 446;
																							break;
																							IL_1445:
																							if (19 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1453;
																							IL_1453:
																							if (19 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1461;
																							IL_1461:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_147a;
																							IL_147a:
																							array2[num6] = 1;
																							goto IL_1488;
																							IL_1488:
																							num6++;
																							goto IL_1496;
																							IL_1496:
																							ptr2 += 16;
																							break;
																							IL_14a9:
																							if (22 >= b)
																							{
																								goto IL_14b7;
																							}
																							goto IL_1551;
																							IL_14b7:
																							if (22 > b)
																							{
																								goto IL_14c2;
																							}
																							num = 181;
																							goto IL_14ec;
																							IL_14c2:
																							if (21 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_14d0;
																							IL_14d0:
																							if (21 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1a6b;
																							IL_1a6b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_1aac;
																							IL_1aac:
																							array2[num6 - 2] = 0;
																							goto IL_1ac0;
																							IL_1ac0:
																							num6--;
																							break;
																							IL_18df:
																							((delegate*<void>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																							goto IL_18f4;
																							IL_14ec:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_153e;
																							IL_153e:
																							num6--;
																							break;
																							IL_1551:
																							if (23 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_155f;
																							IL_155f:
																							if (23 > b)
																							{
																								goto end_IL_0956;
																							}
																							num = 530;
																							goto IL_1b39;
																							IL_18f4:
																							ptr2 += 8;
																							break;
																							IL_1b39:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							goto IL_1b52;
																							IL_1b52:
																							array2[num6] = 3;
																							goto IL_1b60;
																							IL_1b60:
																							num6++;
																							goto IL_1b6e;
																							IL_1b6e:
																							ptr2 += 16;
																							break;
																							IL_1ad3:
																							array2[num6 - 1] = 3;
																							goto IL_1ae7;
																							IL_1ae7:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1b26;
																							IL_1b26:
																							ptr2 += 8;
																							break;
																							IL_157b:
																							if (28 >= b)
																							{
																								goto IL_1589;
																							}
																							goto IL_1783;
																							IL_1589:
																							if (28 <= b)
																							{
																								goto IL_1594;
																							}
																							goto IL_15c1;
																							IL_1594:
																							global::_003CModule_003E.int_59 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_15ae;
																							IL_15ae:
																							num6--;
																							break;
																							IL_15c1:
																							if (26 >= b)
																							{
																								goto IL_15cf;
																							}
																							goto IL_16d5;
																							IL_15cf:
																							if (26 <= b)
																							{
																								goto IL_15da;
																							}
																							goto IL_1649;
																							IL_15da:
																							array2[num6 - 1] = 0;
																							num = 472;
																							goto IL_15f7;
																							IL_15f7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1636;
																							IL_1636:
																							ptr2 += 8;
																							break;
																							IL_1649:
																							if (25 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1657;
																							IL_1657:
																							if (25 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1665;
																							IL_1665:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_16a5;
																							IL_16a5:
																							array2[num6 - 2] = 3;
																							goto IL_16b9;
																							IL_16b9:
																							num6--;
																							num = 93;
																							break;
																							IL_16d5:
																							if (27 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_16e3;
																							IL_16e3:
																							if (27 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_16f1;
																							IL_16f1:
																							array2[num6 - 2] = 0;
																							goto IL_1705;
																							IL_1705:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1759;
																							IL_1759:
																							num6--;
																							num = 278;
																							goto IL_1770;
																							IL_1770:
																							ptr2 += 8;
																							break;
																							IL_1783:
																							if (30 >= b)
																							{
																								goto IL_1791;
																							}
																							goto IL_188e;
																							IL_1791:
																							if (30 <= b)
																							{
																								goto IL_179c;
																							}
																							goto IL_180b;
																							IL_179c:
																							array2[num6 - 1] = 0;
																							goto IL_17b0;
																							IL_17b0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_17ef;
																							IL_17ef:
																							ptr2 += 8;
																							num = 328;
																							break;
																							IL_180b:
																							if (29 < b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1819;
																							IL_1819:
																							if (29 > b)
																							{
																								goto end_IL_0956;
																							}
																							goto IL_1827;
																							IL_1827:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1867;
																						}
																						goto end_IL_0966;
																						continue;
																						end_IL_0956:
																						break;
																						IL_0956:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 98;
																				break;
																				continue;
																				end_IL_0966:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_26b8:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1916:
			while (true)
			{
				IL_1916_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_19be_2:
						array2[num6] = 5;
						num = 253;
						while (true)
						{
							IL_19d5_2:
							num6++;
							while (true)
							{
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_0986_2:
									byte b = *ptr2;
									while (true)
									{
										IL_0976_2:
										ptr2++;
										while (true)
										{
											IL_0966_2:
											if (b >= 1)
											{
												while (b <= 65)
												{
													while (true)
													{
														IL_0949_2:
														if (33 < b)
														{
															while (true)
															{
																IL_0939_2:
																if (49 >= b)
																{
																	while (true)
																	{
																		IL_0929_2:
																		if (49 > b)
																		{
																			while (true)
																			{
																				IL_0919_2:
																				if (41 >= b)
																				{
																					while (true)
																					{
																						IL_090c_2:
																						if (41 > b)
																						{
																							while (true)
																							{
																								IL_08fc_2:
																								if (37 < b)
																								{
																									while (true)
																									{
																										IL_08ec_2:
																										if (39 >= b)
																										{
																											while (true)
																											{
																												IL_08dc_2:
																												if (39 <= b)
																												{
																													while (true)
																													{
																														IL_08b1_2:
																														array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																														while (true)
																														{
																															IL_0892_2:
																															array2[num6 - 1] = 5;
																															num = 540;
																															while (num != 540)
																															{
																																if (num != 1521)
																																{
																																	goto IL_207c_2;
																																}
																																switch (num)
																																{
																																case 176:
																																	goto IL_0892_2;
																																case 27:
																																case 116:
																																	goto IL_08b1_2;
																																case 307:
																																	goto IL_08dc_2;
																																case 183:
																																	goto IL_08ec_2;
																																case 304:
																																	goto IL_08fc_2;
																																case 11:
																																	goto IL_090c_2;
																																case 396:
																																	goto IL_0919_2;
																																case 351:
																																	goto IL_0929_2;
																																case 303:
																																	goto IL_0939_2;
																																case 75:
																																	goto IL_0949_2;
																																case 484:
																																	goto IL_0956_2;
																																case 57:
																																	goto IL_0966_2;
																																case 297:
																																	goto IL_0976_2;
																																case 393:
																																case 465:
																																	goto IL_0986_2;
																																case 13:
																																case 26:
																																	goto IL_0991_2;
																																case 49:
																																	goto IL_09ba_2;
																																case 50:
																																	goto IL_09d3_2;
																																case 85:
																																	goto IL_09e3_2;
																																case 76:
																																case 187:
																																	goto IL_09f0_2;
																																case 111:
																																	goto IL_0a30_2;
																																case 178:
																																	goto IL_0a44_2;
																																case 66:
																																case 202:
																																	goto IL_0a57_2;
																																case 269:
																																	goto IL_0a6d_2;
																																case 270:
																																	goto IL_0a78_2;
																																case 37:
																																	goto IL_0a86_2;
																																case 388:
																																	goto IL_0a96_2;
																																case 392:
																																	goto IL_0aa9_2;
																																case 263:
																																	goto IL_0ae8_2;
																																case 163:
																																case 462:
																																	goto IL_0afb_2;
																																case 378:
																																	goto IL_0b0f_2;
																																case 438:
																																	goto IL_0b47_2;
																																case 262:
																																case 466:
																																	goto IL_0b5a_2;
																																case 25:
																																	goto IL_0b6e_2;
																																case 299:
																																	goto IL_0be9_2;
																																case 429:
																																	goto IL_0bf7_2;
																																case 481:
																																	goto IL_0c0a_2;
																																case 86:
																																	goto IL_0c18_2;
																																case 405:
																																case 424:
																																	goto IL_0c26_2;
																																case 427:
																																	goto IL_0c34_2;
																																case 237:
																																	goto IL_0c52_2;
																																case 249:
																																	goto IL_0c60_2;
																																case 118:
																																case 499:
																																	goto IL_0c73_2;
																																case 322:
																																	goto IL_0c87_2;
																																case 83:
																																	goto IL_0cbf_2;
																																case 515:
																																	goto IL_0cd2_2;
																																case 7:
																																	goto IL_0ce0_2;
																																case 261:
																																case 417:
																																	goto IL_0ceb_2;
																																case 180:
																																	goto IL_0cf9_2;
																																case 314:
																																	goto IL_0d11_2;
																																case 482:
																																	goto IL_0d1f_2;
																																case 114:
																																	goto IL_0d32_2;
																																case 160:
																																	goto IL_0d40_2;
																																case 130:
																																	goto IL_0d4e_2;
																																case 436:
																																	goto IL_0d5c_2;
																																case 213:
																																	goto IL_0d6a_2;
																																case 38:
																																case 470:
																																	goto IL_0d75_2;
																																case 64:
																																	goto IL_0dd7_2;
																																case 240:
																																	goto IL_0dea_2;
																																case 309:
																																	goto IL_0df8_2;
																																case 406:
																																	goto IL_0e0b_2;
																																case 315:
																																	goto IL_0e19_2;
																																case 421:
																																	goto IL_0e3a_2;
																																case 265:
																																	goto IL_0e48_2;
																																case 193:
																																case 486:
																																	goto IL_0e53_2;
																																case 302:
																																	goto IL_0e7c_2;
																																case 394:
																																	goto IL_0e95_2;
																																case 216:
																																	goto IL_0eac_2;
																																case 171:
																																case 506:
																																	goto IL_0eba_2;
																																case 264:
																																	goto IL_0ed8_2;
																																case 204:
																																	goto IL_0ee6_2;
																																case 272:
																																	goto IL_0ef9_2;
																																case 140:
																																	goto IL_0f07_2;
																																case 295:
																																case 318:
																																	goto IL_0f15_2;
																																case 480:
																																	goto IL_0f2d_2;
																																case 149:
																																	goto IL_0f4b_2;
																																case 358:
																																	goto IL_0f6f_2;
																																case 179:
																																	goto IL_0f87_2;
																																case 399:
																																	goto IL_0fa3_2;
																																case 208:
																																case 211:
																																	goto IL_0fae_2;
																																case 247:
																																	goto IL_0fc1_2;
																																case 47:
																																	goto IL_0fcf_2;
																																case 218:
																																case 319:
																																	goto IL_0fda_2;
																																case 440:
																																	goto IL_0fe8_2;
																																case 70:
																																	goto IL_100b_2;
																																case 474:
																																	goto IL_1015_2;
																																case 89:
																																	goto IL_1023_2;
																																case 123:
																																	goto IL_1036_2;
																																case 376:
																																	goto IL_1044_2;
																																case 418:
																																case 483:
																																	goto IL_104f_2;
																																case 402:
																																	goto IL_108f_2;
																																case 78:
																																	goto IL_10a8_2;
																																case 127:
																																	goto IL_10b6_2;
																																case 115:
																																case 364:
																																	goto IL_10c4_2;
																																case 343:
																																	goto IL_10dd_2;
																																case 362:
																																	goto IL_10eb_2;
																																case 371:
																																	goto IL_10f9_2;
																																case 340:
																																	goto IL_110c_2;
																																case 5:
																																	goto IL_111a_2;
																																case 52:
																																case 164:
																																	goto IL_1128_2;
																																case 349:
																																	goto IL_1151_2;
																																case 231:
																																	goto IL_115f_2;
																																case 448:
																																	goto IL_1172_2;
																																case 143:
																																	goto IL_1180_2;
																																case 372:
																																case 426:
																																	goto IL_118b_2;
																																case 190:
																																	goto IL_11cb_2;
																																case 131:
																																	goto IL_11df_2;
																																case 254:
																																	goto IL_11f2_2;
																																case 226:
																																	goto IL_1200_2;
																																case 23:
																																case 203:
																																	goto IL_120e_2;
																																case 24:
																																	goto IL_1257_2;
																																case 478:
																																	goto IL_126b_2;
																																case 395:
																																	goto IL_127e_2;
																																case 106:
																																	goto IL_128c_2;
																																case 69:
																																case 447:
																																	goto IL_129a_2;
																																case 99:
																																	goto IL_12da_2;
																																case 233:
																																	goto IL_12ee_2;
																																case 46:
																																	goto IL_1301_2;
																																case 290:
																																	goto IL_130f_2;
																																case 281:
																																	goto IL_131d_2;
																																case 390:
																																	goto IL_132b_2;
																																case 31:
																																case 456:
																																	goto IL_1336_2;
																																case 18:
																																	goto IL_134e_2;
																																case 458:
																																	goto IL_135c_2;
																																case 144:
																																	goto IL_1367_2;
																																case 313:
																																	goto IL_1375_2;
																																case 154:
																																case 398:
																																	goto IL_1383_2;
																																case 369:
																																	goto IL_13c1_2;
																																case 288:
																																case 490:
																																	goto IL_13d4_2;
																																case 124:
																																	goto IL_13f1_2;
																																case 275:
																																	goto IL_1429_2;
																																case 268:
																																	goto IL_1445_2;
																																case 194:
																																	goto IL_1453_2;
																																case 419:
																																case 454:
																																	goto IL_1461_2;
																																case 30:
																																	goto IL_147a_2;
																																case 15:
																																	goto IL_1488_2;
																																case 185:
																																	goto IL_1496_2;
																																case 56:
																																	goto IL_14a9_2;
																																case 212:
																																	goto IL_14b7_2;
																																case 414:
																																	goto IL_14c2_2;
																																case 148:
																																	goto IL_14d0_2;
																																case 12:
																																case 181:
																																	goto IL_14ec_2;
																																case 334:
																																	goto IL_153e_2;
																																case 445:
																																	goto IL_1551_2;
																																case 374:
																																	goto IL_155f_2;
																																case 232:
																																	goto IL_157b_2;
																																case 44:
																																	goto IL_1589_2;
																																case 132:
																																case 479:
																																	goto IL_1594_2;
																																case 271:
																																	goto IL_15ae_2;
																																case 227:
																																	goto IL_15c1_2;
																																case 60:
																																	goto IL_15cf_2;
																																case 201:
																																case 407:
																																	goto IL_15da_2;
																																case 472:
																																	goto IL_15f7_2;
																																case 379:
																																	goto IL_1636_2;
																																case 80:
																																	goto IL_1649_2;
																																case 42:
																																	goto IL_1657_2;
																																case 241:
																																case 381:
																																	goto IL_1665_2;
																																case 476:
																																	goto IL_16a5_2;
																																case 434:
																																	goto IL_16b9_2;
																																case 428:
																																	goto IL_16d5_2;
																																case 84:
																																	goto IL_16e3_2;
																																case 156:
																																case 189:
																																	goto IL_16f1_2;
																																case 339:
																																	goto IL_1705_2;
																																case 415:
																																	goto IL_1759_2;
																																case 278:
																																	goto IL_1770_2;
																																case 117:
																																	goto IL_1783_2;
																																case 452:
																																	goto IL_1791_2;
																																case 250:
																																case 383:
																																	goto IL_179c_2;
																																case 182:
																																	goto IL_17b0_2;
																																case 67:
																																	goto IL_17ef_2;
																																case 459:
																																	goto IL_180b_2;
																																case 40:
																																	goto IL_1819_2;
																																case 200:
																																case 510:
																																	goto IL_1827_2;
																																case 74:
																																	goto IL_1867_2;
																																case 507:
																																	goto IL_187b_2;
																																case 196:
																																	goto IL_188e_2;
																																case 14:
																																	goto IL_1899_2;
																																case 338:
																																case 511:
																																	goto IL_18a7_2;
																																case 285:
																																	goto IL_18c3_2;
																																case 8:
																																	goto IL_18d1_2;
																																case 129:
																																case 495:
																																	goto IL_18df_2;
																																case 206:
																																	goto IL_18f4_2;
																																case 397:
																																case 518:
																																	goto end_IL_26b8_2;
																																case 17:
																																	goto IL_19be_2;
																																case 253:
																																	goto IL_19d5_2;
																																case 346:
																																case 519:
																																	goto IL_19e8_2;
																																case 308:
																																	goto IL_1a28_2;
																																case 228:
																																	goto IL_1a45_2;
																																case 524:
																																	goto IL_1a58_2;
																																case 55:
																																case 526:
																																	goto IL_1a6b_2;
																																case 100:
																																	goto IL_1aac_2;
																																case 120:
																																	goto IL_1ac0_2;
																																case 94:
																																case 529:
																																	goto IL_1ad3_2;
																																case 135:
																																	goto IL_1ae7_2;
																																case 350:
																																	goto IL_1b26_2;
																																case 223:
																																case 530:
																																	goto IL_1b39_2;
																																case 224:
																																	goto IL_1b52_2;
																																case 354:
																																	goto IL_1b60_2;
																																case 257:
																																	goto IL_1b6e_2;
																																case 508:
																																	goto IL_1b81_2;
																																case 501:
																																	goto IL_1b8f_2;
																																case 142:
																																case 256:
																																	goto IL_1b9d_2;
																																case 375:
																																	goto IL_1bb1_2;
																																case 141:
																																	goto IL_1bf0_2;
																																case 382:
																																	goto IL_1c0c_2;
																																case 489:
																																	goto IL_1c1a_2;
																																case 53:
																																case 366:
																																	goto IL_1c28_2;
																																case 289:
																																	goto IL_1c4c_2;
																																case 82:
																																	goto IL_1c5a_2;
																																case 72:
																																	goto IL_1c68_2;
																																case 6:
																																	goto IL_1c7b_2;
																																case 355:
																																	goto IL_1c89_2;
																																case 248:
																																case 333:
																																	goto IL_1c94_2;
																																case 177:
																																	goto IL_1ca8_2;
																																case 175:
																																	goto IL_1ce7_2;
																																case 521:
																																	goto IL_1cfa_2;
																																case 348:
																																	goto IL_1d08_2;
																																case 158:
																																	goto IL_1d13_2;
																																case 401:
																																	goto IL_1d21_2;
																																case 225:
																																case 527:
																																	goto IL_1d2f_2;
																																case 239:
																																	goto IL_1d68_2;
																																case 425:
																																case 442:
																																	goto IL_1d84_2;
																																case 195:
																																	goto IL_1da8_2;
																																case 244:
																																	goto IL_1db6_2;
																																case 352:
																																	goto IL_1dc4_2;
																																case 90:
																																	goto IL_1dd7_2;
																																case 147:
																																	goto IL_1de5_2;
																																case 162:
																																case 491:
																																	goto IL_1df3_2;
																																case 186:
																																	goto IL_1e1c_2;
																																case 242:
																																	goto IL_1e35_2;
																																case 97:
																																	goto IL_1e43_2;
																																case 410:
																																	goto IL_1e51_2;
																																case 68:
																																	goto IL_1e5f_2;
																																case 287:
																																case 514:
																																	goto IL_1e6d_2;
																																case 477:
																																	goto IL_1e81_2;
																																case 485:
																																	goto IL_1ec0_2;
																																case 471:
																																case 502:
																																	goto IL_1ed3_2;
																																case 493:
																																	goto IL_1eed_2;
																																case 168:
																																	goto IL_1efb_2;
																																case 10:
																																	goto IL_1f12_2;
																																case 113:
																																	goto IL_1f25_2;
																																case 523:
																																	goto IL_1f33_2;
																																case 219:
																																case 361:
																																	goto IL_1f41_2;
																																case 63:
																																	goto IL_1f6a_2;
																																case 469:
																																	goto IL_1f83_2;
																																case 222:
																																	goto IL_1f91_2;
																																case 36:
																																	goto IL_1f9f_2;
																																case 155:
																																case 359:
																																	goto IL_1faa_2;
																																case 326:
																																	goto IL_1fb8_2;
																																case 32:
																																	goto IL_1fdc_2;
																																case 152:
																																	goto IL_1fea_2;
																																case 443:
																																	goto IL_2006_2;
																																case 19:
																																	goto IL_2014_2;
																																case 292:
																																case 420:
																																	goto IL_201f_2;
																																case 377:
																																	goto IL_204d_2;
																																case 62:
																																	goto IL_2060_2;
																																case 9:
																																	goto IL_206e_2;
																																case 73:
																																case 435:
																																	goto IL_207c_2;
																																case 96:
																																	goto IL_208a_2;
																																case 512:
																																	goto IL_20ae_2;
																																case 403:
																																	goto IL_20bc_2;
																																case 296:
																																	goto IL_20d8_2;
																																case 20:
																																	goto IL_20e6_2;
																																case 71:
																																case 525:
																																	goto IL_20f4_2;
																																case 531:
																																	goto IL_211f_2;
																																case 497:
																																	goto IL_2138_2;
																																case 61:
																																	goto IL_2146_2;
																																case 35:
																																case 251:
																																	goto IL_2154_2;
																																case 505:
																																	goto IL_21c2_2;
																																case 380:
																																	goto IL_21d5_2;
																																case 500:
																																	goto IL_21e3_2;
																																case 137:
																																case 400:
																																	goto IL_21f1_2;
																																case 107:
																																	goto IL_222f_2;
																																case 441:
																																	goto IL_2243_2;
																																case 277:
																																	goto IL_2256_2;
																																case 363:
																																	goto IL_2261_2;
																																case 91:
																																case 209:
																																	goto IL_226f_2;
																																case 325:
																																	goto IL_2283_2;
																																case 229:
																																	goto IL_22c2_2;
																																case 279:
																																	goto IL_22d5_2;
																																case 273:
																																	goto IL_22e3_2;
																																case 4:
																																	goto IL_22ff_2;
																																case 169:
																																case 520:
																																	goto IL_230a_2;
																																case 161:
																																	goto IL_2322_2;
																																case 16:
																																	goto IL_2330_2;
																																case 503:
																																	goto IL_233e_2;
																																case 51:
																																	goto IL_2351_2;
																																case 412:
																																	goto IL_235f_2;
																																case 101:
																																	goto IL_236d_2;
																																case 356:
																																	goto IL_237b_2;
																																case 373:
																																	goto IL_2389_2;
																																case 342:
																																	goto IL_2397_2;
																																case 45:
																																case 199:
																																	goto IL_23a5_2;
																																case 33:
																																	goto IL_23b9_2;
																																case 284:
																																	goto IL_23f8_2;
																																case 54:
																																case 457:
																																	goto IL_240b_2;
																																case 437:
																																	goto IL_2422_2;
																																case 157:
																																	goto IL_2446_2;
																																case 423:
																																	goto IL_2454_2;
																																case 320:
																																	goto IL_2470_2;
																																case 22:
																																	goto IL_247e_2;
																																case 0:
																																case 105:
																																	goto IL_248c_2;
																																case 274:
																																	goto IL_24cd_2;
																																case 153:
																																	goto IL_24e1_2;
																																case 102:
																																case 367:
																																	goto IL_24fd_2;
																																case 327:
																																	goto IL_2517_2;
																																case 444:
																																	goto IL_252a_2;
																																case 286:
																																	goto IL_2538_2;
																																case 409:
																																case 473:
																																	goto IL_2543_2;
																																case 188:
																																	goto IL_2551_2;
																																case 330:
																																	goto IL_2575_2;
																																case 345:
																																	goto IL_2583_2;
																																case 300:
																																	goto IL_2596_2;
																																case 453:
																																	goto IL_25a4_2;
																																case 234:
																																case 475:
																																	goto IL_25b2_2;
																																case 58:
																																	goto IL_25c6_2;
																																case 236:
																																	goto IL_2605_2;
																																case 463:
																																	goto IL_2618_2;
																																case 360:
																																	goto IL_2623_2;
																																case 294:
																																case 365:
																																	goto IL_262e_2;
																																case 191:
																																	goto IL_268c_2;
																																case 1:
																																case 3:
																																case 28:
																																case 34:
																																case 41:
																																case 77:
																																case 95:
																																case 108:
																																case 112:
																																case 119:
																																case 122:
																																case 125:
																																case 133:
																																case 139:
																																case 145:
																																case 146:
																																case 150:
																																case 151:
																																case 159:
																																case 165:
																																case 166:
																																case 173:
																																case 192:
																																case 197:
																																case 198:
																																case 205:
																																case 207:
																																case 210:
																																case 217:
																																case 220:
																																case 230:
																																case 235:
																																case 245:
																																case 246:
																																case 267:
																																case 291:
																																case 293:
																																case 298:
																																case 301:
																																case 311:
																																case 312:
																																case 323:
																																case 324:
																																case 332:
																																case 336:
																																case 347:
																																case 357:
																																case 368:
																																case 384:
																																case 385:
																																case 386:
																																case 387:
																																case 389:
																																case 404:
																																case 408:
																																case 416:
																																case 432:
																																case 451:
																																case 455:
																																case 460:
																																case 461:
																																case 468:
																																case 494:
																																case 496:
																																case 504:
																																case 509:
																																case 516:
																																case 528:
																																	goto end_IL_0956_2;
																																case 2:
																																case 21:
																																case 29:
																																case 39:
																																case 48:
																																case 59:
																																case 79:
																																case 88:
																																case 92:
																																case 93:
																																case 98:
																																case 104:
																																case 109:
																																case 110:
																																case 126:
																																case 128:
																																case 134:
																																case 136:
																																case 138:
																																case 167:
																																case 170:
																																case 172:
																																case 174:
																																case 184:
																																case 214:
																																case 221:
																																case 252:
																																case 255:
																																case 258:
																																case 259:
																																case 260:
																																case 266:
																																case 276:
																																case 280:
																																case 282:
																																case 283:
																																case 305:
																																case 306:
																																case 310:
																																case 316:
																																case 317:
																																case 321:
																																case 328:
																																case 329:
																																case 331:
																																case 335:
																																case 337:
																																case 341:
																																case 353:
																																case 370:
																																case 391:
																																case 413:
																																case 422:
																																case 430:
																																case 431:
																																case 433:
																																case 439:
																																case 446:
																																case 464:
																																case 467:
																																case 487:
																																case 488:
																																case 498:
																																case 513:
																																case 522:
																																case 532:
																																case 533:
																																	goto end_IL_087f_2;
																																case 87:
																																	ptr2 = ptr;
																																	goto end_IL_087f_2;
																																case 238:
																																	ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UpArrowBlock.ImporterEventKindgetOffsetToStringData);
																																	goto case 87;
																																case 492:
																																	array7[0] = this;
																																	goto case 238;
																																case 103:
																																	array7 = new object[14];
																																	goto case 492;
																																case 517:
																																	array6 = new long[7];
																																	num = 103;
																																	goto case 103;
																																case 81:
																																	array5 = new int[7];
																																	goto case 517;
																																case 411:
																																	array4 = new int[7];
																																	goto case 81;
																																case 344:
																																	array3 = new object[7];
																																	goto case 411;
																																case 243:
																																	array2 = new byte[7];
																																	goto case 344;
																																case 43:
																																	num4 = num2 * 8;
																																	goto case 243;
																																case 65:
																																	num3 = num2 * 4;
																																	num = 43;
																																	goto case 43;
																																case 449:
																																	num2 = 1;
																																	goto case 65;
																																case 450:
																																	goto end_IL_1924;
																																case 121:
																																case 215:
																																	return;
																																}
																																continue;
																																end_IL_087f_2:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_1b81_2;
																												IL_1bf0_2:
																												ptr2 += 8;
																												num = 282;
																												break;
																												IL_1b81_2:
																												if (38 < b)
																												{
																													goto end_IL_0956_2;
																												}
																												goto IL_1b8f_2;
																												IL_1b8f_2:
																												if (38 > b)
																												{
																													goto end_IL_0956_2;
																												}
																												goto IL_1b9d_2;
																												IL_1b9d_2:
																												array2[num6 - 1] = 0;
																												goto IL_1bb1_2;
																												IL_1bb1_2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_1bf0_2;
																											}
																											break;
																										}
																										goto IL_1c0c_2;
																										IL_1c68_2:
																										ptr2 += 8;
																										break;
																										IL_1c0c_2:
																										if (40 < b)
																										{
																											goto end_IL_0956_2;
																										}
																										goto IL_1c1a_2;
																										IL_1c1a_2:
																										if (40 > b)
																										{
																											goto end_IL_0956_2;
																										}
																										goto IL_1c28_2;
																										IL_1c28_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																										goto IL_1c4c_2;
																										IL_1c4c_2:
																										array2[num6] = 0;
																										goto IL_1c5a_2;
																										IL_1c5a_2:
																										num6++;
																										goto IL_1c68_2;
																									}
																									break;
																								}
																								goto IL_09e3_2;
																								IL_0c60_2:
																								ptr2 += 8;
																								break;
																								IL_09e3_2:
																								if (37 <= b)
																								{
																									goto IL_0a57_2;
																								}
																								goto IL_0a6d_2;
																								IL_0a57_2:
																								array2[num6 - 1] = 3;
																								goto IL_0aa9_2;
																								IL_0aa9_2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_0ae8_2;
																								IL_0ae8_2:
																								ptr2 += 8;
																								break;
																								IL_0a6d_2:
																								if (35 < b)
																								{
																									goto IL_0a78_2;
																								}
																								goto IL_0a96_2;
																								IL_0a78_2:
																								if (36 < b)
																								{
																									goto end_IL_0956_2;
																								}
																								goto IL_0a86_2;
																								IL_0a86_2:
																								if (36 > b)
																								{
																									goto end_IL_0956_2;
																								}
																								goto IL_0afb_2;
																								IL_0afb_2:
																								array2[num6 - 1] = 5;
																								goto IL_0b0f_2;
																								IL_0b0f_2:
																								array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
																								goto IL_0b47_2;
																								IL_0b47_2:
																								ptr2 += 8;
																								break;
																								IL_0a96_2:
																								if (35 > b)
																								{
																									goto IL_0c0a_2;
																								}
																								goto IL_0c73_2;
																								IL_0c73_2:
																								array2[num6 - 1] = 5;
																								goto IL_0c87_2;
																								IL_0c87_2:
																								array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																								goto IL_0cbf_2;
																								IL_0cbf_2:
																								ptr2 += 8;
																								break;
																								IL_0c0a_2:
																								if (34 < b)
																								{
																									goto end_IL_0956_2;
																								}
																								goto IL_0c18_2;
																								IL_0c18_2:
																								if (34 > b)
																								{
																									goto end_IL_0956_2;
																								}
																								goto IL_0c26_2;
																								IL_0c26_2:
																								array2[num6] = 5;
																								goto IL_0c34_2;
																								IL_0c34_2:
																								array3[num6] = ((delegate*<GorillaTagger>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																								goto IL_0c52_2;
																								IL_0c52_2:
																								num6++;
																								goto IL_0c60_2;
																							}
																							break;
																						}
																						goto IL_0991_2;
																						IL_09ba_2:
																						array2[num6 - 1] = 5;
																						break;
																						IL_0991_2:
																						array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_09ba_2;
																					}
																					break;
																				}
																				goto IL_1c7b_2;
																				IL_1f41_2:
																				array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_1f6a_2;
																				IL_1c7b_2:
																				if (45 >= b)
																				{
																					goto IL_1c89_2;
																				}
																				goto IL_1e35_2;
																				IL_1c89_2:
																				if (45 <= b)
																				{
																					goto IL_1c94_2;
																				}
																				goto IL_1cfa_2;
																				IL_1c94_2:
																				array2[num6 - 1] = 3;
																				goto IL_1ca8_2;
																				IL_1ca8_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_1ce7_2;
																				IL_1ce7_2:
																				ptr2 += 8;
																				break;
																				IL_1cfa_2:
																				if (43 >= b)
																				{
																					goto IL_1d08_2;
																				}
																				goto IL_1dd7_2;
																				IL_1d08_2:
																				if (43 > b)
																				{
																					goto IL_1d13_2;
																				}
																				num = 425;
																				goto IL_1d84_2;
																				IL_1d13_2:
																				if (42 < b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1d21_2;
																				IL_1d21_2:
																				if (42 > b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1d2f_2;
																				IL_1d2f_2:
																				((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																				goto IL_1d68_2;
																				IL_1d68_2:
																				num6 -= 3;
																				break;
																				IL_1f6a_2:
																				array2[num6 - 1] = 5;
																				break;
																				IL_1d84_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_1da8_2;
																				IL_1da8_2:
																				array2[num6] = 0;
																				goto IL_1db6_2;
																				IL_1db6_2:
																				num6++;
																				goto IL_1dc4_2;
																				IL_1dc4_2:
																				ptr2 += 8;
																				break;
																				IL_1dd7_2:
																				if (44 < b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1de5_2;
																				IL_1de5_2:
																				if (44 > b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1df3_2;
																				IL_1df3_2:
																				array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																				goto IL_1e1c_2;
																				IL_1e1c_2:
																				array2[num6 - 1] = 5;
																				break;
																				IL_1e35_2:
																				if (47 >= b)
																				{
																					goto IL_1e43_2;
																				}
																				goto IL_1f25_2;
																				IL_1e43_2:
																				if (47 > b)
																				{
																					goto IL_1e51_2;
																				}
																				goto IL_1ed3_2;
																				IL_1e51_2:
																				if (46 < b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1e5f_2;
																				IL_1e5f_2:
																				if (46 > b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1e6d_2;
																				IL_1e6d_2:
																				array2[num6 - 1] = 0;
																				goto IL_1e81_2;
																				IL_1e81_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_1ec0_2;
																				IL_1ec0_2:
																				ptr2 += 8;
																				break;
																				IL_1ed3_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																				goto IL_1eed_2;
																				IL_1eed_2:
																				array2[num6] = 3;
																				goto IL_1efb_2;
																				IL_1efb_2:
																				num6++;
																				num = 10;
																				goto IL_1f12_2;
																				IL_1f12_2:
																				ptr2 += 8;
																				break;
																				IL_1f25_2:
																				if (48 < b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1f33_2;
																				IL_1f33_2:
																				if (48 > b)
																				{
																					goto end_IL_0956_2;
																				}
																				goto IL_1f41_2;
																			}
																			break;
																		}
																		goto IL_0b5a_2;
																		IL_0bf7_2:
																		ptr2 += 8;
																		break;
																		IL_0b5a_2:
																		array2[num6 - 4] = 0;
																		goto IL_0b6e_2;
																		IL_0b6e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
																		goto IL_0be9_2;
																		IL_0be9_2:
																		num6 -= 3;
																		goto IL_0bf7_2;
																	}
																	break;
																}
																goto IL_1f83_2;
																IL_2623_2:
																if (56 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_262e_2;
																IL_1f83_2:
																if (57 < b)
																{
																	goto IL_1f91_2;
																}
																num = 4;
																goto IL_22ff_2;
																IL_1f91_2:
																if (61 >= b)
																{
																	goto IL_1f9f_2;
																}
																goto IL_2138_2;
																IL_1f9f_2:
																if (61 <= b)
																{
																	goto IL_1faa_2;
																}
																goto IL_2006_2;
																IL_1faa_2:
																array2[num6] = 3;
																goto IL_1fb8_2;
																IL_1fb8_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																goto IL_1fdc_2;
																IL_1fdc_2:
																num6++;
																goto IL_1fea_2;
																IL_1fea_2:
																ptr2 += 8;
																num = 306;
																break;
																IL_2006_2:
																if (59 >= b)
																{
																	goto IL_2014_2;
																}
																goto IL_20d8_2;
																IL_2014_2:
																if (59 <= b)
																{
																	goto IL_201f_2;
																}
																goto IL_2060_2;
																IL_201f_2:
																((Class15)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_204d_2;
																IL_204d_2:
																num6 -= 2;
																break;
																IL_2060_2:
																if (58 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_206e_2;
																IL_206e_2:
																if (58 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_207c_2;
																IL_207c_2:
																array2[num6] = 3;
																goto IL_208a_2;
																IL_208a_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																goto IL_20ae_2;
																IL_20ae_2:
																num6++;
																goto IL_20bc_2;
																IL_20bc_2:
																ptr2 += 8;
																num = 39;
																break;
																IL_20d8_2:
																if (60 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_20e6_2;
																IL_20e6_2:
																if (60 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_20f4_2;
																IL_20f4_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_211f_2;
																IL_211f_2:
																array2[num6 - 1] = 0;
																break;
																IL_2138_2:
																if (63 >= b)
																{
																	goto IL_2146_2;
																}
																goto IL_2256_2;
																IL_2146_2:
																if (63 <= b)
																{
																	goto IL_2154_2;
																}
																goto IL_21d5_2;
																IL_2154_2:
																ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_21c2_2;
																IL_21c2_2:
																num6 -= 2;
																break;
																IL_21d5_2:
																if (62 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_21e3_2;
																IL_21e3_2:
																if (62 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_21f1_2;
																IL_21f1_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class15, float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((Class15)array3[num6 - 1]);
																goto IL_222f_2;
																IL_222f_2:
																array2[num6 - 1] = 3;
																goto IL_2243_2;
																IL_2243_2:
																ptr2 += 8;
																break;
																IL_2256_2:
																if (64 >= b)
																{
																	goto IL_2261_2;
																}
																goto IL_22d5_2;
																IL_2261_2:
																if (64 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_226f_2;
																IL_226f_2:
																array2[num6 - 1] = 3;
																goto IL_2283_2;
																IL_2283_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_22c2_2;
																IL_22c2_2:
																ptr2 += 8;
																break;
																IL_22d5_2:
																if (65 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_22e3_2;
																IL_22e3_2:
																if (65 > b)
																{
																}
																goto end_IL_0956_2;
																IL_262e_2:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_268c_2;
																IL_22ff_2:
																if (57 <= b)
																{
																	goto IL_230a_2;
																}
																goto IL_2351_2;
																IL_230a_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_2322_2;
																IL_2322_2:
																array2[num6] = 5;
																goto IL_2330_2;
																IL_2330_2:
																num6++;
																goto IL_233e_2;
																IL_233e_2:
																ptr2 += 8;
																break;
																IL_2351_2:
																if (53 >= b)
																{
																	goto IL_235f_2;
																}
																goto IL_252a_2;
																IL_235f_2:
																if (53 > b)
																{
																	goto IL_236d_2;
																}
																num = 102;
																goto IL_24fd_2;
																IL_236d_2:
																if (51 >= b)
																{
																	goto IL_237b_2;
																}
																goto IL_2470_2;
																IL_237b_2:
																if (51 > b)
																{
																	goto IL_2389_2;
																}
																goto IL_240b_2;
																IL_2389_2:
																if (50 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_2397_2;
																IL_2397_2:
																if (50 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_23a5_2;
																IL_23a5_2:
																array2[num6 - 1] = 3;
																goto IL_23b9_2;
																IL_23b9_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_23f8_2;
																IL_23f8_2:
																ptr2 += 8;
																break;
																IL_240b_2:
																array2[num6] = 3;
																num = 437;
																goto IL_2422_2;
																IL_2422_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
																goto IL_2446_2;
																IL_2446_2:
																num6++;
																goto IL_2454_2;
																IL_2454_2:
																ptr2 += 8;
																num = 136;
																break;
																IL_2470_2:
																if (52 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_247e_2;
																IL_247e_2:
																if (52 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_248c_2;
																IL_248c_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) > *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																goto IL_24cd_2;
																IL_24cd_2:
																array2[num6 - 2] = 0;
																goto IL_24e1_2;
																IL_24e1_2:
																num6--;
																break;
																IL_268c_2:
																num6--;
																break;
																IL_24fd_2:
																global::_003CModule_003E.bool_27 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																goto IL_2517_2;
																IL_2517_2:
																num6--;
																break;
																IL_252a_2:
																if (55 >= b)
																{
																	goto IL_2538_2;
																}
																goto IL_2618_2;
																IL_2538_2:
																if (55 <= b)
																{
																	goto IL_2543_2;
																}
																goto IL_2596_2;
																IL_2543_2:
																array2[num6] = 0;
																goto IL_2551_2;
																IL_2551_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])() ? 1 : 0);
																goto IL_2575_2;
																IL_2575_2:
																num6++;
																goto IL_2583_2;
																IL_2583_2:
																ptr2 += 8;
																break;
																IL_2596_2:
																if (54 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_25a4_2;
																IL_25a4_2:
																if (54 > b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_25b2_2;
																IL_25b2_2:
																array2[num6 - 1] = 3;
																goto IL_25c6_2;
																IL_25c6_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_2605_2;
																IL_2605_2:
																ptr2 += 8;
																break;
																IL_2618_2:
																if (56 < b)
																{
																	goto end_IL_0956_2;
																}
																goto IL_2623_2;
															}
															break;
														}
														goto IL_09d3_2;
														IL_1899_2:
														if (31 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_18a7_2;
														IL_09d3_2:
														if (33 <= b)
														{
															goto IL_09f0_2;
														}
														goto IL_0cd2_2;
														IL_09f0_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0a30_2;
														IL_0a30_2:
														array2[num6 - 2] = 3;
														goto IL_0a44_2;
														IL_0a44_2:
														num6--;
														break;
														IL_0cd2_2:
														if (16 >= b)
														{
															goto IL_0ce0_2;
														}
														goto IL_1301_2;
														IL_0ce0_2:
														if (16 <= b)
														{
															goto IL_0ceb_2;
														}
														goto IL_0d32_2;
														IL_0ceb_2:
														array2[num6] = 5;
														goto IL_0cf9_2;
														IL_0cf9_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_0d11_2;
														IL_0d11_2:
														num6++;
														goto IL_0d1f_2;
														IL_0d1f_2:
														ptr2 += 8;
														break;
														IL_0d32_2:
														if (8 < b)
														{
															goto IL_0d40_2;
														}
														num = 399;
														goto IL_0fa3_2;
														IL_0d40_2:
														if (12 >= b)
														{
															goto IL_0d4e_2;
														}
														goto IL_0e3a_2;
														IL_0d4e_2:
														if (12 <= b)
														{
															num = 397;
															goto end_IL_26b8_2;
														}
														goto IL_0d5c_2;
														IL_0d5c_2:
														if (10 >= b)
														{
															goto IL_0d6a_2;
														}
														goto IL_0e0b_2;
														IL_0d6a_2:
														if (10 <= b)
														{
															goto IL_0d75_2;
														}
														goto IL_0dea_2;
														IL_0d75_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0dd7_2;
														IL_0dd7_2:
														num6 -= 2;
														break;
														IL_0dea_2:
														if (9 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_0df8_2;
														IL_0df8_2:
														if (9 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_19e8_2;
														IL_19e8_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1a28_2;
														IL_1a28_2:
														array2[num6 - 2] = 0;
														num = 228;
														goto IL_1a45_2;
														IL_1a45_2:
														num6--;
														break;
														IL_0e0b_2:
														if (11 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_0e19_2;
														IL_0e19_2:
														if (11 > b)
														{
															goto end_IL_0956_2;
														}
														break;
														IL_18c3_2:
														if (32 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_18d1_2;
														IL_0e3a_2:
														if (14 >= b)
														{
															goto IL_0e48_2;
														}
														goto IL_0ef9_2;
														IL_0e48_2:
														if (14 <= b)
														{
															goto IL_0e53_2;
														}
														goto IL_0e95_2;
														IL_0e53_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_0e7c_2;
														IL_0e7c_2:
														array2[num6 - 1] = 5;
														break;
														IL_0e95_2:
														if (13 < b)
														{
															goto end_IL_0956_2;
														}
														num = 216;
														goto IL_0eac_2;
														IL_18d1_2:
														if (32 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_18df_2;
														IL_0eac_2:
														if (13 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_0eba_2;
														IL_0eba_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_0ed8_2;
														IL_0ed8_2:
														ptr2 += 8;
														goto IL_0ee6_2;
														IL_0ee6_2:
														num6--;
														break;
														IL_0ef9_2:
														if (15 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_0f07_2;
														IL_0f07_2:
														if (15 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_0f15_2;
														IL_0f15_2:
														array2[num6] = array2[num6 - 1];
														goto IL_0f2d_2;
														IL_0f2d_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_0f4b_2;
														IL_0f4b_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0f6f_2;
														IL_0f6f_2:
														array3[num6] = array3[num6 - 1];
														goto IL_0f87_2;
														IL_0f87_2:
														num6++;
														break;
														IL_18a7_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														break;
														IL_0fa3_2:
														if (8 <= b)
														{
															goto IL_0fae_2;
														}
														goto IL_0fc1_2;
														IL_0fae_2:
														num6--;
														break;
														IL_0fc1_2:
														if (4 >= b)
														{
															goto IL_0fcf_2;
														}
														goto IL_1172_2;
														IL_0fcf_2:
														if (4 <= b)
														{
															goto IL_0fda_2;
														}
														goto IL_1036_2;
														IL_0fda_2:
														array2[num6] = 0;
														goto IL_0fe8_2;
														IL_0fe8_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_100b_2;
														IL_100b_2:
														array3[num6] = null;
														goto IL_1015_2;
														IL_1015_2:
														num6++;
														goto IL_1023_2;
														IL_1023_2:
														ptr2 += 8;
														break;
														IL_1036_2:
														if (2 >= b)
														{
															goto IL_1044_2;
														}
														goto IL_110c_2;
														IL_1044_2:
														if (2 <= b)
														{
															goto IL_104f_2;
														}
														goto IL_10a8_2;
														IL_104f_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_108f_2;
														IL_108f_2:
														array2[num6 - 2] = 0;
														goto IL_1a58_2;
														IL_1a58_2:
														num6--;
														break;
														IL_10a8_2:
														if (1 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_10b6_2;
														IL_10b6_2:
														if (1 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_10c4_2;
														IL_10c4_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_10dd_2;
														IL_10dd_2:
														array2[num6] = 0;
														goto IL_10eb_2;
														IL_10eb_2:
														num6++;
														goto IL_10f9_2;
														IL_10f9_2:
														ptr2 += 8;
														break;
														IL_110c_2:
														if (3 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_111a_2;
														IL_111a_2:
														if (3 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1128_2;
														IL_1128_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1151_2;
														IL_1151_2:
														ptr2 += 8;
														goto IL_115f_2;
														IL_115f_2:
														num6--;
														break;
														IL_1172_2:
														if (6 >= b)
														{
															goto IL_1180_2;
														}
														goto IL_127e_2;
														IL_1180_2:
														if (6 <= b)
														{
															goto IL_118b_2;
														}
														goto IL_11f2_2;
														IL_118b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_11cb_2;
														IL_11cb_2:
														array2[num6 - 2] = 0;
														goto IL_11df_2;
														IL_11df_2:
														num6--;
														break;
														IL_11f2_2:
														if (5 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1200_2;
														IL_1200_2:
														if (5 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_120e_2;
														IL_120e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 24;
														goto IL_1257_2;
														IL_1257_2:
														array2[num6 - 2] = 0;
														goto IL_126b_2;
														IL_126b_2:
														num6--;
														break;
														IL_127e_2:
														if (7 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_128c_2;
														IL_128c_2:
														if (7 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_129a_2;
														IL_129a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_12da_2;
														IL_12da_2:
														array2[num6 - 2] = 0;
														goto IL_12ee_2;
														IL_12ee_2:
														num6--;
														break;
														IL_1301_2:
														if (24 >= b)
														{
															goto IL_130f_2;
														}
														goto IL_157b_2;
														IL_130f_2:
														if (24 > b)
														{
															goto IL_131d_2;
														}
														goto IL_1ad3_2;
														IL_131d_2:
														if (20 >= b)
														{
															goto IL_132b_2;
														}
														goto IL_14a9_2;
														IL_132b_2:
														if (20 <= b)
														{
															goto IL_1336_2;
														}
														goto IL_134e_2;
														IL_1336_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														break;
														IL_134e_2:
														if (18 >= b)
														{
															goto IL_135c_2;
														}
														goto IL_1445_2;
														IL_135c_2:
														if (18 > b)
														{
															goto IL_1367_2;
														}
														goto IL_13d4_2;
														IL_1367_2:
														if (17 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1375_2;
														IL_1375_2:
														if (17 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1383_2;
														IL_1383_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_13c1_2;
														IL_13c1_2:
														num6 -= 3;
														break;
														IL_13d4_2:
														array2[num6 - 1] = 5;
														num = 124;
														goto IL_13f1_2;
														IL_13f1_2:
														array3[num6 - 1] = ((delegate*<string[], string>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_1429_2;
														IL_1429_2:
														ptr2 += 8;
														num = 446;
														break;
														IL_1445_2:
														if (19 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1453_2;
														IL_1453_2:
														if (19 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1461_2;
														IL_1461_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_147a_2;
														IL_147a_2:
														array2[num6] = 1;
														goto IL_1488_2;
														IL_1488_2:
														num6++;
														goto IL_1496_2;
														IL_1496_2:
														ptr2 += 16;
														break;
														IL_14a9_2:
														if (22 >= b)
														{
															goto IL_14b7_2;
														}
														goto IL_1551_2;
														IL_14b7_2:
														if (22 > b)
														{
															goto IL_14c2_2;
														}
														num = 181;
														goto IL_14ec_2;
														IL_14c2_2:
														if (21 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_14d0_2;
														IL_14d0_2:
														if (21 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1a6b_2;
														IL_1a6b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1aac_2;
														IL_1aac_2:
														array2[num6 - 2] = 0;
														goto IL_1ac0_2;
														IL_1ac0_2:
														num6--;
														break;
														IL_18df_2:
														((delegate*<void>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])();
														goto IL_18f4_2;
														IL_14ec_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_153e_2;
														IL_153e_2:
														num6--;
														break;
														IL_1551_2:
														if (23 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_155f_2;
														IL_155f_2:
														if (23 > b)
														{
															goto end_IL_0956_2;
														}
														num = 530;
														goto IL_1b39_2;
														IL_18f4_2:
														ptr2 += 8;
														break;
														IL_1b39_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_1b52_2;
														IL_1b52_2:
														array2[num6] = 3;
														goto IL_1b60_2;
														IL_1b60_2:
														num6++;
														goto IL_1b6e_2;
														IL_1b6e_2:
														ptr2 += 16;
														break;
														IL_1ad3_2:
														array2[num6 - 1] = 3;
														goto IL_1ae7_2;
														IL_1ae7_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1b26_2;
														IL_1b26_2:
														ptr2 += 8;
														break;
														IL_157b_2:
														if (28 >= b)
														{
															goto IL_1589_2;
														}
														goto IL_1783_2;
														IL_1589_2:
														if (28 <= b)
														{
															goto IL_1594_2;
														}
														goto IL_15c1_2;
														IL_1594_2:
														global::_003CModule_003E.int_59 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_15ae_2;
														IL_15ae_2:
														num6--;
														break;
														IL_15c1_2:
														if (26 >= b)
														{
															goto IL_15cf_2;
														}
														goto IL_16d5_2;
														IL_15cf_2:
														if (26 <= b)
														{
															goto IL_15da_2;
														}
														goto IL_1649_2;
														IL_15da_2:
														array2[num6 - 1] = 0;
														num = 472;
														goto IL_15f7_2;
														IL_15f7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1636_2;
														IL_1636_2:
														ptr2 += 8;
														break;
														IL_1649_2:
														if (25 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1657_2;
														IL_1657_2:
														if (25 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1665_2;
														IL_1665_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_16a5_2;
														IL_16a5_2:
														array2[num6 - 2] = 3;
														goto IL_16b9_2;
														IL_16b9_2:
														num6--;
														num = 93;
														break;
														IL_16d5_2:
														if (27 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_16e3_2;
														IL_16e3_2:
														if (27 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_16f1_2;
														IL_16f1_2:
														array2[num6 - 2] = 0;
														goto IL_1705_2;
														IL_1705_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1759_2;
														IL_1759_2:
														num6--;
														num = 278;
														goto IL_1770_2;
														IL_1770_2:
														ptr2 += 8;
														break;
														IL_1783_2:
														if (30 >= b)
														{
															goto IL_1791_2;
														}
														goto IL_188e_2;
														IL_1791_2:
														if (30 <= b)
														{
															goto IL_179c_2;
														}
														goto IL_180b_2;
														IL_179c_2:
														array2[num6 - 1] = 0;
														goto IL_17b0_2;
														IL_17b0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)UCOMIEnumeratorNestedPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_17ef_2;
														IL_17ef_2:
														ptr2 += 8;
														num = 328;
														break;
														IL_180b_2:
														if (29 < b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1819_2;
														IL_1819_2:
														if (29 > b)
														{
															goto end_IL_0956_2;
														}
														goto IL_1827_2;
														IL_1827_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1867_2;
														IL_1867_2:
														array2[num6 - 2] = 3;
														goto IL_187b_2;
														IL_187b_2:
														num6--;
														break;
														IL_188e_2:
														if (31 >= b)
														{
															goto IL_1899_2;
														}
														goto IL_18c3_2;
													}
													goto end_IL_0966_2;
													continue;
													end_IL_0956_2:
													break;
													IL_0956_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											num = 98;
											break;
											continue;
											end_IL_0966_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_26b8_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_1916_2;
					}
					continue;
					end_IL_1924:
					break;
				}
				break;
			}
		}
	}

	public Class15()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_0)
	{
		int num = 52;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							IL_06f7:
							int[] array3 = new int[4];
							while (true)
							{
								IL_06e7:
								long[] array4 = new long[3];
								while (true)
								{
									IL_06c9:
									array3[0] = int_0;
									num = 94;
									while (true)
									{
										IL_06b5:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSHASHDIGESTMETHODGlobalizationAssembly.ISOEncoderInfo);
										num = 22;
										while (true)
										{
											IL_06ab:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0698:
												if (num4 != 1)
												{
													while (true)
													{
														IL_029d:
														byte b = *ptr2;
														while (true)
														{
															IL_028d:
															ptr2++;
															while (true)
															{
																IL_027d:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0260:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0253:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0243:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0233:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											while (8 <= b)
																											{
																												num = 120;
																												while (true)
																												{
																													if (num != 120)
																													{
																														if (num != 1101)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 104:
																															goto IL_0210;
																														case 29:
																															goto IL_0223;
																														case 87:
																															goto IL_0233;
																														case 76:
																															goto IL_0243;
																														case 74:
																															goto IL_0253;
																														case 84:
																															goto IL_0260;
																														case 85:
																															goto IL_026d;
																														case 97:
																															goto IL_027d;
																														case 92:
																															goto IL_028d;
																														case 72:
																														case 86:
																															goto IL_029d;
																														case 2:
																															goto IL_02a8;
																														case 11:
																														case 47:
																															goto IL_02bb;
																														case 15:
																															goto IL_02c6;
																														case 17:
																														case 56:
																															goto IL_02d4;
																														case 61:
																														case 63:
																															goto IL_02f9;
																														case 49:
																															goto IL_0307;
																														case 69:
																															goto IL_031a;
																														case 37:
																														case 40:
																															goto IL_0328;
																														case 8:
																														case 96:
																															goto IL_036a;
																														case 98:
																															goto IL_03ac;
																														case 64:
																															goto IL_03c0;
																														case 100:
																															goto IL_03d3;
																														case 30:
																															goto IL_03e7;
																														case 110:
																															goto IL_03fa;
																														case 103:
																															goto IL_0408;
																														case 41:
																														case 95:
																															goto IL_0416;
																														case 55:
																															goto IL_0421;
																														case 26:
																														case 77:
																															goto IL_042f;
																														case 14:
																															goto IL_0448;
																														case 71:
																															goto IL_0456;
																														case 54:
																															goto IL_0464;
																														case 4:
																															goto IL_0480;
																														case 62:
																															goto IL_0497;
																														case 7:
																														case 38:
																															goto IL_04a5;
																														case 102:
																															goto IL_04d7;
																														case 106:
																															goto IL_04e5;
																														case 78:
																														case 80:
																															goto IL_04f8;
																														case 3:
																														case 107:
																															goto IL_0519;
																														case 93:
																															goto IL_0524;
																														case 109:
																															goto IL_0537;
																														case 19:
																															goto IL_054e;
																														case 36:
																														case 60:
																															goto IL_055c;
																														case 68:
																															goto IL_056a;
																														case 99:
																															goto IL_058d;
																														case 58:
																															goto IL_0597;
																														case 83:
																															goto IL_05a5;
																														case 31:
																															goto IL_05b8;
																														case 65:
																															goto IL_05db;
																														case 112:
																															goto IL_05e9;
																														case 101:
																															goto IL_05f7;
																														case 1:
																														case 32:
																															goto IL_060a;
																														case 79:
																															goto IL_0675;
																														case 0:
																														case 5:
																														case 6:
																														case 9:
																														case 12:
																														case 18:
																														case 21:
																														case 27:
																														case 35:
																														case 39:
																														case 48:
																														case 50:
																														case 59:
																														case 67:
																														case 75:
																														case 82:
																														case 88:
																														case 89:
																														case 90:
																														case 91:
																														case 105:
																														case 113:
																															goto end_IL_0210;
																														case 10:
																														case 16:
																														case 20:
																														case 23:
																														case 24:
																														case 25:
																														case 28:
																														case 33:
																														case 42:
																														case 44:
																														case 45:
																														case 53:
																														case 81:
																														case 111:
																															goto IL_0698;
																														case 22:
																															goto IL_06ab;
																														case 94:
																															goto IL_06b5;
																														case 34:
																															goto IL_06c9;
																														case 13:
																															goto IL_06e7;
																														case 43:
																														case 66:
																															goto IL_06f7;
																														case 108:
																															goto end_IL_01fd;
																														case 57:
																														case 73:
																															goto end_IL_0707;
																														case 51:
																															goto end_IL_0717;
																														case 52:
																															goto end_IL_0727;
																														case 46:
																														case 70:
																															goto IL_0742;
																														}
																														continue;
																													}
																													goto IL_05b8;
																													IL_05e9:
																													num5++;
																													goto IL_05f7;
																													IL_05f7:
																													ptr2 += 8;
																													goto IL_0698;
																													IL_05b8:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_05db;
																													IL_05db:
																													array[num5] = 0;
																													goto IL_05e9;
																													continue;
																													end_IL_01fd:
																													break;
																												}
																												goto end_IL_027d;
																												continue;
																												end_IL_0210:
																												break;
																												IL_0210:;
																											}
																											break;
																											IL_0223:;
																										}
																										break;
																									}
																									goto IL_031a;
																									IL_03c0:
																									num5--;
																									goto IL_0698;
																									IL_031a:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0328;
																									IL_0328:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03ac;
																									IL_03ac:
																									array[num5 - 2] = 0;
																									goto IL_03c0;
																								}
																								break;
																							}
																							goto IL_060a;
																							IL_0675:
																							num5 -= 2;
																							goto IL_0698;
																							IL_060a:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 79;
																							goto IL_0675;
																						}
																						break;
																					}
																					goto IL_02bb;
																					IL_0307:
																					if (11 <= b)
																					{
																					}
																					break;
																					IL_02bb:
																					if (10 >= b)
																					{
																						goto IL_02c6;
																					}
																					goto IL_02f9;
																					IL_02c6:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_02d4;
																					IL_02d4:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 44;
																					goto IL_0698;
																					IL_02f9:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0307;
																				}
																				break;
																			}
																			goto IL_02a8;
																			IL_056a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_058d;
																			IL_02a8:
																			if (6 <= b)
																			{
																				goto IL_036a;
																			}
																			goto IL_03fa;
																			IL_036a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03d3;
																			IL_03d3:
																			array[num5 - 2] = 0;
																			goto IL_03e7;
																			IL_03e7:
																			num5--;
																			goto IL_0698;
																			IL_03fa:
																			if (3 >= b)
																			{
																				goto IL_0408;
																			}
																			num = 3;
																			goto IL_0519;
																			IL_0408:
																			if (3 > b)
																			{
																				goto IL_0416;
																			}
																			goto IL_04f8;
																			IL_0416:
																			if (1 >= b)
																			{
																				goto IL_0421;
																			}
																			goto IL_0480;
																			IL_0421:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_042f;
																			IL_042f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0448;
																			IL_0448:
																			array[num5] = 0;
																			goto IL_0456;
																			IL_0456:
																			num5++;
																			goto IL_0464;
																			IL_0464:
																			ptr2 += 8;
																			num = 16;
																			goto IL_0698;
																			IL_0480:
																			if (2 < b)
																			{
																				break;
																			}
																			num = 62;
																			goto IL_0497;
																			IL_0597:
																			num5++;
																			goto IL_05a5;
																			IL_0497:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_04a5;
																			IL_04a5:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 102;
																			goto IL_04d7;
																			IL_04d7:
																			ptr2 += 8;
																			goto IL_04e5;
																			IL_04e5:
																			num5--;
																			goto IL_0698;
																			IL_04f8:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_0698;
																			IL_058d:
																			array2[num5] = null;
																			goto IL_0597;
																			IL_0519:
																			if (4 >= b)
																			{
																				goto IL_0524;
																			}
																			goto IL_0537;
																			IL_0524:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_0698;
																			IL_0537:
																			if (5 < b)
																			{
																				break;
																			}
																			num = 19;
																			goto IL_054e;
																			IL_05a5:
																			ptr2 += 8;
																			goto IL_0698;
																			IL_054e:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_055c;
																			IL_055c:
																			array[num5] = 0;
																			goto IL_056a;
																		}
																		break;
																		IL_026d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0698;
																continue;
																end_IL_027d:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0742;
												IL_0742:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0707:
						break;
					}
					continue;
					end_IL_0717:
					break;
				}
				continue;
				end_IL_0727:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_0, int int_1)
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetEnvironmentVariablesRemoveClaim.LocalDataStoreMgridldescType);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 24;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 82;
																	while (true)
																	{
																		IL_01fc:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01dc:
																					if (4 < b)
																					{
																						goto IL_039f;
																					}
																					while (true)
																					{
																						IL_01cc:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01bc:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01ac:
																										if (2 <= b)
																										{
																											num = 95;
																											while (true)
																											{
																												if (num != 95)
																												{
																													if (num != 1076)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 47:
																														goto IL_01ac;
																													case 15:
																													case 43:
																														goto IL_01bc;
																													case 65:
																														goto IL_01cc;
																													case 77:
																														goto IL_01dc;
																													case 60:
																														goto end_IL_01dc;
																													case 82:
																														goto IL_01fc;
																													case 85:
																														goto end_IL_01fc;
																													case 30:
																													case 39:
																														goto end_IL_020c;
																													case 11:
																														goto IL_0230;
																													case 12:
																														goto IL_023e;
																													case 46:
																														goto IL_0251;
																													case 53:
																														goto IL_02bf;
																													case 10:
																														goto IL_02d2;
																													case 29:
																														goto IL_02e0;
																													case 3:
																													case 50:
																														goto IL_02ee;
																													case 18:
																														goto IL_032e;
																													case 20:
																														goto IL_0342;
																													case 70:
																													case 74:
																														goto IL_0355;
																													case 78:
																														goto IL_037e;
																													case 49:
																														goto IL_038c;
																													case 79:
																														goto IL_039f;
																													case 41:
																														goto IL_03aa;
																													case 56:
																														goto IL_03b8;
																													case 44:
																														goto IL_03c6;
																													case 31:
																													case 54:
																														goto end_IL_0199;
																													case 4:
																														goto IL_03ec;
																													case 73:
																														goto IL_03f7;
																													case 5:
																													case 19:
																														goto IL_0405;
																													case 38:
																														goto IL_0413;
																													case 36:
																														goto IL_0436;
																													case 0:
																														goto IL_0440;
																													case 21:
																														goto IL_044e;
																													case 72:
																														goto IL_046a;
																													case 80:
																														goto IL_0475;
																													case 42:
																													case 52:
																														goto IL_0480;
																													case 8:
																													case 9:
																													case 13:
																													case 14:
																													case 22:
																													case 25:
																													case 26:
																													case 28:
																													case 32:
																													case 33:
																													case 34:
																													case 55:
																													case 63:
																													case 66:
																													case 69:
																													case 75:
																													case 83:
																													case 86:
																													case 87:
																														goto end_IL_01ec;
																													case 68:
																														goto IL_04c5;
																													case 71:
																														goto IL_04d3;
																													case 81:
																														goto IL_04e1;
																													case 1:
																													case 2:
																													case 17:
																													case 23:
																													case 24:
																													case 27:
																													case 35:
																													case 48:
																													case 67:
																													case 88:
																														goto end_IL_0225;
																													case 37:
																														goto end_IL_04ef;
																													case 51:
																														goto end_IL_0502;
																													case 40:
																														goto end_IL_050d;
																													case 59:
																														goto end_IL_0517;
																													case 84:
																														goto end_IL_0522;
																													case 64:
																														goto end_IL_0537;
																													case 16:
																													case 45:
																														goto end_IL_054c;
																													case 57:
																														goto end_IL_055c;
																													case 58:
																													case 61:
																														goto end_IL_056c;
																													case 6:
																														goto end_IL_057c;
																													case 7:
																														goto end_IL_058c;
																													case 62:
																													case 76:
																														goto IL_05a7;
																													}
																													continue;
																												}
																												goto IL_0251;
																												IL_0251:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_02bf;
																												IL_02bf:
																												num5 -= 2;
																												goto end_IL_0225;
																												continue;
																												end_IL_0199:
																												break;
																											}
																											break;
																										}
																										goto IL_0230;
																										IL_0230:
																										if (1 < b)
																										{
																											goto end_IL_01ec;
																										}
																										goto IL_023e;
																										IL_023e:
																										if (1 <= b)
																										{
																										}
																										goto end_IL_01ec;
																									}
																									break;
																								}
																								goto IL_02d2;
																								IL_0342:
																								num5--;
																								goto end_IL_0225;
																								IL_02d2:
																								if (3 < b)
																								{
																									goto end_IL_01ec;
																								}
																								goto IL_02e0;
																								IL_02e0:
																								if (3 > b)
																								{
																									goto end_IL_01ec;
																								}
																								goto IL_02ee;
																								IL_02ee:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_032e;
																								IL_032e:
																								array[num5 - 2] = 0;
																								goto IL_0342;
																							}
																							break;
																						}
																						goto IL_0355;
																						IL_038c:
																						num5--;
																						goto end_IL_0225;
																						IL_0355:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_037e;
																						IL_037e:
																						ptr2 += 8;
																						goto IL_038c;
																					}
																					goto IL_03d4;
																					IL_0480:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0225;
																					IL_039f:
																					if (6 >= b)
																					{
																						goto IL_03aa;
																					}
																					goto IL_03ec;
																					IL_03aa:
																					if (6 <= b)
																					{
																						goto end_IL_0225;
																					}
																					goto IL_03b8;
																					IL_03b8:
																					if (5 < b)
																					{
																						goto end_IL_01ec;
																					}
																					goto IL_03c6;
																					IL_03c6:
																					if (5 > b)
																					{
																						goto end_IL_01ec;
																					}
																					goto IL_03d4;
																					IL_03d4:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0225;
																					IL_03ec:
																					if (7 >= b)
																					{
																						goto IL_03f7;
																					}
																					goto IL_046a;
																					IL_03f7:
																					if (7 > b)
																					{
																						goto end_IL_01ec;
																					}
																					goto IL_0405;
																					IL_0405:
																					array[num5] = 0;
																					goto IL_0413;
																					IL_0413:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0436;
																					IL_0436:
																					array2[num5] = null;
																					goto IL_0440;
																					IL_0440:
																					num5++;
																					goto IL_044e;
																					IL_044e:
																					ptr2 += 8;
																					num = 67;
																					goto end_IL_0225;
																					IL_046a:
																					if (8 < b)
																					{
																						num = 87;
																						goto end_IL_01ec;
																					}
																					goto IL_0475;
																					IL_0475:
																					if (8 > b)
																					{
																						goto end_IL_01ec;
																					}
																					goto IL_0480;
																					continue;
																					end_IL_01dc:
																					break;
																				}
																				continue;
																				end_IL_01ec:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04c5;
																		IL_04e1:
																		ptr2 += 8;
																		goto end_IL_0225;
																		IL_04d3:
																		num5++;
																		goto IL_04e1;
																		IL_04c5:
																		array[num5] = 0;
																		goto IL_04d3;
																		continue;
																		end_IL_01fc:
																		break;
																	}
																	continue;
																	end_IL_020c:
																	break;
																}
																continue;
																end_IL_0225:
																break;
															}
															continue;
														}
														goto IL_05a7;
														IL_05a7:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04ef:
														break;
													}
													continue;
													end_IL_0502:
													break;
												}
												continue;
												end_IL_050d:
												break;
											}
											continue;
											end_IL_0517:
											break;
										}
										continue;
										end_IL_0522:
										break;
									}
									continue;
									end_IL_0537:
									break;
								}
								continue;
								end_IL_054c:
								break;
							}
							continue;
							end_IL_055c:
							break;
						}
						continue;
						end_IL_056c:
						break;
					}
					continue;
					end_IL_057c:
					break;
				}
				continue;
				end_IL_058c:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_0)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 39;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 47;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetNestedTypeSystemAlarmCallback.IDisposableToIClosableAdapterStateMachineType);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_025d:
														byte b = *ptr2;
														while (true)
														{
															IL_024d:
															ptr2++;
															while (true)
															{
																IL_023d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0220:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0213:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0203:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_01f0:
																									if (6 < b)
																									{
																										num = 112;
																										while (true)
																										{
																											if (num != 112)
																											{
																												if (num != 1093)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 50:
																												case 82:
																													goto IL_01f0;
																												case 99:
																													goto IL_0203;
																												case 16:
																													goto IL_0213;
																												case 105:
																													goto IL_0220;
																												case 10:
																													goto IL_022d;
																												case 94:
																													goto IL_023d;
																												case 28:
																													goto IL_024d;
																												case 61:
																												case 103:
																													goto IL_025d;
																												case 18:
																													goto IL_0268;
																												case 38:
																													goto IL_0278;
																												case 12:
																													goto IL_0283;
																												case 29:
																													goto IL_029f;
																												case 15:
																												case 44:
																													goto IL_02af;
																												case 3:
																												case 55:
																													goto IL_02bf;
																												case 13:
																												case 58:
																													goto IL_02db;
																												case 64:
																													goto IL_02ee;
																												case 6:
																												case 21:
																													goto IL_02fc;
																												case 0:
																													goto IL_033c;
																												case 30:
																													goto IL_0350;
																												case 36:
																												case 67:
																													goto IL_0363;
																												case 20:
																													goto IL_0371;
																												case 11:
																													goto IL_0394;
																												case 22:
																													goto IL_03a7;
																												case 84:
																													goto IL_03c3;
																												case 91:
																													goto IL_03d6;
																												case 26:
																												case 70:
																													goto IL_03e1;
																												case 60:
																													goto IL_040a;
																												case 35:
																													goto IL_041a;
																												case 85:
																													goto IL_0428;
																												case 71:
																												case 92:
																													goto IL_0438;
																												case 7:
																													goto IL_0446;
																												case 98:
																													goto IL_0459;
																												case 101:
																													goto IL_046c;
																												case 27:
																												case 57:
																													goto IL_047a;
																												case 102:
																													goto IL_0492;
																												case 5:
																												case 104:
																													goto IL_04a5;
																												case 76:
																													goto IL_04be;
																												case 72:
																													goto IL_04cc;
																												case 54:
																													goto IL_04da;
																												case 79:
																													goto IL_04ed;
																												case 4:
																													goto IL_04f8;
																												case 14:
																												case 32:
																													goto IL_0503;
																												case 52:
																													goto IL_0526;
																												case 42:
																													goto IL_0534;
																												case 75:
																													goto IL_0542;
																												case 1:
																												case 2:
																												case 9:
																												case 17:
																												case 34:
																												case 43:
																												case 46:
																												case 48:
																												case 49:
																												case 65:
																												case 66:
																												case 68:
																												case 69:
																												case 73:
																												case 74:
																												case 77:
																												case 80:
																												case 81:
																												case 86:
																												case 95:
																													goto end_IL_022d;
																												case 25:
																												case 96:
																													goto IL_056a;
																												case 41:
																													goto IL_05d5;
																												case 8:
																												case 19:
																												case 23:
																												case 31:
																												case 33:
																												case 37:
																												case 53:
																												case 59:
																												case 83:
																												case 87:
																												case 88:
																												case 89:
																												case 97:
																													goto end_IL_01dd;
																												case 56:
																													goto end_IL_05e3;
																												case 100:
																													goto end_IL_05f6;
																												case 93:
																													goto end_IL_0600;
																												case 78:
																													goto end_IL_060b;
																												case 47:
																												case 90:
																													goto end_IL_0620;
																												case 45:
																													goto end_IL_0630;
																												case 39:
																												case 51:
																													goto end_IL_0640;
																												case 62:
																													goto end_IL_0659;
																												case 63:
																													goto end_IL_0669;
																												case 24:
																												case 40:
																													goto IL_068d;
																												}
																												continue;
																											}
																											goto IL_04ed;
																											IL_0534:
																											num5++;
																											goto IL_0542;
																											IL_0542:
																											ptr2 += 8;
																											break;
																											IL_04ed:
																											if (7 < b)
																											{
																												goto end_IL_022d;
																											}
																											goto IL_04f8;
																											IL_04f8:
																											if (7 > b)
																											{
																												goto end_IL_022d;
																											}
																											goto IL_0503;
																											IL_0503:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0526;
																											IL_0526:
																											array[num5] = 0;
																											goto IL_0534;
																											continue;
																											end_IL_01dd:
																											break;
																										}
																										break;
																									}
																									goto IL_02ee;
																									IL_033c:
																									array[num5 - 2] = 0;
																									goto IL_0350;
																									IL_0350:
																									num5--;
																									break;
																									IL_02ee:
																									if (6 > b)
																									{
																										goto end_IL_022d;
																									}
																									goto IL_02fc;
																									IL_02fc:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_033c;
																								}
																								break;
																							}
																							goto IL_056a;
																							IL_05d5:
																							num5 -= 2;
																							break;
																							IL_056a:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 41;
																							goto IL_05d5;
																						}
																						break;
																					}
																					goto IL_0278;
																					IL_029f:
																					if (9 > b)
																					{
																						goto end_IL_022d;
																					}
																					goto IL_02bf;
																					IL_0278:
																					if (9 < b)
																					{
																						goto IL_0283;
																					}
																					num = 29;
																					goto IL_029f;
																					IL_0283:
																					if (10 < b)
																					{
																						goto end_IL_022d;
																					}
																					goto IL_03c3;
																					IL_03c3:
																					if (10 <= b)
																					{
																					}
																					goto end_IL_022d;
																					IL_02bf:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																				}
																				break;
																			}
																			goto IL_0268;
																			IL_0459:
																			ptr2 += 8;
																			break;
																			IL_0268:
																			if (5 > b)
																			{
																				goto IL_02af;
																			}
																			goto IL_0363;
																			IL_02af:
																			if (2 < b)
																			{
																				goto IL_02db;
																			}
																			goto IL_03d6;
																			IL_02db:
																			if (3 < b)
																			{
																				goto IL_0438;
																			}
																			goto IL_046c;
																			IL_046c:
																			if (3 > b)
																			{
																				goto end_IL_022d;
																			}
																			goto IL_047a;
																			IL_047a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0438:
																			if (4 < b)
																			{
																				goto end_IL_022d;
																			}
																			goto IL_0446;
																			IL_0446:
																			if (4 > b)
																			{
																				goto end_IL_022d;
																			}
																			break;
																			IL_03d6:
																			if (2 <= b)
																			{
																				goto IL_03e1;
																			}
																			goto IL_041a;
																			IL_03e1:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_040a;
																			IL_040a:
																			ptr2 += 8;
																			goto IL_0492;
																			IL_0492:
																			num5--;
																			break;
																			IL_041a:
																			if (1 < b)
																			{
																				goto end_IL_022d;
																			}
																			goto IL_0428;
																			IL_0428:
																			if (1 > b)
																			{
																				goto end_IL_022d;
																			}
																			goto IL_04a5;
																			IL_04a5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04be;
																			IL_04be:
																			array[num5] = 0;
																			goto IL_04cc;
																			IL_04cc:
																			num5++;
																			goto IL_04da;
																			IL_04da:
																			ptr2 += 8;
																			break;
																			IL_0363:
																			array[num5] = 0;
																			goto IL_0371;
																			IL_0371:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0394;
																			IL_0394:
																			array2[num5] = null;
																			num = 22;
																			goto IL_03a7;
																			IL_03a7:
																			num5++;
																			num = 98;
																			goto IL_0459;
																		}
																		goto end_IL_023d;
																		continue;
																		end_IL_022d:
																		break;
																		IL_022d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_023d:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_068d;
												IL_068d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05e3:
												break;
											}
											continue;
											end_IL_05f6:
											break;
										}
										continue;
										end_IL_0600:
										break;
									}
									continue;
									end_IL_060b:
									break;
								}
								continue;
								end_IL_0620:
								break;
							}
							continue;
							end_IL_0630:
							break;
						}
						continue;
						end_IL_0640:
						break;
					}
					continue;
					end_IL_0659:
					break;
				}
				continue;
				end_IL_0669:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_0, int int_1)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							num = 31;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IVectorRawgetLicenseFile.CallContextsetFormat);
											num = 44;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02c0:
															byte b = *ptr2;
															while (true)
															{
																IL_02b0:
																ptr2++;
																while (true)
																{
																	IL_02a0:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0280:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0270:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0263:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0253:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_0211:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01fb:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_01e2:
																														num5--;
																														num = 112;
																														while (num != 112)
																														{
																															if (num != 1093)
																															{
																																goto end_IL_0290;
																															}
																															switch (num)
																															{
																															case 36:
																																goto IL_01e2;
																															case 81:
																																goto IL_01fb;
																															case 66:
																															case 90:
																																goto IL_0211;
																															case 30:
																																goto IL_0253;
																															case 15:
																																goto IL_0263;
																															case 46:
																																goto IL_0270;
																															case 70:
																																goto IL_0280;
																															case 35:
																																goto IL_0290;
																															case 22:
																																goto IL_02a0;
																															case 26:
																																goto IL_02b0;
																															case 41:
																															case 73:
																																goto IL_02c0;
																															case 20:
																															case 91:
																																goto IL_02cb;
																															case 61:
																																goto IL_02d6;
																															case 8:
																																goto IL_02e6;
																															case 10:
																															case 92:
																																goto IL_02f6;
																															case 62:
																																goto IL_031f;
																															case 13:
																																goto IL_032d;
																															case 100:
																																goto IL_0340;
																															case 76:
																															case 83:
																																goto IL_034e;
																															case 102:
																																goto IL_038e;
																															case 80:
																																goto IL_03a2;
																															case 87:
																																goto IL_03b5;
																															case 49:
																																goto IL_03c3;
																															case 45:
																															case 72:
																																goto IL_03df;
																															case 84:
																																goto IL_03ed;
																															case 42:
																																goto IL_0410;
																															case 34:
																																goto IL_041a;
																															case 65:
																																goto IL_0428;
																															case 86:
																																goto IL_043b;
																															case 77:
																																goto IL_0449;
																															case 7:
																															case 11:
																																goto IL_0454;
																															case 25:
																																goto IL_046d;
																															case 16:
																																goto IL_047b;
																															case 93:
																																goto IL_0489;
																															case 29:
																																goto IL_049c;
																															case 54:
																																goto IL_04aa;
																															case 17:
																															case 56:
																																goto IL_04b8;
																															case 63:
																																goto IL_04f8;
																															case 68:
																																goto IL_050c;
																															case 85:
																																goto IL_051f;
																															case 21:
																																goto IL_052a;
																															case 50:
																															case 58:
																																goto IL_0538;
																															case 96:
																																goto IL_0578;
																															case 55:
																																goto IL_058c;
																															case 28:
																															case 97:
																																goto IL_059c;
																															case 99:
																																goto IL_05a7;
																															case 6:
																															case 18:
																																goto IL_05b2;
																															case 3:
																															case 4:
																															case 5:
																															case 9:
																															case 27:
																															case 37:
																															case 40:
																															case 43:
																															case 47:
																															case 52:
																															case 53:
																															case 57:
																															case 59:
																															case 67:
																															case 69:
																															case 71:
																															case 79:
																															case 82:
																															case 98:
																															case 101:
																															case 103:
																																goto end_IL_0290;
																															case 78:
																																goto IL_05ee;
																															case 2:
																																goto IL_05fc;
																															case 32:
																																goto IL_060a;
																															case 12:
																															case 14:
																															case 38:
																															case 51:
																															case 60:
																															case 88:
																															case 94:
																															case 95:
																															case 104:
																															case 105:
																																goto end_IL_01cf;
																															case 44:
																																goto end_IL_0618;
																															case 48:
																																goto end_IL_062b;
																															case 39:
																																goto end_IL_0635;
																															case 19:
																																goto end_IL_0649;
																															case 31:
																																goto end_IL_065e;
																															case 0:
																															case 89:
																																goto end_IL_0673;
																															case 33:
																																goto end_IL_0683;
																															case 24:
																															case 64:
																																goto end_IL_069c;
																															case 74:
																																goto end_IL_06ac;
																															case 75:
																																goto end_IL_06bc;
																															case 1:
																															case 23:
																																goto IL_06d7;
																															}
																															continue;
																															end_IL_01cf:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_03b5;
																										IL_03c3:
																										if (1 <= b)
																										{
																										}
																										goto end_IL_0290;
																										IL_03b5:
																										if (1 < b)
																										{
																											goto end_IL_0290;
																										}
																										goto IL_03c3;
																									}
																									break;
																								}
																								goto IL_02cb;
																								IL_03a2:
																								num5--;
																								break;
																								IL_02cb:
																								if (3 >= b)
																								{
																									goto IL_02d6;
																								}
																								goto IL_02e6;
																								IL_02d6:
																								if (3 > b)
																								{
																									goto end_IL_0290;
																								}
																								goto IL_02f6;
																								IL_02f6:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_031f;
																								IL_031f:
																								ptr2 += 8;
																								goto IL_032d;
																								IL_032d:
																								num5--;
																								break;
																								IL_02e6:
																								if (4 < b)
																								{
																									goto end_IL_0290;
																								}
																								goto IL_0340;
																								IL_0340:
																								if (4 > b)
																								{
																									goto end_IL_0290;
																								}
																								goto IL_034e;
																								IL_034e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_038e;
																								IL_038e:
																								array[num5 - 2] = 0;
																								goto IL_03a2;
																							}
																							break;
																						}
																						num = 45;
																						goto IL_03df;
																						IL_041a:
																						num5++;
																						goto IL_0428;
																						IL_0428:
																						ptr2 += 8;
																						break;
																						IL_03df:
																						array[num5] = 0;
																						goto IL_03ed;
																						IL_03ed:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0410;
																						IL_0410:
																						array2[num5] = null;
																						goto IL_041a;
																					}
																					break;
																				}
																				goto IL_043b;
																				IL_05b2:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_043b:
																				if (7 >= b)
																				{
																					goto IL_0449;
																				}
																				goto IL_051f;
																				IL_0449:
																				if (7 <= b)
																				{
																					goto IL_0454;
																				}
																				goto IL_049c;
																				IL_0454:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_046d;
																				IL_046d:
																				array[num5] = 0;
																				goto IL_047b;
																				IL_047b:
																				num5++;
																				goto IL_0489;
																				IL_0489:
																				ptr2 += 8;
																				break;
																				IL_049c:
																				if (6 < b)
																				{
																					goto end_IL_0290;
																				}
																				goto IL_04aa;
																				IL_04aa:
																				if (6 > b)
																				{
																					goto end_IL_0290;
																				}
																				goto IL_04b8;
																				IL_04b8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f8;
																				IL_04f8:
																				array[num5 - 2] = 0;
																				goto IL_050c;
																				IL_050c:
																				num5--;
																				break;
																				IL_051f:
																				if (8 >= b)
																				{
																					goto IL_052a;
																				}
																				goto IL_059c;
																				IL_052a:
																				if (8 > b)
																				{
																					goto end_IL_0290;
																				}
																				goto IL_0538;
																				IL_0538:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0578;
																				IL_0578:
																				array[num5 - 2] = 0;
																				goto IL_058c;
																				IL_058c:
																				num5--;
																				break;
																				IL_059c:
																				if (9 < b)
																				{
																					goto end_IL_0290;
																				}
																				goto IL_05a7;
																				IL_05a7:
																				if (9 > b)
																				{
																					goto end_IL_0290;
																				}
																				goto IL_05b2;
																			}
																			goto end_IL_02a0;
																			continue;
																			end_IL_0290:
																			break;
																			IL_0290:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05ee;
																	IL_060a:
																	ptr2 += 8;
																	break;
																	IL_05fc:
																	num5++;
																	goto IL_060a;
																	IL_05ee:
																	array[num5] = 0;
																	goto IL_05fc;
																	continue;
																	end_IL_02a0:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06d7;
													IL_06d7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0618:
													break;
												}
												continue;
												end_IL_062b:
												break;
											}
											continue;
											end_IL_0635:
											break;
										}
										continue;
										end_IL_0649:
										break;
									}
									continue;
									end_IL_065e:
									break;
								}
								continue;
								end_IL_0673:
								break;
							}
							continue;
							end_IL_0683:
							break;
						}
						continue;
						end_IL_069c:
						break;
					}
					continue;
					end_IL_06ac:
					break;
				}
				continue;
				end_IL_06bc:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 83;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OpenSaveIsByRefLikeAttribute.IndexerNameAttributeICustomProperty);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0392:
														num = 55;
														while (true)
														{
															IL_0387:
															byte b = *ptr2;
															while (true)
															{
																IL_0377:
																ptr2++;
																while (true)
																{
																	IL_0367:
																	if (b >= 1)
																	{
																		while (b <= 17)
																		{
																			while (true)
																			{
																				IL_0347:
																				if (9 >= b)
																				{
																					while (9 > b)
																					{
																						while (true)
																						{
																							IL_0327:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_0317:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_0307:
																											if (2 < b)
																											{
																												while (true)
																												{
																													IL_02f4:
																													if (3 < b)
																													{
																														num = 177;
																														while (num != 177)
																														{
																															if (num != 1158)
																															{
																																goto IL_0a6a;
																															}
																															switch (num)
																															{
																															case 69:
																															case 86:
																																goto IL_02f4;
																															case 64:
																															case 127:
																																goto IL_0307;
																															case 58:
																																goto IL_0317;
																															case 154:
																															case 165:
																																goto IL_0327;
																															case 95:
																																goto IL_0337;
																															case 89:
																																goto IL_0347;
																															case 73:
																																goto IL_0357;
																															case 103:
																																goto IL_0367;
																															case 28:
																																goto IL_0377;
																															case 55:
																																goto IL_0387;
																															case 92:
																																goto IL_0392;
																															case 68:
																																goto IL_039d;
																															case 99:
																																goto IL_03ad;
																															case 1:
																															case 102:
																																goto IL_03bb;
																															case 126:
																																goto IL_03ed;
																															case 100:
																															case 141:
																																goto IL_0406;
																															case 10:
																																goto IL_0446;
																															case 22:
																																goto IL_045a;
																															case 79:
																															case 153:
																																goto IL_046d;
																															case 159:
																																goto IL_047b;
																															case 150:
																															case 152:
																																goto IL_0489;
																															case 66:
																																goto IL_04a2;
																															case 36:
																																goto IL_04b0;
																															case 30:
																																goto IL_04be;
																															case 60:
																															case 120:
																																goto IL_04d1;
																															case 162:
																																goto IL_04ef;
																															case 160:
																																goto IL_0506;
																															case 4:
																																goto IL_0519;
																															case 25:
																																goto IL_0527;
																															case 59:
																															case 119:
																																goto IL_0532;
																															case 3:
																																goto IL_0571;
																															case 12:
																															case 18:
																																goto IL_058d;
																															case 123:
																																goto IL_059b;
																															case 70:
																															case 101:
																																goto IL_05a9;
																															case 105:
																																goto IL_05b7;
																															case 82:
																																goto IL_05cf;
																															case 41:
																																goto IL_05dd;
																															case 84:
																																goto IL_05f0;
																															case 106:
																																goto IL_05fb;
																															case 34:
																															case 168:
																																goto IL_0609;
																															case 72:
																																goto IL_0632;
																															case 166:
																																goto IL_0640;
																															case 114:
																																goto IL_0653;
																															case 67:
																																goto IL_0661;
																															case 56:
																															case 170:
																																goto IL_0678;
																															case 90:
																															case 164:
																																goto IL_0690;
																															case 78:
																															case 115:
																																goto IL_069e;
																															case 11:
																															case 111:
																																goto IL_06a9;
																															case 133:
																															case 134:
																																goto IL_06b4;
																															case 143:
																																goto IL_06cd;
																															case 46:
																																goto IL_06e0;
																															case 2:
																															case 144:
																																goto IL_06ee;
																															case 87:
																																goto IL_070a;
																															case 20:
																															case 138:
																																goto IL_0715;
																															case 157:
																																goto IL_0728;
																															case 5:
																																goto IL_0736;
																															case 17:
																															case 52:
																																goto IL_0744;
																															case 7:
																																goto IL_0761;
																															case 98:
																																goto IL_07a0;
																															case 147:
																																goto IL_07b3;
																															case 51:
																															case 61:
																																goto IL_07c1;
																															case 125:
																																goto IL_07cf;
																															case 0:
																															case 40:
																																goto IL_07da;
																															case 75:
																																goto IL_081e;
																															case 9:
																																goto IL_0832;
																															case 65:
																																goto IL_0845;
																															case 63:
																																goto IL_0853;
																															case 145:
																															case 163:
																																goto IL_0861;
																															case 128:
																																goto IL_086f;
																															case 37:
																																goto IL_0892;
																															case 27:
																																goto IL_089c;
																															case 108:
																																goto IL_08aa;
																															case 135:
																																goto IL_08bd;
																															case 45:
																																goto IL_08cb;
																															case 88:
																															case 113:
																																goto IL_08d9;
																															case 15:
																																goto IL_0922;
																															case 74:
																																goto IL_0936;
																															case 48:
																															case 130:
																																goto IL_0949;
																															case 35:
																																goto IL_09ab;
																															case 19:
																															case 21:
																															case 23:
																															case 26:
																															case 38:
																															case 39:
																															case 42:
																															case 43:
																															case 44:
																															case 47:
																															case 49:
																															case 50:
																															case 53:
																															case 76:
																															case 80:
																															case 81:
																															case 85:
																															case 91:
																															case 93:
																															case 94:
																															case 96:
																															case 97:
																															case 110:
																															case 116:
																															case 124:
																															case 129:
																															case 139:
																															case 142:
																															case 148:
																															case 151:
																															case 155:
																															case 158:
																															case 161:
																															case 169:
																																goto end_IL_02e1;
																															case 6:
																															case 13:
																															case 14:
																															case 16:
																															case 24:
																															case 29:
																															case 33:
																															case 54:
																															case 57:
																															case 77:
																															case 104:
																															case 109:
																															case 117:
																															case 118:
																															case 121:
																															case 122:
																															case 131:
																															case 132:
																															case 146:
																															case 156:
																																goto end_IL_0337;
																															case 149:
																																goto end_IL_09ce;
																															case 137:
																																goto end_IL_09e1;
																															case 83:
																																goto end_IL_09eb;
																															case 167:
																																goto end_IL_09f6;
																															case 62:
																															case 112:
																																goto end_IL_0a06;
																															case 8:
																																goto end_IL_0a1f;
																															case 71:
																															case 140:
																																goto end_IL_0a2f;
																															case 31:
																																goto end_IL_0a3f;
																															case 32:
																																goto end_IL_0a4f;
																															case 107:
																															case 136:
																																goto IL_0a6a;
																															}
																															continue;
																															end_IL_02e1:
																															break;
																														}
																														break;
																													}
																													goto IL_03ad;
																													IL_03bb:
																													array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													num = 126;
																													goto IL_03ed;
																													IL_03ed:
																													array[num5 - 1] = 5;
																													goto end_IL_0337;
																													IL_03ad:
																													if (3 > b)
																													{
																														break;
																													}
																													goto IL_03bb;
																												}
																												break;
																											}
																											goto IL_039d;
																											IL_045a:
																											num5--;
																											goto end_IL_0337;
																											IL_039d:
																											if (2 <= b)
																											{
																												goto IL_0406;
																											}
																											goto IL_046d;
																											IL_046d:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_047b;
																											IL_047b:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0489;
																											IL_0489:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_04a2;
																											IL_04a2:
																											array[num5] = 0;
																											goto IL_04b0;
																											IL_04b0:
																											num5++;
																											goto IL_04be;
																											IL_04be:
																											ptr2 += 8;
																											goto end_IL_0337;
																											IL_0406:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0446;
																											IL_0446:
																											array[num5 - 2] = 0;
																											goto IL_045a;
																										}
																										break;
																									}
																									goto IL_04d1;
																									IL_0506:
																									num5--;
																									goto end_IL_0337;
																									IL_04d1:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_04ef;
																									IL_04ef:
																									ptr2 += 8;
																									num = 160;
																									goto IL_0506;
																								}
																								break;
																							}
																							goto IL_0519;
																							IL_0661:
																							if (8 > b)
																							{
																								break;
																							}
																							num = 170;
																							goto IL_0678;
																							IL_0519:
																							if (6 >= b)
																							{
																								goto IL_0527;
																							}
																							goto IL_05f0;
																							IL_0527:
																							if (6 <= b)
																							{
																								goto IL_0532;
																							}
																							num = 12;
																							goto IL_058d;
																							IL_0532:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0571;
																							IL_0571:
																							num5 -= 3;
																							goto end_IL_0337;
																							IL_0678:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0337;
																							IL_058d:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_059b;
																							IL_059b:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_05a9;
																							IL_05a9:
																							array[num5] = 5;
																							goto IL_05b7;
																							IL_05b7:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_05cf;
																							IL_05cf:
																							num5++;
																							goto IL_05dd;
																							IL_05dd:
																							ptr2 += 8;
																							goto end_IL_0337;
																							IL_05f0:
																							if (7 >= b)
																							{
																								goto IL_05fb;
																							}
																							goto IL_0653;
																							IL_05fb:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0609;
																							IL_0609:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0632;
																							IL_0632:
																							ptr2 += 8;
																							goto IL_0640;
																							IL_0640:
																							num5--;
																							goto end_IL_0337;
																							IL_0653:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_0661;
																						}
																						goto end_IL_0357;
																						continue;
																						end_IL_0337:
																						break;
																						IL_0337:;
																					}
																					break;
																				}
																				goto IL_0690;
																				IL_0949:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_09ab;
																				IL_0690:
																				if (13 < b)
																				{
																					goto IL_069e;
																				}
																				goto IL_07b3;
																				IL_069e:
																				if (15 < b)
																				{
																					goto IL_06a9;
																				}
																				goto IL_070a;
																				IL_06a9:
																				if (16 < b)
																				{
																					goto IL_06b4;
																				}
																				goto IL_06e0;
																				IL_06b4:
																				if (17 < b)
																				{
																					num = 26;
																					goto end_IL_0357;
																				}
																				goto IL_06cd;
																				IL_09ab:
																				num5 -= 2;
																				break;
																				IL_06cd:
																				if (17 <= b)
																				{
																				}
																				goto end_IL_0357;
																				IL_06e0:
																				if (16 > b)
																				{
																					goto end_IL_0357;
																				}
																				goto IL_06ee;
																				IL_06ee:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_070a:
																				if (15 <= b)
																				{
																					goto IL_0715;
																				}
																				goto IL_0728;
																				IL_0715:
																				num5--;
																				break;
																				IL_0728:
																				if (14 < b)
																				{
																					goto end_IL_0357;
																				}
																				goto IL_0736;
																				IL_0736:
																				if (14 > b)
																				{
																					goto end_IL_0357;
																				}
																				goto IL_0744;
																				IL_0744:
																				array[num5 - 1] = 0;
																				num = 7;
																				goto IL_0761;
																				IL_0761:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)DSClientWellKnownEntry[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_07a0;
																				IL_07a0:
																				ptr2 += 8;
																				break;
																				IL_07b3:
																				if (13 > b)
																				{
																					goto IL_07c1;
																				}
																				goto IL_0949;
																				IL_07c1:
																				if (11 >= b)
																				{
																					goto IL_07cf;
																				}
																				goto IL_08bd;
																				IL_07cf:
																				if (11 <= b)
																				{
																					goto IL_07da;
																				}
																				goto IL_0845;
																				IL_07da:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_081e;
																				IL_081e:
																				array[num5 - 2] = 0;
																				goto IL_0832;
																				IL_0832:
																				num5--;
																				break;
																				IL_0845:
																				if (10 < b)
																				{
																					goto end_IL_0357;
																				}
																				goto IL_0853;
																				IL_0853:
																				if (10 > b)
																				{
																					goto end_IL_0357;
																				}
																				goto IL_0861;
																				IL_0861:
																				array[num5] = 0;
																				goto IL_086f;
																				IL_086f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0892;
																				IL_0892:
																				array2[num5] = null;
																				goto IL_089c;
																				IL_089c:
																				num5++;
																				goto IL_08aa;
																				IL_08aa:
																				ptr2 += 8;
																				break;
																				IL_08bd:
																				if (12 < b)
																				{
																					goto end_IL_0357;
																				}
																				goto IL_08cb;
																				IL_08cb:
																				if (12 > b)
																				{
																					goto end_IL_0357;
																				}
																				goto IL_08d9;
																				IL_08d9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 15;
																				goto IL_0922;
																				IL_0922:
																				array[num5 - 2] = 0;
																				goto IL_0936;
																				IL_0936:
																				num5--;
																				break;
																			}
																			goto end_IL_0367;
																			continue;
																			end_IL_0357:
																			break;
																			IL_0357:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0367:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a6a;
												IL_0a6a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09ce:
												break;
											}
											continue;
											end_IL_09e1:
											break;
										}
										continue;
										end_IL_09eb:
										break;
									}
									continue;
									end_IL_09f6:
									break;
								}
								continue;
								end_IL_0a06:
								break;
							}
							continue;
							end_IL_0a1f:
							break;
						}
						continue;
						end_IL_0a2f:
						break;
					}
					continue;
					end_IL_0a3f:
					break;
				}
				continue;
				end_IL_0a4f:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 97;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ContextInlineQueryInterface.EncoderFallbackBufferChainSelector);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 33;
												while (true)
												{
													IL_068e:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0303:
															byte b = *ptr2;
															num = 91;
															while (true)
															{
																IL_02f3:
																ptr2++;
																while (true)
																{
																	IL_02e3:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02c0:
																				if (6 >= b)
																				{
																					num = 65;
																					while (true)
																					{
																						IL_02b3:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_02a6:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0296:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (true)
																												{
																													IL_0276:
																													if (5 <= b)
																													{
																														while (true)
																														{
																															IL_0266:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_0241:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																while (true)
																																{
																																	IL_0235:
																																	array2[num5] = null;
																																	while (true)
																																	{
																																		IL_021c:
																																		num5++;
																																		num = 123;
																																		while (true)
																																		{
																																			if (num != 123)
																																			{
																																				if (num != 1104)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 23:
																																					goto IL_021c;
																																				case 113:
																																					goto IL_0235;
																																				case 88:
																																					goto IL_0241;
																																				case 26:
																																				case 44:
																																					goto IL_0266;
																																				case 68:
																																					goto IL_0276;
																																				case 17:
																																				case 53:
																																					goto IL_0286;
																																				case 76:
																																				case 93:
																																					goto IL_0296;
																																				case 87:
																																					goto IL_02a6;
																																				case 65:
																																					goto IL_02b3;
																																				case 4:
																																					goto IL_02c0;
																																				case 50:
																																					goto IL_02d3;
																																				case 90:
																																					goto IL_02e3;
																																				case 91:
																																					goto IL_02f3;
																																				case 75:
																																				case 114:
																																					goto IL_0303;
																																				case 58:
																																					goto IL_0317;
																																				case 54:
																																				case 60:
																																					goto IL_0327;
																																				case 61:
																																					goto IL_0367;
																																				case 32:
																																					goto IL_037b;
																																				case 63:
																																					goto IL_038e;
																																				case 62:
																																					goto IL_0399;
																																				case 0:
																																				case 79:
																																					goto IL_03ac;
																																				case 35:
																																					goto IL_03b7;
																																				case 15:
																																				case 77:
																																					goto IL_03c5;
																																				case 48:
																																					goto IL_03ee;
																																				case 39:
																																					goto IL_03fc;
																																				case 38:
																																				case 82:
																																					goto IL_041d;
																																				case 22:
																																				case 85:
																																					goto IL_0435;
																																				case 70:
																																					goto IL_044e;
																																				case 43:
																																					goto IL_045c;
																																				case 106:
																																					goto IL_046a;
																																				case 6:
																																					goto IL_049e;
																																				case 103:
																																					goto IL_04b1;
																																				case 29:
																																					goto IL_04bf;
																																				case 19:
																																				case 40:
																																					goto IL_04cd;
																																				case 42:
																																				case 95:
																																					goto IL_04d8;
																																				case 52:
																																					goto IL_04e6;
																																				case 89:
																																				case 98:
																																					goto IL_04f4;
																																				case 47:
																																					goto IL_0517;
																																				case 78:
																																					goto IL_0525;
																																				case 56:
																																					goto IL_0533;
																																				case 10:
																																					goto IL_0546;
																																				case 72:
																																				case 81:
																																					goto IL_0554;
																																				case 73:
																																					goto IL_0594;
																																				case 31:
																																					goto IL_05a8;
																																				case 13:
																																				case 109:
																																					goto IL_05bb;
																																				case 86:
																																					goto IL_061d;
																																				case 45:
																																					goto IL_062d;
																																				case 83:
																																					goto IL_0638;
																																				case 49:
																																				case 74:
																																					goto IL_0643;
																																				case 108:
																																					goto IL_065c;
																																				case 112:
																																					goto IL_0667;
																																				case 5:
																																				case 7:
																																				case 8:
																																				case 11:
																																				case 14:
																																				case 16:
																																				case 18:
																																				case 20:
																																				case 24:
																																				case 25:
																																				case 30:
																																				case 34:
																																				case 46:
																																				case 64:
																																				case 66:
																																				case 67:
																																				case 69:
																																				case 80:
																																				case 84:
																																				case 92:
																																				case 94:
																																				case 107:
																																				case 110:
																																				case 111:
																																					goto end_IL_0286;
																																				case 2:
																																				case 3:
																																				case 9:
																																				case 12:
																																				case 21:
																																				case 28:
																																				case 33:
																																				case 36:
																																				case 41:
																																				case 57:
																																				case 59:
																																				case 101:
																																				case 105:
																																					goto IL_068e;
																																				case 116:
																																					goto end_IL_068e;
																																				case 115:
																																					goto end_IL_06a1;
																																				case 51:
																																					goto end_IL_06ac;
																																				case 71:
																																					goto end_IL_06b6;
																																				case 37:
																																					goto end_IL_06c1;
																																				case 55:
																																				case 102:
																																					goto end_IL_06d6;
																																				case 100:
																																					goto end_IL_06e6;
																																				case 27:
																																				case 104:
																																					goto end_IL_06f6;
																																				case 96:
																																					goto end_IL_0706;
																																				case 97:
																																					goto end_IL_0716;
																																				case 1:
																																				case 99:
																																					goto end_IL_0209;
																																				}
																																				continue;
																																			}
																																			ptr2 += 8;
																																			goto IL_068e;
																																			continue;
																																			end_IL_0209:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													num = 111;
																													goto end_IL_0286;
																												}
																												goto end_IL_02e3;
																												continue;
																												end_IL_0286:
																												break;
																												IL_0286:;
																											}
																											break;
																										}
																										goto IL_049e;
																										IL_049e:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_068e;
																									}
																									break;
																								}
																								goto IL_0317;
																								IL_03fc:
																								num5--;
																								goto IL_068e;
																								IL_0317:
																								if (3 > b)
																								{
																									goto IL_038e;
																								}
																								goto IL_041d;
																								IL_041d:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto IL_068e;
																								IL_038e:
																								if (1 >= b)
																								{
																									goto IL_0399;
																								}
																								goto IL_03ac;
																								IL_0399:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0435;
																								IL_0435:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_044e;
																								IL_044e:
																								array[num5] = 0;
																								goto IL_045c;
																								IL_045c:
																								num5++;
																								goto IL_046a;
																								IL_046a:
																								ptr2 += 8;
																								goto IL_068e;
																								IL_03ac:
																								if (2 < b)
																								{
																									num = 14;
																									break;
																								}
																								goto IL_03b7;
																								IL_03b7:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_03c5;
																								IL_03c5:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03ee;
																								IL_03ee:
																								ptr2 += 8;
																								goto IL_03fc;
																							}
																							break;
																						}
																						goto IL_0327;
																						IL_037b:
																						num5--;
																						goto IL_068e;
																						IL_0327:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0367;
																						IL_0367:
																						array[num5 - 2] = 0;
																						goto IL_037b;
																					}
																					break;
																				}
																				goto IL_04b1;
																				IL_065c:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0667;
																				IL_0667:
																				if (11 <= b)
																				{
																					num = 84;
																				}
																				break;
																				IL_04b1:
																				if (9 >= b)
																				{
																					goto IL_04bf;
																				}
																				goto IL_062d;
																				IL_04bf:
																				if (9 > b)
																				{
																					goto IL_04cd;
																				}
																				goto IL_05bb;
																				IL_04cd:
																				if (7 < b)
																				{
																					goto IL_04d8;
																				}
																				goto IL_0546;
																				IL_04d8:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_04e6;
																				IL_04e6:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04f4;
																				IL_04f4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0517;
																				IL_0517:
																				array[num5] = 0;
																				goto IL_0525;
																				IL_0525:
																				num5++;
																				goto IL_0533;
																				IL_0533:
																				ptr2 += 8;
																				goto IL_068e;
																				IL_0546:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0554;
																				IL_0554:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0594;
																				IL_0594:
																				array[num5 - 2] = 0;
																				goto IL_05a8;
																				IL_05a8:
																				num5--;
																				goto IL_068e;
																				IL_05bb:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_061d;
																				IL_061d:
																				num5 -= 2;
																				goto IL_068e;
																				IL_062d:
																				if (10 >= b)
																				{
																					goto IL_0638;
																				}
																				goto IL_065c;
																				IL_0638:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0643;
																				IL_0643:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_068e;
																			}
																			break;
																			IL_02d3:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_068e;
																	continue;
																	end_IL_02e3:
																	break;
																}
																break;
															}
															break;
														}
													}
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_068e:
													break;
												}
												continue;
												end_IL_06a1:
												break;
											}
											continue;
											end_IL_06ac:
											break;
										}
										continue;
										end_IL_06b6:
										break;
									}
									continue;
									end_IL_06c1:
									break;
								}
								continue;
								end_IL_06d6:
								break;
							}
							continue;
							end_IL_06e6:
							break;
						}
						continue;
						end_IL_06f6:
						break;
					}
					continue;
					end_IL_0706:
					break;
				}
				continue;
				end_IL_0716:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_0)
	{
		int num = 97;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									num = 41;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FindTypesFromAsync.KeyAvailableUTFBufferMarshaler);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0286:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0266:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0256:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0249:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_023c:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_01f7:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													while (true)
																													{
																														IL_01e7:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_01ce:
																															num5++;
																															num = 107;
																															while (true)
																															{
																																if (num != 107)
																																{
																																	if (num != 1088)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 46:
																																		goto IL_01ce;
																																	case 17:
																																		goto IL_01e7;
																																	case 51:
																																	case 71:
																																		goto IL_01f7;
																																	case 61:
																																		goto IL_021c;
																																	case 81:
																																		goto IL_022c;
																																	case 84:
																																		goto IL_023c;
																																	case 73:
																																		goto IL_0249;
																																	case 22:
																																	case 39:
																																		goto IL_0256;
																																	case 3:
																																		goto IL_0266;
																																	case 53:
																																		goto IL_0276;
																																	case 77:
																																		goto IL_0286;
																																	case 87:
																																		goto end_IL_0286;
																																	case 20:
																																	case 67:
																																		goto end_IL_0296;
																																	case 60:
																																		goto IL_02bc;
																																	case 31:
																																	case 42:
																																		goto IL_02ca;
																																	case 7:
																																		goto IL_030a;
																																	case 44:
																																		goto IL_031e;
																																	case 63:
																																	case 76:
																																		goto IL_0331;
																																	case 23:
																																		goto IL_0393;
																																	case 85:
																																		goto IL_03b9;
																																	case 38:
																																		goto IL_03c4;
																																	case 79:
																																		goto IL_03d2;
																																	case 100:
																																		goto IL_03e5;
																																	case 50:
																																	case 74:
																																		goto IL_03f3;
																																	case 95:
																																		goto IL_040f;
																																	case 45:
																																	case 52:
																																		goto IL_041d;
																																	case 34:
																																	case 69:
																																		goto IL_0428;
																																	case 49:
																																		goto IL_0433;
																																	case 75:
																																	case 92:
																																		goto IL_0441;
																																	case 93:
																																		goto IL_0462;
																																	case 66:
																																		goto IL_0470;
																																	case 88:
																																		goto IL_0483;
																																	case 40:
																																	case 58:
																																		goto IL_048e;
																																	case 27:
																																		goto IL_04b7;
																																	case 5:
																																		goto IL_04c5;
																																	case 0:
																																		goto IL_04d8;
																																	case 89:
																																		goto IL_04e6;
																																	case 18:
																																	case 35:
																																		goto IL_04f4;
																																	case 12:
																																		goto IL_050d;
																																	case 62:
																																		goto IL_051b;
																																	case 37:
																																		goto IL_0529;
																																	case 11:
																																	case 78:
																																		goto IL_0542;
																																	case 13:
																																		goto IL_0550;
																																	case 2:
																																		goto IL_0573;
																																	case 55:
																																		goto IL_057d;
																																	case 64:
																																		goto IL_058b;
																																	case 1:
																																	case 9:
																																	case 14:
																																	case 15:
																																	case 19:
																																	case 21:
																																	case 29:
																																	case 30:
																																	case 32:
																																	case 56:
																																	case 65:
																																	case 72:
																																	case 80:
																																	case 82:
																																	case 91:
																																	case 98:
																																	case 99:
																																		goto end_IL_01bb;
																																	case 6:
																																	case 10:
																																	case 24:
																																	case 25:
																																	case 26:
																																	case 33:
																																	case 43:
																																	case 48:
																																	case 57:
																																	case 70:
																																	case 83:
																																	case 86:
																																	case 90:
																																		goto end_IL_02a6;
																																	case 47:
																																		goto end_IL_05ae;
																																	case 41:
																																		goto end_IL_05c1;
																																	case 94:
																																		goto end_IL_05cb;
																																	case 8:
																																		goto end_IL_05d6;
																																	case 16:
																																	case 59:
																																		goto end_IL_05f4;
																																	case 36:
																																		goto end_IL_0604;
																																	case 4:
																																	case 28:
																																		goto end_IL_0614;
																																	case 96:
																																		goto end_IL_0624;
																																	case 97:
																																		goto end_IL_0634;
																																	case 54:
																																	case 68:
																																		goto IL_064f;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto end_IL_02a6;
																																continue;
																																end_IL_01bb:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																												IL_021c:;
																											}
																											break;
																											IL_022c:;
																										}
																										break;
																									}
																									goto IL_02bc;
																									IL_031e:
																									num5--;
																									goto end_IL_02a6;
																									IL_02bc:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_02ca;
																									IL_02ca:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_030a;
																									IL_030a:
																									array[num5 - 2] = 0;
																									goto IL_031e;
																								}
																								break;
																							}
																							num = 76;
																							goto IL_0331;
																							IL_0331:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0393;
																							IL_0393:
																							num5 -= 2;
																							goto end_IL_02a6;
																						}
																						break;
																					}
																					goto IL_03b9;
																					IL_03f3:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02a6;
																					IL_03b9:
																					if (9 < b)
																					{
																						goto IL_03c4;
																					}
																					goto IL_03e5;
																					IL_03c4:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_03d2;
																					IL_03d2:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_03e5:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_03f3;
																				}
																				break;
																			}
																			goto IL_040f;
																			IL_058b:
																			ptr2 += 8;
																			goto end_IL_02a6;
																			IL_040f:
																			if (5 > b)
																			{
																				goto IL_041d;
																			}
																			goto IL_0542;
																			IL_041d:
																			if (2 < b)
																			{
																				goto IL_0428;
																			}
																			goto IL_0483;
																			IL_0428:
																			if (3 >= b)
																			{
																				goto IL_0433;
																			}
																			goto IL_0462;
																			IL_0433:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0441;
																			IL_0441:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 33;
																			goto end_IL_02a6;
																			IL_0462:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0470;
																			IL_0470:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02a6;
																			IL_0483:
																			if (2 <= b)
																			{
																				goto IL_048e;
																			}
																			goto IL_04d8;
																			IL_048e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b7;
																			IL_04b7:
																			ptr2 += 8;
																			goto IL_04c5;
																			IL_04c5:
																			num5--;
																			goto end_IL_02a6;
																			IL_04d8:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04e6;
																			IL_04e6:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04f4;
																			IL_04f4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_050d;
																			IL_050d:
																			array[num5] = 0;
																			goto IL_051b;
																			IL_051b:
																			num5++;
																			goto IL_0529;
																			IL_0529:
																			ptr2 += 8;
																			num = 24;
																			goto end_IL_02a6;
																			IL_0542:
																			array[num5] = 0;
																			goto IL_0550;
																			IL_0550:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0573;
																			IL_0573:
																			array2[num5] = null;
																			goto IL_057d;
																			IL_057d:
																			num5++;
																			goto IL_058b;
																		}
																		break;
																		IL_0276:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a6;
																continue;
																end_IL_0286:
																break;
															}
															continue;
															end_IL_0296:
															break;
														}
														continue;
														end_IL_02a6:
														break;
													}
													continue;
												}
												goto IL_064f;
												IL_064f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ae:
												break;
											}
											continue;
											end_IL_05c1:
											break;
										}
										continue;
										end_IL_05cb:
										break;
									}
									continue;
									end_IL_05d6:
									break;
								}
								continue;
								end_IL_05f4:
								break;
							}
							continue;
							end_IL_0604:
							break;
						}
						continue;
						end_IL_0614:
						break;
					}
					continue;
					end_IL_0624:
					break;
				}
				continue;
				end_IL_0634:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0, int int_1)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 88;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InProcessServerAddDays.ExternalProcessMgmtStartOfUserTypes);
												num = 65;
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_01cc:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01ac:
																					if (4 < b)
																					{
																						num = 95;
																						while (true)
																						{
																							if (num != 95)
																							{
																								if (num != 1076)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 29:
																									goto IL_01ac;
																								case 0:
																									goto end_IL_01ac;
																								case 71:
																									goto IL_01cc;
																								case 59:
																									goto end_IL_01cc;
																								case 11:
																								case 37:
																									goto end_IL_01dc;
																								case 80:
																									goto IL_01f7;
																								case 12:
																									goto IL_0205;
																								case 16:
																									goto IL_0213;
																								case 24:
																									goto IL_0221;
																								case 42:
																								case 56:
																									goto IL_022f;
																								case 78:
																									goto IL_026f;
																								case 22:
																									goto IL_0283;
																								case 77:
																									goto IL_029f;
																								case 31:
																									goto IL_02aa;
																								case 38:
																								case 79:
																									goto IL_02c3;
																								case 46:
																									goto end_IL_0199;
																								case 21:
																									goto IL_02fa;
																								case 84:
																									goto IL_030d;
																								case 75:
																								case 85:
																									goto IL_0320;
																								case 82:
																									goto IL_038e;
																								case 10:
																									goto IL_03a1;
																								case 14:
																								case 87:
																									goto IL_03af;
																								case 61:
																									goto IL_03ba;
																								case 3:
																								case 35:
																									goto IL_03c8;
																								case 27:
																									goto IL_03d6;
																								case 15:
																									goto IL_03f9;
																								case 48:
																									goto IL_0403;
																								case 44:
																									goto IL_0411;
																								case 74:
																									goto IL_0424;
																								case 52:
																									goto IL_042f;
																								case 7:
																								case 18:
																									goto IL_043a;
																								case 17:
																									goto IL_0456;
																								case 9:
																									goto IL_0461;
																								case 83:
																									goto IL_046c;
																								case 1:
																								case 30:
																									goto IL_0477;
																								case 2:
																								case 4:
																								case 5:
																								case 6:
																								case 23:
																								case 25:
																								case 26:
																								case 40:
																								case 41:
																								case 49:
																								case 50:
																								case 54:
																								case 58:
																								case 64:
																								case 73:
																								case 76:
																								case 81:
																								case 86:
																									goto end_IL_01bc;
																								case 57:
																									goto IL_04af;
																								case 63:
																									goto IL_04bd;
																								case 67:
																									goto IL_04cb;
																								case 13:
																								case 19:
																								case 34:
																								case 36:
																								case 47:
																								case 53:
																								case 60:
																								case 62:
																								case 68:
																								case 69:
																								case 72:
																									goto end_IL_01ec;
																								case 65:
																									goto end_IL_04d9;
																								case 55:
																									goto end_IL_04ec;
																								case 70:
																									goto end_IL_04f6;
																								case 43:
																									goto end_IL_050a;
																								case 45:
																									goto end_IL_051f;
																								case 20:
																								case 28:
																									goto end_IL_0534;
																								case 66:
																									goto end_IL_0544;
																								case 88:
																									goto end_IL_0554;
																								case 39:
																									goto end_IL_0564;
																								case 32:
																									goto end_IL_0574;
																								case 33:
																									goto end_IL_057f;
																								case 8:
																								case 51:
																									goto IL_059a;
																								}
																								continue;
																							}
																							goto IL_03a1;
																							IL_046c:
																							if (5 > b)
																							{
																								goto end_IL_01bc;
																							}
																							goto IL_0477;
																							IL_0477:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_01ec;
																							IL_03a1:
																							if (6 < b)
																							{
																								goto IL_03af;
																							}
																							goto IL_0456;
																							IL_03af:
																							if (7 >= b)
																							{
																								goto IL_03ba;
																							}
																							goto IL_0424;
																							IL_03ba:
																							if (7 > b)
																							{
																								goto end_IL_01bc;
																							}
																							goto IL_03c8;
																							IL_03c8:
																							array[num5] = 0;
																							goto IL_03d6;
																							IL_03d6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_03f9;
																							IL_03f9:
																							array2[num5] = null;
																							goto IL_0403;
																							IL_0403:
																							num5++;
																							goto IL_0411;
																							IL_0411:
																							ptr2 += 8;
																							goto end_IL_01ec;
																							IL_0424:
																							if (8 < b)
																							{
																								goto end_IL_01bc;
																							}
																							goto IL_042f;
																							IL_042f:
																							if (8 > b)
																							{
																								goto end_IL_01bc;
																							}
																							goto IL_043a;
																							IL_043a:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_01ec;
																							IL_0456:
																							if (6 <= b)
																							{
																								goto end_IL_01ec;
																							}
																							goto IL_0461;
																							IL_0461:
																							if (5 < b)
																							{
																								goto end_IL_01bc;
																							}
																							goto IL_046c;
																							continue;
																							end_IL_0199:
																							break;
																						}
																						goto IL_02ec;
																					}
																					goto IL_01f7;
																					IL_038e:
																					num5 -= 2;
																					goto end_IL_01ec;
																					IL_02c3:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_02ec;
																					IL_01f7:
																					if (4 > b)
																					{
																						goto IL_0205;
																					}
																					goto IL_02c3;
																					IL_0205:
																					if (2 < b)
																					{
																						goto IL_0213;
																					}
																					num = 77;
																					goto IL_029f;
																					IL_0213:
																					if (3 < b)
																					{
																						goto end_IL_01bc;
																					}
																					goto IL_0221;
																					IL_0221:
																					if (3 > b)
																					{
																						goto end_IL_01bc;
																					}
																					goto IL_022f;
																					IL_022f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_026f;
																					IL_026f:
																					array[num5 - 2] = 0;
																					goto IL_0283;
																					IL_0283:
																					num5--;
																					goto end_IL_01ec;
																					IL_02ec:
																					ptr2 += 8;
																					goto IL_02fa;
																					IL_029f:
																					if (2 > b)
																					{
																						goto IL_02aa;
																					}
																					goto IL_0320;
																					IL_02aa:
																					if (1 < b)
																					{
																						num = 26;
																						goto end_IL_01bc;
																					}
																					goto IL_030d;
																					IL_02fa:
																					num5--;
																					goto end_IL_01ec;
																					IL_030d:
																					if (1 > b)
																					{
																					}
																					goto end_IL_01bc;
																					IL_0320:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_038e;
																					continue;
																					end_IL_01ac:
																					break;
																				}
																				continue;
																				end_IL_01bc:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04af;
																		IL_04cb:
																		ptr2 += 8;
																		goto end_IL_01ec;
																		IL_04bd:
																		num5++;
																		goto IL_04cb;
																		IL_04af:
																		array[num5] = 0;
																		goto IL_04bd;
																		continue;
																		end_IL_01cc:
																		break;
																	}
																	continue;
																	end_IL_01dc:
																	break;
																}
																continue;
																end_IL_01ec:
																break;
															}
															continue;
														}
														goto IL_059a;
														IL_059a:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04d9:
														break;
													}
													continue;
													end_IL_04ec:
													break;
												}
												continue;
												end_IL_04f6:
												break;
											}
											continue;
											end_IL_050a:
											break;
										}
										continue;
										end_IL_051f:
										break;
									}
									continue;
									end_IL_0534:
									break;
								}
								continue;
								end_IL_0544:
								break;
							}
							continue;
							end_IL_0554:
							break;
						}
						continue;
						end_IL_0564:
						break;
					}
					continue;
					end_IL_0574:
					break;
				}
				continue;
				end_IL_057f:
				break;
			}
		}
	}

	static Class15()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 11;
					while (true)
					{
						if (num != 11)
						{
							if (num != 992)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 4:
								goto end_IL_0035;
							case 2:
								goto end_IL_0042;
							case 3:
								goto end_IL_0051;
							case 1:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0035:
						break;
					}
					continue;
					end_IL_0042:
					break;
				}
				continue;
				end_IL_0051:
				break;
			}
		}
	}
}
