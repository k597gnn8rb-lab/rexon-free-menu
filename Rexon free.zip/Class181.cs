using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Hand Trails", "Rig", "Trail effects on both hands.", false, 38, ModType.const_0, false)]
internal class Class181 : MonoBehaviour
{
	private TrailRenderer trailRenderer_0;

	private TrailRenderer trailRenderer_1;

	private static double double_0;

	private static bool bool_0;

	private static double double_1;

	private static double double_2;

	private static float float_0;

	private static IntPtr[] ExplicitIsolatedStoragePermission;

	private static IntPtr[] TimerQueueTimerGetRawCertData;

	private static IntPtr[] WmiGuidObjectConfigurationFileValue;

	private static IntPtr[] CLAIMSECURITYATTRIBUTEVCData;

	private static IntPtr[] IClrStrongNameUsingIntPtrIsNullOrWhiteSpace;

	private unsafe void OnEnable()
	{
		int num = 83;
		byte* ptr = default(byte*);
		byte b = default(byte);
		int num4 = default(int);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[3];
									while (true)
									{
										array5[0] = this;
										num = 283;
										while (true)
										{
											if (num != 283)
											{
												if (num != 1264)
												{
													goto IL_05a2;
												}
												switch (num)
												{
												case 272:
													goto end_IL_047b;
												case 245:
													goto end_IL_048e;
												case 12:
													goto end_IL_04a7;
												case 100:
												case 224:
													goto end_IL_04b7;
												case 75:
													goto end_IL_04c7;
												case 45:
												case 274:
													goto end_IL_04d7;
												case 82:
													goto end_IL_04e7;
												case 83:
													goto end_IL_04f7;
												case 186:
													goto IL_051b;
												case 1:
												case 17:
												case 34:
												case 53:
												case 86:
												case 93:
												case 102:
												case 103:
												case 105:
												case 107:
												case 109:
												case 113:
												case 116:
												case 118:
												case 142:
												case 148:
												case 153:
												case 156:
												case 157:
												case 163:
												case 175:
												case 198:
												case 201:
												case 211:
												case 219:
												case 221:
												case 233:
												case 257:
												case 258:
												case 264:
												case 268:
												case 269:
													goto IL_0523;
												case 110:
													goto IL_0533;
												case 114:
													goto IL_053c;
												case 230:
													goto IL_054e;
												case 59:
													goto IL_055c;
												case 240:
													goto IL_056a;
												case 209:
													goto IL_0578;
												case 183:
												case 184:
													goto IL_0586;
												case 165:
												case 266:
													goto IL_0594;
												case 226:
													goto IL_05a2;
												case 31:
												case 50:
													goto IL_05ad;
												case 193:
													goto IL_05e5;
												case 246:
													goto IL_05f9;
												case 177:
													goto IL_060c;
												case 72:
													goto IL_061a;
												case 94:
												case 96:
													goto IL_0628;
												case 265:
													goto IL_0636;
												case 35:
												case 262:
													goto IL_0644;
												case 250:
													goto IL_0658;
												case 275:
													goto IL_06a5;
												case 205:
													goto IL_06b3;
												case 37:
												case 126:
													goto IL_06c6;
												case 0:
													goto IL_06da;
												case 234:
													goto IL_0726;
												case 253:
													goto IL_0734;
												case 215:
													goto IL_0747;
												case 55:
													goto IL_0755;
												case 187:
												case 243:
													goto IL_0763;
												case 25:
													goto IL_0790;
												case 136:
													goto IL_07a3;
												case 77:
													goto IL_07b1;
												case 101:
												case 144:
													goto IL_07bc;
												case 137:
													goto IL_07d8;
												case 81:
													goto IL_07e6;
												case 14:
												case 71:
													goto IL_07f4;
												case 60:
													goto IL_082a;
												case 80:
												case 267:
													goto IL_083d;
												case 188:
													goto IL_084b;
												case 225:
													goto IL_085e;
												case 119:
												case 194:
													goto IL_0869;
												case 121:
													goto IL_08a1;
												case 242:
													goto IL_08b5;
												case 27:
												case 190:
													goto IL_08c8;
												case 24:
												case 168:
													goto IL_08d6;
												case 15:
													goto IL_08e4;
												case 172:
													goto IL_08f2;
												case 47:
													goto IL_0900;
												case 52:
												case 260:
													goto IL_090e;
												case 120:
													goto IL_0922;
												case 10:
													goto IL_096f;
												case 131:
													goto IL_097d;
												case 5:
												case 87:
													goto IL_0990;
												case 66:
													goto IL_09eb;
												case 229:
													goto IL_0a07;
												case 104:
													goto IL_0a15;
												case 189:
												case 213:
													goto IL_0a23;
												case 146:
													goto IL_0a3b;
												case 254:
													goto IL_0a49;
												case 206:
													goto IL_0a57;
												case 65:
													goto IL_0a6a;
												case 41:
												case 249:
													goto IL_0a81;
												case 48:
												case 56:
													goto IL_0a8c;
												case 73:
													goto IL_0a9a;
												case 74:
												case 154:
													goto IL_0aa8;
												case 132:
													goto IL_0abf;
												case 159:
													goto IL_0ad7;
												case 220:
													goto IL_0ae5;
												case 248:
													goto IL_0af8;
												case 117:
												case 180:
													goto IL_0b0f;
												case 3:
													goto IL_0b47;
												case 170:
													goto IL_0b64;
												case 214:
												case 273:
													goto IL_0b77;
												case 88:
													goto IL_0b81;
												case 150:
													goto IL_0b8f;
												case 39:
													goto IL_0bab;
												case 26:
												case 176:
													goto IL_0bb6;
												case 42:
													goto IL_0bd4;
												case 2:
													goto IL_0be2;
												case 46:
												case 164:
													goto IL_0bfe;
												case 67:
												case 95:
													goto IL_0c0c;
												case 167:
													goto IL_0c1a;
												case 7:
												case 33:
													goto IL_0c28;
												case 195:
													goto IL_0c36;
												case 63:
												case 92:
													goto IL_0c41;
												case 58:
													goto IL_0c81;
												case 90:
													goto IL_0c9e;
												case 91:
													goto IL_0cba;
												case 203:
													goto IL_0cc8;
												case 173:
												case 179:
													goto IL_0cd6;
												case 270:
													goto IL_0ce9;
												case 259:
													goto IL_0cf7;
												case 111:
												case 127:
													goto IL_0d05;
												case 135:
													goto IL_0d67;
												case 89:
												case 218:
													goto IL_0d7a;
												case 54:
													goto IL_0d8e;
												case 151:
													goto IL_0de2;
												case 130:
													goto IL_0df0;
												case 252:
													goto IL_0e03;
												case 43:
												case 69:
													goto IL_0e11;
												case 145:
													goto IL_0e1f;
												case 28:
												case 78:
													goto IL_0e2d;
												case 64:
													goto IL_0e65;
												case 30:
													goto IL_0e79;
												case 212:
													goto IL_0e95;
												case 204:
												case 210:
													goto IL_0ea0;
												case 129:
													goto IL_0eae;
												case 84:
												case 85:
													goto IL_0ec1;
												case 182:
													goto IL_0ecf;
												case 199:
													goto IL_0eed;
												case 108:
													goto IL_0efb;
												case 207:
													goto IL_0f0e;
												case 115:
												case 244:
													goto IL_0f19;
												case 161:
													goto IL_0f59;
												case 263:
													goto IL_0f6d;
												case 238:
													goto IL_0f80;
												case 174:
													goto IL_0f8e;
												case 21:
												case 40:
													goto IL_0f9c;
												case 169:
													goto IL_0fa7;
												case 18:
												case 36:
													goto IL_0fb5;
												case 166:
													goto IL_0fce;
												case 11:
													goto IL_0fdc;
												case 255:
													goto IL_0fea;
												case 160:
													goto IL_0ffd;
												case 9:
													goto IL_100b;
												case 8:
												case 191:
													goto IL_1019;
												case 237:
													goto IL_1062;
												case 20:
													goto IL_1076;
												case 133:
												case 239:
													goto IL_1089;
												case 276:
													goto IL_10b2;
												case 202:
													goto IL_10c0;
												case 134:
													goto IL_10d3;
												case 181:
													goto IL_10e1;
												case 122:
												case 261:
													goto IL_10ec;
												case 112:
													goto IL_112c;
												case 236:
													goto IL_1140;
												case 171:
													goto IL_1153;
												case 235:
													goto IL_1161;
												case 152:
												case 251:
													goto IL_116f;
												case 247:
													goto IL_117d;
												case 32:
													goto IL_11a0;
												case 140:
													goto IL_11aa;
												case 216:
													goto IL_11b8;
												case 139:
													goto IL_11cb;
												case 70:
													goto IL_11d6;
												case 51:
												case 228:
													goto IL_11e1;
												case 123:
													goto IL_1221;
												case 141:
													goto IL_123e;
												case 4:
												case 6:
												case 13:
												case 16:
												case 19:
												case 22:
												case 23:
												case 29:
												case 38:
												case 44:
												case 49:
												case 57:
												case 61:
												case 62:
												case 68:
												case 76:
												case 79:
												case 97:
												case 98:
												case 99:
												case 106:
												case 124:
												case 125:
												case 128:
												case 138:
												case 143:
												case 147:
												case 149:
												case 155:
												case 158:
												case 162:
												case 178:
												case 192:
												case 196:
												case 197:
												case 200:
												case 217:
												case 222:
												case 223:
												case 227:
												case 231:
												case 232:
												case 241:
												case 256:
												case 271:
													goto IL_1251;
												case 185:
												case 208:
													return;
												}
												continue;
											}
											ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadDecimalpUint.CurrentIntoBufferParseNumbers);
											goto IL_051b;
											IL_11cb:
											if (6 >= b)
											{
												goto IL_11d6;
											}
											goto IL_1251;
											IL_11e1:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_1221;
											IL_11d6:
											if (6 <= b)
											{
												goto IL_11e1;
											}
											goto IL_1251;
											IL_051b:
											ptr2 = ptr;
											goto IL_0523;
											IL_0523:
											if (num5 == 1)
											{
												return;
											}
											goto IL_0533;
											IL_0533:
											num = 114;
											goto IL_053c;
											IL_053c:
											b = *ptr2;
											num = 230;
											goto IL_054e;
											IL_054e:
											ptr2++;
											goto IL_055c;
											IL_055c:
											if (b >= 1)
											{
												goto IL_056a;
											}
											goto IL_1251;
											IL_056a:
											if (b <= 29)
											{
												goto IL_0578;
											}
											goto IL_1251;
											IL_0578:
											if (15 < b)
											{
												goto IL_0586;
											}
											goto IL_0bab;
											IL_0586:
											if (22 < b)
											{
												goto IL_0594;
											}
											goto IL_085e;
											IL_0594:
											if (26 >= b)
											{
												goto IL_05a2;
											}
											goto IL_07a3;
											IL_05a2:
											if (26 <= b)
											{
												goto IL_05ad;
											}
											goto IL_060c;
											IL_05ad:
											array2[num4 - 1] = ((delegate*<Class181, TrailRenderer>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])((Class181)array2[num4 - 1]);
											goto IL_05e5;
											IL_05e5:
											array[num4 - 1] = 5;
											goto IL_05f9;
											IL_05f9:
											ptr2 += 8;
											goto IL_0523;
											IL_060c:
											if (24 >= b)
											{
												goto IL_061a;
											}
											goto IL_0747;
											IL_061a:
											if (24 > b)
											{
												goto IL_0628;
											}
											goto IL_06c6;
											IL_0628:
											if (23 >= b)
											{
												goto IL_0636;
											}
											goto IL_1251;
											IL_0636:
											if (23 <= b)
											{
												goto IL_0644;
											}
											goto IL_1251;
											IL_0644:
											array[num4 - 2] = 0;
											goto IL_0658;
											IL_0658:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])((TrailRenderer)array2[num4 - 2], (UnityEngine.Object)array2[num4 - 1]) ? 1 : 0);
											goto IL_06a5;
											IL_06a5:
											num4--;
											goto IL_06b3;
											IL_06b3:
											ptr2 += 8;
											goto IL_0523;
											IL_06c6:
											array[num4 - 2] = 5;
											goto IL_06da;
											IL_06da:
											array2[num4 - 2] = ((delegate*<Class181, Transform, TrailRenderer>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])((Class181)array2[num4 - 2], (Transform)array2[num4 - 1]);
											goto IL_0726;
											IL_0726:
											num4--;
											goto IL_0734;
											IL_0734:
											ptr2 += 8;
											goto IL_0523;
											IL_0747:
											if (25 >= b)
											{
												goto IL_0755;
											}
											goto IL_1251;
											IL_0755:
											if (25 <= b)
											{
												goto IL_0763;
											}
											goto IL_1251;
											IL_0763:
											((Class181)array2[num4 - 2]).trailRenderer_0 = (TrailRenderer)array2[num4 - 1];
											goto IL_0790;
											IL_0790:
											num4 -= 2;
											goto IL_0523;
											IL_07a3:
											if (28 >= b)
											{
												goto IL_07b1;
											}
											goto IL_083d;
											IL_07b1:
											if (28 <= b)
											{
												goto IL_07bc;
											}
											goto IL_07d8;
											IL_07bc:
											byte* num6 = ptr2;
											num5 = 1;
											ptr2 = num6 + -200;
											goto IL_0523;
											IL_07d8:
											if (27 >= b)
											{
												goto IL_07e6;
											}
											goto IL_1251;
											IL_07e6:
											if (27 <= b)
											{
												goto IL_07f4;
											}
											goto IL_1251;
											IL_07f4:
											((Class181)array2[num4 - 2]).trailRenderer_1 = (TrailRenderer)array2[num4 - 1];
											num = 60;
											goto IL_082a;
											IL_082a:
											num4 -= 2;
											goto IL_0523;
											IL_083d:
											if (29 >= b)
											{
												goto IL_084b;
											}
											goto IL_1251;
											IL_084b:
											if (29 > b)
											{
											}
											goto IL_1251;
											IL_085e:
											if (22 <= b)
											{
												goto IL_0869;
											}
											goto IL_08c8;
											IL_0869:
											array2[num4 - 1] = ((delegate*<Class181, TrailRenderer>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])((Class181)array2[num4 - 1]);
											goto IL_08a1;
											IL_08a1:
											array[num4 - 1] = 5;
											goto IL_08b5;
											IL_08b5:
											ptr2 += 8;
											goto IL_0523;
											IL_08c8:
											if (18 < b)
											{
												goto IL_08d6;
											}
											goto IL_0a6a;
											IL_08d6:
											if (20 >= b)
											{
												goto IL_08e4;
											}
											goto IL_0a07;
											IL_08e4:
											if (20 > b)
											{
												goto IL_08f2;
											}
											goto IL_0990;
											IL_08f2:
											if (19 >= b)
											{
												goto IL_0900;
											}
											goto IL_1251;
											IL_0900:
											if (19 <= b)
											{
												goto IL_090e;
											}
											goto IL_1251;
											IL_090e:
											array[num4 - 2] = 0;
											goto IL_0922;
											IL_0922:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])((Transform)array2[num4 - 2], (UnityEngine.Object)array2[num4 - 1]) ? 1 : 0);
											goto IL_096f;
											IL_096f:
											num4--;
											goto IL_097d;
											IL_097d:
											ptr2 += 8;
											goto IL_0523;
											IL_0990:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											num = 66;
											goto IL_09eb;
											IL_09eb:
											num4--;
											num = 269;
											goto IL_0523;
											IL_0a07:
											if (21 >= b)
											{
												goto IL_0a15;
											}
											goto IL_1251;
											IL_0a15:
											if (21 <= b)
											{
												goto IL_0a23;
											}
											goto IL_1251;
											IL_0a23:
											array2[num4] = array5[*(int*)(ptr2 + num3)];
											goto IL_0a3b;
											IL_0a3b:
											array[num4] = 5;
											goto IL_0a49;
											IL_0a49:
											num4++;
											goto IL_0a57;
											IL_0a57:
											ptr2 += 8;
											goto IL_0523;
											IL_0a6a:
											if (18 > b)
											{
												num = 249;
												goto IL_0a81;
											}
											goto IL_0b77;
											IL_1221:
											array[num4 - 2] = 0;
											num = 141;
											goto IL_123e;
											IL_0a81:
											if (16 < b)
											{
												goto IL_0a8c;
											}
											goto IL_0af8;
											IL_0a8c:
											if (17 >= b)
											{
												goto IL_0a9a;
											}
											goto IL_1251;
											IL_0a9a:
											if (17 <= b)
											{
												goto IL_0aa8;
											}
											goto IL_1251;
											IL_0aa8:
											array[num4] = 5;
											num = 132;
											goto IL_0abf;
											IL_0abf:
											array2[num4] = array5[*(int*)(ptr2 + num3)];
											goto IL_0ad7;
											IL_0ad7:
											num4++;
											goto IL_0ae5;
											IL_0ae5:
											ptr2 += 8;
											goto IL_0523;
											IL_0af8:
											if (16 <= b)
											{
												num = 180;
												goto IL_0b0f;
											}
											goto IL_1251;
											IL_123e:
											num4--;
											goto IL_0523;
											IL_0b0f:
											array2[num4 - 1] = ((delegate*<GorillaTagger, Transform>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num4 - 1]);
											goto IL_0b47;
											IL_0b47:
											array[num4 - 1] = 5;
											num = 170;
											goto IL_0b64;
											IL_0b64:
											ptr2 += 8;
											goto IL_0523;
											IL_0b77:
											array2[num4] = null;
											goto IL_0b81;
											IL_0b81:
											array[num4] = 5;
											goto IL_0b8f;
											IL_0b8f:
											num4++;
											num = 264;
											goto IL_0523;
											IL_0bab:
											if (15 <= b)
											{
												goto IL_0bb6;
											}
											num = 46;
											goto IL_0bfe;
											IL_0bb6:
											array5[*(int*)(ptr2 + num3)] = array2[num4 - 1];
											goto IL_0bd4;
											IL_0bd4:
											ptr2 += 8;
											goto IL_0be2;
											IL_0be2:
											num4--;
											goto IL_0523;
											IL_1251:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0523;
											IL_0bfe:
											if (7 < b)
											{
												goto IL_0c0c;
											}
											goto IL_0f0e;
											IL_0c0c:
											if (11 >= b)
											{
												goto IL_0c1a;
											}
											goto IL_0e03;
											IL_0c1a:
											if (11 > b)
											{
												goto IL_0c28;
											}
											goto IL_0d7a;
											IL_0c28:
											if (9 >= b)
											{
												goto IL_0c36;
											}
											goto IL_0ce9;
											IL_0c36:
											if (9 <= b)
											{
												goto IL_0c41;
											}
											goto IL_0cba;
											IL_0c41:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_0c81;
											IL_0c81:
											array[num4 - 2] = 0;
											num = 90;
											goto IL_0c9e;
											IL_0c9e:
											num4--;
											num = 153;
											goto IL_0523;
											IL_0cba:
											if (8 >= b)
											{
												goto IL_0cc8;
											}
											goto IL_1251;
											IL_0cc8:
											if (8 <= b)
											{
												goto IL_0cd6;
											}
											goto IL_1251;
											IL_0cd6:
											num4--;
											goto IL_0523;
											IL_0ce9:
											if (10 >= b)
											{
												goto IL_0cf7;
											}
											goto IL_1251;
											IL_0cf7:
											if (10 <= b)
											{
												goto IL_0d05;
											}
											goto IL_1251;
											IL_0d05:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_0d67;
											IL_0d67:
											num4 -= 2;
											goto IL_0523;
											IL_0d7a:
											array[num4 - 2] = 0;
											goto IL_0d8e;
											IL_0d8e:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((delegate*<int, int, int>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
											goto IL_0de2;
											IL_0de2:
											num4--;
											goto IL_0df0;
											IL_0df0:
											ptr2 += 8;
											goto IL_0523;
											IL_0e03:
											if (13 < b)
											{
												goto IL_0e11;
											}
											goto IL_0e95;
											IL_0e11:
											if (14 >= b)
											{
												goto IL_0e1f;
											}
											goto IL_1251;
											IL_0e1f:
											if (14 <= b)
											{
												goto IL_0e2d;
											}
											goto IL_1251;
											IL_0e2d:
											array2[num4 - 1] = ((delegate*<GorillaTagger, Transform>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num4 - 1]);
											goto IL_0e65;
											IL_0e65:
											array[num4 - 1] = 5;
											goto IL_0e79;
											IL_0e79:
											ptr2 += 8;
											num = 163;
											goto IL_0523;
											IL_0e95:
											if (13 > b)
											{
												goto IL_0ea0;
											}
											goto IL_0ec1;
											IL_0ea0:
											if (12 >= b)
											{
												goto IL_0eae;
											}
											goto IL_1251;
											IL_0eae:
											if (12 <= b)
											{
												goto IL_0523;
											}
											goto IL_1251;
											IL_0ec1:
											array[num4] = 5;
											goto IL_0ecf;
											IL_0ecf:
											array2[num4] = ((delegate*<GorillaTagger>)ExplicitIsolatedStoragePermission[*(int*)(ptr2 + num3)])();
											goto IL_0eed;
											IL_0eed:
											num4++;
											goto IL_0efb;
											IL_0efb:
											ptr2 += 8;
											goto IL_0523;
											IL_0f0e:
											if (7 <= b)
											{
												goto IL_0f19;
											}
											goto IL_0f80;
											IL_0f19:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_0f59;
											IL_0f59:
											array[num4 - 2] = 0;
											goto IL_0f6d;
											IL_0f6d:
											num4--;
											goto IL_0523;
											IL_0f80:
											if (3 >= b)
											{
												goto IL_0f8e;
											}
											goto IL_10d3;
											IL_0f8e:
											if (3 > b)
											{
												goto IL_0f9c;
											}
											goto IL_1089;
											IL_0f9c:
											if (1 >= b)
											{
												goto IL_0fa7;
											}
											goto IL_0ffd;
											IL_0fa7:
											if (1 <= b)
											{
												goto IL_0fb5;
											}
											goto IL_1251;
											IL_0fb5:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
											goto IL_0fce;
											IL_0fce:
											array[num4] = 0;
											goto IL_0fdc;
											IL_0fdc:
											num4++;
											goto IL_0fea;
											IL_0fea:
											ptr2 += 8;
											goto IL_0523;
											IL_0ffd:
											if (2 >= b)
											{
												goto IL_100b;
											}
											goto IL_1251;
											IL_100b:
											if (2 <= b)
											{
												goto IL_1019;
											}
											goto IL_1251;
											IL_1019:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											num = 237;
											goto IL_1062;
											IL_1062:
											array[num4 - 2] = 0;
											goto IL_1076;
											IL_1076:
											num4--;
											goto IL_0523;
											IL_1089:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_10b2;
											IL_10b2:
											ptr2 += 8;
											goto IL_10c0;
											IL_10c0:
											num4--;
											goto IL_0523;
											IL_10d3:
											if (5 >= b)
											{
												goto IL_10e1;
											}
											goto IL_11cb;
											IL_10e1:
											if (5 <= b)
											{
												goto IL_10ec;
											}
											goto IL_1153;
											IL_10ec:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_112c;
											IL_112c:
											array[num4 - 2] = 0;
											goto IL_1140;
											IL_1140:
											num4--;
											goto IL_0523;
											IL_1153:
											if (4 >= b)
											{
												goto IL_1161;
											}
											goto IL_1251;
											IL_1161:
											if (4 <= b)
											{
												goto IL_116f;
											}
											goto IL_1251;
											IL_116f:
											array[num4] = 0;
											goto IL_117d;
											IL_117d:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
											goto IL_11a0;
											IL_11a0:
											array2[num4] = null;
											goto IL_11aa;
											IL_11aa:
											num4++;
											goto IL_11b8;
											IL_11b8:
											ptr2 += 8;
											goto IL_0523;
											continue;
											end_IL_047b:
											break;
										}
										continue;
										end_IL_048e:
										break;
									}
									continue;
									end_IL_04a7:
									break;
								}
								continue;
								end_IL_04b7:
								break;
							}
							continue;
							end_IL_04c7:
							break;
						}
						continue;
						end_IL_04d7:
						break;
					}
					continue;
					end_IL_04e7:
					break;
				}
				continue;
				end_IL_04f7:
				break;
			}
		}
	}

	private unsafe TrailRenderer method_0(Transform transform_0)
	{
		//The blocks IL_000e, IL_001e, IL_05d7, IL_05ea, IL_0603, IL_061e, IL_062e, IL_063e, IL_064b, IL_065b, IL_066b, IL_067b, IL_068b, IL_069b, IL_06ab, IL_06b6, IL_06c4, IL_06d1, IL_06dc, IL_06ef, IL_06fd, IL_0708, IL_0716, IL_0726, IL_0734, IL_0742, IL_0755, IL_0763, IL_078c, IL_07a5, IL_07b9, IL_07f1, IL_0804, IL_081b, IL_0833, IL_0841, IL_0854, IL_0862, IL_086b, IL_087e, IL_08c1, IL_08cf, IL_08da, IL_08e8, IL_0928, IL_0941, IL_094f, IL_095d, IL_0968, IL_0976, IL_09b6, IL_09cf, IL_09dd, IL_09eb, IL_0a30, IL_0a3b, IL_0a49, IL_0a89, IL_0a9d, IL_0ab0, IL_0abe, IL_0acc, IL_0b2e, IL_0b41, IL_0b54, IL_0b72, IL_0b85, IL_0b98, IL_0bac, IL_0bbf, IL_0bdc, IL_0c2b, IL_0c35, IL_0c62, IL_0c76, IL_0c84, IL_0c97, IL_0ca5, IL_0cb0, IL_0cf0, IL_0d04, IL_0d17, IL_0d25, IL_0d33, IL_0d4c, IL_0d5a, IL_0d68, IL_0d7b, IL_0d86, IL_0d94, IL_0da2, IL_0db0, IL_0dd3, IL_0ddd, IL_0deb, IL_0dfe, IL_0e0c, IL_0e1f, IL_0e32, IL_0e4a, IL_0e68, IL_0e8c, IL_0ea4, IL_0eb7, IL_0eca, IL_0ed8, IL_0f01, IL_0f0f, IL_0f22, IL_0f30, IL_0f43, IL_0f4e, IL_0f5c, IL_0f7d, IL_0f8b, IL_0f99, IL_0fda, IL_0fee, IL_1001, IL_105c, IL_106f, IL_107d, IL_1088, IL_10c6, IL_10d4, IL_10e7, IL_10f5, IL_1100, IL_110e, IL_1131, IL_113f, IL_1152, IL_1160, IL_116b, IL_117f, IL_11b7, IL_11ca, IL_11d8, IL_11e6, IL_11fa, IL_1232, IL_1245, IL_1250, IL_125e, IL_1276, IL_1284, IL_1292, IL_12a5, IL_12b3, IL_12c1, IL_1313, IL_1321, IL_1334, IL_1342, IL_134d, IL_1367, IL_1375, IL_1383, IL_1396, IL_13a1, IL_13af, IL_13ec, IL_13fa, IL_140d, IL_141b, IL_1429, IL_1446, IL_147e, IL_1491, IL_149c, IL_14aa, IL_14e8, IL_14f6, IL_1509, IL_1517, IL_1520, IL_152e, IL_1537, IL_1575, IL_1583, IL_1596, IL_15a4, IL_15b2, IL_15c0, IL_15cb, IL_15df, IL_1617, IL_162a, IL_1638, IL_1646, IL_1654, IL_1677, IL_1685, IL_1698, IL_16a6, IL_16b4, IL_16c2, IL_16cb, IL_16e2, IL_1705, IL_1713, IL_1726, IL_172f, IL_173d, IL_1783, IL_1791, IL_17ad, IL_17ea, IL_1801, IL_1814, IL_1822, IL_182d, IL_186b, IL_1879, IL_188c, IL_189a, IL_18a8, IL_18bc, IL_1934, IL_1942, IL_1955, IL_1963, IL_1971, IL_19ae, IL_19bc, IL_19cc, IL_19d7, IL_19e2, IL_19fb, IL_1a06, IL_1a0f, IL_1a1a, IL_1a2d, IL_1a40, IL_1a4a, IL_1a55, IL_1a65, IL_1a75, IL_1a85, IL_1a95, IL_1aa5, IL_1ab5, IL_1ac5, IL_1ad5, IL_1ae5, IL_1b00 are reachable both inside and outside the pinned region starting at IL_1afa. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 13;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef84 = default(int);
			ref int reference = ref __rxRef84;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1ae5:
					num2 = 1;
					while (true)
					{
						IL_1ad5:
						num3 = num2 * 4;
						while (true)
						{
							IL_1ac5:
							num4 = num2 * 8;
							while (true)
							{
								IL_1ab5:
								array2 = new byte[6];
								while (true)
								{
									IL_1aa5:
									array3 = new object[6];
									while (true)
									{
										IL_1a95:
										array4 = new int[6];
										while (true)
										{
											IL_1a85:
											array5 = new int[7];
											while (true)
											{
												IL_1a75:
												array6 = new long[6];
												while (true)
												{
													IL_1a65:
													array7 = new object[10];
													while (true)
													{
														IL_1a55:
														array7[0] = transform_0;
														while (true)
														{
															IL_1a4a:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EventRegistrationTokenGetSubKeyNames.getAccessControlTypesetCurrencyPositivePattern);
															while (true)
															{
																IL_1a40:
																ptr2 = ptr;
																while (true)
																{
																	IL_1a2d:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_06ab:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_069b:
																				ptr2++;
																				while (true)
																				{
																					IL_068b:
																					if (b >= 1)
																					{
																						while (b <= 43)
																						{
																							while (true)
																							{
																								IL_066b:
																								if (22 >= b)
																								{
																									while (true)
																									{
																										IL_065b:
																										if (22 > b)
																										{
																											while (true)
																											{
																												IL_064b:
																												if (11 < b)
																												{
																													while (true)
																													{
																														IL_063e:
																														if (16 < b)
																														{
																															while (true)
																															{
																																IL_062e:
																																if (19 >= b)
																																{
																																	while (true)
																																	{
																																		IL_061e:
																																		if (19 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_0603:
																																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																																				while (true)
																																				{
																																					IL_05ea:
																																					array2[num6] = 1;
																																					num = 370;
																																					while (true)
																																					{
																																						if (num != 370)
																																						{
																																							if (num != 1351)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 13:
																																								break;
																																							default:
																																								continue;
																																							case 56:
																																								goto IL_05ea;
																																							case 91:
																																							case 145:
																																								goto IL_0603;
																																							case 184:
																																								goto IL_061e;
																																							case 93:
																																								goto IL_062e;
																																							case 237:
																																								goto IL_063e;
																																							case 31:
																																								goto IL_064b;
																																							case 148:
																																								goto IL_065b;
																																							case 295:
																																								goto IL_066b;
																																							case 354:
																																								goto IL_067b;
																																							case 97:
																																								goto IL_068b;
																																							case 363:
																																								goto IL_069b;
																																							case 47:
																																							case 88:
																																								goto IL_06ab;
																																							case 150:
																																								goto IL_06b6;
																																							case 85:
																																								goto IL_06c4;
																																							case 164:
																																								goto IL_06d1;
																																							case 137:
																																								goto IL_06dc;
																																							case 189:
																																								goto IL_06ef;
																																							case 221:
																																								goto IL_0708;
																																							case 25:
																																								goto IL_0716;
																																							case 225:
																																								goto IL_0726;
																																							case 238:
																																								goto IL_0734;
																																							case 159:
																																								goto IL_0742;
																																							case 246:
																																								goto IL_0755;
																																							case 79:
																																							case 206:
																																								goto IL_0763;
																																							case 235:
																																								goto IL_078c;
																																							case 245:
																																							case 249:
																																								goto IL_07a5;
																																							case 72:
																																								goto IL_07b9;
																																							case 20:
																																								goto IL_07f1;
																																							case 61:
																																							case 260:
																																								goto IL_0804;
																																							case 169:
																																								goto IL_081b;
																																							case 39:
																																								goto IL_0833;
																																							case 15:
																																								goto IL_0841;
																																							case 263:
																																								goto IL_0854;
																																							case 29:
																																								goto IL_086b;
																																							case 18:
																																							case 309:
																																								goto IL_087e;
																																							case 316:
																																								goto IL_08c1;
																																							case 250:
																																								goto IL_08cf;
																																							case 38:
																																								goto IL_08da;
																																							case 173:
																																							case 207:
																																								goto IL_08e8;
																																							case 121:
																																								goto IL_0928;
																																							case 261:
																																								goto IL_0941;
																																							case 211:
																																								goto IL_094f;
																																							case 109:
																																								goto IL_095d;
																																							case 53:
																																								goto IL_0968;
																																							case 7:
																																							case 106:
																																								goto IL_0976;
																																							case 84:
																																								goto IL_09b6;
																																							case 310:
																																								goto IL_09cf;
																																							case 100:
																																								goto IL_09dd;
																																							case 168:
																																							case 265:
																																								goto IL_09eb;
																																							case 151:
																																								goto IL_0a30;
																																							case 122:
																																								goto IL_0a3b;
																																							case 40:
																																							case 264:
																																								goto IL_0a49;
																																							case 201:
																																								goto IL_0a89;
																																							case 154:
																																								goto IL_0a9d;
																																							case 2:
																																								goto IL_0ab0;
																																							case 41:
																																								goto IL_0abe;
																																							case 3:
																																							case 276:
																																								goto IL_0acc;
																																							case 281:
																																								goto IL_0b2e;
																																							case 320:
																																								goto IL_0b41;
																																							case 209:
																																							case 323:
																																								goto IL_0b54;
																																							case 241:
																																								goto IL_0b72;
																																							case 330:
																																								goto IL_0b85;
																																							case 339:
																																								goto IL_0b98;
																																							case 180:
																																								goto IL_0bac;
																																							case 45:
																																							case 341:
																																								goto IL_0bbf;
																																							case 307:
																																								goto IL_0c76;
																																							case 32:
																																								goto IL_0c84;
																																							case 346:
																																								goto IL_0c97;
																																							case 277:
																																								goto IL_0ca5;
																																							case 113:
																																							case 147:
																																								goto IL_0cb0;
																																							case 228:
																																								goto IL_0cf0;
																																							case 133:
																																								goto IL_0d04;
																																							case 306:
																																								goto IL_0d17;
																																							case 178:
																																								goto IL_0d25;
																																							case 298:
																																							case 335:
																																								goto IL_0d33;
																																							case 251:
																																								goto IL_0d4c;
																																							case 214:
																																								goto IL_0d5a;
																																							case 112:
																																								goto IL_0d68;
																																							case 321:
																																								goto IL_0d7b;
																																							case 179:
																																								goto IL_0d86;
																																							case 334:
																																								goto IL_0d94;
																																							case 46:
																																							case 66:
																																								goto IL_0da2;
																																							case 131:
																																								goto IL_0db0;
																																							case 1:
																																								goto IL_0dd3;
																																							case 233:
																																								goto IL_0ddd;
																																							case 6:
																																								goto IL_0deb;
																																							case 352:
																																								goto IL_0e0c;
																																							case 353:
																																								goto IL_0e1f;
																																							case 297:
																																							case 355:
																																								goto IL_0e32;
																																							case 318:
																																								goto IL_0e4a;
																																							case 144:
																																								goto IL_0e68;
																																							case 283:
																																								goto IL_0e8c;
																																							case 102:
																																								goto IL_0ea4;
																																							case 202:
																																							case 357:
																																								goto IL_0eb7;
																																							case 362:
																																								goto end_IL_05d7;
																																							case 75:
																																							case 213:
																																								goto IL_0ed8;
																																							case 68:
																																								goto IL_0f01;
																																							case 222:
																																								goto IL_0f0f;
																																							case 348:
																																								goto IL_0f30;
																																							case 220:
																																								goto IL_0f43;
																																							case 77:
																																								goto IL_0f4e;
																																							case 42:
																																							case 243:
																																								goto IL_0f5c;
																																							case 110:
																																								goto IL_0f7d;
																																							case 229:
																																								goto IL_0f8b;
																																							case 130:
																																							case 258:
																																								goto IL_0f99;
																																							case 143:
																																								goto IL_0fda;
																																							case 160:
																																								goto IL_0fee;
																																							case 351:
																																							case 359:
																																								goto IL_1001;
																																							case 192:
																																								goto IL_105c;
																																							case 332:
																																								goto IL_106f;
																																							case 182:
																																								goto IL_107d;
																																							case 128:
																																							case 313:
																																								goto IL_1088;
																																							case 239:
																																								goto IL_10c6;
																																							case 197:
																																								goto IL_10d4;
																																							case 289:
																																								goto IL_10e7;
																																							case 287:
																																								goto IL_10f5;
																																							case 135:
																																							case 290:
																																								goto IL_1100;
																																							case 199:
																																								goto IL_110e;
																																							case 356:
																																								goto IL_1131;
																																							case 268:
																																								goto IL_113f;
																																							case 301:
																																								goto IL_1152;
																																							case 331:
																																								goto IL_1160;
																																							case 123:
																																							case 193:
																																								goto IL_116b;
																																							case 185:
																																								goto IL_117f;
																																							case 247:
																																								goto IL_11b7;
																																							case 165:
																																								goto IL_11ca;
																																							case 52:
																																								goto IL_11d8;
																																							case 242:
																																							case 286:
																																								goto IL_11e6;
																																							case 65:
																																								goto IL_11fa;
																																							case 89:
																																								goto IL_1232;
																																							case 223:
																																								goto IL_1245;
																																							case 317:
																																								goto IL_1250;
																																							case 37:
																																							case 344:
																																								goto IL_125e;
																																							case 212:
																																								goto IL_1276;
																																							case 116:
																																								goto IL_1284;
																																							case 338:
																																								goto IL_1292;
																																							case 62:
																																								goto IL_12a5;
																																							case 299:
																																								goto IL_12b3;
																																							case 124:
																																							case 181:
																																								goto IL_12c1;
																																							case 108:
																																								goto IL_1313;
																																							case 190:
																																								goto IL_1321;
																																							case 5:
																																								goto IL_1334;
																																							case 358:
																																								goto IL_1342;
																																							case 152:
																																							case 183:
																																								goto IL_134d;
																																							case 342:
																																								goto IL_1367;
																																							case 200:
																																								goto IL_1375;
																																							case 284:
																																								goto IL_1383;
																																							case 120:
																																								goto IL_1396;
																																							case 58:
																																								goto IL_13a1;
																																							case 234:
																																							case 269:
																																								goto IL_13af;
																																							case 163:
																																								goto IL_13ec;
																																							case 115:
																																								goto IL_13fa;
																																							case 215:
																																								goto IL_140d;
																																							case 303:
																																								goto IL_141b;
																																							case 36:
																																							case 55:
																																								goto IL_1429;
																																							case 254:
																																								goto IL_1446;
																																							case 33:
																																								goto IL_147e;
																																							case 19:
																																								goto IL_1491;
																																							case 256:
																																								goto IL_149c;
																																							case 94:
																																							case 255:
																																								goto IL_14aa;
																																							case 142:
																																								goto IL_14e8;
																																							case 177:
																																								goto IL_14f6;
																																							case 226:
																																								goto IL_1509;
																																							case 294:
																																								goto IL_1520;
																																							case 60:
																																							case 70:
																																								goto IL_1537;
																																							case 270:
																																								goto IL_1575;
																																							case 315:
																																								goto IL_1583;
																																							case 146:
																																								goto IL_1596;
																																							case 86:
																																								goto IL_15a4;
																																							case 311:
																																								goto IL_15b2;
																																							case 57:
																																								goto IL_15c0;
																																							case 104:
																																							case 327:
																																								goto IL_15cb;
																																							case 81:
																																								goto IL_15df;
																																							case 205:
																																								goto IL_1617;
																																							case 111:
																																								goto IL_162a;
																																							case 134:
																																								goto IL_1638;
																																							case 118:
																																							case 119:
																																								goto IL_1646;
																																							case 78:
																																								goto IL_1654;
																																							case 63:
																																								goto IL_1677;
																																							case 218:
																																								goto IL_1685;
																																							case 34:
																																								goto IL_1698;
																																							case 96:
																																								goto IL_16a6;
																																							case 188:
																																								goto IL_16b4;
																																							case 28:
																																							case 195:
																																								goto IL_16cb;
																																							case 132:
																																								goto IL_16e2;
																																							case 73:
																																								goto IL_1705;
																																							case 82:
																																								goto IL_1713;
																																							case 267:
																																								goto IL_172f;
																																							case 101:
																																							case 272:
																																								goto IL_173d;
																																							case 140:
																																								goto IL_1783;
																																							case 23:
																																								goto IL_1791;
																																							case 26:
																																							case 162:
																																								goto IL_17ad;
																																							case 198:
																																								goto IL_17ea;
																																							case 253:
																																								goto IL_1801;
																																							case 149:
																																								goto IL_1814;
																																							case 59:
																																								goto IL_1822;
																																							case 324:
																																							case 340:
																																								goto IL_182d;
																																							case 64:
																																								goto IL_186b;
																																							case 349:
																																								goto IL_1879;
																																							case 361:
																																								goto IL_188c;
																																							case 95:
																																								goto IL_189a;
																																							case 8:
																																							case 187:
																																								goto IL_18a8;
																																							case 48:
																																								goto IL_18bc;
																																							case 224:
																																								goto IL_1934;
																																							case 156:
																																								goto IL_1942;
																																							case 236:
																																								goto IL_1955;
																																							case 158:
																																								goto IL_1963;
																																							case 9:
																																							case 326:
																																								goto IL_1971;
																																							case 167:
																																								goto IL_19ae;
																																							case 16:
																																								goto IL_19bc;
																																							case 252:
																																								goto IL_19cc;
																																							case 333:
																																								goto IL_19d7;
																																							case 227:
																																							case 360:
																																								goto IL_19e2;
																																							case 194:
																																								goto IL_19fb;
																																							case 279:
																																								goto IL_1a0f;
																																							case 4:
																																							case 10:
																																							case 11:
																																							case 30:
																																							case 67:
																																							case 69:
																																							case 87:
																																							case 90:
																																							case 92:
																																							case 98:
																																							case 99:
																																							case 103:
																																							case 114:
																																							case 127:
																																							case 136:
																																							case 139:
																																							case 141:
																																							case 155:
																																							case 161:
																																							case 166:
																																							case 174:
																																							case 186:
																																							case 191:
																																							case 203:
																																							case 208:
																																							case 216:
																																							case 219:
																																							case 232:
																																							case 240:
																																							case 248:
																																							case 257:
																																							case 262:
																																							case 266:
																																							case 278:
																																							case 288:
																																							case 300:
																																							case 308:
																																							case 312:
																																							case 319:
																																							case 322:
																																							case 325:
																																							case 328:
																																							case 336:
																																							case 343:
																																							case 345:
																																							case 350:
																																								goto end_IL_067b;
																																							case 0:
																																							case 14:
																																							case 17:
																																							case 22:
																																							case 24:
																																							case 27:
																																							case 35:
																																							case 43:
																																							case 44:
																																							case 49:
																																							case 50:
																																							case 51:
																																							case 54:
																																							case 76:
																																							case 80:
																																							case 117:
																																							case 125:
																																							case 126:
																																							case 129:
																																							case 153:
																																							case 157:
																																							case 170:
																																							case 175:
																																							case 176:
																																							case 196:
																																							case 204:
																																							case 210:
																																							case 217:
																																							case 230:
																																							case 231:
																																							case 259:
																																							case 273:
																																							case 274:
																																							case 275:
																																							case 280:
																																							case 282:
																																							case 291:
																																							case 293:
																																							case 296:
																																							case 302:
																																							case 304:
																																							case 305:
																																							case 314:
																																							case 329:
																																							case 337:
																																							case 347:
																																								goto IL_1a2d;
																																							case 138:
																																								goto IL_1a40;
																																							case 107:
																																								goto IL_1a4a;
																																							case 292:
																																								goto IL_1a55;
																																							case 83:
																																								goto IL_1a65;
																																							case 171:
																																								goto IL_1a75;
																																							case 285:
																																								goto IL_1a85;
																																							case 244:
																																								goto IL_1a95;
																																							case 21:
																																								goto IL_1aa5;
																																							case 71:
																																								goto IL_1ab5;
																																							case 271:
																																								goto IL_1ac5;
																																							case 105:
																																								goto IL_1ad5;
																																							case 12:
																																								goto IL_1ae5;
																																							case 74:
																																							case 172:
																																								goto IL_1b00;
																																							}
																																							goto end_IL_064b;
																																						}
																																						num6++;
																																						goto IL_0f30;
																																						IL_0f30:
																																						ptr2 += 16;
																																						goto IL_1a2d;
																																						continue;
																																						end_IL_05d7:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_06d1;
																																		IL_07f1:
																																		ptr2 += 8;
																																		goto IL_1a2d;
																																		IL_06d1:
																																		if (17 >= b)
																																		{
																																			goto IL_06dc;
																																		}
																																		goto IL_0708;
																																		IL_06dc:
																																		if (17 > b)
																																		{
																																			goto end_IL_067b;
																																		}
																																		goto IL_087e;
																																		IL_087e:
																																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																																		goto IL_0e1f;
																																		IL_0e1f:
																																		num6 -= 3;
																																		goto IL_1a2d;
																																		IL_0708:
																																		if (18 < b)
																																		{
																																			goto end_IL_067b;
																																		}
																																		goto IL_0716;
																																		IL_0716:
																																		if (18 > b)
																																		{
																																			goto end_IL_067b;
																																		}
																																		goto IL_07a5;
																																		IL_07a5:
																																		array2[num6 - 1] = 5;
																																		goto IL_07b9;
																																		IL_07b9:
																																		array3[num6 - 1] = ((delegate*<string[], string>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																																		goto IL_07f1;
																																	}
																																	break;
																																}
																																goto IL_0f43;
																																IL_0fee:
																																num6--;
																																goto IL_1a2d;
																																IL_0f43:
																																if (20 >= b)
																																{
																																	goto IL_0f4e;
																																}
																																goto IL_0f7d;
																																IL_0f4e:
																																if (20 > b)
																																{
																																	goto end_IL_067b;
																																}
																																goto IL_0f5c;
																																IL_0f5c:
																																ptr2 = ptr + *(int*)(ptr2 + num3);
																																num = 44;
																																goto IL_1a2d;
																																IL_0f7d:
																																if (21 < b)
																																{
																																	goto end_IL_067b;
																																}
																																goto IL_0f8b;
																																IL_0f8b:
																																if (21 > b)
																																{
																																	goto end_IL_067b;
																																}
																																goto IL_0f99;
																																IL_0f99:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																																goto IL_0fda;
																																IL_0fda:
																																array2[num6 - 2] = 0;
																																goto IL_0fee;
																															}
																															break;
																														}
																														goto IL_06b6;
																														IL_0e8c:
																														array3[num6] = array3[num6 - 1];
																														goto IL_0ea4;
																														IL_06b6:
																														if (16 > b)
																														{
																															goto IL_06c4;
																														}
																														goto IL_0804;
																														IL_06c4:
																														if (13 < b)
																														{
																															goto IL_06ef;
																														}
																														goto IL_0726;
																														IL_0726:
																														if (13 > b)
																														{
																															goto IL_0734;
																														}
																														goto IL_0b54;
																														IL_0734:
																														if (12 < b)
																														{
																															goto end_IL_067b;
																														}
																														goto IL_0742;
																														IL_0742:
																														if (12 > b)
																														{
																															goto end_IL_067b;
																														}
																														goto IL_0bbf;
																														IL_0bbf:
																														array8 = array3;
																														num7 = num6;
																														if (array == null)
																														{
																															goto IL_0bce;
																														}
																														num8 = ptr2;
																														byte b2 = *num8;
																														ptr2 = num8 + 4;
																														int num9 = *(int*)(ptr2 + num3);
																														ptr2 += 8;
																														byte* ptr3 = ptr2 + num9;
																														byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																														while (ptr2 != ptr3)
																														{
																															*ptr4 = (byte)(*ptr2 ^ b2);
																															ptr2++;
																															ptr4++;
																														}
																														array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																														goto IL_0c76;
																														IL_0ea4:
																														num6++;
																														goto IL_1a2d;
																														IL_0804:
																														array2[num6] = 5;
																														num = 169;
																														goto IL_081b;
																														IL_081b:
																														array3[num6] = array7[*(int*)(ptr2 + num3)];
																														goto IL_0833;
																														IL_0c76:
																														array2[num6] = 5;
																														goto IL_0c84;
																														IL_0c84:
																														num6++;
																														goto IL_1a2d;
																														IL_0b54:
																														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																														goto IL_0b72;
																														IL_0b72:
																														ptr2 += 8;
																														goto IL_0e0c;
																														IL_0e0c:
																														num6--;
																														goto IL_1a2d;
																														IL_06ef:
																														if (14 >= b)
																														{
																															num = 246;
																															goto IL_0755;
																														}
																														goto IL_0854;
																														IL_0833:
																														num6++;
																														goto IL_0841;
																														IL_0755:
																														if (14 > b)
																														{
																															goto end_IL_067b;
																														}
																														goto IL_0763;
																														IL_0763:
																														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																														goto IL_078c;
																														IL_078c:
																														array2[num6 - 1] = 5;
																														goto IL_1a2d;
																														IL_0854:
																														if (15 < b)
																														{
																															goto end_IL_067b;
																														}
																														num = 29;
																														goto IL_086b;
																														IL_0841:
																														ptr2 += 8;
																														goto IL_1a2d;
																														IL_086b:
																														if (15 > b)
																														{
																															goto end_IL_067b;
																														}
																														goto IL_0e32;
																														IL_0e32:
																														array2[num6] = array2[num6 - 1];
																														goto IL_0e4a;
																														IL_0e4a:
																														array4[num6 - 0] = array4[num6 - 1];
																														goto IL_0e68;
																														IL_0e68:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_0e8c;
																													}
																													goto IL_0eca;
																												}
																												goto IL_08c1;
																												IL_0acc:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0b2e;
																												IL_08c1:
																												if (11 <= b)
																												{
																													goto IL_1a2d;
																												}
																												goto IL_08cf;
																												IL_08cf:
																												if (5 >= b)
																												{
																													goto IL_08da;
																												}
																												goto IL_0941;
																												IL_08da:
																												if (5 <= b)
																												{
																													goto IL_08e8;
																												}
																												goto IL_0c97;
																												IL_08e8:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0928;
																												IL_0928:
																												array2[num6 - 2] = 0;
																												goto IL_0b85;
																												IL_0b85:
																												num6--;
																												goto IL_1a2d;
																												IL_0c97:
																												if (2 >= b)
																												{
																													goto IL_0ca5;
																												}
																												goto IL_0d7b;
																												IL_0ca5:
																												if (2 <= b)
																												{
																													goto IL_0cb0;
																												}
																												goto IL_0d17;
																												IL_0cb0:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0cf0;
																												IL_0cf0:
																												array2[num6 - 2] = 0;
																												goto IL_0d04;
																												IL_0d04:
																												num6--;
																												goto IL_1a2d;
																												IL_0d17:
																												if (1 < b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0d25;
																												IL_0d25:
																												if (1 > b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0d33;
																												IL_0d33:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																												goto IL_0d4c;
																												IL_0d4c:
																												array2[num6] = 0;
																												goto IL_0d5a;
																												IL_0d5a:
																												num6++;
																												goto IL_0d68;
																												IL_0d68:
																												ptr2 += 8;
																												goto IL_1a2d;
																												IL_0d7b:
																												if (3 < b)
																												{
																													goto IL_0d86;
																												}
																												num = 362;
																												goto IL_0eca;
																												IL_0d86:
																												if (4 < b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0d94;
																												IL_0d94:
																												if (4 > b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0da2;
																												IL_0da2:
																												array2[num6] = 0;
																												goto IL_0db0;
																												IL_0db0:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																												goto IL_0dd3;
																												IL_0dd3:
																												array3[num6] = null;
																												goto IL_0ddd;
																												IL_0ddd:
																												num6++;
																												goto IL_0deb;
																												IL_0deb:
																												ptr2 += 8;
																												goto IL_1a2d;
																												IL_0b2e:
																												num6 -= 2;
																												goto IL_1a2d;
																												IL_0eca:
																												if (3 > b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0ed8;
																												IL_0ed8:
																												reference = ref array5[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0f01;
																												IL_0f01:
																												ptr2 += 8;
																												goto IL_0f0f;
																												IL_0f0f:
																												num6--;
																												goto IL_1a2d;
																												IL_0941:
																												if (8 >= b)
																												{
																													goto IL_094f;
																												}
																												goto IL_0a30;
																												IL_094f:
																												if (8 > b)
																												{
																													goto IL_095d;
																												}
																												goto IL_0eb7;
																												IL_095d:
																												if (6 >= b)
																												{
																													goto IL_0968;
																												}
																												goto IL_09cf;
																												IL_0968:
																												if (6 > b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0976;
																												IL_0976:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_09b6;
																												IL_09b6:
																												array2[num6 - 2] = 0;
																												goto IL_0b41;
																												IL_0b41:
																												num6--;
																												goto IL_1a2d;
																												IL_09cf:
																												if (7 < b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_09dd;
																												IL_09dd:
																												if (7 > b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_09eb;
																												IL_09eb:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0b98;
																												IL_0b98:
																												array2[num6 - 2] = 0;
																												goto IL_0bac;
																												IL_0bac:
																												num6--;
																												goto IL_1a2d;
																												IL_0eb7:
																												num6--;
																												goto IL_1a2d;
																												IL_0a30:
																												if (9 >= b)
																												{
																													goto IL_0a3b;
																												}
																												goto IL_0ab0;
																												IL_0a3b:
																												if (9 > b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0a49;
																												IL_0a49:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0a89;
																												IL_0a89:
																												array2[num6 - 2] = 0;
																												goto IL_0a9d;
																												IL_0a9d:
																												num6--;
																												goto IL_1a2d;
																												IL_0ab0:
																												if (10 < b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0abe;
																												IL_0abe:
																												if (10 > b)
																												{
																													goto end_IL_067b;
																												}
																												goto IL_0acc;
																												continue;
																												end_IL_064b:
																												break;
																											}
																											break;
																										}
																										goto IL_1001;
																										IL_105c:
																										num6--;
																										goto IL_1a2d;
																										IL_1001:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										num = 192;
																										goto IL_105c;
																									}
																									break;
																								}
																								goto IL_106f;
																								IL_19cc:
																								if (42 >= b)
																								{
																									goto IL_19d7;
																								}
																								goto IL_19fb;
																								IL_106f:
																								if (33 >= b)
																								{
																									goto IL_107d;
																								}
																								goto IL_1596;
																								IL_107d:
																								if (33 <= b)
																								{
																									goto IL_1088;
																								}
																								goto IL_10e7;
																								IL_1088:
																								((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								goto IL_10c6;
																								IL_10c6:
																								num6 -= 2;
																								goto IL_10d4;
																								IL_10d4:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_10e7:
																								if (27 >= b)
																								{
																									goto IL_10f5;
																								}
																								goto IL_1334;
																								IL_10f5:
																								if (27 <= b)
																								{
																									goto IL_1100;
																								}
																								goto IL_1152;
																								IL_1100:
																								array2[num6] = 4;
																								goto IL_110e;
																								IL_110e:
																								array3[num6] = ((delegate*<Vector3>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])();
																								goto IL_1131;
																								IL_1131:
																								num6++;
																								goto IL_113f;
																								IL_113f:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1152:
																								if (24 >= b)
																								{
																									goto IL_1160;
																								}
																								goto IL_1245;
																								IL_1160:
																								if (24 <= b)
																								{
																									goto IL_116b;
																								}
																								goto IL_11ca;
																								IL_116b:
																								array2[num6 - 1] = 5;
																								goto IL_117f;
																								IL_117f:
																								array3[num6 - 1] = ((delegate*<GameObject, Transform>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
																								goto IL_11b7;
																								IL_11b7:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_11ca:
																								if (23 < b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_11d8;
																								IL_11d8:
																								if (23 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_11e6;
																								IL_11e6:
																								array2[num6 - 1] = 5;
																								goto IL_11fa;
																								IL_11fa:
																								array3[num6 - 1] = ((delegate*<string, GameObject>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_1232;
																								IL_1232:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1245:
																								if (25 >= b)
																								{
																									goto IL_1250;
																								}
																								goto IL_12a5;
																								IL_1250:
																								if (25 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_125e;
																								IL_125e:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_1276;
																								IL_1276:
																								array2[num6] = 5;
																								goto IL_1284;
																								IL_1284:
																								num6++;
																								goto IL_1292;
																								IL_1292:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_12a5:
																								if (26 < b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_12b3;
																								IL_12b3:
																								if (26 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_12c1;
																								IL_12c1:
																								((delegate*<Transform, Transform, bool, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 3], (Transform)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																								goto IL_1313;
																								IL_1313:
																								num6 -= 3;
																								goto IL_1321;
																								IL_1321:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1334:
																								if (30 >= b)
																								{
																									goto IL_1342;
																								}
																								goto IL_1491;
																								IL_1342:
																								if (30 <= b)
																								{
																									goto IL_134d;
																								}
																								goto IL_1396;
																								IL_134d:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																								goto IL_1367;
																								IL_1367:
																								array2[num6] = 3;
																								goto IL_1375;
																								IL_1375:
																								num6++;
																								goto IL_1383;
																								IL_1383:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1396:
																								if (28 >= b)
																								{
																									goto IL_13a1;
																								}
																								goto IL_140d;
																								IL_13a1:
																								if (28 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_13af;
																								IL_13af:
																								((delegate*<Transform, Vector3, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																								goto IL_13ec;
																								IL_13ec:
																								num6 -= 2;
																								goto IL_13fa;
																								IL_13fa:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_140d:
																								if (29 < b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_141b;
																								IL_141b:
																								if (29 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_1429;
																								IL_1429:
																								array2[num6 - 1] = 5;
																								num = 254;
																								goto IL_1446;
																								IL_1446:
																								array3[num6 - 1] = ((delegate*<GameObject, TrailRenderer>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
																								goto IL_147e;
																								IL_147e:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1491:
																								if (31 >= b)
																								{
																									goto IL_149c;
																								}
																								goto IL_1509;
																								IL_149c:
																								if (31 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_14aa;
																								IL_14aa:
																								((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								goto IL_14e8;
																								IL_14e8:
																								num6 -= 2;
																								goto IL_14f6;
																								IL_14f6:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1509:
																								if (32 < b)
																								{
																									goto end_IL_067b;
																								}
																								num = 294;
																								goto IL_1520;
																								IL_19d7:
																								if (42 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_19e2;
																								IL_1520:
																								if (32 > b)
																								{
																									goto end_IL_067b;
																								}
																								num = 70;
																								goto IL_1537;
																								IL_19e2:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto IL_1a2d;
																								IL_1537:
																								((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								goto IL_1575;
																								IL_1575:
																								num6 -= 2;
																								goto IL_1583;
																								IL_1583:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1596:
																								if (38 >= b)
																								{
																									goto IL_15a4;
																								}
																								goto IL_1814;
																								IL_15a4:
																								if (38 > b)
																								{
																									goto IL_15b2;
																								}
																								goto IL_17ad;
																								IL_15b2:
																								if (35 >= b)
																								{
																									goto IL_15c0;
																								}
																								goto IL_1698;
																								IL_15c0:
																								if (35 <= b)
																								{
																									goto IL_15cb;
																								}
																								goto IL_162a;
																								IL_15cb:
																								array2[num6 - 1] = 5;
																								goto IL_15df;
																								IL_15df:
																								array3[num6 - 1] = ((delegate*<Color, Material>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																								goto IL_1617;
																								IL_1617:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_162a:
																								if (34 < b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_1638;
																								IL_1638:
																								if (34 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_1646;
																								IL_1646:
																								array2[num6] = 4;
																								goto IL_1654;
																								IL_1654:
																								array3[num6] = ((delegate*<Color>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])();
																								goto IL_1677;
																								IL_1677:
																								num6++;
																								goto IL_1685;
																								IL_1685:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1698:
																								if (36 < b)
																								{
																									goto IL_16a6;
																								}
																								num = 267;
																								goto IL_172f;
																								IL_16a6:
																								if (37 < b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_16b4;
																								IL_16b4:
																								if (37 > b)
																								{
																									goto end_IL_067b;
																								}
																								num = 195;
																								goto IL_16cb;
																								IL_1a0f:
																								if (43 <= b)
																								{
																								}
																								goto end_IL_067b;
																								IL_16cb:
																								array2[num6] = 4;
																								num = 132;
																								goto IL_16e2;
																								IL_16e2:
																								array3[num6] = ((delegate*<Color>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])();
																								goto IL_1705;
																								IL_1705:
																								num6++;
																								goto IL_1713;
																								IL_1713:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_19fb:
																								if (43 < b)
																								{
																									goto end_IL_067b;
																								}
																								num = 279;
																								goto IL_1a0f;
																								IL_172f:
																								if (36 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_173d;
																								IL_173d:
																								((delegate*<Renderer, Material, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (Material)array3[num6 - 1]);
																								num = 140;
																								goto IL_1783;
																								IL_1783:
																								num6 -= 2;
																								goto IL_1791;
																								IL_1791:
																								ptr2 += 8;
																								num = 305;
																								goto IL_1a2d;
																								IL_17ad:
																								((delegate*<TrailRenderer, Color, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
																								goto IL_17ea;
																								IL_17ea:
																								num6 -= 2;
																								num = 253;
																								goto IL_1801;
																								IL_1801:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1814:
																								if (41 >= b)
																								{
																									goto IL_1822;
																								}
																								goto IL_19cc;
																								IL_1822:
																								if (41 <= b)
																								{
																									goto IL_182d;
																								}
																								goto IL_188c;
																								IL_182d:
																								((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								goto IL_186b;
																								IL_186b:
																								num6 -= 2;
																								goto IL_1879;
																								IL_1879:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_188c:
																								if (39 >= b)
																								{
																									goto IL_189a;
																								}
																								goto IL_1955;
																								IL_189a:
																								if (39 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_18a8;
																								IL_18a8:
																								array2[num6 - 4] = 5;
																								goto IL_18bc;
																								IL_18bc:
																								array3[num6 - 4] = ((delegate*<float, float, float, float, object>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								goto IL_1934;
																								IL_1934:
																								num6 -= 3;
																								goto IL_1942;
																								IL_1942:
																								ptr2 += 8;
																								goto IL_1a2d;
																								IL_1955:
																								if (40 < b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_1963;
																								IL_1963:
																								if (40 > b)
																								{
																									goto end_IL_067b;
																								}
																								goto IL_1971;
																								IL_1971:
																								((delegate*<TrailRenderer, Color, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
																								goto IL_19ae;
																								IL_19ae:
																								num6 -= 2;
																								goto IL_19bc;
																								IL_19bc:
																								ptr2 += 8;
																								goto IL_1a2d;
																							}
																							goto end_IL_068b;
																							continue;
																							end_IL_067b:
																							break;
																							IL_067b:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_1a2d;
																					continue;
																					end_IL_068b:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_1b00;
																	IL_1b00:
																	return (TrailRenderer)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0bce:
			while (true)
			{
				IL_0bce_2:
				array = new byte[4];
				while (true)
				{
					IL_0bdc:
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_0c84_2:
							num6++;
							while (true)
							{
								IL_1a2d_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_068b_2:
												if (b >= 1)
												{
													while (b <= 43)
													{
														while (true)
														{
															if (22 >= b)
															{
																while (true)
																{
																	if (22 > b)
																	{
																		while (true)
																		{
																			IL_064b_2:
																			if (11 < b)
																			{
																				while (true)
																				{
																					IL_063e_2:
																					if (16 < b)
																					{
																						while (true)
																						{
																							IL_062e_2:
																							if (19 >= b)
																							{
																								while (true)
																								{
																									IL_061e_2:
																									if (19 <= b)
																									{
																										while (true)
																										{
																											IL_0603_2:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																											while (true)
																											{
																												IL_05ea_2:
																												array2[num6] = 1;
																												num = 370;
																												while (true)
																												{
																													if (num != 370)
																													{
																														if (num != 1351)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 56:
																															goto IL_05ea_2;
																														case 91:
																														case 145:
																															goto IL_0603_2;
																														case 184:
																															goto IL_061e_2;
																														case 93:
																															goto IL_062e_2;
																														case 237:
																															goto IL_063e_2;
																														case 31:
																															goto IL_064b_2;
																														case 148:
																															goto end_IL_064b_2;
																														case 295:
																															goto end_IL_065b;
																														case 354:
																															goto end_IL_066b;
																														case 97:
																															goto IL_068b_2;
																														case 363:
																															goto end_IL_068b_2;
																														case 47:
																														case 88:
																															goto end_IL_069b;
																														case 150:
																															goto IL_06b6_2;
																														case 85:
																															goto IL_06c4_2;
																														case 164:
																															goto IL_06d1_2;
																														case 137:
																															goto IL_06dc_2;
																														case 189:
																															goto IL_06ef_2;
																														case 221:
																															goto IL_0708_2;
																														case 25:
																															goto IL_0716_2;
																														case 225:
																															goto IL_0726_2;
																														case 238:
																															goto IL_0734_2;
																														case 159:
																															goto IL_0742_2;
																														case 246:
																															goto IL_0755_2;
																														case 79:
																														case 206:
																															goto IL_0763_2;
																														case 235:
																															goto IL_078c_2;
																														case 245:
																														case 249:
																															goto IL_07a5_2;
																														case 72:
																															goto IL_07b9_2;
																														case 20:
																															goto IL_07f1_2;
																														case 61:
																														case 260:
																															goto IL_0804_2;
																														case 169:
																															goto IL_081b_2;
																														case 39:
																															goto IL_0833_2;
																														case 15:
																															goto IL_0841_2;
																														case 263:
																															goto IL_0854_2;
																														case 29:
																															goto IL_086b_2;
																														case 18:
																														case 309:
																															goto IL_087e_2;
																														case 316:
																															goto IL_08c1_2;
																														case 250:
																															goto IL_08cf_2;
																														case 38:
																															goto IL_08da_2;
																														case 173:
																														case 207:
																															goto IL_08e8_2;
																														case 121:
																															goto IL_0928_2;
																														case 261:
																															goto IL_0941_2;
																														case 211:
																															goto IL_094f_2;
																														case 109:
																															goto IL_095d_2;
																														case 53:
																															goto IL_0968_2;
																														case 7:
																														case 106:
																															goto IL_0976_2;
																														case 84:
																															goto IL_09b6_2;
																														case 310:
																															goto IL_09cf_2;
																														case 100:
																															goto IL_09dd_2;
																														case 168:
																														case 265:
																															goto IL_09eb_2;
																														case 151:
																															goto IL_0a30_2;
																														case 122:
																															goto IL_0a3b_2;
																														case 40:
																														case 264:
																															goto IL_0a49_2;
																														case 201:
																															goto IL_0a89_2;
																														case 154:
																															goto IL_0a9d_2;
																														case 2:
																															goto IL_0ab0_2;
																														case 41:
																															goto IL_0abe_2;
																														case 3:
																														case 276:
																															goto IL_0acc_2;
																														case 281:
																															goto IL_0b2e_2;
																														case 320:
																															goto IL_0b41_2;
																														case 209:
																														case 323:
																															goto IL_0b54_2;
																														case 241:
																															goto IL_0b72_2;
																														case 330:
																															goto IL_0b85_2;
																														case 339:
																															goto IL_0b98_2;
																														case 180:
																															goto IL_0bac_2;
																														case 45:
																														case 341:
																															goto IL_0bbf_2;
																														case 307:
																															goto end_IL_06ab;
																														case 32:
																															goto IL_0c84_2;
																														case 346:
																															goto IL_0c97_2;
																														case 277:
																															goto IL_0ca5_2;
																														case 113:
																														case 147:
																															goto IL_0cb0_2;
																														case 228:
																															goto IL_0cf0_2;
																														case 133:
																															goto IL_0d04_2;
																														case 306:
																															goto IL_0d17_2;
																														case 178:
																															goto IL_0d25_2;
																														case 298:
																														case 335:
																															goto IL_0d33_2;
																														case 251:
																															goto IL_0d4c_2;
																														case 214:
																															goto IL_0d5a_2;
																														case 112:
																															goto IL_0d68_2;
																														case 321:
																															goto IL_0d7b_2;
																														case 179:
																															goto IL_0d86_2;
																														case 334:
																															goto IL_0d94_2;
																														case 46:
																														case 66:
																															goto IL_0da2_2;
																														case 131:
																															goto IL_0db0_2;
																														case 1:
																															goto IL_0dd3_2;
																														case 233:
																															goto IL_0ddd_2;
																														case 6:
																															goto IL_0deb_2;
																														case 352:
																															goto IL_0e0c_2;
																														case 353:
																															goto IL_0e1f_2;
																														case 297:
																														case 355:
																															goto IL_0e32_2;
																														case 318:
																															goto IL_0e4a_2;
																														case 144:
																															goto IL_0e68_2;
																														case 283:
																															goto IL_0e8c_2;
																														case 102:
																															goto IL_0ea4_2;
																														case 202:
																														case 357:
																															goto IL_0eb7_2;
																														case 362:
																															goto end_IL_05d7_2;
																														case 75:
																														case 213:
																															goto IL_0ed8_2;
																														case 68:
																															goto IL_0f01_2;
																														case 222:
																															goto IL_0f0f_2;
																														case 348:
																															goto IL_0f30_2;
																														case 220:
																															goto IL_0f43_2;
																														case 77:
																															goto IL_0f4e_2;
																														case 42:
																														case 243:
																															goto IL_0f5c_2;
																														case 110:
																															goto IL_0f7d_2;
																														case 229:
																															goto IL_0f8b_2;
																														case 130:
																														case 258:
																															goto IL_0f99_2;
																														case 143:
																															goto IL_0fda_2;
																														case 160:
																															goto IL_0fee_2;
																														case 351:
																														case 359:
																															goto IL_1001_2;
																														case 192:
																															goto IL_105c_2;
																														case 332:
																															goto IL_106f_2;
																														case 182:
																															goto IL_107d_2;
																														case 128:
																														case 313:
																															goto IL_1088_2;
																														case 239:
																															goto IL_10c6_2;
																														case 197:
																															goto IL_10d4_2;
																														case 289:
																															goto IL_10e7_2;
																														case 287:
																															goto IL_10f5_2;
																														case 135:
																														case 290:
																															goto IL_1100_2;
																														case 199:
																															goto IL_110e_2;
																														case 356:
																															goto IL_1131_2;
																														case 268:
																															goto IL_113f_2;
																														case 301:
																															goto IL_1152_2;
																														case 331:
																															goto IL_1160_2;
																														case 123:
																														case 193:
																															goto IL_116b_2;
																														case 185:
																															goto IL_117f_2;
																														case 247:
																															goto IL_11b7_2;
																														case 165:
																															goto IL_11ca_2;
																														case 52:
																															goto IL_11d8_2;
																														case 242:
																														case 286:
																															goto IL_11e6_2;
																														case 65:
																															goto IL_11fa_2;
																														case 89:
																															goto IL_1232_2;
																														case 223:
																															goto IL_1245_2;
																														case 317:
																															goto IL_1250_2;
																														case 37:
																														case 344:
																															goto IL_125e_2;
																														case 212:
																															goto IL_1276_2;
																														case 116:
																															goto IL_1284_2;
																														case 338:
																															goto IL_1292_2;
																														case 62:
																															goto IL_12a5_2;
																														case 299:
																															goto IL_12b3_2;
																														case 124:
																														case 181:
																															goto IL_12c1_2;
																														case 108:
																															goto IL_1313_2;
																														case 190:
																															goto IL_1321_2;
																														case 5:
																															goto IL_1334_2;
																														case 358:
																															goto IL_1342_2;
																														case 152:
																														case 183:
																															goto IL_134d_2;
																														case 342:
																															goto IL_1367_2;
																														case 200:
																															goto IL_1375_2;
																														case 284:
																															goto IL_1383_2;
																														case 120:
																															goto IL_1396_2;
																														case 58:
																															goto IL_13a1_2;
																														case 234:
																														case 269:
																															goto IL_13af_2;
																														case 163:
																															goto IL_13ec_2;
																														case 115:
																															goto IL_13fa_2;
																														case 215:
																															goto IL_140d_2;
																														case 303:
																															goto IL_141b_2;
																														case 36:
																														case 55:
																															goto IL_1429_2;
																														case 254:
																															goto IL_1446_2;
																														case 33:
																															goto IL_147e_2;
																														case 19:
																															goto IL_1491_2;
																														case 256:
																															goto IL_149c_2;
																														case 94:
																														case 255:
																															goto IL_14aa_2;
																														case 142:
																															goto IL_14e8_2;
																														case 177:
																															goto IL_14f6_2;
																														case 226:
																															goto IL_1509_2;
																														case 294:
																															goto IL_1520_2;
																														case 60:
																														case 70:
																															goto IL_1537_2;
																														case 270:
																															goto IL_1575_2;
																														case 315:
																															goto IL_1583_2;
																														case 146:
																															goto IL_1596_2;
																														case 86:
																															goto IL_15a4_2;
																														case 311:
																															goto IL_15b2_2;
																														case 57:
																															goto IL_15c0_2;
																														case 104:
																														case 327:
																															goto IL_15cb_2;
																														case 81:
																															goto IL_15df_2;
																														case 205:
																															goto IL_1617_2;
																														case 111:
																															goto IL_162a_2;
																														case 134:
																															goto IL_1638_2;
																														case 118:
																														case 119:
																															goto IL_1646_2;
																														case 78:
																															goto IL_1654_2;
																														case 63:
																															goto IL_1677_2;
																														case 218:
																															goto IL_1685_2;
																														case 34:
																															goto IL_1698_2;
																														case 96:
																															goto IL_16a6_2;
																														case 188:
																															goto IL_16b4_2;
																														case 28:
																														case 195:
																															goto IL_16cb_2;
																														case 132:
																															goto IL_16e2_2;
																														case 73:
																															goto IL_1705_2;
																														case 82:
																															goto IL_1713_2;
																														case 267:
																															goto IL_172f_2;
																														case 101:
																														case 272:
																															goto IL_173d_2;
																														case 140:
																															goto IL_1783_2;
																														case 23:
																															goto IL_1791_2;
																														case 26:
																														case 162:
																															goto IL_17ad_2;
																														case 198:
																															goto IL_17ea_2;
																														case 253:
																															goto IL_1801_2;
																														case 149:
																															goto IL_1814_2;
																														case 59:
																															goto IL_1822_2;
																														case 324:
																														case 340:
																															goto IL_182d_2;
																														case 64:
																															goto IL_186b_2;
																														case 349:
																															goto IL_1879_2;
																														case 361:
																															goto IL_188c_2;
																														case 95:
																															goto IL_189a_2;
																														case 8:
																														case 187:
																															goto IL_18a8_2;
																														case 48:
																															goto IL_18bc_2;
																														case 224:
																															goto IL_1934_2;
																														case 156:
																															goto IL_1942_2;
																														case 236:
																															goto IL_1955_2;
																														case 158:
																															goto IL_1963_2;
																														case 9:
																														case 326:
																															goto IL_1971_2;
																														case 167:
																															goto IL_19ae_2;
																														case 16:
																															goto IL_19bc_2;
																														case 252:
																															goto IL_19cc_2;
																														case 333:
																															goto IL_19d7_2;
																														case 227:
																														case 360:
																															goto IL_19e2_2;
																														case 194:
																															goto IL_19fb_2;
																														case 279:
																															goto IL_1a0f_2;
																														case 4:
																														case 10:
																														case 11:
																														case 30:
																														case 67:
																														case 69:
																														case 87:
																														case 90:
																														case 92:
																														case 98:
																														case 99:
																														case 103:
																														case 114:
																														case 127:
																														case 136:
																														case 139:
																														case 141:
																														case 155:
																														case 161:
																														case 166:
																														case 174:
																														case 186:
																														case 191:
																														case 203:
																														case 208:
																														case 216:
																														case 219:
																														case 232:
																														case 240:
																														case 248:
																														case 257:
																														case 262:
																														case 266:
																														case 278:
																														case 288:
																														case 300:
																														case 308:
																														case 312:
																														case 319:
																														case 322:
																														case 325:
																														case 328:
																														case 336:
																														case 343:
																														case 345:
																														case 350:
																															goto end_IL_067b_2;
																														case 0:
																														case 14:
																														case 17:
																														case 22:
																														case 24:
																														case 27:
																														case 35:
																														case 43:
																														case 44:
																														case 49:
																														case 50:
																														case 51:
																														case 54:
																														case 76:
																														case 80:
																														case 117:
																														case 125:
																														case 126:
																														case 129:
																														case 153:
																														case 157:
																														case 170:
																														case 175:
																														case 176:
																														case 196:
																														case 204:
																														case 210:
																														case 217:
																														case 230:
																														case 231:
																														case 259:
																														case 273:
																														case 274:
																														case 275:
																														case 280:
																														case 282:
																														case 291:
																														case 293:
																														case 296:
																														case 302:
																														case 304:
																														case 305:
																														case 314:
																														case 329:
																														case 337:
																														case 347:
																															goto IL_1a2d_2;
																														case 138:
																															ptr2 = ptr;
																															goto IL_1a2d_2;
																														case 107:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EventRegistrationTokenGetSubKeyNames.getAccessControlTypesetCurrencyPositivePattern);
																															goto case 138;
																														case 292:
																															array7[0] = transform_0;
																															goto case 107;
																														case 83:
																															array7 = new object[10];
																															goto case 292;
																														case 171:
																															array6 = new long[6];
																															goto case 83;
																														case 285:
																															array5 = new int[7];
																															goto case 171;
																														case 244:
																															array4 = new int[6];
																															goto case 285;
																														case 21:
																															array3 = new object[6];
																															goto case 244;
																														case 71:
																															array2 = new byte[6];
																															goto case 21;
																														case 271:
																															num4 = num2 * 8;
																															goto case 71;
																														case 105:
																															num3 = num2 * 4;
																															goto case 271;
																														case 12:
																															num2 = 1;
																															goto case 105;
																														case 13:
																															goto end_IL_0c76;
																														case 74:
																														case 172:
																															goto IL_1b00_2;
																														}
																														continue;
																													}
																													num6++;
																													goto IL_0f30_2;
																													IL_0f30_2:
																													ptr2 += 16;
																													goto IL_1a2d_2;
																													continue;
																													end_IL_05d7_2:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_06d1_2;
																									IL_07f1_2:
																									ptr2 += 8;
																									goto IL_1a2d_2;
																									IL_06d1_2:
																									if (17 >= b)
																									{
																										goto IL_06dc_2;
																									}
																									goto IL_0708_2;
																									IL_06dc_2:
																									if (17 > b)
																									{
																										goto end_IL_067b_2;
																									}
																									goto IL_087e_2;
																									IL_087e_2:
																									((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																									goto IL_0e1f_2;
																									IL_0e1f_2:
																									num6 -= 3;
																									goto IL_1a2d_2;
																									IL_0708_2:
																									if (18 < b)
																									{
																										goto end_IL_067b_2;
																									}
																									goto IL_0716_2;
																									IL_0716_2:
																									if (18 > b)
																									{
																										goto end_IL_067b_2;
																									}
																									goto IL_07a5_2;
																									IL_07a5_2:
																									array2[num6 - 1] = 5;
																									goto IL_07b9_2;
																									IL_07b9_2:
																									array3[num6 - 1] = ((delegate*<string[], string>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_07f1_2;
																								}
																								break;
																							}
																							goto IL_0f43_2;
																							IL_0fee_2:
																							num6--;
																							goto IL_1a2d_2;
																							IL_0f43_2:
																							if (20 >= b)
																							{
																								goto IL_0f4e_2;
																							}
																							goto IL_0f7d_2;
																							IL_0f4e_2:
																							if (20 > b)
																							{
																								goto end_IL_067b_2;
																							}
																							goto IL_0f5c_2;
																							IL_0f5c_2:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 44;
																							goto IL_1a2d_2;
																							IL_0f7d_2:
																							if (21 < b)
																							{
																								goto end_IL_067b_2;
																							}
																							goto IL_0f8b_2;
																							IL_0f8b_2:
																							if (21 > b)
																							{
																								goto end_IL_067b_2;
																							}
																							goto IL_0f99_2;
																							IL_0f99_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_0fda_2;
																							IL_0fda_2:
																							array2[num6 - 2] = 0;
																							goto IL_0fee_2;
																						}
																						break;
																					}
																					goto IL_06b6_2;
																					IL_081b_2:
																					array3[num6] = array7[*(int*)(ptr2 + num3)];
																					goto IL_0833_2;
																					IL_06b6_2:
																					if (16 > b)
																					{
																						goto IL_06c4_2;
																					}
																					goto IL_0804_2;
																					IL_06c4_2:
																					if (13 < b)
																					{
																						goto IL_06ef_2;
																					}
																					goto IL_0726_2;
																					IL_0726_2:
																					if (13 > b)
																					{
																						goto IL_0734_2;
																					}
																					goto IL_0b54_2;
																					IL_0734_2:
																					if (12 < b)
																					{
																						goto end_IL_067b_2;
																					}
																					goto IL_0742_2;
																					IL_0742_2:
																					if (12 > b)
																					{
																						goto end_IL_067b_2;
																					}
																					goto IL_0bbf_2;
																					IL_0bbf_2:
																					array8 = array3;
																					num7 = num6;
																					if (array == null)
																					{
																						goto IL_0bce_2;
																					}
																					goto IL_0bdc;
																					IL_0b54_2:
																					array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																					goto IL_0b72_2;
																					IL_0b72_2:
																					ptr2 += 8;
																					goto IL_0e0c_2;
																					IL_0e0c_2:
																					num6--;
																					goto IL_1a2d_2;
																					IL_06ef_2:
																					if (14 >= b)
																					{
																						num = 246;
																						goto IL_0755_2;
																					}
																					goto IL_0854_2;
																					IL_0833_2:
																					num6++;
																					goto IL_0841_2;
																					IL_0755_2:
																					if (14 > b)
																					{
																						goto end_IL_067b_2;
																					}
																					goto IL_0763_2;
																					IL_0763_2:
																					array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					goto IL_078c_2;
																					IL_078c_2:
																					array2[num6 - 1] = 5;
																					goto IL_1a2d_2;
																					IL_0854_2:
																					if (15 < b)
																					{
																						goto end_IL_067b_2;
																					}
																					num = 29;
																					goto IL_086b_2;
																					IL_0841_2:
																					ptr2 += 8;
																					goto IL_1a2d_2;
																					IL_086b_2:
																					if (15 > b)
																					{
																						goto end_IL_067b_2;
																					}
																					goto IL_0e32_2;
																					IL_0e32_2:
																					array2[num6] = array2[num6 - 1];
																					goto IL_0e4a_2;
																					IL_0e4a_2:
																					array4[num6 - 0] = array4[num6 - 1];
																					goto IL_0e68_2;
																					IL_0e68_2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0e8c_2;
																					IL_0e8c_2:
																					array3[num6] = array3[num6 - 1];
																					goto IL_0ea4_2;
																					IL_0ea4_2:
																					num6++;
																					goto IL_1a2d_2;
																					IL_0804_2:
																					array2[num6] = 5;
																					num = 169;
																					goto IL_081b_2;
																				}
																				goto IL_0eca_2;
																			}
																			goto IL_08c1_2;
																			IL_0acc_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0b2e_2;
																			IL_08c1_2:
																			if (11 <= b)
																			{
																				goto IL_1a2d_2;
																			}
																			goto IL_08cf_2;
																			IL_08cf_2:
																			if (5 >= b)
																			{
																				goto IL_08da_2;
																			}
																			goto IL_0941_2;
																			IL_08da_2:
																			if (5 <= b)
																			{
																				goto IL_08e8_2;
																			}
																			goto IL_0c97_2;
																			IL_08e8_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0928_2;
																			IL_0928_2:
																			array2[num6 - 2] = 0;
																			goto IL_0b85_2;
																			IL_0b85_2:
																			num6--;
																			goto IL_1a2d_2;
																			IL_0c97_2:
																			if (2 >= b)
																			{
																				goto IL_0ca5_2;
																			}
																			goto IL_0d7b_2;
																			IL_0ca5_2:
																			if (2 <= b)
																			{
																				goto IL_0cb0_2;
																			}
																			goto IL_0d17_2;
																			IL_0cb0_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0cf0_2;
																			IL_0cf0_2:
																			array2[num6 - 2] = 0;
																			goto IL_0d04_2;
																			IL_0d04_2:
																			num6--;
																			goto IL_1a2d_2;
																			IL_0d17_2:
																			if (1 < b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0d25_2;
																			IL_0d25_2:
																			if (1 > b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0d33_2;
																			IL_0d33_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0d4c_2;
																			IL_0d4c_2:
																			array2[num6] = 0;
																			goto IL_0d5a_2;
																			IL_0d5a_2:
																			num6++;
																			goto IL_0d68_2;
																			IL_0d68_2:
																			ptr2 += 8;
																			goto IL_1a2d_2;
																			IL_0d7b_2:
																			if (3 < b)
																			{
																				goto IL_0d86_2;
																			}
																			num = 362;
																			goto IL_0eca_2;
																			IL_0d86_2:
																			if (4 < b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0d94_2;
																			IL_0d94_2:
																			if (4 > b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0da2_2;
																			IL_0da2_2:
																			array2[num6] = 0;
																			goto IL_0db0_2;
																			IL_0db0_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_0dd3_2;
																			IL_0dd3_2:
																			array3[num6] = null;
																			goto IL_0ddd_2;
																			IL_0ddd_2:
																			num6++;
																			goto IL_0deb_2;
																			IL_0deb_2:
																			ptr2 += 8;
																			goto IL_1a2d_2;
																			IL_0b2e_2:
																			num6 -= 2;
																			goto IL_1a2d_2;
																			IL_0eca_2:
																			if (3 > b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0ed8_2;
																			IL_0ed8_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0f01_2;
																			IL_0f01_2:
																			ptr2 += 8;
																			goto IL_0f0f_2;
																			IL_0f0f_2:
																			num6--;
																			goto IL_1a2d_2;
																			IL_0941_2:
																			if (8 >= b)
																			{
																				goto IL_094f_2;
																			}
																			goto IL_0a30_2;
																			IL_094f_2:
																			if (8 > b)
																			{
																				goto IL_095d_2;
																			}
																			goto IL_0eb7_2;
																			IL_095d_2:
																			if (6 >= b)
																			{
																				goto IL_0968_2;
																			}
																			goto IL_09cf_2;
																			IL_0968_2:
																			if (6 > b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0976_2;
																			IL_0976_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_09b6_2;
																			IL_09b6_2:
																			array2[num6 - 2] = 0;
																			goto IL_0b41_2;
																			IL_0b41_2:
																			num6--;
																			goto IL_1a2d_2;
																			IL_09cf_2:
																			if (7 < b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_09dd_2;
																			IL_09dd_2:
																			if (7 > b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_09eb_2;
																			IL_09eb_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0b98_2;
																			IL_0b98_2:
																			array2[num6 - 2] = 0;
																			goto IL_0bac_2;
																			IL_0bac_2:
																			num6--;
																			goto IL_1a2d_2;
																			IL_0eb7_2:
																			num6--;
																			goto IL_1a2d_2;
																			IL_0a30_2:
																			if (9 >= b)
																			{
																				goto IL_0a3b_2;
																			}
																			goto IL_0ab0_2;
																			IL_0a3b_2:
																			if (9 > b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0a49_2;
																			IL_0a49_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0a89_2;
																			IL_0a89_2:
																			array2[num6 - 2] = 0;
																			goto IL_0a9d_2;
																			IL_0a9d_2:
																			num6--;
																			goto IL_1a2d_2;
																			IL_0ab0_2:
																			if (10 < b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0abe_2;
																			IL_0abe_2:
																			if (10 > b)
																			{
																				goto end_IL_067b_2;
																			}
																			goto IL_0acc_2;
																			continue;
																			end_IL_064b_2:
																			break;
																		}
																		continue;
																	}
																	goto IL_1001_2;
																	IL_105c_2:
																	num6--;
																	goto IL_1a2d_2;
																	IL_1001_2:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	num = 192;
																	goto IL_105c_2;
																	continue;
																	end_IL_065b:
																	break;
																}
																continue;
															}
															goto IL_106f_2;
															IL_19cc_2:
															if (42 >= b)
															{
																goto IL_19d7_2;
															}
															goto IL_19fb_2;
															IL_106f_2:
															if (33 >= b)
															{
																goto IL_107d_2;
															}
															goto IL_1596_2;
															IL_107d_2:
															if (33 <= b)
															{
																goto IL_1088_2;
															}
															goto IL_10e7_2;
															IL_1088_2:
															((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
															goto IL_10c6_2;
															IL_10c6_2:
															num6 -= 2;
															goto IL_10d4_2;
															IL_10d4_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_10e7_2:
															if (27 >= b)
															{
																goto IL_10f5_2;
															}
															goto IL_1334_2;
															IL_10f5_2:
															if (27 <= b)
															{
																goto IL_1100_2;
															}
															goto IL_1152_2;
															IL_1100_2:
															array2[num6] = 4;
															goto IL_110e_2;
															IL_110e_2:
															array3[num6] = ((delegate*<Vector3>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])();
															goto IL_1131_2;
															IL_1131_2:
															num6++;
															goto IL_113f_2;
															IL_113f_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1152_2:
															if (24 >= b)
															{
																goto IL_1160_2;
															}
															goto IL_1245_2;
															IL_1160_2:
															if (24 <= b)
															{
																goto IL_116b_2;
															}
															goto IL_11ca_2;
															IL_116b_2:
															array2[num6 - 1] = 5;
															goto IL_117f_2;
															IL_117f_2:
															array3[num6 - 1] = ((delegate*<GameObject, Transform>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
															goto IL_11b7_2;
															IL_11b7_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_11ca_2:
															if (23 < b)
															{
																goto end_IL_067b_2;
															}
															goto IL_11d8_2;
															IL_11d8_2:
															if (23 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_11e6_2;
															IL_11e6_2:
															array2[num6 - 1] = 5;
															goto IL_11fa_2;
															IL_11fa_2:
															array3[num6 - 1] = ((delegate*<string, GameObject>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
															goto IL_1232_2;
															IL_1232_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1245_2:
															if (25 >= b)
															{
																goto IL_1250_2;
															}
															goto IL_12a5_2;
															IL_1250_2:
															if (25 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_125e_2;
															IL_125e_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_1276_2;
															IL_1276_2:
															array2[num6] = 5;
															goto IL_1284_2;
															IL_1284_2:
															num6++;
															goto IL_1292_2;
															IL_1292_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_12a5_2:
															if (26 < b)
															{
																goto end_IL_067b_2;
															}
															goto IL_12b3_2;
															IL_12b3_2:
															if (26 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_12c1_2;
															IL_12c1_2:
															((delegate*<Transform, Transform, bool, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 3], (Transform)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
															goto IL_1313_2;
															IL_1313_2:
															num6 -= 3;
															goto IL_1321_2;
															IL_1321_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1334_2:
															if (30 >= b)
															{
																goto IL_1342_2;
															}
															goto IL_1491_2;
															IL_1342_2:
															if (30 <= b)
															{
																goto IL_134d_2;
															}
															goto IL_1396_2;
															IL_134d_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
															goto IL_1367_2;
															IL_1367_2:
															array2[num6] = 3;
															goto IL_1375_2;
															IL_1375_2:
															num6++;
															goto IL_1383_2;
															IL_1383_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1396_2:
															if (28 >= b)
															{
																goto IL_13a1_2;
															}
															goto IL_140d_2;
															IL_13a1_2:
															if (28 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_13af_2;
															IL_13af_2:
															((delegate*<Transform, Vector3, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Vector3)array3[num6 - 1]);
															goto IL_13ec_2;
															IL_13ec_2:
															num6 -= 2;
															goto IL_13fa_2;
															IL_13fa_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_140d_2:
															if (29 < b)
															{
																goto end_IL_067b_2;
															}
															goto IL_141b_2;
															IL_141b_2:
															if (29 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_1429_2;
															IL_1429_2:
															array2[num6 - 1] = 5;
															num = 254;
															goto IL_1446_2;
															IL_1446_2:
															array3[num6 - 1] = ((delegate*<GameObject, TrailRenderer>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
															goto IL_147e_2;
															IL_147e_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1491_2:
															if (31 >= b)
															{
																goto IL_149c_2;
															}
															goto IL_1509_2;
															IL_149c_2:
															if (31 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_14aa_2;
															IL_14aa_2:
															((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
															goto IL_14e8_2;
															IL_14e8_2:
															num6 -= 2;
															goto IL_14f6_2;
															IL_14f6_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1509_2:
															if (32 < b)
															{
																goto end_IL_067b_2;
															}
															num = 294;
															goto IL_1520_2;
															IL_19d7_2:
															if (42 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_19e2_2;
															IL_1520_2:
															if (32 > b)
															{
																goto end_IL_067b_2;
															}
															num = 70;
															goto IL_1537_2;
															IL_19e2_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															goto IL_1a2d_2;
															IL_1537_2:
															((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
															goto IL_1575_2;
															IL_1575_2:
															num6 -= 2;
															goto IL_1583_2;
															IL_1583_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1596_2:
															if (38 >= b)
															{
																goto IL_15a4_2;
															}
															goto IL_1814_2;
															IL_15a4_2:
															if (38 > b)
															{
																goto IL_15b2_2;
															}
															goto IL_17ad_2;
															IL_15b2_2:
															if (35 >= b)
															{
																goto IL_15c0_2;
															}
															goto IL_1698_2;
															IL_15c0_2:
															if (35 <= b)
															{
																goto IL_15cb_2;
															}
															goto IL_162a_2;
															IL_15cb_2:
															array2[num6 - 1] = 5;
															goto IL_15df_2;
															IL_15df_2:
															array3[num6 - 1] = ((delegate*<Color, Material>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
															goto IL_1617_2;
															IL_1617_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_162a_2:
															if (34 < b)
															{
																goto end_IL_067b_2;
															}
															goto IL_1638_2;
															IL_1638_2:
															if (34 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_1646_2;
															IL_1646_2:
															array2[num6] = 4;
															goto IL_1654_2;
															IL_1654_2:
															array3[num6] = ((delegate*<Color>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])();
															goto IL_1677_2;
															IL_1677_2:
															num6++;
															goto IL_1685_2;
															IL_1685_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1698_2:
															if (36 < b)
															{
																goto IL_16a6_2;
															}
															num = 267;
															goto IL_172f_2;
															IL_16a6_2:
															if (37 < b)
															{
																goto end_IL_067b_2;
															}
															goto IL_16b4_2;
															IL_16b4_2:
															if (37 > b)
															{
																goto end_IL_067b_2;
															}
															num = 195;
															goto IL_16cb_2;
															IL_1a0f_2:
															if (43 <= b)
															{
															}
															goto end_IL_067b_2;
															IL_16cb_2:
															array2[num6] = 4;
															num = 132;
															goto IL_16e2_2;
															IL_16e2_2:
															array3[num6] = ((delegate*<Color>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])();
															goto IL_1705_2;
															IL_1705_2:
															num6++;
															goto IL_1713_2;
															IL_1713_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_19fb_2:
															if (43 < b)
															{
																goto end_IL_067b_2;
															}
															num = 279;
															goto IL_1a0f_2;
															IL_172f_2:
															if (36 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_173d_2;
															IL_173d_2:
															((delegate*<Renderer, Material, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (Material)array3[num6 - 1]);
															num = 140;
															goto IL_1783_2;
															IL_1783_2:
															num6 -= 2;
															goto IL_1791_2;
															IL_1791_2:
															ptr2 += 8;
															num = 305;
															goto IL_1a2d_2;
															IL_17ad_2:
															((delegate*<TrailRenderer, Color, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
															goto IL_17ea_2;
															IL_17ea_2:
															num6 -= 2;
															num = 253;
															goto IL_1801_2;
															IL_1801_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1814_2:
															if (41 >= b)
															{
																goto IL_1822_2;
															}
															goto IL_19cc_2;
															IL_1822_2:
															if (41 <= b)
															{
																goto IL_182d_2;
															}
															goto IL_188c_2;
															IL_182d_2:
															((delegate*<TrailRenderer, float, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
															goto IL_186b_2;
															IL_186b_2:
															num6 -= 2;
															goto IL_1879_2;
															IL_1879_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_188c_2:
															if (39 >= b)
															{
																goto IL_189a_2;
															}
															goto IL_1955_2;
															IL_189a_2:
															if (39 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_18a8_2;
															IL_18a8_2:
															array2[num6 - 4] = 5;
															goto IL_18bc_2;
															IL_18bc_2:
															array3[num6 - 4] = ((delegate*<float, float, float, float, object>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
															goto IL_1934_2;
															IL_1934_2:
															num6 -= 3;
															goto IL_1942_2;
															IL_1942_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															IL_1955_2:
															if (40 < b)
															{
																goto end_IL_067b_2;
															}
															goto IL_1963_2;
															IL_1963_2:
															if (40 > b)
															{
																goto end_IL_067b_2;
															}
															goto IL_1971_2;
															IL_1971_2:
															((delegate*<TrailRenderer, Color, void>)TimerQueueTimerGetRawCertData[*(int*)(ptr2 + num3)])((TrailRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
															goto IL_19ae_2;
															IL_19ae_2:
															num6 -= 2;
															goto IL_19bc_2;
															IL_19bc_2:
															ptr2 += 8;
															goto IL_1a2d_2;
															continue;
															end_IL_066b:
															break;
														}
														continue;
														end_IL_067b_2:
														break;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_1a2d_2;
												continue;
												end_IL_068b_2:
												break;
											}
											continue;
											end_IL_069b:
											break;
										}
										continue;
										end_IL_06ab:
										break;
									}
									break;
								}
								goto IL_1b00_2;
								IL_1b00_2:
								return (TrailRenderer)array3[num6 - 1];
							}
							break;
						}
						continue;
						end_IL_0c76:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private void OnDisable()
	{
		NativeRegisterRelativeTypeInfo(this);
	}

	private unsafe void method_1()
	{
		int num = 102;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GPlatform.IsValidAttributeValueStackCrawlMarkHandle);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 26;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_03e0:
																		if (b >= 1)
																		{
																			num = 60;
																			while (b <= 22)
																			{
																				while (true)
																				{
																					IL_03c0:
																					if (11 < b)
																					{
																						while (true)
																						{
																							IL_03b0:
																							if (17 >= b)
																							{
																								while (true)
																								{
																									IL_03a0:
																									if (17 > b)
																									{
																										while (true)
																										{
																											IL_0390:
																											if (14 < b)
																											{
																												while (true)
																												{
																													IL_0383:
																													if (15 < b)
																													{
																														while (16 >= b)
																														{
																															while (16 <= b)
																															{
																																while (true)
																																{
																																	IL_0340:
																																	array2[num6] = array5[*(int*)(ptr2 + num3)];
																																	num = 196;
																																	while (true)
																																	{
																																		if (num != 196)
																																		{
																																			if (num != 1177)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 12:
																																			case 150:
																																				goto IL_0340;
																																			case 128:
																																				goto IL_0363;
																																			case 127:
																																				goto IL_0373;
																																			case 27:
																																				goto IL_0383;
																																			case 114:
																																				goto IL_0390;
																																			case 17:
																																				goto IL_03a0;
																																			case 1:
																																				goto IL_03b0;
																																			case 171:
																																				goto IL_03c0;
																																			case 60:
																																				goto IL_03d0;
																																			case 55:
																																				goto IL_03e0;
																																			case 49:
																																				goto end_IL_03e0;
																																			case 16:
																																			case 30:
																																				goto end_IL_03f3;
																																			case 40:
																																				goto IL_040e;
																																			case 44:
																																			case 115:
																																				goto IL_041c;
																																			case 19:
																																				goto IL_046e;
																																			case 161:
																																				goto IL_0481;
																																			case 162:
																																				goto IL_048f;
																																			case 133:
																																				goto IL_049d;
																																			case 63:
																																				goto IL_04ab;
																																			case 81:
																																				goto IL_04b9;
																																			case 50:
																																			case 94:
																																				goto IL_04c4;
																																			case 48:
																																				goto IL_050d;
																																			case 24:
																																				goto IL_052a;
																																			case 160:
																																				goto IL_053d;
																																			case 158:
																																				goto IL_054b;
																																			case 3:
																																			case 153:
																																				goto IL_0559;
																																			case 130:
																																				goto IL_0572;
																																			case 52:
																																				goto IL_0580;
																																			case 9:
																																				goto IL_058e;
																																			case 132:
																																				goto IL_05a1;
																																			case 62:
																																				goto IL_05ac;
																																			case 18:
																																				goto IL_05bf;
																																			case 103:
																																				goto IL_05ca;
																																			case 118:
																																			case 147:
																																				goto IL_05e1;
																																			case 116:
																																				goto IL_0621;
																																			case 123:
																																				goto IL_0635;
																																			case 37:
																																				goto IL_0648;
																																			case 78:
																																				goto IL_0656;
																																			case 5:
																																			case 136:
																																				goto IL_0664;
																																			case 138:
																																				goto IL_06c6;
																																			case 0:
																																			case 164:
																																				goto IL_06d9;
																																			case 45:
																																				goto IL_0719;
																																			case 126:
																																				goto IL_072d;
																																			case 82:
																																			case 165:
																																				goto IL_0740;
																																			case 166:
																																				goto IL_0753;
																																			case 25:
																																				goto IL_075e;
																																			case 15:
																																			case 119:
																																				goto IL_076c;
																																			case 43:
																																				goto IL_07ac;
																																			case 92:
																																				goto IL_07c2;
																																			case 170:
																																				goto IL_07d5;
																																			case 173:
																																				goto IL_07e8;
																																			case 120:
																																				goto IL_07f3;
																																			case 7:
																																			case 80:
																																				goto IL_0801;
																																			case 135:
																																				goto IL_082a;
																																			case 88:
																																				goto IL_083a;
																																			case 137:
																																				goto IL_0848;
																																			case 66:
																																			case 152:
																																				goto IL_0856;
																																			case 23:
																																				goto IL_0864;
																																			case 131:
																																				goto IL_0887;
																																			case 11:
																																				goto IL_0891;
																																			case 10:
																																				goto IL_089f;
																																			case 177:
																																				goto IL_08b2;
																																			case 172:
																																			case 180:
																																				goto IL_08c5;
																																			case 107:
																																				goto IL_08ee;
																																			case 184:
																																				goto IL_08fe;
																																			case 67:
																																			case 175:
																																				goto IL_090c;
																																			case 53:
																																				goto IL_094c;
																																			case 144:
																																				goto IL_0960;
																																			case 188:
																																				goto IL_0973;
																																			case 87:
																																				goto IL_0994;
																																			case 151:
																																				goto IL_09a2;
																																			case 100:
																																				goto IL_09b5;
																																			case 61:
																																			case 79:
																																				goto IL_09c0;
																																			case 121:
																																				goto IL_0a01;
																																			case 68:
																																				goto IL_0a15;
																																			case 64:
																																				goto IL_0a28;
																																			case 20:
																																				goto IL_0a33;
																																			case 22:
																																			case 163:
																																				goto IL_0a41;
																																			case 76:
																																				goto IL_0a5a;
																																			case 157:
																																				goto IL_0a68;
																																			case 72:
																																				goto IL_0a76;
																																			case 169:
																																				goto IL_0a89;
																																			case 187:
																																				goto IL_0a97;
																																			case 105:
																																			case 168:
																																				goto IL_0aa5;
																																			case 32:
																																				goto IL_0abd;
																																			case 47:
																																				goto IL_0acb;
																																			case 4:
																																				goto IL_0ad9;
																																			case 2:
																																				goto IL_0ae4;
																																			case 93:
																																			case 154:
																																				goto IL_0af2;
																																			case 42:
																																				goto IL_0b0b;
																																			case 176:
																																				goto IL_0b19;
																																			case 159:
																																				goto IL_0b27;
																																			case 129:
																																				goto IL_0b3a;
																																			case 99:
																																				goto IL_0b48;
																																			case 8:
																																			case 156:
																																				goto IL_0b56;
																																			case 110:
																																				goto IL_0b96;
																																			case 113:
																																				goto IL_0baa;
																																			case 59:
																																			case 106:
																																				goto IL_0bc6;
																																			case 21:
																																				goto end_IL_032d;
																																			case 124:
																																				goto IL_0c19;
																																			case 104:
																																				goto IL_0c29;
																																			case 96:
																																				goto IL_0c34;
																																			case 125:
																																				goto IL_0c3f;
																																			case 182:
																																				goto IL_0c4c;
																																			case 83:
																																			case 174:
																																				goto IL_0c57;
																																			case 13:
																																			case 28:
																																			case 31:
																																			case 36:
																																			case 39:
																																			case 41:
																																			case 46:
																																			case 51:
																																			case 56:
																																			case 57:
																																			case 69:
																																			case 71:
																																			case 86:
																																			case 97:
																																			case 98:
																																			case 109:
																																			case 112:
																																			case 117:
																																			case 134:
																																			case 140:
																																			case 143:
																																			case 146:
																																			case 148:
																																			case 167:
																																			case 186:
																																				goto end_IL_0363;
																																			case 26:
																																			case 29:
																																			case 54:
																																			case 65:
																																			case 70:
																																			case 73:
																																			case 74:
																																			case 75:
																																			case 77:
																																			case 84:
																																			case 89:
																																			case 90:
																																			case 91:
																																			case 95:
																																			case 111:
																																			case 139:
																																			case 141:
																																			case 145:
																																			case 149:
																																			case 155:
																																			case 178:
																																			case 179:
																																			case 183:
																																			case 189:
																																				goto end_IL_0403;
																																			case 58:
																																				goto end_IL_0c83;
																																			case 122:
																																				goto end_IL_0c96;
																																			case 6:
																																				goto end_IL_0ca1;
																																			case 185:
																																				goto end_IL_0cab;
																																			case 35:
																																				goto end_IL_0cb6;
																																			case 142:
																																				goto end_IL_0cc6;
																																			case 38:
																																			case 181:
																																				goto end_IL_0cd6;
																																			case 33:
																																				goto end_IL_0ce6;
																																			case 34:
																																				goto end_IL_0cf6;
																																			case 14:
																																				goto end_IL_0d06;
																																			case 101:
																																				goto end_IL_0d16;
																																			case 102:
																																				goto end_IL_0d26;
																																			case 85:
																																			case 108:
																																				return;
																																			}
																																			continue;
																																		}
																																		array[num6] = 5;
																																		goto IL_0994;
																																		IL_0994:
																																		num6++;
																																		goto IL_09a2;
																																		IL_09a2:
																																		ptr2 += 8;
																																		goto end_IL_0403;
																																		continue;
																																		end_IL_032d:
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0bda;
																																continue;
																																end_IL_0363:
																																break;
																																IL_0363:;
																															}
																															break;
																															IL_0373:;
																														}
																														break;
																													}
																													goto IL_040e;
																													IL_046e:
																													num6--;
																													goto end_IL_0403;
																													IL_040e:
																													if (15 > b)
																													{
																														break;
																													}
																													goto IL_041c;
																													IL_041c:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_046e;
																												}
																												break;
																											}
																											goto IL_09b5;
																											IL_0aa5:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto end_IL_0403;
																											IL_09b5:
																											if (14 <= b)
																											{
																												goto IL_09c0;
																											}
																											goto IL_0a28;
																											IL_09c0:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																											goto IL_0a01;
																											IL_0a01:
																											array[num6 - 2] = 0;
																											goto IL_0a15;
																											IL_0a15:
																											num6--;
																											goto end_IL_0403;
																											IL_0a28:
																											if (12 >= b)
																											{
																												goto IL_0a33;
																											}
																											goto IL_0a89;
																											IL_0a33:
																											if (12 > b)
																											{
																												break;
																											}
																											goto IL_0a41;
																											IL_0a41:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																											goto IL_0a5a;
																											IL_0a5a:
																											array[num6] = 1;
																											goto IL_0a68;
																											IL_0a68:
																											num6++;
																											goto IL_0a76;
																											IL_0a76:
																											ptr2 += 16;
																											goto end_IL_0403;
																											IL_0a89:
																											if (13 < b)
																											{
																												break;
																											}
																											goto IL_0a97;
																											IL_0a97:
																											if (13 > b)
																											{
																												break;
																											}
																											goto IL_0aa5;
																										}
																										break;
																									}
																									goto IL_08c5;
																									IL_0973:
																									ptr2 += 8;
																									goto end_IL_0403;
																									IL_08c5:
																									((delegate*<Class181, void>)WmiGuidObjectConfigurationFileValue[*(int*)(ptr2 + num3)])((Class181)array2[num6 - 1]);
																									goto IL_08ee;
																									IL_08ee:
																									num6--;
																									goto IL_0973;
																								}
																								break;
																							}
																							goto IL_0abd;
																							IL_0c4c:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_0c57;
																							IL_0abd:
																							if (20 >= b)
																							{
																								goto IL_0acb;
																							}
																							goto IL_0c29;
																							IL_0acb:
																							if (20 > b)
																							{
																								goto IL_0ad9;
																							}
																							num = 59;
																							goto IL_0bc6;
																							IL_0ad9:
																							if (18 >= b)
																							{
																								goto IL_0ae4;
																							}
																							goto IL_0b3a;
																							IL_0ae4:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0af2;
																							IL_0af2:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																							goto IL_0b0b;
																							IL_0b0b:
																							array[num6] = 3;
																							goto IL_0b19;
																							IL_0b19:
																							num6++;
																							goto IL_0b27;
																							IL_0b27:
																							ptr2 += 16;
																							goto end_IL_0403;
																							IL_0b3a:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_0b48;
																							IL_0b48:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_0b56;
																							IL_0b56:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0b96;
																							IL_0b96:
																							array[num6 - 2] = 3;
																							goto IL_0baa;
																							IL_0baa:
																							num6--;
																							goto end_IL_0403;
																							IL_0c57:
																							byte* num7 = ptr2;
																							num5 = 1;
																							ptr2 = num7 + -200;
																							goto end_IL_0403;
																							IL_0bc6:
																							array[num6 - 1] = 0;
																							goto IL_0bda;
																							IL_0bda:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)WmiGuidObjectConfigurationFileValue[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_0c19;
																							IL_0c19:
																							ptr2 += 8;
																							goto end_IL_0403;
																							IL_0c29:
																							if (21 < b)
																							{
																								goto IL_0c34;
																							}
																							goto IL_0c4c;
																							IL_0c34:
																							if (22 < b)
																							{
																								break;
																							}
																							goto IL_0c3f;
																							IL_0c3f:
																							if (22 > b)
																							{
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0481;
																					IL_0664:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_06c6;
																					IL_0481:
																					if (11 <= b)
																					{
																						goto end_IL_0403;
																					}
																					goto IL_048f;
																					IL_048f:
																					if (5 >= b)
																					{
																						goto IL_049d;
																					}
																					goto IL_05a1;
																					IL_049d:
																					if (5 > b)
																					{
																						goto IL_04ab;
																					}
																					goto IL_06d9;
																					IL_04ab:
																					if (2 >= b)
																					{
																						goto IL_04b9;
																					}
																					goto IL_07e8;
																					IL_04b9:
																					if (2 <= b)
																					{
																						goto IL_04c4;
																					}
																					goto IL_053d;
																					IL_04c4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 48;
																					goto IL_050d;
																					IL_050d:
																					array[num6 - 2] = 0;
																					num = 24;
																					goto IL_052a;
																					IL_052a:
																					num6--;
																					goto end_IL_0403;
																					IL_053d:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_054b;
																					IL_054b:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_0559;
																					IL_0559:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0572;
																					IL_0572:
																					array[num6] = 0;
																					goto IL_0580;
																					IL_0580:
																					num6++;
																					goto IL_058e;
																					IL_058e:
																					ptr2 += 8;
																					goto end_IL_0403;
																					IL_07e8:
																					if (3 >= b)
																					{
																						goto IL_07f3;
																					}
																					goto IL_083a;
																					IL_07f3:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0801;
																					IL_0801:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_082a;
																					IL_082a:
																					ptr2 += 8;
																					goto IL_08b2;
																					IL_08b2:
																					num6--;
																					goto end_IL_0403;
																					IL_083a:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_0848;
																					IL_0848:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0856;
																					IL_0856:
																					array[num6] = 0;
																					goto IL_0864;
																					IL_0864:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0887;
																					IL_0887:
																					array2[num6] = null;
																					goto IL_0891;
																					IL_0891:
																					num6++;
																					goto IL_089f;
																					IL_089f:
																					ptr2 += 8;
																					goto end_IL_0403;
																					IL_06d9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0719;
																					IL_0719:
																					array[num6 - 2] = 0;
																					goto IL_072d;
																					IL_072d:
																					num6--;
																					goto end_IL_0403;
																					IL_05a1:
																					if (8 >= b)
																					{
																						goto IL_05ac;
																					}
																					goto IL_05bf;
																					IL_05ac:
																					if (8 <= b)
																					{
																						goto IL_0740;
																					}
																					goto IL_0753;
																					IL_0740:
																					num6--;
																					goto end_IL_0403;
																					IL_0753:
																					if (6 >= b)
																					{
																						goto IL_075e;
																					}
																					goto IL_07c2;
																					IL_075e:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_076c;
																					IL_076c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_07ac;
																					IL_07ac:
																					array[num6 - 2] = 0;
																					goto IL_07d5;
																					IL_07d5:
																					num6--;
																					goto end_IL_0403;
																					IL_07c2:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_08fe;
																					IL_08fe:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_090c;
																					IL_090c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_094c;
																					IL_094c:
																					array[num6 - 2] = 0;
																					goto IL_0960;
																					IL_0960:
																					num6--;
																					goto end_IL_0403;
																					IL_05bf:
																					if (9 >= b)
																					{
																						goto IL_05ca;
																					}
																					goto IL_0648;
																					IL_05ca:
																					if (9 > b)
																					{
																						break;
																					}
																					num = 118;
																					goto IL_05e1;
																					IL_06c6:
																					num6 -= 2;
																					goto end_IL_0403;
																					IL_05e1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0621;
																					IL_0621:
																					array[num6 - 2] = 0;
																					goto IL_0635;
																					IL_0635:
																					num6--;
																					goto end_IL_0403;
																					IL_0648:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0656;
																					IL_0656:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0664;
																				}
																				break;
																				IL_03d0:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_0403;
																		continue;
																		end_IL_03e0:
																		break;
																	}
																	continue;
																	end_IL_03f3:
																	break;
																}
																continue;
																end_IL_0403:
																break;
															}
															continue;
															end_IL_0c83:
															break;
														}
														continue;
														end_IL_0c96:
														break;
													}
													continue;
													end_IL_0ca1:
													break;
												}
												continue;
												end_IL_0cab:
												break;
											}
											continue;
											end_IL_0cb6:
											break;
										}
										continue;
										end_IL_0cc6:
										break;
									}
									continue;
									end_IL_0cd6:
									break;
								}
								continue;
								end_IL_0ce6:
								break;
							}
							continue;
							end_IL_0cf6:
							break;
						}
						continue;
						end_IL_0d06:
						break;
					}
					continue;
					end_IL_0d16:
					break;
				}
				continue;
				end_IL_0d26:
				break;
			}
		}
	}

	private unsafe void method_2()
	{
		int num = 66;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getNextgetImpersonationLevel.getControlEvidenceCallConvMask);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 105;
														while (true)
														{
															if (num5 != 1)
															{
																while (true)
																{
																	IL_0608:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_05f8:
																		ptr2++;
																		while (true)
																		{
																			IL_05e8:
																			if (b >= 1)
																			{
																				while (b <= 37)
																				{
																					while (true)
																					{
																						IL_05cb:
																						if (19 < b)
																						{
																							while (true)
																							{
																								IL_05bb:
																								if (28 >= b)
																								{
																									while (true)
																									{
																										IL_05ab:
																										if (28 > b)
																										{
																											while (true)
																											{
																												IL_059b:
																												if (23 < b)
																												{
																													while (true)
																													{
																														IL_058b:
																														if (25 >= b)
																														{
																															while (true)
																															{
																																IL_057b:
																																if (25 <= b)
																																{
																																	while (true)
																																	{
																																		IL_0541:
																																		array2[num6 - 1] = ((delegate*<Class181, TrailRenderer>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])((Class181)array2[num6 - 1]);
																																		while (true)
																																		{
																																			IL_052b:
																																			array[num6 - 1] = 5;
																																			while (true)
																																			{
																																				IL_0512:
																																				ptr2 += 8;
																																				num = 316;
																																				while (num != 316)
																																				{
																																					if (num != 1297)
																																					{
																																						goto IL_0a7d;
																																					}
																																					switch (num)
																																					{
																																					case 47:
																																						goto IL_0512;
																																					case 84:
																																						goto IL_052b;
																																					case 144:
																																					case 240:
																																						goto IL_0541;
																																					case 32:
																																						goto IL_057b;
																																					case 109:
																																						goto IL_058b;
																																					case 207:
																																						goto IL_059b;
																																					case 177:
																																						goto IL_05ab;
																																					case 180:
																																						goto IL_05bb;
																																					case 272:
																																						goto IL_05cb;
																																					case 49:
																																						goto IL_05d8;
																																					case 162:
																																						goto IL_05e8;
																																					case 182:
																																						goto IL_05f8;
																																					case 227:
																																					case 238:
																																						goto IL_0608;
																																					case 112:
																																						goto IL_0613;
																																					case 83:
																																						goto IL_061e;
																																					case 135:
																																						goto IL_062c;
																																					case 33:
																																					case 139:
																																						goto IL_063a;
																																					case 116:
																																						goto IL_067a;
																																					case 9:
																																					case 151:
																																						goto IL_0693;
																																					case 247:
																																						goto IL_06a2;
																																					case 62:
																																						goto IL_06b0;
																																					case 183:
																																						goto IL_06bb;
																																					case 88:
																																						goto IL_06c9;
																																					case 73:
																																						goto IL_06d7;
																																					case 125:
																																					case 230:
																																						goto IL_06ee;
																																					case 110:
																																						goto IL_0707;
																																					case 231:
																																						goto IL_0715;
																																					case 20:
																																					case 150:
																																						goto IL_0723;
																																					case 170:
																																						goto IL_0737;
																																					case 187:
																																						goto IL_0776;
																																					case 244:
																																					case 252:
																																						goto IL_0792;
																																					case 102:
																																						goto IL_07d2;
																																					case 36:
																																						goto IL_07e6;
																																					case 266:
																																						goto IL_07f9;
																																					case 155:
																																						goto IL_0807;
																																					case 273:
																																						goto IL_081a;
																																					case 85:
																																						goto IL_0828;
																																					case 108:
																																					case 164:
																																						goto IL_0836;
																																					case 117:
																																						goto IL_084a;
																																					case 128:
																																						goto IL_0889;
																																					case 269:
																																					case 280:
																																						goto IL_089c;
																																					case 249:
																																						goto IL_08b5;
																																					case 98:
																																						goto IL_08c3;
																																					case 26:
																																						goto IL_08d1;
																																					case 282:
																																						goto IL_08e4;
																																					case 219:
																																						goto IL_08f2;
																																					case 6:
																																					case 28:
																																						goto IL_08fd;
																																					case 21:
																																						goto IL_090b;
																																					case 101:
																																						goto IL_092e;
																																					case 76:
																																						goto IL_0938;
																																					case 268:
																																						goto IL_0946;
																																					case 74:
																																						goto IL_0959;
																																					case 30:
																																						goto IL_0967;
																																					case 181:
																																						goto IL_0975;
																																					case 179:
																																						goto IL_0988;
																																					case 94:
																																						goto IL_0996;
																																					case 29:
																																					case 51:
																																						goto IL_09a1;
																																					case 185:
																																						goto IL_09e1;
																																					case 232:
																																						goto IL_09f5;
																																					case 152:
																																						goto IL_0a08;
																																					case 71:
																																						goto IL_0a16;
																																					case 121:
																																					case 229:
																																						goto IL_0a24;
																																					case 193:
																																						goto IL_0a64;
																																					case 138:
																																						goto IL_0a7d;
																																					case 214:
																																						goto IL_0a88;
																																					case 19:
																																					case 38:
																																						goto IL_0a96;
																																					case 205:
																																						goto IL_0ad6;
																																					case 254:
																																						goto IL_0aea;
																																					case 194:
																																						goto IL_0afd;
																																					case 203:
																																						goto IL_0b0b;
																																					case 53:
																																					case 69:
																																						goto IL_0b19;
																																					case 285:
																																						goto IL_0b2c;
																																					case 286:
																																						goto IL_0b3f;
																																					case 176:
																																						goto IL_0b4d;
																																					case 253:
																																						goto IL_0b5b;
																																					case 16:
																																					case 158:
																																						goto IL_0b66;
																																					case 175:
																																						goto IL_0bb8;
																																					case 43:
																																						goto IL_0bcb;
																																					case 46:
																																						goto IL_0bde;
																																					case 239:
																																						goto IL_0be9;
																																					case 279:
																																						goto IL_0bf7;
																																					case 211:
																																					case 275:
																																						goto IL_0c05;
																																					case 48:
																																						goto IL_0c3d;
																																					case 77:
																																						goto IL_0c51;
																																					case 228:
																																						goto IL_0c6d;
																																					case 54:
																																					case 216:
																																						goto IL_0c7b;
																																					case 34:
																																						goto IL_0c93;
																																					case 276:
																																						goto IL_0ca1;
																																					case 265:
																																						goto IL_0caf;
																																					case 37:
																																						goto IL_0cc2;
																																					case 22:
																																					case 209:
																																						goto IL_0ccd;
																																					case 91:
																																						goto IL_0ce5;
																																					case 124:
																																						goto IL_0cf3;
																																					case 44:
																																						goto IL_0cfe;
																																					case 133:
																																						goto IL_0d0c;
																																					case 192:
																																					case 257:
																																						goto IL_0d1a;
																																					case 246:
																																						goto IL_0d33;
																																					case 200:
																																						goto IL_0d41;
																																					case 13:
																																						goto IL_0d4f;
																																					case 163:
																																						goto IL_0d62;
																																					case 288:
																																						goto IL_0d75;
																																					case 243:
																																						goto IL_0d83;
																																					case 250:
																																						goto IL_0d91;
																																					case 72:
																																					case 255:
																																						goto IL_0d9f;
																																					case 198:
																																						goto IL_0e01;
																																					case 292:
																																						goto IL_0e14;
																																					case 145:
																																					case 157:
																																						goto IL_0e22;
																																					case 100:
																																						goto IL_0e63;
																																					case 262:
																																						goto IL_0e77;
																																					case 78:
																																					case 298:
																																						goto IL_0e8a;
																																					case 234:
																																						goto IL_0eb3;
																																					case 56:
																																						goto IL_0eca;
																																					case 119:
																																					case 299:
																																						goto IL_0edd;
																																					case 0:
																																						goto IL_0ef1;
																																					case 93:
																																						goto IL_0f45;
																																					case 261:
																																						goto IL_0f53;
																																					case 300:
																																						goto IL_0f66;
																																					case 96:
																																					case 111:
																																						goto IL_0f71;
																																					case 189:
																																						goto IL_0fba;
																																					case 118:
																																						goto IL_0fd7;
																																					case 303:
																																						goto IL_0fea;
																																					case 127:
																																						goto IL_0ff8;
																																					case 60:
																																					case 291:
																																						goto IL_1006;
																																					case 215:
																																						goto IL_101f;
																																					case 156:
																																						goto IL_1036;
																																					case 165:
																																						goto IL_1044;
																																					case 304:
																																						goto IL_1057;
																																					case 141:
																																						goto IL_10a4;
																																					case 258:
																																						goto IL_10b2;
																																					case 307:
																																						goto IL_10c5;
																																					case 296:
																																						goto IL_10d8;
																																					case 123:
																																						goto IL_10e3;
																																					case 11:
																																						goto IL_10f1;
																																					case 107:
																																					case 149:
																																						goto IL_10ff;
																																					case 199:
																																						goto IL_1127;
																																					case 95:
																																						goto IL_113a;
																																					case 92:
																																					case 223:
																																						goto IL_1148;
																																					case 134:
																																						goto IL_115c;
																																					case 245:
																																						goto IL_119b;
																																					case 174:
																																					case 305:
																																						goto IL_11ae;
																																					case 140:
																																						goto IL_11ee;
																																					case 24:
																																						goto IL_120b;
																																					case 294:
																																						goto IL_121e;
																																					case 301:
																																						goto IL_122c;
																																					case 3:
																																						goto IL_123a;
																																					case 213:
																																						goto IL_1248;
																																					case 45:
																																					case 81:
																																						goto IL_1253;
																																					case 184:
																																						goto IL_1267;
																																					case 264:
																																						goto IL_12a6;
																																					case 178:
																																						goto IL_12b9;
																																					case 270:
																																						goto IL_12c7;
																																					case 79:
																																					case 130:
																																						goto IL_12d5;
																																					case 1:
																																						goto IL_12fd;
																																					case 61:
																																						goto IL_1310;
																																					case 103:
																																						goto IL_131b;
																																					case 7:
																																					case 12:
																																						goto IL_1329;
																																					case 201:
																																						goto IL_1346;
																																					case 147:
																																						goto IL_137e;
																																					case 171:
																																						goto IL_139a;
																																					case 4:
																																						goto IL_13a8;
																																					case 131:
																																					case 237:
																																						goto IL_13b6;
																																					case 89:
																																						goto IL_13df;
																																					case 31:
																																						goto IL_13ed;
																																					case 57:
																																					case 195:
																																						goto IL_1400;
																																					case 99:
																																						goto IL_1414;
																																					case 293:
																																						goto IL_1453;
																																					case 202:
																																						goto IL_1466;
																																					case 14:
																																						goto IL_1471;
																																					case 52:
																																						goto IL_147c;
																																					case 68:
																																					case 86:
																																						goto IL_148a;
																																					case 260:
																																						goto IL_14a6;
																																					case 2:
																																						goto IL_14b4;
																																					case 159:
																																						goto IL_14c7;
																																					case 263:
																																					case 274:
																																						goto IL_14d2;
																																					case 235:
																																						goto IL_14e6;
																																					case 248:
																																						goto IL_1525;
																																					case 284:
																																						goto IL_1538;
																																					case 210:
																																						goto IL_1546;
																																					case 160:
																																					case 168:
																																						goto IL_155a;
																																					case 197:
																																						goto IL_159a;
																																					case 8:
																																						goto IL_15ae;
																																					case 39:
																																					case 40:
																																					case 41:
																																					case 50:
																																					case 58:
																																					case 59:
																																					case 64:
																																					case 80:
																																					case 82:
																																					case 90:
																																					case 97:
																																					case 104:
																																					case 106:
																																					case 113:
																																					case 115:
																																					case 126:
																																					case 132:
																																					case 136:
																																					case 148:
																																					case 161:
																																					case 167:
																																					case 169:
																																					case 190:
																																					case 204:
																																					case 208:
																																					case 224:
																																					case 226:
																																					case 241:
																																					case 242:
																																					case 256:
																																					case 267:
																																					case 271:
																																					case 277:
																																					case 278:
																																					case 290:
																																					case 295:
																																					case 302:
																																					case 306:
																																					case 308:
																																					case 309:
																																						goto end_IL_05d8;
																																					case 5:
																																					case 10:
																																					case 15:
																																					case 17:
																																					case 23:
																																					case 25:
																																					case 42:
																																					case 63:
																																					case 67:
																																					case 87:
																																					case 105:
																																					case 114:
																																					case 120:
																																					case 129:
																																					case 137:
																																					case 142:
																																					case 146:
																																					case 153:
																																					case 154:
																																					case 166:
																																					case 172:
																																					case 173:
																																					case 186:
																																					case 191:
																																					case 196:
																																					case 206:
																																					case 212:
																																					case 217:
																																					case 218:
																																					case 221:
																																					case 222:
																																					case 225:
																																					case 233:
																																					case 236:
																																					case 251:
																																					case 259:
																																					case 281:
																																					case 297:
																																						goto end_IL_04ff;
																																					case 18:
																																						goto end_IL_15e3;
																																					case 55:
																																						goto end_IL_15f6;
																																					case 220:
																																						goto end_IL_1601;
																																					case 122:
																																						goto end_IL_160b;
																																					case 283:
																																						goto end_IL_1616;
																																					case 188:
																																						goto end_IL_1626;
																																					case 75:
																																					case 289:
																																						goto end_IL_1636;
																																					case 35:
																																						goto end_IL_1646;
																																					case 143:
																																						goto end_IL_1656;
																																					case 70:
																																						goto end_IL_1666;
																																					case 65:
																																						goto end_IL_1676;
																																					case 66:
																																						goto end_IL_1686;
																																					case 27:
																																					case 287:
																																						return;
																																					}
																																					continue;
																																					end_IL_04ff:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_081a;
																																IL_0889:
																																ptr2 += 8;
																																break;
																																IL_081a:
																																if (24 < b)
																																{
																																	goto end_IL_05d8;
																																}
																																goto IL_0828;
																																IL_0828:
																																if (24 > b)
																																{
																																	goto end_IL_05d8;
																																}
																																goto IL_0836;
																																IL_0836:
																																array[num6 - 1] = 0;
																																goto IL_084a;
																																IL_084a:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																																goto IL_0889;
																															}
																															break;
																														}
																														goto IL_10d8;
																														IL_119b:
																														ptr2 += 8;
																														break;
																														IL_10d8:
																														if (26 < b)
																														{
																															goto IL_10e3;
																														}
																														goto IL_113a;
																														IL_10e3:
																														if (27 < b)
																														{
																															goto end_IL_05d8;
																														}
																														goto IL_10f1;
																														IL_10f1:
																														if (27 > b)
																														{
																															goto end_IL_05d8;
																														}
																														goto IL_10ff;
																														IL_10ff:
																														((Class181)array2[num6 - 2]).trailRenderer_0 = (TrailRenderer)array2[num6 - 1];
																														goto IL_1127;
																														IL_1127:
																														num6 -= 2;
																														break;
																														IL_113a:
																														if (26 > b)
																														{
																															goto end_IL_05d8;
																														}
																														goto IL_1148;
																														IL_1148:
																														array[num6 - 1] = 3;
																														goto IL_115c;
																														IL_115c:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																														goto IL_119b;
																													}
																													break;
																												}
																												goto IL_06a2;
																												IL_07d2:
																												array[num6 - 2] = 3;
																												goto IL_07e6;
																												IL_06a2:
																												if (23 > b)
																												{
																													goto IL_06b0;
																												}
																												goto IL_0792;
																												IL_06b0:
																												if (21 >= b)
																												{
																													goto IL_06bb;
																												}
																												goto IL_0707;
																												IL_06bb:
																												if (21 > b)
																												{
																													goto IL_06c9;
																												}
																												goto IL_089c;
																												IL_06c9:
																												if (20 < b)
																												{
																													goto end_IL_05d8;
																												}
																												goto IL_06d7;
																												IL_06d7:
																												if (20 > b)
																												{
																													goto end_IL_05d8;
																												}
																												num = 230;
																												goto IL_06ee;
																												IL_07e6:
																												num6--;
																												break;
																												IL_06ee:
																												array[num6 - 2] = 0;
																												goto IL_1057;
																												IL_1057:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])((TrailRenderer)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																												goto IL_10a4;
																												IL_10a4:
																												num6--;
																												goto IL_10b2;
																												IL_10b2:
																												ptr2 += 8;
																												break;
																												IL_089c:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																												goto IL_08b5;
																												IL_08b5:
																												array[num6] = 3;
																												goto IL_08c3;
																												IL_08c3:
																												num6++;
																												goto IL_08d1;
																												IL_08d1:
																												ptr2 += 16;
																												break;
																												IL_0707:
																												if (22 < b)
																												{
																													goto end_IL_05d8;
																												}
																												goto IL_0715;
																												IL_0715:
																												if (22 > b)
																												{
																													goto end_IL_05d8;
																												}
																												goto IL_0723;
																												IL_0723:
																												array[num6 - 1] = 3;
																												goto IL_0737;
																												IL_0737:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																												goto IL_0776;
																												IL_0776:
																												ptr2 += 8;
																												num = 236;
																												break;
																												IL_0792:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_07d2;
																											}
																											break;
																										}
																										goto IL_11ae;
																										IL_120b:
																										num6--;
																										break;
																										IL_11ae:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_11ee;
																										IL_11ee:
																										array[num6 - 2] = 3;
																										num = 24;
																										goto IL_120b;
																									}
																									break;
																								}
																								goto IL_121e;
																								IL_159a:
																								array[num6 - 2] = 3;
																								goto IL_15ae;
																								IL_121e:
																								if (33 >= b)
																								{
																									goto IL_122c;
																								}
																								goto IL_1466;
																								IL_122c:
																								if (33 > b)
																								{
																									goto IL_123a;
																								}
																								goto IL_1400;
																								IL_123a:
																								if (30 >= b)
																								{
																									goto IL_1248;
																								}
																								goto IL_1310;
																								IL_1248:
																								if (30 <= b)
																								{
																									goto IL_1253;
																								}
																								goto IL_12b9;
																								IL_1253:
																								array[num6 - 1] = 3;
																								goto IL_1267;
																								IL_1267:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_12a6;
																								IL_12a6:
																								ptr2 += 8;
																								break;
																								IL_12b9:
																								if (29 < b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_12c7;
																								IL_12c7:
																								if (29 > b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_12d5;
																								IL_12d5:
																								((Class181)array2[num6 - 2]).trailRenderer_1 = (TrailRenderer)array2[num6 - 1];
																								goto IL_12fd;
																								IL_12fd:
																								num6 -= 2;
																								break;
																								IL_1310:
																								if (31 >= b)
																								{
																									goto IL_131b;
																								}
																								goto IL_139a;
																								IL_131b:
																								if (31 > b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_1329;
																								IL_1329:
																								array[num6 - 1] = 5;
																								num = 201;
																								goto IL_1346;
																								IL_1346:
																								array2[num6 - 1] = ((delegate*<Component, GameObject>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])((TrailRenderer)array2[num6 - 1]);
																								goto IL_137e;
																								IL_137e:
																								ptr2 += 8;
																								num = 142;
																								break;
																								IL_139a:
																								if (32 < b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_13a8;
																								IL_13a8:
																								if (32 > b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_13b6;
																								IL_13b6:
																								((delegate*<UnityEngine.Object, void>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																								goto IL_13df;
																								IL_13df:
																								num6--;
																								goto IL_13ed;
																								IL_13ed:
																								ptr2 += 8;
																								break;
																								IL_1400:
																								array[num6 - 1] = 3;
																								goto IL_1414;
																								IL_1414:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_1453;
																								IL_1453:
																								ptr2 += 8;
																								break;
																								IL_1466:
																								if (35 < b)
																								{
																									goto IL_1471;
																								}
																								goto IL_14c7;
																								IL_1471:
																								if (36 >= b)
																								{
																									goto IL_147c;
																								}
																								goto IL_14a6;
																								IL_147c:
																								if (36 > b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_148a;
																								IL_148a:
																								byte* num7 = ptr2;
																								num5 = 1;
																								ptr2 = num7 + -200;
																								break;
																								IL_14a6:
																								if (37 < b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_14b4;
																								IL_14b4:
																								if (37 <= b)
																								{
																								}
																								goto end_IL_05d8;
																								IL_14c7:
																								if (35 <= b)
																								{
																									goto IL_14d2;
																								}
																								goto IL_1538;
																								IL_14d2:
																								array[num6 - 1] = 3;
																								goto IL_14e6;
																								IL_14e6:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_1525;
																								IL_1525:
																								ptr2 += 8;
																								break;
																								IL_1538:
																								if (34 < b)
																								{
																									goto end_IL_05d8;
																								}
																								goto IL_1546;
																								IL_1546:
																								if (34 > b)
																								{
																									goto end_IL_05d8;
																								}
																								num = 168;
																								goto IL_155a;
																								IL_15ae:
																								num6--;
																								num = 166;
																								break;
																								IL_155a:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_159a;
																							}
																							break;
																						}
																						goto IL_0613;
																						IL_07f9:
																						array[num6] = 5;
																						goto IL_0807;
																						IL_0613:
																						if (19 > b)
																						{
																							goto IL_061e;
																						}
																						goto IL_0693;
																						IL_061e:
																						if (9 >= b)
																						{
																							goto IL_062c;
																						}
																						goto IL_0b3f;
																						IL_062c:
																						if (9 <= b)
																						{
																							goto IL_063a;
																						}
																						goto IL_08e4;
																						IL_063a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_067a;
																						IL_067a:
																						array[num6 - 2] = 0;
																						goto IL_0b2c;
																						IL_0b2c:
																						num6--;
																						break;
																						IL_08e4:
																						if (4 >= b)
																						{
																							goto IL_08f2;
																						}
																						goto IL_0988;
																						IL_08f2:
																						if (4 <= b)
																						{
																							goto IL_08fd;
																						}
																						goto IL_0959;
																						IL_08fd:
																						array[num6] = 0;
																						goto IL_090b;
																						IL_090b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_092e;
																						IL_092e:
																						array2[num6] = null;
																						goto IL_0938;
																						IL_0938:
																						num6++;
																						goto IL_0946;
																						IL_0946:
																						ptr2 += 8;
																						break;
																						IL_0959:
																						if (2 < b)
																						{
																							goto IL_0967;
																						}
																						goto IL_0f66;
																						IL_0967:
																						if (3 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0975;
																						IL_0975:
																						if (3 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0e8a;
																						IL_0e8a:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0eb3;
																						IL_0eb3:
																						ptr2 += 8;
																						num = 56;
																						goto IL_0eca;
																						IL_0eca:
																						num6--;
																						break;
																						IL_0f66:
																						if (2 <= b)
																						{
																							goto IL_0f71;
																						}
																						goto IL_0fea;
																						IL_0f71:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						num = 189;
																						goto IL_0fba;
																						IL_0fba:
																						array[num6 - 2] = 0;
																						num = 118;
																						goto IL_0fd7;
																						IL_0fd7:
																						num6--;
																						break;
																						IL_0fea:
																						if (1 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0ff8;
																						IL_0ff8:
																						if (1 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_1006;
																						IL_1006:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_101f;
																						IL_101f:
																						array[num6] = 0;
																						num = 156;
																						goto IL_1036;
																						IL_1036:
																						num6++;
																						goto IL_1044;
																						IL_1044:
																						ptr2 += 8;
																						break;
																						IL_0988:
																						if (6 >= b)
																						{
																							goto IL_0996;
																						}
																						goto IL_0a7d;
																						IL_0996:
																						if (6 <= b)
																						{
																							goto IL_09a1;
																						}
																						goto IL_0a08;
																						IL_09a1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_09e1;
																						IL_09e1:
																						array[num6 - 2] = 0;
																						goto IL_09f5;
																						IL_09f5:
																						num6--;
																						break;
																						IL_0a08:
																						if (5 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0a16;
																						IL_0a16:
																						if (5 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0a24;
																						IL_0a24:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0a64;
																						IL_0a64:
																						array[num6 - 2] = 0;
																						goto IL_10c5;
																						IL_10c5:
																						num6--;
																						break;
																						IL_0a7d:
																						if (7 >= b)
																						{
																							goto IL_0a88;
																						}
																						goto IL_0afd;
																						IL_0a88:
																						if (7 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0a96;
																						IL_0a96:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0ad6;
																						IL_0ad6:
																						array[num6 - 2] = 0;
																						goto IL_0aea;
																						IL_0aea:
																						num6--;
																						break;
																						IL_0afd:
																						if (8 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0b0b;
																						IL_0b0b:
																						if (8 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0b19;
																						IL_0b19:
																						num6--;
																						break;
																						IL_0b3f:
																						if (14 < b)
																						{
																							goto IL_0b4d;
																						}
																						goto IL_0cc2;
																						IL_0b4d:
																						if (16 >= b)
																						{
																							goto IL_0b5b;
																						}
																						goto IL_0bde;
																						IL_0b5b:
																						if (16 <= b)
																						{
																							goto IL_0b66;
																						}
																						goto IL_0bcb;
																						IL_0b66:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0bb8;
																						IL_0bb8:
																						num6--;
																						break;
																						IL_0bcb:
																						if (15 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0e14;
																						IL_0e14:
																						if (15 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0e22;
																						IL_0e22:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_0e63;
																						IL_0e63:
																						array[num6 - 2] = 0;
																						goto IL_0e77;
																						IL_0e77:
																						num6--;
																						break;
																						IL_0bde:
																						if (17 < b)
																						{
																							goto IL_0be9;
																						}
																						num = 228;
																						goto IL_0c6d;
																						IL_0be9:
																						if (18 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0bf7;
																						IL_0bf7:
																						if (18 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0c05;
																						IL_0c05:
																						array2[num6 - 1] = ((delegate*<Class181, TrailRenderer>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])((Class181)array2[num6 - 1]);
																						goto IL_0c3d;
																						IL_0c3d:
																						array[num6 - 1] = 5;
																						goto IL_0c51;
																						IL_0c51:
																						ptr2 += 8;
																						break;
																						IL_0807:
																						num6++;
																						break;
																						IL_0c6d:
																						if (17 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0c7b;
																						IL_0c7b:
																						array2[num6] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0c93;
																						IL_0c93:
																						array[num6] = 5;
																						goto IL_0ca1;
																						IL_0ca1:
																						num6++;
																						goto IL_0caf;
																						IL_0caf:
																						ptr2 += 8;
																						break;
																						IL_0cc2:
																						if (14 <= b)
																						{
																							goto IL_0ccd;
																						}
																						goto IL_0ce5;
																						IL_0ccd:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_0ce5:
																						if (11 < b)
																						{
																							goto IL_0cf3;
																						}
																						goto IL_0d75;
																						IL_0cf3:
																						if (12 < b)
																						{
																							goto IL_0cfe;
																						}
																						goto IL_0d62;
																						IL_0cfe:
																						if (13 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0d0c;
																						IL_0d0c:
																						if (13 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0d1a;
																						IL_0d1a:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0d33;
																						IL_0d33:
																						array[num6] = 1;
																						goto IL_0d41;
																						IL_0d41:
																						num6++;
																						goto IL_0d4f;
																						IL_0d4f:
																						ptr2 += 16;
																						break;
																						IL_0d62:
																						if (12 > b)
																						{
																							goto end_IL_05d8;
																						}
																						break;
																						IL_0d75:
																						if (11 > b)
																						{
																							goto IL_0d83;
																						}
																						goto IL_0edd;
																						IL_0d83:
																						if (10 < b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0d91;
																						IL_0d91:
																						if (10 > b)
																						{
																							goto end_IL_05d8;
																						}
																						goto IL_0d9f;
																						IL_0d9f:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0e01;
																						IL_0e01:
																						num6 -= 2;
																						break;
																						IL_0edd:
																						array[num6 - 2] = 0;
																						goto IL_0ef1;
																						IL_0ef1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)CLAIMSECURITYATTRIBUTEVCData[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0f45;
																						IL_0f45:
																						num6--;
																						goto IL_0f53;
																						IL_0f53:
																						ptr2 += 8;
																						break;
																						IL_0693:
																						array2[num6] = null;
																						goto IL_07f9;
																					}
																					goto end_IL_05e8;
																					continue;
																					end_IL_05d8:
																					break;
																					IL_05d8:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 251;
																			break;
																			continue;
																			end_IL_05e8:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
															}
															num = 287;
															return;
															continue;
															end_IL_15e3:
															break;
														}
														continue;
														end_IL_15f6:
														break;
													}
													continue;
													end_IL_1601:
													break;
												}
												continue;
												end_IL_160b:
												break;
											}
											continue;
											end_IL_1616:
											break;
										}
										continue;
										end_IL_1626:
										break;
									}
									continue;
									end_IL_1636:
									break;
								}
								continue;
								end_IL_1646:
								break;
							}
							continue;
							end_IL_1656:
							break;
						}
						continue;
						end_IL_1666:
						break;
					}
					continue;
					end_IL_1676:
					break;
				}
				continue;
				end_IL_1686:
				break;
			}
		}
	}

	public Class181()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_0)
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnumeratorToIteratorAdapterUSEnglish.WindowsRuntimeMarshalProduct);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_027b:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_025b:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_024b:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_023b:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_022e:
																									if (2 <= b)
																									{
																										while (true)
																										{
																											IL_0203:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											while (true)
																											{
																												IL_01ea:
																												ptr2 += 8;
																												num = 114;
																												while (true)
																												{
																													if (num != 114)
																													{
																														if (num != 1095)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 82:
																															goto IL_01ea;
																														case 25:
																														case 95:
																															goto IL_0203;
																														case 80:
																															goto IL_022e;
																														case 34:
																														case 89:
																															goto IL_023b;
																														case 16:
																															goto IL_024b;
																														case 40:
																															goto IL_025b;
																														case 18:
																															goto IL_026b;
																														case 50:
																															goto IL_027b;
																														case 12:
																															goto end_IL_027b;
																														case 21:
																														case 104:
																															goto end_IL_028b;
																														case 55:
																														case 63:
																															goto IL_02a6;
																														case 10:
																															goto IL_02b4;
																														case 28:
																														case 65:
																															goto IL_02cd;
																														case 8:
																															goto IL_02d8;
																														case 66:
																															goto IL_02e6;
																														case 53:
																														case 99:
																															goto IL_02f9;
																														case 60:
																															goto IL_0312;
																														case 98:
																															goto IL_0320;
																														case 91:
																															goto IL_032e;
																														case 100:
																															goto IL_0341;
																														case 0:
																														case 105:
																															goto IL_034f;
																														case 42:
																														case 75:
																															goto IL_037a;
																														case 97:
																															goto IL_0388;
																														case 39:
																															goto IL_03ab;
																														case 38:
																															goto IL_03b5;
																														case 7:
																															goto IL_03cc;
																														case 11:
																															goto IL_03df;
																														case 20:
																														case 49:
																															goto IL_03ea;
																														case 13:
																														case 45:
																															goto IL_03f5;
																														case 70:
																															goto IL_0403;
																														case 71:
																															goto IL_0416;
																														case 6:
																														case 47:
																															goto IL_0424;
																														case 4:
																															goto IL_0440;
																														case 29:
																														case 81:
																															goto IL_044e;
																														case 17:
																														case 59:
																															goto IL_045c;
																														case 68:
																															goto IL_0473;
																														case 27:
																														case 61:
																															goto IL_0481;
																														case 52:
																															goto IL_04a4;
																														case 102:
																															goto IL_04bb;
																														case 58:
																															goto IL_04c9;
																														case 83:
																															goto IL_04dc;
																														case 37:
																														case 54:
																															goto IL_04ea;
																														case 2:
																															goto IL_052a;
																														case 48:
																															goto IL_053e;
																														case 19:
																														case 62:
																															goto IL_0551;
																														case 88:
																															goto IL_05b3;
																														case 5:
																														case 14:
																														case 15:
																														case 22:
																														case 23:
																														case 26:
																														case 33:
																														case 43:
																														case 46:
																														case 64:
																														case 69:
																														case 72:
																														case 76:
																														case 85:
																														case 92:
																														case 93:
																														case 94:
																														case 101:
																														case 103:
																														case 107:
																															goto end_IL_01d7;
																														case 1:
																														case 3:
																														case 9:
																														case 30:
																														case 35:
																														case 41:
																														case 44:
																														case 51:
																														case 67:
																														case 73:
																														case 74:
																														case 86:
																														case 96:
																															goto end_IL_029b;
																														case 56:
																															goto end_IL_05df;
																														case 90:
																															goto end_IL_05f2;
																														case 106:
																															goto end_IL_05fc;
																														case 84:
																															goto end_IL_0607;
																														case 24:
																														case 36:
																															goto end_IL_061c;
																														case 32:
																															goto end_IL_062c;
																														case 57:
																														case 79:
																															goto end_IL_063c;
																														case 77:
																															goto end_IL_064c;
																														case 78:
																															goto end_IL_065c;
																														case 31:
																														case 87:
																															goto IL_0677;
																														}
																														continue;
																													}
																													num5--;
																													goto end_IL_029b;
																													continue;
																													end_IL_01d7:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_02a6;
																									IL_0320:
																									num5++;
																									goto IL_032e;
																									IL_02a6:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_02b4;
																									IL_02b4:
																									if (1 > b)
																									{
																										num = 33;
																										break;
																									}
																									goto IL_02f9;
																									IL_032e:
																									ptr2 += 8;
																									goto end_IL_029b;
																									IL_02f9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0312;
																									IL_0312:
																									array[num5] = 0;
																									goto IL_0320;
																								}
																								break;
																							}
																							goto IL_02cd;
																							IL_034f:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_029b;
																							IL_02cd:
																							if (3 < b)
																							{
																								goto IL_02d8;
																							}
																							goto IL_0341;
																							IL_02d8:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_02e6;
																							IL_02e6:
																							if (4 <= b)
																							{
																								goto end_IL_029b;
																							}
																							break;
																							IL_0341:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_034f;
																						}
																						break;
																					}
																					goto IL_037a;
																					IL_03cc:
																					ptr2 += 8;
																					goto end_IL_029b;
																					IL_037a:
																					array[num5] = 0;
																					goto IL_0388;
																					IL_0388:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03ab;
																					IL_03ab:
																					array2[num5] = null;
																					goto IL_03b5;
																					IL_03b5:
																					num5++;
																					num = 7;
																					goto IL_03cc;
																				}
																				break;
																			}
																			goto IL_03df;
																			IL_0551:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05b3;
																			IL_03df:
																			if (8 < b)
																			{
																				goto IL_03ea;
																			}
																			goto IL_0440;
																			IL_03ea:
																			if (9 < b)
																			{
																				goto IL_03f5;
																			}
																			goto IL_0416;
																			IL_03f5:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0403;
																			IL_0403:
																			if (10 > b)
																			{
																			}
																			break;
																			IL_0416:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0424;
																			IL_0424:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_029b;
																			IL_0440:
																			if (8 > b)
																			{
																				goto IL_044e;
																			}
																			goto IL_0551;
																			IL_044e:
																			if (6 < b)
																			{
																				goto IL_045c;
																			}
																			goto IL_04dc;
																			IL_045c:
																			if (7 < b)
																			{
																				break;
																			}
																			num = 68;
																			goto IL_0473;
																			IL_05b3:
																			num5 -= 2;
																			goto end_IL_029b;
																			IL_0473:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0481;
																			IL_0481:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04a4;
																			IL_04a4:
																			array[num5] = 0;
																			num = 102;
																			goto IL_04bb;
																			IL_04bb:
																			num5++;
																			goto IL_04c9;
																			IL_04c9:
																			ptr2 += 8;
																			goto end_IL_029b;
																			IL_04dc:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_04ea;
																			IL_04ea:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_052a;
																			IL_052a:
																			array[num5 - 2] = 0;
																			goto IL_053e;
																			IL_053e:
																			num5--;
																			goto end_IL_029b;
																		}
																		break;
																		IL_026b:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 41;
																goto end_IL_029b;
																continue;
																end_IL_027b:
																break;
															}
															continue;
															end_IL_028b:
															break;
														}
														continue;
														end_IL_029b:
														break;
													}
													continue;
												}
												goto IL_0677;
												IL_0677:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05df:
												break;
											}
											continue;
											end_IL_05f2:
											break;
										}
										continue;
										end_IL_05fc:
										break;
									}
									continue;
									end_IL_0607:
									break;
								}
								continue;
								end_IL_061c:
								break;
							}
							continue;
							end_IL_062c:
							break;
						}
						continue;
						end_IL_063c:
						break;
					}
					continue;
					end_IL_064c:
					break;
				}
				continue;
				end_IL_065c:
				break;
			}
		}
	}

	private static int smethod_1(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		num += num2;
		int num3 = num;
		num = int_0;
		num2 = int_1;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 276;
		num2 = 92;
		return num + 92;
	}

	private unsafe static int smethod_2(int int_0, int int_1)
	{
		int num = 5;
		long[] array4 = default(long[]);
		byte b = default(byte);
		int num4 = default(int);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							num = 131;
							while (true)
							{
								if (num != 131)
								{
									if (num != 1112)
									{
										goto IL_02cd;
									}
									switch (num)
									{
									case 17:
									case 122:
										goto end_IL_021b;
									case 80:
										goto end_IL_022b;
									case 48:
									case 90:
										goto end_IL_0244;
									case 4:
										goto end_IL_0254;
									case 5:
										goto end_IL_0264;
									case 92:
										goto IL_028d;
									case 46:
										goto IL_02a0;
									case 123:
										goto IL_02bc;
									case 51:
										goto IL_02c5;
									case 1:
									case 8:
									case 38:
									case 41:
									case 50:
									case 52:
									case 73:
									case 77:
									case 86:
									case 87:
									case 89:
									case 105:
									case 107:
									case 110:
									case 124:
										goto IL_02cd;
									case 44:
										goto IL_02dd;
									case 11:
										goto IL_02e6;
									case 3:
										goto IL_02ef;
									case 54:
										goto IL_02fd;
									case 95:
										goto IL_030b;
									case 114:
										goto IL_0324;
									case 13:
										goto IL_0332;
									case 49:
										goto IL_033d;
									case 2:
										goto IL_034b;
									case 33:
									case 102:
										goto IL_0356;
									case 111:
										goto IL_0396;
									case 88:
										goto IL_03aa;
									case 79:
										goto IL_03c6;
									case 68:
										goto IL_03d1;
									case 19:
										goto IL_03e4;
									case 21:
										goto IL_03fb;
									case 7:
									case 30:
										goto IL_0409;
									case 71:
										goto IL_0477;
									case 28:
										goto IL_048a;
									case 109:
										goto IL_0495;
									case 12:
									case 58:
										goto IL_04a3;
									case 47:
										goto IL_04cc;
									case 62:
										goto IL_04da;
									case 78:
									case 118:
										goto IL_04ed;
									case 23:
										goto IL_04fb;
									case 27:
									case 67:
										goto IL_0512;
									case 85:
										goto IL_052a;
									case 43:
									case 74:
										goto IL_0538;
									case 31:
										goto IL_0546;
									case 29:
									case 112:
										goto IL_0554;
									case 24:
										goto IL_056d;
									case 34:
									case 104:
										goto IL_057b;
									case 63:
										goto IL_058f;
									case 103:
										goto IL_05e3;
									case 72:
										goto IL_05f1;
									case 0:
									case 115:
										goto IL_0604;
									case 37:
									case 117:
										goto IL_0617;
									case 76:
										goto IL_0630;
									case 101:
									case 106:
										goto IL_063e;
									case 97:
										goto IL_065a;
									case 35:
									case 61:
										goto IL_0665;
									case 42:
										goto IL_06a5;
									case 18:
										goto IL_06b9;
									case 82:
										goto IL_06cc;
									case 57:
										goto IL_06d7;
									case 39:
									case 56:
										goto IL_06e5;
									case 40:
										goto IL_06f3;
									case 14:
										goto IL_0716;
									case 93:
										goto IL_0720;
									case 25:
										goto IL_072e;
									case 65:
										goto IL_0741;
									case 116:
										goto IL_074f;
									case 69:
									case 75:
										goto IL_075d;
									case 81:
										goto IL_0776;
									case 32:
										goto IL_0784;
									case 66:
										goto IL_0792;
									case 94:
										goto IL_07a5;
									case 10:
										goto IL_07bc;
									case 91:
										goto IL_07ca;
									case 6:
									case 9:
									case 15:
									case 16:
									case 22:
									case 26:
									case 36:
									case 45:
									case 53:
									case 55:
									case 59:
									case 60:
									case 64:
									case 83:
									case 84:
									case 96:
									case 98:
									case 99:
									case 100:
									case 108:
									case 113:
									case 119:
									case 120:
									case 121:
										goto IL_07e6;
									case 20:
									case 70:
										goto IL_0814;
									}
									continue;
								}
								array4 = new long[4];
								goto IL_028d;
								IL_074f:
								if (8 <= b)
								{
									goto IL_075d;
								}
								goto IL_07e6;
								IL_0776:
								array[num4] = 0;
								goto IL_0784;
								IL_075d:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
								goto IL_0776;
								IL_028d:
								array3[0] = int_0;
								goto IL_02a0;
								IL_02a0:
								array3[1] = int_1;
								num = 123;
								goto IL_02bc;
								IL_02bc:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FNonBrowsableRaiseMethod.VarArgMethodResourceManagerMediator);
								goto IL_02c5;
								IL_02c5:
								ptr = ptr2;
								goto IL_02cd;
								IL_02cd:
								if (num5 != 1)
								{
									goto IL_02dd;
								}
								num = 70;
								goto IL_0814;
								IL_0784:
								num4++;
								goto IL_0792;
								IL_0814:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								IL_02dd:
								num = 11;
								goto IL_02e6;
								IL_02e6:
								b = *ptr;
								goto IL_02ef;
								IL_02ef:
								ptr++;
								goto IL_02fd;
								IL_02fd:
								if (b >= 1)
								{
									goto IL_030b;
								}
								goto IL_07e6;
								IL_030b:
								if (b <= 12)
								{
									goto IL_0324;
								}
								num = 100;
								goto IL_07e6;
								IL_0792:
								ptr += 8;
								goto IL_02cd;
								IL_0324:
								if (6 >= b)
								{
									goto IL_0332;
								}
								goto IL_052a;
								IL_0332:
								if (6 <= b)
								{
									goto IL_02cd;
								}
								goto IL_033d;
								IL_033d:
								if (3 >= b)
								{
									goto IL_034b;
								}
								goto IL_048a;
								IL_034b:
								if (3 <= b)
								{
									goto IL_0356;
								}
								goto IL_03c6;
								IL_0356:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0396;
								IL_0396:
								array[num4 - 2] = 0;
								goto IL_03aa;
								IL_03aa:
								num4--;
								num = 107;
								goto IL_02cd;
								IL_03c6:
								if (1 >= b)
								{
									goto IL_03d1;
								}
								goto IL_03e4;
								IL_03d1:
								if (1 > b)
								{
								}
								goto IL_07e6;
								IL_03e4:
								if (2 >= b)
								{
									num = 21;
									goto IL_03fb;
								}
								goto IL_07e6;
								IL_07e6:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_07a5;
								IL_03fb:
								if (2 <= b)
								{
									goto IL_0409;
								}
								goto IL_07e6;
								IL_0409:
								ptr = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
								goto IL_0477;
								IL_0477:
								num4 -= 2;
								goto IL_02cd;
								IL_048a:
								if (4 >= b)
								{
									goto IL_0495;
								}
								goto IL_04ed;
								IL_0495:
								if (4 <= b)
								{
									goto IL_04a3;
								}
								goto IL_07e6;
								IL_04a3:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_04cc;
								IL_04cc:
								ptr += 8;
								goto IL_04da;
								IL_04da:
								num4--;
								goto IL_02cd;
								IL_04ed:
								if (5 >= b)
								{
									goto IL_04fb;
								}
								goto IL_07e6;
								IL_04fb:
								if (5 <= b)
								{
									num = 67;
									goto IL_0512;
								}
								goto IL_07e6;
								IL_07a5:
								array[num4] = 0;
								num = 10;
								goto IL_07bc;
								IL_0512:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_02cd;
								IL_052a:
								if (9 < b)
								{
									goto IL_0538;
								}
								goto IL_065a;
								IL_0538:
								if (11 >= b)
								{
									goto IL_0546;
								}
								goto IL_0617;
								IL_0546:
								if (11 > b)
								{
									goto IL_0554;
								}
								goto IL_0604;
								IL_0554:
								if (10 >= b)
								{
									goto IL_056d;
								}
								num = 96;
								goto IL_07e6;
								IL_07bc:
								num4++;
								goto IL_07ca;
								IL_056d:
								if (10 <= b)
								{
									goto IL_057b;
								}
								goto IL_07e6;
								IL_057b:
								array[num4 - 2] = 0;
								goto IL_058f;
								IL_058f:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((delegate*<int, int, int>)IClrStrongNameUsingIntPtrIsNullOrWhiteSpace[*(int*)(ptr + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
								goto IL_05e3;
								IL_05e3:
								num4--;
								goto IL_05f1;
								IL_05f1:
								ptr += 8;
								goto IL_02cd;
								IL_0604:
								num4--;
								goto IL_02cd;
								IL_0617:
								if (12 >= b)
								{
									goto IL_0630;
								}
								num = 45;
								goto IL_07e6;
								IL_07ca:
								ptr += 8;
								num = 50;
								goto IL_02cd;
								IL_0630:
								if (12 <= b)
								{
									goto IL_063e;
								}
								goto IL_07e6;
								IL_063e:
								byte* num6 = ptr;
								num5 = 1;
								ptr = num6 + -200;
								goto IL_02cd;
								IL_065a:
								if (9 <= b)
								{
									goto IL_0665;
								}
								goto IL_06cc;
								IL_0665:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_06a5;
								IL_06a5:
								array[num4 - 2] = 0;
								goto IL_06b9;
								IL_06b9:
								num4--;
								goto IL_02cd;
								IL_06cc:
								if (7 >= b)
								{
									goto IL_06d7;
								}
								goto IL_0741;
								IL_06d7:
								if (7 <= b)
								{
									goto IL_06e5;
								}
								goto IL_07e6;
								IL_06e5:
								array[num4] = 0;
								goto IL_06f3;
								IL_06f3:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_0716;
								IL_0716:
								array2[num4] = null;
								goto IL_0720;
								IL_0720:
								num4++;
								goto IL_072e;
								IL_072e:
								ptr += 8;
								goto IL_02cd;
								IL_0741:
								if (8 >= b)
								{
									goto IL_074f;
								}
								goto IL_07e6;
								continue;
								end_IL_021b:
								break;
							}
							continue;
							end_IL_022b:
							break;
						}
						continue;
						end_IL_0244:
						break;
					}
					continue;
					end_IL_0254:
					break;
				}
				continue;
				end_IL_0264:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_0)
	{
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 75;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsSymboltpQuantum.GetActivationFactorygetMaxSize);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02bd:
														byte b = *ptr2;
														while (true)
														{
															IL_02ad:
															ptr2++;
															while (true)
															{
																IL_029d:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_027d:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_026d:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0260:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0250:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											while (8 <= b)
																											{
																												while (true)
																												{
																													IL_0202:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													num = 120;
																													while (true)
																													{
																														if (num != 120)
																														{
																															if (num != 1101)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 53:
																															case 76:
																																goto IL_0202;
																															case 18:
																																goto IL_0230;
																															case 11:
																															case 48:
																																goto IL_0240;
																															case 106:
																																goto IL_0250;
																															case 60:
																																goto IL_0260;
																															case 17:
																															case 67:
																																goto IL_026d;
																															case 9:
																																goto IL_027d;
																															case 88:
																																goto IL_028d;
																															case 84:
																																goto IL_029d;
																															case 90:
																																goto IL_02ad;
																															case 65:
																															case 108:
																																goto IL_02bd;
																															case 27:
																															case 66:
																																goto IL_02c8;
																															case 39:
																																goto IL_032a;
																															case 101:
																																goto IL_033d;
																															case 34:
																															case 40:
																																goto IL_034b;
																															case 68:
																																goto IL_038b;
																															case 32:
																																goto IL_039f;
																															case 35:
																																goto IL_03c0;
																															case 86:
																																goto IL_03ce;
																															case 79:
																																goto IL_03e1;
																															case 10:
																																goto IL_03ec;
																															case 28:
																															case 96:
																																goto IL_03fa;
																															case 55:
																															case 98:
																																goto IL_0416;
																															case 110:
																																goto IL_0424;
																															case 87:
																																goto IL_0437;
																															case 43:
																															case 70:
																																goto IL_0442;
																															case 42:
																																goto IL_0482;
																															case 93:
																																goto IL_0496;
																															case 20:
																															case 95:
																																goto IL_04a9;
																															case 15:
																																goto IL_04b7;
																															case 50:
																															case 54:
																																goto IL_04c2;
																															case 24:
																																goto IL_04da;
																															case 99:
																																goto IL_04e5;
																															case 52:
																															case 59:
																																goto IL_04f3;
																															case 23:
																																goto IL_050c;
																															case 47:
																																goto IL_051a;
																															case 92:
																																goto IL_0528;
																															case 33:
																																goto IL_053b;
																															case 19:
																																goto IL_0549;
																															case 57:
																															case 77:
																																goto IL_0557;
																															case 97:
																																goto IL_0589;
																															case 83:
																																goto IL_0597;
																															case 21:
																																goto IL_05aa;
																															case 3:
																															case 31:
																																goto IL_05b5;
																															case 64:
																																goto IL_05c0;
																															case 30:
																															case 58:
																																goto IL_05cb;
																															case 13:
																																goto IL_05d9;
																															case 72:
																																goto IL_05fc;
																															case 74:
																																goto IL_0606;
																															case 89:
																																goto IL_0614;
																															case 82:
																																goto IL_0624;
																															case 0:
																															case 2:
																															case 12:
																															case 14:
																															case 22:
																															case 25:
																															case 26:
																															case 36:
																															case 37:
																															case 38:
																															case 41:
																															case 44:
																															case 61:
																															case 63:
																															case 69:
																															case 73:
																															case 85:
																															case 91:
																															case 94:
																															case 102:
																															case 109:
																																goto end_IL_0230;
																															case 1:
																															case 5:
																															case 6:
																															case 29:
																															case 45:
																															case 49:
																															case 51:
																															case 56:
																															case 71:
																															case 78:
																															case 104:
																															case 105:
																															case 111:
																															case 113:
																																goto end_IL_01ef;
																															case 62:
																																goto end_IL_0642;
																															case 16:
																																goto end_IL_0655;
																															case 112:
																																goto end_IL_065f;
																															case 46:
																																goto end_IL_066a;
																															case 80:
																															case 107:
																																goto end_IL_067f;
																															case 75:
																																goto end_IL_068f;
																															case 4:
																															case 103:
																																goto end_IL_069f;
																															case 7:
																																goto end_IL_06af;
																															case 8:
																																goto end_IL_06c8;
																															case 81:
																															case 100:
																																goto IL_06e3;
																															}
																															continue;
																														}
																														array[num5] = 0;
																														goto IL_03c0;
																														IL_03c0:
																														num5++;
																														goto IL_03ce;
																														IL_03ce:
																														ptr2 += 8;
																														break;
																														continue;
																														end_IL_01ef:
																														break;
																													}
																													break;
																												}
																												goto end_IL_029d;
																												continue;
																												end_IL_0230:
																												break;
																												IL_0230:;
																											}
																											break;
																											IL_0240:;
																										}
																										break;
																									}
																									goto IL_033d;
																									IL_039f:
																									num5--;
																									goto end_IL_029d;
																									IL_033d:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_034b;
																									IL_034b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_038b;
																									IL_038b:
																									array[num5 - 2] = 0;
																									goto IL_039f;
																								}
																								break;
																							}
																							goto IL_02c8;
																							IL_032a:
																							num5 -= 2;
																							goto end_IL_029d;
																							IL_02c8:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_032a;
																						}
																						break;
																					}
																					goto IL_03e1;
																					IL_0424:
																					if (11 <= b)
																					{
																					}
																					break;
																					IL_03e1:
																					if (10 >= b)
																					{
																						goto IL_03ec;
																					}
																					goto IL_0416;
																					IL_03ec:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_03fa;
																					IL_03fa:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_029d;
																					IL_0416:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0424;
																				}
																				break;
																			}
																			goto IL_0437;
																			IL_0624:
																			if (4 <= b)
																			{
																				goto end_IL_029d;
																			}
																			break;
																			IL_0437:
																			if (6 <= b)
																			{
																				goto IL_0442;
																			}
																			goto IL_04a9;
																			IL_0442:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0482;
																			IL_0482:
																			array[num5 - 2] = 0;
																			goto IL_0496;
																			IL_0496:
																			num5--;
																			goto end_IL_029d;
																			IL_04a9:
																			if (3 >= b)
																			{
																				goto IL_04b7;
																			}
																			goto IL_05aa;
																			IL_04b7:
																			if (3 <= b)
																			{
																				goto IL_04c2;
																			}
																			goto IL_04da;
																			IL_04c2:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_029d;
																			IL_04da:
																			if (1 >= b)
																			{
																				goto IL_04e5;
																			}
																			goto IL_053b;
																			IL_04e5:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04f3;
																			IL_04f3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_050c;
																			IL_050c:
																			array[num5] = 0;
																			goto IL_051a;
																			IL_051a:
																			num5++;
																			goto IL_0528;
																			IL_0528:
																			ptr2 += 8;
																			goto end_IL_029d;
																			IL_053b:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0549;
																			IL_0549:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0557;
																			IL_0557:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 97;
																			goto IL_0589;
																			IL_0589:
																			ptr2 += 8;
																			goto IL_0597;
																			IL_0597:
																			num5--;
																			goto end_IL_029d;
																			IL_05aa:
																			if (4 < b)
																			{
																				goto IL_05b5;
																			}
																			goto IL_0624;
																			IL_05b5:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_05c0;
																			IL_05c0:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_05cb;
																			IL_05cb:
																			array[num5] = 0;
																			goto IL_05d9;
																			IL_05d9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05fc;
																			IL_05fc:
																			array2[num5] = null;
																			goto IL_0606;
																			IL_0606:
																			num5++;
																			goto IL_0614;
																			IL_0614:
																			ptr2 += 8;
																			goto end_IL_029d;
																		}
																		break;
																		IL_028d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_029d:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06e3;
												IL_06e3:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0642:
												break;
											}
											continue;
											end_IL_0655:
											break;
										}
										continue;
										end_IL_065f:
										break;
									}
									continue;
									end_IL_066a:
									break;
								}
								continue;
								end_IL_067f:
								break;
							}
							continue;
							end_IL_068f:
							break;
						}
						continue;
						end_IL_069f:
						break;
					}
					continue;
					end_IL_06af:
					break;
				}
				continue;
				end_IL_06c8:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetComponentManifestThreadContextChanged.FormatJapaneseFirstYearAsANumberCreateFloatingDateRule);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													IL_04e7:
													if (num4 != 1)
													{
														goto IL_000e;
													}
													num = 92;
													while (true)
													{
														if (num != 92)
														{
															if (num != 1073)
															{
																break;
															}
															switch (num)
															{
															case 65:
																break;
															case 15:
																goto IL_0017;
															case 68:
																goto IL_0020;
															case 1:
																goto IL_002e;
															case 32:
																goto IL_003c;
															case 83:
																goto IL_004a;
															case 48:
																goto IL_0058;
															case 6:
																goto IL_0066;
															case 60:
															case 81:
																goto IL_0074;
															case 11:
																goto IL_0082;
															case 29:
															case 71:
																goto IL_0090;
															case 14:
																goto end_IL_04d4;
															case 77:
																goto IL_00ed;
															case 36:
																goto IL_0100;
															case 20:
															case 38:
																goto IL_010b;
															case 82:
																goto IL_0119;
															case 23:
															case 67:
																goto IL_012c;
															case 5:
																goto IL_019a;
															case 55:
															case 70:
																goto IL_01b6;
															case 33:
																goto IL_01df;
															case 53:
																goto IL_01ed;
															case 63:
																goto IL_0200;
															case 49:
															case 61:
																goto IL_020e;
															case 28:
																goto IL_0219;
															case 24:
															case 31:
																goto IL_0227;
															case 25:
																goto IL_0235;
															case 69:
																goto IL_0258;
															case 13:
																goto IL_0262;
															case 54:
																goto IL_0270;
															case 8:
																goto IL_0283;
															case 39:
																goto IL_028e;
															case 7:
															case 62:
																goto IL_0299;
															case 52:
																goto IL_02b5;
															case 45:
															case 47:
																goto IL_02c3;
															case 17:
																goto IL_02d7;
															case 0:
															case 57:
																goto IL_02e2;
															case 19:
															case 22:
															case 34:
															case 35:
															case 44:
															case 50:
															case 51:
															case 59:
															case 66:
															case 73:
															case 78:
															case 79:
															case 85:
																goto IL_02fa;
															case 9:
																goto IL_031d;
															case 10:
																goto IL_0334;
															case 46:
																goto IL_0342;
															default:
																continue;
															case 2:
															case 3:
															case 12:
															case 16:
															case 21:
															case 26:
															case 30:
															case 42:
															case 64:
															case 72:
															case 80:
																goto IL_04e7;
															case 43:
																goto end_IL_04e7;
															case 74:
																goto end_IL_04fa;
															case 58:
																goto end_IL_0504;
															case 76:
																goto end_IL_050f;
															case 56:
																goto end_IL_0524;
															case 37:
															case 75:
																goto end_IL_0539;
															case 18:
																goto end_IL_0549;
															case 27:
															case 84:
																goto end_IL_0559;
															case 40:
																goto end_IL_0569;
															case 41:
																goto end_IL_0579;
															case 4:
																goto IL_0594;
															}
															goto IL_000e;
														}
														goto IL_0594;
														IL_0594:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04d4:
														break;
													}
													goto IL_00d9;
													IL_02fa:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_031d;
													IL_031d:
													array[num5] = 0;
													num = 10;
													goto IL_0334;
													IL_000e:
													num = 15;
													goto IL_0017;
													IL_0017:
													b = *ptr2;
													goto IL_0020;
													IL_0020:
													ptr2++;
													goto IL_002e;
													IL_002e:
													if (b >= 1)
													{
														goto IL_003c;
													}
													goto IL_02fa;
													IL_003c:
													if (b <= 8)
													{
														goto IL_004a;
													}
													goto IL_02fa;
													IL_004a:
													if (4 >= b)
													{
														goto IL_0058;
													}
													goto IL_0200;
													IL_0058:
													if (4 > b)
													{
														goto IL_0066;
													}
													num = 70;
													goto IL_01b6;
													IL_0066:
													if (2 < b)
													{
														goto IL_0074;
													}
													goto IL_0100;
													IL_0074:
													if (3 >= b)
													{
														goto IL_0082;
													}
													goto IL_02fa;
													IL_0082:
													if (3 <= b)
													{
														goto IL_0090;
													}
													goto IL_02fa;
													IL_0090:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													num = 14;
													goto IL_00d9;
													IL_00d9:
													array[num5 - 2] = 0;
													goto IL_00ed;
													IL_00ed:
													num5--;
													continue;
													IL_0100:
													if (2 > b)
													{
														goto IL_010b;
													}
													goto IL_012c;
													IL_010b:
													if (1 >= b)
													{
														goto IL_0119;
													}
													goto IL_02fa;
													IL_0119:
													if (1 > b)
													{
													}
													goto IL_02fa;
													IL_012c:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_019a;
													IL_019a:
													num5 -= 2;
													continue;
													IL_0334:
													num5++;
													goto IL_0342;
													IL_01b6:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_01df;
													IL_01df:
													ptr2 += 8;
													goto IL_01ed;
													IL_01ed:
													num5--;
													continue;
													IL_0200:
													if (6 < b)
													{
														goto IL_020e;
													}
													goto IL_02b5;
													IL_020e:
													if (7 >= b)
													{
														goto IL_0219;
													}
													goto IL_0283;
													IL_0219:
													if (7 <= b)
													{
														goto IL_0227;
													}
													goto IL_02fa;
													IL_0227:
													array[num5] = 0;
													goto IL_0235;
													IL_0235:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0258;
													IL_0258:
													array2[num5] = null;
													goto IL_0262;
													IL_0262:
													num5++;
													goto IL_0270;
													IL_0270:
													ptr2 += 8;
													continue;
													IL_0283:
													if (8 >= b)
													{
														goto IL_028e;
													}
													goto IL_02fa;
													IL_028e:
													if (8 <= b)
													{
														goto IL_0299;
													}
													goto IL_02fa;
													IL_0299:
													byte* num6 = ptr2;
													num4 = 1;
													ptr2 = num6 + -200;
													continue;
													IL_02b5:
													if (6 <= b)
													{
														continue;
													}
													goto IL_02c3;
													IL_02c3:
													if (5 >= b)
													{
														num = 17;
														goto IL_02d7;
													}
													goto IL_02fa;
													IL_0342:
													ptr2 += 8;
													continue;
													IL_02d7:
													if (5 <= b)
													{
														goto IL_02e2;
													}
													goto IL_02fa;
													IL_02e2:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													continue;
													end_IL_04e7:
													break;
												}
												continue;
												end_IL_04fa:
												break;
											}
											continue;
											end_IL_0504:
											break;
										}
										continue;
										end_IL_050f:
										break;
									}
									continue;
									end_IL_0524:
									break;
								}
								continue;
								end_IL_0539:
								break;
							}
							continue;
							end_IL_0549:
							break;
						}
						continue;
						end_IL_0559:
						break;
					}
					continue;
					end_IL_0569:
					break;
				}
				continue;
				end_IL_0579:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSkipSizeIteratorOfTToIteratorAdapter.ObjectAceTypegetSynchronization);
										num = 55;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_026d:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_025d:
																		if (b <= 11)
																		{
																			while (true)
																			{
																				IL_024d:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_023d:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0230:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0220:
																										if (4 < b)
																										{
																											while (true)
																											{
																												IL_0210:
																												if (5 < b)
																												{
																													num = 120;
																													while (num != 120 && num == 1101)
																													{
																														switch (num)
																														{
																														case 44:
																															goto IL_0210;
																														case 29:
																														case 68:
																															goto IL_0220;
																														case 19:
																															goto IL_0230;
																														case 45:
																															goto IL_023d;
																														case 64:
																															goto IL_024d;
																														case 79:
																															goto IL_025d;
																														case 95:
																															goto IL_026d;
																														case 65:
																															goto end_IL_026d;
																														case 67:
																														case 110:
																															goto end_IL_027d;
																														case 31:
																															goto IL_0298;
																														case 46:
																															goto IL_02ab;
																														case 59:
																															goto IL_02b9;
																														case 37:
																															goto IL_02c4;
																														case 30:
																															goto IL_02d2;
																														case 61:
																															goto IL_02e2;
																														case 36:
																														case 76:
																															goto IL_02f2;
																														case 40:
																															goto IL_031b;
																														case 72:
																															goto IL_0329;
																														case 83:
																															goto IL_033c;
																														case 14:
																														case 100:
																															goto IL_034f;
																														case 85:
																															goto IL_0368;
																														case 26:
																															goto IL_0376;
																														case 56:
																															goto IL_0384;
																														case 77:
																														case 102:
																															goto IL_0397;
																														case 63:
																														case 108:
																															goto IL_03af;
																														case 104:
																															goto IL_03ef;
																														case 99:
																															goto IL_0403;
																														case 88:
																														case 111:
																															goto IL_0416;
																														case 106:
																															goto IL_042d;
																														case 47:
																															goto IL_0450;
																														case 75:
																															goto IL_045a;
																														case 39:
																															goto IL_0468;
																														case 60:
																														case 112:
																															goto IL_047b;
																														case 80:
																															goto IL_0489;
																														case 71:
																														case 78:
																															goto IL_0497;
																														case 57:
																														case 62:
																															goto IL_04a2;
																														case 91:
																															goto IL_04b0;
																														case 48:
																														case 92:
																															goto IL_04be;
																														case 0:
																															goto IL_04e1;
																														case 25:
																															goto IL_04ef;
																														case 15:
																															goto IL_04fd;
																														case 9:
																															goto IL_0510;
																														case 22:
																														case 52:
																															goto IL_051b;
																														case 93:
																															goto IL_055b;
																														case 69:
																															goto IL_056f;
																														case 18:
																														case 50:
																															goto IL_0590;
																														case 21:
																															goto IL_05f2;
																														case 20:
																															goto IL_0602;
																														case 16:
																															goto IL_060d;
																														case 23:
																															goto IL_0618;
																														case 51:
																															goto IL_062e;
																														case 34:
																														case 35:
																															goto IL_0639;
																														case 1:
																														case 5:
																														case 10:
																														case 11:
																														case 24:
																														case 32:
																														case 33:
																														case 38:
																														case 49:
																														case 54:
																														case 58:
																														case 74:
																														case 82:
																														case 90:
																														case 94:
																														case 96:
																														case 98:
																														case 101:
																														case 103:
																														case 107:
																														case 113:
																															goto end_IL_01fd;
																														case 4:
																														case 12:
																														case 13:
																														case 27:
																														case 28:
																														case 42:
																														case 53:
																														case 66:
																														case 70:
																														case 73:
																														case 81:
																														case 84:
																														case 86:
																														case 109:
																															goto end_IL_028d;
																														case 55:
																															goto end_IL_0677;
																														case 97:
																															goto end_IL_068a;
																														case 43:
																															goto end_IL_0694;
																														case 89:
																															goto end_IL_06a8;
																														case 8:
																														case 41:
																															goto end_IL_06bd;
																														case 2:
																															goto end_IL_06cd;
																														case 87:
																														case 105:
																															goto end_IL_06dd;
																														case 6:
																															goto end_IL_06ed;
																														case 7:
																															goto end_IL_06fd;
																														case 3:
																														case 17:
																															goto IL_0718;
																														}
																														continue;
																														end_IL_01fd:
																														break;
																													}
																													break;
																												}
																												goto IL_0298;
																												IL_045a:
																												num5++;
																												goto IL_0468;
																												IL_0468:
																												ptr2 += 8;
																												goto end_IL_028d;
																												IL_0298:
																												if (5 > b)
																												{
																													break;
																												}
																												goto IL_0416;
																												IL_0416:
																												array[num5] = 0;
																												num = 106;
																												goto IL_042d;
																												IL_042d:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0450;
																												IL_0450:
																												array2[num5] = null;
																												goto IL_045a;
																											}
																											break;
																										}
																										goto IL_033c;
																										IL_033c:
																										if (4 > b)
																										{
																											break;
																										}
																										goto end_IL_028d;
																									}
																									break;
																								}
																								goto IL_02ab;
																								IL_0397:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_028d;
																								IL_02ab:
																								if (3 > b)
																								{
																									goto IL_02b9;
																								}
																								goto IL_0397;
																								IL_02b9:
																								if (1 < b)
																								{
																									goto IL_02c4;
																								}
																								goto IL_02e2;
																								IL_02c4:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_02d2;
																								IL_02d2:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_02f2;
																								IL_02f2:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_031b;
																								IL_031b:
																								ptr2 += 8;
																								goto IL_0329;
																								IL_0329:
																								num5--;
																								goto end_IL_028d;
																								IL_02e2:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_034f;
																								IL_034f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0368;
																								IL_0368:
																								array[num5] = 0;
																								goto IL_0376;
																								IL_0376:
																								num5++;
																								goto IL_0384;
																								IL_0384:
																								ptr2 += 8;
																								goto end_IL_028d;
																							}
																							break;
																						}
																						goto IL_03af;
																						IL_0403:
																						num5--;
																						goto end_IL_028d;
																						IL_03af:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03ef;
																						IL_03ef:
																						array[num5 - 2] = 0;
																						goto IL_0403;
																					}
																					break;
																				}
																				goto IL_047b;
																				IL_0639:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 13;
																				goto end_IL_028d;
																				IL_047b:
																				if (9 >= b)
																				{
																					goto IL_0489;
																				}
																				goto IL_0602;
																				IL_0489:
																				if (9 > b)
																				{
																					goto IL_0497;
																				}
																				goto IL_0590;
																				IL_0497:
																				if (7 < b)
																				{
																					goto IL_04a2;
																				}
																				goto IL_0510;
																				IL_04a2:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_04b0;
																				IL_04b0:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04be;
																				IL_04be:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04e1;
																				IL_04e1:
																				array[num5] = 0;
																				goto IL_04ef;
																				IL_04ef:
																				num5++;
																				goto IL_04fd;
																				IL_04fd:
																				ptr2 += 8;
																				goto end_IL_028d;
																				IL_0510:
																				if (7 > b)
																				{
																					num = 96;
																					break;
																				}
																				goto IL_051b;
																				IL_051b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_055b;
																				IL_055b:
																				array[num5 - 2] = 0;
																				goto IL_056f;
																				IL_056f:
																				num5--;
																				goto end_IL_028d;
																				IL_062e:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0639;
																				IL_0590:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05f2;
																				IL_05f2:
																				num5 -= 2;
																				goto end_IL_028d;
																				IL_0602:
																				if (10 < b)
																				{
																					goto IL_060d;
																				}
																				num = 51;
																				goto IL_062e;
																				IL_060d:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0618;
																				IL_0618:
																				if (11 <= b)
																				{
																				}
																				break;
																			}
																		}
																		else
																		{
																			num = 82;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_028d;
																continue;
																end_IL_026d:
																break;
															}
															continue;
															end_IL_027d:
															break;
														}
														continue;
														end_IL_028d:
														break;
													}
													continue;
												}
												goto IL_0718;
												IL_0718:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0677:
												break;
											}
											continue;
											end_IL_068a:
											break;
										}
										continue;
										end_IL_0694:
										break;
									}
									continue;
									end_IL_06a8:
									break;
								}
								continue;
								end_IL_06bd:
								break;
							}
							continue;
							end_IL_06cd:
							break;
						}
						continue;
						end_IL_06dd:
						break;
					}
					continue;
					end_IL_06ed:
					break;
				}
				continue;
				end_IL_06fd:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_0, int int_1)
	{
		int num = 29;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											IL_0503:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SystemDefinedImplNetCodeGroup.VARFLAGFNONBROWSABLEGetFuncDesc);
											while (true)
											{
												IL_04f9:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_04e6:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0227:
															byte b = *ptr2;
															while (true)
															{
																IL_0217:
																ptr2++;
																while (true)
																{
																	IL_0207:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e7:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01da:
																						if (4 <= b)
																						{
																							while (true)
																							{
																								IL_01a6:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 97;
																								while (true)
																								{
																									if (num != 97)
																									{
																										if (num != 1078)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 69:
																										case 89:
																											goto IL_01a6;
																										case 14:
																											goto IL_01da;
																										case 72:
																											goto IL_01e7;
																										case 58:
																											goto IL_01f7;
																										case 55:
																											goto IL_0207;
																										case 26:
																											goto IL_0217;
																										case 16:
																										case 73:
																											goto IL_0227;
																										case 18:
																											goto IL_0232;
																										case 22:
																											goto IL_0240;
																										case 2:
																										case 5:
																											goto IL_024b;
																										case 74:
																											goto IL_02bb;
																										case 39:
																											goto IL_02c9;
																										case 75:
																											goto IL_02dc;
																										case 21:
																										case 77:
																											goto IL_02ef;
																										case 60:
																											goto IL_02fd;
																										case 81:
																										case 87:
																											goto IL_030b;
																										case 83:
																											goto IL_034b;
																										case 37:
																											goto IL_035f;
																										case 47:
																											goto IL_0380;
																										case 40:
																											goto IL_039c;
																										case 53:
																											goto IL_03a7;
																										case 61:
																											goto IL_03b5;
																										case 88:
																											goto IL_03c3;
																										case 20:
																										case 56:
																											goto IL_03d1;
																										case 19:
																											goto IL_03e9;
																										case 34:
																										case 38:
																											goto IL_03f4;
																										case 11:
																											goto IL_0402;
																										case 45:
																										case 59:
																											goto IL_0410;
																										case 70:
																											goto IL_042c;
																										case 0:
																										case 3:
																											goto IL_0437;
																										case 7:
																											goto IL_0445;
																										case 4:
																											goto IL_0468;
																										case 33:
																											goto IL_0472;
																										case 90:
																											goto IL_0480;
																										case 1:
																										case 8:
																										case 9:
																										case 10:
																										case 17:
																										case 23:
																										case 24:
																										case 25:
																										case 27:
																										case 30:
																										case 31:
																										case 32:
																										case 43:
																										case 49:
																										case 51:
																										case 57:
																										case 62:
																										case 63:
																										case 80:
																										case 84:
																											goto end_IL_01f7;
																										case 15:
																											goto IL_04b3;
																										case 13:
																											goto IL_04c1;
																										case 36:
																											goto IL_04d8;
																										case 42:
																										case 46:
																										case 48:
																										case 52:
																										case 54:
																										case 64:
																										case 66:
																										case 68:
																										case 71:
																										case 76:
																										case 78:
																											goto IL_04e6;
																										case 12:
																											goto IL_04f9;
																										case 85:
																											goto IL_0503;
																										case 86:
																											goto end_IL_0193;
																										case 6:
																											goto end_IL_050e;
																										case 41:
																											goto end_IL_0523;
																										case 44:
																										case 82:
																											goto end_IL_0538;
																										case 35:
																											goto end_IL_0548;
																										case 50:
																										case 67:
																											goto end_IL_0558;
																										case 28:
																											goto end_IL_0568;
																										case 29:
																											goto end_IL_0578;
																										case 65:
																										case 79:
																											goto IL_0593;
																										}
																										continue;
																									}
																									ptr2 += 8;
																									goto IL_0380;
																									IL_0380:
																									num5--;
																									num = 64;
																									goto IL_04e6;
																									continue;
																									end_IL_0193:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0232;
																						IL_035f:
																						num5--;
																						goto IL_04e6;
																						IL_0232:
																						if (2 >= b)
																						{
																							goto IL_0240;
																						}
																						goto IL_02ef;
																						IL_0240:
																						if (2 <= b)
																						{
																							goto IL_024b;
																						}
																						goto IL_02bb;
																						IL_024b:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_02dc;
																						IL_02dc:
																						num5 -= 2;
																						goto IL_04e6;
																						IL_02bb:
																						if (1 < b)
																						{
																							goto end_IL_01f7;
																						}
																						goto IL_02c9;
																						IL_02c9:
																						if (1 <= b)
																						{
																						}
																						goto end_IL_01f7;
																						IL_02ef:
																						if (3 < b)
																						{
																							goto end_IL_01f7;
																						}
																						goto IL_02fd;
																						IL_02fd:
																						if (3 > b)
																						{
																							goto end_IL_01f7;
																						}
																						goto IL_030b;
																						IL_030b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_034b;
																						IL_034b:
																						array[num5 - 2] = 0;
																						goto IL_035f;
																					}
																					break;
																				}
																				goto IL_039c;
																				IL_0480:
																				ptr2 += 8;
																				goto IL_04e6;
																				IL_039c:
																				if (6 >= b)
																				{
																					goto IL_03a7;
																				}
																				goto IL_03e9;
																				IL_03a7:
																				if (6 <= b)
																				{
																					goto IL_04e6;
																				}
																				goto IL_03b5;
																				IL_03b5:
																				if (5 < b)
																				{
																					goto end_IL_01f7;
																				}
																				goto IL_03c3;
																				IL_03c3:
																				if (5 > b)
																				{
																					goto end_IL_01f7;
																				}
																				goto IL_03d1;
																				IL_03d1:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_04e6;
																				IL_03e9:
																				if (7 < b)
																				{
																					goto IL_03f4;
																				}
																				goto IL_042c;
																				IL_03f4:
																				if (8 < b)
																				{
																					goto end_IL_01f7;
																				}
																				goto IL_0402;
																				IL_0402:
																				if (8 > b)
																				{
																					goto end_IL_01f7;
																				}
																				goto IL_0410;
																				IL_0410:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_04e6;
																				IL_042c:
																				if (7 > b)
																				{
																					goto end_IL_01f7;
																				}
																				goto IL_0437;
																				IL_0437:
																				array[num5] = 0;
																				goto IL_0445;
																				IL_0445:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0468;
																				IL_0468:
																				array2[num5] = null;
																				goto IL_0472;
																				IL_0472:
																				num5++;
																				goto IL_0480;
																			}
																			goto end_IL_0207;
																			continue;
																			end_IL_01f7:
																			break;
																			IL_01f7:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04b3;
																	IL_04d8:
																	ptr2 += 8;
																	goto IL_04e6;
																	IL_04c1:
																	num5++;
																	num = 36;
																	goto IL_04d8;
																	IL_04b3:
																	array[num5] = 0;
																	goto IL_04c1;
																	continue;
																	end_IL_0207:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_0593;
													IL_0593:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										continue;
										end_IL_050e:
										break;
									}
									continue;
									end_IL_0523:
									break;
								}
								continue;
								end_IL_0538:
								break;
							}
							continue;
							end_IL_0548:
							break;
						}
						continue;
						end_IL_0558:
						break;
					}
					continue;
					end_IL_0568:
					break;
				}
				continue;
				end_IL_0578:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0)
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct94.setPercentDecimalSeparatorAnyScheme);
										num = 22;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0265:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		num = 110;
																		while (true)
																		{
																			IL_0242:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0235:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0222:
																							if (9 <= b)
																							{
																								num = 121;
																								while (true)
																								{
																									if (num != 121)
																									{
																										if (num != 1102)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 59:
																											goto IL_0222;
																										case 103:
																										case 114:
																											goto IL_0235;
																										case 110:
																											goto IL_0242;
																										case 90:
																											goto end_IL_0242;
																										case 66:
																											goto IL_0265;
																										case 25:
																											goto end_IL_0265;
																										case 19:
																										case 99:
																											goto end_IL_0275;
																										case 15:
																										case 28:
																											goto IL_0290;
																										case 79:
																											goto IL_029b;
																										case 69:
																										case 87:
																											goto IL_02ae;
																										case 56:
																											goto IL_02bc;
																										case 92:
																											goto IL_02cf;
																										case 17:
																											goto IL_02da;
																										case 76:
																											goto IL_02f6;
																										case 16:
																											goto IL_0304;
																										case 55:
																										case 65:
																											goto IL_0312;
																										case 63:
																											goto IL_0335;
																										case 86:
																											goto IL_0343;
																										case 43:
																											goto IL_0351;
																										case 93:
																											goto IL_036d;
																										case 26:
																										case 54:
																											goto IL_0378;
																										case 78:
																											goto IL_03b8;
																										case 61:
																										case 96:
																											goto IL_03d1;
																										case 98:
																											goto IL_03ed;
																										case 51:
																											goto IL_03fb;
																										case 47:
																										case 74:
																											goto IL_0406;
																										case 20:
																										case 42:
																											goto IL_041d;
																										case 4:
																											goto IL_042b;
																										case 9:
																										case 77:
																											goto IL_043b;
																										case 12:
																										case 104:
																											goto IL_0453;
																										case 32:
																											goto IL_047c;
																										case 70:
																											goto IL_048a;
																										case 107:
																											goto IL_049d;
																										case 18:
																										case 45:
																											goto IL_04ab;
																										case 68:
																											goto IL_04c4;
																										case 106:
																											goto IL_04d2;
																										case 24:
																											goto IL_04e0;
																										case 109:
																											goto IL_04f3;
																										case 52:
																										case 111:
																											goto IL_0506;
																										case 7:
																											goto IL_054f;
																										case 2:
																											goto IL_0563;
																										case 113:
																											goto IL_0576;
																										case 84:
																											goto IL_0581;
																										case 53:
																											goto IL_0594;
																										case 29:
																											goto IL_05a2;
																										case 60:
																										case 108:
																											goto end_IL_020f;
																										case 81:
																											goto IL_05be;
																										case 41:
																											goto IL_05e1;
																										case 94:
																											goto IL_05eb;
																										case 35:
																											goto IL_05f9;
																										case 21:
																											goto IL_060c;
																										case 101:
																											goto IL_066e;
																										case 0:
																										case 6:
																										case 10:
																										case 11:
																										case 13:
																										case 30:
																										case 36:
																										case 37:
																										case 39:
																										case 49:
																										case 57:
																										case 58:
																										case 62:
																										case 64:
																										case 67:
																										case 73:
																										case 75:
																										case 80:
																										case 85:
																										case 97:
																										case 105:
																										case 112:
																											goto end_IL_0252;
																										case 3:
																										case 5:
																										case 8:
																										case 33:
																										case 34:
																										case 40:
																										case 44:
																										case 48:
																										case 50:
																										case 72:
																										case 82:
																										case 95:
																										case 100:
																										case 102:
																											goto end_IL_0285;
																										case 22:
																											goto end_IL_0691;
																										case 71:
																											goto end_IL_06a4;
																										case 46:
																											goto end_IL_06ae;
																										case 31:
																											goto end_IL_06c2;
																										case 23:
																										case 38:
																											goto end_IL_06d7;
																										case 83:
																											goto end_IL_06e7;
																										case 1:
																										case 27:
																											goto end_IL_06f7;
																										case 88:
																											goto end_IL_0707;
																										case 89:
																											goto end_IL_0717;
																										case 14:
																										case 91:
																											goto IL_0732;
																										}
																										continue;
																									}
																									goto IL_060c;
																									IL_060c:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_066e;
																									IL_066e:
																									num5 -= 2;
																									goto end_IL_0285;
																									continue;
																									end_IL_020f:
																									break;
																								}
																								break;
																							}
																							goto IL_02cf;
																							IL_0335:
																							array[num5] = 0;
																							goto IL_0343;
																							IL_0343:
																							num5++;
																							goto IL_0351;
																							IL_02cf:
																							if (7 >= b)
																							{
																								goto IL_02da;
																							}
																							goto IL_02f6;
																							IL_02da:
																							if (7 > b)
																							{
																								goto end_IL_0252;
																							}
																							num = 111;
																							goto IL_0506;
																							IL_0351:
																							ptr2 += 8;
																							num = 44;
																							goto end_IL_0285;
																							IL_0506:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 7;
																							goto IL_054f;
																							IL_054f:
																							array[num5 - 2] = 0;
																							goto IL_0563;
																							IL_0563:
																							num5--;
																							goto end_IL_0285;
																							IL_02f6:
																							if (8 < b)
																							{
																								goto end_IL_0252;
																							}
																							goto IL_0304;
																							IL_0304:
																							if (8 > b)
																							{
																								goto end_IL_0252;
																							}
																							goto IL_0312;
																							IL_0312:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0335;
																						}
																						break;
																					}
																					goto IL_0290;
																					IL_02bc:
																					if (11 <= b)
																					{
																					}
																					goto end_IL_0252;
																					IL_0290:
																					if (10 >= b)
																					{
																						goto IL_029b;
																					}
																					goto IL_02ae;
																					IL_029b:
																					if (10 > b)
																					{
																						goto end_IL_0252;
																					}
																					goto IL_03d1;
																					IL_03d1:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0285;
																					IL_02ae:
																					if (11 < b)
																					{
																						goto end_IL_0252;
																					}
																					goto IL_02bc;
																				}
																				goto IL_05b0;
																			}
																			goto IL_036d;
																			IL_05eb:
																			num5++;
																			goto IL_05f9;
																			IL_036d:
																			if (6 <= b)
																			{
																				goto IL_0378;
																			}
																			goto IL_03ed;
																			IL_0378:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03b8;
																			IL_03b8:
																			array[num5 - 2] = 0;
																			goto IL_04f3;
																			IL_04f3:
																			num5--;
																			goto end_IL_0285;
																			IL_03ed:
																			if (3 >= b)
																			{
																				goto IL_03fb;
																			}
																			goto IL_0576;
																			IL_03fb:
																			if (3 > b)
																			{
																				goto IL_0406;
																			}
																			goto IL_043b;
																			IL_0406:
																			if (1 < b)
																			{
																				num = 42;
																				goto IL_041d;
																			}
																			goto IL_049d;
																			IL_05f9:
																			ptr2 += 8;
																			goto end_IL_0285;
																			IL_041d:
																			if (2 < b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_042b;
																			IL_042b:
																			if (2 > b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_0453;
																			IL_0453:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_047c;
																			IL_047c:
																			ptr2 += 8;
																			goto IL_048a;
																			IL_048a:
																			num5--;
																			goto end_IL_0285;
																			IL_049d:
																			if (1 > b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_04ab;
																			IL_04ab:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04c4;
																			IL_04c4:
																			array[num5] = 0;
																			goto IL_04d2;
																			IL_04d2:
																			num5++;
																			goto IL_04e0;
																			IL_04e0:
																			ptr2 += 8;
																			goto end_IL_0285;
																			IL_043b:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0285;
																			IL_0576:
																			if (4 >= b)
																			{
																				goto IL_0581;
																			}
																			goto IL_0594;
																			IL_0581:
																			if (4 <= b)
																			{
																				goto end_IL_0285;
																			}
																			goto end_IL_0252;
																			IL_0594:
																			if (5 < b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_05a2;
																			IL_05a2:
																			if (5 > b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_05b0;
																			IL_05b0:
																			array[num5] = 0;
																			goto IL_05be;
																			IL_05be:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05e1;
																			IL_05e1:
																			array2[num5] = null;
																			goto IL_05eb;
																			continue;
																			end_IL_0242:
																			break;
																		}
																		continue;
																		end_IL_0252:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0285;
																continue;
																end_IL_0265:
																break;
															}
															continue;
															end_IL_0275:
															break;
														}
														continue;
														end_IL_0285:
														break;
													}
													continue;
												}
												goto IL_0732;
												IL_0732:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0691:
												break;
											}
											continue;
											end_IL_06a4:
											break;
										}
										continue;
										end_IL_06ae:
										break;
									}
									continue;
									end_IL_06c2:
									break;
								}
								continue;
								end_IL_06d7:
								break;
							}
							continue;
							end_IL_06e7:
							break;
						}
						continue;
						end_IL_06f7:
						break;
					}
					continue;
					end_IL_0707:
					break;
				}
				continue;
				end_IL_0717:
				break;
			}
		}
	}

	static Class181()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 15;
					while (true)
					{
						if (num == 15 || num != 996)
						{
							return;
						}
						switch (num)
						{
						case 7:
							goto end_IL_0045;
						case 1:
							goto end_IL_0052;
						case 2:
							goto end_IL_005e;
						case 0:
							return;
						case 3:
							return;
						case 4:
							return;
						case 5:
							return;
						case 6:
							return;
						case 8:
							return;
						}
						continue;
						end_IL_0045:
						break;
					}
					continue;
					end_IL_0052:
					break;
				}
				continue;
				end_IL_005e:
				break;
			}
		}
	}

	private static void NativeRegisterRelativeTypeInfo(Class181 class181_1)
	{
		class181_1.method_2();
	}
}
