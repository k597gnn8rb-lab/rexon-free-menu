using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Weak Blaster Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns weak blasters.", false, 16, ModType.const_0, false)]
internal class Class111 : Class93
{
	private static double double_1;

	private static double double_2;

	private static float float_0;

	private static bool bool_0;

	private static int int_3;

	private static IntPtr[] BinaryBeq;

	private static IntPtr[] ActivatorLevelIIDIDefinitionIdentity;

	private static IntPtr[] MessageSmugglerGetAsyncResult;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_035f, IL_036f, IL_0383, IL_038e, IL_03a5, IL_03b3, IL_03c1, IL_03cf, IL_03dd, IL_03e8, IL_03f3, IL_0401, IL_0419, IL_0427, IL_0435, IL_0451, IL_045c, IL_0475, IL_0483, IL_0491, IL_04a4, IL_04af, IL_04ba, IL_04f8, IL_050b, IL_0519, IL_0527, IL_0535, IL_0549, IL_0581, IL_0594, IL_05a2, IL_05b0, IL_05bb, IL_05c4, IL_05e2, IL_05f0, IL_0603, IL_0611, IL_061a, IL_0628, IL_0645, IL_0694, IL_069e, IL_06cb, IL_06df, IL_06ed, IL_0700, IL_070b, IL_0719, IL_0742, IL_075b, IL_0769, IL_0777, IL_078f, IL_07ad, IL_07d1, IL_07f2, IL_0805, IL_0813, IL_082b, IL_0839, IL_084c, IL_085a, IL_0868, IL_0871, IL_087c, IL_08bc, IL_08d0, IL_08e3, IL_08ec, IL_08fa, IL_0908, IL_0913, IL_0921, IL_092f, IL_093d, IL_0960, IL_096a, IL_0978, IL_098b, IL_0999, IL_09c2, IL_09d0, IL_09e3, IL_09ee, IL_09fc, IL_0a0f, IL_0a4f, IL_0a63, IL_0a76, IL_0a84, IL_0a92, IL_0aa0, IL_0aa9, IL_0ab7, IL_0ac0, IL_0b22, IL_0b35, IL_0b43, IL_0b83, IL_0b97, IL_0baa, IL_0bb8, IL_0bc6, IL_0bd4, IL_0bdf, IL_0bed, IL_0c2d, IL_0c41, IL_0c54, IL_0c5f, IL_0c9f, IL_0cb3, IL_0cc3, IL_0cd3, IL_0cec, IL_0cfa, IL_0d08, IL_0d16, IL_0d29, IL_0d33, IL_0d3e, IL_0d4e, IL_0d5e, IL_0d77, IL_0d87, IL_0d97, IL_0da7, IL_0db7, IL_0dd0, IL_0deb are reachable both inside and outside the pinned region starting at IL_0de5. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 112;
			int num5 = default(int);
			int num8 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				byte* num6;
				int num7;
				object[] array8;
				int num9;
				byte* num10;
				int __rxRef26 = default(int);
				ref int reference = ref __rxRef26;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0dd0:
						num2 = 1;
						while (true)
						{
							IL_0db7:
							num3 = num2 * 4;
							num = 40;
							while (true)
							{
								IL_0da7:
								num4 = num2 * 8;
								while (true)
								{
									IL_0d97:
									array2 = new byte[4];
									while (true)
									{
										IL_0d87:
										array3 = new object[4];
										while (true)
										{
											IL_0d77:
											array4 = new int[4];
											while (true)
											{
												IL_0d5e:
												array5 = new int[6];
												num = 128;
												while (true)
												{
													IL_0d4e:
													array6 = new long[4];
													while (true)
													{
														IL_0d3e:
														array7 = new object[13];
														while (true)
														{
															IL_0d33:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getNameClaimTypeSysUInt.GetServerTypeForUriIMembershipCondition);
															while (true)
															{
																IL_0d29:
																ptr2 = ptr;
																while (true)
																{
																	IL_0d16:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0383:
																			num = 60;
																			while (true)
																			{
																				IL_036f:
																				byte b = *ptr2;
																				num = 212;
																				while (true)
																				{
																					if (num != 212)
																					{
																						if (num != 1193)
																						{
																							goto IL_0594;
																						}
																						switch (num)
																						{
																						case 112:
																							break;
																						default:
																							continue;
																						case 60:
																							goto IL_036f;
																						case 78:
																							goto IL_0383;
																						case 72:
																							goto IL_03a5;
																						case 6:
																							goto IL_03b3;
																						case 158:
																							goto IL_03c1;
																						case 52:
																						case 122:
																							goto IL_03cf;
																						case 94:
																							goto IL_03dd;
																						case 50:
																						case 173:
																							goto IL_03e8;
																						case 34:
																							goto IL_03f3;
																						case 19:
																						case 26:
																							goto IL_0401;
																						case 108:
																							goto IL_0419;
																						case 163:
																							goto IL_0427;
																						case 45:
																						case 119:
																							goto IL_0435;
																						case 199:
																							goto IL_0451;
																						case 103:
																						case 185:
																							goto IL_045c;
																						case 29:
																							goto IL_0475;
																						case 24:
																							goto IL_0483;
																						case 162:
																							goto IL_0491;
																						case 47:
																							goto IL_04a4;
																						case 105:
																							goto IL_04af;
																						case 12:
																						case 83:
																							goto IL_04ba;
																						case 117:
																							goto IL_04f8;
																						case 13:
																							goto IL_0519;
																						case 98:
																							goto IL_0527;
																						case 11:
																						case 14:
																							goto IL_0535;
																						case 142:
																							goto IL_0549;
																						case 204:
																							goto IL_0581;
																						case 106:
																							goto IL_0594;
																						case 56:
																						case 97:
																							goto IL_05a2;
																						case 188:
																							goto IL_05b0;
																						case 148:
																						case 183:
																							goto IL_05c4;
																						case 144:
																							goto IL_05e2;
																						case 152:
																							goto IL_05f0;
																						case 121:
																							goto IL_0603;
																						case 155:
																							goto IL_061a;
																						case 32:
																						case 135:
																							goto IL_0628;
																						case 74:
																							goto IL_06df;
																						case 35:
																							goto IL_06ed;
																						case 73:
																							goto IL_0700;
																						case 130:
																							goto IL_070b;
																						case 88:
																						case 194:
																							goto IL_0719;
																						case 192:
																							goto IL_0742;
																						case 114:
																							goto IL_075b;
																						case 125:
																							goto IL_0769;
																						case 187:
																						case 189:
																							goto IL_0777;
																						case 177:
																							goto IL_078f;
																						case 196:
																							goto IL_07ad;
																						case 1:
																							goto IL_07d1;
																						case 184:
																							goto IL_07f2;
																						case 96:
																						case 195:
																							goto IL_0805;
																						case 65:
																							goto IL_0813;
																						case 203:
																							goto IL_082b;
																						case 137:
																							goto IL_0839;
																						case 165:
																							goto IL_084c;
																						case 38:
																						case 49:
																							goto IL_085a;
																						case 102:
																							goto IL_0871;
																						case 22:
																						case 164:
																							goto IL_087c;
																						case 54:
																							goto IL_08bc;
																						case 33:
																							goto IL_08d0;
																						case 95:
																						case 134:
																							goto IL_08ec;
																						case 92:
																						case 182:
																							goto IL_08fa;
																						case 109:
																						case 123:
																							goto IL_0908;
																						case 127:
																							goto IL_0921;
																						case 15:
																						case 146:
																							goto IL_092f;
																						case 115:
																							goto IL_093d;
																						case 198:
																							goto IL_0960;
																						case 197:
																							goto IL_096a;
																						case 138:
																							goto IL_0978;
																						case 167:
																							goto IL_098b;
																						case 58:
																						case 181:
																							goto IL_0999;
																						case 202:
																							goto IL_09c2;
																						case 154:
																							goto IL_09d0;
																						case 133:
																							goto IL_09e3;
																						case 44:
																						case 62:
																							goto IL_09ee;
																						case 46:
																							goto IL_09fc;
																						case 172:
																						case 193:
																							goto IL_0a0f;
																						case 84:
																							goto IL_0a4f;
																						case 131:
																							goto IL_0a63;
																						case 70:
																							goto IL_0a76;
																						case 10:
																						case 42:
																							goto IL_0a84;
																						case 86:
																						case 156:
																							goto IL_0a92;
																						case 89:
																							goto IL_0aa9;
																						case 9:
																						case 59:
																							goto IL_0ac0;
																						case 63:
																							goto IL_0b22;
																						case 200:
																							goto IL_0b35;
																						case 132:
																						case 140:
																							goto IL_0b43;
																						case 118:
																							goto IL_0b83;
																						case 190:
																							goto IL_0b97;
																						case 71:
																							goto IL_0baa;
																						case 57:
																							goto IL_0bb8;
																						case 25:
																						case 175:
																							goto IL_0bc6;
																						case 174:
																							goto IL_0bd4;
																						case 7:
																						case 157:
																							goto IL_0bed;
																						case 205:
																							goto IL_0c2d;
																						case 159:
																							goto IL_0c41;
																						case 55:
																							goto IL_0c54;
																						case 150:
																						case 169:
																							goto IL_0c5f;
																						case 80:
																							goto IL_0c9f;
																						case 191:
																							goto IL_0cb3;
																						case 61:
																						case 180:
																							goto IL_0cc3;
																						case 0:
																						case 4:
																						case 5:
																						case 17:
																						case 21:
																						case 23:
																						case 28:
																						case 37:
																						case 39:
																						case 41:
																						case 48:
																						case 64:
																						case 68:
																						case 77:
																						case 81:
																						case 85:
																						case 87:
																						case 91:
																						case 104:
																						case 110:
																						case 120:
																						case 126:
																						case 136:
																						case 141:
																						case 143:
																						case 147:
																						case 151:
																						case 160:
																						case 161:
																						case 168:
																						case 171:
																						case 176:
																						case 178:
																						case 179:
																						case 186:
																							goto IL_0cd3;
																						case 16:
																							goto IL_0cec;
																						case 27:
																							goto IL_0cfa;
																						case 100:
																							goto IL_0d08;
																						case 2:
																						case 3:
																						case 8:
																						case 18:
																						case 20:
																						case 31:
																						case 43:
																						case 53:
																						case 66:
																						case 67:
																						case 75:
																						case 79:
																						case 82:
																						case 90:
																						case 93:
																						case 101:
																						case 107:
																						case 113:
																						case 116:
																						case 124:
																						case 129:
																						case 145:
																						case 149:
																						case 166:
																							goto IL_0d16;
																						case 153:
																							goto IL_0d29;
																						case 51:
																							goto IL_0d33;
																						case 139:
																							goto IL_0d3e;
																						case 128:
																							goto IL_0d4e;
																						case 36:
																							goto IL_0d5e;
																						case 99:
																							goto IL_0d77;
																						case 69:
																							goto IL_0d87;
																						case 170:
																							goto IL_0d97;
																						case 40:
																							goto IL_0da7;
																						case 76:
																							goto IL_0db7;
																						case 111:
																							goto IL_0dd0;
																						case 30:
																						case 201:
																							goto IL_0deb;
																						}
																						break;
																					}
																					ptr2++;
																					num = 72;
																					goto IL_03a5;
																					IL_0bc6:
																					if (7 >= b)
																					{
																						goto IL_0bd4;
																					}
																					goto IL_0cd3;
																					IL_0d08:
																					ptr2 += 8;
																					goto IL_0d16;
																					IL_0bd4:
																					if (7 <= b)
																					{
																						goto IL_0bed;
																					}
																					num = 21;
																					goto IL_0cd3;
																					IL_03a5:
																					if (b >= 1)
																					{
																						goto IL_03b3;
																					}
																					goto IL_0cd3;
																					IL_03b3:
																					if (b <= 21)
																					{
																						goto IL_03c1;
																					}
																					goto IL_0cd3;
																					IL_03c1:
																					if (11 < b)
																					{
																						goto IL_03cf;
																					}
																					goto IL_084c;
																					IL_03cf:
																					if (16 < b)
																					{
																						goto IL_03dd;
																					}
																					goto IL_0594;
																					IL_03dd:
																					if (19 < b)
																					{
																						goto IL_03e8;
																					}
																					goto IL_0451;
																					IL_03e8:
																					if (20 >= b)
																					{
																						goto IL_03f3;
																					}
																					goto IL_0419;
																					IL_03f3:
																					if (20 <= b)
																					{
																						goto IL_0401;
																					}
																					goto IL_0cd3;
																					IL_0401:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_0d16;
																					IL_0419:
																					if (21 >= b)
																					{
																						goto IL_0427;
																					}
																					goto IL_0cd3;
																					IL_0427:
																					if (21 <= b)
																					{
																						goto IL_0435;
																					}
																					goto IL_0cd3;
																					IL_0435:
																					num6 = ptr2;
																					num7 = -200;
																					num5 = 1;
																					ptr2 = num6 + num7;
																					goto IL_0d16;
																					IL_0451:
																					if (19 <= b)
																					{
																						goto IL_045c;
																					}
																					goto IL_04a4;
																					IL_045c:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)(ptr2 + num4);
																					goto IL_0475;
																					IL_0475:
																					array2[num8] = 1;
																					goto IL_0483;
																					IL_0483:
																					num8++;
																					goto IL_0491;
																					IL_0491:
																					ptr2 += 16;
																					goto IL_0d16;
																					IL_04a4:
																					if (17 >= b)
																					{
																						goto IL_04af;
																					}
																					goto IL_0519;
																					IL_04af:
																					if (17 <= b)
																					{
																						goto IL_04ba;
																					}
																					num = 126;
																					goto IL_0cd3;
																					IL_04ba:
																					((string[])array3[num8 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2])] = (string)array3[num8 - 1];
																					goto IL_04f8;
																					IL_04f8:
																					num8 -= 3;
																					goto IL_0d16;
																					IL_0bed:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																					goto IL_0c2d;
																					IL_0519:
																					if (18 >= b)
																					{
																						goto IL_0527;
																					}
																					goto IL_0cd3;
																					IL_0527:
																					if (18 <= b)
																					{
																						goto IL_0535;
																					}
																					goto IL_0cd3;
																					IL_0535:
																					array2[num8 - 1] = 5;
																					goto IL_0549;
																					IL_0549:
																					array3[num8 - 1] = ((delegate*<string[], string>)BinaryBeq[*(int*)(ptr2 + num3)])((string[])array3[num8 - 1]);
																					goto IL_0581;
																					IL_0581:
																					ptr2 += 8;
																					goto IL_0d16;
																					IL_0594:
																					if (16 > b)
																					{
																						goto IL_05a2;
																					}
																					goto IL_0805;
																					IL_05a2:
																					if (13 >= b)
																					{
																						goto IL_05b0;
																					}
																					goto IL_0700;
																					IL_05b0:
																					if (13 <= b)
																					{
																						num = 148;
																						goto IL_05c4;
																					}
																					goto IL_0603;
																					IL_0c2d:
																					array2[num8 - 2] = 0;
																					goto IL_0c41;
																					IL_05c4:
																					array7[*(int*)(ptr2 + num3)] = array3[num8 - 1];
																					goto IL_05e2;
																					IL_05e2:
																					ptr2 += 8;
																					goto IL_05f0;
																					IL_05f0:
																					num8--;
																					goto IL_0d16;
																					IL_0603:
																					if (12 >= b)
																					{
																						num = 155;
																						goto IL_061a;
																					}
																					goto IL_0cd3;
																					IL_0c41:
																					num8--;
																					goto IL_0d16;
																					IL_061a:
																					if (12 <= b)
																					{
																						goto IL_0628;
																					}
																					goto IL_0cd3;
																					IL_0628:
																					array8 = array3;
																					num9 = num8;
																					if (array == null)
																					{
																						goto IL_0637;
																					}
																					num10 = ptr2;
																					byte b2 = *num10;
																					ptr2 = num10 + 4;
																					int num11 = *(int*)(ptr2 + num3);
																					ptr2 += 8;
																					byte* ptr3 = ptr2 + num11;
																					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																					while (ptr2 != ptr3)
																					{
																						*ptr4 = (byte)(*ptr2 ^ b2);
																						ptr2++;
																						ptr4++;
																					}
																					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																					goto IL_06df;
																					IL_0c54:
																					if (6 <= b)
																					{
																						goto IL_0c5f;
																					}
																					goto IL_0cd3;
																					IL_0c5f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																					goto IL_0c9f;
																					IL_0c9f:
																					array2[num8 - 2] = 0;
																					goto IL_0cb3;
																					IL_06df:
																					array2[num8] = 5;
																					goto IL_06ed;
																					IL_06ed:
																					num8++;
																					goto IL_0d16;
																					IL_0700:
																					if (14 >= b)
																					{
																						goto IL_070b;
																					}
																					goto IL_075b;
																					IL_070b:
																					if (14 <= b)
																					{
																						goto IL_0719;
																					}
																					goto IL_0cd3;
																					IL_0719:
																					array3[num8 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])];
																					goto IL_0742;
																					IL_0742:
																					array2[num8 - 1] = 5;
																					goto IL_0d16;
																					IL_075b:
																					if (15 >= b)
																					{
																						goto IL_0769;
																					}
																					goto IL_0cd3;
																					IL_0769:
																					if (15 <= b)
																					{
																						goto IL_0777;
																					}
																					goto IL_0cd3;
																					IL_0777:
																					array2[num8] = array2[num8 - 1];
																					goto IL_078f;
																					IL_078f:
																					array4[num8 - 0] = array4[num8 - 1];
																					goto IL_07ad;
																					IL_07ad:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																					goto IL_07d1;
																					IL_07d1:
																					array3[num8] = array3[num8 - 1];
																					num = 184;
																					goto IL_07f2;
																					IL_07f2:
																					num8++;
																					goto IL_0d16;
																					IL_0805:
																					array2[num8] = 5;
																					goto IL_0813;
																					IL_0813:
																					array3[num8] = array7[*(int*)(ptr2 + num3)];
																					goto IL_082b;
																					IL_082b:
																					num8++;
																					goto IL_0839;
																					IL_0839:
																					ptr2 += 8;
																					goto IL_0d16;
																					IL_084c:
																					if (11 <= b)
																					{
																						goto IL_0d16;
																					}
																					goto IL_085a;
																					IL_085a:
																					if (5 >= b)
																					{
																						num = 102;
																						goto IL_0871;
																					}
																					goto IL_0a76;
																					IL_0cb3:
																					num8--;
																					goto IL_0d16;
																					IL_0871:
																					if (5 <= b)
																					{
																						goto IL_087c;
																					}
																					num = 95;
																					goto IL_08ec;
																					IL_087c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																					goto IL_08bc;
																					IL_08bc:
																					array2[num8 - 2] = 0;
																					goto IL_08d0;
																					IL_08d0:
																					num8--;
																					goto IL_0d16;
																					IL_0cc3:
																					num8--;
																					goto IL_0d16;
																					IL_08ec:
																					if (2 < b)
																					{
																						goto IL_08fa;
																					}
																					goto IL_09e3;
																					IL_08fa:
																					if (3 < b)
																					{
																						goto IL_0908;
																					}
																					goto IL_098b;
																					IL_0908:
																					if (4 >= b)
																					{
																						goto IL_0921;
																					}
																					num = 104;
																					goto IL_0cd3;
																					IL_0cd3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(int*)(ptr2 + num3);
																					goto IL_0cec;
																					IL_0921:
																					if (4 <= b)
																					{
																						goto IL_092f;
																					}
																					goto IL_0cd3;
																					IL_092f:
																					array2[num8] = 0;
																					goto IL_093d;
																					IL_093d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = array5[*(int*)(ptr2 + num3)];
																					goto IL_0960;
																					IL_0960:
																					array3[num8] = null;
																					goto IL_096a;
																					IL_096a:
																					num8++;
																					goto IL_0978;
																					IL_0978:
																					ptr2 += 8;
																					goto IL_0d16;
																					IL_098b:
																					if (3 <= b)
																					{
																						goto IL_0999;
																					}
																					goto IL_0cd3;
																					IL_0999:
																					reference = ref array5[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																					goto IL_09c2;
																					IL_09c2:
																					ptr2 += 8;
																					goto IL_09d0;
																					IL_09d0:
																					num8--;
																					goto IL_0d16;
																					IL_09e3:
																					if (2 > b)
																					{
																						goto IL_09ee;
																					}
																					goto IL_0a0f;
																					IL_09ee:
																					if (1 >= b)
																					{
																						goto IL_09fc;
																					}
																					goto IL_0cd3;
																					IL_09fc:
																					if (1 <= b)
																					{
																					}
																					goto IL_0cd3;
																					IL_0a0f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																					goto IL_0a4f;
																					IL_0a4f:
																					array2[num8 - 2] = 0;
																					goto IL_0a63;
																					IL_0a63:
																					num8--;
																					goto IL_0d16;
																					IL_0a76:
																					if (8 < b)
																					{
																						goto IL_0a84;
																					}
																					goto IL_0baa;
																					IL_0a84:
																					if (9 < b)
																					{
																						goto IL_0a92;
																					}
																					goto IL_0b35;
																					IL_0a92:
																					if (10 >= b)
																					{
																						num = 89;
																						goto IL_0aa9;
																					}
																					goto IL_0cd3;
																					IL_0cec:
																					array2[num8] = 0;
																					goto IL_0cfa;
																					IL_0aa9:
																					if (10 <= b)
																					{
																						num = 9;
																						goto IL_0ac0;
																					}
																					goto IL_0cd3;
																					IL_0cfa:
																					num8++;
																					goto IL_0d08;
																					IL_0ac0:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0b22;
																					IL_0b22:
																					num8 -= 2;
																					goto IL_0d16;
																					IL_0b35:
																					if (9 <= b)
																					{
																						goto IL_0b43;
																					}
																					goto IL_0cd3;
																					IL_0b43:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																					goto IL_0b83;
																					IL_0b83:
																					array2[num8 - 2] = 0;
																					goto IL_0b97;
																					IL_0b97:
																					num8--;
																					goto IL_0d16;
																					IL_0baa:
																					if (8 > b)
																					{
																						goto IL_0bb8;
																					}
																					goto IL_0cc3;
																					IL_0bb8:
																					if (6 < b)
																					{
																						goto IL_0bc6;
																					}
																					goto IL_0c54;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0deb;
																	IL_0deb:
																	return (string)array3[num8 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0637:
				while (true)
				{
					IL_0637_2:
					array = new byte[4];
					while (true)
					{
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							IL_06df_2:
							array2[num8] = 5;
							while (true)
							{
								IL_06ed_2:
								num8++;
								while (true)
								{
									IL_0d16_2:
									if (num5 != 1)
									{
										while (true)
										{
											num = 60;
											while (true)
											{
												byte b = *ptr2;
												num = 212;
												while (true)
												{
													if (num != 212)
													{
														if (num != 1193)
														{
															goto IL_0594_2;
														}
														switch (num)
														{
														case 60:
															goto end_IL_035f;
														case 78:
															goto end_IL_036f;
														case 72:
															goto IL_03a5_2;
														case 6:
															goto IL_03b3_2;
														case 158:
															goto IL_03c1_2;
														case 52:
														case 122:
															goto IL_03cf_2;
														case 94:
															goto IL_03dd_2;
														case 50:
														case 173:
															goto IL_03e8_2;
														case 34:
															goto IL_03f3_2;
														case 19:
														case 26:
															goto IL_0401_2;
														case 108:
															goto IL_0419_2;
														case 163:
															goto IL_0427_2;
														case 45:
														case 119:
															goto IL_0435_2;
														case 199:
															goto IL_0451_2;
														case 103:
														case 185:
															goto IL_045c_2;
														case 29:
															goto IL_0475_2;
														case 24:
															goto IL_0483_2;
														case 162:
															goto IL_0491_2;
														case 47:
															goto IL_04a4_2;
														case 105:
															goto IL_04af_2;
														case 12:
														case 83:
															goto IL_04ba_2;
														case 117:
															goto IL_04f8_2;
														case 13:
															goto IL_0519_2;
														case 98:
															goto IL_0527_2;
														case 11:
														case 14:
															goto IL_0535_2;
														case 142:
															goto IL_0549_2;
														case 204:
															goto IL_0581_2;
														case 106:
															goto IL_0594_2;
														case 56:
														case 97:
															goto IL_05a2_2;
														case 188:
															goto IL_05b0_2;
														case 148:
														case 183:
															goto IL_05c4_2;
														case 144:
															goto IL_05e2_2;
														case 152:
															goto IL_05f0_2;
														case 121:
															goto IL_0603_2;
														case 155:
															goto IL_061a_2;
														case 32:
														case 135:
															goto end_IL_0383;
														case 74:
															goto IL_06df_2;
														case 35:
															goto IL_06ed_2;
														case 73:
															goto IL_0700_2;
														case 130:
															goto IL_070b_2;
														case 88:
														case 194:
															goto IL_0719_2;
														case 192:
															goto IL_0742_2;
														case 114:
															goto IL_075b_2;
														case 125:
															goto IL_0769_2;
														case 187:
														case 189:
															goto IL_0777_2;
														case 177:
															goto IL_078f_2;
														case 196:
															goto IL_07ad_2;
														case 1:
															goto IL_07d1_2;
														case 184:
															goto IL_07f2_2;
														case 96:
														case 195:
															goto IL_0805_2;
														case 65:
															goto IL_0813_2;
														case 203:
															goto IL_082b_2;
														case 137:
															goto IL_0839_2;
														case 165:
															goto IL_084c_2;
														case 38:
														case 49:
															goto IL_085a_2;
														case 102:
															goto IL_0871_2;
														case 22:
														case 164:
															goto IL_087c_2;
														case 54:
															goto IL_08bc_2;
														case 33:
															goto IL_08d0_2;
														case 95:
														case 134:
															goto IL_08ec_2;
														case 92:
														case 182:
															goto IL_08fa_2;
														case 109:
														case 123:
															goto IL_0908_2;
														case 127:
															goto IL_0921_2;
														case 15:
														case 146:
															goto IL_092f_2;
														case 115:
															goto IL_093d_2;
														case 198:
															goto IL_0960_2;
														case 197:
															goto IL_096a_2;
														case 138:
															goto IL_0978_2;
														case 167:
															goto IL_098b_2;
														case 58:
														case 181:
															goto IL_0999_2;
														case 202:
															goto IL_09c2_2;
														case 154:
															goto IL_09d0_2;
														case 133:
															goto IL_09e3_2;
														case 44:
														case 62:
															goto IL_09ee_2;
														case 46:
															goto IL_09fc_2;
														case 172:
														case 193:
															goto IL_0a0f_2;
														case 84:
															goto IL_0a4f_2;
														case 131:
															goto IL_0a63_2;
														case 70:
															goto IL_0a76_2;
														case 10:
														case 42:
															goto IL_0a84_2;
														case 86:
														case 156:
															goto IL_0a92_2;
														case 89:
															goto IL_0aa9_2;
														case 9:
														case 59:
															goto IL_0ac0_2;
														case 63:
															goto IL_0b22_2;
														case 200:
															goto IL_0b35_2;
														case 132:
														case 140:
															goto IL_0b43_2;
														case 118:
															goto IL_0b83_2;
														case 190:
															goto IL_0b97_2;
														case 71:
															goto IL_0baa_2;
														case 57:
															goto IL_0bb8_2;
														case 25:
														case 175:
															goto IL_0bc6_2;
														case 174:
															goto IL_0bd4_2;
														case 7:
														case 157:
															goto IL_0bed_2;
														case 205:
															goto IL_0c2d_2;
														case 159:
															goto IL_0c41_2;
														case 55:
															goto IL_0c54_2;
														case 150:
														case 169:
															goto IL_0c5f_2;
														case 80:
															goto IL_0c9f_2;
														case 191:
															goto IL_0cb3_2;
														case 61:
														case 180:
															goto IL_0cc3_2;
														case 0:
														case 4:
														case 5:
														case 17:
														case 21:
														case 23:
														case 28:
														case 37:
														case 39:
														case 41:
														case 48:
														case 64:
														case 68:
														case 77:
														case 81:
														case 85:
														case 87:
														case 91:
														case 104:
														case 110:
														case 120:
														case 126:
														case 136:
														case 141:
														case 143:
														case 147:
														case 151:
														case 160:
														case 161:
														case 168:
														case 171:
														case 176:
														case 178:
														case 179:
														case 186:
															goto IL_0cd3_2;
														case 16:
															goto IL_0cec_2;
														case 27:
															goto IL_0cfa_2;
														case 100:
															goto IL_0d08_2;
														case 2:
														case 3:
														case 8:
														case 18:
														case 20:
														case 31:
														case 43:
														case 53:
														case 66:
														case 67:
														case 75:
														case 79:
														case 82:
														case 90:
														case 93:
														case 101:
														case 107:
														case 113:
														case 116:
														case 124:
														case 129:
														case 145:
														case 149:
														case 166:
															goto IL_0d16_2;
														case 153:
															ptr2 = ptr;
															goto IL_0d16_2;
														case 51:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getNameClaimTypeSysUInt.GetServerTypeForUriIMembershipCondition);
															goto case 153;
														case 139:
															array7 = new object[13];
															goto case 51;
														case 128:
															array6 = new long[4];
															goto case 139;
														case 36:
															array5 = new int[6];
															num = 128;
															goto case 128;
														case 99:
															array4 = new int[4];
															goto case 36;
														case 69:
															array3 = new object[4];
															goto case 99;
														case 170:
															array2 = new byte[4];
															goto case 69;
														case 40:
															num4 = num2 * 8;
															goto case 170;
														case 76:
															num3 = num2 * 4;
															num = 40;
															goto case 40;
														case 111:
															num2 = 1;
															goto case 76;
														case 112:
															goto end_IL_0645;
														case 30:
														case 201:
															goto IL_0deb_2;
														}
														continue;
													}
													ptr2++;
													num = 72;
													goto IL_03a5_2;
													IL_0bed_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
													goto IL_0c2d_2;
													IL_0c41_2:
													num8--;
													goto IL_0d16_2;
													IL_0c2d_2:
													array2[num8 - 2] = 0;
													goto IL_0c41_2;
													IL_03a5_2:
													if (b >= 1)
													{
														goto IL_03b3_2;
													}
													goto IL_0cd3_2;
													IL_03b3_2:
													if (b <= 21)
													{
														goto IL_03c1_2;
													}
													goto IL_0cd3_2;
													IL_03c1_2:
													if (11 < b)
													{
														goto IL_03cf_2;
													}
													goto IL_084c_2;
													IL_03cf_2:
													if (16 < b)
													{
														goto IL_03dd_2;
													}
													goto IL_0594_2;
													IL_03dd_2:
													if (19 < b)
													{
														goto IL_03e8_2;
													}
													goto IL_0451_2;
													IL_03e8_2:
													if (20 >= b)
													{
														goto IL_03f3_2;
													}
													goto IL_0419_2;
													IL_03f3_2:
													if (20 <= b)
													{
														goto IL_0401_2;
													}
													goto IL_0cd3_2;
													IL_0401_2:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0d16_2;
													IL_0419_2:
													if (21 >= b)
													{
														goto IL_0427_2;
													}
													goto IL_0cd3_2;
													IL_0427_2:
													if (21 <= b)
													{
														goto IL_0435_2;
													}
													goto IL_0cd3_2;
													IL_0435_2:
													num6 = ptr2;
													num7 = -200;
													num5 = 1;
													ptr2 = num6 + num7;
													goto IL_0d16_2;
													IL_0451_2:
													if (19 <= b)
													{
														goto IL_045c_2;
													}
													goto IL_04a4_2;
													IL_045c_2:
													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)(ptr2 + num4);
													goto IL_0475_2;
													IL_0475_2:
													array2[num8] = 1;
													goto IL_0483_2;
													IL_0483_2:
													num8++;
													goto IL_0491_2;
													IL_0491_2:
													ptr2 += 16;
													goto IL_0d16_2;
													IL_04a4_2:
													if (17 >= b)
													{
														goto IL_04af_2;
													}
													goto IL_0519_2;
													IL_04af_2:
													if (17 <= b)
													{
														goto IL_04ba_2;
													}
													num = 126;
													goto IL_0cd3_2;
													IL_04ba_2:
													((string[])array3[num8 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2])] = (string)array3[num8 - 1];
													goto IL_04f8_2;
													IL_04f8_2:
													num8 -= 3;
													goto IL_0d16_2;
													IL_0c54_2:
													if (6 <= b)
													{
														goto IL_0c5f_2;
													}
													goto IL_0cd3_2;
													IL_0519_2:
													if (18 >= b)
													{
														goto IL_0527_2;
													}
													goto IL_0cd3_2;
													IL_0527_2:
													if (18 <= b)
													{
														goto IL_0535_2;
													}
													goto IL_0cd3_2;
													IL_0535_2:
													array2[num8 - 1] = 5;
													goto IL_0549_2;
													IL_0549_2:
													array3[num8 - 1] = ((delegate*<string[], string>)BinaryBeq[*(int*)(ptr2 + num3)])((string[])array3[num8 - 1]);
													goto IL_0581_2;
													IL_0581_2:
													ptr2 += 8;
													goto IL_0d16_2;
													IL_0594_2:
													if (16 > b)
													{
														goto IL_05a2_2;
													}
													goto IL_0805_2;
													IL_05a2_2:
													if (13 >= b)
													{
														goto IL_05b0_2;
													}
													goto IL_0700_2;
													IL_05b0_2:
													if (13 <= b)
													{
														num = 148;
														goto IL_05c4_2;
													}
													goto IL_0603_2;
													IL_0c5f_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
													goto IL_0c9f_2;
													IL_05c4_2:
													array7[*(int*)(ptr2 + num3)] = array3[num8 - 1];
													goto IL_05e2_2;
													IL_05e2_2:
													ptr2 += 8;
													goto IL_05f0_2;
													IL_05f0_2:
													num8--;
													goto IL_0d16_2;
													IL_0603_2:
													if (12 >= b)
													{
														num = 155;
														goto IL_061a_2;
													}
													goto IL_0cd3_2;
													IL_0c9f_2:
													array2[num8 - 2] = 0;
													goto IL_0cb3_2;
													IL_061a_2:
													if (12 <= b)
													{
														goto end_IL_0383;
													}
													goto IL_0cd3_2;
													IL_0700_2:
													if (14 >= b)
													{
														goto IL_070b_2;
													}
													goto IL_075b_2;
													IL_070b_2:
													if (14 <= b)
													{
														goto IL_0719_2;
													}
													goto IL_0cd3_2;
													IL_0719_2:
													array3[num8 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])];
													goto IL_0742_2;
													IL_0742_2:
													array2[num8 - 1] = 5;
													goto IL_0d16_2;
													IL_075b_2:
													if (15 >= b)
													{
														goto IL_0769_2;
													}
													goto IL_0cd3_2;
													IL_0769_2:
													if (15 <= b)
													{
														goto IL_0777_2;
													}
													goto IL_0cd3_2;
													IL_0777_2:
													array2[num8] = array2[num8 - 1];
													goto IL_078f_2;
													IL_078f_2:
													array4[num8 - 0] = array4[num8 - 1];
													goto IL_07ad_2;
													IL_07ad_2:
													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
													goto IL_07d1_2;
													IL_07d1_2:
													array3[num8] = array3[num8 - 1];
													num = 184;
													goto IL_07f2_2;
													IL_07f2_2:
													num8++;
													goto IL_0d16_2;
													IL_0805_2:
													array2[num8] = 5;
													goto IL_0813_2;
													IL_0813_2:
													array3[num8] = array7[*(int*)(ptr2 + num3)];
													goto IL_082b_2;
													IL_082b_2:
													num8++;
													goto IL_0839_2;
													IL_0839_2:
													ptr2 += 8;
													goto IL_0d16_2;
													IL_084c_2:
													if (11 <= b)
													{
														goto IL_0d16_2;
													}
													goto IL_085a_2;
													IL_085a_2:
													if (5 >= b)
													{
														num = 102;
														goto IL_0871_2;
													}
													goto IL_0a76_2;
													IL_0cb3_2:
													num8--;
													goto IL_0d16_2;
													IL_0871_2:
													if (5 <= b)
													{
														goto IL_087c_2;
													}
													num = 95;
													goto IL_08ec_2;
													IL_087c_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
													goto IL_08bc_2;
													IL_08bc_2:
													array2[num8 - 2] = 0;
													goto IL_08d0_2;
													IL_08d0_2:
													num8--;
													goto IL_0d16_2;
													IL_0cc3_2:
													num8--;
													goto IL_0d16_2;
													IL_08ec_2:
													if (2 < b)
													{
														goto IL_08fa_2;
													}
													goto IL_09e3_2;
													IL_08fa_2:
													if (3 < b)
													{
														goto IL_0908_2;
													}
													goto IL_098b_2;
													IL_0908_2:
													if (4 >= b)
													{
														goto IL_0921_2;
													}
													num = 104;
													goto IL_0cd3_2;
													IL_0cd3_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(int*)(ptr2 + num3);
													goto IL_0cec_2;
													IL_0921_2:
													if (4 <= b)
													{
														goto IL_092f_2;
													}
													goto IL_0cd3_2;
													IL_092f_2:
													array2[num8] = 0;
													goto IL_093d_2;
													IL_093d_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = array5[*(int*)(ptr2 + num3)];
													goto IL_0960_2;
													IL_0960_2:
													array3[num8] = null;
													goto IL_096a_2;
													IL_096a_2:
													num8++;
													goto IL_0978_2;
													IL_0978_2:
													ptr2 += 8;
													goto IL_0d16_2;
													IL_098b_2:
													if (3 <= b)
													{
														goto IL_0999_2;
													}
													goto IL_0cd3_2;
													IL_0999_2:
													reference = ref array5[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
													goto IL_09c2_2;
													IL_09c2_2:
													ptr2 += 8;
													goto IL_09d0_2;
													IL_09d0_2:
													num8--;
													goto IL_0d16_2;
													IL_09e3_2:
													if (2 > b)
													{
														goto IL_09ee_2;
													}
													goto IL_0a0f_2;
													IL_09ee_2:
													if (1 >= b)
													{
														goto IL_09fc_2;
													}
													goto IL_0cd3_2;
													IL_09fc_2:
													if (1 <= b)
													{
													}
													goto IL_0cd3_2;
													IL_0a0f_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
													goto IL_0a4f_2;
													IL_0a4f_2:
													array2[num8 - 2] = 0;
													goto IL_0a63_2;
													IL_0a63_2:
													num8--;
													goto IL_0d16_2;
													IL_0a76_2:
													if (8 < b)
													{
														goto IL_0a84_2;
													}
													goto IL_0baa_2;
													IL_0a84_2:
													if (9 < b)
													{
														goto IL_0a92_2;
													}
													goto IL_0b35_2;
													IL_0a92_2:
													if (10 >= b)
													{
														num = 89;
														goto IL_0aa9_2;
													}
													goto IL_0cd3_2;
													IL_0cec_2:
													array2[num8] = 0;
													goto IL_0cfa_2;
													IL_0aa9_2:
													if (10 <= b)
													{
														num = 9;
														goto IL_0ac0_2;
													}
													goto IL_0cd3_2;
													IL_0cfa_2:
													num8++;
													goto IL_0d08_2;
													IL_0ac0_2:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_0b22_2;
													IL_0b22_2:
													num8 -= 2;
													goto IL_0d16_2;
													IL_0b35_2:
													if (9 <= b)
													{
														goto IL_0b43_2;
													}
													goto IL_0cd3_2;
													IL_0b43_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
													goto IL_0b83_2;
													IL_0b83_2:
													array2[num8 - 2] = 0;
													goto IL_0b97_2;
													IL_0b97_2:
													num8--;
													goto IL_0d16_2;
													IL_0baa_2:
													if (8 > b)
													{
														goto IL_0bb8_2;
													}
													goto IL_0cc3_2;
													IL_0bb8_2:
													if (6 < b)
													{
														goto IL_0bc6_2;
													}
													goto IL_0c54_2;
													IL_0bc6_2:
													if (7 >= b)
													{
														goto IL_0bd4_2;
													}
													goto IL_0cd3_2;
													IL_0bd4_2:
													if (7 <= b)
													{
														goto IL_0bed_2;
													}
													num = 21;
													goto IL_0cd3_2;
													IL_0d08_2:
													ptr2 += 8;
													goto IL_0d16_2;
													continue;
													end_IL_035f:
													break;
												}
												continue;
												end_IL_036f:
												break;
											}
											continue;
											end_IL_0383:
											break;
										}
										break;
									}
									goto IL_0deb_2;
									IL_0deb_2:
									return (string)array3[num8 - 1];
								}
								break;
							}
							break;
						}
						array8 = array3;
						num9 = num8;
						if (array == null)
						{
							goto IL_0637_2;
						}
						continue;
						end_IL_0645:
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0389, IL_039c, IL_03af, IL_03bf, IL_03cf, IL_03df, IL_03ef, IL_03fc, IL_040c, IL_041c, IL_042c, IL_0437, IL_0445, IL_0453, IL_045e, IL_046e, IL_047c, IL_048a, IL_04b5, IL_04c3, IL_04d1, IL_04e4, IL_04f2, IL_050a, IL_0518, IL_052b, IL_0544, IL_0557, IL_0562, IL_056d, IL_057b, IL_0593, IL_05a1, IL_05af, IL_05cb, IL_05d9, IL_05e4, IL_05f2, IL_0630, IL_0643, IL_0651, IL_065f, IL_0673, IL_06ab, IL_06be, IL_06d7, IL_06e5, IL_06f3, IL_0706, IL_0714, IL_0722, IL_073a, IL_0758, IL_077c, IL_0799, IL_07ad, IL_0801, IL_080f, IL_0822, IL_0840, IL_084e, IL_0861, IL_087e, IL_08cd, IL_08d7, IL_0904, IL_0918, IL_0926, IL_0939, IL_094c, IL_098c, IL_09a0, IL_09b3, IL_09c1, IL_09ca, IL_09dd, IL_09e8, IL_09f6, IL_0a1f, IL_0a36, IL_0a52, IL_0a60, IL_0a6e, IL_0a7c, IL_0a9f, IL_0aa9, IL_0ac0, IL_0ad3, IL_0b13, IL_0b27, IL_0b3a, IL_0b48, IL_0b56, IL_0b61, IL_0b6f, IL_0baf, IL_0bc3, IL_0bd6, IL_0be4, IL_0bf2, IL_0c32, IL_0c46, IL_0c62, IL_0c75, IL_0c80, IL_0c8e, IL_0cce, IL_0ce2, IL_0cf5, IL_0d00, IL_0d0b, IL_0d6d, IL_0d7d, IL_0d96, IL_0da4, IL_0db2, IL_0dc0, IL_0dd3, IL_0ddd, IL_0de8, IL_0df8, IL_0e08, IL_0e18, IL_0e28, IL_0e38, IL_0e48, IL_0e58, IL_0e68, IL_0e83 are reachable both inside and outside the pinned region starting at IL_0e7d. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 144;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef27 = default(int);
				ref int reference = ref __rxRef27;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e68:
						num2 = 1;
						while (true)
						{
							IL_0e58:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e48:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e38:
									array2 = new byte[4];
									while (true)
									{
										IL_0e28:
										array3 = new object[4];
										while (true)
										{
											IL_0e18:
											array4 = new int[4];
											while (true)
											{
												IL_0e08:
												array5 = new int[6];
												while (true)
												{
													IL_0df8:
													array6 = new long[4];
													while (true)
													{
														IL_0de8:
														array7 = new object[13];
														while (true)
														{
															IL_0ddd:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CheckSubTreePermissionCharUnknown.AssemblyNameProxyResourceTypeIdString);
															while (true)
															{
																IL_0dd3:
																ptr2 = ptr;
																while (true)
																{
																	IL_0dc0:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_042c:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_041c:
																				ptr2++;
																				while (true)
																				{
																					IL_040c:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_03ef:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_03df:
																										if (11 > b)
																										{
																											while (true)
																											{
																												IL_03cf:
																												if (5 >= b)
																												{
																													while (true)
																													{
																														IL_03bf:
																														if (5 > b)
																														{
																															while (true)
																															{
																																IL_03af:
																																if (2 >= b)
																																{
																																	while (true)
																																	{
																																		IL_039c:
																																		if (2 <= b)
																																		{
																																			num = 219;
																																			while (true)
																																			{
																																				if (num != 219)
																																				{
																																					if (num != 1200)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 144:
																																						break;
																																					default:
																																						continue;
																																					case 87:
																																						goto IL_039c;
																																					case 22:
																																					case 145:
																																						goto IL_03af;
																																					case 4:
																																						goto IL_03bf;
																																					case 116:
																																						goto IL_03cf;
																																					case 73:
																																						goto IL_03df;
																																					case 149:
																																						goto IL_03ef;
																																					case 196:
																																						goto IL_03fc;
																																					case 138:
																																						goto IL_040c;
																																					case 206:
																																						goto IL_041c;
																																					case 126:
																																					case 172:
																																						goto IL_042c;
																																					case 17:
																																					case 38:
																																						goto IL_0437;
																																					case 109:
																																						goto IL_0445;
																																					case 84:
																																					case 153:
																																						goto IL_0453;
																																					case 131:
																																						goto IL_045e;
																																					case 154:
																																						goto IL_046e;
																																					case 99:
																																						goto IL_047c;
																																					case 55:
																																					case 164:
																																						goto IL_048a;
																																					case 69:
																																					case 174:
																																						goto IL_04b5;
																																					case 47:
																																						goto IL_04c3;
																																					case 91:
																																						goto IL_04d1;
																																					case 33:
																																					case 180:
																																						goto IL_04e4;
																																					case 104:
																																						goto IL_04f2;
																																					case 112:
																																						goto IL_050a;
																																					case 37:
																																						goto IL_0518;
																																					case 183:
																																						goto IL_052b;
																																					case 185:
																																						goto IL_0544;
																																					case 78:
																																					case 189:
																																						goto IL_0557;
																																					case 48:
																																					case 146:
																																						goto IL_0562;
																																					case 166:
																																						goto IL_056d;
																																					case 21:
																																					case 169:
																																						goto IL_057b;
																																					case 117:
																																						goto IL_0593;
																																					case 39:
																																						goto IL_05a1;
																																					case 105:
																																					case 165:
																																						goto IL_05af;
																																					case 60:
																																						goto IL_05cb;
																																					case 63:
																																					case 103:
																																						goto IL_05d9;
																																					case 186:
																																						goto IL_05e4;
																																					case 18:
																																					case 24:
																																						goto IL_05f2;
																																					case 85:
																																						goto IL_0630;
																																					case 75:
																																						goto IL_0643;
																																					case 119:
																																						goto IL_0651;
																																					case 1:
																																					case 2:
																																						goto IL_065f;
																																					case 178:
																																						goto IL_0673;
																																					case 30:
																																						goto IL_06ab;
																																					case 64:
																																					case 101:
																																						goto IL_06be;
																																					case 161:
																																						goto IL_06d7;
																																					case 10:
																																						goto IL_06e5;
																																					case 159:
																																						goto IL_06f3;
																																					case 194:
																																						goto IL_0706;
																																					case 56:
																																						goto IL_0714;
																																					case 83:
																																					case 134:
																																						goto IL_0722;
																																					case 115:
																																						goto IL_073a;
																																					case 12:
																																						goto IL_0758;
																																					case 57:
																																						goto IL_077c;
																																					case 49:
																																					case 199:
																																						goto IL_0799;
																																					case 182:
																																						goto IL_07ad;
																																					case 157:
																																						goto IL_0801;
																																					case 43:
																																						goto IL_080f;
																																					case 148:
																																					case 200:
																																						goto IL_0822;
																																					case 170:
																																						goto IL_0840;
																																					case 74:
																																						goto IL_084e;
																																					case 5:
																																					case 207:
																																						goto IL_0861;
																																					case 198:
																																						goto IL_0918;
																																					case 14:
																																						goto IL_0926;
																																					case 209:
																																						goto IL_0939;
																																					case 90:
																																						goto IL_094c;
																																					case 23:
																																						goto IL_098c;
																																					case 197:
																																						goto IL_09a0;
																																					case 191:
																																						goto IL_09b3;
																																					case 151:
																																						goto IL_09ca;
																																					case 96:
																																						goto IL_09dd;
																																					case 28:
																																						goto IL_09e8;
																																					case 202:
																																					case 208:
																																						goto IL_09f6;
																																					case 19:
																																						goto IL_0a1f;
																																					case 67:
																																						goto IL_0a36;
																																					case 155:
																																						goto IL_0a52;
																																					case 121:
																																						goto IL_0a60;
																																					case 29:
																																					case 212:
																																						goto IL_0a6e;
																																					case 135:
																																						goto IL_0a7c;
																																					case 93:
																																						goto IL_0a9f;
																																					case 62:
																																						goto IL_0aa9;
																																					case 129:
																																						goto IL_0ac0;
																																					case 122:
																																					case 171:
																																						goto IL_0ad3;
																																					case 107:
																																						goto IL_0b13;
																																					case 79:
																																						goto IL_0b27;
																																					case 102:
																																						goto IL_0b3a;
																																					case 156:
																																						goto IL_0b48;
																																					case 40:
																																					case 80:
																																						goto IL_0b56;
																																					case 27:
																																						goto IL_0b61;
																																					case 8:
																																					case 201:
																																						goto IL_0b6f;
																																					case 120:
																																						goto IL_0baf;
																																					case 140:
																																						goto IL_0bc3;
																																					case 61:
																																						goto IL_0bd6;
																																					case 123:
																																						goto IL_0be4;
																																					case 53:
																																					case 132:
																																						goto IL_0bf2;
																																					case 0:
																																						goto IL_0c32;
																																					case 106:
																																						goto IL_0c46;
																																					case 11:
																																					case 210:
																																						goto IL_0c62;
																																					case 95:
																																						goto IL_0c75;
																																					case 173:
																																						goto IL_0c80;
																																					case 9:
																																					case 98:
																																						goto IL_0c8e;
																																					case 100:
																																						goto IL_0cce;
																																					case 125:
																																						goto IL_0ce2;
																																					case 108:
																																						goto IL_0cf5;
																																					case 195:
																																						goto IL_0d00;
																																					case 77:
																																					case 130:
																																						goto IL_0d0b;
																																					case 86:
																																						goto IL_0d6d;
																																					case 7:
																																					case 15:
																																					case 25:
																																					case 34:
																																					case 41:
																																					case 50:
																																					case 51:
																																					case 54:
																																					case 58:
																																					case 59:
																																					case 70:
																																					case 72:
																																					case 76:
																																					case 92:
																																					case 113:
																																					case 114:
																																					case 118:
																																					case 124:
																																					case 127:
																																					case 133:
																																					case 136:
																																					case 137:
																																					case 142:
																																					case 150:
																																					case 152:
																																					case 162:
																																					case 167:
																																					case 176:
																																					case 179:
																																					case 181:
																																					case 187:
																																					case 188:
																																					case 190:
																																					case 203:
																																					case 204:
																																					case 205:
																																					case 211:
																																						goto end_IL_0389;
																																					case 139:
																																						goto IL_0d96;
																																					case 35:
																																						goto IL_0da4;
																																					case 81:
																																						goto IL_0db2;
																																					case 3:
																																					case 6:
																																					case 16:
																																					case 26:
																																					case 32:
																																					case 36:
																																					case 45:
																																					case 46:
																																					case 52:
																																					case 65:
																																					case 66:
																																					case 68:
																																					case 71:
																																					case 88:
																																					case 94:
																																					case 97:
																																					case 110:
																																					case 111:
																																					case 128:
																																					case 141:
																																					case 147:
																																					case 160:
																																					case 163:
																																					case 168:
																																					case 193:
																																						goto IL_0dc0;
																																					case 20:
																																						goto IL_0dd3;
																																					case 192:
																																						goto IL_0ddd;
																																					case 42:
																																						goto IL_0de8;
																																					case 175:
																																						goto IL_0df8;
																																					case 184:
																																						goto IL_0e08;
																																					case 177:
																																						goto IL_0e18;
																																					case 44:
																																						goto IL_0e28;
																																					case 82:
																																						goto IL_0e38;
																																					case 31:
																																						goto IL_0e48;
																																					case 13:
																																						goto IL_0e58;
																																					case 143:
																																						goto IL_0e68;
																																					case 89:
																																					case 158:
																																						goto IL_0e83;
																																					}
																																					goto end_IL_040c;
																																				}
																																				goto IL_094c;
																																				IL_098c:
																																				array2[num6 - 2] = 0;
																																				goto IL_09a0;
																																				IL_09a0:
																																				num6--;
																																				goto IL_0dc0;
																																				IL_094c:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																				goto IL_098c;
																																				continue;
																																				end_IL_0389:
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_09b3;
																																		IL_09b3:
																																		if (1 < b)
																																		{
																																			break;
																																		}
																																		num = 151;
																																		goto IL_09ca;
																																		IL_09ca:
																																		if (1 <= b)
																																		{
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_09dd;
																																IL_0ac0:
																																ptr2 += 8;
																																goto IL_0dc0;
																																IL_09dd:
																																if (3 >= b)
																																{
																																	goto IL_09e8;
																																}
																																goto IL_0a52;
																																IL_09e8:
																																if (3 > b)
																																{
																																	break;
																																}
																																goto IL_09f6;
																																IL_09f6:
																																reference = ref array5[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0a1f;
																																IL_0a1f:
																																ptr2 += 8;
																																num = 67;
																																goto IL_0a36;
																																IL_0a36:
																																num6--;
																																num = 52;
																																goto IL_0dc0;
																																IL_0a52:
																																if (4 < b)
																																{
																																	break;
																																}
																																goto IL_0a60;
																																IL_0a60:
																																if (4 > b)
																																{
																																	break;
																																}
																																goto IL_0a6e;
																																IL_0a6e:
																																array2[num6] = 0;
																																goto IL_0a7c;
																																IL_0a7c:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																goto IL_0a9f;
																																IL_0a9f:
																																array3[num6] = null;
																																goto IL_0aa9;
																																IL_0aa9:
																																num6++;
																																num = 129;
																																goto IL_0ac0;
																															}
																															break;
																														}
																														goto IL_0ad3;
																														IL_0b27:
																														num6--;
																														goto IL_0dc0;
																														IL_0ad3:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_0b13;
																														IL_0b13:
																														array2[num6 - 2] = 0;
																														goto IL_0b27;
																													}
																													break;
																												}
																												goto IL_0b3a;
																												IL_0d6d:
																												num6 -= 2;
																												goto IL_0dc0;
																												IL_0b3a:
																												if (8 >= b)
																												{
																													goto IL_0b48;
																												}
																												goto IL_0c75;
																												IL_0b48:
																												if (8 > b)
																												{
																													goto IL_0b56;
																												}
																												goto IL_0c62;
																												IL_0b56:
																												if (6 >= b)
																												{
																													goto IL_0b61;
																												}
																												goto IL_0bd6;
																												IL_0b61:
																												if (6 > b)
																												{
																													break;
																												}
																												goto IL_0b6f;
																												IL_0b6f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0baf;
																												IL_0baf:
																												array2[num6 - 2] = 0;
																												goto IL_0bc3;
																												IL_0bc3:
																												num6--;
																												goto IL_0dc0;
																												IL_0bd6:
																												if (7 < b)
																												{
																													break;
																												}
																												goto IL_0be4;
																												IL_0be4:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_0bf2;
																												IL_0bf2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0c32;
																												IL_0c32:
																												array2[num6 - 2] = 0;
																												goto IL_0c46;
																												IL_0c46:
																												num6--;
																												num = 168;
																												goto IL_0dc0;
																												IL_0c62:
																												num6--;
																												goto IL_0dc0;
																												IL_0c75:
																												if (9 >= b)
																												{
																													goto IL_0c80;
																												}
																												goto IL_0cf5;
																												IL_0c80:
																												if (9 > b)
																												{
																													break;
																												}
																												goto IL_0c8e;
																												IL_0c8e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0cce;
																												IL_0cce:
																												array2[num6 - 2] = 0;
																												goto IL_0ce2;
																												IL_0ce2:
																												num6--;
																												goto IL_0dc0;
																												IL_0cf5:
																												if (10 < b)
																												{
																													break;
																												}
																												goto IL_0d00;
																												IL_0d00:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_0d0b;
																												IL_0d0b:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0d6d;
																											}
																											break;
																										}
																										goto IL_0799;
																										IL_080f:
																										ptr2 += 8;
																										goto IL_0dc0;
																										IL_0799:
																										array2[num6 - 2] = 0;
																										goto IL_07ad;
																										IL_07ad:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)ActivatorLevelIIDIDefinitionIdentity[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_0801;
																										IL_0801:
																										num6--;
																										goto IL_080f;
																									}
																									break;
																								}
																								goto IL_0437;
																								IL_06be:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_06d7;
																								IL_0437:
																								if (17 >= b)
																								{
																									goto IL_0445;
																								}
																								goto IL_0557;
																								IL_0445:
																								if (17 > b)
																								{
																									goto IL_0453;
																								}
																								goto IL_04e4;
																								IL_0453:
																								if (14 >= b)
																								{
																									goto IL_045e;
																								}
																								goto IL_046e;
																								IL_045e:
																								if (14 > b)
																								{
																									goto IL_04b5;
																								}
																								goto IL_0822;
																								IL_04b5:
																								if (12 < b)
																								{
																									goto IL_04c3;
																								}
																								goto IL_0544;
																								IL_04c3:
																								if (13 < b)
																								{
																									break;
																								}
																								goto IL_04d1;
																								IL_04d1:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_0861;
																								IL_0861:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_0870;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0918;
																								IL_06d7:
																								array2[num6] = 1;
																								goto IL_06e5;
																								IL_06e5:
																								num6++;
																								goto IL_06f3;
																								IL_06f3:
																								ptr2 += 16;
																								goto IL_0dc0;
																								IL_0918:
																								array2[num6] = 5;
																								goto IL_0926;
																								IL_0926:
																								num6++;
																								goto IL_0dc0;
																								IL_0544:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_0dc0;
																								IL_0822:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0840;
																								IL_0840:
																								ptr2 += 8;
																								goto IL_084e;
																								IL_084e:
																								num6--;
																								goto IL_0dc0;
																								IL_046e:
																								if (15 >= b)
																								{
																									goto IL_047c;
																								}
																								goto IL_0706;
																								IL_047c:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_048a;
																								IL_048a:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_052b;
																								IL_052b:
																								array2[num6 - 1] = 5;
																								goto IL_0dc0;
																								IL_0706:
																								if (16 < b)
																								{
																									break;
																								}
																								goto IL_0714;
																								IL_0714:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_0722;
																								IL_0722:
																								array2[num6] = array2[num6 - 1];
																								goto IL_073a;
																								IL_073a:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_0758;
																								IL_0758:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_077c;
																								IL_077c:
																								array3[num6] = array3[num6 - 1];
																								goto IL_0939;
																								IL_0939:
																								num6++;
																								goto IL_0dc0;
																								IL_04e4:
																								array2[num6] = 5;
																								goto IL_04f2;
																								IL_04f2:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_050a;
																								IL_050a:
																								num6++;
																								goto IL_0518;
																								IL_0518:
																								ptr2 += 8;
																								goto IL_0dc0;
																								IL_0557:
																								if (20 < b)
																								{
																									goto IL_0562;
																								}
																								goto IL_05cb;
																								IL_0562:
																								if (21 >= b)
																								{
																									goto IL_056d;
																								}
																								goto IL_0593;
																								IL_056d:
																								if (21 > b)
																								{
																									break;
																								}
																								goto IL_057b;
																								IL_057b:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto IL_0dc0;
																								IL_0593:
																								if (22 < b)
																								{
																									break;
																								}
																								goto IL_05a1;
																								IL_05a1:
																								if (22 > b)
																								{
																									break;
																								}
																								goto IL_05af;
																								IL_05af:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto IL_0dc0;
																								IL_05cb:
																								if (20 > b)
																								{
																									goto IL_05d9;
																								}
																								goto IL_06be;
																								IL_05d9:
																								if (18 >= b)
																								{
																									goto IL_05e4;
																								}
																								goto IL_0643;
																								IL_05e4:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_05f2;
																								IL_05f2:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_0630;
																								IL_0630:
																								num6 -= 3;
																								goto IL_0dc0;
																								IL_0643:
																								if (19 < b)
																								{
																									break;
																								}
																								goto IL_0651;
																								IL_0651:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_065f;
																								IL_065f:
																								array2[num6 - 1] = 5;
																								goto IL_0673;
																								IL_0673:
																								array3[num6 - 1] = ((delegate*<string[], string>)ActivatorLevelIIDIDefinitionIdentity[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_06ab;
																								IL_06ab:
																								ptr2 += 8;
																								goto IL_0dc0;
																							}
																							break;
																							IL_03fc:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0d96;
																					IL_0db2:
																					ptr2 += 8;
																					goto IL_0dc0;
																					IL_0da4:
																					num6++;
																					goto IL_0db2;
																					IL_0d96:
																					array2[num6] = 0;
																					goto IL_0da4;
																					continue;
																					end_IL_040c:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0e83;
																	IL_0e83:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0870:
				while (true)
				{
					IL_0870_2:
					array = new byte[4];
					while (true)
					{
						IL_087e:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0926_2:
								num6++;
								while (true)
								{
									IL_0dc0_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_040c_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_03ef_2:
																if (11 >= b)
																{
																	while (true)
																	{
																		IL_03df_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_03cf_2:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_03bf_2:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_03af_2:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_039c_2:
																										if (2 <= b)
																										{
																											num = 219;
																											while (true)
																											{
																												if (num != 219)
																												{
																													if (num != 1200)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 87:
																														goto IL_039c_2;
																													case 22:
																													case 145:
																														goto IL_03af_2;
																													case 4:
																														goto IL_03bf_2;
																													case 116:
																														goto IL_03cf_2;
																													case 73:
																														goto IL_03df_2;
																													case 149:
																														goto IL_03ef_2;
																													case 196:
																														goto IL_03fc_2;
																													case 138:
																														goto IL_040c_2;
																													case 206:
																														goto end_IL_040c_2;
																													case 126:
																													case 172:
																														goto end_IL_041c;
																													case 17:
																													case 38:
																														goto IL_0437_2;
																													case 109:
																														goto IL_0445_2;
																													case 84:
																													case 153:
																														goto IL_0453_2;
																													case 131:
																														goto IL_045e_2;
																													case 154:
																														goto IL_046e_2;
																													case 99:
																														goto IL_047c_2;
																													case 55:
																													case 164:
																														goto IL_048a_2;
																													case 69:
																													case 174:
																														goto IL_04b5_2;
																													case 47:
																														goto IL_04c3_2;
																													case 91:
																														goto IL_04d1_2;
																													case 33:
																													case 180:
																														goto IL_04e4_2;
																													case 104:
																														goto IL_04f2_2;
																													case 112:
																														goto IL_050a_2;
																													case 37:
																														goto IL_0518_2;
																													case 183:
																														goto IL_052b_2;
																													case 185:
																														goto IL_0544_2;
																													case 78:
																													case 189:
																														goto IL_0557_2;
																													case 48:
																													case 146:
																														goto IL_0562_2;
																													case 166:
																														goto IL_056d_2;
																													case 21:
																													case 169:
																														goto IL_057b_2;
																													case 117:
																														goto IL_0593_2;
																													case 39:
																														goto IL_05a1_2;
																													case 105:
																													case 165:
																														goto IL_05af_2;
																													case 60:
																														goto IL_05cb_2;
																													case 63:
																													case 103:
																														goto IL_05d9_2;
																													case 186:
																														goto IL_05e4_2;
																													case 18:
																													case 24:
																														goto IL_05f2_2;
																													case 85:
																														goto IL_0630_2;
																													case 75:
																														goto IL_0643_2;
																													case 119:
																														goto IL_0651_2;
																													case 1:
																													case 2:
																														goto IL_065f_2;
																													case 178:
																														goto IL_0673_2;
																													case 30:
																														goto IL_06ab_2;
																													case 64:
																													case 101:
																														goto IL_06be_2;
																													case 161:
																														goto IL_06d7_2;
																													case 10:
																														goto IL_06e5_2;
																													case 159:
																														goto IL_06f3_2;
																													case 194:
																														goto IL_0706_2;
																													case 56:
																														goto IL_0714_2;
																													case 83:
																													case 134:
																														goto IL_0722_2;
																													case 115:
																														goto IL_073a_2;
																													case 12:
																														goto IL_0758_2;
																													case 57:
																														goto IL_077c_2;
																													case 49:
																													case 199:
																														goto IL_0799_2;
																													case 182:
																														goto IL_07ad_2;
																													case 157:
																														goto IL_0801_2;
																													case 43:
																														goto IL_080f_2;
																													case 148:
																													case 200:
																														goto IL_0822_2;
																													case 170:
																														goto IL_0840_2;
																													case 74:
																														goto IL_084e_2;
																													case 5:
																													case 207:
																														goto IL_0861_2;
																													case 198:
																														goto end_IL_042c;
																													case 14:
																														goto IL_0926_2;
																													case 209:
																														goto IL_0939_2;
																													case 90:
																														goto IL_094c_2;
																													case 23:
																														goto IL_098c_2;
																													case 197:
																														goto IL_09a0_2;
																													case 191:
																														goto IL_09b3_2;
																													case 151:
																														goto IL_09ca_2;
																													case 96:
																														goto IL_09dd_2;
																													case 28:
																														goto IL_09e8_2;
																													case 202:
																													case 208:
																														goto IL_09f6_2;
																													case 19:
																														goto IL_0a1f_2;
																													case 67:
																														goto IL_0a36_2;
																													case 155:
																														goto IL_0a52_2;
																													case 121:
																														goto IL_0a60_2;
																													case 29:
																													case 212:
																														goto IL_0a6e_2;
																													case 135:
																														goto IL_0a7c_2;
																													case 93:
																														goto IL_0a9f_2;
																													case 62:
																														goto IL_0aa9_2;
																													case 129:
																														goto IL_0ac0_2;
																													case 122:
																													case 171:
																														goto IL_0ad3_2;
																													case 107:
																														goto IL_0b13_2;
																													case 79:
																														goto IL_0b27_2;
																													case 102:
																														goto IL_0b3a_2;
																													case 156:
																														goto IL_0b48_2;
																													case 40:
																													case 80:
																														goto IL_0b56_2;
																													case 27:
																														goto IL_0b61_2;
																													case 8:
																													case 201:
																														goto IL_0b6f_2;
																													case 120:
																														goto IL_0baf_2;
																													case 140:
																														goto IL_0bc3_2;
																													case 61:
																														goto IL_0bd6_2;
																													case 123:
																														goto IL_0be4_2;
																													case 53:
																													case 132:
																														goto IL_0bf2_2;
																													case 0:
																														goto IL_0c32_2;
																													case 106:
																														goto IL_0c46_2;
																													case 11:
																													case 210:
																														goto IL_0c62_2;
																													case 95:
																														goto IL_0c75_2;
																													case 173:
																														goto IL_0c80_2;
																													case 9:
																													case 98:
																														goto IL_0c8e_2;
																													case 100:
																														goto IL_0cce_2;
																													case 125:
																														goto IL_0ce2_2;
																													case 108:
																														goto IL_0cf5_2;
																													case 195:
																														goto IL_0d00_2;
																													case 77:
																													case 130:
																														goto IL_0d0b_2;
																													case 86:
																														goto IL_0d6d_2;
																													case 7:
																													case 15:
																													case 25:
																													case 34:
																													case 41:
																													case 50:
																													case 51:
																													case 54:
																													case 58:
																													case 59:
																													case 70:
																													case 72:
																													case 76:
																													case 92:
																													case 113:
																													case 114:
																													case 118:
																													case 124:
																													case 127:
																													case 133:
																													case 136:
																													case 137:
																													case 142:
																													case 150:
																													case 152:
																													case 162:
																													case 167:
																													case 176:
																													case 179:
																													case 181:
																													case 187:
																													case 188:
																													case 190:
																													case 203:
																													case 204:
																													case 205:
																													case 211:
																														goto end_IL_0389_2;
																													case 139:
																														goto IL_0d96_2;
																													case 35:
																														goto IL_0da4_2;
																													case 81:
																														goto IL_0db2_2;
																													case 3:
																													case 6:
																													case 16:
																													case 26:
																													case 32:
																													case 36:
																													case 45:
																													case 46:
																													case 52:
																													case 65:
																													case 66:
																													case 68:
																													case 71:
																													case 88:
																													case 94:
																													case 97:
																													case 110:
																													case 111:
																													case 128:
																													case 141:
																													case 147:
																													case 160:
																													case 163:
																													case 168:
																													case 193:
																														goto IL_0dc0_2;
																													case 20:
																														ptr2 = ptr;
																														goto IL_0dc0_2;
																													case 192:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CheckSubTreePermissionCharUnknown.AssemblyNameProxyResourceTypeIdString);
																														goto case 20;
																													case 42:
																														array7 = new object[13];
																														goto case 192;
																													case 175:
																														array6 = new long[4];
																														goto case 42;
																													case 184:
																														array5 = new int[6];
																														goto case 175;
																													case 177:
																														array4 = new int[4];
																														goto case 184;
																													case 44:
																														array3 = new object[4];
																														goto case 177;
																													case 82:
																														array2 = new byte[4];
																														goto case 44;
																													case 31:
																														num4 = num2 * 8;
																														goto case 82;
																													case 13:
																														num3 = num2 * 4;
																														goto case 31;
																													case 143:
																														num2 = 1;
																														goto case 13;
																													case 144:
																														goto end_IL_0918;
																													case 89:
																													case 158:
																														goto IL_0e83_2;
																													}
																													continue;
																												}
																												goto IL_094c_2;
																												IL_098c_2:
																												array2[num6 - 2] = 0;
																												goto IL_09a0_2;
																												IL_09a0_2:
																												num6--;
																												goto IL_0dc0_2;
																												IL_094c_2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_098c_2;
																												continue;
																												end_IL_0389_2:
																												break;
																											}
																											break;
																										}
																										goto IL_09b3_2;
																										IL_09b3_2:
																										if (1 < b)
																										{
																											break;
																										}
																										num = 151;
																										goto IL_09ca_2;
																										IL_09ca_2:
																										if (1 <= b)
																										{
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_09dd_2;
																								IL_0ac0_2:
																								ptr2 += 8;
																								goto IL_0dc0_2;
																								IL_09dd_2:
																								if (3 >= b)
																								{
																									goto IL_09e8_2;
																								}
																								goto IL_0a52_2;
																								IL_09e8_2:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_09f6_2;
																								IL_09f6_2:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a1f_2;
																								IL_0a1f_2:
																								ptr2 += 8;
																								num = 67;
																								goto IL_0a36_2;
																								IL_0a36_2:
																								num6--;
																								num = 52;
																								goto IL_0dc0_2;
																								IL_0a52_2:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0a60_2;
																								IL_0a60_2:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0a6e_2;
																								IL_0a6e_2:
																								array2[num6] = 0;
																								goto IL_0a7c_2;
																								IL_0a7c_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0a9f_2;
																								IL_0a9f_2:
																								array3[num6] = null;
																								goto IL_0aa9_2;
																								IL_0aa9_2:
																								num6++;
																								num = 129;
																								goto IL_0ac0_2;
																							}
																							break;
																						}
																						goto IL_0ad3_2;
																						IL_0b27_2:
																						num6--;
																						goto IL_0dc0_2;
																						IL_0ad3_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0b13_2;
																						IL_0b13_2:
																						array2[num6 - 2] = 0;
																						goto IL_0b27_2;
																					}
																					break;
																				}
																				goto IL_0b3a_2;
																				IL_0d6d_2:
																				num6 -= 2;
																				goto IL_0dc0_2;
																				IL_0b3a_2:
																				if (8 >= b)
																				{
																					goto IL_0b48_2;
																				}
																				goto IL_0c75_2;
																				IL_0b48_2:
																				if (8 > b)
																				{
																					goto IL_0b56_2;
																				}
																				goto IL_0c62_2;
																				IL_0b56_2:
																				if (6 >= b)
																				{
																					goto IL_0b61_2;
																				}
																				goto IL_0bd6_2;
																				IL_0b61_2:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0b6f_2;
																				IL_0b6f_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0baf_2;
																				IL_0baf_2:
																				array2[num6 - 2] = 0;
																				goto IL_0bc3_2;
																				IL_0bc3_2:
																				num6--;
																				goto IL_0dc0_2;
																				IL_0bd6_2:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0be4_2;
																				IL_0be4_2:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0bf2_2;
																				IL_0bf2_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0c32_2;
																				IL_0c32_2:
																				array2[num6 - 2] = 0;
																				goto IL_0c46_2;
																				IL_0c46_2:
																				num6--;
																				num = 168;
																				goto IL_0dc0_2;
																				IL_0c62_2:
																				num6--;
																				goto IL_0dc0_2;
																				IL_0c75_2:
																				if (9 >= b)
																				{
																					goto IL_0c80_2;
																				}
																				goto IL_0cf5_2;
																				IL_0c80_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0c8e_2;
																				IL_0c8e_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0cce_2;
																				IL_0cce_2:
																				array2[num6 - 2] = 0;
																				goto IL_0ce2_2;
																				IL_0ce2_2:
																				num6--;
																				goto IL_0dc0_2;
																				IL_0cf5_2:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0d00_2;
																				IL_0d00_2:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0d0b_2;
																				IL_0d0b_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0d6d_2;
																			}
																			break;
																		}
																		goto IL_0799_2;
																		IL_080f_2:
																		ptr2 += 8;
																		goto IL_0dc0_2;
																		IL_0799_2:
																		array2[num6 - 2] = 0;
																		goto IL_07ad_2;
																		IL_07ad_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)ActivatorLevelIIDIDefinitionIdentity[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0801_2;
																		IL_0801_2:
																		num6--;
																		goto IL_080f_2;
																	}
																	break;
																}
																goto IL_0437_2;
																IL_06f3_2:
																ptr2 += 16;
																goto IL_0dc0_2;
																IL_0437_2:
																if (17 >= b)
																{
																	goto IL_0445_2;
																}
																goto IL_0557_2;
																IL_0445_2:
																if (17 > b)
																{
																	goto IL_0453_2;
																}
																goto IL_04e4_2;
																IL_0453_2:
																if (14 >= b)
																{
																	goto IL_045e_2;
																}
																goto IL_046e_2;
																IL_045e_2:
																if (14 > b)
																{
																	goto IL_04b5_2;
																}
																goto IL_0822_2;
																IL_04b5_2:
																if (12 < b)
																{
																	goto IL_04c3_2;
																}
																goto IL_0544_2;
																IL_04c3_2:
																if (13 < b)
																{
																	break;
																}
																goto IL_04d1_2;
																IL_04d1_2:
																if (13 > b)
																{
																	break;
																}
																goto IL_0861_2;
																IL_0861_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_0870_2;
																}
																goto IL_087e;
																IL_0544_2:
																if (12 > b)
																{
																	break;
																}
																goto IL_0dc0_2;
																IL_0822_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0840_2;
																IL_0840_2:
																ptr2 += 8;
																goto IL_084e_2;
																IL_084e_2:
																num6--;
																goto IL_0dc0_2;
																IL_046e_2:
																if (15 >= b)
																{
																	goto IL_047c_2;
																}
																goto IL_0706_2;
																IL_047c_2:
																if (15 > b)
																{
																	break;
																}
																goto IL_048a_2;
																IL_048a_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_052b_2;
																IL_052b_2:
																array2[num6 - 1] = 5;
																goto IL_0dc0_2;
																IL_0706_2:
																if (16 < b)
																{
																	break;
																}
																goto IL_0714_2;
																IL_0714_2:
																if (16 > b)
																{
																	break;
																}
																goto IL_0722_2;
																IL_0722_2:
																array2[num6] = array2[num6 - 1];
																goto IL_073a_2;
																IL_073a_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_0758_2;
																IL_0758_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_077c_2;
																IL_077c_2:
																array3[num6] = array3[num6 - 1];
																goto IL_0939_2;
																IL_0939_2:
																num6++;
																goto IL_0dc0_2;
																IL_04e4_2:
																array2[num6] = 5;
																goto IL_04f2_2;
																IL_04f2_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_050a_2;
																IL_050a_2:
																num6++;
																goto IL_0518_2;
																IL_0518_2:
																ptr2 += 8;
																goto IL_0dc0_2;
																IL_0557_2:
																if (20 < b)
																{
																	goto IL_0562_2;
																}
																goto IL_05cb_2;
																IL_0562_2:
																if (21 >= b)
																{
																	goto IL_056d_2;
																}
																goto IL_0593_2;
																IL_056d_2:
																if (21 > b)
																{
																	break;
																}
																goto IL_057b_2;
																IL_057b_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0dc0_2;
																IL_0593_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_05a1_2;
																IL_05a1_2:
																if (22 > b)
																{
																	break;
																}
																goto IL_05af_2;
																IL_05af_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																goto IL_0dc0_2;
																IL_05cb_2:
																if (20 > b)
																{
																	goto IL_05d9_2;
																}
																goto IL_06be_2;
																IL_05d9_2:
																if (18 >= b)
																{
																	goto IL_05e4_2;
																}
																goto IL_0643_2;
																IL_05e4_2:
																if (18 > b)
																{
																	break;
																}
																goto IL_05f2_2;
																IL_05f2_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0630_2;
																IL_0630_2:
																num6 -= 3;
																goto IL_0dc0_2;
																IL_0643_2:
																if (19 < b)
																{
																	break;
																}
																goto IL_0651_2;
																IL_0651_2:
																if (19 > b)
																{
																	break;
																}
																goto IL_065f_2;
																IL_065f_2:
																array2[num6 - 1] = 5;
																goto IL_0673_2;
																IL_0673_2:
																array3[num6 - 1] = ((delegate*<string[], string>)ActivatorLevelIIDIDefinitionIdentity[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_06ab_2;
																IL_06ab_2:
																ptr2 += 8;
																goto IL_0dc0_2;
																IL_06be_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_06d7_2;
																IL_06d7_2:
																array2[num6] = 1;
																goto IL_06e5_2;
																IL_06e5_2:
																num6++;
																goto IL_06f3_2;
															}
															break;
															IL_03fc_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0d96_2;
													IL_0db2_2:
													ptr2 += 8;
													goto IL_0dc0_2;
													IL_0da4_2:
													num6++;
													goto IL_0db2_2;
													IL_0d96_2:
													array2[num6] = 0;
													goto IL_0da4_2;
													continue;
													end_IL_040c_2:
													break;
												}
												continue;
												end_IL_041c:
												break;
											}
											continue;
											end_IL_042c:
											break;
										}
										break;
									}
									goto IL_0e83_2;
									IL_0e83_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0918:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class111()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_4)
	{
		int num = 95;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ObjmodelgetHashName.SupportUrlBeginRead);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_067b:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02ba:
														byte b = *ptr2;
														while (true)
														{
															IL_02aa:
															ptr2++;
															while (true)
															{
																IL_029a:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_027a:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_026d:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_025d:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0250:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											while (true)
																											{
																												IL_0230:
																												if (8 <= b)
																												{
																													while (true)
																													{
																														IL_0202:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 120;
																														while (true)
																														{
																															if (num != 120)
																															{
																																if (num != 1101)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 59:
																																case 64:
																																	goto IL_0202;
																																case 68:
																																	goto IL_0230;
																																case 107:
																																	goto IL_0240;
																																case 96:
																																	goto IL_0250;
																																case 14:
																																	goto IL_025d;
																																case 2:
																																	goto IL_026d;
																																case 54:
																																	goto IL_027a;
																																case 88:
																																	goto IL_028a;
																																case 90:
																																	goto IL_029a;
																																case 9:
																																	goto IL_02aa;
																																case 19:
																																case 21:
																																	goto IL_02ba;
																																case 26:
																																	goto IL_02d3;
																																case 70:
																																case 78:
																																	goto IL_02e6;
																																case 6:
																																	goto IL_02f1;
																																case 37:
																																case 62:
																																	goto IL_02ff;
																																case 75:
																																	goto IL_0324;
																																case 80:
																																	goto IL_0332;
																																case 1:
																																case 105:
																																	goto IL_0345;
																																case 10:
																																	goto IL_03a7;
																																case 22:
																																case 113:
																																	goto IL_03ba;
																																case 13:
																																	goto IL_03fa;
																																case 77:
																																	goto IL_040e;
																																case 84:
																																	goto IL_042f;
																																case 60:
																																	goto IL_043d;
																																case 53:
																																	goto IL_0450;
																																case 63:
																																case 112:
																																	goto IL_045e;
																																case 24:
																																	goto IL_046c;
																																case 5:
																																case 27:
																																	goto IL_0477;
																																case 3:
																																	goto IL_048f;
																																case 56:
																																case 69:
																																	goto IL_049a;
																																case 102:
																																	goto IL_04a8;
																																case 0:
																																case 108:
																																	goto IL_04b6;
																																case 76:
																																	goto IL_04df;
																																case 43:
																																	goto IL_04ed;
																																case 61:
																																	goto IL_0500;
																																case 7:
																																case 52:
																																	goto IL_0517;
																																case 91:
																																	goto IL_0530;
																																case 87:
																																	goto IL_0547;
																																case 49:
																																	goto IL_0555;
																																case 25:
																																	goto IL_0568;
																																case 35:
																																case 41:
																																	goto IL_0576;
																																case 32:
																																	goto IL_0584;
																																case 15:
																																case 89:
																																	goto IL_0592;
																																case 74:
																																	goto IL_05a0;
																																case 29:
																																	goto IL_05c3;
																																case 110:
																																	goto IL_05cd;
																																case 46:
																																	goto IL_05e4;
																																case 48:
																																	goto IL_05f7;
																																case 4:
																																case 79:
																																	goto IL_0604;
																																case 66:
																																	goto IL_0644;
																																case 40:
																																	goto IL_0658;
																																case 11:
																																case 30:
																																case 31:
																																case 34:
																																case 38:
																																case 39:
																																case 44:
																																case 47:
																																case 50:
																																case 51:
																																case 58:
																																case 65:
																																case 72:
																																case 73:
																																case 81:
																																case 86:
																																case 97:
																																case 99:
																																case 101:
																																case 103:
																																case 104:
																																case 109:
																																	goto end_IL_0230;
																																case 8:
																																case 12:
																																case 16:
																																case 17:
																																case 20:
																																case 28:
																																case 36:
																																case 45:
																																case 55:
																																case 57:
																																case 71:
																																case 92:
																																case 106:
																																case 111:
																																	goto IL_067b;
																																case 67:
																																	goto end_IL_067b;
																																case 23:
																																	goto end_IL_068e;
																																case 83:
																																	goto end_IL_0698;
																																case 100:
																																	goto end_IL_06a3;
																																case 33:
																																case 42:
																																	goto end_IL_06b8;
																																case 98:
																																	goto end_IL_06c8;
																																case 82:
																																case 93:
																																	goto end_IL_06d8;
																																case 94:
																																	goto end_IL_06e8;
																																case 95:
																																	goto end_IL_06f8;
																																case 18:
																																case 85:
																																	goto end_IL_01ef;
																																}
																																continue;
																															}
																															array[num5] = 0;
																															goto IL_042f;
																															IL_042f:
																															num5++;
																															goto IL_043d;
																															IL_043d:
																															ptr2 += 8;
																															goto IL_067b;
																															continue;
																															end_IL_01ef:
																															break;
																														}
																														break;
																													}
																													goto end_IL_029a;
																												}
																												num = 51;
																												break;
																												continue;
																												end_IL_0230:
																												break;
																											}
																											break;
																											IL_0240:;
																										}
																										break;
																									}
																									goto IL_02d3;
																									IL_040e:
																									num5--;
																									goto IL_067b;
																									IL_02d3:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_03ba;
																									IL_03ba:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03fa;
																									IL_03fa:
																									array[num5 - 2] = 0;
																									goto IL_040e;
																								}
																								break;
																							}
																							goto IL_0345;
																							IL_03a7:
																							num5 -= 2;
																							goto IL_067b;
																							IL_0345:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03a7;
																						}
																						break;
																					}
																					goto IL_02e6;
																					IL_0332:
																					if (11 <= b)
																					{
																					}
																					break;
																					IL_02e6:
																					if (10 >= b)
																					{
																						goto IL_02f1;
																					}
																					goto IL_0324;
																					IL_02f1:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_02ff;
																					IL_02ff:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 92;
																					goto IL_067b;
																					IL_0324:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0332;
																				}
																				break;
																			}
																			goto IL_0450;
																			IL_0644:
																			array[num5 - 2] = 0;
																			goto IL_0658;
																			IL_0450:
																			if (6 > b)
																			{
																				goto IL_045e;
																			}
																			goto IL_0604;
																			IL_045e:
																			if (3 >= b)
																			{
																				goto IL_046c;
																			}
																			goto IL_0568;
																			IL_046c:
																			if (3 <= b)
																			{
																				goto IL_0477;
																			}
																			goto IL_048f;
																			IL_0477:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_067b;
																			IL_048f:
																			if (1 < b)
																			{
																				goto IL_049a;
																			}
																			goto IL_0500;
																			IL_049a:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04a8;
																			IL_04a8:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_04b6;
																			IL_04b6:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04df;
																			IL_04df:
																			ptr2 += 8;
																			goto IL_04ed;
																			IL_04ed:
																			num5--;
																			goto IL_067b;
																			IL_0500:
																			if (1 > b)
																			{
																				break;
																			}
																			num = 7;
																			goto IL_0517;
																			IL_0658:
																			num5--;
																			goto IL_067b;
																			IL_0517:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0530;
																			IL_0530:
																			array[num5] = 0;
																			num = 87;
																			goto IL_0547;
																			IL_0547:
																			num5++;
																			goto IL_0555;
																			IL_0555:
																			ptr2 += 8;
																			goto IL_067b;
																			IL_0568:
																			if (4 < b)
																			{
																				goto IL_0576;
																			}
																			goto IL_05f7;
																			IL_0576:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0584;
																			IL_0584:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0592;
																			IL_0592:
																			array[num5] = 0;
																			goto IL_05a0;
																			IL_05a0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05c3;
																			IL_05c3:
																			array2[num5] = null;
																			goto IL_05cd;
																			IL_05cd:
																			num5++;
																			num = 46;
																			goto IL_05e4;
																			IL_05e4:
																			ptr2 += 8;
																			goto IL_067b;
																			IL_05f7:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_067b;
																			IL_0604:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0644;
																		}
																		break;
																		IL_028a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_067b;
																continue;
																end_IL_029a:
																break;
															}
															break;
														}
														break;
													}
												}
												else
												{
													num = 85;
												}
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067b:
												break;
											}
											continue;
											end_IL_068e:
											break;
										}
										continue;
										end_IL_0698:
										break;
									}
									continue;
									end_IL_06a3:
									break;
								}
								continue;
								end_IL_06b8:
								break;
							}
							continue;
							end_IL_06c8:
							break;
						}
						continue;
						end_IL_06d8:
						break;
					}
					continue;
					end_IL_06e8:
					break;
				}
				continue;
				end_IL_06f8:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_4)
	{
		int num = 53;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetCulturesInterface.ImportCspBlobCMSENTRYPOINTFLAG);
										num = 110;
										while (true)
										{
											byte* ptr2 = ptr;
											num = 119;
											while (true)
											{
												if (num == 119)
												{
													goto IL_0295;
												}
												if (num != 1100)
												{
													goto IL_02e6;
												}
												switch (num)
												{
												case 110:
													goto end_IL_01eb;
												case 40:
													goto end_IL_01fe;
												case 104:
													goto end_IL_0211;
												case 66:
													goto end_IL_0225;
												case 51:
												case 105:
													goto end_IL_023a;
												case 67:
													goto end_IL_024a;
												case 24:
												case 59:
													goto end_IL_025a;
												case 52:
													goto end_IL_026a;
												case 53:
													goto end_IL_027a;
												case 2:
												case 7:
												case 19:
												case 22:
												case 30:
												case 37:
												case 48:
												case 60:
												case 80:
												case 81:
												case 85:
												case 88:
												case 99:
													goto IL_0295;
												case 15:
												case 82:
													goto IL_02a5;
												case 20:
													goto IL_02ae;
												case 108:
													goto IL_02bc;
												case 109:
													goto IL_02ca;
												case 74:
													goto IL_02d8;
												case 69:
												case 112:
													goto IL_02e6;
												case 93:
													goto IL_02f4;
												case 29:
												case 54:
													goto IL_02ff;
												case 92:
													goto IL_0361;
												case 46:
													goto IL_0374;
												case 100:
													goto IL_037f;
												case 43:
												case 68:
													goto IL_038d;
												case 26:
													goto IL_03cd;
												case 1:
													goto IL_03e1;
												case 9:
													goto IL_03f4;
												case 58:
													goto IL_0402;
												case 3:
												case 8:
													goto IL_0410;
												case 63:
													goto IL_0433;
												case 18:
													goto IL_0441;
												case 34:
													goto IL_044f;
												case 70:
													goto IL_0462;
												case 90:
													goto IL_046d;
												case 28:
												case 89:
													goto IL_047b;
												case 71:
													goto IL_0497;
												case 79:
													goto IL_04a5;
												case 76:
													goto IL_04b8;
												case 41:
												case 57:
													goto IL_04c6;
												case 45:
													goto IL_04d4;
												case 12:
												case 21:
													goto IL_04df;
												case 49:
													goto IL_04f7;
												case 14:
												case 75:
													goto IL_0502;
												case 16:
													goto IL_0510;
												case 55:
												case 103:
													goto IL_051e;
												case 13:
													goto IL_0547;
												case 44:
													goto IL_0555;
												case 98:
													goto IL_0568;
												case 101:
												case 107:
													goto IL_0576;
												case 23:
													goto IL_0598;
												case 97:
													goto IL_05a6;
												case 32:
													goto IL_05b4;
												case 84:
													goto IL_05c7;
												case 33:
												case 65:
													goto IL_05d5;
												case 31:
													goto IL_05e3;
												case 6:
												case 36:
													goto IL_05f1;
												case 61:
													goto IL_0608;
												case 95:
													goto IL_062b;
												case 102:
													goto IL_0635;
												case 106:
													goto IL_064c;
												case 10:
													goto IL_065f;
												case 11:
												case 94:
													goto IL_066f;
												case 78:
													goto IL_06af;
												case 86:
													goto IL_06cc;
												case 0:
												case 4:
												case 5:
												case 17:
												case 25:
												case 27:
												case 35:
												case 38:
												case 39:
												case 42:
												case 50:
												case 56:
												case 62:
												case 64:
												case 72:
												case 73:
												case 77:
												case 83:
												case 91:
												case 96:
												case 111:
													goto IL_06df;
												case 47:
												case 87:
													goto IL_06f7;
												}
												continue;
												IL_06cc:
												num4--;
												goto IL_0295;
												IL_06df:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0295;
												IL_0295:
												if (num5 != 1)
												{
													goto IL_02a5;
												}
												goto IL_06f7;
												IL_06f7:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_02a5:
												b = *ptr2;
												goto IL_02ae;
												IL_02ae:
												ptr2++;
												goto IL_02bc;
												IL_02bc:
												if (b >= 1)
												{
													goto IL_02ca;
												}
												goto IL_06df;
												IL_02ca:
												if (b <= 11)
												{
													goto IL_02d8;
												}
												goto IL_06df;
												IL_02d8:
												if (6 < b)
												{
													goto IL_02e6;
												}
												goto IL_04b8;
												IL_02e6:
												if (9 >= b)
												{
													goto IL_02f4;
												}
												goto IL_0462;
												IL_02f4:
												if (9 <= b)
												{
													goto IL_02ff;
												}
												goto IL_0374;
												IL_02ff:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0361;
												IL_0361:
												num4 -= 2;
												goto IL_0295;
												IL_0374:
												if (7 >= b)
												{
													goto IL_037f;
												}
												goto IL_03f4;
												IL_037f:
												if (7 <= b)
												{
													goto IL_038d;
												}
												goto IL_06df;
												IL_038d:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_03cd;
												IL_03cd:
												array[num4 - 2] = 0;
												goto IL_03e1;
												IL_03e1:
												num4--;
												goto IL_0295;
												IL_03f4:
												if (8 >= b)
												{
													goto IL_0402;
												}
												goto IL_06df;
												IL_0402:
												if (8 <= b)
												{
													goto IL_0410;
												}
												goto IL_06df;
												IL_0410:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0433;
												IL_0433:
												array[num4] = 0;
												goto IL_0441;
												IL_0441:
												num4++;
												goto IL_044f;
												IL_044f:
												ptr2 += 8;
												goto IL_0295;
												IL_0462:
												if (10 >= b)
												{
													goto IL_046d;
												}
												goto IL_0497;
												IL_046d:
												if (10 <= b)
												{
													goto IL_047b;
												}
												goto IL_06df;
												IL_047b:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												goto IL_0295;
												IL_0497:
												if (11 >= b)
												{
													goto IL_04a5;
												}
												goto IL_06df;
												IL_04a5:
												if (11 <= b)
												{
												}
												goto IL_06df;
												IL_04b8:
												if (6 > b)
												{
													goto IL_04c6;
												}
												goto IL_066f;
												IL_04c6:
												if (3 >= b)
												{
													goto IL_04d4;
												}
												goto IL_05c7;
												IL_04d4:
												if (3 <= b)
												{
													goto IL_04df;
												}
												goto IL_04f7;
												IL_04df:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0295;
												IL_04f7:
												if (1 < b)
												{
													goto IL_0502;
												}
												goto IL_0568;
												IL_0502:
												if (2 >= b)
												{
													goto IL_0510;
												}
												goto IL_06df;
												IL_0510:
												if (2 <= b)
												{
													goto IL_051e;
												}
												goto IL_06df;
												IL_051e:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0547;
												IL_0547:
												ptr2 += 8;
												goto IL_0555;
												IL_0555:
												num4--;
												goto IL_0295;
												IL_0568:
												if (1 <= b)
												{
													goto IL_0576;
												}
												goto IL_06df;
												IL_0576:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												num = 23;
												goto IL_0598;
												IL_0598:
												array[num4] = 0;
												goto IL_05a6;
												IL_05a6:
												num4++;
												goto IL_05b4;
												IL_05b4:
												ptr2 += 8;
												goto IL_0295;
												IL_05c7:
												if (4 < b)
												{
													goto IL_05d5;
												}
												goto IL_065f;
												IL_05d5:
												if (5 >= b)
												{
													goto IL_05e3;
												}
												goto IL_06df;
												IL_05e3:
												if (5 <= b)
												{
													goto IL_05f1;
												}
												goto IL_06df;
												IL_05f1:
												array[num4] = 0;
												num = 61;
												goto IL_0608;
												IL_0608:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_062b;
												IL_062b:
												array2[num4] = null;
												goto IL_0635;
												IL_0635:
												num4++;
												num = 106;
												goto IL_064c;
												IL_064c:
												ptr2 += 8;
												goto IL_0295;
												IL_065f:
												if (4 <= b)
												{
													goto IL_0295;
												}
												goto IL_06df;
												IL_066f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_06af;
												IL_06af:
												array[num4 - 2] = 0;
												num = 86;
												goto IL_06cc;
												continue;
												end_IL_01eb:
												break;
											}
											continue;
											end_IL_01fe:
											break;
										}
										continue;
										end_IL_0211:
										break;
									}
									continue;
									end_IL_0225:
									break;
								}
								continue;
								end_IL_023a:
								break;
							}
							continue;
							end_IL_024a:
							break;
						}
						continue;
						end_IL_025a:
						break;
					}
					continue;
					end_IL_026a:
					break;
				}
				continue;
				end_IL_027a:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_4, int int_5)
	{
		int num = 2;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NotCurrentlyProcessingFUNCDESC.IManifestParseErrorCallbackPreviousValue);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 99;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 40;
																	while (true)
																	{
																		IL_02b7:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_0297:
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_0287:
																							if (9 < b)
																							{
																								while (true)
																								{
																									IL_0277:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_0267:
																											if (11 > b)
																											{
																												while (10 >= b)
																												{
																													while (true)
																													{
																														IL_0244:
																														if (10 > b)
																														{
																															num = 133;
																															while (num != 133)
																															{
																																if (num != 1114)
																																{
																																	goto IL_04fb;
																																}
																																switch (num)
																																{
																																case 36:
																																	goto IL_0244;
																																case 38:
																																	goto IL_0257;
																																case 8:
																																	goto IL_0267;
																																case 87:
																																case 107:
																																	goto IL_0277;
																																case 0:
																																case 112:
																																	goto IL_0287;
																																case 37:
																																	goto IL_0297;
																																case 91:
																																	goto IL_02a7;
																																case 40:
																																	goto IL_02b7;
																																case 44:
																																	goto end_IL_02b7;
																																case 99:
																																	goto end_IL_02c7;
																																case 13:
																																	goto end_IL_02e0;
																																case 72:
																																case 117:
																																	goto IL_02f6;
																																case 68:
																																	goto IL_030a;
																																case 105:
																																	goto IL_0349;
																																case 20:
																																case 113:
																																	goto IL_035c;
																																case 124:
																																case 126:
																																	goto IL_036f;
																																case 118:
																																	goto IL_037d;
																																case 3:
																																case 77:
																																	goto IL_038b;
																																case 35:
																																	goto IL_03a7;
																																case 15:
																																case 52:
																																	goto IL_03b2;
																																case 97:
																																	goto IL_03f2;
																																case 70:
																																	goto IL_0406;
																																case 22:
																																	goto IL_0419;
																																case 42:
																																case 69:
																																	goto IL_0424;
																																case 5:
																																	goto IL_0432;
																																case 25:
																																case 88:
																																	goto IL_0440;
																																case 17:
																																	goto IL_0459;
																																case 93:
																																	goto IL_0470;
																																case 50:
																																	goto IL_047e;
																																case 82:
																																	goto IL_0491;
																																case 34:
																																case 74:
																																	goto IL_049f;
																																case 27:
																																	goto IL_04ad;
																																case 122:
																																	goto IL_04d0;
																																case 76:
																																	goto IL_04da;
																																case 41:
																																	goto IL_04e8;
																																case 86:
																																	goto IL_04fb;
																																case 33:
																																case 62:
																																	goto IL_0509;
																																case 116:
																																	goto IL_0517;
																																case 51:
																																case 80:
																																	goto IL_0525;
																																case 31:
																																case 64:
																																	goto IL_0533;
																																case 78:
																																	goto IL_0541;
																																case 19:
																																case 47:
																																	goto IL_054f;
																																case 58:
																																	goto IL_05bd;
																																case 6:
																																	goto IL_05d0;
																																case 48:
																																case 96:
																																	goto IL_05e3;
																																case 14:
																																	goto IL_0623;
																																case 55:
																																	goto IL_0637;
																																case 65:
																																	goto IL_064a;
																																case 125:
																																	goto IL_0655;
																																case 89:
																																case 103:
																																	goto IL_0660;
																																case 45:
																																	goto IL_0689;
																																case 39:
																																	goto IL_0697;
																																case 110:
																																	goto IL_06a7;
																																case 10:
																																	goto IL_06b2;
																																case 90:
																																case 120:
																																	goto IL_06bd;
																																case 4:
																																case 7:
																																case 16:
																																case 18:
																																case 29:
																																case 53:
																																case 54:
																																case 57:
																																case 59:
																																case 63:
																																case 67:
																																case 73:
																																case 75:
																																case 84:
																																case 85:
																																case 95:
																																case 98:
																																case 104:
																																case 106:
																																case 109:
																																case 111:
																																case 119:
																																case 121:
																																	goto end_IL_0231;
																																case 114:
																																	goto IL_06f5;
																																case 60:
																																	goto IL_0703;
																																case 79:
																																	goto IL_0711;
																																case 12:
																																case 21:
																																case 26:
																																case 30:
																																case 32:
																																case 61:
																																case 66:
																																case 71:
																																case 81:
																																case 83:
																																case 92:
																																case 94:
																																case 101:
																																case 102:
																																case 108:
																																	goto end_IL_02eb;
																																case 28:
																																	goto end_IL_071f;
																																case 23:
																																	goto end_IL_0732;
																																case 49:
																																	goto end_IL_073c;
																																case 100:
																																	goto end_IL_0747;
																																case 24:
																																	goto end_IL_075c;
																																case 115:
																																case 123:
																																	goto end_IL_0771;
																																case 56:
																																	goto end_IL_0781;
																																case 9:
																																case 46:
																																	goto end_IL_0791;
																																case 1:
																																	goto end_IL_07a1;
																																case 2:
																																	goto end_IL_07b1;
																																case 11:
																																case 43:
																																	goto IL_07cc;
																																}
																																continue;
																																end_IL_0231:
																																break;
																															}
																															break;
																														}
																														goto IL_02f6;
																														IL_030a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)MessageSmugglerGetAsyncResult[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																														goto IL_0349;
																														IL_0349:
																														ptr2 += 8;
																														goto end_IL_02eb;
																														IL_02f6:
																														array[num5 - 1] = 0;
																														goto IL_030a;
																													}
																													break;
																													IL_0257:;
																												}
																												break;
																											}
																											goto IL_035c;
																											IL_035c:
																											num5--;
																											goto end_IL_02eb;
																										}
																										break;
																									}
																									goto IL_036f;
																									IL_038b:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_02eb;
																									IL_036f:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_037d;
																									IL_037d:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_038b;
																								}
																								break;
																							}
																							goto IL_03a7;
																							IL_04e8:
																							ptr2 += 8;
																							goto end_IL_02eb;
																							IL_03a7:
																							if (9 <= b)
																							{
																								goto IL_03b2;
																							}
																							goto IL_0419;
																							IL_03b2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03f2;
																							IL_03f2:
																							array[num5 - 2] = 0;
																							goto IL_0406;
																							IL_0406:
																							num5--;
																							goto end_IL_02eb;
																							IL_0419:
																							if (7 < b)
																							{
																								goto IL_0424;
																							}
																							goto IL_0491;
																							IL_0424:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_0432;
																							IL_0432:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0440;
																							IL_0440:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0459;
																							IL_0459:
																							array[num5] = 0;
																							num = 93;
																							goto IL_0470;
																							IL_0470:
																							num5++;
																							goto IL_047e;
																							IL_047e:
																							ptr2 += 8;
																							goto end_IL_02eb;
																							IL_0491:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_049f;
																							IL_049f:
																							array[num5] = 0;
																							goto IL_04ad;
																							IL_04ad:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_04d0;
																							IL_04d0:
																							array2[num5] = null;
																							goto IL_04da;
																							IL_04da:
																							num5++;
																							goto IL_04e8;
																						}
																						break;
																					}
																					goto IL_04fb;
																					IL_06bd:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_02eb;
																					IL_04fb:
																					if (6 <= b)
																					{
																						goto end_IL_02eb;
																					}
																					goto IL_0509;
																					IL_0509:
																					if (3 >= b)
																					{
																						goto IL_0517;
																					}
																					goto IL_064a;
																					IL_0517:
																					if (3 > b)
																					{
																						goto IL_0525;
																					}
																					goto IL_05e3;
																					IL_0525:
																					if (1 < b)
																					{
																						goto IL_0533;
																					}
																					goto IL_05d0;
																					IL_0533:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_0541;
																					IL_0541:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_054f;
																					IL_054f:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_05bd;
																					IL_05bd:
																					num5 -= 2;
																					goto end_IL_02eb;
																					IL_05d0:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_05e3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0623;
																					IL_0623:
																					array[num5 - 2] = 0;
																					goto IL_0637;
																					IL_0637:
																					num5--;
																					goto end_IL_02eb;
																					IL_064a:
																					if (4 >= b)
																					{
																						goto IL_0655;
																					}
																					goto IL_06a7;
																					IL_0655:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0660;
																					IL_0660:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0689;
																					IL_0689:
																					ptr2 += 8;
																					goto IL_0697;
																					IL_0697:
																					num5--;
																					goto end_IL_02eb;
																					IL_06a7:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_06b2;
																					IL_06b2:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_06bd;
																				}
																				break;
																				IL_02a7:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_06f5;
																		IL_0711:
																		ptr2 += 8;
																		goto end_IL_02eb;
																		IL_0703:
																		num5++;
																		goto IL_0711;
																		IL_06f5:
																		array[num5] = 0;
																		goto IL_0703;
																		continue;
																		end_IL_02b7:
																		break;
																	}
																	continue;
																	end_IL_02c7:
																	break;
																}
																continue;
																end_IL_02e0:
																break;
															}
															continue;
															end_IL_02eb:
															break;
														}
														continue;
													}
													goto IL_07cc;
													IL_07cc:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_071f:
													break;
												}
												continue;
												end_IL_0732:
												break;
											}
											continue;
											end_IL_073c:
											break;
										}
										continue;
										end_IL_0747:
										break;
									}
									continue;
									end_IL_075c:
									break;
								}
								continue;
								end_IL_0771:
								break;
							}
							continue;
							end_IL_0781:
							break;
						}
						continue;
						end_IL_0791:
						break;
					}
					continue;
					end_IL_07a1:
					break;
				}
				continue;
				end_IL_07b1:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_4)
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getHourmemid.IWinRTClassActivatorApplicationIsolationByMachine);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 110;
														while (true)
														{
															if (num != 110)
															{
																if (num != 1091)
																{
																	goto IL_05a3;
																}
																switch (num)
																{
																case 8:
																case 69:
																	goto end_IL_01c7;
																case 24:
																	goto IL_01f9;
																case 41:
																	goto IL_0207;
																case 62:
																	goto IL_021e;
																case 61:
																	goto IL_022c;
																case 49:
																	goto IL_023a;
																case 13:
																	goto IL_0248;
																case 73:
																case 87:
																	goto IL_0253;
																case 36:
																	goto IL_025e;
																case 43:
																case 90:
																	goto IL_026c;
																case 88:
																	goto IL_028f;
																case 64:
																	goto IL_029d;
																case 42:
																	goto IL_02ab;
																case 22:
																	goto IL_02cc;
																case 27:
																case 97:
																	goto IL_02da;
																case 35:
																	goto IL_031a;
																case 21:
																	goto IL_032e;
																case 26:
																case 39:
																	goto IL_0341;
																case 6:
																	goto IL_03a3;
																case 28:
																	goto IL_03bf;
																case 37:
																case 99:
																	goto IL_03ca;
																case 94:
																	goto IL_03d5;
																case 93:
																	goto IL_03f6;
																case 30:
																case 96:
																	goto IL_0404;
																case 82:
																	goto IL_0420;
																case 38:
																	goto IL_042e;
																case 56:
																case 57:
																	goto IL_0439;
																case 60:
																	goto IL_0444;
																case 74:
																case 85:
																	goto IL_0452;
																case 53:
																	goto IL_0473;
																case 50:
																	goto IL_0481;
																case 76:
																	goto IL_0494;
																case 9:
																case 55:
																	goto IL_049f;
																case 95:
																	goto IL_04c8;
																case 89:
																	goto IL_04d6;
																case 47:
																	goto IL_04e9;
																case 70:
																	goto IL_04f7;
																case 12:
																case 20:
																	goto IL_0505;
																case 84:
																	goto IL_051e;
																case 2:
																	goto IL_052c;
																case 31:
																	goto IL_053a;
																case 46:
																case 48:
																	goto IL_054a;
																case 16:
																	goto IL_0558;
																case 54:
																	goto IL_057b;
																case 44:
																	goto IL_0585;
																case 45:
																	goto IL_0593;
																case 3:
																case 5:
																case 10:
																case 15:
																case 18:
																case 19:
																case 23:
																case 25:
																case 58:
																case 63:
																case 65:
																case 66:
																case 67:
																case 68:
																case 77:
																case 79:
																case 80:
																case 91:
																case 100:
																case 103:
																	goto IL_05a3;
																case 7:
																case 29:
																case 34:
																case 52:
																case 59:
																case 71:
																case 72:
																case 75:
																case 78:
																case 86:
																case 92:
																case 101:
																case 102:
																	goto end_IL_01d7;
																case 4:
																	goto end_IL_05b6;
																case 33:
																	goto end_IL_05c9;
																case 11:
																	goto end_IL_05d3;
																case 81:
																	goto end_IL_05de;
																case 17:
																case 51:
																	goto end_IL_05f3;
																case 40:
																	goto end_IL_0603;
																case 14:
																case 83:
																	goto end_IL_0613;
																case 0:
																	goto end_IL_0623;
																case 1:
																	goto end_IL_0633;
																case 32:
																case 98:
																	goto IL_064e;
																}
																continue;
															}
															ptr2++;
															goto IL_01f9;
															IL_054a:
															array[num5] = 0;
															goto IL_0558;
															IL_057b:
															array2[num5] = null;
															goto IL_0585;
															IL_0558:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_057b;
															IL_01f9:
															if (b >= 1)
															{
																goto IL_0207;
															}
															goto IL_05a3;
															IL_0207:
															if (b <= 10)
															{
																num = 62;
																goto IL_021e;
															}
															goto IL_05a3;
															IL_0585:
															num5++;
															goto IL_0593;
															IL_021e:
															if (5 < b)
															{
																goto IL_022c;
															}
															goto IL_0420;
															IL_022c:
															if (8 >= b)
															{
																goto IL_023a;
															}
															goto IL_03bf;
															IL_023a:
															if (8 > b)
															{
																goto IL_0248;
															}
															goto IL_0341;
															IL_0248:
															if (6 < b)
															{
																goto IL_0253;
															}
															goto IL_02cc;
															IL_0253:
															if (7 >= b)
															{
																goto IL_025e;
															}
															num = 23;
															goto IL_05a3;
															IL_025e:
															if (7 <= b)
															{
																goto IL_026c;
															}
															goto IL_05a3;
															IL_026c:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_028f;
															IL_028f:
															array[num5] = 0;
															goto IL_029d;
															IL_029d:
															num5++;
															goto IL_02ab;
															IL_02ab:
															ptr2 += 8;
															goto end_IL_01d7;
															IL_0593:
															ptr2 += 8;
															goto end_IL_01d7;
															IL_02cc:
															if (6 <= b)
															{
																goto IL_02da;
															}
															goto IL_05a3;
															IL_02da:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_031a;
															IL_031a:
															array[num5 - 2] = 0;
															goto IL_032e;
															IL_032e:
															num5--;
															goto end_IL_01d7;
															IL_0341:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_03a3;
															IL_03a3:
															num5 -= 2;
															num = 92;
															goto end_IL_01d7;
															IL_03bf:
															if (9 < b)
															{
																goto IL_03ca;
															}
															goto IL_03f6;
															IL_03ca:
															if (10 >= b)
															{
																goto IL_03d5;
															}
															num = 18;
															goto IL_05a3;
															IL_03d5:
															if (10 > b)
															{
															}
															goto IL_05a3;
															IL_05a3:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_01d7;
															IL_03f6:
															if (9 <= b)
															{
																goto IL_0404;
															}
															goto IL_05a3;
															IL_0404:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto end_IL_01d7;
															IL_0420:
															if (5 > b)
															{
																goto IL_042e;
															}
															goto IL_054a;
															IL_042e:
															if (2 < b)
															{
																goto IL_0439;
															}
															goto IL_0494;
															IL_0439:
															if (3 >= b)
															{
																goto IL_0444;
															}
															goto IL_0473;
															IL_0444:
															if (3 <= b)
															{
																goto IL_0452;
															}
															goto IL_05a3;
															IL_0452:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															num = 102;
															goto end_IL_01d7;
															IL_0473:
															if (4 >= b)
															{
																goto IL_0481;
															}
															goto IL_05a3;
															IL_0481:
															if (4 <= b)
															{
																goto end_IL_01d7;
															}
															goto IL_05a3;
															IL_0494:
															if (2 <= b)
															{
																goto IL_049f;
															}
															goto IL_04e9;
															IL_049f:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_04c8;
															IL_04c8:
															ptr2 += 8;
															goto IL_04d6;
															IL_04d6:
															num5--;
															goto end_IL_01d7;
															IL_04e9:
															if (1 >= b)
															{
																goto IL_04f7;
															}
															goto IL_05a3;
															IL_04f7:
															if (1 <= b)
															{
																goto IL_0505;
															}
															goto IL_05a3;
															IL_0505:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_051e;
															IL_051e:
															array[num5] = 0;
															goto IL_052c;
															IL_052c:
															num5++;
															goto IL_053a;
															IL_053a:
															ptr2 += 8;
															goto end_IL_01d7;
															continue;
															end_IL_01c7:
															break;
														}
														continue;
														end_IL_01d7:
														break;
													}
													continue;
												}
												goto IL_064e;
												IL_064e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b6:
												break;
											}
											continue;
											end_IL_05c9:
											break;
										}
										continue;
										end_IL_05d3:
										break;
									}
									continue;
									end_IL_05de:
									break;
								}
								continue;
								end_IL_05f3:
								break;
							}
							continue;
							end_IL_0603:
							break;
						}
						continue;
						end_IL_0613:
						break;
					}
					continue;
					end_IL_0623:
					break;
				}
				continue;
				end_IL_0633:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_4)
	{
		int num = 69;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 45;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_4;
										num = 3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsGlobalTypeDefTokenCompareOptions.TRACEQUERYINFOCLASSaddDomainUnload);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0277:
															byte b = *ptr2;
															num = 57;
															while (true)
															{
																IL_0267:
																ptr2++;
																while (true)
																{
																	IL_0257:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0237:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0227:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_0217:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_0207:
																										if (6 >= b)
																										{
																											while (6 <= b)
																											{
																												num = 113;
																												while (true)
																												{
																													if (num != 113)
																													{
																														if (num != 1094)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 30:
																															goto IL_01f4;
																														case 34:
																															goto IL_0207;
																														case 36:
																															goto IL_0217;
																														case 11:
																														case 87:
																															goto IL_0227;
																														case 62:
																															goto IL_0237;
																														case 104:
																															goto IL_0247;
																														case 27:
																															goto IL_0257;
																														case 57:
																															goto IL_0267;
																														case 58:
																														case 71:
																															goto IL_0277;
																														case 51:
																															goto IL_028b;
																														case 83:
																															goto IL_02cb;
																														case 38:
																															goto IL_02df;
																														case 42:
																														case 100:
																															goto IL_02f2;
																														case 35:
																															goto IL_0300;
																														case 61:
																														case 98:
																															goto IL_030e;
																														case 92:
																															goto IL_0331;
																														case 20:
																															goto IL_033f;
																														case 50:
																															goto IL_034d;
																														case 24:
																														case 94:
																															goto IL_0360;
																														case 77:
																															goto IL_03c2;
																														case 73:
																														case 93:
																															goto IL_03d5;
																														case 13:
																														case 72:
																															goto IL_03e0;
																														case 46:
																															goto IL_03ee;
																														case 48:
																															goto IL_0401;
																														case 12:
																														case 19:
																															goto IL_040f;
																														case 89:
																															goto IL_042b;
																														case 10:
																														case 79:
																															goto IL_0439;
																														case 76:
																														case 91:
																															goto IL_0444;
																														case 70:
																															goto IL_044f;
																														case 0:
																														case 5:
																															goto IL_045d;
																														case 7:
																															goto IL_0475;
																														case 40:
																															goto IL_0483;
																														case 63:
																															goto IL_0496;
																														case 16:
																														case 52:
																															goto IL_04a1;
																														case 81:
																															goto IL_04af;
																														case 54:
																														case 64:
																															goto IL_04bd;
																														case 96:
																															goto IL_04d6;
																														case 86:
																															goto IL_04e4;
																														case 85:
																															goto IL_04f2;
																														case 9:
																														case 99:
																															goto IL_0505;
																														case 102:
																															goto IL_052e;
																														case 74:
																															goto IL_053c;
																														case 14:
																														case 59:
																															goto IL_054c;
																														case 15:
																															goto IL_055a;
																														case 97:
																															goto IL_057d;
																														case 103:
																															goto IL_0587;
																														case 65:
																															goto IL_0595;
																														case 2:
																														case 4:
																														case 8:
																														case 18:
																														case 21:
																														case 22:
																														case 23:
																														case 25:
																														case 26:
																														case 32:
																														case 37:
																														case 43:
																														case 44:
																														case 47:
																														case 66:
																														case 75:
																														case 84:
																														case 88:
																														case 95:
																															goto end_IL_01f4;
																														case 1:
																														case 6:
																														case 28:
																														case 33:
																														case 39:
																														case 41:
																														case 53:
																														case 60:
																														case 67:
																														case 78:
																														case 90:
																														case 101:
																														case 105:
																															goto end_IL_01e1;
																														case 17:
																															goto end_IL_05b8;
																														case 3:
																															goto end_IL_05cb;
																														case 80:
																															goto end_IL_05d5;
																														case 31:
																															goto end_IL_05e0;
																														case 45:
																															goto end_IL_05fe;
																														case 29:
																															goto end_IL_060e;
																														case 55:
																															goto end_IL_061e;
																														case 49:
																														case 106:
																															goto end_IL_0629;
																														case 68:
																															goto end_IL_0639;
																														case 69:
																															goto end_IL_0649;
																														case 56:
																														case 82:
																															goto IL_0664;
																														}
																														continue;
																													}
																													goto IL_028b;
																													IL_02cb:
																													array[num5 - 2] = 0;
																													goto IL_02df;
																													IL_02df:
																													num5--;
																													break;
																													IL_028b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_02cb;
																													continue;
																													end_IL_01e1:
																													break;
																												}
																												goto end_IL_0257;
																												continue;
																												end_IL_01f4:
																												break;
																												IL_01f4:;
																											}
																											break;
																										}
																										goto IL_02f2;
																										IL_034d:
																										ptr2 += 8;
																										goto end_IL_0257;
																										IL_02f2:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0300;
																										IL_0300:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_030e;
																										IL_030e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0331;
																										IL_0331:
																										array[num5] = 0;
																										goto IL_033f;
																										IL_033f:
																										num5++;
																										goto IL_034d;
																									}
																									break;
																								}
																								goto IL_0360;
																								IL_03c2:
																								num5 -= 2;
																								goto end_IL_0257;
																								IL_0360:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_03c2;
																							}
																							break;
																						}
																						goto IL_03d5;
																						IL_040f:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0257;
																						IL_03d5:
																						if (9 < b)
																						{
																							goto IL_03e0;
																						}
																						goto IL_0401;
																						IL_03e0:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_03ee;
																						IL_03ee:
																						if (10 > b)
																						{
																						}
																						break;
																						IL_0401:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_040f;
																					}
																					break;
																				}
																				goto IL_042b;
																				IL_0595:
																				ptr2 += 8;
																				goto end_IL_0257;
																				IL_042b:
																				if (5 > b)
																				{
																					goto IL_0439;
																				}
																				goto IL_054c;
																				IL_0439:
																				if (2 < b)
																				{
																					goto IL_0444;
																				}
																				goto IL_0496;
																				IL_0444:
																				if (3 >= b)
																				{
																					goto IL_044f;
																				}
																				goto IL_0475;
																				IL_044f:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_045d;
																				IL_045d:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0257;
																				IL_0475:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0483;
																				IL_0483:
																				if (4 > b)
																				{
																					break;
																				}
																				goto end_IL_0257;
																				IL_0496:
																				if (2 > b)
																				{
																					goto IL_04a1;
																				}
																				goto IL_0505;
																				IL_04a1:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_04af;
																				IL_04af:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_04bd;
																				IL_04bd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04d6;
																				IL_04d6:
																				array[num5] = 0;
																				goto IL_04e4;
																				IL_04e4:
																				num5++;
																				goto IL_04f2;
																				IL_04f2:
																				ptr2 += 8;
																				goto end_IL_0257;
																				IL_0505:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_052e;
																				IL_052e:
																				ptr2 += 8;
																				goto IL_053c;
																				IL_053c:
																				num5--;
																				goto end_IL_0257;
																				IL_054c:
																				array[num5] = 0;
																				goto IL_055a;
																				IL_055a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_057d;
																				IL_057d:
																				array2[num5] = null;
																				goto IL_0587;
																				IL_0587:
																				num5++;
																				goto IL_0595;
																			}
																			break;
																			IL_0247:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0257:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0664;
													IL_0664:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05b8:
													break;
												}
												continue;
												end_IL_05cb:
												break;
											}
											continue;
											end_IL_05d5:
											break;
										}
										continue;
										end_IL_05e0:
										break;
									}
									continue;
									end_IL_05fe:
									break;
								}
								continue;
								end_IL_060e:
								break;
							}
							continue;
							end_IL_061e:
							break;
						}
						continue;
						end_IL_0629:
						break;
					}
					continue;
					end_IL_0639:
					break;
				}
				continue;
				end_IL_0649:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_4, int int_5)
	{
		int num = 14;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 70;
				while (true)
				{
					num = 59;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							IL_06a2:
							object[] array2 = new object[3];
							while (true)
							{
								IL_0692:
								int[] array3 = new int[5];
								while (true)
								{
									IL_0682:
									long[] array4 = new long[3];
									while (true)
									{
										IL_066d:
										array3[0] = int_4;
										while (true)
										{
											IL_0658:
											array3[1] = int_5;
											while (true)
											{
												IL_064d:
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IStructuralComparableSoapMonthDay.ClassgetTypeNameConverter);
												while (true)
												{
													IL_0643:
													byte* ptr2 = ptr;
													while (true)
													{
														IL_0630:
														if (num4 != 1)
														{
															while (true)
															{
																IL_0238:
																byte b = *ptr2;
																while (true)
																{
																	IL_0228:
																	ptr2++;
																	while (true)
																	{
																		IL_0218:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_01f8:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_01e8:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_01d8:
																									if (2 >= b)
																									{
																										num = 106;
																										while (true)
																										{
																											if (num != 106)
																											{
																												if (num != 1087)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 90:
																													goto IL_01d8;
																												case 54:
																													goto IL_01e8;
																												case 16:
																													goto IL_01f8;
																												case 93:
																													goto IL_0208;
																												case 2:
																													goto IL_0218;
																												case 83:
																													goto IL_0228;
																												case 31:
																												case 44:
																													goto IL_0238;
																												case 66:
																													goto IL_0243;
																												case 78:
																													goto IL_024e;
																												case 51:
																													goto IL_0265;
																												case 30:
																												case 68:
																													goto IL_0273;
																												case 41:
																													goto IL_02b3;
																												case 85:
																													goto IL_02c9;
																												case 28:
																												case 33:
																													goto IL_02d7;
																												case 60:
																													goto IL_0300;
																												case 89:
																													goto IL_030e;
																												case 99:
																													goto IL_0321;
																												case 25:
																												case 91:
																													goto IL_0348;
																												case 21:
																													goto IL_0388;
																												case 34:
																													goto IL_03a5;
																												case 74:
																													goto IL_03b8;
																												case 67:
																													goto IL_03c6;
																												case 27:
																												case 36:
																													goto IL_03e2;
																												case 42:
																													goto IL_03f0;
																												case 12:
																													goto IL_0413;
																												case 61:
																													goto IL_041d;
																												case 23:
																													goto IL_042b;
																												case 69:
																													goto IL_043e;
																												case 87:
																												case 94:
																													goto IL_044c;
																												case 81:
																													goto IL_0457;
																												case 24:
																													goto IL_0465;
																												case 5:
																												case 52:
																													goto IL_0473;
																												case 96:
																													goto IL_048f;
																												case 4:
																												case 49:
																													goto IL_049d;
																												case 22:
																													goto IL_04dd;
																												case 6:
																													goto IL_04f1;
																												case 82:
																													goto IL_0504;
																												case 56:
																													goto IL_0512;
																												case 37:
																													goto IL_0520;
																												case 80:
																												case 84:
																													goto IL_052e;
																												case 17:
																													goto IL_056e;
																												case 50:
																													goto IL_0582;
																												case 29:
																												case 97:
																													goto IL_0595;
																												case 47:
																													goto IL_05ae;
																												case 40:
																													goto IL_05bc;
																												case 8:
																													goto IL_05ca;
																												case 1:
																												case 10:
																												case 18:
																												case 19:
																												case 38:
																												case 48:
																												case 53:
																												case 57:
																												case 58:
																												case 63:
																												case 64:
																												case 65:
																												case 71:
																												case 73:
																												case 75:
																												case 98:
																													goto end_IL_0208;
																												case 79:
																													goto IL_05fd;
																												case 62:
																													goto IL_0614;
																												case 55:
																													goto IL_0622;
																												case 0:
																												case 7:
																												case 15:
																												case 20:
																												case 35:
																												case 43:
																												case 45:
																												case 46:
																												case 72:
																												case 86:
																												case 92:
																													goto IL_0630;
																												case 9:
																													goto IL_0643;
																												case 77:
																													goto IL_064d;
																												case 11:
																													goto IL_0658;
																												case 88:
																													goto IL_066d;
																												case 95:
																													goto IL_0682;
																												case 39:
																												case 76:
																													goto IL_0692;
																												case 32:
																													goto IL_06a2;
																												case 59:
																													goto end_IL_01c5;
																												case 70:
																													goto end_IL_06b2;
																												case 13:
																													goto end_IL_06c2;
																												case 14:
																													goto end_IL_06cd;
																												case 3:
																												case 26:
																													goto IL_06f1;
																												}
																												continue;
																											}
																											if (2 <= b)
																											{
																												goto IL_0348;
																											}
																											goto IL_03b8;
																											IL_03a5:
																											num5--;
																											goto IL_0630;
																											IL_03c6:
																											if (1 <= b)
																											{
																											}
																											goto end_IL_0208;
																											IL_03b8:
																											if (1 < b)
																											{
																												goto end_IL_0208;
																											}
																											goto IL_03c6;
																											IL_0348:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0388;
																											IL_0388:
																											array[num5 - 2] = 0;
																											num = 34;
																											goto IL_03a5;
																											continue;
																											end_IL_01c5:
																											break;
																										}
																										break;
																									}
																									goto IL_0243;
																									IL_02d7:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0300;
																									IL_0300:
																									ptr2 += 8;
																									goto IL_030e;
																									IL_0243:
																									if (3 < b)
																									{
																										goto IL_024e;
																									}
																									goto IL_02c9;
																									IL_024e:
																									if (4 < b)
																									{
																										goto end_IL_0208;
																									}
																									num = 51;
																									goto IL_0265;
																									IL_030e:
																									num5--;
																									goto IL_0630;
																									IL_0265:
																									if (4 > b)
																									{
																										goto end_IL_0208;
																									}
																									goto IL_0273;
																									IL_0273:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_02b3;
																									IL_02b3:
																									array[num5 - 2] = 0;
																									goto IL_0321;
																									IL_0321:
																									num5--;
																									num = 35;
																									goto IL_0630;
																									IL_02c9:
																									if (3 > b)
																									{
																										goto end_IL_0208;
																									}
																									goto IL_02d7;
																								}
																								break;
																							}
																							num = 27;
																							goto IL_03e2;
																							IL_041d:
																							num5++;
																							goto IL_042b;
																							IL_042b:
																							ptr2 += 8;
																							goto IL_0630;
																							IL_03e2:
																							array[num5] = 0;
																							goto IL_03f0;
																							IL_03f0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0413;
																							IL_0413:
																							array2[num5] = null;
																							goto IL_041d;
																						}
																						break;
																					}
																					goto IL_043e;
																					IL_05ca:
																					ptr2 += 8;
																					goto IL_0630;
																					IL_043e:
																					if (7 < b)
																					{
																						goto IL_044c;
																					}
																					goto IL_0504;
																					IL_044c:
																					if (8 < b)
																					{
																						goto IL_0457;
																					}
																					goto IL_048f;
																					IL_0457:
																					if (9 < b)
																					{
																						goto end_IL_0208;
																					}
																					goto IL_0465;
																					IL_0465:
																					if (9 > b)
																					{
																						goto end_IL_0208;
																					}
																					goto IL_0473;
																					IL_0473:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_0630;
																					IL_048f:
																					if (8 > b)
																					{
																						goto end_IL_0208;
																					}
																					goto IL_049d;
																					IL_049d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04dd;
																					IL_04dd:
																					array[num5 - 2] = 0;
																					goto IL_04f1;
																					IL_04f1:
																					num5--;
																					goto IL_0630;
																					IL_0504:
																					if (7 > b)
																					{
																						goto IL_0512;
																					}
																					goto IL_0595;
																					IL_0512:
																					if (6 < b)
																					{
																						goto end_IL_0208;
																					}
																					goto IL_0520;
																					IL_0520:
																					if (6 > b)
																					{
																						goto end_IL_0208;
																					}
																					goto IL_052e;
																					IL_052e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_056e;
																					IL_056e:
																					array[num5 - 2] = 0;
																					goto IL_0582;
																					IL_0582:
																					num5--;
																					goto IL_0630;
																					IL_0595:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_05ae;
																					IL_05ae:
																					array[num5] = 0;
																					goto IL_05bc;
																					IL_05bc:
																					num5++;
																					goto IL_05ca;
																				}
																				goto end_IL_0218;
																				continue;
																				end_IL_0208:
																				break;
																				IL_0208:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05fd;
																		IL_0622:
																		ptr2 += 8;
																		goto IL_0630;
																		IL_0614:
																		num5++;
																		goto IL_0622;
																		IL_05fd:
																		array[num5] = 0;
																		num = 62;
																		goto IL_0614;
																		continue;
																		end_IL_0218:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														goto IL_06f1;
														IL_06f1:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_06b2:
						break;
					}
					continue;
					end_IL_06c2:
					break;
				}
				continue;
				end_IL_06cd:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_4, int int_5)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_06bc:
						object[] array2 = new object[3];
						while (true)
						{
							IL_06ac:
							int[] array3 = new int[5];
							while (true)
							{
								IL_069c:
								long[] array4 = new long[3];
								while (true)
								{
									IL_0687:
									array3[0] = int_4;
									while (true)
									{
										IL_0672:
										array3[1] = int_5;
										while (true)
										{
											IL_0667:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WriteAllLinesCngAlgorithmID.HASHVALUEPermitOnlySetInstance);
											while (true)
											{
												IL_065d:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_064a:
													if (num4 != 1)
													{
														while (true)
														{
															IL_028d:
															byte b = *ptr2;
															while (true)
															{
																IL_027d:
																ptr2++;
																while (true)
																{
																	IL_026d:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_024d:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0240:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_022d:
																								if (2 < b)
																								{
																									num = 2;
																									while (true)
																									{
																										IL_021d:
																										if (3 < b)
																										{
																											while (4 >= b)
																											{
																												while (4 <= b)
																												{
																													num = 111;
																													while (true)
																													{
																														if (num != 111)
																														{
																															if (num != 1092)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 14:
																																goto IL_01fa;
																															case 8:
																																goto IL_020d;
																															case 2:
																															case 82:
																																goto IL_021d;
																															case 95:
																																goto IL_022d;
																															case 74:
																																goto IL_0240;
																															case 26:
																																goto IL_024d;
																															case 58:
																																goto IL_025d;
																															case 101:
																																goto IL_026d;
																															case 0:
																																goto IL_027d;
																															case 67:
																															case 77:
																																goto IL_028d;
																															case 42:
																															case 52:
																																goto IL_0298;
																															case 10:
																																goto IL_02a6;
																															case 33:
																																goto IL_02c9;
																															case 64:
																																goto IL_02e1;
																															case 40:
																															case 48:
																																goto IL_02ec;
																															case 54:
																																goto IL_032e;
																															case 68:
																																goto IL_033e;
																															case 43:
																																goto IL_0352;
																															case 94:
																																goto IL_0365;
																															case 103:
																																goto IL_0381;
																															case 51:
																																goto IL_038f;
																															case 92:
																																goto IL_03a2;
																															case 25:
																																goto IL_03e2;
																															case 18:
																																goto IL_03f6;
																															case 28:
																																goto IL_0409;
																															case 5:
																															case 65:
																																goto IL_0417;
																															case 69:
																																goto IL_0440;
																															case 96:
																																goto IL_044e;
																															case 56:
																																goto IL_0461;
																															case 32:
																																goto IL_046f;
																															case 3:
																															case 90:
																																goto IL_047d;
																															case 30:
																																goto IL_048b;
																															case 61:
																															case 84:
																																goto IL_0499;
																															case 60:
																																goto IL_04d9;
																															case 76:
																																goto IL_04f6;
																															case 39:
																															case 87:
																																goto IL_0509;
																															case 19:
																																goto IL_0522;
																															case 104:
																																goto IL_0530;
																															case 59:
																																goto IL_053e;
																															case 50:
																															case 85:
																																goto IL_0551;
																															case 44:
																																goto IL_055c;
																															case 22:
																															case 91:
																																goto IL_056a;
																															case 97:
																																goto IL_05aa;
																															case 9:
																																goto IL_05be;
																															case 49:
																																goto IL_05ce;
																															case 15:
																																goto IL_05d9;
																															case 20:
																															case 66:
																																goto IL_05e4;
																															case 1:
																															case 11:
																															case 13:
																															case 16:
																															case 21:
																															case 23:
																															case 35:
																															case 36:
																															case 45:
																															case 47:
																															case 71:
																															case 72:
																															case 75:
																															case 79:
																															case 80:
																															case 83:
																															case 86:
																															case 99:
																															case 102:
																																goto end_IL_01fa;
																															case 70:
																																goto IL_0620;
																															case 7:
																																goto IL_062e;
																															case 55:
																																goto IL_063c;
																															case 31:
																															case 34:
																															case 41:
																															case 46:
																															case 78:
																															case 81:
																															case 88:
																															case 89:
																															case 93:
																															case 98:
																															case 100:
																																goto IL_064a;
																															case 38:
																																goto IL_065d;
																															case 37:
																																goto IL_0667;
																															case 6:
																																goto IL_0672;
																															case 29:
																																goto IL_0687;
																															case 73:
																																goto IL_069c;
																															case 4:
																															case 53:
																																goto IL_06ac;
																															case 17:
																																goto IL_06bc;
																															case 12:
																															case 57:
																																goto end_IL_01e7;
																															case 62:
																																goto end_IL_06cc;
																															case 63:
																																goto end_IL_06dc;
																															case 24:
																															case 27:
																																goto IL_06f7;
																															}
																															continue;
																														}
																														goto IL_03a2;
																														IL_03e2:
																														array[num5 - 2] = 0;
																														goto IL_03f6;
																														IL_03f6:
																														num5--;
																														goto IL_064a;
																														IL_03a2:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_03e2;
																														continue;
																														end_IL_01e7:
																														break;
																													}
																													goto end_IL_026d;
																													continue;
																													end_IL_01fa:
																													break;
																													IL_01fa:;
																												}
																												break;
																												IL_020d:;
																											}
																											break;
																										}
																										goto IL_0409;
																										IL_044e:
																										num5--;
																										goto IL_064a;
																										IL_0409:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0417;
																										IL_0417:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0440;
																										IL_0440:
																										ptr2 += 8;
																										goto IL_044e;
																									}
																									break;
																								}
																								goto IL_02e1;
																								IL_032e:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0365;
																								IL_0365:
																								if (1 > b)
																								{
																									num = 45;
																								}
																								break;
																								IL_02e1:
																								if (2 <= b)
																								{
																									goto IL_02ec;
																								}
																								goto IL_032e;
																								IL_02ec:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_033e;
																								IL_033e:
																								array[num5 - 2] = 0;
																								goto IL_0352;
																								IL_0352:
																								num5--;
																								goto IL_064a;
																							}
																							break;
																						}
																						goto IL_0298;
																						IL_038f:
																						ptr2 += 8;
																						goto IL_064a;
																						IL_0298:
																						array[num5] = 0;
																						goto IL_02a6;
																						IL_02a6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02c9;
																						IL_02c9:
																						array2[num5] = null;
																						num = 103;
																						goto IL_0381;
																						IL_0381:
																						num5++;
																						goto IL_038f;
																					}
																					break;
																				}
																				goto IL_0461;
																				IL_05e4:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_064a;
																				IL_0461:
																				if (7 >= b)
																				{
																					goto IL_046f;
																				}
																				goto IL_0551;
																				IL_046f:
																				if (7 > b)
																				{
																					goto IL_047d;
																				}
																				goto IL_0509;
																				IL_047d:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_048b;
																				IL_048b:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0499;
																				IL_0499:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04d9;
																				IL_04d9:
																				array[num5 - 2] = 0;
																				num = 76;
																				goto IL_04f6;
																				IL_04f6:
																				num5--;
																				goto IL_064a;
																				IL_0509:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0522;
																				IL_0522:
																				array[num5] = 0;
																				goto IL_0530;
																				IL_0530:
																				num5++;
																				goto IL_053e;
																				IL_053e:
																				ptr2 += 8;
																				goto IL_064a;
																				IL_0551:
																				if (8 >= b)
																				{
																					goto IL_055c;
																				}
																				goto IL_05ce;
																				IL_055c:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_056a;
																				IL_056a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05aa;
																				IL_05aa:
																				array[num5 - 2] = 0;
																				goto IL_05be;
																				IL_05be:
																				num5--;
																				goto IL_064a;
																				IL_05ce:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_05d9;
																				IL_05d9:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_05e4;
																			}
																			break;
																			IL_025d:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0620;
																	IL_063c:
																	ptr2 += 8;
																	goto IL_064a;
																	IL_062e:
																	num5++;
																	goto IL_063c;
																	IL_0620:
																	array[num5] = 0;
																	goto IL_062e;
																	continue;
																	end_IL_026d:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_06f7;
													IL_06f7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_06cc:
					break;
				}
				continue;
				end_IL_06dc:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_4)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 95;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BeginChildrenpFqbn.IsSoapActionValidForMethodBaseDynamicScope);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d4:
														byte b = *ptr2;
														while (true)
														{
															IL_02c4:
															ptr2++;
															while (true)
															{
																IL_02b4:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0297:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0287:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0277:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0267:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_025a:
																											if (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_022f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_0216:
																															array[num5] = 0;
																															num = 125;
																															while (true)
																															{
																																if (num != 125)
																																{
																																	if (num != 1106)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 40:
																																		goto IL_0216;
																																	case 93:
																																	case 101:
																																		goto IL_022f;
																																	case 83:
																																		goto IL_024a;
																																	case 25:
																																		goto IL_025a;
																																	case 36:
																																		goto IL_0267;
																																	case 28:
																																	case 115:
																																		goto IL_0277;
																																	case 13:
																																		goto IL_0287;
																																	case 87:
																																		goto IL_0297;
																																	case 33:
																																		goto IL_02a4;
																																	case 68:
																																		goto IL_02b4;
																																	case 3:
																																		goto IL_02c4;
																																	case 102:
																																	case 103:
																																		goto IL_02d4;
																																	case 6:
																																	case 39:
																																		goto IL_02df;
																																	case 5:
																																	case 57:
																																		goto IL_02f2;
																																	case 8:
																																		goto IL_0300;
																																	case 35:
																																	case 45:
																																		goto IL_030e;
																																	case 2:
																																		goto IL_0370;
																																	case 67:
																																		goto IL_0383;
																																	case 7:
																																		goto IL_0391;
																																	case 20:
																																	case 79:
																																		goto IL_03a4;
																																	case 26:
																																		goto IL_03af;
																																	case 42:
																																		goto IL_03c2;
																																	case 91:
																																	case 92:
																																		goto IL_03d5;
																																	case 15:
																																	case 59:
																																		goto IL_03e0;
																																	case 17:
																																		goto IL_03ee;
																																	case 9:
																																	case 81:
																																		goto IL_03fc;
																																	case 19:
																																		goto IL_041f;
																																	case 85:
																																		goto IL_0432;
																																	case 34:
																																	case 104:
																																		goto IL_0445;
																																	case 106:
																																		goto IL_0461;
																																	case 10:
																																	case 99:
																																		goto IL_046f;
																																	case 65:
																																		goto IL_0498;
																																	case 37:
																																		goto IL_04a6;
																																	case 109:
																																		goto IL_04b9;
																																	case 55:
																																	case 63:
																																		goto IL_04c7;
																																	case 111:
																																		goto IL_04d7;
																																	case 80:
																																		goto IL_04e5;
																																	case 112:
																																		goto IL_04f8;
																																	case 21:
																																		goto IL_051b;
																																	case 54:
																																		goto IL_0525;
																																	case 24:
																																		goto IL_0533;
																																	case 110:
																																	case 117:
																																		goto IL_0546;
																																	case 76:
																																		goto IL_0554;
																																	case 0:
																																	case 118:
																																		goto IL_0570;
																																	case 107:
																																		goto IL_05b0;
																																	case 48:
																																		goto IL_05c4;
																																	case 66:
																																		goto IL_05e5;
																																	case 50:
																																	case 72:
																																		goto IL_0601;
																																	case 56:
																																	case 90:
																																		goto IL_0616;
																																	case 88:
																																		goto IL_0656;
																																	case 75:
																																		goto IL_066a;
																																	case 4:
																																	case 11:
																																	case 18:
																																	case 27:
																																	case 29:
																																	case 30:
																																	case 31:
																																	case 38:
																																	case 41:
																																	case 44:
																																	case 46:
																																	case 49:
																																	case 52:
																																	case 53:
																																	case 58:
																																	case 61:
																																	case 62:
																																	case 69:
																																	case 70:
																																	case 74:
																																	case 82:
																																	case 84:
																																	case 94:
																																	case 113:
																																		goto end_IL_024a;
																																	case 1:
																																	case 12:
																																	case 16:
																																	case 47:
																																	case 51:
																																	case 60:
																																	case 64:
																																	case 73:
																																	case 89:
																																	case 98:
																																	case 105:
																																	case 108:
																																	case 114:
																																	case 116:
																																		goto end_IL_0203;
																																	case 23:
																																		goto end_IL_068d;
																																	case 71:
																																		goto end_IL_06a0;
																																	case 86:
																																		goto end_IL_06aa;
																																	case 14:
																																		goto end_IL_06b5;
																																	case 78:
																																	case 100:
																																		goto end_IL_06ca;
																																	case 97:
																																		goto end_IL_06da;
																																	case 22:
																																	case 77:
																																		goto end_IL_06ea;
																																	case 95:
																																		goto end_IL_06fa;
																																	case 96:
																																		goto end_IL_070a;
																																	case 32:
																																	case 43:
																																		goto IL_072e;
																																	}
																																	continue;
																																}
																																num5++;
																																goto IL_05e5;
																																IL_05e5:
																																ptr2 += 8;
																																break;
																																continue;
																																end_IL_0203:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_02b4;
																													continue;
																													end_IL_024a:
																													break;
																													IL_024a:;
																												}
																												break;
																											}
																											goto IL_02df;
																											IL_04a6:
																											num5--;
																											goto end_IL_02b4;
																											IL_02df:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_0461;
																											IL_0461:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_046f;
																											IL_046f:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0498;
																											IL_0498:
																											ptr2 += 8;
																											goto IL_04a6;
																										}
																										break;
																									}
																									num = 72;
																									goto IL_0601;
																									IL_0601:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02b4;
																								}
																								break;
																							}
																							goto IL_03a4;
																							IL_0533:
																							ptr2 += 8;
																							goto end_IL_02b4;
																							IL_03a4:
																							if (4 >= b)
																							{
																								goto IL_03af;
																							}
																							goto IL_03c2;
																							IL_03af:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_02b4;
																							IL_03c2:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_04b9;
																							IL_04b9:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_04c7;
																							IL_04c7:
																							array[num5] = 0;
																							goto IL_04f8;
																							IL_04f8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_051b;
																							IL_051b:
																							array2[num5] = null;
																							goto IL_0525;
																							IL_0525:
																							num5++;
																							goto IL_0533;
																						}
																						break;
																					}
																					goto IL_0616;
																					IL_066a:
																					num5--;
																					goto end_IL_02b4;
																					IL_0616:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0656;
																					IL_0656:
																					array[num5 - 2] = 0;
																					goto IL_066a;
																				}
																				break;
																			}
																			goto IL_02f2;
																			IL_0554:
																			if (11 <= b)
																			{
																				num = 46;
																			}
																			break;
																			IL_02f2:
																			if (9 >= b)
																			{
																				goto IL_0300;
																			}
																			goto IL_0383;
																			IL_0300:
																			if (9 <= b)
																			{
																				goto IL_030e;
																			}
																			goto IL_03d5;
																			IL_030e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0370;
																			IL_0370:
																			num5 -= 2;
																			goto end_IL_02b4;
																			IL_03d5:
																			if (7 < b)
																			{
																				goto IL_03e0;
																			}
																			goto IL_0432;
																			IL_03e0:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_03ee;
																			IL_03ee:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_03fc;
																			IL_03fc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_041f;
																			IL_041f:
																			array[num5] = 0;
																			goto IL_04d7;
																			IL_04d7:
																			num5++;
																			goto IL_04e5;
																			IL_04e5:
																			ptr2 += 8;
																			goto end_IL_02b4;
																			IL_0432:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0570;
																			IL_0570:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05b0;
																			IL_05b0:
																			array[num5 - 2] = 0;
																			goto IL_05c4;
																			IL_05c4:
																			num5--;
																			goto end_IL_02b4;
																			IL_0383:
																			if (10 >= b)
																			{
																				goto IL_0391;
																			}
																			goto IL_0546;
																			IL_0391:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0445;
																			IL_0445:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02b4;
																			IL_0546:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0554;
																		}
																		break;
																		IL_02a4:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02b4:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_072e;
												IL_072e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068d:
												break;
											}
											continue;
											end_IL_06a0:
											break;
										}
										continue;
										end_IL_06aa:
										break;
									}
									continue;
									end_IL_06b5:
									break;
								}
								continue;
								end_IL_06ca:
								break;
							}
							continue;
							end_IL_06da:
							break;
						}
						continue;
						end_IL_06ea:
						break;
					}
					continue;
					end_IL_06fa:
					break;
				}
				continue;
				end_IL_070a:
				break;
			}
		}
	}

	static Class111()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num == 12 || num != 993)
						{
							goto IL_0064;
						}
						switch (num)
						{
						case 0:
						case 1:
							goto end_IL_0039;
						case 3:
							goto end_IL_0046;
						case 4:
							goto end_IL_0055;
						case 5:
							goto IL_0064;
						case 2:
							return;
						}
						continue;
						IL_0064:
						num = 2;
						return;
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_0055:
				break;
			}
		}
	}
}
