using System;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Hand Tap Pointer Gun", "World", "Shoot hand taps at aim.", false, 24, ModType.const_0, false)]
internal class Class16 : MonoBehaviour
{
	private static string string_0;

	private float float_0;

	private bool bool_0;

	private static int int_0;

	private static bool bool_1;

	private static int int_1;

	private static float float_1;

	private static double double_0;

	private static float float_2;

	private static IntPtr[] GetLastWriteTimeInTypeFixedCountFlag;

	private static IntPtr[] setCursorLeftSiteIdentityPermissionAttribute;

	private static IntPtr[] LocalSidTokenAppContainerSid;

	private static IntPtr[] getSettingPreLoadEntry;

	private static IntPtr[] NewPermissionElementMergeLogic;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_0038, IL_0048, IL_0921, IL_0934, IL_0947, IL_0957, IL_0967, IL_0977, IL_098a, IL_099a, IL_09aa, IL_09ba, IL_09cd, IL_09dd, IL_09ed, IL_09f8, IL_0a0b, IL_0a19, IL_0a27, IL_0a35, IL_0a43, IL_0a51, IL_0a67, IL_0a86, IL_0ac5, IL_0ad8, IL_0b17, IL_0b2a, IL_0b3e, IL_0bcf, IL_0bdd, IL_0bf0, IL_0bfe, IL_0c09, IL_0c17, IL_0c20, IL_0c2e, IL_0c37, IL_0c62, IL_0c7b, IL_0c89, IL_0c92, IL_0cc9, IL_0cdc, IL_0cea, IL_0d18, IL_0d23, IL_0d37, IL_0d76, IL_0d89, IL_0d97, IL_0da5, IL_0dc3, IL_0dce, IL_0e0e, IL_0e22, IL_0e35, IL_0e43, IL_0e51, IL_0e65, IL_0ee0, IL_0eee, IL_0f01, IL_0f2a, IL_0f43, IL_0f51, IL_0f5f, IL_0f6d, IL_0f7b, IL_0f86, IL_0f9a, IL_0fd9, IL_0fec, IL_0ffa, IL_1005, IL_1019, IL_1058, IL_106b, IL_1079, IL_1087, IL_10a0, IL_10b3, IL_10c6, IL_10d4, IL_10df, IL_10ed, IL_10fb, IL_1124, IL_113d, IL_1146, IL_115a, IL_1199, IL_11ac, IL_11b7, IL_11c5, IL_11d9, IL_121d, IL_122b, IL_1239, IL_1262, IL_127b, IL_1284, IL_128f, IL_1298, IL_12b5, IL_12ed, IL_1309, IL_1317, IL_1322, IL_1363, IL_1377, IL_138a, IL_1398, IL_13a3, IL_13bc, IL_13ca, IL_13d8, IL_13eb, IL_13f9, IL_1407, IL_141b, IL_1453, IL_1466, IL_1474, IL_1482, IL_149a, IL_14a8, IL_14b3, IL_14c1, IL_14d4, IL_14e2, IL_14f0, IL_1504, IL_153c, IL_154f, IL_155a, IL_1576, IL_1584, IL_158d, IL_159b, IL_15ed, IL_1600, IL_161e, IL_162c, IL_163f, IL_164d, IL_1660, IL_166b, IL_16a9, IL_16bc, IL_16ca, IL_16d5, IL_16e8, IL_16f6, IL_1704, IL_1712, IL_171d, IL_175d, IL_1771, IL_1784, IL_1792, IL_17a0, IL_17b9, IL_17d0, IL_17de, IL_17f1, IL_17ff, IL_180d, IL_1836, IL_1844, IL_1857, IL_1865, IL_1888, IL_1892, IL_18ae, IL_18bc, IL_18ca, IL_18d3, IL_18e1, IL_1921, IL_1935, IL_1948, IL_1956, IL_1964, IL_1972, IL_19b2, IL_19c6, IL_19d9, IL_1a19, IL_1a36, IL_1a49, IL_1a57, IL_1a65, IL_1a82, IL_1ad1, IL_1adb, IL_1b08, IL_1b1c, IL_1b2a, IL_1b3d, IL_1b4b, IL_1b56, IL_1bb8, IL_1bcb, IL_1bd9, IL_1be2, IL_1bf0, IL_1c39, IL_1c4d, IL_1c60, IL_1c6e, IL_1c81, IL_1c8f, IL_1c9a, IL_1cc3, IL_1cdc, IL_1cea, IL_1cf8, IL_1d01, IL_1d1f, IL_1d36, IL_1d49, IL_1d57, IL_1d65, IL_1d7d, IL_1d9b, IL_1dbf, IL_1dd7, IL_1dea, IL_1df8, IL_1e06, IL_1e14, IL_1e2c, IL_1e3a, IL_1e56, IL_1e64, IL_1ea4, IL_1ec1, IL_1ed4, IL_1ee7, IL_1efa, IL_1f33, IL_1f4f, IL_1f68, IL_1f7b, IL_1f86, IL_1fc4, IL_1fd8, IL_1feb, IL_1ff9, IL_2007, IL_201f, IL_202d, IL_203b, IL_204e, IL_205c, IL_2067, IL_207b, IL_20ba, IL_20cd, IL_20db, IL_20e9, IL_2129, IL_213d, IL_2150, IL_215e, IL_216c, IL_2186, IL_2194, IL_21a2, IL_21be, IL_21cc, IL_21f0, IL_21fe, IL_2211, IL_221f, IL_222d, IL_223b, IL_2249, IL_2252, IL_225d, IL_2271, IL_22b0, IL_22cc, IL_22da, IL_22e8, IL_2356, IL_2369, IL_2377, IL_2385, IL_239a, IL_23ad, IL_23c1, IL_2400, IL_2413, IL_2421, IL_242f, IL_243d, IL_244b, IL_2489, IL_249d, IL_24b0, IL_24be, IL_24e2, IL_24f9, IL_250c, IL_2517, IL_2525, IL_2553, IL_2566, IL_2574, IL_2587, IL_2592, IL_25d0, IL_25e4, IL_25f7, IL_2605, IL_260e, IL_2619, IL_2657, IL_266b, IL_267e, IL_268c, IL_269a, IL_26a8, IL_26b6, IL_2714, IL_2727, IL_273b, IL_277a, IL_278d, IL_279b, IL_27a9, IL_27d5, IL_27e3, IL_27f1, IL_2804, IL_2812, IL_281d, IL_2846, IL_285d, IL_2870, IL_287e, IL_288c, IL_28a0, IL_28df, IL_28f2, IL_28fd, IL_290b, IL_294b, IL_2968, IL_2978, IL_2983, IL_298e, IL_299c, IL_29c0, IL_29ce, IL_29de, IL_29f1, IL_2a04, IL_2a0e, IL_2a19, IL_2a29, IL_2a39, IL_2a49, IL_2a62, IL_2a72, IL_2a82, IL_2a92, IL_2aa2, IL_2ab2 are reachable both inside and outside the pinned region starting at IL_2ac7. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 255;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef70 = default(int);
			ref int reference = ref __rxRef70;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2ab2:
					num2 = 1;
					while (true)
					{
						IL_2aa2:
						num3 = num2 * 4;
						while (true)
						{
							IL_2a92:
							num4 = num2 * 8;
							while (true)
							{
								IL_2a82:
								array2 = new byte[8];
								while (true)
								{
									IL_2a72:
									array3 = new object[8];
									while (true)
									{
										IL_2a62:
										array4 = new int[8];
										while (true)
										{
											IL_2a49:
											array5 = new int[7];
											num = 404;
											while (true)
											{
												IL_2a39:
												array6 = new long[8];
												while (true)
												{
													IL_2a29:
													array7 = new object[22];
													while (true)
													{
														IL_2a19:
														array7[0] = this;
														while (true)
														{
															IL_2a0e:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsFixedSizeMoveFile.StackFrameHelpertdesc);
															while (true)
															{
																IL_2a04:
																ptr2 = ptr;
																while (true)
																{
																	IL_29f1:
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_09ed:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_09dd:
																			ptr2++;
																			while (true)
																			{
																				IL_09cd:
																				if (b >= 1)
																				{
																					while (b <= 69)
																					{
																						num = 289;
																						while (true)
																						{
																							IL_09aa:
																							if (35 < b)
																							{
																								while (true)
																								{
																									IL_099a:
																									if (52 >= b)
																									{
																										while (true)
																										{
																											IL_098a:
																											if (52 > b)
																											{
																												while (true)
																												{
																													IL_0977:
																													if (43 >= b)
																													{
																														num = 121;
																														while (true)
																														{
																															IL_0967:
																															if (43 > b)
																															{
																																while (true)
																																{
																																	IL_0957:
																																	if (39 >= b)
																																	{
																																		while (true)
																																		{
																																			IL_0947:
																																			if (39 > b)
																																			{
																																				while (true)
																																				{
																																					IL_0934:
																																					if (37 >= b)
																																					{
																																						num = 570;
																																						while (true)
																																						{
																																							if (num != 570)
																																							{
																																								if (num != 1551)
																																								{
																																									break;
																																								}
																																								switch (num)
																																								{
																																								case 255:
																																									break;
																																								default:
																																									continue;
																																								case 295:
																																									goto IL_0934;
																																								case 145:
																																									goto IL_0947;
																																								case 216:
																																									goto IL_0957;
																																								case 121:
																																									goto IL_0967;
																																								case 218:
																																									goto IL_0977;
																																								case 3:
																																									goto IL_098a;
																																								case 131:
																																									goto IL_099a;
																																								case 289:
																																									goto IL_09aa;
																																								case 104:
																																									goto IL_09ba;
																																								case 345:
																																									goto IL_09cd;
																																								case 401:
																																									goto IL_09dd;
																																								case 357:
																																								case 371:
																																									goto IL_09ed;
																																								case 32:
																																									goto IL_09f8;
																																								case 169:
																																									goto IL_0a0b;
																																								case 227:
																																									goto IL_0a19;
																																								case 85:
																																									goto IL_0a27;
																																								case 11:
																																									goto IL_0a35;
																																								case 178:
																																									goto IL_0a43;
																																								case 192:
																																								case 230:
																																									goto IL_0a51;
																																								case 200:
																																								case 312:
																																									goto IL_0a67;
																																								case 318:
																																									goto IL_0a86;
																																								case 58:
																																									goto IL_0ac5;
																																								case 349:
																																									goto IL_0ad8;
																																								case 430:
																																									goto IL_0b17;
																																								case 163:
																																								case 451:
																																									goto IL_0b2a;
																																								case 56:
																																									goto IL_0b3e;
																																								case 420:
																																									goto IL_0bcf;
																																								case 226:
																																									goto IL_0bdd;
																																								case 455:
																																									goto IL_0bf0;
																																								case 93:
																																									goto IL_0bfe;
																																								case 177:
																																									goto IL_0c09;
																																								case 46:
																																									goto IL_0c20;
																																								case 277:
																																								case 442:
																																									goto IL_0c37;
																																								case 148:
																																									goto IL_0c62;
																																								case 494:
																																									goto IL_0c7b;
																																								case 139:
																																								case 429:
																																									goto IL_0c92;
																																								case 470:
																																									goto IL_0cc9;
																																								case 508:
																																									goto IL_0cdc;
																																								case 96:
																																								case 181:
																																									goto IL_0cea;
																																								case 517:
																																									goto IL_0d18;
																																								case 103:
																																								case 334:
																																									goto IL_0d23;
																																								case 315:
																																									goto IL_0d37;
																																								case 305:
																																									goto IL_0d76;
																																								case 267:
																																									goto IL_0d89;
																																								case 198:
																																									goto IL_0d97;
																																								case 152:
																																								case 480:
																																									goto IL_0da5;
																																								case 529:
																																									goto IL_0dc3;
																																								case 42:
																																								case 243:
																																									goto IL_0dce;
																																								case 445:
																																									goto IL_0e0e;
																																								case 417:
																																									goto IL_0e22;
																																								case 374:
																																									goto IL_0e35;
																																								case 528:
																																									goto IL_0e43;
																																								case 215:
																																								case 245:
																																									goto IL_0e51;
																																								case 241:
																																									goto IL_0e65;
																																								case 531:
																																									goto IL_0ee0;
																																								case 74:
																																									goto IL_0eee;
																																								case 399:
																																								case 537:
																																									goto IL_0f01;
																																								case 276:
																																									goto IL_0f2a;
																																								case 538:
																																									goto IL_0f43;
																																								case 291:
																																									goto IL_0f51;
																																								case 444:
																																									goto IL_0f5f;
																																								case 75:
																																									goto IL_0f6d;
																																								case 234:
																																									goto IL_0f7b;
																																								case 184:
																																								case 521:
																																									goto IL_0f86;
																																								case 411:
																																									goto IL_0f9a;
																																								case 224:
																																									goto IL_0fd9;
																																								case 235:
																																									goto IL_0fec;
																																								case 182:
																																									goto IL_0ffa;
																																								case 214:
																																								case 511:
																																									goto IL_1005;
																																								case 269:
																																									goto IL_1019;
																																								case 423:
																																									goto IL_1058;
																																								case 344:
																																									goto IL_106b;
																																								case 475:
																																									goto IL_1079;
																																								case 69:
																																								case 132:
																																									goto IL_1087;
																																								case 225:
																																									goto IL_10a0;
																																								case 253:
																																									goto IL_10b3;
																																								case 434:
																																									goto IL_10c6;
																																								case 50:
																																									goto IL_10d4;
																																								case 126:
																																									goto IL_10df;
																																								case 194:
																																									goto IL_10ed;
																																								case 27:
																																								case 279:
																																									goto IL_10fb;
																																								case 59:
																																									goto IL_1124;
																																								case 54:
																																								case 281:
																																									goto IL_1146;
																																								case 164:
																																									goto IL_115a;
																																								case 450:
																																									goto IL_1199;
																																								case 174:
																																									goto IL_11ac;
																																								case 6:
																																									goto IL_11b7;
																																								case 308:
																																								case 314:
																																									goto IL_11c5;
																																								case 73:
																																									goto IL_11d9;
																																								case 389:
																																									goto IL_121d;
																																								case 53:
																																									goto IL_122b;
																																								case 188:
																																								case 505:
																																									goto IL_1239;
																																								case 48:
																																									goto IL_1262;
																																								case 128:
																																									goto IL_1284;
																																								case 336:
																																								case 495:
																																									goto IL_1298;
																																								case 303:
																																									goto IL_12b5;
																																								case 413:
																																									goto IL_12ed;
																																								case 328:
																																									goto end_IL_0921;
																																								case 101:
																																									goto IL_1317;
																																								case 205:
																																								case 273:
																																									goto IL_1322;
																																								case 33:
																																									goto IL_1363;
																																								case 297:
																																									goto IL_1377;
																																								case 436:
																																									goto IL_138a;
																																								case 272:
																																									goto IL_1398;
																																								case 170:
																																								case 186:
																																									goto IL_13a3;
																																								case 26:
																																									goto IL_13bc;
																																								case 500:
																																									goto IL_13ca;
																																								case 247:
																																									goto IL_13d8;
																																								case 519:
																																									goto IL_13eb;
																																								case 310:
																																									goto IL_13f9;
																																								case 307:
																																								case 416:
																																									goto IL_1407;
																																								case 124:
																																									goto IL_141b;
																																								case 142:
																																									goto IL_1453;
																																								case 41:
																																									goto IL_1466;
																																								case 189:
																																									goto IL_1474;
																																								case 114:
																																								case 459:
																																									goto IL_1482;
																																								case 1:
																																									goto IL_149a;
																																								case 464:
																																									goto IL_14a8;
																																								case 454:
																																									goto IL_14b3;
																																								case 120:
																																								case 271:
																																									goto IL_14c1;
																																								case 424:
																																									goto IL_14d4;
																																								case 306:
																																									goto IL_14e2;
																																								case 5:
																																								case 379:
																																									goto IL_14f0;
																																								case 223:
																																									goto IL_1504;
																																								case 30:
																																									goto IL_153c;
																																								case 542:
																																									goto IL_154f;
																																								case 250:
																																								case 355:
																																									goto IL_155a;
																																								case 283:
																																									goto IL_1576;
																																								case 240:
																																									goto IL_158d;
																																								case 99:
																																								case 351:
																																									goto IL_159b;
																																								case 212:
																																									goto IL_15ed;
																																								case 545:
																																									goto IL_1600;
																																								case 102:
																																									goto IL_161e;
																																								case 397:
																																									goto IL_162c;
																																								case 546:
																																									goto IL_163f;
																																								case 471:
																																									goto IL_164d;
																																								case 550:
																																									goto IL_1660;
																																								case 8:
																																								case 158:
																																									goto IL_166b;
																																								case 487:
																																									goto IL_16a9;
																																								case 246:
																																									goto IL_16bc;
																																								case 280:
																																									goto IL_16ca;
																																								case 20:
																																								case 24:
																																									goto IL_16d5;
																																								case 143:
																																									goto IL_16e8;
																																								case 110:
																																									goto IL_16f6;
																																								case 51:
																																									goto IL_1704;
																																								case 15:
																																									goto IL_1712;
																																								case 2:
																																								case 155:
																																									goto IL_171d;
																																								case 368:
																																									goto IL_175d;
																																								case 134:
																																									goto IL_1771;
																																								case 316:
																																									goto IL_1784;
																																								case 479:
																																									goto IL_1792;
																																								case 209:
																																								case 496:
																																									goto IL_17a0;
																																								case 18:
																																									goto IL_17b9;
																																								case 332:
																																									goto IL_17d0;
																																								case 43:
																																									goto IL_17de;
																																								case 282:
																																									goto IL_17f1;
																																								case 321:
																																									goto IL_17ff;
																																								case 193:
																																								case 456:
																																									goto IL_180d;
																																								case 117:
																																									goto IL_1836;
																																								case 187:
																																									goto IL_1844;
																																								case 115:
																																								case 166:
																																									goto IL_1857;
																																								case 36:
																																									goto IL_1865;
																																								case 469:
																																									goto IL_1888;
																																								case 125:
																																									goto IL_1892;
																																								case 67:
																																									goto IL_18ae;
																																								case 232:
																																									goto IL_18bc;
																																								case 378:
																																									goto IL_18d3;
																																								case 203:
																																								case 465:
																																									goto IL_18e1;
																																								case 23:
																																									goto IL_1921;
																																								case 256:
																																									goto IL_1935;
																																								case 407:
																																									goto IL_1948;
																																								case 196:
																																									goto IL_1956;
																																								case 14:
																																									goto IL_1964;
																																								case 248:
																																								case 292:
																																									goto IL_1972;
																																								case 140:
																																									goto IL_19b2;
																																								case 68:
																																									goto IL_19c6;
																																								case 57:
																																								case 290:
																																									goto IL_19d9;
																																								case 486:
																																									goto IL_1a19;
																																								case 197:
																																									goto IL_1a36;
																																								case 137:
																																									goto IL_1a49;
																																								case 147:
																																									goto IL_1a57;
																																								case 31:
																																								case 278:
																																									goto IL_1a65;
																																								case 208:
																																									goto IL_1b1c;
																																								case 402:
																																									goto IL_1b2a;
																																								case 217:
																																									goto IL_1b3d;
																																								case 81:
																																									goto IL_1b4b;
																																								case 13:
																																								case 437:
																																									goto IL_1b56;
																																								case 261:
																																									goto IL_1bb8;
																																								case 141:
																																									goto IL_1bcb;
																																								case 354:
																																									goto IL_1be2;
																																								case 156:
																																								case 237:
																																									goto IL_1bf0;
																																								case 512:
																																									goto IL_1c39;
																																								case 294:
																																									goto IL_1c4d;
																																								case 409:
																																									goto IL_1c60;
																																								case 347:
																																									goto IL_1c6e;
																																								case 25:
																																									goto IL_1c81;
																																								case 95:
																																									goto IL_1c8f;
																																								case 179:
																																								case 421:
																																									goto IL_1c9a;
																																								case 89:
																																									goto IL_1cc3;
																																								case 171:
																																									goto IL_1cdc;
																																								case 457:
																																									goto IL_1cea;
																																								case 394:
																																								case 447:
																																									goto IL_1d01;
																																								case 82:
																																									goto IL_1d1f;
																																								case 113:
																																									goto IL_1d36;
																																								case 265:
																																									goto IL_1d49;
																																								case 325:
																																									goto IL_1d57;
																																								case 107:
																																								case 168:
																																									goto IL_1d65;
																																								case 443:
																																									goto IL_1d7d;
																																								case 406:
																																									goto IL_1d9b;
																																								case 274:
																																									goto IL_1dbf;
																																								case 301:
																																									goto IL_1dd7;
																																								case 286:
																																									goto IL_1dea;
																																								case 329:
																																									goto IL_1df8;
																																								case 239:
																																								case 474:
																																									goto IL_1e06;
																																								case 343:
																																									goto IL_1e14;
																																								case 60:
																																									goto IL_1e2c;
																																								case 49:
																																									goto IL_1e3a;
																																								case 551:
																																									goto IL_1e56;
																																								case 133:
																																								case 369:
																																									goto IL_1e64;
																																								case 266:
																																									goto IL_1ea4;
																																								case 485:
																																									goto IL_1ec1;
																																								case 553:
																																									goto IL_1ed4;
																																								case 555:
																																									goto IL_1ee7;
																																								case 229:
																																								case 556:
																																									goto IL_1efa;
																																								case 222:
																																									goto IL_1f33;
																																								case 559:
																																									goto IL_1f4f;
																																								case 561:
																																									goto IL_1f68;
																																								case 300:
																																								case 395:
																																									goto IL_1f86;
																																								case 396:
																																									goto IL_1fc4;
																																								case 37:
																																									goto IL_1fd8;
																																								case 326:
																																									goto IL_1feb;
																																								case 317:
																																									goto IL_1ff9;
																																								case 337:
																																								case 342:
																																									goto IL_2007;
																																								case 80:
																																									goto IL_201f;
																																								case 167:
																																									goto IL_202d;
																																								case 100:
																																									goto IL_203b;
																																								case 105:
																																									goto IL_204e;
																																								case 527:
																																									goto IL_205c;
																																								case 287:
																																								case 439:
																																									goto IL_2067;
																																								case 161:
																																									goto IL_207b;
																																								case 284:
																																									goto IL_20ba;
																																								case 219:
																																									goto IL_20cd;
																																								case 221:
																																									goto IL_20db;
																																								case 165:
																																								case 352:
																																									goto IL_20e9;
																																								case 482:
																																									goto IL_2129;
																																								case 94:
																																									goto IL_213d;
																																								case 40:
																																									goto IL_2150;
																																								case 453:
																																									goto IL_215e;
																																								case 249:
																																								case 557:
																																									goto IL_216c;
																																								case 207:
																																									goto IL_2186;
																																								case 518:
																																									goto IL_2194;
																																								case 524:
																																									goto IL_21a2;
																																								case 375:
																																								case 541:
																																									goto IL_21be;
																																								case 76:
																																									goto IL_21cc;
																																								case 238:
																																									goto IL_21f0;
																																								case 563:
																																									goto IL_21fe;
																																								case 435:
																																									goto IL_2211;
																																								case 361:
																																									goto IL_221f;
																																								case 356:
																																									goto IL_222d;
																																								case 154:
																																									goto IL_223b;
																																								case 195:
																																									goto IL_2252;
																																								case 35:
																																								case 392:
																																									goto IL_225d;
																																								case 10:
																																									goto IL_2271;
																																								case 61:
																																									goto IL_22b0;
																																								case 452:
																																									goto IL_22cc;
																																								case 462:
																																									goto IL_22da;
																																								case 129:
																																								case 350:
																																									goto IL_22e8;
																																								case 366:
																																									goto IL_2356;
																																								case 562:
																																									goto IL_2369;
																																								case 231:
																																									goto IL_2377;
																																								case 4:
																																								case 98:
																																									goto IL_2385;
																																								case 311:
																																									goto IL_239a;
																																								case 65:
																																								case 534:
																																									goto IL_23ad;
																																								case 458:
																																									goto IL_23c1;
																																								case 510:
																																									goto IL_2400;
																																								case 405:
																																									goto IL_2413;
																																								case 348:
																																									goto IL_2421;
																																								case 415:
																																									goto IL_242f;
																																								case 502:
																																									goto IL_243d;
																																								case 185:
																																								case 323:
																																									goto IL_244b;
																																								case 333:
																																									goto IL_2489;
																																								case 180:
																																									goto IL_249d;
																																								case 77:
																																								case 377:
																																									goto IL_24b0;
																																								case 460:
																																									goto IL_24be;
																																								case 473:
																																									goto IL_24e2;
																																								case 92:
																																									goto IL_24f9;
																																								case 425:
																																									goto IL_250c;
																																								case 242:
																																									goto IL_2517;
																																								case 335:
																																								case 477:
																																									goto IL_2525;
																																								case 400:
																																									goto IL_2553;
																																								case 381:
																																									goto IL_2566;
																																								case 79:
																																									goto IL_2574;
																																								case 526:
																																									goto IL_2587;
																																								case 19:
																																								case 199:
																																									goto IL_2592;
																																								case 367:
																																									goto IL_25d0;
																																								case 536:
																																									goto IL_25e4;
																																								case 373:
																																									goto IL_25f7;
																																								case 260:
																																									goto IL_260e;
																																								case 34:
																																								case 45:
																																									goto IL_2619;
																																								case 414:
																																									goto IL_2657;
																																								case 97:
																																									goto IL_266b;
																																								case 244:
																																									goto IL_267e;
																																								case 383:
																																									goto IL_268c;
																																								case 362:
																																									goto IL_269a;
																																								case 339:
																																									goto IL_26a8;
																																								case 0:
																																								case 525:
																																									goto IL_26b6;
																																								case 472:
																																									goto IL_2714;
																																								case 190:
																																								case 463:
																																									goto IL_2727;
																																								case 122:
																																									goto IL_273b;
																																								case 504:
																																									goto IL_277a;
																																								case 419:
																																									goto IL_278d;
																																								case 62:
																																									goto IL_279b;
																																								case 268:
																																								case 492:
																																									goto IL_27a9;
																																								case 236:
																																									goto IL_27d5;
																																								case 506:
																																									goto IL_27e3;
																																								case 12:
																																									goto IL_27f1;
																																								case 173:
																																									goto IL_2804;
																																								case 385:
																																									goto IL_2812;
																																								case 288:
																																								case 543:
																																									goto IL_281d;
																																								case 532:
																																									goto IL_2846;
																																								case 427:
																																									goto IL_285d;
																																								case 111:
																																									goto IL_2870;
																																								case 548:
																																									goto IL_287e;
																																								case 64:
																																								case 262:
																																									goto IL_288c;
																																								case 202:
																																									goto IL_28a0;
																																								case 319:
																																									goto IL_28df;
																																								case 449:
																																									goto IL_28f2;
																																								case 520:
																																									goto IL_28fd;
																																								case 90:
																																								case 213:
																																									goto IL_290b;
																																								case 388:
																																									goto IL_294b;
																																								case 441:
																																									goto IL_2968;
																																								case 153:
																																									goto IL_2978;
																																								case 503:
																																									goto IL_2983;
																																								case 488:
																																								case 539:
																																									goto IL_298e;
																																								case 489:
																																									goto IL_299c;
																																								case 228:
																																									goto IL_29c0;
																																								case 106:
																																									goto IL_29ce;
																																								case 7:
																																								case 16:
																																								case 17:
																																								case 21:
																																								case 22:
																																								case 29:
																																								case 38:
																																								case 39:
																																								case 47:
																																								case 63:
																																								case 66:
																																								case 72:
																																								case 83:
																																								case 87:
																																								case 91:
																																								case 108:
																																								case 118:
																																								case 119:
																																								case 130:
																																								case 136:
																																								case 138:
																																								case 144:
																																								case 150:
																																								case 159:
																																								case 160:
																																								case 162:
																																								case 175:
																																								case 204:
																																								case 210:
																																								case 220:
																																								case 252:
																																								case 264:
																																								case 275:
																																								case 296:
																																								case 299:
																																								case 309:
																																								case 313:
																																								case 327:
																																								case 331:
																																								case 341:
																																								case 358:
																																								case 363:
																																								case 372:
																																								case 382:
																																								case 386:
																																								case 387:
																																								case 398:
																																								case 403:
																																								case 418:
																																								case 422:
																																								case 431:
																																								case 432:
																																								case 438:
																																								case 440:
																																								case 466:
																																								case 467:
																																								case 476:
																																								case 478:
																																								case 483:
																																								case 490:
																																								case 499:
																																								case 501:
																																								case 514:
																																								case 516:
																																								case 522:
																																								case 530:
																																								case 535:
																																								case 544:
																																								case 549:
																																								case 552:
																																								case 554:
																																								case 558:
																																									goto end_IL_09ba;
																																								case 9:
																																								case 28:
																																								case 44:
																																								case 52:
																																								case 55:
																																								case 70:
																																								case 78:
																																								case 84:
																																								case 86:
																																								case 88:
																																								case 109:
																																								case 112:
																																								case 123:
																																								case 127:
																																								case 135:
																																								case 149:
																																								case 151:
																																								case 157:
																																								case 176:
																																								case 183:
																																								case 191:
																																								case 201:
																																								case 211:
																																								case 233:
																																								case 251:
																																								case 257:
																																								case 258:
																																								case 259:
																																								case 270:
																																								case 285:
																																								case 293:
																																								case 298:
																																								case 302:
																																								case 304:
																																								case 320:
																																								case 322:
																																								case 324:
																																								case 330:
																																								case 338:
																																								case 340:
																																								case 346:
																																								case 353:
																																								case 360:
																																								case 364:
																																								case 365:
																																								case 370:
																																								case 380:
																																								case 384:
																																								case 391:
																																								case 393:
																																								case 408:
																																								case 410:
																																								case 412:
																																								case 426:
																																								case 428:
																																								case 433:
																																								case 446:
																																								case 448:
																																								case 461:
																																								case 468:
																																								case 481:
																																								case 484:
																																								case 493:
																																								case 497:
																																								case 509:
																																								case 513:
																																								case 515:
																																								case 523:
																																								case 533:
																																								case 540:
																																								case 547:
																																								case 560:
																																									goto IL_29f1;
																																								case 498:
																																									goto IL_2a04;
																																								case 172:
																																									goto IL_2a0e;
																																								case 146:
																																									goto IL_2a19;
																																								case 71:
																																									goto IL_2a29;
																																								case 404:
																																									goto IL_2a39;
																																								case 116:
																																									goto IL_2a49;
																																								case 390:
																																									goto IL_2a62;
																																								case 376:
																																									goto IL_2a72;
																																								case 359:
																																									goto IL_2a82;
																																								case 206:
																																									goto IL_2a92;
																																								case 491:
																																									goto IL_2aa2;
																																								case 254:
																																									goto IL_2ab2;
																																								case 263:
																																								case 507:
																																									return;
																																								}
																																								goto end_IL_09aa;
																																							}
																																							if (37 <= b)
																																							{
																																								goto IL_1f86;
																																							}
																																							goto IL_1feb;
																																							IL_201f:
																																							array2[num6] = 5;
																																							goto IL_202d;
																																							IL_203b:
																																							ptr2 += 8;
																																							goto IL_29f1;
																																							IL_202d:
																																							num6++;
																																							goto IL_203b;
																																							IL_1f86:
																																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class16, bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class16)array3[num6 - 1]) ? 1 : 0);
																																							goto IL_1fc4;
																																							IL_1fc4:
																																							array2[num6 - 1] = 0;
																																							goto IL_1fd8;
																																							IL_1fd8:
																																							ptr2 += 8;
																																							goto IL_29f1;
																																							IL_1feb:
																																							if (36 < b)
																																							{
																																								goto end_IL_09ba;
																																							}
																																							goto IL_1ff9;
																																							IL_1ff9:
																																							if (36 > b)
																																							{
																																								goto end_IL_09ba;
																																							}
																																							goto IL_2007;
																																							IL_2007:
																																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																																							goto IL_201f;
																																							continue;
																																							end_IL_0921:
																																							break;
																																						}
																																						break;
																																					}
																																					goto IL_09f8;
																																					IL_0cea:
																																					array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																																					goto IL_1f4f;
																																					IL_1f4f:
																																					array2[num6 - 1] = 5;
																																					goto IL_29f1;
																																					IL_09f8:
																																					if (38 < b)
																																					{
																																						goto end_IL_09ba;
																																					}
																																					goto IL_0cdc;
																																					IL_0cdc:
																																					if (38 > b)
																																					{
																																						goto end_IL_09ba;
																																					}
																																					goto IL_0cea;
																																				}
																																				break;
																																			}
																																			goto IL_0a67;
																																			IL_0b17:
																																			ptr2 += 8;
																																			goto IL_29f1;
																																			IL_0a67:
																																			array2[num6 - 1] = 3;
																																			num = 349;
																																			goto IL_0ad8;
																																			IL_0ad8:
																																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																			goto IL_0b17;
																																		}
																																		break;
																																	}
																																	goto IL_204e;
																																	IL_21a2:
																																	ptr2 += 8;
																																	num = 151;
																																	goto IL_29f1;
																																	IL_204e:
																																	if (41 >= b)
																																	{
																																		goto IL_205c;
																																	}
																																	goto IL_2150;
																																	IL_205c:
																																	if (41 <= b)
																																	{
																																		goto IL_2067;
																																	}
																																	goto IL_20cd;
																																	IL_2067:
																																	array2[num6 - 1] = 0;
																																	goto IL_207b;
																																	IL_207b:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																	goto IL_20ba;
																																	IL_20ba:
																																	ptr2 += 8;
																																	goto IL_29f1;
																																	IL_20cd:
																																	if (40 < b)
																																	{
																																		goto end_IL_09ba;
																																	}
																																	goto IL_20db;
																																	IL_20db:
																																	if (40 > b)
																																	{
																																		goto end_IL_09ba;
																																	}
																																	goto IL_20e9;
																																	IL_20e9:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	goto IL_2129;
																																	IL_2129:
																																	array2[num6 - 2] = 3;
																																	goto IL_213d;
																																	IL_213d:
																																	num6--;
																																	goto IL_29f1;
																																	IL_2150:
																																	if (42 < b)
																																	{
																																		goto end_IL_09ba;
																																	}
																																	goto IL_215e;
																																	IL_215e:
																																	if (42 > b)
																																	{
																																		goto end_IL_09ba;
																																	}
																																	goto IL_216c;
																																	IL_216c:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																																	goto IL_2186;
																																	IL_2186:
																																	array2[num6] = 3;
																																	goto IL_2194;
																																	IL_2194:
																																	num6++;
																																	goto IL_21a2;
																																}
																																break;
																															}
																															goto IL_0f01;
																															IL_0f2a:
																															array2[num6 - 1] = 5;
																															goto IL_29f1;
																															IL_0f01:
																															array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																															goto IL_0f2a;
																														}
																														break;
																													}
																													goto IL_0a0b;
																													IL_0d76:
																													ptr2 += 8;
																													goto IL_29f1;
																													IL_0d89:
																													if (48 < b)
																													{
																														goto end_IL_09ba;
																													}
																													goto IL_0d97;
																													IL_0a0b:
																													if (47 >= b)
																													{
																														goto IL_0a19;
																													}
																													goto IL_0bf0;
																													IL_0a19:
																													if (47 > b)
																													{
																														goto IL_0a27;
																													}
																													goto IL_0b2a;
																													IL_0a27:
																													if (45 < b)
																													{
																														goto IL_0a35;
																													}
																													goto IL_0dc3;
																													IL_0a35:
																													if (46 < b)
																													{
																														goto end_IL_09ba;
																													}
																													goto IL_0a43;
																													IL_0a43:
																													if (46 > b)
																													{
																														goto end_IL_09ba;
																													}
																													goto IL_0a51;
																													IL_0a51:
																													array2[num6 - 1] = 0;
																													goto IL_0a86;
																													IL_0a86:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_0ac5;
																													IL_0ac5:
																													ptr2 += 8;
																													goto IL_29f1;
																													IL_0dc3:
																													if (45 <= b)
																													{
																														goto IL_0dce;
																													}
																													goto IL_0e35;
																													IL_0dce:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0e0e;
																													IL_0e0e:
																													array2[num6 - 2] = 3;
																													goto IL_0e22;
																													IL_0e22:
																													num6--;
																													goto IL_29f1;
																													IL_0e35:
																													if (44 < b)
																													{
																														goto end_IL_09ba;
																													}
																													goto IL_0e43;
																													IL_0e43:
																													if (44 > b)
																													{
																														goto end_IL_09ba;
																													}
																													goto IL_0e51;
																													IL_0e51:
																													array2[num6 - 4] = 0;
																													goto IL_0e65;
																													IL_0e65:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
																													goto IL_0ee0;
																													IL_0ee0:
																													num6 -= 3;
																													goto IL_0eee;
																													IL_0eee:
																													ptr2 += 8;
																													goto IL_29f1;
																													IL_0b2a:
																													array2[num6 - 5] = 4;
																													goto IL_0b3e;
																													IL_0b3e:
																													array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																													goto IL_0bcf;
																													IL_0bcf:
																													num6 -= 4;
																													goto IL_0bdd;
																													IL_0bdd:
																													ptr2 += 8;
																													goto IL_29f1;
																													IL_0bf0:
																													if (49 < b)
																													{
																														goto IL_0bfe;
																													}
																													goto IL_0d18;
																													IL_0bfe:
																													if (50 < b)
																													{
																														goto IL_0c09;
																													}
																													goto IL_0c7b;
																													IL_0c09:
																													if (51 < b)
																													{
																														goto end_IL_09ba;
																													}
																													num = 46;
																													goto IL_0c20;
																													IL_0d97:
																													if (48 > b)
																													{
																														goto end_IL_09ba;
																													}
																													goto IL_0da5;
																													IL_0c20:
																													if (51 > b)
																													{
																														goto end_IL_09ba;
																													}
																													num = 442;
																													goto IL_0c37;
																													IL_0da5:
																													global::_003CModule_003E.gunResult_0 = (Class8.GunResult)array3[num6 - 1];
																													goto IL_1ed4;
																													IL_0c37:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0c62;
																													IL_0c62:
																													array2[num6 - 1] = 0;
																													goto IL_29f1;
																													IL_0c7b:
																													if (50 > b)
																													{
																														goto end_IL_09ba;
																													}
																													num = 139;
																													goto IL_0c92;
																													IL_1ed4:
																													num6--;
																													goto IL_29f1;
																													IL_0c92:
																													((Class16)array3[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																													num = 470;
																													goto IL_0cc9;
																													IL_0cc9:
																													num6 -= 2;
																													goto IL_29f1;
																													IL_0d18:
																													if (49 <= b)
																													{
																														goto IL_0d23;
																													}
																													goto IL_0d89;
																													IL_0d23:
																													array2[num6 - 1] = 3;
																													goto IL_0d37;
																													IL_0d37:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_0d76;
																												}
																												break;
																											}
																											goto IL_21be;
																											IL_21fe:
																											ptr2 += 8;
																											goto IL_29f1;
																											IL_21be:
																											array2[num6] = 0;
																											goto IL_21cc;
																											IL_21cc:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])() ? 1 : 0);
																											goto IL_21f0;
																											IL_21f0:
																											num6++;
																											goto IL_21fe;
																										}
																										break;
																									}
																									goto IL_2211;
																									IL_299c:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																									goto IL_29c0;
																									IL_2211:
																									if (61 < b)
																									{
																										goto IL_221f;
																									}
																									goto IL_2587;
																									IL_221f:
																									if (65 >= b)
																									{
																										goto IL_222d;
																									}
																									goto IL_2413;
																									IL_222d:
																									if (65 > b)
																									{
																										goto IL_223b;
																									}
																									goto IL_23ad;
																									IL_223b:
																									if (63 >= b)
																									{
																										num = 195;
																										goto IL_2252;
																									}
																									goto IL_2369;
																									IL_29c0:
																									num6++;
																									goto IL_29ce;
																									IL_2252:
																									if (63 <= b)
																									{
																										goto IL_225d;
																									}
																									goto IL_22cc;
																									IL_225d:
																									array2[num6 - 1] = 3;
																									goto IL_2271;
																									IL_2271:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_22b0;
																									IL_22b0:
																									ptr2 += 8;
																									num = 523;
																									goto IL_29f1;
																									IL_22cc:
																									if (62 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_22da;
																									IL_22da:
																									if (62 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_22e8;
																									IL_22e8:
																									ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_2356;
																									IL_2356:
																									num6 -= 2;
																									goto IL_29f1;
																									IL_2369:
																									if (64 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_2377;
																									IL_2377:
																									if (64 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_2385;
																									IL_2385:
																									((delegate*<void>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																									goto IL_239a;
																									IL_239a:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_23ad:
																									array2[num6 - 1] = 3;
																									goto IL_23c1;
																									IL_23c1:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_2400;
																									IL_2400:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_2413:
																									if (67 >= b)
																									{
																										goto IL_2421;
																									}
																									goto IL_250c;
																									IL_2421:
																									if (67 > b)
																									{
																										goto IL_242f;
																									}
																									goto IL_24b0;
																									IL_242f:
																									if (66 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_243d;
																									IL_243d:
																									if (66 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_244b;
																									IL_244b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																									goto IL_2489;
																									IL_2489:
																									array2[num6 - 1] = 0;
																									goto IL_249d;
																									IL_249d:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_24b0:
																									array2[num6] = 3;
																									goto IL_24be;
																									IL_24be:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																									goto IL_24e2;
																									IL_24e2:
																									num6++;
																									num = 92;
																									goto IL_24f9;
																									IL_24f9:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_250c:
																									if (68 >= b)
																									{
																										goto IL_2517;
																									}
																									goto IL_2566;
																									IL_2517:
																									if (68 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_2525;
																									IL_2525:
																									((Class16)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_2553;
																									IL_2553:
																									num6 -= 2;
																									goto IL_29f1;
																									IL_2566:
																									if (69 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_2574;
																									IL_2574:
																									if (69 > b)
																									{
																									}
																									goto end_IL_09ba;
																									IL_2587:
																									if (61 <= b)
																									{
																										goto IL_2592;
																									}
																									goto IL_25f7;
																									IL_2592:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class16, float>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class16)array3[num6 - 1]);
																									goto IL_25d0;
																									IL_25d0:
																									array2[num6 - 1] = 3;
																									goto IL_25e4;
																									IL_25e4:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_25f7:
																									if (56 >= b)
																									{
																										num = 260;
																										goto IL_260e;
																									}
																									goto IL_2804;
																									IL_29ce:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_260e:
																									if (56 <= b)
																									{
																										goto IL_2619;
																									}
																									goto IL_267e;
																									IL_2619:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																									goto IL_2657;
																									IL_2657:
																									array2[num6 - 1] = 0;
																									goto IL_266b;
																									IL_266b:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_267e:
																									if (54 >= b)
																									{
																										goto IL_268c;
																									}
																									goto IL_278d;
																									IL_268c:
																									if (54 > b)
																									{
																										goto IL_269a;
																									}
																									goto IL_2727;
																									IL_269a:
																									if (53 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_26a8;
																									IL_26a8:
																									if (53 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_26b6;
																									IL_26b6:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_2714;
																									IL_2714:
																									num6--;
																									goto IL_29f1;
																									IL_2727:
																									array2[num6 - 1] = 3;
																									goto IL_273b;
																									IL_273b:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_277a;
																									IL_277a:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_278d:
																									if (55 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_279b;
																									IL_279b:
																									if (55 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_27a9;
																									IL_27a9:
																									array3[num6] = ((delegate*<Class8.GunResult>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																									num = 236;
																									goto IL_27d5;
																									IL_27d5:
																									array2[num6] = 4;
																									goto IL_27e3;
																									IL_27e3:
																									num6++;
																									goto IL_27f1;
																									IL_27f1:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_2804:
																									if (58 >= b)
																									{
																										goto IL_2812;
																									}
																									goto IL_28f2;
																									IL_2812:
																									if (58 <= b)
																									{
																										goto IL_281d;
																									}
																									goto IL_2870;
																									IL_281d:
																									((delegate*<string, void>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																									goto IL_2846;
																									IL_2846:
																									num6--;
																									num = 427;
																									goto IL_285d;
																									IL_285d:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_2870:
																									if (57 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_287e;
																									IL_287e:
																									if (57 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_288c;
																									IL_288c:
																									array2[num6 - 1] = 3;
																									goto IL_28a0;
																									IL_28a0:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_28df;
																									IL_28df:
																									ptr2 += 8;
																									goto IL_29f1;
																									IL_28f2:
																									if (59 >= b)
																									{
																										goto IL_28fd;
																									}
																									goto IL_2978;
																									IL_28fd:
																									if (59 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_290b;
																									IL_290b:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_294b;
																									IL_294b:
																									array2[num6 - 2] = 3;
																									num = 441;
																									goto IL_2968;
																									IL_2968:
																									num6--;
																									goto IL_29f1;
																									IL_2978:
																									if (60 < b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_2983;
																									IL_2983:
																									if (60 > b)
																									{
																										goto end_IL_09ba;
																									}
																									goto IL_298e;
																									IL_298e:
																									array2[num6] = 3;
																									goto IL_299c;
																								}
																								goto IL_1309;
																							}
																							goto IL_0f43;
																							IL_1d9b:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1dbf;
																							IL_0f43:
																							if (35 > b)
																							{
																								goto IL_0f51;
																							}
																							goto IL_1efa;
																							IL_0f51:
																							if (17 < b)
																							{
																								goto IL_0f5f;
																							}
																							goto IL_1660;
																							IL_0f5f:
																							if (26 < b)
																							{
																								goto IL_0f6d;
																							}
																							num = 128;
																							goto IL_1284;
																							IL_0f6d:
																							if (30 >= b)
																							{
																								goto IL_0f7b;
																							}
																							goto IL_10c6;
																							IL_0f7b:
																							if (30 <= b)
																							{
																								goto IL_0f86;
																							}
																							goto IL_0fec;
																							IL_0f86:
																							array2[num6 - 1] = 0;
																							goto IL_0f9a;
																							IL_0f9a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0fd9;
																							IL_0fd9:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_0fec:
																							if (28 >= b)
																							{
																								goto IL_0ffa;
																							}
																							goto IL_10b3;
																							IL_0ffa:
																							if (28 <= b)
																							{
																								goto IL_1005;
																							}
																							goto IL_106b;
																							IL_1005:
																							array2[num6 - 1] = 3;
																							goto IL_1019;
																							IL_1019:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1058;
																							IL_1058:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_106b:
																							if (27 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1079;
																							IL_1079:
																							if (27 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1087;
																							IL_1087:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							goto IL_10a0;
																							IL_10a0:
																							array2[num6] = 3;
																							goto IL_163f;
																							IL_163f:
																							num6++;
																							goto IL_164d;
																							IL_164d:
																							ptr2 += 16;
																							goto IL_29f1;
																							IL_10b3:
																							if (29 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1e56;
																							IL_1e56:
																							if (29 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1e64;
																							IL_1e64:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1ea4;
																							IL_1ea4:
																							array2[num6 - 2] = 3;
																							num = 485;
																							goto IL_1ec1;
																							IL_1ec1:
																							num6--;
																							goto IL_29f1;
																							IL_10c6:
																							if (32 >= b)
																							{
																								goto IL_10d4;
																							}
																							goto IL_11ac;
																							IL_10d4:
																							if (32 > b)
																							{
																								goto IL_10df;
																							}
																							num = 54;
																							goto IL_1146;
																							IL_10df:
																							if (31 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_10ed;
																							IL_10ed:
																							if (31 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_10fb;
																							IL_10fb:
																							array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_1124;
																							IL_1124:
																							array2[num6 - 1] = 5;
																							goto IL_29f1;
																							IL_1dd7:
																							num6++;
																							goto IL_29f1;
																							IL_1146:
																							array2[num6 - 1] = 3;
																							goto IL_115a;
																							IL_115a:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1199;
																							IL_1199:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_11ac:
																							if (33 >= b)
																							{
																								goto IL_11b7;
																							}
																							goto IL_121d;
																							IL_11b7:
																							if (33 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_11c5;
																							IL_11c5:
																							array2[num6 - 1] = 0;
																							goto IL_11d9;
																							IL_11d9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1ee7;
																							IL_1ee7:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_121d:
																							if (34 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_122b;
																							IL_122b:
																							if (34 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1239;
																							IL_1239:
																							array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1262;
																							IL_1262:
																							array2[num6 - 1] = 5;
																							goto IL_29f1;
																							IL_1dbf:
																							array3[num6] = array3[num6 - 1];
																							goto IL_1dd7;
																							IL_1284:
																							if (26 <= b)
																							{
																								num = 336;
																								goto IL_1298;
																							}
																							goto IL_1309;
																							IL_1dea:
																							if (16 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1df8;
																							IL_1298:
																							array2[num6 - 1] = 5;
																							num = 303;
																							goto IL_12b5;
																							IL_12b5:
																							array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
																							goto IL_12ed;
																							IL_12ed:
																							ptr2 += 8;
																							num = 86;
																							goto IL_29f1;
																							IL_1309:
																							if (21 >= b)
																							{
																								goto IL_1317;
																							}
																							goto IL_149a;
																							IL_1317:
																							if (21 <= b)
																							{
																								goto IL_1322;
																							}
																							goto IL_138a;
																							IL_1322:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_1363;
																							IL_1363:
																							array2[num6 - 2] = 0;
																							goto IL_1377;
																							IL_1377:
																							num6--;
																							goto IL_29f1;
																							IL_138a:
																							if (19 >= b)
																							{
																								goto IL_1398;
																							}
																							goto IL_1466;
																							IL_1398:
																							if (19 <= b)
																							{
																								goto IL_13a3;
																							}
																							goto IL_13eb;
																							IL_13a3:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_13bc;
																							IL_13bc:
																							array2[num6] = 1;
																							goto IL_13ca;
																							IL_13ca:
																							num6++;
																							goto IL_13d8;
																							IL_13d8:
																							ptr2 += 16;
																							goto IL_29f1;
																							IL_13eb:
																							if (18 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_13f9;
																							IL_13f9:
																							if (18 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1407;
																							IL_1407:
																							array2[num6 - 1] = 5;
																							goto IL_141b;
																							IL_141b:
																							array3[num6 - 1] = ((delegate*<string[], string>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_1453;
																							IL_1453:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_1466:
																							if (20 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1474;
																							IL_1474:
																							if (20 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1482;
																							IL_1482:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_29f1;
																							IL_149a:
																							if (23 < b)
																							{
																								goto IL_14a8;
																							}
																							goto IL_154f;
																							IL_14a8:
																							if (24 >= b)
																							{
																								goto IL_14b3;
																							}
																							goto IL_14d4;
																							IL_14b3:
																							if (24 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_14c1;
																							IL_14c1:
																							array2[num6] = 5;
																							goto IL_1600;
																							IL_1600:
																							array3[num6] = ((delegate*<GorillaTagger>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																							goto IL_161e;
																							IL_161e:
																							num6++;
																							goto IL_162c;
																							IL_162c:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_14d4:
																							if (25 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_14e2;
																							IL_14e2:
																							if (25 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_14f0;
																							IL_14f0:
																							array2[num6 - 1] = 5;
																							goto IL_1504;
																							IL_1504:
																							array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																							goto IL_153c;
																							IL_153c:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_154f:
																							if (23 <= b)
																							{
																								goto IL_155a;
																							}
																							goto IL_1576;
																							IL_155a:
																							num7 = ptr2;
																							num8 = -200;
																							num5 = 1;
																							ptr2 = num7 + num8;
																							goto IL_29f1;
																							IL_1576:
																							if (22 < b)
																							{
																								goto end_IL_09ba;
																							}
																							num = 240;
																							goto IL_158d;
																							IL_1df8:
																							if (16 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1e06;
																							IL_158d:
																							if (22 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_159b;
																							IL_159b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_15ed;
																							IL_15ed:
																							num6--;
																							goto IL_29f1;
																							IL_1660:
																							if (17 <= b)
																							{
																								goto IL_166b;
																							}
																							goto IL_16bc;
																							IL_166b:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_16a9;
																							IL_16a9:
																							num6 -= 3;
																							goto IL_29f1;
																							IL_16bc:
																							if (8 >= b)
																							{
																								goto IL_16ca;
																							}
																							goto IL_1a49;
																							IL_16ca:
																							if (8 <= b)
																							{
																								goto IL_16d5;
																							}
																							goto IL_16e8;
																							IL_16d5:
																							num6--;
																							goto IL_29f1;
																							IL_16e8:
																							if (4 >= b)
																							{
																								goto IL_16f6;
																							}
																							goto IL_18ae;
																							IL_16f6:
																							if (4 > b)
																							{
																								goto IL_1704;
																							}
																							goto IL_1857;
																							IL_1704:
																							if (2 >= b)
																							{
																								goto IL_1712;
																							}
																							goto IL_17f1;
																							IL_1712:
																							if (2 <= b)
																							{
																								goto IL_171d;
																							}
																							goto IL_1784;
																							IL_171d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_175d;
																							IL_175d:
																							array2[num6 - 2] = 0;
																							goto IL_1771;
																							IL_1771:
																							num6--;
																							goto IL_29f1;
																							IL_1784:
																							if (1 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1792;
																							IL_1792:
																							if (1 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_17a0;
																							IL_17a0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_17b9;
																							IL_17b9:
																							array2[num6] = 0;
																							num = 332;
																							goto IL_17d0;
																							IL_17d0:
																							num6++;
																							goto IL_17de;
																							IL_17de:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_17f1:
																							if (3 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_17ff;
																							IL_17ff:
																							if (3 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_180d;
																							IL_180d:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1836;
																							IL_1836:
																							ptr2 += 8;
																							goto IL_1844;
																							IL_1844:
																							num6--;
																							goto IL_29f1;
																							IL_1857:
																							array2[num6] = 0;
																							goto IL_1865;
																							IL_1865:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_1888;
																							IL_1888:
																							array3[num6] = null;
																							goto IL_1892;
																							IL_1892:
																							num6++;
																							num = 561;
																							goto IL_1f68;
																							IL_1f68:
																							ptr2 += 8;
																							goto IL_29f1;
																							IL_18ae:
																							if (6 < b)
																							{
																								goto IL_18bc;
																							}
																							goto IL_1948;
																							IL_18bc:
																							if (7 < b)
																							{
																								goto end_IL_09ba;
																							}
																							num = 378;
																							goto IL_18d3;
																							IL_1e06:
																							array2[num6] = 5;
																							goto IL_1e14;
																							IL_18d3:
																							if (7 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_18e1;
																							IL_18e1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1921;
																							IL_1921:
																							array2[num6 - 2] = 0;
																							goto IL_1935;
																							IL_1935:
																							num6--;
																							goto IL_29f1;
																							IL_1948:
																							if (6 > b)
																							{
																								goto IL_1956;
																							}
																							goto IL_19d9;
																							IL_1956:
																							if (5 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1964;
																							IL_1964:
																							if (5 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1972;
																							IL_1972:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_19b2;
																							IL_19b2:
																							array2[num6 - 2] = 0;
																							goto IL_19c6;
																							IL_19c6:
																							num6--;
																							goto IL_29f1;
																							IL_19d9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1a19;
																							IL_1a19:
																							array2[num6 - 2] = 0;
																							num = 197;
																							goto IL_1a36;
																							IL_1a36:
																							num6--;
																							goto IL_29f1;
																							IL_1a49:
																							if (12 >= b)
																							{
																								goto IL_1a57;
																							}
																							goto IL_1c81;
																							IL_1a57:
																							if (12 <= b)
																							{
																								goto IL_1a65;
																							}
																							goto IL_1b3d;
																							IL_1a65:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_1a74;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_1b1c;
																							IL_1e14:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_1e2c;
																							IL_1e2c:
																							num6++;
																							goto IL_1e3a;
																							IL_1e3a:
																							ptr2 += 8;
																							num = 270;
																							goto IL_29f1;
																							IL_1b1c:
																							array2[num6] = 5;
																							goto IL_1b2a;
																							IL_1b2a:
																							num6++;
																							goto IL_29f1;
																							IL_1b3d:
																							if (10 >= b)
																							{
																								goto IL_1b4b;
																							}
																							goto IL_1c60;
																							IL_1b4b:
																							if (10 <= b)
																							{
																								goto IL_1b56;
																							}
																							goto IL_1bcb;
																							IL_1b56:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_1bb8;
																							IL_1bb8:
																							num6 -= 2;
																							goto IL_29f1;
																							IL_1bcb:
																							if (9 < b)
																							{
																								goto end_IL_09ba;
																							}
																							num = 354;
																							goto IL_1be2;
																							IL_1efa:
																							((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																							goto IL_1f33;
																							IL_1be2:
																							if (9 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1bf0;
																							IL_1bf0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 512;
																							goto IL_1c39;
																							IL_1c39:
																							array2[num6 - 2] = 0;
																							goto IL_1c4d;
																							IL_1c4d:
																							num6--;
																							goto IL_29f1;
																							IL_1c60:
																							if (11 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1c6e;
																							IL_1c6e:
																							if (11 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_29f1;
																							IL_1c81:
																							if (14 >= b)
																							{
																								goto IL_1c8f;
																							}
																							goto IL_1d49;
																							IL_1c8f:
																							if (14 <= b)
																							{
																								goto IL_1c9a;
																							}
																							goto IL_1cdc;
																							IL_1c9a:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_1cc3;
																							IL_1cc3:
																							array2[num6 - 1] = 5;
																							goto IL_29f1;
																							IL_1cdc:
																							if (13 < b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1cea;
																							IL_1cea:
																							if (13 > b)
																							{
																								goto end_IL_09ba;
																							}
																							num = 447;
																							goto IL_1d01;
																							IL_1f33:
																							num6 -= 3;
																							num = 493;
																							goto IL_29f1;
																							IL_1d01:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_1d1f;
																							IL_1d1f:
																							ptr2 += 8;
																							num = 113;
																							goto IL_1d36;
																							IL_1d36:
																							num6--;
																							goto IL_29f1;
																							IL_1d49:
																							if (15 >= b)
																							{
																								goto IL_1d57;
																							}
																							goto IL_1dea;
																							IL_1d57:
																							if (15 > b)
																							{
																								goto end_IL_09ba;
																							}
																							goto IL_1d65;
																							IL_1d65:
																							array2[num6] = array2[num6 - 1];
																							goto IL_1d7d;
																							IL_1d7d:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_1d9b;
																							continue;
																							end_IL_09aa:
																							break;
																						}
																						goto end_IL_09cd;
																						continue;
																						end_IL_09ba:
																						break;
																						IL_09ba:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_29f1;
																				continue;
																				end_IL_09cd:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1a74:
			while (true)
			{
				IL_1a74_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_1b1c_2:
						array2[num6] = 5;
						while (true)
						{
							IL_1b2a_2:
							num6++;
							while (true)
							{
								IL_29f1_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_09cd_2:
											if (b >= 1)
											{
												while (b <= 69)
												{
													num = 289;
													while (true)
													{
														IL_09aa_2:
														if (35 < b)
														{
															while (true)
															{
																IL_099a_2:
																if (52 >= b)
																{
																	while (true)
																	{
																		IL_098a_2:
																		if (52 > b)
																		{
																			while (true)
																			{
																				IL_0977_2:
																				if (43 >= b)
																				{
																					num = 121;
																					while (true)
																					{
																						IL_0967_2:
																						if (43 > b)
																						{
																							while (true)
																							{
																								IL_0957_2:
																								if (39 >= b)
																								{
																									while (true)
																									{
																										IL_0947_2:
																										if (39 > b)
																										{
																											while (true)
																											{
																												IL_0934_2:
																												if (37 >= b)
																												{
																													num = 570;
																													while (true)
																													{
																														if (num != 570)
																														{
																															if (num != 1551)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 295:
																																goto IL_0934_2;
																															case 145:
																																goto IL_0947_2;
																															case 216:
																																goto IL_0957_2;
																															case 121:
																																goto IL_0967_2;
																															case 218:
																																goto IL_0977_2;
																															case 3:
																																goto IL_098a_2;
																															case 131:
																																goto IL_099a_2;
																															case 289:
																																goto IL_09aa_2;
																															case 104:
																																goto end_IL_09aa_2;
																															case 345:
																																goto IL_09cd_2;
																															case 401:
																																goto end_IL_09cd_2;
																															case 357:
																															case 371:
																																goto end_IL_09dd;
																															case 32:
																																goto IL_09f8_2;
																															case 169:
																																goto IL_0a0b_2;
																															case 227:
																																goto IL_0a19_2;
																															case 85:
																																goto IL_0a27_2;
																															case 11:
																																goto IL_0a35_2;
																															case 178:
																																goto IL_0a43_2;
																															case 192:
																															case 230:
																																goto IL_0a51_2;
																															case 200:
																															case 312:
																																goto IL_0a67_2;
																															case 318:
																																goto IL_0a86_2;
																															case 58:
																																goto IL_0ac5_2;
																															case 349:
																																goto IL_0ad8_2;
																															case 430:
																																goto IL_0b17_2;
																															case 163:
																															case 451:
																																goto IL_0b2a_2;
																															case 56:
																																goto IL_0b3e_2;
																															case 420:
																																goto IL_0bcf_2;
																															case 226:
																																goto IL_0bdd_2;
																															case 455:
																																goto IL_0bf0_2;
																															case 93:
																																goto IL_0bfe_2;
																															case 177:
																																goto IL_0c09_2;
																															case 46:
																																goto IL_0c20_2;
																															case 277:
																															case 442:
																																goto IL_0c37_2;
																															case 148:
																																goto IL_0c62_2;
																															case 494:
																																goto IL_0c7b_2;
																															case 139:
																															case 429:
																																goto IL_0c92_2;
																															case 470:
																																goto IL_0cc9_2;
																															case 508:
																																goto IL_0cdc_2;
																															case 96:
																															case 181:
																																goto IL_0cea_2;
																															case 517:
																																goto IL_0d18_2;
																															case 103:
																															case 334:
																																goto IL_0d23_2;
																															case 315:
																																goto IL_0d37_2;
																															case 305:
																																goto IL_0d76_2;
																															case 267:
																																goto IL_0d89_2;
																															case 198:
																																goto IL_0d97_2;
																															case 152:
																															case 480:
																																goto IL_0da5_2;
																															case 529:
																																goto IL_0dc3_2;
																															case 42:
																															case 243:
																																goto IL_0dce_2;
																															case 445:
																																goto IL_0e0e_2;
																															case 417:
																																goto IL_0e22_2;
																															case 374:
																																goto IL_0e35_2;
																															case 528:
																																goto IL_0e43_2;
																															case 215:
																															case 245:
																																goto IL_0e51_2;
																															case 241:
																																goto IL_0e65_2;
																															case 531:
																																goto IL_0ee0_2;
																															case 74:
																																goto IL_0eee_2;
																															case 399:
																															case 537:
																																goto IL_0f01_2;
																															case 276:
																																goto IL_0f2a_2;
																															case 538:
																																goto IL_0f43_2;
																															case 291:
																																goto IL_0f51_2;
																															case 444:
																																goto IL_0f5f_2;
																															case 75:
																																goto IL_0f6d_2;
																															case 234:
																																goto IL_0f7b_2;
																															case 184:
																															case 521:
																																goto IL_0f86_2;
																															case 411:
																																goto IL_0f9a_2;
																															case 224:
																																goto IL_0fd9_2;
																															case 235:
																																goto IL_0fec_2;
																															case 182:
																																goto IL_0ffa_2;
																															case 214:
																															case 511:
																																goto IL_1005_2;
																															case 269:
																																goto IL_1019_2;
																															case 423:
																																goto IL_1058_2;
																															case 344:
																																goto IL_106b_2;
																															case 475:
																																goto IL_1079_2;
																															case 69:
																															case 132:
																																goto IL_1087_2;
																															case 225:
																																goto IL_10a0_2;
																															case 253:
																																goto IL_10b3_2;
																															case 434:
																																goto IL_10c6_2;
																															case 50:
																																goto IL_10d4_2;
																															case 126:
																																goto IL_10df_2;
																															case 194:
																																goto IL_10ed_2;
																															case 27:
																															case 279:
																																goto IL_10fb_2;
																															case 59:
																																goto IL_1124_2;
																															case 54:
																															case 281:
																																goto IL_1146_2;
																															case 164:
																																goto IL_115a_2;
																															case 450:
																																goto IL_1199_2;
																															case 174:
																																goto IL_11ac_2;
																															case 6:
																																goto IL_11b7_2;
																															case 308:
																															case 314:
																																goto IL_11c5_2;
																															case 73:
																																goto IL_11d9_2;
																															case 389:
																																goto IL_121d_2;
																															case 53:
																																goto IL_122b_2;
																															case 188:
																															case 505:
																																goto IL_1239_2;
																															case 48:
																																goto IL_1262_2;
																															case 128:
																																goto IL_1284_2;
																															case 336:
																															case 495:
																																goto IL_1298_2;
																															case 303:
																																goto IL_12b5_2;
																															case 413:
																																goto IL_12ed_2;
																															case 328:
																																goto end_IL_0921_2;
																															case 101:
																																goto IL_1317_2;
																															case 205:
																															case 273:
																																goto IL_1322_2;
																															case 33:
																																goto IL_1363_2;
																															case 297:
																																goto IL_1377_2;
																															case 436:
																																goto IL_138a_2;
																															case 272:
																																goto IL_1398_2;
																															case 170:
																															case 186:
																																goto IL_13a3_2;
																															case 26:
																																goto IL_13bc_2;
																															case 500:
																																goto IL_13ca_2;
																															case 247:
																																goto IL_13d8_2;
																															case 519:
																																goto IL_13eb_2;
																															case 310:
																																goto IL_13f9_2;
																															case 307:
																															case 416:
																																goto IL_1407_2;
																															case 124:
																																goto IL_141b_2;
																															case 142:
																																goto IL_1453_2;
																															case 41:
																																goto IL_1466_2;
																															case 189:
																																goto IL_1474_2;
																															case 114:
																															case 459:
																																goto IL_1482_2;
																															case 1:
																																goto IL_149a_2;
																															case 464:
																																goto IL_14a8_2;
																															case 454:
																																goto IL_14b3_2;
																															case 120:
																															case 271:
																																goto IL_14c1_2;
																															case 424:
																																goto IL_14d4_2;
																															case 306:
																																goto IL_14e2_2;
																															case 5:
																															case 379:
																																goto IL_14f0_2;
																															case 223:
																																goto IL_1504_2;
																															case 30:
																																goto IL_153c_2;
																															case 542:
																																goto IL_154f_2;
																															case 250:
																															case 355:
																																goto IL_155a_2;
																															case 283:
																																goto IL_1576_2;
																															case 240:
																																goto IL_158d_2;
																															case 99:
																															case 351:
																																goto IL_159b_2;
																															case 212:
																																goto IL_15ed_2;
																															case 545:
																																goto IL_1600_2;
																															case 102:
																																goto IL_161e_2;
																															case 397:
																																goto IL_162c_2;
																															case 546:
																																goto IL_163f_2;
																															case 471:
																																goto IL_164d_2;
																															case 550:
																																goto IL_1660_2;
																															case 8:
																															case 158:
																																goto IL_166b_2;
																															case 487:
																																goto IL_16a9_2;
																															case 246:
																																goto IL_16bc_2;
																															case 280:
																																goto IL_16ca_2;
																															case 20:
																															case 24:
																																goto IL_16d5_2;
																															case 143:
																																goto IL_16e8_2;
																															case 110:
																																goto IL_16f6_2;
																															case 51:
																																goto IL_1704_2;
																															case 15:
																																goto IL_1712_2;
																															case 2:
																															case 155:
																																goto IL_171d_2;
																															case 368:
																																goto IL_175d_2;
																															case 134:
																																goto IL_1771_2;
																															case 316:
																																goto IL_1784_2;
																															case 479:
																																goto IL_1792_2;
																															case 209:
																															case 496:
																																goto IL_17a0_2;
																															case 18:
																																goto IL_17b9_2;
																															case 332:
																																goto IL_17d0_2;
																															case 43:
																																goto IL_17de_2;
																															case 282:
																																goto IL_17f1_2;
																															case 321:
																																goto IL_17ff_2;
																															case 193:
																															case 456:
																																goto IL_180d_2;
																															case 117:
																																goto IL_1836_2;
																															case 187:
																																goto IL_1844_2;
																															case 115:
																															case 166:
																																goto IL_1857_2;
																															case 36:
																																goto IL_1865_2;
																															case 469:
																																goto IL_1888_2;
																															case 125:
																																goto IL_1892_2;
																															case 67:
																																goto IL_18ae_2;
																															case 232:
																																goto IL_18bc_2;
																															case 378:
																																goto IL_18d3_2;
																															case 203:
																															case 465:
																																goto IL_18e1_2;
																															case 23:
																																goto IL_1921_2;
																															case 256:
																																goto IL_1935_2;
																															case 407:
																																goto IL_1948_2;
																															case 196:
																																goto IL_1956_2;
																															case 14:
																																goto IL_1964_2;
																															case 248:
																															case 292:
																																goto IL_1972_2;
																															case 140:
																																goto IL_19b2_2;
																															case 68:
																																goto IL_19c6_2;
																															case 57:
																															case 290:
																																goto IL_19d9_2;
																															case 486:
																																goto IL_1a19_2;
																															case 197:
																																goto IL_1a36_2;
																															case 137:
																																goto IL_1a49_2;
																															case 147:
																																goto IL_1a57_2;
																															case 31:
																															case 278:
																																goto end_IL_09ed;
																															case 208:
																																goto IL_1b1c_2;
																															case 402:
																																goto IL_1b2a_2;
																															case 217:
																																goto IL_1b3d_2;
																															case 81:
																																goto IL_1b4b_2;
																															case 13:
																															case 437:
																																goto IL_1b56_2;
																															case 261:
																																goto IL_1bb8_2;
																															case 141:
																																goto IL_1bcb_2;
																															case 354:
																																goto IL_1be2_2;
																															case 156:
																															case 237:
																																goto IL_1bf0_2;
																															case 512:
																																goto IL_1c39_2;
																															case 294:
																																goto IL_1c4d_2;
																															case 409:
																																goto IL_1c60_2;
																															case 347:
																																goto IL_1c6e_2;
																															case 25:
																																goto IL_1c81_2;
																															case 95:
																																goto IL_1c8f_2;
																															case 179:
																															case 421:
																																goto IL_1c9a_2;
																															case 89:
																																goto IL_1cc3_2;
																															case 171:
																																goto IL_1cdc_2;
																															case 457:
																																goto IL_1cea_2;
																															case 394:
																															case 447:
																																goto IL_1d01_2;
																															case 82:
																																goto IL_1d1f_2;
																															case 113:
																																goto IL_1d36_2;
																															case 265:
																																goto IL_1d49_2;
																															case 325:
																																goto IL_1d57_2;
																															case 107:
																															case 168:
																																goto IL_1d65_2;
																															case 443:
																																goto IL_1d7d_2;
																															case 406:
																																goto IL_1d9b_2;
																															case 274:
																																goto IL_1dbf_2;
																															case 301:
																																goto IL_1dd7_2;
																															case 286:
																																goto IL_1dea_2;
																															case 329:
																																goto IL_1df8_2;
																															case 239:
																															case 474:
																																goto IL_1e06_2;
																															case 343:
																																goto IL_1e14_2;
																															case 60:
																																goto IL_1e2c_2;
																															case 49:
																																goto IL_1e3a_2;
																															case 551:
																																goto IL_1e56_2;
																															case 133:
																															case 369:
																																goto IL_1e64_2;
																															case 266:
																																goto IL_1ea4_2;
																															case 485:
																																goto IL_1ec1_2;
																															case 553:
																																goto IL_1ed4_2;
																															case 555:
																																goto IL_1ee7_2;
																															case 229:
																															case 556:
																																goto IL_1efa_2;
																															case 222:
																																goto IL_1f33_2;
																															case 559:
																																goto IL_1f4f_2;
																															case 561:
																																goto IL_1f68_2;
																															case 300:
																															case 395:
																																goto IL_1f86_2;
																															case 396:
																																goto IL_1fc4_2;
																															case 37:
																																goto IL_1fd8_2;
																															case 326:
																																goto IL_1feb_2;
																															case 317:
																																goto IL_1ff9_2;
																															case 337:
																															case 342:
																																goto IL_2007_2;
																															case 80:
																																goto IL_201f_2;
																															case 167:
																																goto IL_202d_2;
																															case 100:
																																goto IL_203b_2;
																															case 105:
																																goto IL_204e_2;
																															case 527:
																																goto IL_205c_2;
																															case 287:
																															case 439:
																																goto IL_2067_2;
																															case 161:
																																goto IL_207b_2;
																															case 284:
																																goto IL_20ba_2;
																															case 219:
																																goto IL_20cd_2;
																															case 221:
																																goto IL_20db_2;
																															case 165:
																															case 352:
																																goto IL_20e9_2;
																															case 482:
																																goto IL_2129_2;
																															case 94:
																																goto IL_213d_2;
																															case 40:
																																goto IL_2150_2;
																															case 453:
																																goto IL_215e_2;
																															case 249:
																															case 557:
																																goto IL_216c_2;
																															case 207:
																																goto IL_2186_2;
																															case 518:
																																goto IL_2194_2;
																															case 524:
																																goto IL_21a2_2;
																															case 375:
																															case 541:
																																goto IL_21be_2;
																															case 76:
																																goto IL_21cc_2;
																															case 238:
																																goto IL_21f0_2;
																															case 563:
																																goto IL_21fe_2;
																															case 435:
																																goto IL_2211_2;
																															case 361:
																																goto IL_221f_2;
																															case 356:
																																goto IL_222d_2;
																															case 154:
																																goto IL_223b_2;
																															case 195:
																																goto IL_2252_2;
																															case 35:
																															case 392:
																																goto IL_225d_2;
																															case 10:
																																goto IL_2271_2;
																															case 61:
																																goto IL_22b0_2;
																															case 452:
																																goto IL_22cc_2;
																															case 462:
																																goto IL_22da_2;
																															case 129:
																															case 350:
																																goto IL_22e8_2;
																															case 366:
																																goto IL_2356_2;
																															case 562:
																																goto IL_2369_2;
																															case 231:
																																goto IL_2377_2;
																															case 4:
																															case 98:
																																goto IL_2385_2;
																															case 311:
																																goto IL_239a_2;
																															case 65:
																															case 534:
																																goto IL_23ad_2;
																															case 458:
																																goto IL_23c1_2;
																															case 510:
																																goto IL_2400_2;
																															case 405:
																																goto IL_2413_2;
																															case 348:
																																goto IL_2421_2;
																															case 415:
																																goto IL_242f_2;
																															case 502:
																																goto IL_243d_2;
																															case 185:
																															case 323:
																																goto IL_244b_2;
																															case 333:
																																goto IL_2489_2;
																															case 180:
																																goto IL_249d_2;
																															case 77:
																															case 377:
																																goto IL_24b0_2;
																															case 460:
																																goto IL_24be_2;
																															case 473:
																																goto IL_24e2_2;
																															case 92:
																																goto IL_24f9_2;
																															case 425:
																																goto IL_250c_2;
																															case 242:
																																goto IL_2517_2;
																															case 335:
																															case 477:
																																goto IL_2525_2;
																															case 400:
																																goto IL_2553_2;
																															case 381:
																																goto IL_2566_2;
																															case 79:
																																goto IL_2574_2;
																															case 526:
																																goto IL_2587_2;
																															case 19:
																															case 199:
																																goto IL_2592_2;
																															case 367:
																																goto IL_25d0_2;
																															case 536:
																																goto IL_25e4_2;
																															case 373:
																																goto IL_25f7_2;
																															case 260:
																																goto IL_260e_2;
																															case 34:
																															case 45:
																																goto IL_2619_2;
																															case 414:
																																goto IL_2657_2;
																															case 97:
																																goto IL_266b_2;
																															case 244:
																																goto IL_267e_2;
																															case 383:
																																goto IL_268c_2;
																															case 362:
																																goto IL_269a_2;
																															case 339:
																																goto IL_26a8_2;
																															case 0:
																															case 525:
																																goto IL_26b6_2;
																															case 472:
																																goto IL_2714_2;
																															case 190:
																															case 463:
																																goto IL_2727_2;
																															case 122:
																																goto IL_273b_2;
																															case 504:
																																goto IL_277a_2;
																															case 419:
																																goto IL_278d_2;
																															case 62:
																																goto IL_279b_2;
																															case 268:
																															case 492:
																																goto IL_27a9_2;
																															case 236:
																																goto IL_27d5_2;
																															case 506:
																																goto IL_27e3_2;
																															case 12:
																																goto IL_27f1_2;
																															case 173:
																																goto IL_2804_2;
																															case 385:
																																goto IL_2812_2;
																															case 288:
																															case 543:
																																goto IL_281d_2;
																															case 532:
																																goto IL_2846_2;
																															case 427:
																																goto IL_285d_2;
																															case 111:
																																goto IL_2870_2;
																															case 548:
																																goto IL_287e_2;
																															case 64:
																															case 262:
																																goto IL_288c_2;
																															case 202:
																																goto IL_28a0_2;
																															case 319:
																																goto IL_28df_2;
																															case 449:
																																goto IL_28f2_2;
																															case 520:
																																goto IL_28fd_2;
																															case 90:
																															case 213:
																																goto IL_290b_2;
																															case 388:
																																goto IL_294b_2;
																															case 441:
																																goto IL_2968_2;
																															case 153:
																																goto IL_2978_2;
																															case 503:
																																goto IL_2983_2;
																															case 488:
																															case 539:
																																goto IL_298e_2;
																															case 489:
																																goto IL_299c_2;
																															case 228:
																																goto IL_29c0_2;
																															case 106:
																																goto IL_29ce_2;
																															case 7:
																															case 16:
																															case 17:
																															case 21:
																															case 22:
																															case 29:
																															case 38:
																															case 39:
																															case 47:
																															case 63:
																															case 66:
																															case 72:
																															case 83:
																															case 87:
																															case 91:
																															case 108:
																															case 118:
																															case 119:
																															case 130:
																															case 136:
																															case 138:
																															case 144:
																															case 150:
																															case 159:
																															case 160:
																															case 162:
																															case 175:
																															case 204:
																															case 210:
																															case 220:
																															case 252:
																															case 264:
																															case 275:
																															case 296:
																															case 299:
																															case 309:
																															case 313:
																															case 327:
																															case 331:
																															case 341:
																															case 358:
																															case 363:
																															case 372:
																															case 382:
																															case 386:
																															case 387:
																															case 398:
																															case 403:
																															case 418:
																															case 422:
																															case 431:
																															case 432:
																															case 438:
																															case 440:
																															case 466:
																															case 467:
																															case 476:
																															case 478:
																															case 483:
																															case 490:
																															case 499:
																															case 501:
																															case 514:
																															case 516:
																															case 522:
																															case 530:
																															case 535:
																															case 544:
																															case 549:
																															case 552:
																															case 554:
																															case 558:
																																goto end_IL_09ba_2;
																															case 9:
																															case 28:
																															case 44:
																															case 52:
																															case 55:
																															case 70:
																															case 78:
																															case 84:
																															case 86:
																															case 88:
																															case 109:
																															case 112:
																															case 123:
																															case 127:
																															case 135:
																															case 149:
																															case 151:
																															case 157:
																															case 176:
																															case 183:
																															case 191:
																															case 201:
																															case 211:
																															case 233:
																															case 251:
																															case 257:
																															case 258:
																															case 259:
																															case 270:
																															case 285:
																															case 293:
																															case 298:
																															case 302:
																															case 304:
																															case 320:
																															case 322:
																															case 324:
																															case 330:
																															case 338:
																															case 340:
																															case 346:
																															case 353:
																															case 360:
																															case 364:
																															case 365:
																															case 370:
																															case 380:
																															case 384:
																															case 391:
																															case 393:
																															case 408:
																															case 410:
																															case 412:
																															case 426:
																															case 428:
																															case 433:
																															case 446:
																															case 448:
																															case 461:
																															case 468:
																															case 481:
																															case 484:
																															case 493:
																															case 497:
																															case 509:
																															case 513:
																															case 515:
																															case 523:
																															case 533:
																															case 540:
																															case 547:
																															case 560:
																																goto IL_29f1_2;
																															case 498:
																																ptr2 = ptr;
																																goto IL_29f1_2;
																															case 172:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsFixedSizeMoveFile.StackFrameHelpertdesc);
																																goto case 498;
																															case 146:
																																array7[0] = this;
																																goto case 172;
																															case 71:
																																array7 = new object[22];
																																goto case 146;
																															case 404:
																																array6 = new long[8];
																																goto case 71;
																															case 116:
																																array5 = new int[7];
																																num = 404;
																																goto case 404;
																															case 390:
																																array4 = new int[8];
																																goto case 116;
																															case 376:
																																array3 = new object[8];
																																goto case 390;
																															case 359:
																																array2 = new byte[8];
																																goto case 376;
																															case 206:
																																num4 = num2 * 8;
																																goto case 359;
																															case 491:
																																num3 = num2 * 4;
																																goto case 206;
																															case 254:
																																num2 = 1;
																																goto case 491;
																															case 255:
																																goto end_IL_1a82;
																															case 263:
																															case 507:
																																return;
																															}
																															continue;
																														}
																														if (37 <= b)
																														{
																															goto IL_1f86_2;
																														}
																														goto IL_1feb_2;
																														IL_201f_2:
																														array2[num6] = 5;
																														goto IL_202d_2;
																														IL_203b_2:
																														ptr2 += 8;
																														goto IL_29f1_2;
																														IL_202d_2:
																														num6++;
																														goto IL_203b_2;
																														IL_1f86_2:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class16, bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class16)array3[num6 - 1]) ? 1 : 0);
																														goto IL_1fc4_2;
																														IL_1fc4_2:
																														array2[num6 - 1] = 0;
																														goto IL_1fd8_2;
																														IL_1fd8_2:
																														ptr2 += 8;
																														goto IL_29f1_2;
																														IL_1feb_2:
																														if (36 < b)
																														{
																															goto end_IL_09ba_2;
																														}
																														goto IL_1ff9_2;
																														IL_1ff9_2:
																														if (36 > b)
																														{
																															goto end_IL_09ba_2;
																														}
																														goto IL_2007_2;
																														IL_2007_2:
																														array3[num6] = array7[*(int*)(ptr2 + num3)];
																														goto IL_201f_2;
																														continue;
																														end_IL_0921_2:
																														break;
																													}
																													break;
																												}
																												goto IL_09f8_2;
																												IL_0cea_2:
																												array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																												goto IL_1f4f_2;
																												IL_1f4f_2:
																												array2[num6 - 1] = 5;
																												goto IL_29f1_2;
																												IL_09f8_2:
																												if (38 < b)
																												{
																													goto end_IL_09ba_2;
																												}
																												goto IL_0cdc_2;
																												IL_0cdc_2:
																												if (38 > b)
																												{
																													goto end_IL_09ba_2;
																												}
																												goto IL_0cea_2;
																											}
																											break;
																										}
																										goto IL_0a67_2;
																										IL_0b17_2:
																										ptr2 += 8;
																										goto IL_29f1_2;
																										IL_0a67_2:
																										array2[num6 - 1] = 3;
																										num = 349;
																										goto IL_0ad8_2;
																										IL_0ad8_2:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_0b17_2;
																									}
																									break;
																								}
																								goto IL_204e_2;
																								IL_21a2_2:
																								ptr2 += 8;
																								num = 151;
																								goto IL_29f1_2;
																								IL_204e_2:
																								if (41 >= b)
																								{
																									goto IL_205c_2;
																								}
																								goto IL_2150_2;
																								IL_205c_2:
																								if (41 <= b)
																								{
																									goto IL_2067_2;
																								}
																								goto IL_20cd_2;
																								IL_2067_2:
																								array2[num6 - 1] = 0;
																								goto IL_207b_2;
																								IL_207b_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_20ba_2;
																								IL_20ba_2:
																								ptr2 += 8;
																								goto IL_29f1_2;
																								IL_20cd_2:
																								if (40 < b)
																								{
																									goto end_IL_09ba_2;
																								}
																								goto IL_20db_2;
																								IL_20db_2:
																								if (40 > b)
																								{
																									goto end_IL_09ba_2;
																								}
																								goto IL_20e9_2;
																								IL_20e9_2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_2129_2;
																								IL_2129_2:
																								array2[num6 - 2] = 3;
																								goto IL_213d_2;
																								IL_213d_2:
																								num6--;
																								goto IL_29f1_2;
																								IL_2150_2:
																								if (42 < b)
																								{
																									goto end_IL_09ba_2;
																								}
																								goto IL_215e_2;
																								IL_215e_2:
																								if (42 > b)
																								{
																									goto end_IL_09ba_2;
																								}
																								goto IL_216c_2;
																								IL_216c_2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																								goto IL_2186_2;
																								IL_2186_2:
																								array2[num6] = 3;
																								goto IL_2194_2;
																								IL_2194_2:
																								num6++;
																								goto IL_21a2_2;
																							}
																							break;
																						}
																						goto IL_0f01_2;
																						IL_0f2a_2:
																						array2[num6 - 1] = 5;
																						goto IL_29f1_2;
																						IL_0f01_2:
																						array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_0f2a_2;
																					}
																					break;
																				}
																				goto IL_0a0b_2;
																				IL_0d76_2:
																				ptr2 += 8;
																				goto IL_29f1_2;
																				IL_0d89_2:
																				if (48 < b)
																				{
																					goto end_IL_09ba_2;
																				}
																				goto IL_0d97_2;
																				IL_0a0b_2:
																				if (47 >= b)
																				{
																					goto IL_0a19_2;
																				}
																				goto IL_0bf0_2;
																				IL_0a19_2:
																				if (47 > b)
																				{
																					goto IL_0a27_2;
																				}
																				goto IL_0b2a_2;
																				IL_0a27_2:
																				if (45 < b)
																				{
																					goto IL_0a35_2;
																				}
																				goto IL_0dc3_2;
																				IL_0a35_2:
																				if (46 < b)
																				{
																					goto end_IL_09ba_2;
																				}
																				goto IL_0a43_2;
																				IL_0a43_2:
																				if (46 > b)
																				{
																					goto end_IL_09ba_2;
																				}
																				goto IL_0a51_2;
																				IL_0a51_2:
																				array2[num6 - 1] = 0;
																				goto IL_0a86_2;
																				IL_0a86_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_0ac5_2;
																				IL_0ac5_2:
																				ptr2 += 8;
																				goto IL_29f1_2;
																				IL_0dc3_2:
																				if (45 <= b)
																				{
																					goto IL_0dce_2;
																				}
																				goto IL_0e35_2;
																				IL_0dce_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0e0e_2;
																				IL_0e0e_2:
																				array2[num6 - 2] = 3;
																				goto IL_0e22_2;
																				IL_0e22_2:
																				num6--;
																				goto IL_29f1_2;
																				IL_0e35_2:
																				if (44 < b)
																				{
																					goto end_IL_09ba_2;
																				}
																				goto IL_0e43_2;
																				IL_0e43_2:
																				if (44 > b)
																				{
																					goto end_IL_09ba_2;
																				}
																				goto IL_0e51_2;
																				IL_0e51_2:
																				array2[num6 - 4] = 0;
																				goto IL_0e65_2;
																				IL_0e65_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
																				goto IL_0ee0_2;
																				IL_0ee0_2:
																				num6 -= 3;
																				goto IL_0eee_2;
																				IL_0eee_2:
																				ptr2 += 8;
																				goto IL_29f1_2;
																				IL_0b2a_2:
																				array2[num6 - 5] = 4;
																				goto IL_0b3e_2;
																				IL_0b3e_2:
																				array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																				goto IL_0bcf_2;
																				IL_0bcf_2:
																				num6 -= 4;
																				goto IL_0bdd_2;
																				IL_0bdd_2:
																				ptr2 += 8;
																				goto IL_29f1_2;
																				IL_0bf0_2:
																				if (49 < b)
																				{
																					goto IL_0bfe_2;
																				}
																				goto IL_0d18_2;
																				IL_0bfe_2:
																				if (50 < b)
																				{
																					goto IL_0c09_2;
																				}
																				goto IL_0c7b_2;
																				IL_0c09_2:
																				if (51 < b)
																				{
																					goto end_IL_09ba_2;
																				}
																				num = 46;
																				goto IL_0c20_2;
																				IL_0d97_2:
																				if (48 > b)
																				{
																					goto end_IL_09ba_2;
																				}
																				goto IL_0da5_2;
																				IL_0c20_2:
																				if (51 > b)
																				{
																					goto end_IL_09ba_2;
																				}
																				num = 442;
																				goto IL_0c37_2;
																				IL_0da5_2:
																				global::_003CModule_003E.gunResult_0 = (Class8.GunResult)array3[num6 - 1];
																				goto IL_1ed4_2;
																				IL_0c37_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0c62_2;
																				IL_0c62_2:
																				array2[num6 - 1] = 0;
																				goto IL_29f1_2;
																				IL_0c7b_2:
																				if (50 > b)
																				{
																					goto end_IL_09ba_2;
																				}
																				num = 139;
																				goto IL_0c92_2;
																				IL_1ed4_2:
																				num6--;
																				goto IL_29f1_2;
																				IL_0c92_2:
																				((Class16)array3[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																				num = 470;
																				goto IL_0cc9_2;
																				IL_0cc9_2:
																				num6 -= 2;
																				goto IL_29f1_2;
																				IL_0d18_2:
																				if (49 <= b)
																				{
																					goto IL_0d23_2;
																				}
																				goto IL_0d89_2;
																				IL_0d23_2:
																				array2[num6 - 1] = 3;
																				goto IL_0d37_2;
																				IL_0d37_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_0d76_2;
																			}
																			break;
																		}
																		goto IL_21be_2;
																		IL_21fe_2:
																		ptr2 += 8;
																		goto IL_29f1_2;
																		IL_21be_2:
																		array2[num6] = 0;
																		goto IL_21cc_2;
																		IL_21cc_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])() ? 1 : 0);
																		goto IL_21f0_2;
																		IL_21f0_2:
																		num6++;
																		goto IL_21fe_2;
																	}
																	break;
																}
																goto IL_2211_2;
																IL_299c_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																goto IL_29c0_2;
																IL_2211_2:
																if (61 < b)
																{
																	goto IL_221f_2;
																}
																goto IL_2587_2;
																IL_221f_2:
																if (65 >= b)
																{
																	goto IL_222d_2;
																}
																goto IL_2413_2;
																IL_222d_2:
																if (65 > b)
																{
																	goto IL_223b_2;
																}
																goto IL_23ad_2;
																IL_223b_2:
																if (63 >= b)
																{
																	num = 195;
																	goto IL_2252_2;
																}
																goto IL_2369_2;
																IL_29c0_2:
																num6++;
																goto IL_29ce_2;
																IL_2252_2:
																if (63 <= b)
																{
																	goto IL_225d_2;
																}
																goto IL_22cc_2;
																IL_225d_2:
																array2[num6 - 1] = 3;
																goto IL_2271_2;
																IL_2271_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_22b0_2;
																IL_22b0_2:
																ptr2 += 8;
																num = 523;
																goto IL_29f1_2;
																IL_22cc_2:
																if (62 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_22da_2;
																IL_22da_2:
																if (62 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_22e8_2;
																IL_22e8_2:
																ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_2356_2;
																IL_2356_2:
																num6 -= 2;
																goto IL_29f1_2;
																IL_2369_2:
																if (64 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_2377_2;
																IL_2377_2:
																if (64 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_2385_2;
																IL_2385_2:
																((delegate*<void>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																goto IL_239a_2;
																IL_239a_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_23ad_2:
																array2[num6 - 1] = 3;
																goto IL_23c1_2;
																IL_23c1_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_2400_2;
																IL_2400_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_2413_2:
																if (67 >= b)
																{
																	goto IL_2421_2;
																}
																goto IL_250c_2;
																IL_2421_2:
																if (67 > b)
																{
																	goto IL_242f_2;
																}
																goto IL_24b0_2;
																IL_242f_2:
																if (66 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_243d_2;
																IL_243d_2:
																if (66 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_244b_2;
																IL_244b_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																goto IL_2489_2;
																IL_2489_2:
																array2[num6 - 1] = 0;
																goto IL_249d_2;
																IL_249d_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_24b0_2:
																array2[num6] = 3;
																goto IL_24be_2;
																IL_24be_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																goto IL_24e2_2;
																IL_24e2_2:
																num6++;
																num = 92;
																goto IL_24f9_2;
																IL_24f9_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_250c_2:
																if (68 >= b)
																{
																	goto IL_2517_2;
																}
																goto IL_2566_2;
																IL_2517_2:
																if (68 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_2525_2;
																IL_2525_2:
																((Class16)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_2553_2;
																IL_2553_2:
																num6 -= 2;
																goto IL_29f1_2;
																IL_2566_2:
																if (69 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_2574_2;
																IL_2574_2:
																if (69 > b)
																{
																}
																goto end_IL_09ba_2;
																IL_2587_2:
																if (61 <= b)
																{
																	goto IL_2592_2;
																}
																goto IL_25f7_2;
																IL_2592_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class16, float>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class16)array3[num6 - 1]);
																goto IL_25d0_2;
																IL_25d0_2:
																array2[num6 - 1] = 3;
																goto IL_25e4_2;
																IL_25e4_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_25f7_2:
																if (56 >= b)
																{
																	num = 260;
																	goto IL_260e_2;
																}
																goto IL_2804_2;
																IL_29ce_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_260e_2:
																if (56 <= b)
																{
																	goto IL_2619_2;
																}
																goto IL_267e_2;
																IL_2619_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																goto IL_2657_2;
																IL_2657_2:
																array2[num6 - 1] = 0;
																goto IL_266b_2;
																IL_266b_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_267e_2:
																if (54 >= b)
																{
																	goto IL_268c_2;
																}
																goto IL_278d_2;
																IL_268c_2:
																if (54 > b)
																{
																	goto IL_269a_2;
																}
																goto IL_2727_2;
																IL_269a_2:
																if (53 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_26a8_2;
																IL_26a8_2:
																if (53 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_26b6_2;
																IL_26b6_2:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_2714_2;
																IL_2714_2:
																num6--;
																goto IL_29f1_2;
																IL_2727_2:
																array2[num6 - 1] = 3;
																goto IL_273b_2;
																IL_273b_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_277a_2;
																IL_277a_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_278d_2:
																if (55 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_279b_2;
																IL_279b_2:
																if (55 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_27a9_2;
																IL_27a9_2:
																array3[num6] = ((delegate*<Class8.GunResult>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
																num = 236;
																goto IL_27d5_2;
																IL_27d5_2:
																array2[num6] = 4;
																goto IL_27e3_2;
																IL_27e3_2:
																num6++;
																goto IL_27f1_2;
																IL_27f1_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_2804_2:
																if (58 >= b)
																{
																	goto IL_2812_2;
																}
																goto IL_28f2_2;
																IL_2812_2:
																if (58 <= b)
																{
																	goto IL_281d_2;
																}
																goto IL_2870_2;
																IL_281d_2:
																((delegate*<string, void>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_2846_2;
																IL_2846_2:
																num6--;
																num = 427;
																goto IL_285d_2;
																IL_285d_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_2870_2:
																if (57 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_287e_2;
																IL_287e_2:
																if (57 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_288c_2;
																IL_288c_2:
																array2[num6 - 1] = 3;
																goto IL_28a0_2;
																IL_28a0_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_28df_2;
																IL_28df_2:
																ptr2 += 8;
																goto IL_29f1_2;
																IL_28f2_2:
																if (59 >= b)
																{
																	goto IL_28fd_2;
																}
																goto IL_2978_2;
																IL_28fd_2:
																if (59 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_290b_2;
																IL_290b_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_294b_2;
																IL_294b_2:
																array2[num6 - 2] = 3;
																num = 441;
																goto IL_2968_2;
																IL_2968_2:
																num6--;
																goto IL_29f1_2;
																IL_2978_2:
																if (60 < b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_2983_2;
																IL_2983_2:
																if (60 > b)
																{
																	goto end_IL_09ba_2;
																}
																goto IL_298e_2;
																IL_298e_2:
																array2[num6] = 3;
																goto IL_299c_2;
															}
															goto IL_1309_2;
														}
														goto IL_0f43_2;
														IL_1dea_2:
														if (16 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1df8_2;
														IL_0f43_2:
														if (35 > b)
														{
															goto IL_0f51_2;
														}
														goto IL_1efa_2;
														IL_0f51_2:
														if (17 < b)
														{
															goto IL_0f5f_2;
														}
														goto IL_1660_2;
														IL_0f5f_2:
														if (26 < b)
														{
															goto IL_0f6d_2;
														}
														num = 128;
														goto IL_1284_2;
														IL_0f6d_2:
														if (30 >= b)
														{
															goto IL_0f7b_2;
														}
														goto IL_10c6_2;
														IL_0f7b_2:
														if (30 <= b)
														{
															goto IL_0f86_2;
														}
														goto IL_0fec_2;
														IL_0f86_2:
														array2[num6 - 1] = 0;
														goto IL_0f9a_2;
														IL_0f9a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_0fd9_2;
														IL_0fd9_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_0fec_2:
														if (28 >= b)
														{
															goto IL_0ffa_2;
														}
														goto IL_10b3_2;
														IL_0ffa_2:
														if (28 <= b)
														{
															goto IL_1005_2;
														}
														goto IL_106b_2;
														IL_1005_2:
														array2[num6 - 1] = 3;
														goto IL_1019_2;
														IL_1019_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1058_2;
														IL_1058_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_106b_2:
														if (27 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1079_2;
														IL_1079_2:
														if (27 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1087_2;
														IL_1087_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_10a0_2;
														IL_10a0_2:
														array2[num6] = 3;
														goto IL_163f_2;
														IL_163f_2:
														num6++;
														goto IL_164d_2;
														IL_164d_2:
														ptr2 += 16;
														goto IL_29f1_2;
														IL_10b3_2:
														if (29 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1e56_2;
														IL_1e56_2:
														if (29 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1e64_2;
														IL_1e64_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1ea4_2;
														IL_1ea4_2:
														array2[num6 - 2] = 3;
														num = 485;
														goto IL_1ec1_2;
														IL_1ec1_2:
														num6--;
														goto IL_29f1_2;
														IL_10c6_2:
														if (32 >= b)
														{
															goto IL_10d4_2;
														}
														goto IL_11ac_2;
														IL_10d4_2:
														if (32 > b)
														{
															goto IL_10df_2;
														}
														num = 54;
														goto IL_1146_2;
														IL_10df_2:
														if (31 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_10ed_2;
														IL_10ed_2:
														if (31 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_10fb_2;
														IL_10fb_2:
														array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1124_2;
														IL_1124_2:
														array2[num6 - 1] = 5;
														goto IL_29f1_2;
														IL_1e06_2:
														array2[num6] = 5;
														goto IL_1e14_2;
														IL_1146_2:
														array2[num6 - 1] = 3;
														goto IL_115a_2;
														IL_115a_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1199_2;
														IL_1199_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_11ac_2:
														if (33 >= b)
														{
															goto IL_11b7_2;
														}
														goto IL_121d_2;
														IL_11b7_2:
														if (33 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_11c5_2;
														IL_11c5_2:
														array2[num6 - 1] = 0;
														goto IL_11d9_2;
														IL_11d9_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1ee7_2;
														IL_1ee7_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_121d_2:
														if (34 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_122b_2;
														IL_122b_2:
														if (34 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1239_2;
														IL_1239_2:
														array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1262_2;
														IL_1262_2:
														array2[num6 - 1] = 5;
														goto IL_29f1_2;
														IL_1df8_2:
														if (16 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1e06_2;
														IL_1284_2:
														if (26 <= b)
														{
															num = 336;
															goto IL_1298_2;
														}
														goto IL_1309_2;
														IL_1e14_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_1e2c_2;
														IL_1298_2:
														array2[num6 - 1] = 5;
														num = 303;
														goto IL_12b5_2;
														IL_12b5_2:
														array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
														goto IL_12ed_2;
														IL_12ed_2:
														ptr2 += 8;
														num = 86;
														goto IL_29f1_2;
														IL_1309_2:
														if (21 >= b)
														{
															goto IL_1317_2;
														}
														goto IL_149a_2;
														IL_1317_2:
														if (21 <= b)
														{
															goto IL_1322_2;
														}
														goto IL_138a_2;
														IL_1322_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1363_2;
														IL_1363_2:
														array2[num6 - 2] = 0;
														goto IL_1377_2;
														IL_1377_2:
														num6--;
														goto IL_29f1_2;
														IL_138a_2:
														if (19 >= b)
														{
															goto IL_1398_2;
														}
														goto IL_1466_2;
														IL_1398_2:
														if (19 <= b)
														{
															goto IL_13a3_2;
														}
														goto IL_13eb_2;
														IL_13a3_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_13bc_2;
														IL_13bc_2:
														array2[num6] = 1;
														goto IL_13ca_2;
														IL_13ca_2:
														num6++;
														goto IL_13d8_2;
														IL_13d8_2:
														ptr2 += 16;
														goto IL_29f1_2;
														IL_13eb_2:
														if (18 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_13f9_2;
														IL_13f9_2:
														if (18 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1407_2;
														IL_1407_2:
														array2[num6 - 1] = 5;
														goto IL_141b_2;
														IL_141b_2:
														array3[num6 - 1] = ((delegate*<string[], string>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_1453_2;
														IL_1453_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_1466_2:
														if (20 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1474_2;
														IL_1474_2:
														if (20 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1482_2;
														IL_1482_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_29f1_2;
														IL_149a_2:
														if (23 < b)
														{
															goto IL_14a8_2;
														}
														goto IL_154f_2;
														IL_14a8_2:
														if (24 >= b)
														{
															goto IL_14b3_2;
														}
														goto IL_14d4_2;
														IL_14b3_2:
														if (24 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_14c1_2;
														IL_14c1_2:
														array2[num6] = 5;
														goto IL_1600_2;
														IL_1600_2:
														array3[num6] = ((delegate*<GorillaTagger>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])();
														goto IL_161e_2;
														IL_161e_2:
														num6++;
														goto IL_162c_2;
														IL_162c_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_14d4_2:
														if (25 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_14e2_2;
														IL_14e2_2:
														if (25 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_14f0_2;
														IL_14f0_2:
														array2[num6 - 1] = 5;
														goto IL_1504_2;
														IL_1504_2:
														array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)GetLastWriteTimeInTypeFixedCountFlag[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
														goto IL_153c_2;
														IL_153c_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_154f_2:
														if (23 <= b)
														{
															goto IL_155a_2;
														}
														goto IL_1576_2;
														IL_155a_2:
														num7 = ptr2;
														num8 = -200;
														num5 = 1;
														ptr2 = num7 + num8;
														goto IL_29f1_2;
														IL_1576_2:
														if (22 < b)
														{
															goto end_IL_09ba_2;
														}
														num = 240;
														goto IL_158d_2;
														IL_1e2c_2:
														num6++;
														goto IL_1e3a_2;
														IL_158d_2:
														if (22 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_159b_2;
														IL_159b_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_15ed_2;
														IL_15ed_2:
														num6--;
														goto IL_29f1_2;
														IL_1660_2:
														if (17 <= b)
														{
															goto IL_166b_2;
														}
														goto IL_16bc_2;
														IL_166b_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_16a9_2;
														IL_16a9_2:
														num6 -= 3;
														goto IL_29f1_2;
														IL_16bc_2:
														if (8 >= b)
														{
															goto IL_16ca_2;
														}
														goto IL_1a49_2;
														IL_16ca_2:
														if (8 <= b)
														{
															goto IL_16d5_2;
														}
														goto IL_16e8_2;
														IL_16d5_2:
														num6--;
														goto IL_29f1_2;
														IL_16e8_2:
														if (4 >= b)
														{
															goto IL_16f6_2;
														}
														goto IL_18ae_2;
														IL_16f6_2:
														if (4 > b)
														{
															goto IL_1704_2;
														}
														goto IL_1857_2;
														IL_1704_2:
														if (2 >= b)
														{
															goto IL_1712_2;
														}
														goto IL_17f1_2;
														IL_1712_2:
														if (2 <= b)
														{
															goto IL_171d_2;
														}
														goto IL_1784_2;
														IL_171d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_175d_2;
														IL_175d_2:
														array2[num6 - 2] = 0;
														goto IL_1771_2;
														IL_1771_2:
														num6--;
														goto IL_29f1_2;
														IL_1784_2:
														if (1 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1792_2;
														IL_1792_2:
														if (1 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_17a0_2;
														IL_17a0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_17b9_2;
														IL_17b9_2:
														array2[num6] = 0;
														num = 332;
														goto IL_17d0_2;
														IL_17d0_2:
														num6++;
														goto IL_17de_2;
														IL_17de_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_17f1_2:
														if (3 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_17ff_2;
														IL_17ff_2:
														if (3 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_180d_2;
														IL_180d_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1836_2;
														IL_1836_2:
														ptr2 += 8;
														goto IL_1844_2;
														IL_1844_2:
														num6--;
														goto IL_29f1_2;
														IL_1857_2:
														array2[num6] = 0;
														goto IL_1865_2;
														IL_1865_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_1888_2;
														IL_1888_2:
														array3[num6] = null;
														goto IL_1892_2;
														IL_1892_2:
														num6++;
														num = 561;
														goto IL_1f68_2;
														IL_1f68_2:
														ptr2 += 8;
														goto IL_29f1_2;
														IL_18ae_2:
														if (6 < b)
														{
															goto IL_18bc_2;
														}
														goto IL_1948_2;
														IL_18bc_2:
														if (7 < b)
														{
															goto end_IL_09ba_2;
														}
														num = 378;
														goto IL_18d3_2;
														IL_1e3a_2:
														ptr2 += 8;
														num = 270;
														goto IL_29f1_2;
														IL_18d3_2:
														if (7 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_18e1_2;
														IL_18e1_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1921_2;
														IL_1921_2:
														array2[num6 - 2] = 0;
														goto IL_1935_2;
														IL_1935_2:
														num6--;
														goto IL_29f1_2;
														IL_1948_2:
														if (6 > b)
														{
															goto IL_1956_2;
														}
														goto IL_19d9_2;
														IL_1956_2:
														if (5 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1964_2;
														IL_1964_2:
														if (5 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1972_2;
														IL_1972_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_19b2_2;
														IL_19b2_2:
														array2[num6 - 2] = 0;
														goto IL_19c6_2;
														IL_19c6_2:
														num6--;
														goto IL_29f1_2;
														IL_19d9_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1a19_2;
														IL_1a19_2:
														array2[num6 - 2] = 0;
														num = 197;
														goto IL_1a36_2;
														IL_1a36_2:
														num6--;
														goto IL_29f1_2;
														IL_1a49_2:
														if (12 >= b)
														{
															goto IL_1a57_2;
														}
														goto IL_1c81_2;
														IL_1a57_2:
														if (12 <= b)
														{
															goto end_IL_09ed;
														}
														goto IL_1b3d_2;
														IL_1b3d_2:
														if (10 >= b)
														{
															goto IL_1b4b_2;
														}
														goto IL_1c60_2;
														IL_1b4b_2:
														if (10 <= b)
														{
															goto IL_1b56_2;
														}
														goto IL_1bcb_2;
														IL_1b56_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1bb8_2;
														IL_1bb8_2:
														num6 -= 2;
														goto IL_29f1_2;
														IL_1bcb_2:
														if (9 < b)
														{
															goto end_IL_09ba_2;
														}
														num = 354;
														goto IL_1be2_2;
														IL_1efa_2:
														((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
														goto IL_1f33_2;
														IL_1be2_2:
														if (9 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1bf0_2;
														IL_1bf0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 512;
														goto IL_1c39_2;
														IL_1c39_2:
														array2[num6 - 2] = 0;
														goto IL_1c4d_2;
														IL_1c4d_2:
														num6--;
														goto IL_29f1_2;
														IL_1c60_2:
														if (11 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1c6e_2;
														IL_1c6e_2:
														if (11 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_29f1_2;
														IL_1c81_2:
														if (14 >= b)
														{
															goto IL_1c8f_2;
														}
														goto IL_1d49_2;
														IL_1c8f_2:
														if (14 <= b)
														{
															goto IL_1c9a_2;
														}
														goto IL_1cdc_2;
														IL_1c9a_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1cc3_2;
														IL_1cc3_2:
														array2[num6 - 1] = 5;
														goto IL_29f1_2;
														IL_1cdc_2:
														if (13 < b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1cea_2;
														IL_1cea_2:
														if (13 > b)
														{
															goto end_IL_09ba_2;
														}
														num = 447;
														goto IL_1d01_2;
														IL_1f33_2:
														num6 -= 3;
														num = 493;
														goto IL_29f1_2;
														IL_1d01_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_1d1f_2;
														IL_1d1f_2:
														ptr2 += 8;
														num = 113;
														goto IL_1d36_2;
														IL_1d36_2:
														num6--;
														goto IL_29f1_2;
														IL_1d49_2:
														if (15 >= b)
														{
															goto IL_1d57_2;
														}
														goto IL_1dea_2;
														IL_1d57_2:
														if (15 > b)
														{
															goto end_IL_09ba_2;
														}
														goto IL_1d65_2;
														IL_1d65_2:
														array2[num6] = array2[num6 - 1];
														goto IL_1d7d_2;
														IL_1d7d_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_1d9b_2;
														IL_1d9b_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1dbf_2;
														IL_1dbf_2:
														array3[num6] = array3[num6 - 1];
														goto IL_1dd7_2;
														IL_1dd7_2:
														num6++;
														goto IL_29f1_2;
														continue;
														end_IL_09aa_2:
														break;
													}
													continue;
													end_IL_09ba_2:
													break;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_29f1_2;
											continue;
											end_IL_09cd_2:
											break;
										}
										continue;
										end_IL_09dd:
										break;
									}
									continue;
									end_IL_09ed:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_1a74_2;
					}
					continue;
					end_IL_1a82:
					break;
				}
				break;
			}
		}
	}

	private void OnDisable()
	{
		SoapTypeAttributeInvocationList(this);
	}

	private unsafe void method_0()
	{
		int num = 175;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										num = 170;
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SecurityZoneIsValidTag.GetTextElementEnumeratorTemplate);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 118;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 88;
																	while (true)
																	{
																		IL_0390:
																		if (b >= 1)
																		{
																			while (b <= 22)
																			{
																				while (true)
																				{
																					if (11 < b)
																					{
																						while (true)
																						{
																							IL_0363:
																							if (17 < b)
																							{
																								while (true)
																								{
																									IL_0353:
																									if (20 >= b)
																									{
																										while (true)
																										{
																											IL_0340:
																											if (20 <= b)
																											{
																												num = 196;
																												while (true)
																												{
																													if (num != 196)
																													{
																														if (num != 1177)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 0:
																															goto IL_0340;
																														case 17:
																															goto IL_0353;
																														case 50:
																															goto IL_0363;
																														case 142:
																															goto end_IL_0363;
																														case 161:
																															goto end_IL_0370;
																														case 88:
																															goto IL_0390;
																														case 165:
																															goto end_IL_0390;
																														case 74:
																														case 169:
																															goto end_IL_03a0;
																														case 91:
																															goto IL_03c4;
																														case 60:
																															goto end_IL_032d;
																														case 5:
																															goto IL_03e0;
																														case 26:
																														case 85:
																															goto IL_03ee;
																														case 18:
																															goto IL_042f;
																														case 135:
																															goto IL_0443;
																														case 124:
																														case 150:
																															goto IL_0456;
																														case 157:
																															goto IL_0484;
																														case 21:
																															goto IL_048f;
																														case 133:
																															goto IL_04a6;
																														case 93:
																														case 143:
																															goto IL_04b4;
																														case 171:
																															goto IL_04ce;
																														case 48:
																														case 115:
																															goto IL_04dc;
																														case 158:
																															goto IL_052e;
																														case 182:
																															goto IL_0541;
																														case 178:
																															goto IL_0558;
																														case 129:
																															goto IL_0566;
																														case 187:
																															goto IL_0582;
																														case 90:
																															goto IL_058d;
																														case 75:
																														case 104:
																															goto IL_059b;
																														case 62:
																															goto IL_05b4;
																														case 120:
																															goto IL_05c2;
																														case 179:
																															goto IL_05d0;
																														case 82:
																															goto IL_05e3;
																														case 33:
																															goto IL_05f1;
																														case 106:
																														case 126:
																															goto IL_05ff;
																														case 188:
																															goto IL_0617;
																														case 45:
																															goto IL_0625;
																														case 32:
																															goto IL_0638;
																														case 176:
																															goto IL_064c;
																														case 51:
																															goto IL_068b;
																														case 172:
																															goto IL_069e;
																														case 76:
																															goto IL_06a9;
																														case 108:
																														case 114:
																															goto IL_06b7;
																														case 23:
																															goto IL_06d0;
																														case 94:
																															goto IL_06de;
																														case 89:
																															goto IL_06ec;
																														case 72:
																															goto IL_06ff;
																														case 184:
																															goto IL_070d;
																														case 14:
																														case 47:
																															goto IL_071b;
																														case 160:
																															goto IL_075b;
																														case 140:
																															goto IL_076f;
																														case 35:
																															goto IL_0782;
																														case 24:
																															goto IL_078d;
																														case 80:
																														case 128:
																															goto IL_079b;
																														case 147:
																															goto IL_07b7;
																														case 116:
																															goto IL_07c5;
																														case 102:
																															goto IL_07d8;
																														case 151:
																															goto IL_07e6;
																														case 113:
																															goto IL_07f4;
																														case 78:
																														case 145:
																															goto IL_07ff;
																														case 167:
																															goto IL_083f;
																														case 25:
																															goto IL_0853;
																														case 81:
																															goto IL_0866;
																														case 107:
																															goto IL_0874;
																														case 31:
																														case 121:
																															goto IL_087f;
																														case 110:
																															goto IL_08bf;
																														case 9:
																															goto IL_08d3;
																														case 55:
																															goto IL_08e6;
																														case 173:
																															goto IL_08f4;
																														case 77:
																														case 163:
																															goto IL_0902;
																														case 87:
																															goto IL_0924;
																														case 3:
																															goto IL_0932;
																														case 37:
																															goto IL_0940;
																														case 42:
																															goto IL_0953;
																														case 27:
																															goto IL_095e;
																														case 36:
																														case 46:
																															goto IL_096c;
																														case 8:
																															goto IL_0995;
																														case 13:
																															goto IL_09a3;
																														case 86:
																															goto IL_09b6;
																														case 12:
																															goto IL_09cd;
																														case 52:
																														case 68:
																															goto IL_09e4;
																														case 101:
																															goto IL_09f2;
																														case 139:
																															goto IL_0a15;
																														case 153:
																															goto IL_0a1f;
																														case 40:
																															goto IL_0a2d;
																														case 96:
																															goto IL_0a40;
																														case 70:
																															goto IL_0a4e;
																														case 109:
																														case 156:
																															goto IL_0a59;
																														case 67:
																															goto IL_0a6c;
																														case 154:
																															goto IL_0a7a;
																														case 166:
																															goto IL_0a88;
																														case 29:
																														case 44:
																															goto IL_0a96;
																														case 54:
																															goto IL_0ad6;
																														case 19:
																															goto IL_0aea;
																														case 58:
																															goto IL_0b06;
																														case 6:
																														case 20:
																															goto IL_0b14;
																														case 69:
																															goto IL_0b54;
																														case 164:
																															goto IL_0b68;
																														case 34:
																															goto IL_0b7b;
																														case 159:
																															goto IL_0b89;
																														case 71:
																														case 130:
																															goto IL_0ba0;
																														case 28:
																															goto IL_0be0;
																														case 155:
																															goto IL_0bfd;
																														case 97:
																															goto IL_0c19;
																														case 83:
																															goto IL_0c24;
																														case 131:
																														case 168:
																															goto IL_0c2f;
																														case 125:
																															goto IL_0c91;
																														case 1:
																														case 2:
																														case 4:
																														case 7:
																														case 11:
																														case 16:
																														case 22:
																														case 49:
																														case 53:
																														case 57:
																														case 63:
																														case 73:
																														case 79:
																														case 99:
																														case 100:
																														case 103:
																														case 111:
																														case 117:
																														case 122:
																														case 127:
																														case 136:
																														case 137:
																														case 162:
																														case 181:
																														case 189:
																															goto end_IL_0380;
																														case 10:
																														case 15:
																														case 38:
																														case 39:
																														case 43:
																														case 56:
																														case 61:
																														case 64:
																														case 65:
																														case 84:
																														case 92:
																														case 95:
																														case 98:
																														case 105:
																														case 118:
																														case 119:
																														case 132:
																														case 141:
																														case 144:
																														case 146:
																														case 148:
																														case 177:
																														case 185:
																														case 186:
																															goto end_IL_03b9;
																														case 66:
																															goto end_IL_0cb4;
																														case 123:
																															goto end_IL_0cc7;
																														case 138:
																															goto end_IL_0cd2;
																														case 170:
																															goto end_IL_0cdc;
																														case 134:
																															goto end_IL_0ce7;
																														case 183:
																															goto end_IL_0cf7;
																														case 30:
																														case 180:
																															goto end_IL_0d10;
																														case 41:
																															goto end_IL_0d20;
																														case 112:
																															goto end_IL_0d30;
																														case 149:
																															goto end_IL_0d40;
																														case 174:
																															goto end_IL_0d50;
																														case 175:
																															goto end_IL_0d60;
																														case 59:
																														case 152:
																															return;
																														}
																														continue;
																													}
																													goto IL_0638;
																													IL_064c:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)setCursorLeftSiteIdentityPermissionAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																													goto IL_068b;
																													IL_068b:
																													ptr2 += 8;
																													goto end_IL_03b9;
																													IL_0638:
																													array[num6 - 1] = 0;
																													goto IL_064c;
																													continue;
																													end_IL_032d:
																													break;
																												}
																												break;
																											}
																											goto IL_069e;
																											IL_075b:
																											array[num6 - 2] = 3;
																											goto IL_076f;
																											IL_076f:
																											num6--;
																											goto end_IL_03b9;
																											IL_069e:
																											if (18 >= b)
																											{
																												goto IL_06a9;
																											}
																											goto IL_06ff;
																											IL_06a9:
																											if (18 > b)
																											{
																												goto end_IL_0380;
																											}
																											goto IL_06b7;
																											IL_06b7:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																											goto IL_06d0;
																											IL_06d0:
																											array[num6] = 3;
																											goto IL_06de;
																											IL_06de:
																											num6++;
																											goto IL_06ec;
																											IL_06ec:
																											ptr2 += 16;
																											goto end_IL_03b9;
																											IL_06ff:
																											if (19 < b)
																											{
																												goto end_IL_0380;
																											}
																											goto IL_070d;
																											IL_070d:
																											if (19 > b)
																											{
																												goto end_IL_0380;
																											}
																											goto IL_071b;
																											IL_071b:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_075b;
																										}
																										break;
																									}
																									goto IL_0782;
																									IL_07c5:
																									if (22 > b)
																									{
																									}
																									goto end_IL_0380;
																									IL_0782:
																									if (21 >= b)
																									{
																										goto IL_078d;
																									}
																									goto IL_07b7;
																									IL_078d:
																									if (21 > b)
																									{
																										goto end_IL_0380;
																									}
																									goto IL_079b;
																									IL_079b:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									goto end_IL_03b9;
																									IL_07b7:
																									if (22 < b)
																									{
																										goto end_IL_0380;
																									}
																									goto IL_07c5;
																								}
																								goto IL_03d2;
																							}
																							goto IL_03c4;
																							IL_0617:
																							num6--;
																							goto IL_0625;
																							IL_03c4:
																							if (17 > b)
																							{
																								goto IL_03d2;
																							}
																							goto IL_0456;
																							IL_03d2:
																							if (14 >= b)
																							{
																								goto IL_03e0;
																							}
																							goto IL_0484;
																							IL_03e0:
																							if (14 <= b)
																							{
																								goto IL_03ee;
																							}
																							goto IL_0582;
																							IL_03ee:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																							goto IL_042f;
																							IL_042f:
																							array[num6 - 2] = 0;
																							goto IL_0443;
																							IL_0443:
																							num6--;
																							goto end_IL_03b9;
																							IL_0582:
																							if (12 >= b)
																							{
																								goto IL_058d;
																							}
																							goto IL_05e3;
																							IL_058d:
																							if (12 > b)
																							{
																								goto end_IL_0380;
																							}
																							goto IL_059b;
																							IL_059b:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																							goto IL_05b4;
																							IL_05b4:
																							array[num6] = 1;
																							goto IL_05c2;
																							IL_05c2:
																							num6++;
																							goto IL_05d0;
																							IL_05d0:
																							ptr2 += 16;
																							goto end_IL_03b9;
																							IL_05e3:
																							if (13 < b)
																							{
																								goto end_IL_0380;
																							}
																							goto IL_05f1;
																							IL_05f1:
																							if (13 > b)
																							{
																								goto end_IL_0380;
																							}
																							goto IL_05ff;
																							IL_05ff:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_03b9;
																							IL_0484:
																							if (15 < b)
																							{
																								goto IL_048f;
																							}
																							goto IL_04ce;
																							IL_048f:
																							if (16 < b)
																							{
																								goto end_IL_0380;
																							}
																							num = 133;
																							goto IL_04a6;
																							IL_0625:
																							ptr2 += 8;
																							goto end_IL_03b9;
																							IL_04a6:
																							if (16 > b)
																							{
																								goto end_IL_0380;
																							}
																							goto IL_04b4;
																							IL_04b4:
																							array2[num6] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0541;
																							IL_0541:
																							array[num6] = 5;
																							num = 178;
																							goto IL_0558;
																							IL_0558:
																							num6++;
																							goto IL_0566;
																							IL_0566:
																							ptr2 += 8;
																							num = 141;
																							goto end_IL_03b9;
																							IL_04ce:
																							if (15 > b)
																							{
																								goto end_IL_0380;
																							}
																							goto IL_04dc;
																							IL_04dc:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_052e;
																							IL_052e:
																							num6--;
																							goto end_IL_03b9;
																							IL_0456:
																							((delegate*<Class16, void>)setCursorLeftSiteIdentityPermissionAttribute[*(int*)(ptr2 + num3)])((Class16)array2[num6 - 1]);
																							goto IL_0617;
																							continue;
																							end_IL_0363:
																							break;
																						}
																						continue;
																					}
																					goto IL_07d8;
																					IL_0bfd:
																					num6--;
																					num = 61;
																					goto end_IL_03b9;
																					IL_07d8:
																					if (11 <= b)
																					{
																						goto end_IL_03b9;
																					}
																					goto IL_07e6;
																					IL_07e6:
																					if (5 >= b)
																					{
																						goto IL_07f4;
																					}
																					goto IL_0a40;
																					IL_07f4:
																					if (5 <= b)
																					{
																						goto IL_07ff;
																					}
																					goto IL_0866;
																					IL_07ff:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_083f;
																					IL_083f:
																					array[num6 - 2] = 0;
																					goto IL_0853;
																					IL_0853:
																					num6--;
																					goto end_IL_03b9;
																					IL_0866:
																					if (2 >= b)
																					{
																						goto IL_0874;
																					}
																					goto IL_0953;
																					IL_0874:
																					if (2 <= b)
																					{
																						goto IL_087f;
																					}
																					goto IL_08e6;
																					IL_087f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_08bf;
																					IL_08bf:
																					array[num6 - 2] = 0;
																					goto IL_08d3;
																					IL_08d3:
																					num6--;
																					goto end_IL_03b9;
																					IL_08e6:
																					if (1 < b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_08f4;
																					IL_08f4:
																					if (1 > b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_0902;
																					IL_0902:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																					num = 87;
																					goto IL_0924;
																					IL_0924:
																					array[num6] = 0;
																					goto IL_0932;
																					IL_0932:
																					num6++;
																					goto IL_0940;
																					IL_0940:
																					ptr2 += 8;
																					goto end_IL_03b9;
																					IL_0953:
																					if (3 >= b)
																					{
																						goto IL_095e;
																					}
																					goto IL_09b6;
																					IL_095e:
																					if (3 > b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_096c;
																					IL_096c:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0995;
																					IL_0995:
																					ptr2 += 8;
																					goto IL_09a3;
																					IL_09a3:
																					num6--;
																					goto end_IL_03b9;
																					IL_09b6:
																					if (4 < b)
																					{
																						goto end_IL_0380;
																					}
																					num = 12;
																					goto IL_09cd;
																					IL_0c19:
																					if (10 < b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_0c24;
																					IL_09cd:
																					if (4 > b)
																					{
																						goto end_IL_0380;
																					}
																					num = 52;
																					goto IL_09e4;
																					IL_0c24:
																					if (10 > b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_0c2f;
																					IL_09e4:
																					array[num6] = 0;
																					goto IL_09f2;
																					IL_09f2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0a15;
																					IL_0a15:
																					array2[num6] = null;
																					goto IL_0a1f;
																					IL_0a1f:
																					num6++;
																					goto IL_0a2d;
																					IL_0a2d:
																					ptr2 += 8;
																					goto end_IL_03b9;
																					IL_0a40:
																					if (8 >= b)
																					{
																						goto IL_0a4e;
																					}
																					goto IL_0b7b;
																					IL_0a4e:
																					if (8 <= b)
																					{
																						goto IL_0a59;
																					}
																					goto IL_0a6c;
																					IL_0a59:
																					num6--;
																					goto end_IL_03b9;
																					IL_0a6c:
																					if (6 < b)
																					{
																						goto IL_0a7a;
																					}
																					num = 58;
																					goto IL_0b06;
																					IL_0a7a:
																					if (7 < b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_0a88;
																					IL_0a88:
																					if (7 > b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_0a96;
																					IL_0a96:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0ad6;
																					IL_0ad6:
																					array[num6 - 2] = 0;
																					goto IL_0aea;
																					IL_0aea:
																					num6--;
																					goto end_IL_03b9;
																					IL_0c2f:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0c91;
																					IL_0b06:
																					if (6 > b)
																					{
																						goto end_IL_0380;
																					}
																					goto IL_0b14;
																					IL_0b14:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0b54;
																					IL_0b54:
																					array[num6 - 2] = 0;
																					goto IL_0b68;
																					IL_0b68:
																					num6--;
																					goto end_IL_03b9;
																					IL_0b7b:
																					if (9 >= b)
																					{
																						goto IL_0b89;
																					}
																					goto IL_0c19;
																					IL_0b89:
																					if (9 > b)
																					{
																						goto end_IL_0380;
																					}
																					num = 130;
																					goto IL_0ba0;
																					IL_0c91:
																					num6 -= 2;
																					goto end_IL_03b9;
																					IL_0ba0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0be0;
																					IL_0be0:
																					array[num6 - 2] = 0;
																					num = 155;
																					goto IL_0bfd;
																					continue;
																					end_IL_0370:
																					break;
																				}
																				continue;
																				end_IL_0380:
																				break;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_03b9;
																		continue;
																		end_IL_0390:
																		break;
																	}
																	continue;
																	end_IL_03a0:
																	break;
																}
																continue;
																end_IL_03b9:
																break;
															}
															continue;
															end_IL_0cb4:
															break;
														}
														continue;
														end_IL_0cc7:
														break;
													}
													continue;
													end_IL_0cd2:
													break;
												}
												continue;
												end_IL_0cdc:
												break;
											}
											continue;
											end_IL_0ce7:
											break;
										}
										continue;
										end_IL_0cf7:
										break;
									}
									continue;
									end_IL_0d10:
									break;
								}
								continue;
								end_IL_0d20:
								break;
							}
							continue;
							end_IL_0d30:
							break;
						}
						continue;
						end_IL_0d40:
						break;
					}
					continue;
					end_IL_0d50:
					break;
				}
				continue;
				end_IL_0d60:
				break;
			}
		}
	}

	private unsafe void method_1()
	{
		//The blocks IL_0593, IL_059c, IL_05aa, IL_05b8, IL_05c6, IL_05d4, IL_05df, IL_05ed, IL_0605, IL_0613, IL_062f, IL_063d, IL_0648, IL_065b, IL_0669, IL_0674, IL_0682, IL_06a5, IL_06af, IL_06bd, IL_06d0, IL_06de, IL_06e9, IL_0729, IL_073d, IL_0750, IL_075e, IL_0767, IL_0775, IL_078e, IL_079c, IL_07aa, IL_07bd, IL_07cb, IL_07d9, IL_0802, IL_0819, IL_082c, IL_083a, IL_0848, IL_0851, IL_085f, IL_089f, IL_08b3, IL_08c6, IL_08d1, IL_0911, IL_0925, IL_0938, IL_0946, IL_0954, IL_0994, IL_09a8, IL_09bb, IL_09c9, IL_09d7, IL_09e5, IL_09f3, IL_0a01, IL_0a0f, IL_0a4f, IL_0a63, IL_0a76, IL_0a7f, IL_0aea, IL_0b06, IL_0b14, IL_0b22, IL_0b36, IL_0b8a, IL_0b98, IL_0bab, IL_0bb9, IL_0bc4, IL_0be2, IL_0bf0, IL_0c03, IL_0c11, IL_0c1f, IL_0c3c, IL_0c8b, IL_0c95, IL_0cc2, IL_0cd6, IL_0ce4, IL_0cf7, IL_0d02, IL_0d10, IL_0d42, IL_0d5b, IL_0d69, IL_0d77, IL_0d8f, IL_0dad, IL_0dd1, IL_0df2, IL_0e05, IL_0e13, IL_0e21, IL_0e2f, IL_0e3a, IL_0e52, IL_0e60, IL_0e6b, IL_0e7f, IL_0eb7, IL_0eca, IL_0ed8, IL_0ee1, IL_0eef, IL_0f2d, IL_0f40, IL_0f4e, IL_0f5c, IL_0f75, IL_0f83, IL_0f91, IL_0fad, IL_0fbb, IL_0fc6, IL_0fd4, IL_0fdd, IL_0ff5, IL_1003, IL_1011, IL_1024, IL_1032, IL_1040, IL_1063, IL_1071, IL_107f, IL_1092, IL_109b, IL_10a6, IL_10f8, IL_110b, IL_1119, IL_1127, IL_1168, IL_117c, IL_118f, IL_1198, IL_11c6, IL_11d9, IL_11e7, IL_11f2, IL_121b, IL_1229, IL_123c, IL_124a, IL_1255, IL_1295, IL_12a9, IL_12bc, IL_12ca, IL_12d8, IL_12f1, IL_12ff, IL_130d, IL_1320, IL_132e, IL_133c, IL_1350, IL_138f, IL_13a2, IL_13b0, IL_13bb, IL_13fb, IL_140f, IL_1422, IL_1430, IL_1439, IL_1447, IL_145b, IL_149a, IL_14aa, IL_14b5, IL_14c0, IL_14d9, IL_14e4, IL_14ef, IL_1502 are reachable both inside and outside the pinned region starting at IL_0580. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 213;
		int num3;
		int num4;
		byte[] array2;
		object[] array3;
		int[] array4;
		int[] array5;
		long[] array6;
		object[] array7;
		byte* ptr;
		int num5 = default(int);
		int num6 = default(int);
		int __rxRef71 = default(int);
		ref int reference = ref __rxRef71;
		object[] array8;
		int num7;
		byte* num8;
		byte* num10;
		int num11;
		byte* ptr2 = default(byte*);
		byte b = default(byte);
		while (true)
		{
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_056b:
					int num2 = 1;
					while (true)
					{
						IL_055b:
						num3 = num2 * 4;
						while (true)
						{
							IL_054b:
							num4 = num2 * 8;
							while (true)
							{
								IL_053b:
								array2 = new byte[4];
								while (true)
								{
									IL_052b:
									array3 = new object[4];
									while (true)
									{
										IL_051b:
										array4 = new int[4];
										while (true)
										{
											IL_050b:
											array5 = new int[7];
											while (true)
											{
												IL_04fb:
												array6 = new long[4];
												while (true)
												{
													array7 = new object[16];
													while (true)
													{
														IL_04d2:
														array7[0] = this;
														num = 125;
														while (true)
														{
															IL_04be:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BinaryTrackInfogetImpersonationLevel.getCultureInfoCompatibleFrameworksMetadataEntry);
															num = 295;
															while (true)
															{
																if (num != 295)
																{
																	if (num != 1276)
																	{
																		break;
																	}
																	switch (num)
																	{
																	case 213:
																		break;
																	default:
																		continue;
																	case 125:
																		goto IL_04be;
																	case 107:
																		goto IL_04d2;
																	case 86:
																		goto end_IL_04ab;
																	case 177:
																		goto IL_04fb;
																	case 235:
																		goto IL_050b;
																	case 67:
																		goto IL_051b;
																	case 230:
																		goto IL_052b;
																	case 93:
																		goto IL_053b;
																	case 180:
																		goto IL_054b;
																	case 149:
																		goto IL_055b;
																	case 212:
																		goto IL_056b;
																	case 133:
																	case 155:
																		goto IL_0593;
																	case 100:
																		goto IL_059c;
																	case 183:
																		goto IL_05aa;
																	case 194:
																		goto IL_05b8;
																	case 23:
																		goto IL_05c6;
																	case 266:
																		goto IL_05d4;
																	case 59:
																	case 90:
																		goto IL_05df;
																	case 115:
																		goto IL_05ed;
																	case 210:
																		goto IL_0605;
																	case 94:
																		goto IL_0613;
																	case 283:
																		goto IL_062f;
																	case 256:
																		goto IL_063d;
																	case 45:
																	case 203:
																		goto IL_0648;
																	case 145:
																		goto IL_065b;
																	case 24:
																		goto IL_0669;
																	case 88:
																	case 260:
																		goto IL_0674;
																	case 102:
																		goto IL_0682;
																	case 193:
																		goto IL_06a5;
																	case 160:
																		goto IL_06af;
																	case 258:
																		goto IL_06bd;
																	case 144:
																		goto IL_06d0;
																	case 16:
																		goto IL_06de;
																	case 124:
																	case 195:
																		goto IL_06e9;
																	case 49:
																		goto IL_0729;
																	case 188:
																		goto IL_073d;
																	case 174:
																		goto IL_0750;
																	case 30:
																		goto IL_0767;
																	case 186:
																	case 227:
																		goto IL_0775;
																	case 198:
																		goto IL_078e;
																	case 219:
																		goto IL_079c;
																	case 137:
																		goto IL_07aa;
																	case 153:
																		goto IL_07bd;
																	case 36:
																		goto IL_07cb;
																	case 76:
																	case 110:
																		goto IL_07d9;
																	case 229:
																		goto IL_0802;
																	case 263:
																		goto IL_0819;
																	case 97:
																		goto IL_082c;
																	case 185:
																		goto IL_083a;
																	case 69:
																		goto IL_0851;
																	case 5:
																	case 26:
																		goto IL_085f;
																	case 222:
																		goto IL_089f;
																	case 119:
																		goto IL_08b3;
																	case 269:
																		goto IL_08c6;
																	case 104:
																	case 108:
																		goto IL_08d1;
																	case 207:
																		goto IL_0911;
																	case 217:
																		goto IL_0925;
																	case 169:
																		goto IL_0938;
																	case 151:
																		goto IL_0946;
																	case 111:
																	case 140:
																		goto IL_0954;
																	case 208:
																		goto IL_0994;
																	case 147:
																		goto IL_09a8;
																	case 264:
																		goto IL_09bb;
																	case 202:
																		goto IL_09c9;
																	case 73:
																		goto IL_09d7;
																	case 204:
																		goto IL_09e5;
																	case 28:
																		goto IL_09f3;
																	case 127:
																		goto IL_0a01;
																	case 168:
																	case 218:
																		goto IL_0a0f;
																	case 255:
																		goto IL_0a4f;
																	case 1:
																		goto IL_0a63;
																	case 51:
																	case 176:
																		goto IL_0a7f;
																	case 20:
																		goto IL_0aea;
																	case 19:
																		goto IL_0b06;
																	case 245:
																		goto IL_0b14;
																	case 75:
																	case 200:
																		goto IL_0b22;
																	case 162:
																		goto IL_0b36;
																	case 247:
																		goto IL_0b8a;
																	case 134:
																		goto IL_0b98;
																	case 273:
																		goto IL_0bab;
																	case 201:
																		goto IL_0bb9;
																	case 62:
																	case 197:
																		goto IL_0bc4;
																	case 4:
																		goto IL_0be2;
																	case 281:
																		goto IL_0bf0;
																	case 158:
																		goto IL_0c03;
																	case 42:
																		goto IL_0c11;
																	case 106:
																	case 284:
																		goto IL_0c1f;
																	case 135:
																		goto IL_0cd6;
																	case 22:
																		goto IL_0ce4;
																	case 223:
																		goto IL_0cf7;
																	case 11:
																		goto IL_0d02;
																	case 70:
																	case 252:
																		goto IL_0d10;
																	case 206:
																		goto IL_0d42;
																	case 152:
																		goto IL_0d5b;
																	case 277:
																		goto IL_0d69;
																	case 163:
																	case 199:
																		goto IL_0d77;
																	case 53:
																		goto IL_0d8f;
																	case 129:
																		goto IL_0dad;
																	case 132:
																		goto IL_0dd1;
																	case 272:
																		goto IL_0df2;
																	case 233:
																		goto IL_0e05;
																	case 60:
																		goto IL_0e13;
																	case 27:
																		goto IL_0e21;
																	case 190:
																		goto IL_0e2f;
																	case 44:
																	case 246:
																		goto IL_0e3a;
																	case 122:
																		goto IL_0e52;
																	case 192:
																		goto IL_0e60;
																	case 254:
																	case 279:
																		goto IL_0e6b;
																	case 282:
																		goto IL_0e7f;
																	case 172:
																		goto IL_0eb7;
																	case 29:
																		goto IL_0eca;
																	case 225:
																		goto IL_0ee1;
																	case 167:
																	case 189:
																		goto IL_0eef;
																	case 171:
																		goto IL_0f2d;
																	case 77:
																		goto IL_0f40;
																	case 257:
																		goto IL_0f4e;
																	case 9:
																	case 52:
																		goto IL_0f5c;
																	case 181:
																		goto IL_0f75;
																	case 123:
																		goto IL_0f83;
																	case 243:
																		goto IL_0f91;
																	case 228:
																		goto IL_0fad;
																	case 154:
																		goto IL_0fbb;
																	case 175:
																		goto IL_0fc6;
																	case 98:
																	case 161:
																		goto IL_0fdd;
																	case 143:
																		goto IL_0ff5;
																	case 83:
																		goto IL_1003;
																	case 46:
																		goto IL_1011;
																	case 82:
																		goto IL_1024;
																	case 48:
																		goto IL_1032;
																	case 61:
																	case 81:
																		goto IL_1040;
																	case 224:
																		goto IL_1063;
																	case 56:
																		goto IL_1071;
																	case 50:
																		goto IL_107f;
																	case 128:
																		goto IL_109b;
																	case 32:
																	case 99:
																		goto IL_10a6;
																	case 6:
																		goto IL_10f8;
																	case 205:
																		goto IL_110b;
																	case 142:
																		goto IL_1119;
																	case 89:
																	case 242:
																		goto IL_1127;
																	case 232:
																		goto IL_1168;
																	case 126:
																		goto IL_117c;
																	case 131:
																	case 278:
																		goto IL_1198;
																	case 234:
																		goto IL_11c6;
																	case 18:
																		goto IL_11d9;
																	case 211:
																		goto IL_11e7;
																	case 248:
																	case 276:
																		goto IL_11f2;
																	case 54:
																		goto IL_121b;
																	case 21:
																		goto IL_1229;
																	case 35:
																		goto IL_123c;
																	case 65:
																		goto IL_124a;
																	case 31:
																	case 187:
																		goto IL_1255;
																	case 71:
																		goto IL_1295;
																	case 287:
																		goto IL_12a9;
																	case 249:
																		goto IL_12bc;
																	case 148:
																		goto IL_12ca;
																	case 8:
																	case 173:
																		goto IL_12d8;
																	case 178:
																		goto IL_12f1;
																	case 2:
																		goto IL_12ff;
																	case 58:
																		goto IL_130d;
																	case 184:
																		goto IL_1320;
																	case 214:
																		goto IL_132e;
																	case 10:
																	case 25:
																		goto IL_133c;
																	case 164:
																		goto IL_1350;
																	case 33:
																		goto IL_138f;
																	case 244:
																		goto IL_13a2;
																	case 253:
																		goto IL_13b0;
																	case 72:
																	case 141:
																		goto IL_13bb;
																	case 226:
																		goto IL_13fb;
																	case 159:
																		goto IL_140f;
																	case 150:
																		goto IL_1422;
																	case 112:
																		goto IL_1439;
																	case 68:
																	case 179:
																		goto IL_1447;
																	case 231:
																		goto IL_145b;
																	case 41:
																		goto IL_149a;
																	case 85:
																		goto IL_14aa;
																	case 170:
																		goto IL_14b5;
																	case 38:
																	case 240:
																		goto IL_14c0;
																	case 96:
																		goto IL_14d9;
																	case 114:
																		goto IL_14e4;
																	case 12:
																	case 15:
																	case 34:
																	case 37:
																	case 39:
																	case 47:
																	case 55:
																	case 57:
																	case 66:
																	case 74:
																	case 80:
																	case 91:
																	case 92:
																	case 95:
																	case 101:
																	case 103:
																	case 105:
																	case 109:
																	case 120:
																	case 121:
																	case 130:
																	case 136:
																	case 139:
																	case 146:
																	case 157:
																	case 182:
																	case 220:
																	case 237:
																	case 239:
																	case 241:
																	case 259:
																	case 261:
																	case 271:
																	case 275:
																	case 280:
																	case 285:
																	case 286:
																		goto IL_14ef;
																	case 0:
																	case 3:
																	case 7:
																	case 13:
																	case 17:
																	case 40:
																	case 43:
																	case 63:
																	case 64:
																	case 78:
																	case 79:
																	case 84:
																	case 87:
																	case 113:
																	case 116:
																	case 117:
																	case 118:
																	case 138:
																	case 156:
																	case 165:
																	case 166:
																	case 191:
																	case 196:
																	case 209:
																	case 215:
																	case 216:
																	case 221:
																	case 236:
																	case 238:
																	case 250:
																	case 251:
																	case 262:
																	case 265:
																	case 267:
																	case 268:
																	case 274:
																	case 288:
																		goto IL_1502;
																	case 14:
																	case 270:
																		return;
																	}
																	goto end_IL_04eb;
																}
																ptr2 = ptr;
																goto IL_1502;
																IL_13fb:
																array2[num5 - 2] = 3;
																goto IL_140f;
																IL_1422:
																if (31 >= b)
																{
																	num = 112;
																	goto IL_1439;
																}
																goto IL_14ef;
																IL_140f:
																num5--;
																goto IL_1502;
																IL_1502:
																if (num6 == 1)
																{
																	return;
																}
																goto IL_0593;
																IL_0593:
																b = *ptr2;
																goto IL_059c;
																IL_059c:
																ptr2++;
																goto IL_05aa;
																IL_05aa:
																if (b >= 1)
																{
																	goto IL_05b8;
																}
																goto IL_14ef;
																IL_05b8:
																if (b <= 34)
																{
																	goto IL_05c6;
																}
																goto IL_14ef;
																IL_05c6:
																if (17 >= b)
																{
																	goto IL_05d4;
																}
																goto IL_0e05;
																IL_05d4:
																if (17 <= b)
																{
																	goto IL_05df;
																}
																goto IL_062f;
																IL_05df:
																array2[num5] = 5;
																goto IL_05ed;
																IL_05ed:
																array3[num5] = array7[*(int*)(ptr2 + num3)];
																goto IL_0605;
																IL_0605:
																num5++;
																goto IL_0613;
																IL_0613:
																ptr2 += 8;
																num = 43;
																goto IL_1502;
																IL_062f:
																if (8 >= b)
																{
																	goto IL_063d;
																}
																goto IL_09bb;
																IL_063d:
																if (8 <= b)
																{
																	goto IL_0648;
																}
																goto IL_065b;
																IL_0648:
																num5--;
																goto IL_1502;
																IL_065b:
																if (4 >= b)
																{
																	goto IL_0669;
																}
																goto IL_082c;
																IL_0669:
																if (4 <= b)
																{
																	goto IL_0674;
																}
																goto IL_06d0;
																IL_0674:
																array2[num5] = 0;
																goto IL_0682;
																IL_0682:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																goto IL_06a5;
																IL_06a5:
																array3[num5] = null;
																goto IL_06af;
																IL_06af:
																num5++;
																goto IL_06bd;
																IL_06bd:
																ptr2 += 8;
																goto IL_1502;
																IL_06d0:
																if (2 >= b)
																{
																	goto IL_06de;
																}
																goto IL_07bd;
																IL_06de:
																if (2 <= b)
																{
																	goto IL_06e9;
																}
																goto IL_0750;
																IL_06e9:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0729;
																IL_0729:
																array2[num5 - 2] = 0;
																goto IL_073d;
																IL_073d:
																num5--;
																goto IL_1502;
																IL_0750:
																if (1 >= b)
																{
																	num = 30;
																	goto IL_0767;
																}
																goto IL_14ef;
																IL_14ef:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_1502;
																IL_0767:
																if (1 <= b)
																{
																	goto IL_0775;
																}
																goto IL_14ef;
																IL_0775:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																goto IL_078e;
																IL_078e:
																array2[num5] = 0;
																goto IL_079c;
																IL_079c:
																num5++;
																goto IL_07aa;
																IL_07aa:
																ptr2 += 8;
																goto IL_1502;
																IL_07bd:
																if (3 >= b)
																{
																	goto IL_07cb;
																}
																goto IL_14ef;
																IL_07cb:
																if (3 <= b)
																{
																	goto IL_07d9;
																}
																goto IL_14ef;
																IL_07d9:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0802;
																IL_0802:
																ptr2 += 8;
																num = 263;
																goto IL_0819;
																IL_0819:
																num5--;
																goto IL_1502;
																IL_082c:
																if (6 < b)
																{
																	goto IL_083a;
																}
																goto IL_08c6;
																IL_083a:
																if (7 >= b)
																{
																	num = 69;
																	goto IL_0851;
																}
																goto IL_14ef;
																IL_1439:
																if (31 <= b)
																{
																	goto IL_1447;
																}
																goto IL_14ef;
																IL_0851:
																if (7 <= b)
																{
																	goto IL_085f;
																}
																goto IL_14ef;
																IL_085f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_089f;
																IL_089f:
																array2[num5 - 2] = 0;
																goto IL_08b3;
																IL_08b3:
																num5--;
																goto IL_1502;
																IL_08c6:
																if (6 <= b)
																{
																	goto IL_08d1;
																}
																goto IL_0938;
																IL_08d1:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0911;
																IL_0911:
																array2[num5 - 2] = 0;
																goto IL_0925;
																IL_0925:
																num5--;
																goto IL_1502;
																IL_0938:
																if (5 >= b)
																{
																	goto IL_0946;
																}
																goto IL_14ef;
																IL_0946:
																if (5 <= b)
																{
																	goto IL_0954;
																}
																goto IL_14ef;
																IL_0954:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0994;
																IL_0994:
																array2[num5 - 2] = 0;
																goto IL_09a8;
																IL_09a8:
																num5--;
																goto IL_1502;
																IL_09bb:
																if (12 >= b)
																{
																	goto IL_09c9;
																}
																goto IL_0bab;
																IL_09c9:
																if (12 > b)
																{
																	goto IL_09d7;
																}
																goto IL_1502;
																IL_09d7:
																if (10 >= b)
																{
																	goto IL_09e5;
																}
																goto IL_0b06;
																IL_09e5:
																if (10 > b)
																{
																	goto IL_09f3;
																}
																num = 51;
																goto IL_0a7f;
																IL_09f3:
																if (9 >= b)
																{
																	goto IL_0a01;
																}
																goto IL_14ef;
																IL_0a01:
																if (9 <= b)
																{
																	goto IL_0a0f;
																}
																goto IL_14ef;
																IL_0a0f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0a4f;
																IL_0a4f:
																array2[num5 - 2] = 0;
																goto IL_0a63;
																IL_0a63:
																num5--;
																goto IL_1502;
																IL_1447:
																array2[num5 - 1] = 3;
																goto IL_145b;
																IL_0a7f:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																num = 20;
																goto IL_0aea;
																IL_0aea:
																num5 -= 2;
																num = 87;
																goto IL_1502;
																IL_0b06:
																if (11 >= b)
																{
																	goto IL_0b14;
																}
																goto IL_14ef;
																IL_0b14:
																if (11 <= b)
																{
																	goto IL_0b22;
																}
																goto IL_14ef;
																IL_0b22:
																array2[num5 - 2] = 0;
																goto IL_0b36;
																IL_0b36:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_0b8a;
																IL_0b8a:
																num5--;
																goto IL_0b98;
																IL_0b98:
																ptr2 += 8;
																goto IL_1502;
																IL_0bab:
																if (14 >= b)
																{
																	goto IL_0bb9;
																}
																goto IL_0cf7;
																IL_0bb9:
																if (14 <= b)
																{
																	goto IL_0bc4;
																}
																goto IL_0c03;
																IL_0bc4:
																array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																goto IL_0be2;
																IL_0be2:
																ptr2 += 8;
																goto IL_0bf0;
																IL_0bf0:
																num5--;
																goto IL_1502;
																IL_0c03:
																if (13 >= b)
																{
																	goto IL_0c11;
																}
																goto IL_14ef;
																IL_0c11:
																if (13 <= b)
																{
																	goto IL_0c1f;
																}
																goto IL_14ef;
																IL_0c1f:
																array8 = array3;
																num7 = num5;
																if (array == null)
																{
																	goto end_IL_0576;
																}
																num8 = ptr2;
																byte b2 = *num8;
																ptr2 = num8 + 4;
																int num9 = *(int*)(ptr2 + num3);
																ptr2 += 8;
																byte* ptr3 = ptr2 + num9;
																byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																while (ptr2 != ptr3)
																{
																	*ptr4 = (byte)(*ptr2 ^ b2);
																	ptr2++;
																	ptr4++;
																}
																array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																goto IL_0cd6;
																IL_145b:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<double, double>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_149a;
																IL_149a:
																ptr2 += 8;
																goto IL_1502;
																IL_14aa:
																if (33 >= b)
																{
																	goto IL_14b5;
																}
																goto IL_14d9;
																IL_0cd6:
																array2[num5] = 5;
																goto IL_0ce4;
																IL_0ce4:
																num5++;
																goto IL_1502;
																IL_0cf7:
																if (15 >= b)
																{
																	goto IL_0d02;
																}
																goto IL_0d5b;
																IL_0d02:
																if (15 <= b)
																{
																	goto IL_0d10;
																}
																goto IL_14ef;
																IL_0d10:
																array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																num = 206;
																goto IL_0d42;
																IL_0d42:
																array2[num5 - 1] = 5;
																goto IL_1502;
																IL_0d5b:
																if (16 >= b)
																{
																	goto IL_0d69;
																}
																goto IL_14ef;
																IL_0d69:
																if (16 <= b)
																{
																	goto IL_0d77;
																}
																goto IL_14ef;
																IL_0d77:
																array2[num5] = array2[num5 - 1];
																goto IL_0d8f;
																IL_0d8f:
																array4[num5 - 0] = array4[num5 - 1];
																goto IL_0dad;
																IL_0dad:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0dd1;
																IL_0dd1:
																array3[num5] = array3[num5 - 1];
																num = 272;
																goto IL_0df2;
																IL_0df2:
																num5++;
																goto IL_1502;
																IL_0e05:
																if (26 >= b)
																{
																	goto IL_0e13;
																}
																goto IL_11d9;
																IL_0e13:
																if (26 > b)
																{
																	goto IL_0e21;
																}
																num = 131;
																goto IL_1198;
																IL_0e21:
																if (21 >= b)
																{
																	goto IL_0e2f;
																}
																goto IL_0fad;
																IL_0e2f:
																if (21 <= b)
																{
																	goto IL_0e3a;
																}
																goto IL_0e52;
																IL_0e3a:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_1502;
																IL_0e52:
																if (19 >= b)
																{
																	goto IL_0e60;
																}
																goto IL_0f40;
																IL_0e60:
																if (19 <= b)
																{
																	goto IL_0e6b;
																}
																goto IL_0eca;
																IL_0e6b:
																array2[num5 - 1] = 5;
																goto IL_0e7f;
																IL_0e7f:
																array3[num5 - 1] = ((delegate*<string[], string>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																goto IL_0eb7;
																IL_0eb7:
																ptr2 += 8;
																goto IL_1502;
																IL_0eca:
																if (18 >= b)
																{
																	num = 225;
																	goto IL_0ee1;
																}
																goto IL_14ef;
																IL_14c0:
																num10 = ptr2;
																num11 = -200;
																num6 = 1;
																ptr2 = num10 + num11;
																goto IL_1502;
																IL_0ee1:
																if (18 <= b)
																{
																	goto IL_0eef;
																}
																goto IL_14ef;
																IL_0eef:
																((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																goto IL_0f2d;
																IL_0f2d:
																num5 -= 3;
																goto IL_1502;
																IL_0f40:
																if (20 >= b)
																{
																	goto IL_0f4e;
																}
																goto IL_14ef;
																IL_0f4e:
																if (20 <= b)
																{
																	goto IL_0f5c;
																}
																goto IL_14ef;
																IL_0f5c:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)(ptr2 + num4);
																goto IL_0f75;
																IL_0f75:
																array2[num5] = 1;
																goto IL_0f83;
																IL_0f83:
																num5++;
																goto IL_0f91;
																IL_0f91:
																ptr2 += 16;
																num = 288;
																goto IL_1502;
																IL_0fad:
																if (23 < b)
																{
																	goto IL_0fbb;
																}
																num = 128;
																goto IL_109b;
																IL_0fbb:
																if (24 >= b)
																{
																	goto IL_0fc6;
																}
																goto IL_1024;
																IL_0fc6:
																if (24 <= b)
																{
																	num = 161;
																	goto IL_0fdd;
																}
																goto IL_14ef;
																IL_14e4:
																if (34 <= b)
																{
																}
																goto IL_14ef;
																IL_0fdd:
																array3[num5] = array7[*(int*)(ptr2 + num3)];
																goto IL_0ff5;
																IL_0ff5:
																array2[num5] = 5;
																goto IL_1003;
																IL_1003:
																num5++;
																goto IL_1011;
																IL_1011:
																ptr2 += 8;
																goto IL_1502;
																IL_1024:
																if (25 >= b)
																{
																	goto IL_1032;
																}
																goto IL_14ef;
																IL_1032:
																if (25 <= b)
																{
																	goto IL_1040;
																}
																goto IL_14ef;
																IL_1040:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(float*)(ptr2 + num3);
																num = 224;
																goto IL_1063;
																IL_1063:
																array2[num5] = 3;
																goto IL_1071;
																IL_1071:
																num5++;
																goto IL_107f;
																IL_107f:
																ptr2 += 8;
																goto IL_1502;
																IL_14d9:
																if (34 >= b)
																{
																	goto IL_14e4;
																}
																goto IL_14ef;
																IL_109b:
																if (23 <= b)
																{
																	goto IL_10a6;
																}
																goto IL_110b;
																IL_10a6:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_10f8;
																IL_10f8:
																num5--;
																goto IL_1502;
																IL_110b:
																if (22 >= b)
																{
																	goto IL_1119;
																}
																goto IL_14ef;
																IL_1119:
																if (22 <= b)
																{
																	goto IL_1127;
																}
																goto IL_14ef;
																IL_1127:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0);
																goto IL_1168;
																IL_1168:
																array2[num5 - 2] = 0;
																goto IL_117c;
																IL_117c:
																num5--;
																goto IL_1502;
																IL_14b5:
																if (33 <= b)
																{
																	goto IL_14c0;
																}
																goto IL_14ef;
																IL_1198:
																((Class16)array3[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_11c6;
																IL_11c6:
																num5 -= 2;
																goto IL_1502;
																IL_11d9:
																if (30 >= b)
																{
																	goto IL_11e7;
																}
																goto IL_13a2;
																IL_11e7:
																if (30 <= b)
																{
																	goto IL_11f2;
																}
																goto IL_123c;
																IL_11f2:
																((delegate*<string, void>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																goto IL_121b;
																IL_121b:
																num5--;
																goto IL_1229;
																IL_1229:
																ptr2 += 8;
																goto IL_1502;
																IL_123c:
																if (28 >= b)
																{
																	goto IL_124a;
																}
																goto IL_1320;
																IL_124a:
																if (28 <= b)
																{
																	goto IL_1255;
																}
																goto IL_12bc;
																IL_1255:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_1295;
																IL_1295:
																array2[num5 - 2] = 3;
																goto IL_12a9;
																IL_12a9:
																num5--;
																goto IL_1502;
																IL_12bc:
																if (27 >= b)
																{
																	goto IL_12ca;
																}
																goto IL_14ef;
																IL_12ca:
																if (27 <= b)
																{
																	goto IL_12d8;
																}
																goto IL_14ef;
																IL_12d8:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(double*)(ptr2 + num4);
																goto IL_12f1;
																IL_12f1:
																array2[num5] = 3;
																goto IL_12ff;
																IL_12ff:
																num5++;
																goto IL_130d;
																IL_130d:
																ptr2 += 16;
																goto IL_1502;
																IL_1320:
																if (29 >= b)
																{
																	goto IL_132e;
																}
																goto IL_14ef;
																IL_132e:
																if (29 <= b)
																{
																	goto IL_133c;
																}
																goto IL_14ef;
																IL_133c:
																array2[num5 - 1] = 0;
																goto IL_1350;
																IL_1350:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<double, int>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_138f;
																IL_138f:
																ptr2 += 8;
																goto IL_1502;
																IL_13a2:
																if (32 >= b)
																{
																	goto IL_13b0;
																}
																goto IL_14aa;
																IL_13b0:
																if (32 <= b)
																{
																	goto IL_13bb;
																}
																goto IL_1422;
																IL_13bb:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_13fb;
																continue;
																end_IL_04ab:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_04eb:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			end_IL_0576:
			break;
		}
		while (true)
		{
			byte[] array = new byte[4];
			do
			{
				num8 = ptr2;
				byte b2 = *num8;
				ptr2 = num8 + 4;
				int num9 = *(int*)(ptr2 + num3);
				ptr2 += 8;
				byte* ptr3 = ptr2 + num9;
				byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
				while (ptr2 != ptr3)
				{
					*ptr4 = (byte)(*ptr2 ^ b2);
					ptr2++;
					ptr4++;
				}
				array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
				array2[num5] = 5;
				num5++;
				while (true)
				{
					if (num6 == 1)
					{
						return;
					}
					b = *ptr2;
					ptr2++;
					if (b >= 1 && b <= 34)
					{
						if (17 >= b)
						{
							if (17 <= b)
							{
								array2[num5] = 5;
								array3[num5] = array7[*(int*)(ptr2 + num3)];
								num5++;
								ptr2 += 8;
								num = 43;
								continue;
							}
							if (8 >= b)
							{
								if (8 <= b)
								{
									num5--;
									continue;
								}
								if (4 >= b)
								{
									if (4 <= b)
									{
										array2[num5] = 0;
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
										array3[num5] = null;
										num5++;
										ptr2 += 8;
										continue;
									}
									if (2 >= b)
									{
										if (2 <= b)
										{
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											array2[num5 - 2] = 0;
											num5--;
											continue;
										}
										if (1 >= b)
										{
											num = 30;
											if (1 <= b)
											{
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
												array2[num5] = 0;
												num5++;
												ptr2 += 8;
												continue;
											}
										}
									}
									else if (3 >= b && 3 <= b)
									{
										reference = ref array5[*(int*)(ptr2 + num3)];
										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
										ptr2 += 8;
										num = 263;
										num5--;
										continue;
									}
								}
								else if (6 < b)
								{
									if (7 >= b)
									{
										num = 69;
										if (7 <= b)
										{
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											array2[num5 - 2] = 0;
											num5--;
											continue;
										}
									}
								}
								else
								{
									if (6 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
										array2[num5 - 2] = 0;
										num5--;
										continue;
									}
									if (5 >= b && 5 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
										array2[num5 - 2] = 0;
										num5--;
										continue;
									}
								}
							}
							else if (12 >= b)
							{
								if (12 <= b)
								{
									continue;
								}
								if (10 >= b)
								{
									if (10 <= b)
									{
										num = 51;
										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
										num = 20;
										num5 -= 2;
										num = 87;
										continue;
									}
									if (9 >= b && 9 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
										array2[num5 - 2] = 0;
										num5--;
										continue;
									}
								}
								else if (11 >= b && 11 <= b)
								{
									array2[num5 - 2] = 0;
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
									num5--;
									ptr2 += 8;
									continue;
								}
							}
							else if (14 >= b)
							{
								if (14 <= b)
								{
									array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
									ptr2 += 8;
									num5--;
									continue;
								}
								if (13 >= b && 13 <= b)
								{
									break;
								}
							}
							else if (15 >= b)
							{
								if (15 <= b)
								{
									array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
									num = 206;
									array2[num5 - 1] = 5;
									continue;
								}
							}
							else if (16 >= b && 16 <= b)
							{
								array2[num5] = array2[num5 - 1];
								array4[num5 - 0] = array4[num5 - 1];
								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
								array3[num5] = array3[num5 - 1];
								num = 272;
								num5++;
								continue;
							}
						}
						else if (26 >= b)
						{
							if (26 <= b)
							{
								num = 131;
								((Class16)array3[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
								num5 -= 2;
								continue;
							}
							if (21 >= b)
							{
								if (21 <= b)
								{
									ptr2 = ptr + *(int*)(ptr2 + num3);
									continue;
								}
								if (19 >= b)
								{
									if (19 <= b)
									{
										array2[num5 - 1] = 5;
										array3[num5 - 1] = ((delegate*<string[], string>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
										ptr2 += 8;
										continue;
									}
									if (18 >= b)
									{
										num = 225;
										if (18 <= b)
										{
											((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
											num5 -= 3;
											continue;
										}
									}
								}
								else if (20 >= b && 20 <= b)
								{
									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)(ptr2 + num4);
									array2[num5] = 1;
									num5++;
									ptr2 += 16;
									num = 288;
									continue;
								}
							}
							else if (23 < b)
							{
								if (24 >= b)
								{
									if (24 <= b)
									{
										num = 161;
										array3[num5] = array7[*(int*)(ptr2 + num3)];
										array2[num5] = 5;
										num5++;
										ptr2 += 8;
										continue;
									}
								}
								else if (25 >= b && 25 <= b)
								{
									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(float*)(ptr2 + num3);
									num = 224;
									array2[num5] = 3;
									num5++;
									ptr2 += 8;
									continue;
								}
							}
							else
							{
								num = 128;
								if (23 <= b)
								{
									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
									num5--;
									continue;
								}
								if (22 >= b && 22 <= b)
								{
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0);
									array2[num5 - 2] = 0;
									num5--;
									continue;
								}
							}
						}
						else if (30 >= b)
						{
							if (30 <= b)
							{
								((delegate*<string, void>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
								num5--;
								ptr2 += 8;
								continue;
							}
							if (28 >= b)
							{
								if (28 <= b)
								{
									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
									array2[num5 - 2] = 3;
									num5--;
									continue;
								}
								if (27 >= b && 27 <= b)
								{
									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(double*)(ptr2 + num4);
									array2[num5] = 3;
									num5++;
									ptr2 += 16;
									continue;
								}
							}
							else if (29 >= b && 29 <= b)
							{
								array2[num5 - 1] = 0;
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<double, int>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
								ptr2 += 8;
								continue;
							}
						}
						else if (32 >= b)
						{
							if (32 <= b)
							{
								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
								array2[num5 - 2] = 3;
								num5--;
								continue;
							}
							if (31 >= b)
							{
								num = 112;
								if (31 <= b)
								{
									array2[num5 - 1] = 3;
									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<double, double>)LocalSidTokenAppContainerSid[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
									ptr2 += 8;
									continue;
								}
							}
						}
						else if (33 >= b)
						{
							if (33 <= b)
							{
								num10 = ptr2;
								num11 = -200;
								num6 = 1;
								ptr2 = num10 + num11;
								continue;
							}
						}
						else if (34 >= b && 34 <= b)
						{
						}
					}
					ptr2 = ptr + *(int*)(ptr2 + num3);
				}
				array8 = array3;
				num7 = num5;
			}
			while (array != null);
		}
	}

	public Class16()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 50;
		int num4 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EntryPointIList.MVarOemMinus);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 131;
															while (true)
															{
																if (num != 131)
																{
																	if (num != 1112)
																	{
																		goto IL_0498;
																	}
																	switch (num)
																	{
																	case 102:
																		goto end_IL_021b;
																	case 37:
																		goto IL_023f;
																	case 64:
																		goto IL_024d;
																	case 22:
																		goto IL_025b;
																	case 63:
																		goto IL_0269;
																	case 14:
																		goto IL_0277;
																	case 81:
																	case 107:
																		goto IL_0285;
																	case 68:
																		goto IL_0293;
																	case 4:
																	case 80:
																		goto IL_029e;
																	case 59:
																		goto IL_02c7;
																	case 99:
																		goto IL_02d5;
																	case 44:
																		goto IL_02e8;
																	case 72:
																	case 101:
																		goto IL_02f6;
																	case 26:
																		goto IL_0304;
																	case 93:
																	case 118:
																		goto IL_0312;
																	case 1:
																		goto IL_0352;
																	case 41:
																		goto IL_0366;
																	case 73:
																		goto IL_0379;
																	case 57:
																	case 104:
																		goto IL_0395;
																	case 85:
																		goto IL_03a0;
																	case 40:
																	case 90:
																		goto IL_03ae;
																	case 17:
																		goto IL_03ee;
																	case 74:
																		goto IL_0402;
																	case 58:
																	case 106:
																		goto IL_0415;
																	case 47:
																		goto IL_0420;
																	case 96:
																	case 110:
																		goto IL_042e;
																	case 52:
																		goto IL_043c;
																	case 98:
																		goto IL_045f;
																	case 112:
																		goto IL_0469;
																	case 25:
																		goto IL_0477;
																	case 103:
																	case 124:
																		goto IL_0498;
																	case 34:
																		goto IL_04d8;
																	case 18:
																		goto IL_04ec;
																	case 20:
																	case 113:
																		goto IL_0508;
																	case 24:
																		goto IL_0516;
																	case 66:
																	case 123:
																		goto IL_0524;
																	case 54:
																		goto IL_0532;
																	case 71:
																		goto IL_0540;
																	case 56:
																	case 120:
																		goto IL_054e;
																	case 100:
																		goto IL_058e;
																	case 53:
																		goto IL_05a2;
																	case 122:
																		goto IL_05c7;
																	case 86:
																	case 91:
																		goto IL_05d5;
																	case 9:
																		goto IL_05ee;
																	case 94:
																		goto IL_05fc;
																	case 45:
																		goto IL_0613;
																	case 38:
																	case 95:
																		goto IL_0626;
																	case 108:
																		goto IL_0643;
																	case 6:
																		goto IL_0682;
																	case 35:
																		goto IL_069e;
																	case 78:
																		goto IL_06a9;
																	case 23:
																	case 55:
																		goto IL_06b4;
																	case 3:
																	case 114:
																		goto IL_06c4;
																	case 48:
																		goto IL_06cf;
																	case 31:
																	case 79:
																		goto IL_06da;
																	case 7:
																	case 8:
																	case 10:
																	case 19:
																	case 29:
																	case 30:
																	case 32:
																	case 43:
																	case 51:
																	case 61:
																	case 62:
																	case 65:
																	case 82:
																	case 83:
																	case 87:
																	case 88:
																	case 89:
																	case 92:
																	case 105:
																	case 109:
																	case 115:
																	case 119:
																	case 121:
																		goto IL_06f3;
																	case 2:
																		goto IL_0716;
																	case 70:
																		goto IL_0724;
																	case 42:
																		goto IL_0732;
																	case 5:
																	case 12:
																	case 13:
																	case 27:
																	case 28:
																	case 39:
																	case 67:
																	case 75:
																	case 76:
																	case 77:
																	case 97:
																	case 111:
																	case 117:
																		goto end_IL_022b;
																	case 33:
																		goto end_IL_0740;
																	case 69:
																		goto end_IL_0753;
																	case 46:
																		goto end_IL_075d;
																	case 0:
																		goto end_IL_0768;
																	case 11:
																		goto end_IL_077d;
																	case 21:
																	case 36:
																		goto end_IL_0792;
																	case 15:
																		goto end_IL_07a2;
																	case 16:
																	case 60:
																		goto end_IL_07b2;
																	case 49:
																		goto end_IL_07c2;
																	case 50:
																		goto end_IL_07d2;
																	case 84:
																	case 116:
																		goto IL_07ed;
																	}
																	continue;
																}
																b = *ptr2;
																goto IL_023f;
																IL_06c4:
																if (11 >= b)
																{
																	goto IL_06cf;
																}
																goto IL_06f3;
																IL_06da:
																byte* num5 = ptr2;
																num4 = 1;
																ptr2 = num5 + -200;
																goto end_IL_022b;
																IL_06cf:
																if (11 <= b)
																{
																	goto IL_06da;
																}
																goto IL_06f3;
																IL_023f:
																ptr2++;
																goto IL_024d;
																IL_024d:
																if (b >= 1)
																{
																	goto IL_025b;
																}
																goto IL_06f3;
																IL_025b:
																if (b <= 11)
																{
																	goto IL_0269;
																}
																goto IL_06f3;
																IL_0269:
																if (6 >= b)
																{
																	goto IL_0277;
																}
																num = 20;
																goto IL_0508;
																IL_0277:
																if (6 > b)
																{
																	goto IL_0285;
																}
																goto IL_0498;
																IL_0285:
																if (3 >= b)
																{
																	goto IL_0293;
																}
																num = 57;
																goto IL_0395;
																IL_0293:
																if (3 <= b)
																{
																	goto IL_029e;
																}
																goto IL_02e8;
																IL_029e:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_02c7;
																IL_02c7:
																ptr2 += 8;
																goto IL_02d5;
																IL_02d5:
																num6--;
																goto end_IL_022b;
																IL_02e8:
																if (1 < b)
																{
																	goto IL_02f6;
																}
																goto IL_0379;
																IL_02f6:
																if (2 >= b)
																{
																	goto IL_0304;
																}
																goto IL_06f3;
																IL_0304:
																if (2 <= b)
																{
																	goto IL_0312;
																}
																goto IL_06f3;
																IL_0312:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_0352;
																IL_0352:
																array[num6 - 2] = 0;
																goto IL_0366;
																IL_0366:
																num6--;
																goto end_IL_022b;
																IL_0379:
																if (1 > b)
																{
																}
																goto IL_06f3;
																IL_0716:
																array[num6] = 0;
																goto IL_0724;
																IL_0395:
																if (4 >= b)
																{
																	goto IL_03a0;
																}
																goto IL_0415;
																IL_03a0:
																if (4 <= b)
																{
																	goto IL_03ae;
																}
																goto IL_06f3;
																IL_03ae:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_03ee;
																IL_03ee:
																array[num6 - 2] = 0;
																goto IL_0402;
																IL_0402:
																num6--;
																goto end_IL_022b;
																IL_0415:
																if (5 >= b)
																{
																	goto IL_0420;
																}
																num = 30;
																goto IL_06f3;
																IL_0420:
																if (5 <= b)
																{
																	goto IL_042e;
																}
																goto IL_06f3;
																IL_042e:
																array[num6] = 0;
																goto IL_043c;
																IL_043c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_045f;
																IL_045f:
																array2[num6] = null;
																goto IL_0469;
																IL_0469:
																num6++;
																goto IL_0477;
																IL_0477:
																ptr2 += 8;
																goto end_IL_022b;
																IL_0724:
																num6++;
																goto IL_0732;
																IL_0498:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_04d8;
																IL_04d8:
																array[num6 - 2] = 0;
																goto IL_04ec;
																IL_04ec:
																num6--;
																goto end_IL_022b;
																IL_06f3:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0716;
																IL_0508:
																if (9 >= b)
																{
																	goto IL_0516;
																}
																goto IL_069e;
																IL_0516:
																if (9 > b)
																{
																	goto IL_0524;
																}
																goto IL_0626;
																IL_0524:
																if (7 < b)
																{
																	goto IL_0532;
																}
																num = 122;
																goto IL_05c7;
																IL_0532:
																if (8 >= b)
																{
																	goto IL_0540;
																}
																goto IL_06f3;
																IL_0540:
																if (8 <= b)
																{
																	goto IL_054e;
																}
																goto IL_06f3;
																IL_054e:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_058e;
																IL_058e:
																array[num6 - 2] = 0;
																goto IL_05a2;
																IL_05a2:
																num6--;
																num = 39;
																goto end_IL_022b;
																IL_0732:
																ptr2 += 8;
																goto end_IL_022b;
																IL_05c7:
																if (7 <= b)
																{
																	goto IL_05d5;
																}
																goto IL_06f3;
																IL_05d5:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																goto IL_05ee;
																IL_05ee:
																array[num6] = 0;
																goto IL_05fc;
																IL_05fc:
																num6++;
																num = 45;
																goto IL_0613;
																IL_0613:
																ptr2 += 8;
																goto end_IL_022b;
																IL_0626:
																array[num6 - 1] = 0;
																num = 108;
																goto IL_0643;
																IL_0643:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)getSettingPreLoadEntry[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																goto IL_0682;
																IL_0682:
																ptr2 += 8;
																num = 27;
																goto end_IL_022b;
																IL_069e:
																if (10 >= b)
																{
																	goto IL_06a9;
																}
																goto IL_06c4;
																IL_06a9:
																if (10 <= b)
																{
																	goto IL_06b4;
																}
																goto IL_06f3;
																IL_06b4:
																num6--;
																goto end_IL_022b;
																continue;
																end_IL_021b:
																break;
															}
															continue;
															end_IL_022b:
															break;
														}
														continue;
													}
													goto IL_07ed;
													IL_07ed:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0740:
													break;
												}
												continue;
												end_IL_0753:
												break;
											}
											continue;
											end_IL_075d:
											break;
										}
										continue;
										end_IL_0768:
										break;
									}
									continue;
									end_IL_077d:
									break;
								}
								continue;
								end_IL_0792:
								break;
							}
							continue;
							end_IL_07a2:
							break;
						}
						continue;
						end_IL_07b2:
						break;
					}
					continue;
					end_IL_07c2:
					break;
				}
				continue;
				end_IL_07d2:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 103;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResourceManagerCreatingResourceSetGetClientContextSink.CurrentIntoBufferPrivateProcessMessage);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 26;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0244:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0224:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0217:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_0207:
																								if (8 < b)
																								{
																									while (9 >= b)
																									{
																										num = 113;
																										while (true)
																										{
																											if (num != 113)
																											{
																												if (num != 1094)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 10:
																												case 85:
																													goto IL_01f4;
																												case 91:
																													goto IL_0207;
																												case 8:
																												case 106:
																													goto end_IL_01e1;
																												case 15:
																													goto IL_0224;
																												case 2:
																													goto IL_0234;
																												case 55:
																													goto IL_0244;
																												case 40:
																													goto end_IL_0244;
																												case 6:
																												case 42:
																													goto end_IL_0254;
																												case 76:
																													goto IL_026f;
																												case 3:
																												case 13:
																													goto IL_027a;
																												case 7:
																													goto IL_0288;
																												case 4:
																												case 52:
																													goto IL_0298;
																												case 74:
																													goto IL_02b1;
																												case 27:
																												case 80:
																													goto IL_02c1;
																												case 83:
																													goto IL_0303;
																												case 35:
																													goto IL_0311;
																												case 88:
																													goto IL_0324;
																												case 45:
																													goto IL_0341;
																												case 31:
																												case 95:
																													goto IL_0362;
																												case 38:
																													goto IL_037e;
																												case 48:
																												case 99:
																													goto IL_038c;
																												case 72:
																													goto IL_03cc;
																												case 21:
																													goto IL_03e0;
																												case 46:
																													goto IL_03f3;
																												case 18:
																												case 57:
																													goto IL_03fe;
																												case 16:
																													goto IL_040c;
																												case 49:
																													goto IL_042f;
																												case 53:
																													goto IL_0439;
																												case 22:
																													goto IL_0447;
																												case 82:
																													goto IL_045a;
																												case 56:
																												case 67:
																													goto IL_0468;
																												case 37:
																												case 78:
																													goto IL_0476;
																												case 79:
																													goto IL_0484;
																												case 39:
																												case 50:
																													goto IL_0492;
																												case 62:
																													goto IL_04d2;
																												case 11:
																													goto IL_04e6;
																												case 25:
																													goto IL_04f9;
																												case 12:
																												case 29:
																													goto IL_0507;
																												case 96:
																													goto IL_0530;
																												case 89:
																													goto IL_053e;
																												case 33:
																													goto IL_0551;
																												case 51:
																												case 87:
																													goto IL_055c;
																												case 24:
																													goto IL_0567;
																												case 17:
																												case 59:
																													goto IL_0574;
																												case 14:
																													goto IL_05b4;
																												case 77:
																													goto IL_05c8;
																												case 30:
																												case 34:
																												case 36:
																												case 43:
																												case 44:
																												case 47:
																												case 54:
																												case 60:
																												case 61:
																												case 63:
																												case 65:
																												case 66:
																												case 68:
																												case 69:
																												case 90:
																												case 98:
																												case 104:
																												case 105:
																													goto end_IL_01f4;
																												case 97:
																													goto IL_05fb;
																												case 86:
																													goto IL_0609;
																												case 19:
																													goto IL_0617;
																												case 9:
																												case 26:
																												case 28:
																												case 32:
																												case 41:
																												case 58:
																												case 71:
																												case 75:
																												case 84:
																												case 94:
																												case 100:
																													goto end_IL_0264;
																												case 92:
																													goto end_IL_0625;
																												case 0:
																													goto end_IL_0638;
																												case 23:
																													goto end_IL_064b;
																												case 81:
																													goto end_IL_0656;
																												case 73:
																													goto end_IL_066b;
																												case 1:
																												case 70:
																													goto end_IL_0680;
																												case 93:
																													goto end_IL_0690;
																												case 20:
																												case 64:
																													goto end_IL_06a0;
																												case 102:
																													goto end_IL_06b0;
																												case 103:
																													goto end_IL_06c0;
																												case 5:
																												case 101:
																													goto IL_06e4;
																												}
																												continue;
																											}
																											if (9 > b)
																											{
																												goto end_IL_01f4;
																											}
																											goto IL_0362;
																											IL_0362:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											goto end_IL_0264;
																											continue;
																											end_IL_01e1:
																											break;
																										}
																										goto IL_0217;
																										continue;
																										end_IL_01f4:
																										break;
																										IL_01f4:;
																									}
																									break;
																								}
																								goto IL_037e;
																								IL_03e0:
																								num6--;
																								goto end_IL_0264;
																								IL_037e:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_038c;
																								IL_038c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_03cc;
																								IL_03cc:
																								array[num6 - 2] = 0;
																								goto IL_03e0;
																							}
																							break;
																						}
																						goto IL_026f;
																						IL_0311:
																						ptr2 += 8;
																						goto end_IL_0264;
																						IL_026f:
																						if (7 > b)
																						{
																							goto IL_027a;
																						}
																						goto IL_0298;
																						IL_027a:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_0288;
																						IL_0288:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_02c1;
																						IL_02c1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0324;
																						IL_0324:
																						array[num6 - 2] = 0;
																						num = 45;
																						goto IL_0341;
																						IL_0341:
																						num6--;
																						goto end_IL_0264;
																						IL_0298:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_02b1;
																						IL_02b1:
																						array[num6] = 0;
																						goto IL_0303;
																						IL_0303:
																						num6++;
																						goto IL_0311;
																					}
																					break;
																				}
																				goto IL_03f3;
																				IL_05c8:
																				num6--;
																				goto end_IL_0264;
																				IL_03f3:
																				if (5 <= b)
																				{
																					goto IL_03fe;
																				}
																				goto IL_045a;
																				IL_03fe:
																				array[num6] = 0;
																				goto IL_040c;
																				IL_040c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_042f;
																				IL_042f:
																				array2[num6] = null;
																				goto IL_0439;
																				IL_0439:
																				num6++;
																				goto IL_0447;
																				IL_0447:
																				ptr2 += 8;
																				goto end_IL_0264;
																				IL_045a:
																				if (2 < b)
																				{
																					goto IL_0468;
																				}
																				goto IL_0551;
																				IL_0468:
																				if (3 < b)
																				{
																					goto IL_0476;
																				}
																				goto IL_04f9;
																				IL_0476:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0484;
																				IL_0484:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0492;
																				IL_0492:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04d2;
																				IL_04d2:
																				array[num6 - 2] = 0;
																				goto IL_04e6;
																				IL_04e6:
																				num6--;
																				goto end_IL_0264;
																				IL_04f9:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0507;
																				IL_0507:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0530;
																				IL_0530:
																				ptr2 += 8;
																				goto IL_053e;
																				IL_053e:
																				num6--;
																				goto end_IL_0264;
																				IL_0551:
																				if (2 > b)
																				{
																					goto IL_055c;
																				}
																				goto IL_0574;
																				IL_055c:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0567;
																				IL_0567:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0574:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_05b4;
																				IL_05b4:
																				array[num6 - 2] = 0;
																				goto IL_05c8;
																			}
																			break;
																			IL_0234:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05fb;
																	IL_0617:
																	ptr2 += 8;
																	goto end_IL_0264;
																	IL_0609:
																	num6++;
																	goto IL_0617;
																	IL_05fb:
																	array[num6] = 0;
																	goto IL_0609;
																	continue;
																	end_IL_0244:
																	break;
																}
																continue;
																end_IL_0254:
																break;
															}
															continue;
															end_IL_0264:
															break;
														}
														continue;
													}
													num = 101;
													goto IL_06e4;
													IL_06e4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0625:
													break;
												}
												continue;
												end_IL_0638:
												break;
											}
											continue;
											end_IL_064b:
											break;
										}
										continue;
										end_IL_0656:
										break;
									}
									continue;
									end_IL_066b:
									break;
								}
								continue;
								end_IL_0680:
								break;
							}
							continue;
							end_IL_0690:
							break;
						}
						continue;
						end_IL_06a0:
						break;
					}
					continue;
					end_IL_06b0:
					break;
				}
				continue;
				end_IL_06c0:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 43;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 4;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SubLdelemR.NormalizationFormrangeManager);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_027d:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0260:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0253:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0243:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0233:
																									if (7 >= b)
																									{
																										while (true)
																										{
																											IL_0220:
																											if (7 > b)
																											{
																												num = 124;
																												while (num != 124 && num == 1105)
																												{
																													switch (num)
																													{
																													case 29:
																														goto IL_0220;
																													case 46:
																													case 61:
																														goto IL_0233;
																													case 15:
																														goto IL_0243;
																													case 50:
																														goto IL_0253;
																													case 113:
																														goto IL_0260;
																													case 96:
																														goto IL_026d;
																													case 5:
																														goto IL_027d;
																													case 88:
																														goto end_IL_027d;
																													case 22:
																													case 72:
																														goto end_IL_028d;
																													case 49:
																													case 64:
																														goto IL_02a8;
																													case 6:
																														goto IL_02b6;
																													case 66:
																														goto IL_02c9;
																													case 40:
																													case 44:
																														goto IL_02d4;
																													case 2:
																													case 81:
																														goto IL_0316;
																													case 36:
																													case 68:
																														goto IL_0321;
																													case 51:
																														goto IL_032e;
																													case 85:
																														goto IL_0341;
																													case 94:
																														goto IL_0354;
																													case 28:
																														goto IL_0368;
																													case 99:
																														goto IL_0384;
																													case 90:
																														goto IL_0392;
																													case 34:
																													case 56:
																														goto IL_03a0;
																													case 86:
																														goto IL_03ae;
																													case 67:
																														goto IL_03d1;
																													case 30:
																														goto IL_03db;
																													case 0:
																														goto IL_03e9;
																													case 47:
																													case 100:
																														goto IL_03fc;
																													case 97:
																														goto IL_043c;
																													case 71:
																														goto IL_0450;
																													case 102:
																													case 103:
																														goto IL_0463;
																													case 93:
																														goto IL_046e;
																													case 11:
																													case 32:
																														goto IL_047c;
																													case 60:
																														goto IL_0495;
																													case 95:
																														goto IL_04a3;
																													case 59:
																														goto IL_04b1;
																													case 23:
																													case 104:
																														goto IL_04c4;
																													case 53:
																													case 111:
																														goto IL_04dc;
																													case 27:
																														goto IL_04ea;
																													case 25:
																													case 45:
																														goto IL_04f8;
																													case 87:
																														goto IL_0521;
																													case 39:
																														goto IL_052f;
																													case 14:
																													case 112:
																														goto IL_0542;
																													case 82:
																													case 115:
																														goto IL_055e;
																													case 63:
																														goto IL_056c;
																													case 89:
																														goto IL_057f;
																													case 92:
																														goto IL_058d;
																													case 7:
																													case 26:
																														goto IL_059b;
																													case 52:
																														goto IL_05be;
																													case 79:
																														goto IL_05cc;
																													case 110:
																														goto IL_05e3;
																													case 18:
																													case 78:
																														goto IL_05f6;
																													case 65:
																														goto IL_0658;
																													case 1:
																													case 8:
																													case 9:
																													case 10:
																													case 12:
																													case 16:
																													case 17:
																													case 21:
																													case 35:
																													case 37:
																													case 54:
																													case 62:
																													case 69:
																													case 73:
																													case 75:
																													case 83:
																													case 91:
																													case 98:
																													case 106:
																													case 107:
																													case 109:
																													case 114:
																														goto end_IL_020d;
																													case 3:
																													case 13:
																													case 24:
																													case 31:
																													case 57:
																													case 58:
																													case 76:
																													case 77:
																													case 84:
																													case 101:
																													case 105:
																													case 108:
																													case 116:
																													case 117:
																														goto end_IL_029d;
																													case 33:
																														goto end_IL_068d;
																													case 19:
																														goto end_IL_06a0;
																													case 74:
																														goto end_IL_06aa;
																													case 4:
																														goto end_IL_06b5;
																													case 48:
																													case 80:
																														goto end_IL_06ca;
																													case 70:
																														goto end_IL_06da;
																													case 41:
																													case 55:
																														goto end_IL_06f3;
																													case 42:
																														goto end_IL_0703;
																													case 43:
																														goto end_IL_0713;
																													case 20:
																													case 38:
																														goto IL_072e;
																													}
																													continue;
																													end_IL_020d:
																													break;
																												}
																												break;
																											}
																											goto IL_03fc;
																											IL_043c:
																											array[num5 - 2] = 0;
																											goto IL_0450;
																											IL_0450:
																											num5--;
																											goto end_IL_029d;
																											IL_03fc:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_043c;
																										}
																										break;
																									}
																									goto IL_057f;
																									IL_05e3:
																									ptr2 += 8;
																									goto end_IL_029d;
																									IL_057f:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_058d;
																									IL_058d:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_059b;
																									IL_059b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_05be;
																									IL_05be:
																									array[num5] = 0;
																									goto IL_05cc;
																									IL_05cc:
																									num5++;
																									num = 110;
																									goto IL_05e3;
																								}
																								break;
																							}
																							goto IL_05f6;
																							IL_0658:
																							num5 -= 2;
																							goto end_IL_029d;
																							IL_05f6:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0658;
																						}
																						break;
																					}
																					goto IL_02a8;
																					IL_056c:
																					if (11 > b)
																					{
																					}
																					break;
																					IL_02a8:
																					if (10 >= b)
																					{
																						goto IL_02b6;
																					}
																					goto IL_055e;
																					IL_02b6:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0542;
																					IL_0542:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_029d;
																					IL_055e:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_056c;
																				}
																				break;
																			}
																			goto IL_02c9;
																			IL_04c4:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_029d;
																			IL_02c9:
																			if (6 <= b)
																			{
																				goto IL_02d4;
																			}
																			goto IL_0316;
																			IL_02d4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0354;
																			IL_0354:
																			array[num5 - 2] = 0;
																			goto IL_0368;
																			IL_0368:
																			num5--;
																			num = 31;
																			goto end_IL_029d;
																			IL_0316:
																			if (3 < b)
																			{
																				goto IL_0321;
																			}
																			goto IL_032e;
																			IL_0321:
																			if (4 >= b)
																			{
																				goto IL_0341;
																			}
																			goto IL_0384;
																			IL_0341:
																			if (4 <= b)
																			{
																				goto end_IL_029d;
																			}
																			break;
																			IL_0384:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0392;
																			IL_0392:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_03a0;
																			IL_03a0:
																			array[num5] = 0;
																			goto IL_03ae;
																			IL_03ae:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03d1;
																			IL_03d1:
																			array2[num5] = null;
																			goto IL_03db;
																			IL_03db:
																			num5++;
																			goto IL_03e9;
																			IL_03e9:
																			ptr2 += 8;
																			goto end_IL_029d;
																			IL_032e:
																			if (3 > b)
																			{
																				goto IL_0463;
																			}
																			goto IL_04c4;
																			IL_0463:
																			if (1 >= b)
																			{
																				goto IL_046e;
																			}
																			goto IL_04dc;
																			IL_046e:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_047c;
																			IL_047c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0495;
																			IL_0495:
																			array[num5] = 0;
																			goto IL_04a3;
																			IL_04a3:
																			num5++;
																			goto IL_04b1;
																			IL_04b1:
																			ptr2 += 8;
																			goto end_IL_029d;
																			IL_04dc:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04ea;
																			IL_04ea:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_04f8;
																			IL_04f8:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0521;
																			IL_0521:
																			ptr2 += 8;
																			goto IL_052f;
																			IL_052f:
																			num5--;
																			goto end_IL_029d;
																		}
																		break;
																		IL_026d:;
																	}
																}
																else
																{
																	num = 21;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 57;
																goto end_IL_029d;
																continue;
																end_IL_027d:
																break;
															}
															continue;
															end_IL_028d:
															break;
														}
														continue;
														end_IL_029d:
														break;
													}
													continue;
												}
												goto IL_072e;
												IL_072e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068d:
												break;
											}
											continue;
											end_IL_06a0:
											break;
										}
										continue;
										end_IL_06aa:
										break;
									}
									continue;
									end_IL_06b5:
									break;
								}
								continue;
								end_IL_06ca:
								break;
							}
							continue;
							end_IL_06da:
							break;
						}
						continue;
						end_IL_06f3:
						break;
					}
					continue;
					end_IL_0703:
					break;
				}
				continue;
				end_IL_0713:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 126;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref varkindProcessMessageFinish.setSponsorshipTimeoutReflectionOnlyLoadFrom);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 16;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_033b:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_031b:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_030b:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02fe:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02f1:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_02e1:
																												if (6 > b)
																												{
																													while (5 >= b)
																													{
																														while (5 <= b)
																														{
																															while (true)
																															{
																																IL_02b1:
																																array[num5] = 5;
																																while (true)
																																{
																																	IL_0297:
																																	array2[num5] = array5[*(int*)(ptr2 + num3)];
																																	while (true)
																																	{
																																		IL_027e:
																																		num5++;
																																		num = 151;
																																		while (true)
																																		{
																																			if (num != 151)
																																			{
																																				if (num != 1132)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 22:
																																					goto IL_027e;
																																				case 14:
																																					goto IL_0297;
																																				case 77:
																																				case 89:
																																					goto IL_02b1;
																																				case 56:
																																					goto IL_02c1;
																																				case 66:
																																					goto IL_02d1;
																																				case 127:
																																					goto IL_02e1;
																																				case 108:
																																				case 142:
																																					goto IL_02f1;
																																				case 30:
																																					goto IL_02fe;
																																				case 25:
																																					goto IL_030b;
																																				case 88:
																																					goto IL_031b;
																																				case 119:
																																					goto IL_032b;
																																				case 109:
																																					goto IL_033b;
																																				case 28:
																																					goto end_IL_033b;
																																				case 43:
																																				case 82:
																																					goto end_IL_034b;
																																				case 3:
																																				case 23:
																																					goto IL_0366;
																																				case 46:
																																					goto IL_0376;
																																				case 69:
																																					goto IL_0386;
																																				case 9:
																																				case 27:
																																					goto IL_0394;
																																				case 102:
																																					goto IL_03bd;
																																				case 51:
																																				case 120:
																																					goto IL_03d0;
																																				case 124:
																																					goto IL_03ee;
																																				case 70:
																																					goto IL_03fc;
																																				case 33:
																																				case 137:
																																					goto IL_040f;
																																				case 4:
																																					goto IL_041d;
																																				case 85:
																																				case 98:
																																					goto IL_0428;
																																				case 128:
																																					goto IL_0468;
																																				case 37:
																																					goto IL_047c;
																																				case 80:
																																					goto IL_048f;
																																				case 103:
																																					goto IL_049d;
																																				case 20:
																																				case 131:
																																					goto IL_04ab;
																																				case 97:
																																					goto IL_04c4;
																																				case 79:
																																					goto IL_04d2;
																																				case 50:
																																					goto IL_04e0;
																																				case 2:
																																					goto IL_04f3;
																																				case 63:
																																					goto IL_0501;
																																				case 0:
																																				case 76:
																																					goto IL_050f;
																																				case 86:
																																					goto IL_0538;
																																				case 141:
																																					goto IL_0551;
																																				case 41:
																																				case 144:
																																					goto IL_0564;
																																				case 139:
																																					goto IL_05a3;
																																				case 83:
																																				case 96:
																																					goto IL_05c9;
																																				case 135:
																																					goto IL_05e1;
																																				case 118:
																																					goto IL_05ef;
																																				case 10:
																																				case 84:
																																					goto IL_05fa;
																																				case 57:
																																					goto IL_063a;
																																				case 116:
																																					goto IL_064e;
																																				case 99:
																																					goto IL_0661;
																																				case 32:
																																					goto IL_066f;
																																				case 24:
																																				case 132:
																																					goto IL_067a;
																																				case 100:
																																					goto IL_0688;
																																				case 114:
																																					goto IL_06ab;
																																				case 19:
																																					goto IL_06b5;
																																				case 73:
																																					goto IL_06c3;
																																				case 55:
																																				case 62:
																																					goto IL_06df;
																																				case 134:
																																					goto IL_06ed;
																																				case 13:
																																					goto IL_0709;
																																				case 29:
																																					goto IL_0717;
																																				case 52:
																																				case 60:
																																					goto end_IL_026b;
																																				case 45:
																																					goto IL_0769;
																																				case 129:
																																					goto IL_077d;
																																				case 122:
																																					goto IL_0790;
																																				case 71:
																																				case 133:
																																					goto IL_079b;
																																				case 61:
																																					goto IL_07a9;
																																				case 35:
																																					goto IL_07bc;
																																				case 12:
																																				case 95:
																																					goto IL_07ca;
																																				case 11:
																																					goto IL_07d8;
																																				case 81:
																																				case 140:
																																					goto IL_07e6;
																																				case 18:
																																					goto IL_0848;
																																				case 72:
																																				case 110:
																																					goto IL_0858;
																																				case 1:
																																				case 5:
																																				case 21:
																																				case 26:
																																				case 31:
																																				case 34:
																																				case 36:
																																				case 38:
																																				case 39:
																																				case 40:
																																				case 44:
																																				case 53:
																																				case 54:
																																				case 58:
																																				case 64:
																																				case 74:
																																				case 75:
																																				case 91:
																																				case 92:
																																				case 94:
																																				case 104:
																																				case 105:
																																				case 112:
																																				case 121:
																																				case 130:
																																					goto end_IL_02c1;
																																				case 8:
																																				case 16:
																																				case 17:
																																				case 42:
																																				case 47:
																																				case 48:
																																				case 49:
																																				case 59:
																																				case 87:
																																				case 90:
																																				case 93:
																																				case 107:
																																				case 111:
																																				case 115:
																																				case 136:
																																				case 138:
																																				case 143:
																																					goto end_IL_035b;
																																				case 67:
																																					goto end_IL_0884;
																																				case 101:
																																					goto end_IL_0897;
																																				case 106:
																																					goto end_IL_08a2;
																																				case 15:
																																					goto end_IL_08ac;
																																				case 65:
																																					goto end_IL_08b7;
																																				case 68:
																																				case 123:
																																					goto end_IL_08c7;
																																				case 7:
																																					goto end_IL_08d7;
																																				case 78:
																																				case 113:
																																					goto end_IL_08e7;
																																				case 125:
																																					goto end_IL_08f7;
																																				case 126:
																																					goto end_IL_0907;
																																				case 6:
																																				case 117:
																																					goto IL_0922;
																																				}
																																				continue;
																																			}
																																			ptr2 += 8;
																																			goto end_IL_035b;
																																			continue;
																																			end_IL_026b:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_0725;
																															continue;
																															end_IL_02c1:
																															break;
																															IL_02c1:;
																														}
																														break;
																														IL_02d1:;
																													}
																													break;
																												}
																												goto IL_0564;
																												IL_05a3:
																												num5 -= 3;
																												goto end_IL_035b;
																												IL_0564:
																												((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_05a3;
																											}
																											break;
																										}
																										goto IL_0366;
																										IL_0551:
																										num5--;
																										goto end_IL_035b;
																										IL_0366:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0386;
																										IL_0386:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0394;
																										IL_0394:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03bd;
																										IL_03bd:
																										ptr2 += 8;
																										goto IL_0551;
																									}
																									break;
																								}
																								goto IL_0376;
																								IL_0538:
																								array[num5 - 1] = 5;
																								goto end_IL_035b;
																								IL_0376:
																								if (4 <= b)
																								{
																									goto IL_03d0;
																								}
																								goto IL_040f;
																								IL_03d0:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_03ee;
																								IL_03ee:
																								ptr2 += 8;
																								goto IL_03fc;
																								IL_03fc:
																								num5--;
																								goto end_IL_035b;
																								IL_040f:
																								if (2 >= b)
																								{
																									goto IL_041d;
																								}
																								goto IL_04f3;
																								IL_041d:
																								if (2 <= b)
																								{
																									goto IL_0428;
																								}
																								goto IL_048f;
																								IL_0428:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0468;
																								IL_0468:
																								array[num5 - 2] = 0;
																								goto IL_047c;
																								IL_047c:
																								num5--;
																								goto end_IL_035b;
																								IL_048f:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_049d;
																								IL_049d:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_04ab;
																								IL_04ab:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_04c4;
																								IL_04c4:
																								array[num5] = 0;
																								goto IL_04d2;
																								IL_04d2:
																								num5++;
																								goto IL_04e0;
																								IL_04e0:
																								ptr2 += 8;
																								goto end_IL_035b;
																								IL_04f3:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0501;
																								IL_0501:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_050f;
																								IL_050f:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_0538;
																							}
																							break;
																						}
																						goto IL_05c9;
																						IL_05c9:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_035b;
																					}
																					break;
																				}
																				goto IL_05e1;
																				IL_07e6:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0848;
																				IL_05e1:
																				if (12 >= b)
																				{
																					goto IL_05ef;
																				}
																				goto IL_0790;
																				IL_05ef:
																				if (12 <= b)
																				{
																					goto IL_05fa;
																				}
																				goto IL_0661;
																				IL_05fa:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_063a;
																				IL_063a:
																				array[num5 - 2] = 0;
																				goto IL_064e;
																				IL_064e:
																				num5--;
																				goto end_IL_035b;
																				IL_0661:
																				if (10 >= b)
																				{
																					goto IL_066f;
																				}
																				goto IL_0709;
																				IL_066f:
																				if (10 <= b)
																				{
																					goto IL_067a;
																				}
																				num = 62;
																				goto IL_06df;
																				IL_067a:
																				array[num5] = 0;
																				goto IL_0688;
																				IL_0688:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_06ab;
																				IL_06ab:
																				array2[num5] = null;
																				goto IL_06b5;
																				IL_06b5:
																				num5++;
																				goto IL_06c3;
																				IL_06c3:
																				ptr2 += 8;
																				goto end_IL_035b;
																				IL_0848:
																				num5 -= 2;
																				goto end_IL_035b;
																				IL_06df:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_06ed;
																				IL_06ed:
																				if (9 <= b)
																				{
																					goto end_IL_035b;
																				}
																				num = 5;
																				break;
																				IL_0858:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_035b;
																				IL_0709:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0717;
																				IL_0717:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0725;
																				IL_0725:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0769;
																				IL_0769:
																				array[num5 - 2] = 0;
																				goto IL_077d;
																				IL_077d:
																				num5--;
																				goto end_IL_035b;
																				IL_0790:
																				if (14 < b)
																				{
																					goto IL_079b;
																				}
																				goto IL_07bc;
																				IL_079b:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_07a9;
																				IL_07a9:
																				if (15 > b)
																				{
																				}
																				break;
																				IL_07bc:
																				if (14 > b)
																				{
																					goto IL_07ca;
																				}
																				goto IL_0858;
																				IL_07ca:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_07d8;
																				IL_07d8:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_07e6;
																			}
																			break;
																			IL_032b:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_035b;
																	continue;
																	end_IL_033b:
																	break;
																}
																continue;
																end_IL_034b:
																break;
															}
															continue;
															end_IL_035b:
															break;
														}
														continue;
													}
													goto IL_0922;
													IL_0922:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0884:
													break;
												}
												continue;
												end_IL_0897:
												break;
											}
											continue;
											end_IL_08a2:
											break;
										}
										continue;
										end_IL_08ac:
										break;
									}
									continue;
									end_IL_08b7:
									break;
								}
								continue;
								end_IL_08c7:
								break;
							}
							continue;
							end_IL_08d7:
							break;
						}
						continue;
						end_IL_08e7:
						break;
					}
					continue;
					end_IL_08f7:
					break;
				}
				continue;
				end_IL_0907:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 73;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PrefixCodeGetEncoder.GetResourceDatagetDefaultIcon);
											num = 32;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0225:
															byte b = *ptr2;
															while (true)
															{
																IL_0215:
																ptr2++;
																while (true)
																{
																	IL_0205:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e5:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01d8:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01cb:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01bb:
																										if (2 > b)
																										{
																											while (true)
																											{
																												IL_01a8:
																												if (1 < b)
																												{
																													num = 94;
																													while (num != 94)
																													{
																														if (num != 1075)
																														{
																															goto end_IL_0205;
																														}
																														switch (num)
																														{
																														case 38:
																														case 42:
																															goto IL_01a8;
																														case 0:
																															goto IL_01bb;
																														case 44:
																															goto IL_01cb;
																														case 56:
																															goto IL_01d8;
																														case 30:
																															goto IL_01e5;
																														case 40:
																															goto IL_01f5;
																														case 52:
																															goto IL_0205;
																														case 50:
																															goto IL_0215;
																														case 64:
																														case 82:
																															goto IL_0225;
																														case 25:
																														case 58:
																															goto IL_0230;
																														case 29:
																															goto IL_023e;
																														case 22:
																														case 60:
																															goto IL_024e;
																														case 21:
																															goto IL_0277;
																														case 33:
																															goto IL_0285;
																														case 39:
																														case 86:
																															goto IL_0298;
																														case 69:
																															goto IL_02d8;
																														case 45:
																															goto IL_02ec;
																														case 57:
																															goto IL_02ff;
																														case 26:
																														case 80:
																															goto IL_0312;
																														case 85:
																															goto IL_0380;
																														case 11:
																															goto IL_0393;
																														case 20:
																															goto IL_039e;
																														case 78:
																															goto IL_03ac;
																														case 53:
																															goto IL_03ba;
																														case 16:
																														case 75:
																															goto IL_03c8;
																														case 67:
																														case 71:
																															goto IL_03e0;
																														case 68:
																															goto IL_03eb;
																														case 6:
																														case 66:
																															goto IL_03f9;
																														case 36:
																															goto IL_0407;
																														case 10:
																															goto IL_0433;
																														case 23:
																															goto IL_043d;
																														case 87:
																															goto IL_044b;
																														case 35:
																															goto IL_045e;
																														case 2:
																															goto IL_0472;
																														case 77:
																														case 84:
																															goto IL_047d;
																														case 4:
																														case 7:
																														case 9:
																														case 13:
																														case 14:
																														case 15:
																														case 24:
																														case 27:
																														case 48:
																														case 49:
																														case 51:
																														case 59:
																														case 62:
																														case 70:
																														case 83:
																															goto end_IL_0195;
																														case 1:
																															goto IL_04b9;
																														case 31:
																															goto IL_04c7;
																														case 55:
																															goto IL_04d5;
																														case 3:
																														case 8:
																														case 12:
																														case 17:
																														case 28:
																														case 43:
																														case 46:
																														case 63:
																														case 65:
																														case 72:
																														case 76:
																															goto end_IL_0205;
																														case 32:
																															goto end_IL_04e3;
																														case 41:
																															goto end_IL_04f6;
																														case 47:
																															goto end_IL_0500;
																														case 37:
																															goto end_IL_0514;
																														case 18:
																															goto end_IL_0529;
																														case 5:
																														case 79:
																															goto end_IL_053e;
																														case 34:
																															goto end_IL_054e;
																														case 19:
																														case 81:
																															goto end_IL_055e;
																														case 73:
																															goto end_IL_056e;
																														case 74:
																															goto end_IL_057e;
																														case 54:
																														case 61:
																															goto IL_05a2;
																														}
																														continue;
																														end_IL_0195:
																														break;
																													}
																													break;
																												}
																												goto IL_02ff;
																												IL_02ff:
																												if (1 <= b)
																												{
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_0312;
																										IL_0380:
																										num5 -= 2;
																										goto end_IL_0205;
																										IL_0312:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0380;
																									}
																									break;
																								}
																								goto IL_0230;
																								IL_02ec:
																								num5--;
																								goto end_IL_0205;
																								IL_0230:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_023e;
																								IL_023e:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0298;
																								IL_0298:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02d8;
																								IL_02d8:
																								array[num5 - 2] = 0;
																								goto IL_02ec;
																							}
																							break;
																						}
																						goto IL_024e;
																						IL_0285:
																						num5--;
																						goto end_IL_0205;
																						IL_024e:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0277;
																						IL_0277:
																						ptr2 += 8;
																						goto IL_0285;
																					}
																					break;
																				}
																				goto IL_0393;
																				IL_0472:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_047d;
																				IL_0393:
																				if (6 >= b)
																				{
																					goto IL_039e;
																				}
																				goto IL_03e0;
																				IL_039e:
																				if (6 <= b)
																				{
																					goto end_IL_0205;
																				}
																				goto IL_03ac;
																				IL_03ac:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_03ba;
																				IL_03ba:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_03c8;
																				IL_03c8:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0205;
																				IL_03e0:
																				if (7 >= b)
																				{
																					goto IL_03eb;
																				}
																				goto IL_045e;
																				IL_03eb:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_03f9;
																				IL_03f9:
																				array[num5] = 0;
																				goto IL_0407;
																				IL_0407:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 10;
																				goto IL_0433;
																				IL_0433:
																				array2[num5] = null;
																				goto IL_043d;
																				IL_043d:
																				num5++;
																				goto IL_044b;
																				IL_044b:
																				ptr2 += 8;
																				goto end_IL_0205;
																				IL_045e:
																				if (8 < b)
																				{
																					break;
																				}
																				num = 2;
																				goto IL_0472;
																				IL_047d:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0205;
																			}
																			break;
																			IL_01f5:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04b9;
																	IL_04d5:
																	ptr2 += 8;
																	break;
																	IL_04c7:
																	num5++;
																	goto IL_04d5;
																	IL_04b9:
																	array[num5] = 0;
																	goto IL_04c7;
																	continue;
																	end_IL_0205:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a2;
													IL_05a2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04e3:
													break;
												}
												continue;
												end_IL_04f6:
												break;
											}
											continue;
											end_IL_0500:
											break;
										}
										continue;
										end_IL_0514:
										break;
									}
									continue;
									end_IL_0529:
									break;
								}
								continue;
								end_IL_053e:
								break;
							}
							continue;
							end_IL_054e:
							break;
						}
						continue;
						end_IL_055e:
						break;
					}
					continue;
					end_IL_056e:
					break;
				}
				continue;
				end_IL_057e:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getTraceLevelLeaseManager.PermissionSetEnumeratorsetSkipVerificationInFullTrust);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0259:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0239:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0229:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_021c:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_020c:
																									if (4 < b)
																									{
																										num = 119;
																										while (true)
																										{
																											if (num != 119)
																											{
																												if (num != 1100)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 56:
																													goto IL_020c;
																												case 110:
																													goto IL_021c;
																												case 97:
																													goto IL_0229;
																												case 4:
																													goto IL_0239;
																												case 26:
																													goto IL_0249;
																												case 21:
																													goto IL_0259;
																												case 65:
																													goto end_IL_0259;
																												case 68:
																												case 83:
																													goto end_IL_0269;
																												case 87:
																													goto IL_0284;
																												case 101:
																													goto IL_0297;
																												case 79:
																												case 82:
																													goto IL_02a5;
																												case 11:
																												case 81:
																													goto IL_02b0;
																												case 63:
																													goto IL_02be;
																												case 16:
																												case 72:
																													goto IL_02d5;
																												case 31:
																													goto IL_0307;
																												case 80:
																													goto IL_0315;
																												case 53:
																													goto IL_0328;
																												case 29:
																												case 77:
																													goto IL_0336;
																												case 88:
																													goto IL_0358;
																												case 78:
																													goto IL_036f;
																												case 40:
																													goto IL_037d;
																												case 3:
																												case 76:
																													goto IL_0399;
																												case 93:
																												case 105:
																													goto IL_03b1;
																												case 50:
																													goto IL_03f1;
																												case 39:
																													goto IL_0405;
																												case 47:
																													goto IL_0418;
																												case 89:
																													goto IL_0426;
																												case 48:
																												case 52:
																													goto IL_0434;
																												case 90:
																													goto IL_0442;
																												case 49:
																													goto IL_0465;
																												case 22:
																													goto IL_046f;
																												case 71:
																													goto IL_047d;
																												case 58:
																													goto IL_0490;
																												case 13:
																												case 67:
																													goto IL_049b;
																												case 34:
																													goto IL_04a6;
																												case 98:
																												case 102:
																													goto IL_04b4;
																												case 55:
																													goto IL_04d0;
																												case 66:
																													goto IL_04de;
																												case 70:
																													goto IL_04f1;
																												case 32:
																												case 103:
																													goto IL_04ff;
																												case 94:
																												case 99:
																													goto IL_050a;
																												case 64:
																													goto IL_0521;
																												case 45:
																												case 85:
																													goto IL_052f;
																												case 109:
																													goto IL_0552;
																												case 7:
																													goto IL_0560;
																												case 19:
																													goto IL_056e;
																												case 6:
																													goto IL_0581;
																												case 2:
																												case 104:
																													goto IL_058f;
																												case 111:
																													goto IL_05cf;
																												case 37:
																													goto IL_05e3;
																												case 69:
																												case 100:
																													goto IL_05f6;
																												case 86:
																													goto IL_0658;
																												case 0:
																												case 1:
																												case 8:
																												case 9:
																												case 10:
																												case 15:
																												case 17:
																												case 18:
																												case 28:
																												case 33:
																												case 41:
																												case 46:
																												case 54:
																												case 60:
																												case 61:
																												case 62:
																												case 84:
																												case 91:
																												case 106:
																													goto end_IL_01f9;
																												case 5:
																												case 20:
																												case 35:
																												case 38:
																												case 42:
																												case 44:
																												case 51:
																												case 57:
																												case 73:
																												case 92:
																												case 95:
																												case 96:
																												case 107:
																												case 112:
																													goto end_IL_0279;
																												case 59:
																													goto end_IL_067b;
																												case 25:
																													goto end_IL_068e;
																												case 23:
																													goto end_IL_0698;
																												case 12:
																													goto end_IL_06a3;
																												case 36:
																												case 108:
																													goto end_IL_06b8;
																												case 24:
																													goto end_IL_06c8;
																												case 14:
																												case 43:
																													goto end_IL_06d8;
																												case 74:
																													goto end_IL_06e8;
																												case 75:
																													goto end_IL_06f8;
																												case 27:
																												case 30:
																													goto IL_0713;
																												}
																												continue;
																											}
																											goto IL_0418;
																											IL_046f:
																											num5++;
																											goto IL_047d;
																											IL_047d:
																											ptr2 += 8;
																											goto end_IL_0279;
																											IL_0418:
																											if (5 < b)
																											{
																												break;
																											}
																											goto IL_0426;
																											IL_0426:
																											if (5 > b)
																											{
																												break;
																											}
																											goto IL_0434;
																											IL_0434:
																											array[num5] = 0;
																											goto IL_0442;
																											IL_0442:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0465;
																											IL_0465:
																											array2[num5] = null;
																											goto IL_046f;
																											continue;
																											end_IL_01f9:
																											break;
																										}
																										break;
																									}
																									goto IL_0284;
																									IL_0284:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_0279;
																								}
																								break;
																							}
																							goto IL_0297;
																							IL_037d:
																							ptr2 += 8;
																							num = 44;
																							goto end_IL_0279;
																							IL_0297:
																							if (3 > b)
																							{
																								goto IL_02a5;
																							}
																							goto IL_0399;
																							IL_02a5:
																							if (1 < b)
																							{
																								goto IL_02b0;
																							}
																							goto IL_0328;
																							IL_02b0:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_02be;
																							IL_02be:
																							if (2 > b)
																							{
																								break;
																							}
																							num = 16;
																							goto IL_02d5;
																							IL_0399:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0279;
																							IL_02d5:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 31;
																							goto IL_0307;
																							IL_0307:
																							ptr2 += 8;
																							goto IL_0315;
																							IL_0315:
																							num5--;
																							goto end_IL_0279;
																							IL_0328:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0336;
																							IL_0336:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							num = 88;
																							goto IL_0358;
																							IL_0358:
																							array[num5] = 0;
																							num = 78;
																							goto IL_036f;
																							IL_036f:
																							num5++;
																							goto IL_037d;
																						}
																						break;
																					}
																					goto IL_03b1;
																					IL_0405:
																					num5--;
																					goto end_IL_0279;
																					IL_03b1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03f1;
																					IL_03f1:
																					array[num5 - 2] = 0;
																					goto IL_0405;
																				}
																				break;
																			}
																			goto IL_0490;
																			IL_05f6:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0658;
																			IL_0490:
																			if (9 < b)
																			{
																				goto IL_049b;
																			}
																			goto IL_04f1;
																			IL_049b:
																			if (10 >= b)
																			{
																				goto IL_04a6;
																			}
																			goto IL_04d0;
																			IL_04a6:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_04b4;
																			IL_04b4:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0279;
																			IL_04d0:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_04de;
																			IL_04de:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_04f1:
																			if (9 > b)
																			{
																				goto IL_04ff;
																			}
																			goto IL_05f6;
																			IL_04ff:
																			if (7 < b)
																			{
																				goto IL_050a;
																			}
																			goto IL_0581;
																			IL_050a:
																			if (8 < b)
																			{
																				break;
																			}
																			num = 64;
																			goto IL_0521;
																			IL_0658:
																			num5 -= 2;
																			goto end_IL_0279;
																			IL_0521:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_052f;
																			IL_052f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0552;
																			IL_0552:
																			array[num5] = 0;
																			goto IL_0560;
																			IL_0560:
																			num5++;
																			goto IL_056e;
																			IL_056e:
																			ptr2 += 8;
																			goto end_IL_0279;
																			IL_0581:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_058f;
																			IL_058f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05cf;
																			IL_05cf:
																			array[num5 - 2] = 0;
																			goto IL_05e3;
																			IL_05e3:
																			num5--;
																			goto end_IL_0279;
																		}
																		break;
																		IL_0249:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0279;
																continue;
																end_IL_0259:
																break;
															}
															continue;
															end_IL_0269:
															break;
														}
														continue;
														end_IL_0279:
														break;
													}
													continue;
												}
												goto IL_0713;
												IL_0713:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067b:
												break;
											}
											continue;
											end_IL_068e:
											break;
										}
										continue;
										end_IL_0698:
										break;
									}
									continue;
									end_IL_06a3:
									break;
								}
								continue;
								end_IL_06b8:
								break;
							}
							continue;
							end_IL_06c8:
							break;
						}
						continue;
						end_IL_06d8:
						break;
					}
					continue;
					end_IL_06e8:
					break;
				}
				continue;
				end_IL_06f8:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 11;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									num = 94;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CrossAppDomainDataPoprefpopipopi.POLICYTRUSTADMINGetRuntimeEvent);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f2:
														byte b = *ptr2;
														while (true)
														{
															IL_02e2:
															ptr2++;
															while (true)
															{
																IL_02d2:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_02af:
																			if (5 >= b)
																			{
																				num = 30;
																				while (true)
																				{
																					IL_029c:
																					if (5 > b)
																					{
																						num = 32;
																						while (true)
																						{
																							IL_028f:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_027f:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (1 <= b)
																											{
																												while (true)
																												{
																													IL_023b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													num = 9;
																													while (true)
																													{
																														IL_022b:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_021b:
																															num5++;
																															while (true)
																															{
																																IL_0202:
																																ptr2 += 8;
																																num = 113;
																																while (num != 113)
																																{
																																	if (num != 1094)
																																	{
																																		goto end_IL_025f;
																																	}
																																	switch (num)
																																	{
																																	case 35:
																																		goto IL_0202;
																																	case 63:
																																		goto IL_021b;
																																	case 9:
																																		goto IL_022b;
																																	case 58:
																																	case 104:
																																		goto IL_023b;
																																	case 52:
																																		goto IL_025f;
																																	case 31:
																																	case 81:
																																		goto IL_026f;
																																	case 72:
																																		goto IL_027f;
																																	case 32:
																																	case 36:
																																		goto IL_028f;
																																	case 30:
																																		goto IL_029c;
																																	case 21:
																																		goto IL_02af;
																																	case 80:
																																		goto IL_02c2;
																																	case 90:
																																		goto IL_02d2;
																																	case 69:
																																		goto IL_02e2;
																																	case 27:
																																	case 40:
																																		goto IL_02f2;
																																	case 8:
																																	case 67:
																																		goto IL_0306;
																																	case 6:
																																	case 61:
																																		goto IL_0311;
																																	case 41:
																																		goto IL_031f;
																																	case 96:
																																		goto IL_0332;
																																	case 100:
																																		goto IL_0345;
																																	case 29:
																																		goto IL_0350;
																																	case 76:
																																		goto IL_035e;
																																	case 1:
																																	case 43:
																																		goto IL_036c;
																																	case 33:
																																		goto IL_0388;
																																	case 38:
																																	case 51:
																																		goto IL_0396;
																																	case 5:
																																		goto IL_03a1;
																																	case 59:
																																	case 87:
																																		goto IL_03af;
																																	case 64:
																																		goto IL_03ef;
																																	case 47:
																																		goto IL_0403;
																																	case 82:
																																		goto IL_0416;
																																	case 20:
																																		goto IL_0424;
																																	case 14:
																																	case 19:
																																		goto IL_0432;
																																	case 13:
																																		goto IL_0455;
																																	case 48:
																																		goto IL_0463;
																																	case 88:
																																		goto IL_0471;
																																	case 7:
																																	case 57:
																																		goto IL_0484;
																																	case 65:
																																		goto IL_04e6;
																																	case 102:
																																		goto IL_04f9;
																																	case 0:
																																		goto IL_0507;
																																	case 18:
																																	case 106:
																																		goto IL_051a;
																																	case 23:
																																	case 79:
																																		goto IL_0532;
																																	case 103:
																																		goto IL_055b;
																																	case 44:
																																		goto IL_0569;
																																	case 15:
																																	case 75:
																																		goto IL_0582;
																																	case 86:
																																		goto IL_0590;
																																	case 53:
																																		goto IL_05b3;
																																	case 77:
																																		goto IL_05bd;
																																	case 49:
																																		goto IL_05cb;
																																	case 2:
																																	case 4:
																																	case 12:
																																	case 16:
																																	case 17:
																																	case 34:
																																	case 50:
																																	case 54:
																																	case 60:
																																	case 62:
																																	case 66:
																																	case 68:
																																	case 70:
																																	case 73:
																																	case 74:
																																	case 83:
																																	case 85:
																																	case 91:
																																	case 92:
																																	case 93:
																																	case 101:
																																		goto end_IL_025f;
																																	case 3:
																																	case 26:
																																	case 37:
																																	case 39:
																																	case 42:
																																	case 45:
																																	case 55:
																																	case 56:
																																	case 71:
																																	case 84:
																																	case 98:
																																	case 105:
																																		goto end_IL_01ef;
																																	case 89:
																																		goto end_IL_05ee;
																																	case 94:
																																		goto end_IL_0601;
																																	case 25:
																																		goto end_IL_060b;
																																	case 78:
																																		goto end_IL_0616;
																																	case 22:
																																	case 95:
																																		goto end_IL_0634;
																																	case 97:
																																		goto end_IL_0644;
																																	case 28:
																																	case 46:
																																		goto end_IL_0654;
																																	case 10:
																																		goto end_IL_0664;
																																	case 11:
																																		goto end_IL_0674;
																																	case 24:
																																	case 99:
																																		goto IL_068f;
																																	}
																																	continue;
																																	end_IL_01ef:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02d2;
																												continue;
																												end_IL_025f:
																												break;
																												IL_025f:;
																											}
																											break;
																											IL_026f:;
																										}
																										break;
																									}
																									goto IL_0532;
																									IL_0569:
																									num5--;
																									num = 37;
																									goto end_IL_02d2;
																									IL_0532:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_055b;
																									IL_055b:
																									ptr2 += 8;
																									goto IL_0569;
																								}
																								break;
																							}
																							num = 67;
																							goto IL_0306;
																							IL_0332:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_051a;
																							IL_051a:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02d2;
																							IL_0306:
																							if (3 < b)
																							{
																								goto IL_0311;
																							}
																							goto IL_0332;
																							IL_0311:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_031f;
																							IL_031f:
																							if (4 <= b)
																							{
																								goto end_IL_02d2;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0582;
																					IL_05bd:
																					num5++;
																					goto IL_05cb;
																					IL_05cb:
																					ptr2 += 8;
																					goto end_IL_02d2;
																					IL_0582:
																					array[num5] = 0;
																					goto IL_0590;
																					IL_0590:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05b3;
																					IL_05b3:
																					array2[num5] = null;
																					goto IL_05bd;
																				}
																				break;
																			}
																			goto IL_0345;
																			IL_0484:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04e6;
																			IL_04e6:
																			num5 -= 2;
																			goto end_IL_02d2;
																			IL_0345:
																			if (8 < b)
																			{
																				goto IL_0350;
																			}
																			goto IL_0388;
																			IL_0350:
																			if (9 >= b)
																			{
																				goto IL_035e;
																			}
																			goto IL_04f9;
																			IL_035e:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_036c;
																			IL_036c:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02d2;
																			IL_04f9:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0507;
																			IL_0507:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_0388:
																			if (8 > b)
																			{
																				goto IL_0396;
																			}
																			goto IL_0484;
																			IL_0396:
																			if (6 >= b)
																			{
																				goto IL_03a1;
																			}
																			goto IL_0416;
																			IL_03a1:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_03af;
																			IL_03af:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03ef;
																			IL_03ef:
																			array[num5 - 2] = 0;
																			goto IL_0403;
																			IL_0403:
																			num5--;
																			goto end_IL_02d2;
																			IL_0416:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0424;
																			IL_0424:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0432;
																			IL_0432:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0455;
																			IL_0455:
																			array[num5] = 0;
																			goto IL_0463;
																			IL_0463:
																			num5++;
																			goto IL_0471;
																			IL_0471:
																			ptr2 += 8;
																			goto end_IL_02d2;
																		}
																		break;
																		IL_02c2:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d2:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_068f;
												IL_068f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ee:
												break;
											}
											continue;
											end_IL_0601:
											break;
										}
										continue;
										end_IL_060b:
										break;
									}
									continue;
									end_IL_0616:
									break;
								}
								continue;
								end_IL_0634:
								break;
							}
							continue;
							end_IL_0644:
							break;
						}
						continue;
						end_IL_0654:
						break;
					}
					continue;
					end_IL_0664:
					break;
				}
				continue;
				end_IL_0674:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 50;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 87;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MethodCodeTypeenableWorkerTracking.IContributeDynamicSinkSetScopeRange);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_039d:
														num = 16;
														while (true)
														{
															IL_0392:
															byte b = *ptr2;
															while (true)
															{
																IL_0382:
																ptr2++;
																while (true)
																{
																	IL_0372:
																	if (b >= 1)
																	{
																		while (b <= 17)
																		{
																			num = 160;
																			while (true)
																			{
																				IL_034f:
																				if (9 >= b)
																				{
																					while (9 > b)
																					{
																						while (true)
																						{
																							IL_032f:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_0322:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_0302:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											while (true)
																											{
																												IL_02e9:
																												ptr2 += 8;
																												num = 136;
																												while (true)
																												{
																													IL_02d0:
																													num5--;
																													num = 168;
																													while (num != 168)
																													{
																														if (num != 1149)
																														{
																															goto IL_08a1;
																														}
																														switch (num)
																														{
																														case 136:
																															goto IL_02d0;
																														case 23:
																															goto IL_02e9;
																														case 73:
																														case 78:
																															goto IL_0302;
																														case 94:
																															goto IL_0322;
																														case 33:
																															goto IL_032f;
																														case 2:
																															goto IL_033f;
																														case 160:
																															goto IL_034f;
																														case 109:
																															goto IL_035f;
																														case 134:
																															goto IL_0372;
																														case 140:
																															goto IL_0382;
																														case 16:
																															goto IL_0392;
																														case 69:
																															goto IL_039d;
																														case 21:
																														case 51:
																															goto IL_03a8;
																														case 11:
																															goto IL_03b3;
																														case 70:
																														case 103:
																															goto IL_03c1;
																														case 45:
																															goto IL_0401;
																														case 35:
																															goto IL_0415;
																														case 118:
																															goto IL_0428;
																														case 112:
																															goto IL_0436;
																														case 48:
																														case 53:
																															goto IL_0444;
																														case 52:
																															goto IL_046d;
																														case 34:
																														case 141:
																															goto IL_0486;
																														case 12:
																															goto IL_0494;
																														case 56:
																														case 149:
																															goto IL_04b0;
																														case 25:
																														case 114:
																															goto IL_04bb;
																														case 126:
																															goto IL_04c6;
																														case 19:
																															goto IL_04d9;
																														case 58:
																															goto IL_04f0;
																														case 22:
																														case 84:
																															goto IL_04fe;
																														case 86:
																															goto IL_0516;
																														case 27:
																															goto IL_0521;
																														case 32:
																															goto IL_052f;
																														case 3:
																														case 110:
																															goto IL_053d;
																														case 76:
																															goto IL_054b;
																														case 47:
																															goto IL_0563;
																														case 37:
																															goto IL_0571;
																														case 41:
																														case 90:
																															goto IL_0584;
																														case 138:
																															goto IL_05cc;
																														case 147:
																														case 152:
																															goto IL_05df;
																														case 83:
																															goto IL_0608;
																														case 139:
																															goto IL_0616;
																														case 131:
																														case 158:
																															goto IL_0629;
																														case 93:
																															goto IL_0642;
																														case 98:
																															goto IL_0650;
																														case 132:
																															goto IL_065e;
																														case 156:
																															goto IL_0671;
																														case 115:
																															goto IL_067f;
																														case 154:
																														case 155:
																															goto IL_068d;
																														case 75:
																														case 107:
																															goto IL_069b;
																														case 79:
																															goto IL_06a9;
																														case 65:
																														case 77:
																															goto IL_06b7;
																														case 61:
																															goto IL_06f7;
																														case 85:
																															goto IL_070b;
																														case 57:
																															goto IL_071e;
																														case 71:
																															goto IL_072c;
																														case 24:
																															goto IL_073a;
																														case 91:
																														case 133:
																															goto IL_0748;
																														case 105:
																															goto IL_075f;
																														case 67:
																															goto IL_0782;
																														case 30:
																															goto IL_078c;
																														case 102:
																															goto IL_079a;
																														case 113:
																														case 144:
																															goto IL_07ad;
																														case 26:
																															goto IL_07f1;
																														case 13:
																															goto IL_0805;
																														case 17:
																														case 143:
																															goto IL_0821;
																														case 9:
																															goto IL_0883;
																														case 39:
																															goto IL_0896;
																														case 54:
																														case 148:
																															goto IL_08a1;
																														case 36:
																														case 38:
																															goto IL_08ac;
																														case 92:
																															goto IL_08ba;
																														case 137:
																															goto IL_08cd;
																														case 124:
																														case 145:
																															goto IL_08db;
																														case 82:
																															goto IL_08f7;
																														case 101:
																														case 153:
																															goto IL_0905;
																														case 99:
																															goto IL_0913;
																														case 14:
																														case 42:
																															goto IL_0921;
																														case 123:
																															goto IL_0935;
																														case 5:
																															goto IL_0989;
																														case 130:
																															goto IL_0997;
																														case 46:
																														case 63:
																															goto IL_09a7;
																														case 1:
																														case 6:
																														case 10:
																														case 43:
																														case 59:
																														case 66:
																														case 68:
																														case 74:
																														case 80:
																														case 88:
																														case 95:
																														case 96:
																														case 97:
																														case 100:
																														case 108:
																														case 111:
																														case 117:
																														case 120:
																														case 121:
																														case 125:
																														case 127:
																														case 128:
																														case 135:
																														case 146:
																														case 150:
																														case 151:
																															goto end_IL_035f;
																														case 7:
																														case 8:
																														case 18:
																														case 20:
																														case 29:
																														case 31:
																														case 40:
																														case 44:
																														case 55:
																														case 60:
																														case 62:
																														case 72:
																														case 89:
																														case 104:
																														case 116:
																														case 119:
																														case 142:
																														case 159:
																														case 161:
																															goto end_IL_02bd;
																														case 106:
																															goto end_IL_09ca;
																														case 122:
																															goto end_IL_09dd;
																														case 15:
																															goto end_IL_09e7;
																														case 0:
																															goto end_IL_09f2;
																														case 28:
																														case 157:
																															goto end_IL_0a02;
																														case 64:
																															goto end_IL_0a12;
																														case 81:
																														case 87:
																															goto end_IL_0a22;
																														case 49:
																															goto end_IL_0a32;
																														case 50:
																															goto end_IL_0a42;
																														case 4:
																														case 129:
																															goto IL_0a66;
																														}
																														continue;
																														end_IL_02bd:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_03a8;
																									IL_0444:
																									array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_046d;
																									IL_03a8:
																									if (2 >= b)
																									{
																										goto IL_03b3;
																									}
																									goto IL_0428;
																									IL_03b3:
																									if (2 <= b)
																									{
																										goto IL_03c1;
																									}
																									goto IL_0486;
																									IL_03c1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0401;
																									IL_0401:
																									array[num5 - 2] = 0;
																									goto IL_0415;
																									IL_0415:
																									num5--;
																									break;
																									IL_0486:
																									if (1 < b)
																									{
																										goto end_IL_035f;
																									}
																									goto IL_0494;
																									IL_0494:
																									if (1 > b)
																									{
																										goto end_IL_035f;
																									}
																									num = 131;
																									goto IL_0629;
																									IL_046d:
																									array[num5 - 1] = 5;
																									break;
																									IL_0629:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0642;
																									IL_0642:
																									array[num5] = 0;
																									goto IL_0650;
																									IL_0650:
																									num5++;
																									goto IL_065e;
																									IL_065e:
																									ptr2 += 8;
																									break;
																									IL_0428:
																									if (3 < b)
																									{
																										goto end_IL_035f;
																									}
																									goto IL_0436;
																									IL_0436:
																									if (3 > b)
																									{
																										goto end_IL_035f;
																									}
																									goto IL_0444;
																								}
																								break;
																							}
																							goto IL_04b0;
																							IL_0584:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 138;
																							goto IL_05cc;
																							IL_04b0:
																							if (6 < b)
																							{
																								goto IL_04bb;
																							}
																							goto IL_0516;
																							IL_04bb:
																							if (7 >= b)
																							{
																								goto IL_04c6;
																							}
																							goto IL_04d9;
																							IL_04c6:
																							if (7 > b)
																							{
																								goto end_IL_035f;
																							}
																							goto IL_05df;
																							IL_05df:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0608;
																							IL_0608:
																							ptr2 += 8;
																							goto IL_0616;
																							IL_0616:
																							num5--;
																							break;
																							IL_04d9:
																							if (8 < b)
																							{
																								goto end_IL_035f;
																							}
																							num = 58;
																							goto IL_04f0;
																							IL_05cc:
																							num5 -= 3;
																							break;
																							IL_04f0:
																							if (8 > b)
																							{
																								goto end_IL_035f;
																							}
																							goto IL_04fe;
																							IL_04fe:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_0516:
																							if (6 > b)
																							{
																								goto IL_0521;
																							}
																							goto IL_0584;
																							IL_0521:
																							if (5 < b)
																							{
																								goto end_IL_035f;
																							}
																							goto IL_052f;
																							IL_052f:
																							if (5 > b)
																							{
																								goto end_IL_035f;
																							}
																							goto IL_053d;
																							IL_053d:
																							array[num5] = 5;
																							goto IL_054b;
																							IL_054b:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0563;
																							IL_0563:
																							num5++;
																							goto IL_0571;
																							IL_0571:
																							ptr2 += 8;
																							break;
																						}
																						break;
																						IL_033f:;
																					}
																					break;
																				}
																				goto IL_0671;
																				IL_09a7:
																				num5--;
																				break;
																				IL_0671:
																				if (13 >= b)
																				{
																					goto IL_067f;
																				}
																				goto IL_0896;
																				IL_067f:
																				if (13 > b)
																				{
																					goto IL_068d;
																				}
																				goto IL_0821;
																				IL_068d:
																				if (11 < b)
																				{
																					goto IL_069b;
																				}
																				goto IL_071e;
																				IL_069b:
																				if (12 < b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_06a9;
																				IL_06a9:
																				if (12 > b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_06b7;
																				IL_06b7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06f7;
																				IL_06f7:
																				array[num5 - 2] = 0;
																				goto IL_070b;
																				IL_070b:
																				num5--;
																				break;
																				IL_071e:
																				if (11 > b)
																				{
																					goto IL_072c;
																				}
																				goto IL_07ad;
																				IL_072c:
																				if (10 < b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_073a;
																				IL_073a:
																				if (10 > b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_0748;
																				IL_0748:
																				array[num5] = 0;
																				num = 105;
																				goto IL_075f;
																				IL_075f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0782;
																				IL_0782:
																				array2[num5] = null;
																				goto IL_078c;
																				IL_078c:
																				num5++;
																				goto IL_079a;
																				IL_079a:
																				ptr2 += 8;
																				break;
																				IL_07ad:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_07f1;
																				IL_07f1:
																				array[num5 - 2] = 0;
																				goto IL_0805;
																				IL_0805:
																				num5--;
																				num = 119;
																				break;
																				IL_0821:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0883;
																				IL_0883:
																				num5 -= 2;
																				break;
																				IL_0896:
																				if (15 < b)
																				{
																					goto IL_08a1;
																				}
																				goto IL_08f7;
																				IL_08a1:
																				if (16 < b)
																				{
																					goto IL_08ac;
																				}
																				goto IL_08cd;
																				IL_08ac:
																				if (17 < b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_08ba;
																				IL_08ba:
																				if (17 > b)
																				{
																				}
																				goto end_IL_035f;
																				IL_08cd:
																				if (16 > b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_08db;
																				IL_08db:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_08f7:
																				if (15 > b)
																				{
																					goto IL_0905;
																				}
																				goto IL_09a7;
																				IL_0905:
																				if (14 < b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_0913;
																				IL_0913:
																				if (14 > b)
																				{
																					goto end_IL_035f;
																				}
																				goto IL_0921;
																				IL_0921:
																				array[num5 - 2] = 0;
																				goto IL_0935;
																				IL_0935:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)NewPermissionElementMergeLogic[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0989;
																				IL_0989:
																				num5--;
																				goto IL_0997;
																				IL_0997:
																				ptr2 += 8;
																				break;
																			}
																			goto end_IL_0372;
																			continue;
																			end_IL_035f:
																			break;
																			IL_035f:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0372:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a66;
												IL_0a66:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09ca:
												break;
											}
											continue;
											end_IL_09dd:
											break;
										}
										continue;
										end_IL_09e7:
										break;
									}
									continue;
									end_IL_09f2:
									break;
								}
								continue;
								end_IL_0a02:
								break;
							}
							continue;
							end_IL_0a12:
							break;
						}
						continue;
						end_IL_0a22:
						break;
					}
					continue;
					end_IL_0a32:
					break;
				}
				continue;
				end_IL_0a42:
				break;
			}
		}
	}

	static Class16()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 16;
					while (true)
					{
						if (num != 16)
						{
							if (num != 997)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 4:
							case 5:
							case 6:
							case 8:
								goto end_IL_004c;
							case 2:
								goto end_IL_0059;
							case 3:
								goto end_IL_0074;
							case 9:
								goto IL_0083;
							case 7:
								return;
							}
							continue;
						}
						goto IL_0083;
						IL_0083:
						string_0 = "HandTapPointerGun";
						return;
						continue;
						end_IL_004c:
						break;
					}
					continue;
					end_IL_0059:
					break;
				}
				continue;
				end_IL_0074:
				break;
			}
		}
	}

	private static void SoapTypeAttributeInvocationList(Class16 class16_1)
	{
		class16_1.method_1();
	}
}
