using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 10)]
internal struct AppDomainIDGetSurrogateForCyclicalReference
{
	internal static AppDomainIDGetSurrogateForCyclicalReference BneUnSPermitOnly/* Not supported: data(01 00 00 00 00 00 00 00 00 02) */;
}
