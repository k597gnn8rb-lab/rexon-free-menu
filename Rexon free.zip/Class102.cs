using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Platform Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns platforms.", false, 6, ModType.const_0, false)]
internal class Class102 : Class93
{
	private static bool bool_0;

	private static int int_3;

	private static double double_1;

	private static bool bool_1;

	private static float float_0;

	private static IntPtr[] FormKCPm;

	private static IntPtr[] RSAPKCSKeyExchangeFormatterIsNestedPublic;

	private static IntPtr[] ServerSecurityNumLockOn;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_0383, IL_0396, IL_03af, IL_03bf, IL_03df, IL_03ef, IL_03ff, IL_040f, IL_041c, IL_042c, IL_043c, IL_044c, IL_045c, IL_0467, IL_0472, IL_0480, IL_048e, IL_0499, IL_04a4, IL_04b2, IL_04ca, IL_04d8, IL_04e6, IL_04f4, IL_0502, IL_0510, IL_0524, IL_055c, IL_056f, IL_057a, IL_0588, IL_05b1, IL_05ca, IL_05dd, IL_05eb, IL_0629, IL_063c, IL_0658, IL_0676, IL_0684, IL_069c, IL_06ba, IL_06de, IL_06f6, IL_0709, IL_0717, IL_0725, IL_0738, IL_0743, IL_0756, IL_0764, IL_0772, IL_078f, IL_07de, IL_07e8, IL_0815, IL_0829, IL_0840, IL_0853, IL_0861, IL_0882, IL_0890, IL_08a3, IL_08b1, IL_08c5, IL_0919, IL_0930, IL_0943, IL_0951, IL_095f, IL_096d, IL_0978, IL_0986, IL_0999, IL_09a2, IL_09e2, IL_09f6, IL_0a09, IL_0a14, IL_0a22, IL_0a4b, IL_0a59, IL_0a6c, IL_0a77, IL_0a85, IL_0a93, IL_0ab6, IL_0ac0, IL_0ace, IL_0ae1, IL_0aef, IL_0b2f, IL_0b43, IL_0b56, IL_0b64, IL_0b6f, IL_0b82, IL_0b90, IL_0b9e, IL_0ba9, IL_0bb7, IL_0bf7, IL_0c0b, IL_0c1e, IL_0c29, IL_0c37, IL_0c77, IL_0c8b, IL_0c9e, IL_0cac, IL_0cba, IL_0cc8, IL_0d2a, IL_0d3d, IL_0d48, IL_0d91, IL_0da5, IL_0db5, IL_0dce, IL_0de5, IL_0df3, IL_0e01, IL_0e14, IL_0e1e, IL_0e29, IL_0e39, IL_0e49, IL_0e59, IL_0e69, IL_0e79, IL_0e89, IL_0e99, IL_0ea9, IL_0ec4 are reachable both inside and outside the pinned region starting at IL_0ebe. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 206;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				int __rxRef6 = default(int);
				ref int reference = ref __rxRef6;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0ea9:
						num2 = 1;
						while (true)
						{
							IL_0e99:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e89:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e79:
									array2 = new byte[4];
									while (true)
									{
										IL_0e69:
										array3 = new object[4];
										while (true)
										{
											IL_0e59:
											array4 = new int[4];
											while (true)
											{
												IL_0e49:
												array5 = new int[6];
												while (true)
												{
													IL_0e39:
													array6 = new long[4];
													while (true)
													{
														IL_0e29:
														array7 = new object[12];
														while (true)
														{
															IL_0e1e:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MapViewToReadOnlyCollectionAdapterTargetFrameworkId.getTypedValueIReportMatchMembershipCondition);
															while (true)
															{
																IL_0e14:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_045c:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_044c:
																				ptr2++;
																				while (true)
																				{
																					IL_043c:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_041c:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_040f:
																										if (17 >= b)
																										{
																											while (true)
																											{
																												IL_03ff:
																												if (17 > b)
																												{
																													while (true)
																													{
																														IL_03ef:
																														if (14 >= b)
																														{
																															while (true)
																															{
																																IL_03df:
																																if (14 <= b)
																																{
																																	while (true)
																																	{
																																		IL_03bf:
																																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																																		while (true)
																																		{
																																			IL_03af:
																																			ptr2 += 8;
																																			while (true)
																																			{
																																				IL_0396:
																																				num6--;
																																				num = 221;
																																				while (num != 221)
																																				{
																																					if (num != 1202)
																																					{
																																						goto IL_0510;
																																					}
																																					switch (num)
																																					{
																																					case 206:
																																						break;
																																					default:
																																						continue;
																																					case 15:
																																						goto IL_0396;
																																					case 112:
																																						goto IL_03af;
																																					case 119:
																																					case 163:
																																						goto IL_03bf;
																																					case 181:
																																						goto IL_03df;
																																					case 61:
																																						goto IL_03ef;
																																					case 187:
																																						goto IL_03ff;
																																					case 52:
																																					case 178:
																																						goto IL_040f;
																																					case 204:
																																						goto IL_041c;
																																					case 95:
																																						goto IL_042c;
																																					case 194:
																																						goto IL_043c;
																																					case 3:
																																						goto IL_044c;
																																					case 111:
																																					case 164:
																																						goto IL_045c;
																																					case 40:
																																					case 73:
																																						goto IL_0467;
																																					case 96:
																																						goto IL_0472;
																																					case 1:
																																					case 75:
																																						goto IL_0480;
																																					case 138:
																																					case 145:
																																						goto IL_0499;
																																					case 122:
																																						goto IL_04a4;
																																					case 17:
																																					case 132:
																																						goto IL_04b2;
																																					case 10:
																																						goto IL_04ca;
																																					case 136:
																																						goto IL_04d8;
																																					case 153:
																																					case 160:
																																						goto IL_04f4;
																																					case 42:
																																						goto IL_0502;
																																					case 80:
																																					case 87:
																																						goto IL_0510;
																																					case 23:
																																						goto IL_0524;
																																					case 49:
																																						goto IL_055c;
																																					case 154:
																																					case 161:
																																						goto IL_056f;
																																					case 58:
																																						goto IL_057a;
																																					case 92:
																																					case 127:
																																						goto IL_0588;
																																					case 35:
																																						goto IL_05b1;
																																					case 99:
																																						goto IL_05ca;
																																					case 166:
																																						goto IL_05dd;
																																					case 18:
																																					case 177:
																																						goto IL_05eb;
																																					case 77:
																																						goto IL_0629;
																																					case 34:
																																					case 193:
																																						goto IL_063c;
																																					case 54:
																																					case 195:
																																						goto IL_0658;
																																					case 196:
																																						goto IL_0676;
																																					case 16:
																																					case 115:
																																						goto IL_0684;
																																					case 101:
																																						goto IL_069c;
																																					case 125:
																																						goto IL_06ba;
																																					case 82:
																																						goto IL_06de;
																																					case 36:
																																						goto IL_06f6;
																																					case 197:
																																						goto IL_0709;
																																					case 46:
																																						goto IL_0717;
																																					case 11:
																																						goto IL_0725;
																																					case 8:
																																						goto IL_0738;
																																					case 28:
																																						goto IL_0743;
																																					case 173:
																																						goto IL_0756;
																																					case 157:
																																						goto IL_0764;
																																					case 84:
																																					case 185:
																																						goto IL_0772;
																																					case 214:
																																						goto IL_0829;
																																					case 55:
																																						goto IL_0840;
																																					case 27:
																																					case 213:
																																						goto IL_0853;
																																					case 191:
																																						goto IL_0861;
																																					case 144:
																																						goto IL_0882;
																																					case 74:
																																						goto IL_0890;
																																					case 51:
																																						goto IL_08a3;
																																					case 0:
																																					case 66:
																																						goto IL_08b1;
																																					case 44:
																																						goto IL_08c5;
																																					case 155:
																																						goto IL_0919;
																																					case 41:
																																						goto IL_0930;
																																					case 113:
																																						goto IL_0943;
																																					case 32:
																																						goto IL_0951;
																																					case 207:
																																					case 212:
																																						goto IL_095f;
																																					case 146:
																																						goto IL_096d;
																																					case 137:
																																						goto IL_0978;
																																					case 200:
																																						goto IL_0986;
																																					case 124:
																																					case 152:
																																						goto IL_09a2;
																																					case 79:
																																						goto IL_09e2;
																																					case 118:
																																						goto IL_09f6;
																																					case 106:
																																						goto IL_0a09;
																																					case 180:
																																						goto IL_0a14;
																																					case 26:
																																					case 179:
																																						goto IL_0a22;
																																					case 150:
																																						goto IL_0a4b;
																																					case 89:
																																						goto IL_0a59;
																																					case 7:
																																						goto IL_0a6c;
																																					case 56:
																																						goto IL_0a77;
																																					case 53:
																																					case 93:
																																						goto IL_0a85;
																																					case 148:
																																						goto IL_0a93;
																																					case 140:
																																						goto IL_0ab6;
																																					case 14:
																																						goto IL_0ac0;
																																					case 63:
																																						goto IL_0ace;
																																					case 85:
																																					case 90:
																																						goto IL_0aef;
																																					case 97:
																																						goto IL_0b2f;
																																					case 149:
																																						goto IL_0b43;
																																					case 78:
																																						goto IL_0b56;
																																					case 33:
																																						goto IL_0b64;
																																					case 83:
																																					case 139:
																																						goto IL_0b6f;
																																					case 117:
																																						goto IL_0b82;
																																					case 147:
																																					case 201:
																																						goto IL_0b90;
																																					case 120:
																																						goto IL_0b9e;
																																					case 29:
																																					case 184:
																																						goto IL_0bb7;
																																					case 203:
																																						goto IL_0bf7;
																																					case 103:
																																						goto IL_0c0b;
																																					case 156:
																																						goto IL_0c1e;
																																					case 68:
																																					case 159:
																																						goto IL_0c37;
																																					case 211:
																																						goto IL_0c77;
																																					case 123:
																																						goto IL_0c8b;
																																					case 50:
																																						goto IL_0c9e;
																																					case 182:
																																					case 186:
																																						goto IL_0cac;
																																					case 13:
																																						goto IL_0cba;
																																					case 24:
																																					case 69:
																																						goto IL_0cc8;
																																					case 19:
																																						goto IL_0d2a;
																																					case 48:
																																						goto IL_0d3d;
																																					case 59:
																																					case 126:
																																						goto IL_0d48;
																																					case 172:
																																						goto IL_0d91;
																																					case 9:
																																						goto IL_0da5;
																																					case 5:
																																					case 6:
																																					case 12:
																																					case 20:
																																					case 21:
																																					case 22:
																																					case 25:
																																					case 37:
																																					case 38:
																																					case 47:
																																					case 62:
																																					case 64:
																																					case 76:
																																					case 88:
																																					case 102:
																																					case 105:
																																					case 114:
																																					case 129:
																																					case 130:
																																					case 131:
																																					case 133:
																																					case 141:
																																					case 143:
																																					case 162:
																																					case 167:
																																					case 168:
																																					case 169:
																																					case 170:
																																					case 171:
																																					case 176:
																																					case 188:
																																					case 189:
																																					case 190:
																																					case 192:
																																					case 202:
																																					case 208:
																																					case 209:
																																					case 210:
																																						goto end_IL_042c;
																																					case 134:
																																						goto IL_0dce;
																																					case 135:
																																						goto IL_0de5;
																																					case 183:
																																						goto IL_0df3;
																																					case 30:
																																					case 39:
																																					case 45:
																																					case 60:
																																					case 65:
																																					case 71:
																																					case 72:
																																					case 81:
																																					case 86:
																																					case 91:
																																					case 98:
																																					case 100:
																																					case 104:
																																					case 107:
																																					case 108:
																																					case 109:
																																					case 110:
																																					case 121:
																																					case 128:
																																					case 151:
																																					case 158:
																																					case 165:
																																					case 174:
																																					case 175:
																																						goto end_IL_0383;
																																					case 43:
																																						goto IL_0e14;
																																					case 116:
																																						goto IL_0e1e;
																																					case 67:
																																						goto IL_0e29;
																																					case 31:
																																						goto IL_0e39;
																																					case 199:
																																						goto IL_0e49;
																																					case 4:
																																						goto IL_0e59;
																																					case 70:
																																						goto IL_0e69;
																																					case 198:
																																						goto IL_0e79;
																																					case 57:
																																						goto IL_0e89;
																																					case 94:
																																						goto IL_0e99;
																																					case 205:
																																						goto IL_0ea9;
																																					case 2:
																																					case 142:
																																						goto IL_0ec4;
																																					}
																																					goto end_IL_0e01;
																																					continue;
																																					end_IL_0383:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0738;
																																IL_0829:
																																array2[num6] = 5;
																																num = 55;
																																goto IL_0840;
																																IL_0738:
																																if (12 >= b)
																																{
																																	goto IL_0743;
																																}
																																goto IL_0756;
																																IL_0743:
																																if (12 > b)
																																{
																																	goto end_IL_042c;
																																}
																																break;
																																IL_0756:
																																if (13 < b)
																																{
																																	goto end_IL_042c;
																																}
																																goto IL_0764;
																																IL_0764:
																																if (13 > b)
																																{
																																	goto end_IL_042c;
																																}
																																goto IL_0772;
																																IL_0772:
																																array8 = array3;
																																num7 = num6;
																																if (array == null)
																																{
																																	goto IL_0781;
																																}
																																num8 = ptr2;
																																byte b2 = *num8;
																																ptr2 = num8 + 4;
																																int num9 = *(int*)(ptr2 + num3);
																																ptr2 += 8;
																																byte* ptr3 = ptr2 + num9;
																																byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																																while (ptr2 != ptr3)
																																{
																																	*ptr4 = (byte)(*ptr2 ^ b2);
																																	ptr2++;
																																	ptr4++;
																																}
																																array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																																goto IL_0829;
																																IL_0840:
																																num6++;
																																break;
																															}
																															break;
																														}
																														goto IL_056f;
																														IL_06f6:
																														num6++;
																														break;
																														IL_056f:
																														if (15 >= b)
																														{
																															goto IL_057a;
																														}
																														goto IL_05ca;
																														IL_057a:
																														if (15 > b)
																														{
																															goto end_IL_042c;
																														}
																														goto IL_0588;
																														IL_0588:
																														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																														goto IL_05b1;
																														IL_05b1:
																														array2[num6 - 1] = 5;
																														break;
																														IL_05ca:
																														if (16 < b)
																														{
																															goto end_IL_042c;
																														}
																														goto IL_0676;
																														IL_0676:
																														if (16 > b)
																														{
																															goto end_IL_042c;
																														}
																														goto IL_0684;
																														IL_0684:
																														array2[num6] = array2[num6 - 1];
																														goto IL_069c;
																														IL_069c:
																														array4[num6 - 0] = array4[num6 - 1];
																														goto IL_06ba;
																														IL_06ba:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_06de;
																														IL_06de:
																														array3[num6] = array3[num6 - 1];
																														goto IL_06f6;
																													}
																													break;
																												}
																												goto IL_0853;
																												IL_0890:
																												ptr2 += 8;
																												break;
																												IL_0853:
																												array2[num6] = 5;
																												goto IL_0861;
																												IL_0861:
																												array3[num6] = array7[*(int*)(ptr2 + num3)];
																												num = 144;
																												goto IL_0882;
																												IL_0882:
																												num6++;
																												goto IL_0890;
																											}
																											break;
																										}
																										goto IL_0467;
																										IL_04d8:
																										if (22 > b)
																										{
																											goto end_IL_042c;
																										}
																										num = 34;
																										goto IL_063c;
																										IL_0467:
																										if (20 >= b)
																										{
																											goto IL_0472;
																										}
																										goto IL_0499;
																										IL_0472:
																										if (20 > b)
																										{
																											goto IL_0480;
																										}
																										goto IL_0658;
																										IL_0480:
																										if (18 < b)
																										{
																											num = 153;
																											goto IL_04f4;
																										}
																										goto IL_05dd;
																										IL_063c:
																										num10 = ptr2;
																										num11 = -200;
																										num5 = 1;
																										ptr2 = num10 + num11;
																										break;
																										IL_04f4:
																										if (19 < b)
																										{
																											goto end_IL_042c;
																										}
																										goto IL_0502;
																										IL_0502:
																										if (19 > b)
																										{
																											goto end_IL_042c;
																										}
																										goto IL_0510;
																										IL_0510:
																										array2[num6 - 1] = 5;
																										goto IL_0524;
																										IL_0524:
																										array3[num6 - 1] = ((delegate*<string[], string>)FormKCPm[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																										goto IL_055c;
																										IL_055c:
																										ptr2 += 8;
																										break;
																										IL_05dd:
																										if (18 > b)
																										{
																											goto end_IL_042c;
																										}
																										goto IL_05eb;
																										IL_05eb:
																										((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																										goto IL_0629;
																										IL_0629:
																										num6 -= 3;
																										break;
																										IL_0658:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																										goto IL_0709;
																										IL_0709:
																										array2[num6] = 1;
																										goto IL_0717;
																										IL_0717:
																										num6++;
																										goto IL_0725;
																										IL_0725:
																										ptr2 += 16;
																										break;
																										IL_0499:
																										if (21 >= b)
																										{
																											goto IL_04a4;
																										}
																										goto IL_04ca;
																										IL_04a4:
																										if (21 > b)
																										{
																											goto end_IL_042c;
																										}
																										goto IL_04b2;
																										IL_04b2:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										break;
																										IL_04ca:
																										if (22 < b)
																										{
																											goto end_IL_042c;
																										}
																										goto IL_04d8;
																									}
																									break;
																								}
																								goto IL_08a3;
																								IL_0d2a:
																								num6 -= 2;
																								break;
																								IL_08a3:
																								if (11 <= b)
																								{
																									goto IL_08b1;
																								}
																								goto IL_0943;
																								IL_08b1:
																								array2[num6 - 2] = 0;
																								goto IL_08c5;
																								IL_08c5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)FormKCPm[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_0919;
																								IL_0919:
																								num6--;
																								num = 41;
																								goto IL_0930;
																								IL_0930:
																								ptr2 += 8;
																								break;
																								IL_0943:
																								if (5 >= b)
																								{
																									goto IL_0951;
																								}
																								goto IL_0b56;
																								IL_0951:
																								if (5 > b)
																								{
																									goto IL_095f;
																								}
																								goto IL_0aef;
																								IL_095f:
																								if (2 >= b)
																								{
																									goto IL_096d;
																								}
																								goto IL_0a09;
																								IL_096d:
																								if (2 > b)
																								{
																									goto IL_0978;
																								}
																								num = 152;
																								goto IL_09a2;
																								IL_0978:
																								if (1 < b)
																								{
																									goto end_IL_042c;
																								}
																								goto IL_0986;
																								IL_0986:
																								if (1 <= b)
																								{
																								}
																								goto end_IL_042c;
																								IL_0d3d:
																								if (9 > b)
																								{
																									goto end_IL_042c;
																								}
																								goto IL_0d48;
																								IL_09a2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_09e2;
																								IL_09e2:
																								array2[num6 - 2] = 0;
																								goto IL_09f6;
																								IL_09f6:
																								num6--;
																								break;
																								IL_0a09:
																								if (3 >= b)
																								{
																									goto IL_0a14;
																								}
																								goto IL_0a6c;
																								IL_0a14:
																								if (3 > b)
																								{
																									goto end_IL_042c;
																								}
																								goto IL_0a22;
																								IL_0a22:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a4b;
																								IL_0a4b:
																								ptr2 += 8;
																								goto IL_0a59;
																								IL_0a59:
																								num6--;
																								break;
																								IL_0a6c:
																								if (4 < b)
																								{
																									num = 25;
																									goto end_IL_042c;
																								}
																								goto IL_0a77;
																								IL_0a77:
																								if (4 > b)
																								{
																									goto end_IL_042c;
																								}
																								goto IL_0a85;
																								IL_0a85:
																								array2[num6] = 0;
																								goto IL_0a93;
																								IL_0a93:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0ab6;
																								IL_0ab6:
																								array3[num6] = null;
																								goto IL_0ac0;
																								IL_0ac0:
																								num6++;
																								goto IL_0ace;
																								IL_0ace:
																								ptr2 += 8;
																								break;
																								IL_0d48:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 172;
																								goto IL_0d91;
																								IL_0aef:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0b2f;
																								IL_0b2f:
																								array2[num6 - 2] = 0;
																								goto IL_0b43;
																								IL_0b43:
																								num6--;
																								break;
																								IL_0b56:
																								if (8 >= b)
																								{
																									goto IL_0b64;
																								}
																								goto IL_0c9e;
																								IL_0b64:
																								if (8 <= b)
																								{
																									goto IL_0b6f;
																								}
																								goto IL_0b82;
																								IL_0b6f:
																								num6--;
																								break;
																								IL_0b82:
																								if (6 < b)
																								{
																									goto IL_0b90;
																								}
																								goto IL_0c1e;
																								IL_0b90:
																								if (7 < b)
																								{
																									goto end_IL_042c;
																								}
																								goto IL_0b9e;
																								IL_0b9e:
																								if (7 > b)
																								{
																									num = 188;
																									goto end_IL_042c;
																								}
																								goto IL_0bb7;
																								IL_0d91:
																								array2[num6 - 2] = 0;
																								goto IL_0da5;
																								IL_0bb7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0bf7;
																								IL_0bf7:
																								array2[num6 - 2] = 0;
																								goto IL_0c0b;
																								IL_0c0b:
																								num6--;
																								break;
																								IL_0c1e:
																								if (6 > b)
																								{
																									num = 6;
																									goto end_IL_042c;
																								}
																								goto IL_0c37;
																								IL_0da5:
																								num6--;
																								break;
																								IL_0c37:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0c77;
																								IL_0c77:
																								array2[num6 - 2] = 0;
																								goto IL_0c8b;
																								IL_0c8b:
																								num6--;
																								break;
																								IL_0c9e:
																								if (9 < b)
																								{
																									goto IL_0cac;
																								}
																								goto IL_0d3d;
																								IL_0cac:
																								if (10 < b)
																								{
																									goto end_IL_042c;
																								}
																								goto IL_0cba;
																								IL_0cba:
																								if (10 > b)
																								{
																									goto end_IL_042c;
																								}
																								goto IL_0cc8;
																								IL_0cc8:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0d2a;
																							}
																							goto end_IL_043c;
																							continue;
																							end_IL_042c:
																							break;
																							IL_042c:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0dce;
																					IL_0df3:
																					ptr2 += 8;
																					break;
																					IL_0de5:
																					num6++;
																					goto IL_0df3;
																					IL_0dce:
																					array2[num6] = 0;
																					num = 135;
																					goto IL_0de5;
																					continue;
																					end_IL_043c:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0ec4;
																	IL_0ec4:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0e01:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0781:
				while (true)
				{
					IL_0781_2:
					array = new byte[4];
					while (true)
					{
						IL_078f:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							num = 55;
							while (true)
							{
								IL_0840_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_045c_2:
											byte b = *ptr2;
											while (true)
											{
												IL_044c_2:
												ptr2++;
												while (true)
												{
													IL_043c_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_041c_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_040f_2:
																		if (17 >= b)
																		{
																			while (true)
																			{
																				IL_03ff_2:
																				if (17 > b)
																				{
																					while (true)
																					{
																						IL_03ef_2:
																						if (14 >= b)
																						{
																							while (true)
																							{
																								IL_03df_2:
																								if (14 <= b)
																								{
																									while (true)
																									{
																										IL_03bf_2:
																										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										while (true)
																										{
																											IL_03af_2:
																											ptr2 += 8;
																											while (true)
																											{
																												IL_0396_2:
																												num6--;
																												num = 221;
																												while (num != 221)
																												{
																													if (num != 1202)
																													{
																														goto IL_0510_2;
																													}
																													switch (num)
																													{
																													case 15:
																														goto IL_0396_2;
																													case 112:
																														goto IL_03af_2;
																													case 119:
																													case 163:
																														goto IL_03bf_2;
																													case 181:
																														goto IL_03df_2;
																													case 61:
																														goto IL_03ef_2;
																													case 187:
																														goto IL_03ff_2;
																													case 52:
																													case 178:
																														goto IL_040f_2;
																													case 204:
																														goto IL_041c_2;
																													case 95:
																														goto IL_042c_2;
																													case 194:
																														goto IL_043c_2;
																													case 3:
																														goto IL_044c_2;
																													case 111:
																													case 164:
																														goto IL_045c_2;
																													case 40:
																													case 73:
																														goto IL_0467_2;
																													case 96:
																														goto IL_0472_2;
																													case 1:
																													case 75:
																														goto IL_0480_2;
																													case 138:
																													case 145:
																														goto IL_0499_2;
																													case 122:
																														goto IL_04a4_2;
																													case 17:
																													case 132:
																														goto IL_04b2_2;
																													case 10:
																														goto IL_04ca_2;
																													case 136:
																														goto IL_04d8_2;
																													case 153:
																													case 160:
																														goto IL_04f4_2;
																													case 42:
																														goto IL_0502_2;
																													case 80:
																													case 87:
																														goto IL_0510_2;
																													case 23:
																														goto IL_0524_2;
																													case 49:
																														goto IL_055c_2;
																													case 154:
																													case 161:
																														goto IL_056f_2;
																													case 58:
																														goto IL_057a_2;
																													case 92:
																													case 127:
																														goto IL_0588_2;
																													case 35:
																														goto IL_05b1_2;
																													case 99:
																														goto IL_05ca_2;
																													case 166:
																														goto IL_05dd_2;
																													case 18:
																													case 177:
																														goto IL_05eb_2;
																													case 77:
																														goto IL_0629_2;
																													case 34:
																													case 193:
																														goto IL_063c_2;
																													case 54:
																													case 195:
																														goto IL_0658_2;
																													case 196:
																														goto IL_0676_2;
																													case 16:
																													case 115:
																														goto IL_0684_2;
																													case 101:
																														goto IL_069c_2;
																													case 125:
																														goto IL_06ba_2;
																													case 82:
																														goto IL_06de_2;
																													case 36:
																														goto IL_06f6_2;
																													case 197:
																														goto IL_0709_2;
																													case 46:
																														goto IL_0717_2;
																													case 11:
																														goto IL_0725_2;
																													case 8:
																														goto IL_0738_2;
																													case 28:
																														goto IL_0743_2;
																													case 173:
																														goto IL_0756_2;
																													case 157:
																														goto IL_0764_2;
																													case 84:
																													case 185:
																														goto IL_0772_2;
																													case 214:
																														goto end_IL_0e01_2;
																													case 55:
																														goto IL_0840_2;
																													case 27:
																													case 213:
																														goto IL_0853_2;
																													case 191:
																														goto IL_0861_2;
																													case 144:
																														goto IL_0882_2;
																													case 74:
																														goto IL_0890_2;
																													case 51:
																														goto IL_08a3_2;
																													case 0:
																													case 66:
																														goto IL_08b1_2;
																													case 44:
																														goto IL_08c5_2;
																													case 155:
																														goto IL_0919_2;
																													case 41:
																														goto IL_0930_2;
																													case 113:
																														goto IL_0943_2;
																													case 32:
																														goto IL_0951_2;
																													case 207:
																													case 212:
																														goto IL_095f_2;
																													case 146:
																														goto IL_096d_2;
																													case 137:
																														goto IL_0978_2;
																													case 200:
																														goto IL_0986_2;
																													case 124:
																													case 152:
																														goto IL_09a2_2;
																													case 79:
																														goto IL_09e2_2;
																													case 118:
																														goto IL_09f6_2;
																													case 106:
																														goto IL_0a09_2;
																													case 180:
																														goto IL_0a14_2;
																													case 26:
																													case 179:
																														goto IL_0a22_2;
																													case 150:
																														goto IL_0a4b_2;
																													case 89:
																														goto IL_0a59_2;
																													case 7:
																														goto IL_0a6c_2;
																													case 56:
																														goto IL_0a77_2;
																													case 53:
																													case 93:
																														goto IL_0a85_2;
																													case 148:
																														goto IL_0a93_2;
																													case 140:
																														goto IL_0ab6_2;
																													case 14:
																														goto IL_0ac0_2;
																													case 63:
																														goto IL_0ace_2;
																													case 85:
																													case 90:
																														goto IL_0aef_2;
																													case 97:
																														goto IL_0b2f_2;
																													case 149:
																														goto IL_0b43_2;
																													case 78:
																														goto IL_0b56_2;
																													case 33:
																														goto IL_0b64_2;
																													case 83:
																													case 139:
																														goto IL_0b6f_2;
																													case 117:
																														goto IL_0b82_2;
																													case 147:
																													case 201:
																														goto IL_0b90_2;
																													case 120:
																														goto IL_0b9e_2;
																													case 29:
																													case 184:
																														goto IL_0bb7_2;
																													case 203:
																														goto IL_0bf7_2;
																													case 103:
																														goto IL_0c0b_2;
																													case 156:
																														goto IL_0c1e_2;
																													case 68:
																													case 159:
																														goto IL_0c37_2;
																													case 211:
																														goto IL_0c77_2;
																													case 123:
																														goto IL_0c8b_2;
																													case 50:
																														goto IL_0c9e_2;
																													case 182:
																													case 186:
																														goto IL_0cac_2;
																													case 13:
																														goto IL_0cba_2;
																													case 24:
																													case 69:
																														goto IL_0cc8_2;
																													case 19:
																														goto IL_0d2a_2;
																													case 48:
																														goto IL_0d3d_2;
																													case 59:
																													case 126:
																														goto IL_0d48_2;
																													case 172:
																														goto IL_0d91_2;
																													case 9:
																														goto IL_0da5_2;
																													case 5:
																													case 6:
																													case 12:
																													case 20:
																													case 21:
																													case 22:
																													case 25:
																													case 37:
																													case 38:
																													case 47:
																													case 62:
																													case 64:
																													case 76:
																													case 88:
																													case 102:
																													case 105:
																													case 114:
																													case 129:
																													case 130:
																													case 131:
																													case 133:
																													case 141:
																													case 143:
																													case 162:
																													case 167:
																													case 168:
																													case 169:
																													case 170:
																													case 171:
																													case 176:
																													case 188:
																													case 189:
																													case 190:
																													case 192:
																													case 202:
																													case 208:
																													case 209:
																													case 210:
																														goto end_IL_042c_2;
																													case 134:
																														goto IL_0dce_2;
																													case 135:
																														goto IL_0de5_2;
																													case 183:
																														goto IL_0df3_2;
																													case 30:
																													case 39:
																													case 45:
																													case 60:
																													case 65:
																													case 71:
																													case 72:
																													case 81:
																													case 86:
																													case 91:
																													case 98:
																													case 100:
																													case 104:
																													case 107:
																													case 108:
																													case 109:
																													case 110:
																													case 121:
																													case 128:
																													case 151:
																													case 158:
																													case 165:
																													case 174:
																													case 175:
																														goto end_IL_0383_2;
																													case 43:
																														ptr2 = ptr;
																														goto end_IL_0383_2;
																													case 116:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MapViewToReadOnlyCollectionAdapterTargetFrameworkId.getTypedValueIReportMatchMembershipCondition);
																														goto case 43;
																													case 67:
																														array7 = new object[12];
																														goto case 116;
																													case 31:
																														array6 = new long[4];
																														goto case 67;
																													case 199:
																														array5 = new int[6];
																														goto case 31;
																													case 4:
																														array4 = new int[4];
																														goto case 199;
																													case 70:
																														array3 = new object[4];
																														goto case 4;
																													case 198:
																														array2 = new byte[4];
																														goto case 70;
																													case 57:
																														num4 = num2 * 8;
																														goto case 198;
																													case 94:
																														num3 = num2 * 4;
																														goto case 57;
																													case 205:
																														num2 = 1;
																														goto case 94;
																													case 206:
																														goto end_IL_0829;
																													case 2:
																													case 142:
																														goto IL_0ec4_2;
																													}
																													continue;
																													end_IL_0383_2:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0738_2;
																								IL_0772_2:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_0781_2;
																								}
																								goto IL_078f;
																								IL_0738_2:
																								if (12 >= b)
																								{
																									goto IL_0743_2;
																								}
																								goto IL_0756_2;
																								IL_0743_2:
																								if (12 > b)
																								{
																									goto end_IL_042c_2;
																								}
																								break;
																								IL_0756_2:
																								if (13 < b)
																								{
																									goto end_IL_042c_2;
																								}
																								goto IL_0764_2;
																								IL_0764_2:
																								if (13 > b)
																								{
																									goto end_IL_042c_2;
																								}
																								goto IL_0772_2;
																							}
																							break;
																						}
																						goto IL_056f_2;
																						IL_06f6_2:
																						num6++;
																						break;
																						IL_056f_2:
																						if (15 >= b)
																						{
																							goto IL_057a_2;
																						}
																						goto IL_05ca_2;
																						IL_057a_2:
																						if (15 > b)
																						{
																							goto end_IL_042c_2;
																						}
																						goto IL_0588_2;
																						IL_0588_2:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_05b1_2;
																						IL_05b1_2:
																						array2[num6 - 1] = 5;
																						break;
																						IL_05ca_2:
																						if (16 < b)
																						{
																							goto end_IL_042c_2;
																						}
																						goto IL_0676_2;
																						IL_0676_2:
																						if (16 > b)
																						{
																							goto end_IL_042c_2;
																						}
																						goto IL_0684_2;
																						IL_0684_2:
																						array2[num6] = array2[num6 - 1];
																						goto IL_069c_2;
																						IL_069c_2:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_06ba_2;
																						IL_06ba_2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_06de_2;
																						IL_06de_2:
																						array3[num6] = array3[num6 - 1];
																						goto IL_06f6_2;
																					}
																					break;
																				}
																				goto IL_0853_2;
																				IL_0890_2:
																				ptr2 += 8;
																				break;
																				IL_0853_2:
																				array2[num6] = 5;
																				goto IL_0861_2;
																				IL_0861_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				num = 144;
																				goto IL_0882_2;
																				IL_0882_2:
																				num6++;
																				goto IL_0890_2;
																			}
																			break;
																		}
																		goto IL_0467_2;
																		IL_04d8_2:
																		if (22 > b)
																		{
																			goto end_IL_042c_2;
																		}
																		num = 34;
																		goto IL_063c_2;
																		IL_0467_2:
																		if (20 >= b)
																		{
																			goto IL_0472_2;
																		}
																		goto IL_0499_2;
																		IL_0472_2:
																		if (20 > b)
																		{
																			goto IL_0480_2;
																		}
																		goto IL_0658_2;
																		IL_0480_2:
																		if (18 < b)
																		{
																			num = 153;
																			goto IL_04f4_2;
																		}
																		goto IL_05dd_2;
																		IL_063c_2:
																		num10 = ptr2;
																		num11 = -200;
																		num5 = 1;
																		ptr2 = num10 + num11;
																		break;
																		IL_04f4_2:
																		if (19 < b)
																		{
																			goto end_IL_042c_2;
																		}
																		goto IL_0502_2;
																		IL_0502_2:
																		if (19 > b)
																		{
																			goto end_IL_042c_2;
																		}
																		goto IL_0510_2;
																		IL_0510_2:
																		array2[num6 - 1] = 5;
																		goto IL_0524_2;
																		IL_0524_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)FormKCPm[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_055c_2;
																		IL_055c_2:
																		ptr2 += 8;
																		break;
																		IL_05dd_2:
																		if (18 > b)
																		{
																			goto end_IL_042c_2;
																		}
																		goto IL_05eb_2;
																		IL_05eb_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_0629_2;
																		IL_0629_2:
																		num6 -= 3;
																		break;
																		IL_0658_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0709_2;
																		IL_0709_2:
																		array2[num6] = 1;
																		goto IL_0717_2;
																		IL_0717_2:
																		num6++;
																		goto IL_0725_2;
																		IL_0725_2:
																		ptr2 += 16;
																		break;
																		IL_0499_2:
																		if (21 >= b)
																		{
																			goto IL_04a4_2;
																		}
																		goto IL_04ca_2;
																		IL_04a4_2:
																		if (21 > b)
																		{
																			goto end_IL_042c_2;
																		}
																		goto IL_04b2_2;
																		IL_04b2_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		IL_04ca_2:
																		if (22 < b)
																		{
																			goto end_IL_042c_2;
																		}
																		goto IL_04d8_2;
																	}
																	break;
																}
																goto IL_08a3_2;
																IL_0d2a_2:
																num6 -= 2;
																break;
																IL_08a3_2:
																if (11 <= b)
																{
																	goto IL_08b1_2;
																}
																goto IL_0943_2;
																IL_08b1_2:
																array2[num6 - 2] = 0;
																goto IL_08c5_2;
																IL_08c5_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)FormKCPm[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_0919_2;
																IL_0919_2:
																num6--;
																num = 41;
																goto IL_0930_2;
																IL_0930_2:
																ptr2 += 8;
																break;
																IL_0943_2:
																if (5 >= b)
																{
																	goto IL_0951_2;
																}
																goto IL_0b56_2;
																IL_0951_2:
																if (5 > b)
																{
																	goto IL_095f_2;
																}
																goto IL_0aef_2;
																IL_095f_2:
																if (2 >= b)
																{
																	goto IL_096d_2;
																}
																goto IL_0a09_2;
																IL_096d_2:
																if (2 > b)
																{
																	goto IL_0978_2;
																}
																num = 152;
																goto IL_09a2_2;
																IL_0978_2:
																if (1 < b)
																{
																	goto end_IL_042c_2;
																}
																goto IL_0986_2;
																IL_0986_2:
																if (1 <= b)
																{
																}
																goto end_IL_042c_2;
																IL_0d3d_2:
																if (9 > b)
																{
																	goto end_IL_042c_2;
																}
																goto IL_0d48_2;
																IL_09a2_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_09e2_2;
																IL_09e2_2:
																array2[num6 - 2] = 0;
																goto IL_09f6_2;
																IL_09f6_2:
																num6--;
																break;
																IL_0a09_2:
																if (3 >= b)
																{
																	goto IL_0a14_2;
																}
																goto IL_0a6c_2;
																IL_0a14_2:
																if (3 > b)
																{
																	goto end_IL_042c_2;
																}
																goto IL_0a22_2;
																IL_0a22_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0a4b_2;
																IL_0a4b_2:
																ptr2 += 8;
																goto IL_0a59_2;
																IL_0a59_2:
																num6--;
																break;
																IL_0a6c_2:
																if (4 < b)
																{
																	num = 25;
																	goto end_IL_042c_2;
																}
																goto IL_0a77_2;
																IL_0a77_2:
																if (4 > b)
																{
																	goto end_IL_042c_2;
																}
																goto IL_0a85_2;
																IL_0a85_2:
																array2[num6] = 0;
																goto IL_0a93_2;
																IL_0a93_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0ab6_2;
																IL_0ab6_2:
																array3[num6] = null;
																goto IL_0ac0_2;
																IL_0ac0_2:
																num6++;
																goto IL_0ace_2;
																IL_0ace_2:
																ptr2 += 8;
																break;
																IL_0d48_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																num = 172;
																goto IL_0d91_2;
																IL_0aef_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0b2f_2;
																IL_0b2f_2:
																array2[num6 - 2] = 0;
																goto IL_0b43_2;
																IL_0b43_2:
																num6--;
																break;
																IL_0b56_2:
																if (8 >= b)
																{
																	goto IL_0b64_2;
																}
																goto IL_0c9e_2;
																IL_0b64_2:
																if (8 <= b)
																{
																	goto IL_0b6f_2;
																}
																goto IL_0b82_2;
																IL_0b6f_2:
																num6--;
																break;
																IL_0b82_2:
																if (6 < b)
																{
																	goto IL_0b90_2;
																}
																goto IL_0c1e_2;
																IL_0b90_2:
																if (7 < b)
																{
																	goto end_IL_042c_2;
																}
																goto IL_0b9e_2;
																IL_0b9e_2:
																if (7 > b)
																{
																	num = 188;
																	goto end_IL_042c_2;
																}
																goto IL_0bb7_2;
																IL_0d91_2:
																array2[num6 - 2] = 0;
																goto IL_0da5_2;
																IL_0bb7_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0bf7_2;
																IL_0bf7_2:
																array2[num6 - 2] = 0;
																goto IL_0c0b_2;
																IL_0c0b_2:
																num6--;
																break;
																IL_0c1e_2:
																if (6 > b)
																{
																	num = 6;
																	goto end_IL_042c_2;
																}
																goto IL_0c37_2;
																IL_0da5_2:
																num6--;
																break;
																IL_0c37_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0c77_2;
																IL_0c77_2:
																array2[num6 - 2] = 0;
																goto IL_0c8b_2;
																IL_0c8b_2:
																num6--;
																break;
																IL_0c9e_2:
																if (9 < b)
																{
																	goto IL_0cac_2;
																}
																goto IL_0d3d_2;
																IL_0cac_2:
																if (10 < b)
																{
																	goto end_IL_042c_2;
																}
																goto IL_0cba_2;
																IL_0cba_2:
																if (10 > b)
																{
																	goto end_IL_042c_2;
																}
																goto IL_0cc8_2;
																IL_0cc8_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0d2a_2;
															}
															goto end_IL_043c_2;
															continue;
															end_IL_042c_2:
															break;
															IL_042c_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0dce_2;
													IL_0df3_2:
													ptr2 += 8;
													break;
													IL_0de5_2:
													num6++;
													goto IL_0df3_2;
													IL_0dce_2:
													array2[num6] = 0;
													num = 135;
													goto IL_0de5_2;
													continue;
													end_IL_043c_2:
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0ec4_2;
									IL_0ec4_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0e01_2:
									break;
								}
								break;
							}
							continue;
							end_IL_0829:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0361, IL_0374, IL_03bf, IL_03cf, IL_03df, IL_03ef, IL_03ff, IL_040f, IL_041c, IL_042c, IL_043c, IL_044c, IL_045f, IL_046f, IL_047a, IL_0488, IL_0495, IL_04a8, IL_04bb, IL_04c9, IL_04d7, IL_04e5, IL_04f0, IL_0535, IL_0543, IL_0556, IL_0564, IL_056d, IL_057b, IL_0589, IL_05ac, IL_05b6, IL_05c4, IL_05d7, IL_05eb, IL_05fe, IL_063e, IL_0652, IL_0665, IL_0673, IL_0681, IL_068f, IL_069d, IL_06ab, IL_06b9, IL_06d1, IL_06f8, IL_0721, IL_072f, IL_0747, IL_0755, IL_0768, IL_0773, IL_0791, IL_079f, IL_07b2, IL_07c0, IL_07ce, IL_07eb, IL_083a, IL_0844, IL_0871, IL_088e, IL_089c, IL_08af, IL_08ba, IL_08e3, IL_08fc, IL_090a, IL_0918, IL_0923, IL_0931, IL_093f, IL_0952, IL_095b, IL_097d, IL_098b, IL_0999, IL_09ac, IL_09b7, IL_09ca, IL_09d3, IL_09e1, IL_09ef, IL_0a0b, IL_0a4b, IL_0a5f, IL_0a72, IL_0a8a, IL_0a9d, IL_0ac6, IL_0ad4, IL_0ae7, IL_0afb, IL_0b33, IL_0b46, IL_0b67, IL_0b75, IL_0bb3, IL_0bc6, IL_0bda, IL_0bed, IL_0bf6, IL_0c01, IL_0c0f, IL_0c4f, IL_0c63, IL_0c7f, IL_0c8a, IL_0c95, IL_0cf7, IL_0d07, IL_0d20, IL_0d2e, IL_0d3c, IL_0d4a, IL_0d5d, IL_0d67, IL_0d72, IL_0d82, IL_0d92, IL_0da2, IL_0db2, IL_0dc2, IL_0dd2, IL_0de2, IL_0df2, IL_0e0d are reachable both inside and outside the pinned region starting at IL_0e07. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 105;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef7 = default(int);
				ref int reference = ref __rxRef7;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0df2:
						num2 = 1;
						while (true)
						{
							IL_0de2:
							num3 = num2 * 4;
							while (true)
							{
								IL_0dd2:
								num4 = num2 * 8;
								while (true)
								{
									IL_0dc2:
									array2 = new byte[4];
									while (true)
									{
										IL_0db2:
										array3 = new object[4];
										while (true)
										{
											IL_0da2:
											array4 = new int[4];
											while (true)
											{
												IL_0d92:
												array5 = new int[6];
												while (true)
												{
													IL_0d82:
													array6 = new long[4];
													while (true)
													{
														IL_0d72:
														array7 = new object[16];
														while (true)
														{
															IL_0d67:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsOneWayExceptionHandler.PeekCustomAttribute);
															while (true)
															{
																IL_0d5d:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_046f:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_045f:
																				ptr2++;
																				while (true)
																				{
																					IL_044c:
																					if (b >= 1)
																					{
																						num = 44;
																						while (b <= 21)
																						{
																							while (true)
																							{
																								IL_042c:
																								if (11 >= b)
																								{
																									while (11 > b)
																									{
																										while (true)
																										{
																											IL_040f:
																											if (5 < b)
																											{
																												while (true)
																												{
																													IL_03ff:
																													if (8 >= b)
																													{
																														while (true)
																														{
																															IL_03ef:
																															if (8 > b)
																															{
																																while (true)
																																{
																																	IL_03df:
																																	if (6 < b)
																																	{
																																		while (7 >= b)
																																		{
																																			while (7 <= b)
																																			{
																																				while (true)
																																				{
																																					IL_0374:
																																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																					num = 209;
																																					while (true)
																																					{
																																						if (num != 209)
																																						{
																																							if (num != 1190)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 105:
																																								break;
																																							default:
																																								continue;
																																							case 88:
																																							case 129:
																																								goto IL_0374;
																																							case 34:
																																								goto IL_03bf;
																																							case 19:
																																								goto IL_03cf;
																																							case 116:
																																								goto IL_03df;
																																							case 64:
																																								goto IL_03ef;
																																							case 182:
																																								goto IL_03ff;
																																							case 76:
																																							case 118:
																																								goto IL_040f;
																																							case 124:
																																								goto IL_041c;
																																							case 180:
																																								goto IL_042c;
																																							case 44:
																																								goto IL_043c;
																																							case 89:
																																								goto IL_044c;
																																							case 110:
																																								goto IL_045f;
																																							case 30:
																																							case 54:
																																								goto IL_046f;
																																							case 84:
																																								goto IL_047a;
																																							case 37:
																																								goto IL_0488;
																																							case 43:
																																							case 87:
																																								goto IL_0495;
																																							case 115:
																																								goto IL_04a8;
																																							case 97:
																																							case 123:
																																								goto IL_04bb;
																																							case 35:
																																								goto IL_04c9;
																																							case 127:
																																								goto IL_04e5;
																																							case 55:
																																							case 58:
																																								goto IL_04f0;
																																							case 1:
																																								goto IL_0535;
																																							case 74:
																																								goto IL_0543;
																																							case 90:
																																							case 154:
																																								goto IL_0556;
																																							case 57:
																																								goto IL_056d;
																																							case 142:
																																							case 149:
																																								goto IL_057b;
																																							case 92:
																																								goto IL_0589;
																																							case 28:
																																								goto IL_05ac;
																																							case 22:
																																								goto IL_05b6;
																																							case 83:
																																								goto IL_05c4;
																																							case 162:
																																								goto IL_05d7;
																																							case 78:
																																								goto IL_05eb;
																																							case 100:
																																							case 166:
																																								goto IL_05fe;
																																							case 73:
																																								goto IL_063e;
																																							case 13:
																																								goto IL_0652;
																																							case 26:
																																							case 172:
																																								goto IL_0665;
																																							case 67:
																																								goto IL_0673;
																																							case 16:
																																							case 66:
																																								goto IL_0681;
																																							case 20:
																																								goto IL_068f;
																																							case 103:
																																								goto IL_069d;
																																							case 7:
																																								goto IL_06ab;
																																							case 39:
																																							case 72:
																																								goto IL_06b9;
																																							case 5:
																																								goto IL_06d1;
																																							case 132:
																																								goto IL_06f8;
																																							case 91:
																																							case 101:
																																								goto IL_0721;
																																							case 170:
																																								goto IL_072f;
																																							case 140:
																																								goto IL_0747;
																																							case 119:
																																								goto IL_0755;
																																							case 174:
																																								goto IL_0768;
																																							case 8:
																																							case 173:
																																								goto IL_0773;
																																							case 25:
																																								goto IL_0791;
																																							case 51:
																																								goto IL_079f;
																																							case 144:
																																								goto IL_07b2;
																																							case 71:
																																								goto IL_07c0;
																																							case 38:
																																							case 171:
																																								goto IL_07ce;
																																							case 47:
																																								goto IL_088e;
																																							case 181:
																																								goto IL_089c;
																																							case 188:
																																								goto IL_08af;
																																							case 0:
																																							case 53:
																																								goto IL_08ba;
																																							case 106:
																																								goto IL_08e3;
																																							case 45:
																																							case 189:
																																								goto IL_090a;
																																							case 121:
																																								goto IL_0918;
																																							case 175:
																																								goto IL_0923;
																																							case 49:
																																								goto IL_0931;
																																							case 14:
																																								goto IL_093f;
																																							case 31:
																																							case 112:
																																								goto IL_095b;
																																							case 95:
																																								goto IL_097d;
																																							case 102:
																																								goto IL_098b;
																																							case 81:
																																								goto IL_0999;
																																							case 60:
																																								goto IL_09ac;
																																							case 82:
																																								goto IL_09b7;
																																							case 126:
																																							case 178:
																																								goto IL_09d3;
																																							case 98:
																																								goto IL_09e1;
																																							case 24:
																																							case 185:
																																								goto IL_09ef;
																																							case 69:
																																							case 190:
																																								goto IL_0a0b;
																																							case 147:
																																								goto IL_0a4b;
																																							case 75:
																																								goto IL_0a5f;
																																							case 191:
																																								goto IL_0a72;
																																							case 3:
																																								goto IL_0a8a;
																																							case 161:
																																							case 193:
																																								goto IL_0a9d;
																																							case 63:
																																								goto IL_0ac6;
																																							case 32:
																																								goto IL_0ad4;
																																							case 117:
																																							case 198:
																																								goto IL_0ae7;
																																							case 68:
																																								goto IL_0afb;
																																							case 70:
																																								goto IL_0b33;
																																							case 94:
																																							case 200:
																																								goto IL_0b46;
																																							case 201:
																																								goto IL_0b67;
																																							case 152:
																																							case 196:
																																								goto IL_0b75;
																																							case 77:
																																								goto IL_0bb3;
																																							case 33:
																																								goto IL_0bda;
																																							case 29:
																																							case 56:
																																								goto IL_0bf6;
																																							case 199:
																																								goto IL_0c01;
																																							case 157:
																																							case 164:
																																								goto IL_0c0f;
																																							case 155:
																																								goto IL_0c4f;
																																							case 179:
																																								goto IL_0c63;
																																							case 192:
																																								goto IL_0c7f;
																																							case 2:
																																								goto IL_0c8a;
																																							case 62:
																																							case 107:
																																								goto IL_0c95;
																																							case 79:
																																								goto IL_0cf7;
																																							case 6:
																																							case 9:
																																							case 17:
																																							case 21:
																																							case 27:
																																							case 40:
																																							case 41:
																																							case 50:
																																							case 59:
																																							case 65:
																																							case 85:
																																							case 99:
																																							case 111:
																																							case 114:
																																							case 122:
																																							case 128:
																																							case 131:
																																							case 133:
																																							case 135:
																																							case 139:
																																							case 141:
																																							case 146:
																																							case 151:
																																							case 153:
																																							case 158:
																																							case 160:
																																							case 163:
																																							case 165:
																																							case 167:
																																							case 169:
																																							case 177:
																																							case 184:
																																							case 187:
																																							case 195:
																																							case 197:
																																								goto end_IL_03bf;
																																							case 42:
																																								goto IL_0d20;
																																							case 108:
																																								goto IL_0d2e;
																																							case 15:
																																								goto IL_0d3c;
																																							case 4:
																																							case 11:
																																							case 18:
																																							case 23:
																																							case 36:
																																							case 46:
																																							case 61:
																																							case 80:
																																							case 93:
																																							case 96:
																																							case 109:
																																							case 125:
																																							case 137:
																																							case 138:
																																							case 145:
																																							case 150:
																																							case 156:
																																							case 159:
																																							case 168:
																																							case 176:
																																							case 183:
																																							case 186:
																																							case 194:
																																							case 202:
																																								goto end_IL_0361;
																																							case 143:
																																								goto IL_0d5d;
																																							case 134:
																																								goto IL_0d67;
																																							case 136:
																																								goto IL_0d72;
																																							case 113:
																																								goto IL_0d82;
																																							case 120:
																																								goto IL_0d92;
																																							case 148:
																																								goto IL_0da2;
																																							case 52:
																																								goto IL_0db2;
																																							case 86:
																																								goto IL_0dc2;
																																							case 130:
																																								goto IL_0dd2;
																																							case 48:
																																								goto IL_0de2;
																																							case 104:
																																								goto IL_0df2;
																																							case 10:
																																							case 12:
																																								goto IL_0e0d;
																																							}
																																							goto end_IL_0d4a;
																																						}
																																						array2[num6 - 2] = 0;
																																						goto IL_0bda;
																																						IL_0bda:
																																						num6--;
																																						break;
																																						continue;
																																						end_IL_0361:
																																						break;
																																					}
																																					break;
																																				}
																																				goto end_IL_041c;
																																				continue;
																																				end_IL_03bf:
																																				break;
																																				IL_03bf:;
																																			}
																																			break;
																																			IL_03cf:;
																																		}
																																		break;
																																	}
																																	goto IL_04a8;
																																	IL_0a5f:
																																	num6--;
																																	goto end_IL_041c;
																																	IL_04a8:
																																	if (6 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0a0b;
																																	IL_0a0b:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	goto IL_0a4b;
																																	IL_0a4b:
																																	array2[num6 - 2] = 0;
																																	goto IL_0a5f;
																																}
																																break;
																															}
																															goto IL_0495;
																															IL_0495:
																															num6--;
																															goto end_IL_041c;
																														}
																														break;
																													}
																													num = 56;
																													goto IL_0bf6;
																													IL_0c95:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0cf7;
																													IL_0cf7:
																													num6 -= 2;
																													goto end_IL_041c;
																													IL_0bf6:
																													if (9 >= b)
																													{
																														goto IL_0c01;
																													}
																													goto IL_0c7f;
																													IL_0c01:
																													if (9 > b)
																													{
																														break;
																													}
																													goto IL_0c0f;
																													IL_0c0f:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0c4f;
																													IL_0c4f:
																													array2[num6 - 2] = 0;
																													goto IL_0c63;
																													IL_0c63:
																													num6--;
																													num = 96;
																													goto end_IL_041c;
																													IL_0c7f:
																													if (10 < b)
																													{
																														break;
																													}
																													goto IL_0c8a;
																													IL_0c8a:
																													if (10 > b)
																													{
																														break;
																													}
																													goto IL_0c95;
																												}
																												break;
																											}
																											goto IL_047a;
																											IL_05fe:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_063e;
																											IL_047a:
																											if (5 > b)
																											{
																												goto IL_0488;
																											}
																											goto IL_05fe;
																											IL_0488:
																											if (2 < b)
																											{
																												goto IL_04bb;
																											}
																											goto IL_04e5;
																											IL_04bb:
																											if (3 >= b)
																											{
																												goto IL_04c9;
																											}
																											goto IL_0556;
																											IL_04c9:
																											if (3 > b)
																											{
																												num = 177;
																												break;
																											}
																											goto IL_0a9d;
																											IL_063e:
																											array2[num6 - 2] = 0;
																											goto IL_0652;
																											IL_0a9d:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0ac6;
																											IL_0ac6:
																											ptr2 += 8;
																											goto IL_0ad4;
																											IL_0ad4:
																											num6--;
																											goto end_IL_041c;
																											IL_0556:
																											if (4 < b)
																											{
																												break;
																											}
																											num = 57;
																											goto IL_056d;
																											IL_0652:
																											num6--;
																											goto end_IL_041c;
																											IL_056d:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_057b;
																											IL_057b:
																											array2[num6] = 0;
																											goto IL_0589;
																											IL_0589:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_05ac;
																											IL_05ac:
																											array3[num6] = null;
																											goto IL_05b6;
																											IL_05b6:
																											num6++;
																											goto IL_05c4;
																											IL_05c4:
																											ptr2 += 8;
																											goto end_IL_041c;
																											IL_04e5:
																											if (2 <= b)
																											{
																												goto IL_04f0;
																											}
																											goto IL_0535;
																											IL_04f0:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_05d7;
																											IL_05d7:
																											array2[num6 - 2] = 0;
																											goto IL_05eb;
																											IL_05eb:
																											num6--;
																											goto end_IL_041c;
																											IL_0535:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_0543;
																											IL_0543:
																											if (1 > b)
																											{
																											}
																											break;
																										}
																										goto end_IL_043c;
																										continue;
																										end_IL_041c:
																										break;
																										IL_041c:;
																									}
																									break;
																								}
																								goto IL_0665;
																								IL_09ac:
																								if (20 >= b)
																								{
																									goto IL_09b7;
																								}
																								num = 178;
																								goto IL_09d3;
																								IL_0665:
																								if (16 >= b)
																								{
																									goto IL_0673;
																								}
																								goto IL_090a;
																								IL_0673:
																								if (16 > b)
																								{
																									goto IL_0681;
																								}
																								goto IL_0721;
																								IL_0681:
																								if (13 < b)
																								{
																									goto IL_068f;
																								}
																								goto IL_0768;
																								IL_068f:
																								if (14 < b)
																								{
																									goto IL_069d;
																								}
																								goto IL_08af;
																								IL_069d:
																								if (15 < b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_06ab;
																								IL_06ab:
																								if (15 > b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_06b9;
																								IL_06b9:
																								array2[num6] = array2[num6 - 1];
																								goto IL_06d1;
																								IL_06d1:
																								array4[num6 - 0] = array4[num6 - 1];
																								num = 132;
																								goto IL_06f8;
																								IL_06f8:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a72;
																								IL_0a72:
																								array3[num6] = array3[num6 - 1];
																								goto IL_0a8a;
																								IL_0a8a:
																								num6++;
																								break;
																								IL_08af:
																								if (14 > b)
																								{
																									num = 85;
																									goto end_IL_043c;
																								}
																								goto IL_08ba;
																								IL_08ba:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_08e3;
																								IL_08e3:
																								array2[num6 - 1] = 5;
																								break;
																								IL_09b7:
																								if (20 > b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_0b46;
																								IL_0768:
																								if (13 <= b)
																								{
																									goto IL_0773;
																								}
																								goto IL_07b2;
																								IL_0773:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0791;
																								IL_0791:
																								ptr2 += 8;
																								goto IL_079f;
																								IL_079f:
																								num6--;
																								break;
																								IL_07b2:
																								if (12 < b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_07c0;
																								IL_07c0:
																								if (12 > b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_07ce;
																								IL_07ce:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_07dd;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								num = 47;
																								goto IL_088e;
																								IL_0b46:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								num = 61;
																								break;
																								IL_09ef:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								break;
																								IL_09d3:
																								if (21 < b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_09e1;
																								IL_088e:
																								array2[num6] = 5;
																								goto IL_089c;
																								IL_089c:
																								num6++;
																								break;
																								IL_0721:
																								array2[num6] = 5;
																								goto IL_072f;
																								IL_072f:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0747;
																								IL_0747:
																								num6++;
																								goto IL_0755;
																								IL_0755:
																								ptr2 += 8;
																								break;
																								IL_090a:
																								if (19 >= b)
																								{
																									goto IL_0918;
																								}
																								goto IL_09ac;
																								IL_0918:
																								if (19 > b)
																								{
																									goto IL_0923;
																								}
																								num = 112;
																								goto IL_095b;
																								IL_0923:
																								if (17 < b)
																								{
																									goto IL_0931;
																								}
																								goto IL_0b67;
																								IL_0931:
																								if (18 < b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_093f;
																								IL_093f:
																								if (18 > b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_0ae7;
																								IL_0ae7:
																								array2[num6 - 1] = 5;
																								goto IL_0afb;
																								IL_0afb:
																								array3[num6 - 1] = ((delegate*<string[], string>)RSAPKCSKeyExchangeFormatterIsNestedPublic[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0b33;
																								IL_0b33:
																								ptr2 += 8;
																								break;
																								IL_0b67:
																								if (17 > b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_0b75;
																								IL_0b75:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_0bb3;
																								IL_0bb3:
																								num6 -= 3;
																								break;
																								IL_09e1:
																								if (21 > b)
																								{
																									goto end_IL_043c;
																								}
																								goto IL_09ef;
																								IL_095b:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								num = 95;
																								goto IL_097d;
																								IL_097d:
																								array2[num6] = 1;
																								goto IL_098b;
																								IL_098b:
																								num6++;
																								goto IL_0999;
																								IL_0999:
																								ptr2 += 16;
																								break;
																							}
																							goto end_IL_044c;
																							continue;
																							end_IL_043c:
																							break;
																							IL_043c:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0d20;
																					IL_0d2e:
																					num6++;
																					goto IL_0d3c;
																					IL_0d3c:
																					ptr2 += 8;
																					break;
																					IL_0d20:
																					array2[num6] = 0;
																					goto IL_0d2e;
																					continue;
																					end_IL_044c:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0e0d;
																	IL_0e0d:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0d4a:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_07dd:
				while (true)
				{
					IL_07dd_2:
					array = new byte[4];
					while (true)
					{
						IL_07eb:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						num = 47;
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_089c_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_046f_2:
											byte b = *ptr2;
											while (true)
											{
												IL_045f_2:
												ptr2++;
												while (true)
												{
													IL_044c_2:
													if (b >= 1)
													{
														num = 44;
														while (b <= 21)
														{
															while (true)
															{
																IL_042c_2:
																if (11 >= b)
																{
																	while (11 > b)
																	{
																		while (true)
																		{
																			IL_040f_2:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_03ff_2:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_03ef_2:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_03df_2:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_0374_2:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													num = 209;
																													while (true)
																													{
																														if (num != 209)
																														{
																															if (num != 1190)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 88:
																															case 129:
																																goto IL_0374_2;
																															case 34:
																																goto IL_03bf_2;
																															case 19:
																																goto IL_03cf_2;
																															case 116:
																																goto IL_03df_2;
																															case 64:
																																goto IL_03ef_2;
																															case 182:
																																goto IL_03ff_2;
																															case 76:
																															case 118:
																																goto IL_040f_2;
																															case 124:
																																goto IL_041c_2;
																															case 180:
																																goto IL_042c_2;
																															case 44:
																																goto IL_043c_2;
																															case 89:
																																goto IL_044c_2;
																															case 110:
																																goto IL_045f_2;
																															case 30:
																															case 54:
																																goto IL_046f_2;
																															case 84:
																																goto IL_047a_2;
																															case 37:
																																goto IL_0488_2;
																															case 43:
																															case 87:
																																goto IL_0495_2;
																															case 115:
																																goto IL_04a8_2;
																															case 97:
																															case 123:
																																goto IL_04bb_2;
																															case 35:
																																goto IL_04c9_2;
																															case 127:
																																goto IL_04e5_2;
																															case 55:
																															case 58:
																																goto IL_04f0_2;
																															case 1:
																																goto IL_0535_2;
																															case 74:
																																goto IL_0543_2;
																															case 90:
																															case 154:
																																goto IL_0556_2;
																															case 57:
																																goto IL_056d_2;
																															case 142:
																															case 149:
																																goto IL_057b_2;
																															case 92:
																																goto IL_0589_2;
																															case 28:
																																goto IL_05ac_2;
																															case 22:
																																goto IL_05b6_2;
																															case 83:
																																goto IL_05c4_2;
																															case 162:
																																goto IL_05d7_2;
																															case 78:
																																goto IL_05eb_2;
																															case 100:
																															case 166:
																																goto IL_05fe_2;
																															case 73:
																																goto IL_063e_2;
																															case 13:
																																goto IL_0652_2;
																															case 26:
																															case 172:
																																goto IL_0665_2;
																															case 67:
																																goto IL_0673_2;
																															case 16:
																															case 66:
																																goto IL_0681_2;
																															case 20:
																																goto IL_068f_2;
																															case 103:
																																goto IL_069d_2;
																															case 7:
																																goto IL_06ab_2;
																															case 39:
																															case 72:
																																goto IL_06b9_2;
																															case 5:
																																goto IL_06d1_2;
																															case 132:
																																goto IL_06f8_2;
																															case 91:
																															case 101:
																																goto IL_0721_2;
																															case 170:
																																goto IL_072f_2;
																															case 140:
																																goto IL_0747_2;
																															case 119:
																																goto IL_0755_2;
																															case 174:
																																goto IL_0768_2;
																															case 8:
																															case 173:
																																goto IL_0773_2;
																															case 25:
																																goto IL_0791_2;
																															case 51:
																																goto IL_079f_2;
																															case 144:
																																goto IL_07b2_2;
																															case 71:
																																goto IL_07c0_2;
																															case 38:
																															case 171:
																																goto IL_07ce_2;
																															case 47:
																																goto end_IL_0d4a_2;
																															case 181:
																																goto IL_089c_2;
																															case 188:
																																goto IL_08af_2;
																															case 0:
																															case 53:
																																goto IL_08ba_2;
																															case 106:
																																goto IL_08e3_2;
																															case 45:
																															case 189:
																																goto IL_090a_2;
																															case 121:
																																goto IL_0918_2;
																															case 175:
																																goto IL_0923_2;
																															case 49:
																																goto IL_0931_2;
																															case 14:
																																goto IL_093f_2;
																															case 31:
																															case 112:
																																goto IL_095b_2;
																															case 95:
																																goto IL_097d_2;
																															case 102:
																																goto IL_098b_2;
																															case 81:
																																goto IL_0999_2;
																															case 60:
																																goto IL_09ac_2;
																															case 82:
																																goto IL_09b7_2;
																															case 126:
																															case 178:
																																goto IL_09d3_2;
																															case 98:
																																goto IL_09e1_2;
																															case 24:
																															case 185:
																																goto IL_09ef_2;
																															case 69:
																															case 190:
																																goto IL_0a0b_2;
																															case 147:
																																goto IL_0a4b_2;
																															case 75:
																																goto IL_0a5f_2;
																															case 191:
																																goto IL_0a72_2;
																															case 3:
																																goto IL_0a8a_2;
																															case 161:
																															case 193:
																																goto IL_0a9d_2;
																															case 63:
																																goto IL_0ac6_2;
																															case 32:
																																goto IL_0ad4_2;
																															case 117:
																															case 198:
																																goto IL_0ae7_2;
																															case 68:
																																goto IL_0afb_2;
																															case 70:
																																goto IL_0b33_2;
																															case 94:
																															case 200:
																																goto IL_0b46_2;
																															case 201:
																																goto IL_0b67_2;
																															case 152:
																															case 196:
																																goto IL_0b75_2;
																															case 77:
																																goto IL_0bb3_2;
																															case 33:
																																goto IL_0bda_2;
																															case 29:
																															case 56:
																																goto IL_0bf6_2;
																															case 199:
																																goto IL_0c01_2;
																															case 157:
																															case 164:
																																goto IL_0c0f_2;
																															case 155:
																																goto IL_0c4f_2;
																															case 179:
																																goto IL_0c63_2;
																															case 192:
																																goto IL_0c7f_2;
																															case 2:
																																goto IL_0c8a_2;
																															case 62:
																															case 107:
																																goto IL_0c95_2;
																															case 79:
																																goto IL_0cf7_2;
																															case 6:
																															case 9:
																															case 17:
																															case 21:
																															case 27:
																															case 40:
																															case 41:
																															case 50:
																															case 59:
																															case 65:
																															case 85:
																															case 99:
																															case 111:
																															case 114:
																															case 122:
																															case 128:
																															case 131:
																															case 133:
																															case 135:
																															case 139:
																															case 141:
																															case 146:
																															case 151:
																															case 153:
																															case 158:
																															case 160:
																															case 163:
																															case 165:
																															case 167:
																															case 169:
																															case 177:
																															case 184:
																															case 187:
																															case 195:
																															case 197:
																																goto end_IL_03bf_2;
																															case 42:
																																goto IL_0d20_2;
																															case 108:
																																goto IL_0d2e_2;
																															case 15:
																																goto IL_0d3c_2;
																															case 4:
																															case 11:
																															case 18:
																															case 23:
																															case 36:
																															case 46:
																															case 61:
																															case 80:
																															case 93:
																															case 96:
																															case 109:
																															case 125:
																															case 137:
																															case 138:
																															case 145:
																															case 150:
																															case 156:
																															case 159:
																															case 168:
																															case 176:
																															case 183:
																															case 186:
																															case 194:
																															case 202:
																																goto end_IL_0361_2;
																															case 143:
																																ptr2 = ptr;
																																goto end_IL_0361_2;
																															case 134:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsOneWayExceptionHandler.PeekCustomAttribute);
																																goto case 143;
																															case 136:
																																array7 = new object[16];
																																goto case 134;
																															case 113:
																																array6 = new long[4];
																																goto case 136;
																															case 120:
																																array5 = new int[6];
																																goto case 113;
																															case 148:
																																array4 = new int[4];
																																goto case 120;
																															case 52:
																																array3 = new object[4];
																																goto case 148;
																															case 86:
																																array2 = new byte[4];
																																goto case 52;
																															case 130:
																																num4 = num2 * 8;
																																goto case 86;
																															case 48:
																																num3 = num2 * 4;
																																goto case 130;
																															case 104:
																																num2 = 1;
																																goto case 48;
																															case 105:
																																goto end_IL_088e;
																															case 10:
																															case 12:
																																goto IL_0e0d_2;
																															}
																															continue;
																														}
																														array2[num6 - 2] = 0;
																														goto IL_0bda_2;
																														IL_0bda_2:
																														num6--;
																														break;
																														continue;
																														end_IL_0361_2:
																														break;
																													}
																													break;
																												}
																												goto end_IL_041c_2;
																												continue;
																												end_IL_03bf_2:
																												break;
																												IL_03bf_2:;
																											}
																											break;
																											IL_03cf_2:;
																										}
																										break;
																									}
																									goto IL_04a8_2;
																									IL_0a5f_2:
																									num6--;
																									goto end_IL_041c_2;
																									IL_04a8_2:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_0a0b_2;
																									IL_0a0b_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0a4b_2;
																									IL_0a4b_2:
																									array2[num6 - 2] = 0;
																									goto IL_0a5f_2;
																								}
																								break;
																							}
																							goto IL_0495_2;
																							IL_0495_2:
																							num6--;
																							goto end_IL_041c_2;
																						}
																						break;
																					}
																					num = 56;
																					goto IL_0bf6_2;
																					IL_0c95_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0cf7_2;
																					IL_0cf7_2:
																					num6 -= 2;
																					goto end_IL_041c_2;
																					IL_0bf6_2:
																					if (9 >= b)
																					{
																						goto IL_0c01_2;
																					}
																					goto IL_0c7f_2;
																					IL_0c01_2:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0c0f_2;
																					IL_0c0f_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0c4f_2;
																					IL_0c4f_2:
																					array2[num6 - 2] = 0;
																					goto IL_0c63_2;
																					IL_0c63_2:
																					num6--;
																					num = 96;
																					goto end_IL_041c_2;
																					IL_0c7f_2:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0c8a_2;
																					IL_0c8a_2:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0c95_2;
																				}
																				break;
																			}
																			goto IL_047a_2;
																			IL_05fe_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_063e_2;
																			IL_047a_2:
																			if (5 > b)
																			{
																				goto IL_0488_2;
																			}
																			goto IL_05fe_2;
																			IL_0488_2:
																			if (2 < b)
																			{
																				goto IL_04bb_2;
																			}
																			goto IL_04e5_2;
																			IL_04bb_2:
																			if (3 >= b)
																			{
																				goto IL_04c9_2;
																			}
																			goto IL_0556_2;
																			IL_04c9_2:
																			if (3 > b)
																			{
																				num = 177;
																				break;
																			}
																			goto IL_0a9d_2;
																			IL_063e_2:
																			array2[num6 - 2] = 0;
																			goto IL_0652_2;
																			IL_0a9d_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0ac6_2;
																			IL_0ac6_2:
																			ptr2 += 8;
																			goto IL_0ad4_2;
																			IL_0ad4_2:
																			num6--;
																			goto end_IL_041c_2;
																			IL_0556_2:
																			if (4 < b)
																			{
																				break;
																			}
																			num = 57;
																			goto IL_056d_2;
																			IL_0652_2:
																			num6--;
																			goto end_IL_041c_2;
																			IL_056d_2:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_057b_2;
																			IL_057b_2:
																			array2[num6] = 0;
																			goto IL_0589_2;
																			IL_0589_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_05ac_2;
																			IL_05ac_2:
																			array3[num6] = null;
																			goto IL_05b6_2;
																			IL_05b6_2:
																			num6++;
																			goto IL_05c4_2;
																			IL_05c4_2:
																			ptr2 += 8;
																			goto end_IL_041c_2;
																			IL_04e5_2:
																			if (2 <= b)
																			{
																				goto IL_04f0_2;
																			}
																			goto IL_0535_2;
																			IL_04f0_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_05d7_2;
																			IL_05d7_2:
																			array2[num6 - 2] = 0;
																			goto IL_05eb_2;
																			IL_05eb_2:
																			num6--;
																			goto end_IL_041c_2;
																			IL_0535_2:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0543_2;
																			IL_0543_2:
																			if (1 > b)
																			{
																			}
																			break;
																		}
																		goto end_IL_043c_2;
																		continue;
																		end_IL_041c_2:
																		break;
																		IL_041c_2:;
																	}
																	break;
																}
																goto IL_0665_2;
																IL_09ef_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																break;
																IL_0665_2:
																if (16 >= b)
																{
																	goto IL_0673_2;
																}
																goto IL_090a_2;
																IL_0673_2:
																if (16 > b)
																{
																	goto IL_0681_2;
																}
																goto IL_0721_2;
																IL_0681_2:
																if (13 < b)
																{
																	goto IL_068f_2;
																}
																goto IL_0768_2;
																IL_068f_2:
																if (14 < b)
																{
																	goto IL_069d_2;
																}
																goto IL_08af_2;
																IL_069d_2:
																if (15 < b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_06ab_2;
																IL_06ab_2:
																if (15 > b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_06b9_2;
																IL_06b9_2:
																array2[num6] = array2[num6 - 1];
																goto IL_06d1_2;
																IL_06d1_2:
																array4[num6 - 0] = array4[num6 - 1];
																num = 132;
																goto IL_06f8_2;
																IL_06f8_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0a72_2;
																IL_0a72_2:
																array3[num6] = array3[num6 - 1];
																goto IL_0a8a_2;
																IL_0a8a_2:
																num6++;
																break;
																IL_08af_2:
																if (14 > b)
																{
																	num = 85;
																	goto end_IL_043c_2;
																}
																goto IL_08ba_2;
																IL_08ba_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_08e3_2;
																IL_08e3_2:
																array2[num6 - 1] = 5;
																break;
																IL_09d3_2:
																if (21 < b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_09e1_2;
																IL_0768_2:
																if (13 <= b)
																{
																	goto IL_0773_2;
																}
																goto IL_07b2_2;
																IL_0773_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0791_2;
																IL_0791_2:
																ptr2 += 8;
																goto IL_079f_2;
																IL_079f_2:
																num6--;
																break;
																IL_07b2_2:
																if (12 < b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_07c0_2;
																IL_07c0_2:
																if (12 > b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_07ce_2;
																IL_07ce_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_07dd_2;
																}
																goto IL_07eb;
																IL_0721_2:
																array2[num6] = 5;
																goto IL_072f_2;
																IL_072f_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_0747_2;
																IL_0747_2:
																num6++;
																goto IL_0755_2;
																IL_0755_2:
																ptr2 += 8;
																break;
																IL_090a_2:
																if (19 >= b)
																{
																	goto IL_0918_2;
																}
																goto IL_09ac_2;
																IL_0918_2:
																if (19 > b)
																{
																	goto IL_0923_2;
																}
																num = 112;
																goto IL_095b_2;
																IL_0923_2:
																if (17 < b)
																{
																	goto IL_0931_2;
																}
																goto IL_0b67_2;
																IL_0931_2:
																if (18 < b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_093f_2;
																IL_093f_2:
																if (18 > b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_0ae7_2;
																IL_0ae7_2:
																array2[num6 - 1] = 5;
																goto IL_0afb_2;
																IL_0afb_2:
																array3[num6 - 1] = ((delegate*<string[], string>)RSAPKCSKeyExchangeFormatterIsNestedPublic[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0b33_2;
																IL_0b33_2:
																ptr2 += 8;
																break;
																IL_0b67_2:
																if (17 > b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_0b75_2;
																IL_0b75_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0bb3_2;
																IL_0bb3_2:
																num6 -= 3;
																break;
																IL_09e1_2:
																if (21 > b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_09ef_2;
																IL_095b_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																num = 95;
																goto IL_097d_2;
																IL_097d_2:
																array2[num6] = 1;
																goto IL_098b_2;
																IL_098b_2:
																num6++;
																goto IL_0999_2;
																IL_0999_2:
																ptr2 += 16;
																break;
																IL_09ac_2:
																if (20 >= b)
																{
																	goto IL_09b7_2;
																}
																num = 178;
																goto IL_09d3_2;
																IL_09b7_2:
																if (20 > b)
																{
																	goto end_IL_043c_2;
																}
																goto IL_0b46_2;
																IL_0b46_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 61;
																break;
															}
															goto end_IL_044c_2;
															continue;
															end_IL_043c_2:
															break;
															IL_043c_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0d20_2;
													IL_0d2e_2:
													num6++;
													goto IL_0d3c_2;
													IL_0d3c_2:
													ptr2 += 8;
													break;
													IL_0d20_2:
													array2[num6] = 0;
													goto IL_0d2e_2;
													continue;
													end_IL_044c_2:
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0e0d_2;
									IL_0e0d_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0d4a_2:
									break;
								}
								break;
							}
							continue;
							end_IL_088e:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class102()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_4, int int_5)
	{
		int num = 50;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 75;
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComponentCountLimitBinaryHeaderEnum.UCOMIEnumVARIANTTimeZoneInfo);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 7;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02bf:
																		if (b >= 1)
																		{
																			goto IL_019a;
																		}
																		goto IL_028e;
																		IL_028e:
																		while (true)
																		{
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 94;
																			while (true)
																			{
																				if (num != 94)
																				{
																					if (num != 1075)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 8:
																						goto end_IL_028e;
																					case 28:
																						goto IL_01a8;
																					case 1:
																						goto IL_01b3;
																					case 2:
																					case 15:
																						goto IL_01c1;
																					case 16:
																						goto IL_01cc;
																					case 25:
																					case 51:
																						goto IL_01df;
																					case 46:
																						goto IL_01ed;
																					case 53:
																						goto IL_0200;
																					case 20:
																					case 45:
																						goto IL_0217;
																					case 11:
																						goto IL_0222;
																					case 66:
																						goto IL_0232;
																					case 73:
																						goto IL_023f;
																					case 77:
																						goto IL_024a;
																					case 79:
																						goto IL_0257;
																					case 83:
																						goto IL_0267;
																					case 13:
																						goto IL_0275;
																					case 59:
																						goto IL_0280;
																					case 3:
																					case 12:
																					case 19:
																					case 22:
																					case 24:
																					case 26:
																					case 41:
																					case 47:
																					case 48:
																					case 52:
																					case 57:
																					case 58:
																					case 63:
																					case 64:
																					case 76:
																					case 85:
																						goto end_IL_0187;
																					case 34:
																						goto IL_02bf;
																					case 31:
																						goto end_IL_02bf;
																					case 7:
																						goto end_IL_02cf;
																					case 71:
																						goto end_IL_02df;
																					case 42:
																					case 60:
																						goto IL_02f5;
																					case 35:
																						goto IL_031e;
																					case 14:
																						goto IL_0335;
																					case 56:
																					case 61:
																						goto IL_0348;
																					case 37:
																					case 69:
																						goto IL_0364;
																					case 62:
																						goto IL_03ad;
																					case 55:
																						goto IL_03c1;
																					case 74:
																					case 80:
																						goto IL_03d4;
																					case 43:
																						goto IL_0442;
																					case 0:
																					case 82:
																						goto IL_0455;
																					case 4:
																						goto IL_0463;
																					case 68:
																						goto IL_0486;
																					case 32:
																						goto IL_0499;
																					case 44:
																					case 84:
																						goto IL_04b2;
																					case 87:
																						goto IL_04c7;
																					case 72:
																						goto IL_04e5;
																					case 29:
																						goto IL_04f3;
																					case 9:
																					case 10:
																					case 17:
																					case 23:
																					case 27:
																					case 30:
																					case 36:
																					case 39:
																					case 40:
																					case 65:
																					case 86:
																						goto end_IL_02ea;
																					case 67:
																						goto end_IL_0501;
																					case 78:
																						goto end_IL_0514;
																					case 70:
																						goto end_IL_051e;
																					case 75:
																						goto end_IL_0529;
																					case 21:
																						goto end_IL_053e;
																					case 6:
																					case 33:
																						goto end_IL_0553;
																					case 38:
																						goto end_IL_056c;
																					case 5:
																					case 18:
																						goto end_IL_057c;
																					case 49:
																						goto end_IL_058c;
																					case 50:
																						goto end_IL_059c;
																					case 54:
																					case 81:
																						goto IL_05b7;
																					}
																					continue;
																				}
																				array[num5] = 0;
																				goto IL_04e5;
																				IL_04e5:
																				num5++;
																				goto IL_04f3;
																				IL_04f3:
																				ptr2 += 8;
																				goto end_IL_02ea;
																				continue;
																				end_IL_0187:
																				break;
																			}
																			continue;
																			end_IL_028e:
																			break;
																		}
																		goto IL_019a;
																		IL_019a:
																		if (b <= 8)
																		{
																			goto IL_01a8;
																		}
																		goto IL_028e;
																		IL_01a8:
																		if (4 < b)
																		{
																			goto IL_01b3;
																		}
																		goto IL_0200;
																		IL_01b3:
																		if (6 < b)
																		{
																			goto IL_01c1;
																		}
																		goto IL_0267;
																		IL_01c1:
																		if (7 >= b)
																		{
																			goto IL_01cc;
																		}
																		goto IL_01df;
																		IL_01cc:
																		if (7 > b)
																		{
																			goto IL_028e;
																		}
																		goto IL_0455;
																		IL_0455:
																		array[num5] = 0;
																		goto IL_0463;
																		IL_0463:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0486;
																		IL_0486:
																		array2[num5] = null;
																		num = 32;
																		goto IL_0499;
																		IL_0499:
																		num5++;
																		num = 87;
																		goto IL_04c7;
																		IL_04c7:
																		ptr2 += 8;
																		goto end_IL_02ea;
																		IL_01df:
																		if (8 >= b)
																		{
																			goto IL_01ed;
																		}
																		goto IL_028e;
																		IL_01ed:
																		if (8 > b)
																		{
																			goto IL_028e;
																		}
																		goto IL_0348;
																		IL_0348:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_02ea;
																		IL_0267:
																		if (6 <= b)
																		{
																			goto end_IL_02ea;
																		}
																		goto IL_0275;
																		IL_0275:
																		if (5 >= b)
																		{
																			goto IL_0280;
																		}
																		goto IL_028e;
																		IL_0280:
																		if (5 > b)
																		{
																			goto IL_028e;
																		}
																		goto IL_04b2;
																		IL_04b2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_02ea;
																		IL_0200:
																		if (4 > b)
																		{
																			num = 20;
																			goto IL_0217;
																		}
																		goto IL_02f5;
																		IL_0335:
																		num5--;
																		goto end_IL_02ea;
																		IL_0217:
																		if (2 >= b)
																		{
																			goto IL_0222;
																		}
																		goto IL_0232;
																		IL_0222:
																		if (2 > b)
																		{
																			goto IL_023f;
																		}
																		goto IL_03d4;
																		IL_03d4:
																		ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0442;
																		IL_0442:
																		num5 -= 2;
																		goto end_IL_02ea;
																		IL_023f:
																		if (1 >= b)
																		{
																			goto IL_024a;
																		}
																		goto IL_028e;
																		IL_024a:
																		if (1 <= b)
																		{
																		}
																		goto IL_028e;
																		IL_0232:
																		if (3 >= b)
																		{
																			goto IL_0257;
																		}
																		goto IL_028e;
																		IL_0257:
																		if (3 > b)
																		{
																			goto IL_028e;
																		}
																		goto IL_0364;
																		IL_0364:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		num = 62;
																		goto IL_03ad;
																		IL_03ad:
																		array[num5 - 2] = 0;
																		goto IL_03c1;
																		IL_03c1:
																		num5--;
																		goto end_IL_02ea;
																		IL_02f5:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_031e;
																		IL_031e:
																		ptr2 += 8;
																		num = 14;
																		goto IL_0335;
																		continue;
																		end_IL_02bf:
																		break;
																	}
																	continue;
																	end_IL_02cf:
																	break;
																}
																continue;
																end_IL_02df:
																break;
															}
															continue;
															end_IL_02ea:
															break;
														}
														continue;
													}
													goto IL_05b7;
													IL_05b7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0501:
													break;
												}
												continue;
												end_IL_0514:
												break;
											}
											continue;
											end_IL_051e:
											break;
										}
										continue;
										end_IL_0529:
										break;
									}
									continue;
									end_IL_053e:
									break;
								}
								continue;
								end_IL_0553:
								break;
							}
							continue;
							end_IL_056c:
							break;
						}
						continue;
						end_IL_057c:
						break;
					}
					continue;
					end_IL_058c:
					break;
				}
				continue;
				end_IL_059c:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_4)
	{
		int num = 92;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 91;
			while (true)
			{
				int num3 = num2 * 4;
				num = 15;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref headLowsetCreationTime.encoderResetAccessRule);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02b4:
														num = 78;
														while (true)
														{
															IL_02a0:
															byte b = *ptr2;
															num = 52;
															while (true)
															{
																IL_0290:
																ptr2++;
																while (true)
																{
																	IL_0280:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0260:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0250:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0240:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0233:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0223:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														while (2 <= b)
																														{
																															num = 116;
																															while (true)
																															{
																																if (num != 116)
																																{
																																	if (num != 1097)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 23:
																																		goto IL_0200;
																																	case 17:
																																		goto IL_0213;
																																	case 69:
																																		goto IL_0223;
																																	case 60:
																																		goto IL_0233;
																																	case 2:
																																		goto IL_0240;
																																	case 50:
																																		goto IL_0250;
																																	case 95:
																																		goto IL_0260;
																																	case 19:
																																		goto IL_0270;
																																	case 33:
																																		goto IL_0280;
																																	case 52:
																																		goto IL_0290;
																																	case 78:
																																		goto IL_02a0;
																																	case 74:
																																		goto IL_02b4;
																																	case 10:
																																	case 26:
																																		goto IL_02bf;
																																	case 38:
																																		goto IL_02d7;
																																	case 57:
																																	case 61:
																																		goto IL_02ee;
																																	case 62:
																																		goto IL_0307;
																																	case 20:
																																		goto IL_0315;
																																	case 1:
																																	case 66:
																																		goto IL_0325;
																																	case 16:
																																		goto IL_0330;
																																	case 24:
																																		goto IL_0343;
																																	case 83:
																																		goto IL_0353;
																																	case 99:
																																		goto IL_0366;
																																	case 55:
																																	case 80:
																																		goto IL_0374;
																																	case 7:
																																		goto IL_0382;
																																	case 65:
																																		goto IL_03a5;
																																	case 48:
																																		goto IL_03af;
																																	case 41:
																																		goto IL_03bd;
																																	case 104:
																																		goto IL_03d0;
																																	case 59:
																																		goto IL_03f9;
																																	case 21:
																																		goto IL_0407;
																																	case 8:
																																	case 96:
																																		goto IL_041a;
																																	case 81:
																																		goto IL_0463;
																																	case 5:
																																		goto IL_0477;
																																	case 86:
																																	case 98:
																																		goto IL_049c;
																																	case 88:
																																		goto IL_04aa;
																																	case 53:
																																		goto IL_04b8;
																																	case 64:
																																	case 107:
																																		goto IL_04c3;
																																	case 103:
																																		goto IL_04d1;
																																	case 63:
																																	case 90:
																																		goto IL_04e8;
																																	case 31:
																																		goto IL_050b;
																																	case 30:
																																		goto IL_0519;
																																	case 72:
																																		goto IL_0527;
																																	case 43:
																																		goto IL_053a;
																																	case 22:
																																	case 49:
																																		goto IL_0548;
																																	case 101:
																																		goto IL_0588;
																																	case 75:
																																		goto IL_059c;
																																	case 45:
																																	case 105:
																																		goto IL_05af;
																																	case 54:
																																		goto IL_0611;
																																	case 70:
																																		goto IL_062a;
																																	case 39:
																																		goto IL_0635;
																																	case 6:
																																	case 35:
																																		goto IL_0649;
																																	case 58:
																																	case 100:
																																		goto IL_0662;
																																	case 94:
																																		goto IL_066d;
																																	case 9:
																																	case 27:
																																	case 29:
																																	case 34:
																																	case 37:
																																	case 42:
																																	case 44:
																																	case 47:
																																	case 51:
																																	case 56:
																																	case 68:
																																	case 73:
																																	case 84:
																																	case 85:
																																	case 87:
																																	case 93:
																																	case 97:
																																	case 102:
																																		goto end_IL_0200;
																																	case 4:
																																	case 12:
																																	case 14:
																																	case 18:
																																	case 25:
																																	case 28:
																																	case 36:
																																	case 40:
																																	case 71:
																																	case 76:
																																	case 79:
																																	case 82:
																																	case 106:
																																	case 109:
																																		goto end_IL_01ed;
																																	case 32:
																																		goto end_IL_068b;
																																	case 89:
																																		goto end_IL_069e;
																																	case 108:
																																		goto end_IL_06a8;
																																	case 11:
																																		goto end_IL_06b3;
																																	case 46:
																																	case 77:
																																		goto end_IL_06c8;
																																	case 67:
																																		goto end_IL_06d8;
																																	case 13:
																																	case 15:
																																		goto end_IL_06e8;
																																	case 91:
																																		goto end_IL_06f8;
																																	case 92:
																																		goto end_IL_0708;
																																	case 0:
																																	case 3:
																																		goto IL_0735;
																																	}
																																	continue;
																																}
																																goto IL_03d0;
																																IL_03f9:
																																ptr2 += 8;
																																goto IL_0407;
																																IL_0407:
																																num5--;
																																break;
																																IL_03d0:
																																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																goto IL_03f9;
																																continue;
																																end_IL_01ed:
																																break;
																															}
																															goto end_IL_0280;
																															continue;
																															end_IL_0200:
																															break;
																															IL_0200:;
																														}
																														break;
																														IL_0213:;
																													}
																													break;
																												}
																												goto IL_02d7;
																												IL_0315:
																												num5++;
																												goto IL_0353;
																												IL_02d7:
																												if (1 > b)
																												{
																													break;
																												}
																												num = 61;
																												goto IL_02ee;
																												IL_0353:
																												ptr2 += 8;
																												goto end_IL_0280;
																												IL_02ee:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_0307;
																												IL_0307:
																												array[num5] = 0;
																												goto IL_0315;
																											}
																											break;
																										}
																										goto IL_02bf;
																										IL_02bf:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_0280;
																									}
																									break;
																								}
																								goto IL_0325;
																								IL_03bd:
																								ptr2 += 8;
																								goto end_IL_0280;
																								IL_0325:
																								if (4 >= b)
																								{
																									goto IL_0330;
																								}
																								goto IL_0343;
																								IL_0330:
																								if (4 <= b)
																								{
																									goto end_IL_0280;
																								}
																								break;
																								IL_0343:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_0366;
																								IL_0366:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_0374;
																								IL_0374:
																								array[num5] = 0;
																								goto IL_0382;
																								IL_0382:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03a5;
																								IL_03a5:
																								array2[num5] = null;
																								goto IL_03af;
																								IL_03af:
																								num5++;
																								goto IL_03bd;
																							}
																							break;
																						}
																						goto IL_041a;
																						IL_0477:
																						num5--;
																						num = 109;
																						goto end_IL_0280;
																						IL_041a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 81;
																						goto IL_0463;
																						IL_0463:
																						array[num5 - 2] = 0;
																						goto IL_0477;
																					}
																					break;
																				}
																				num = 86;
																				goto IL_049c;
																				IL_066d:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_0649:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0280;
																				IL_049c:
																				if (9 >= b)
																				{
																					goto IL_04aa;
																				}
																				goto IL_062a;
																				IL_04aa:
																				if (9 > b)
																				{
																					goto IL_04b8;
																				}
																				goto IL_05af;
																				IL_04b8:
																				if (7 < b)
																				{
																					goto IL_04c3;
																				}
																				goto IL_053a;
																				IL_04c3:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_04d1;
																				IL_04d1:
																				if (8 > b)
																				{
																					break;
																				}
																				num = 90;
																				goto IL_04e8;
																				IL_0662:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_066d;
																				IL_04e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_050b;
																				IL_050b:
																				array[num5] = 0;
																				goto IL_0519;
																				IL_0519:
																				num5++;
																				goto IL_0527;
																				IL_0527:
																				ptr2 += 8;
																				goto end_IL_0280;
																				IL_053a:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0548;
																				IL_0548:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0588;
																				IL_0588:
																				array[num5 - 2] = 0;
																				goto IL_059c;
																				IL_059c:
																				num5--;
																				goto end_IL_0280;
																				IL_05af:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0611;
																				IL_0611:
																				num5 -= 2;
																				num = 36;
																				goto end_IL_0280;
																				IL_062a:
																				if (10 >= b)
																				{
																					goto IL_0635;
																				}
																				goto IL_0662;
																				IL_0635:
																				if (10 > b)
																				{
																					break;
																				}
																				num = 6;
																				goto IL_0649;
																			}
																			break;
																			IL_0270:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0280:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0735;
												IL_0735:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068b:
												break;
											}
											continue;
											end_IL_069e:
											break;
										}
										continue;
										end_IL_06a8:
										break;
									}
									continue;
									end_IL_06b3:
									break;
								}
								continue;
								end_IL_06c8:
								break;
							}
							continue;
							end_IL_06d8:
							break;
						}
						continue;
						end_IL_06e8:
						break;
					}
					continue;
					end_IL_06f8:
					break;
				}
				continue;
				end_IL_0708:
				break;
			}
		}
	}

	private unsafe static int smethod_15()
	{
		int num = 109;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 136;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDaygetPercentNegativePattern.DispatchChannelSinkProviderDictionaryValueEnumerator);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_087a:
												if (num4 != 1)
												{
													goto IL_000e;
												}
												num = 153;
												while (true)
												{
													if (num != 153)
													{
														if (num != 1134)
														{
															break;
														}
														switch (num)
														{
														case 76:
														case 128:
															break;
														case 133:
															goto IL_0017;
														case 145:
															goto IL_0025;
														case 115:
															goto IL_0033;
														case 101:
															goto IL_0041;
														case 122:
															goto IL_004f;
														case 9:
															goto IL_005d;
														case 112:
															goto IL_006b;
														case 47:
														case 79:
															goto IL_0079;
														case 17:
															goto IL_0087;
														case 69:
														case 102:
															goto end_IL_0867;
														case 8:
															goto IL_00d2;
														case 74:
															goto IL_00e6;
														case 0:
															goto IL_00f9;
														case 139:
															goto IL_0107;
														case 77:
														case 129:
															goto IL_0115;
														case 87:
															goto IL_012e;
														case 124:
															goto IL_013c;
														case 1:
															goto IL_014a;
														case 80:
														case 114:
															goto IL_015d;
														case 28:
															goto IL_0174;
														case 35:
														case 111:
															goto IL_0182;
														case 13:
															goto IL_01ab;
														case 29:
														case 146:
															goto IL_01c4;
														case 85:
															goto IL_01e2;
														case 49:
															goto IL_01f0;
														case 67:
															goto IL_0203;
														case 38:
														case 90:
															goto IL_020e;
														case 126:
															goto IL_021c;
														case 31:
														case 105:
															goto IL_022a;
														case 40:
															goto IL_0253;
														case 70:
															goto IL_0261;
														case 116:
															goto IL_0274;
														case 11:
														case 119:
															goto IL_027f;
														case 10:
															goto IL_028d;
														case 54:
														case 95:
															goto IL_029b;
														case 42:
															goto IL_02a9;
														case 44:
															goto IL_02c1;
														case 15:
															goto IL_02cf;
														case 18:
														case 65:
															goto IL_02e2;
														case 131:
															goto IL_0321;
														case 99:
														case 107:
															goto IL_0334;
														case 20:
														case 132:
															goto IL_034c;
														case 48:
															goto IL_035a;
														case 33:
															goto IL_0365;
														case 89:
															goto IL_0373;
														case 6:
															goto IL_038f;
														case 81:
														case 110:
															goto IL_039a;
														case 53:
															goto IL_03b6;
														case 135:
															goto IL_03c4;
														case 19:
														case 143:
															goto IL_03d2;
														case 37:
															goto IL_0434;
														case 75:
															goto IL_0447;
														case 130:
														case 140:
															goto IL_045e;
														case 4:
														case 98:
															goto IL_046c;
														case 92:
															goto IL_047a;
														case 12:
														case 14:
															goto IL_0488;
														case 104:
															goto IL_04cc;
														case 27:
															goto IL_04e0;
														case 125:
															goto IL_04f3;
														case 7:
														case 63:
															goto IL_04fe;
														case 117:
															goto IL_050c;
														case 93:
															goto IL_052f;
														case 82:
															goto IL_0539;
														case 43:
															goto IL_0547;
														case 56:
														case 68:
															goto IL_055a;
														case 62:
															goto IL_0565;
														case 59:
														case 88:
															goto IL_0575;
														case 25:
															goto IL_05b5;
														case 55:
															goto IL_05c9;
														case 5:
														case 22:
														case 23:
														case 26:
														case 32:
														case 34:
														case 36:
														case 41:
														case 45:
														case 51:
														case 52:
														case 60:
														case 66:
														case 72:
														case 73:
														case 78:
														case 86:
														case 100:
														case 118:
														case 121:
														case 127:
														case 134:
														case 141:
														case 142:
														case 144:
															goto IL_05dc;
														default:
															continue;
														case 2:
														case 16:
														case 21:
														case 30:
														case 39:
														case 58:
														case 61:
														case 64:
														case 71:
														case 84:
														case 91:
														case 94:
														case 96:
														case 97:
														case 106:
														case 113:
														case 123:
														case 138:
															goto IL_087a;
														case 24:
															goto end_IL_087a;
														case 83:
															goto end_IL_088d;
														case 120:
															goto end_IL_0897;
														case 136:
															goto end_IL_08a2;
														case 50:
														case 103:
															goto end_IL_08b2;
														case 46:
															goto end_IL_08c2;
														case 57:
														case 137:
															goto end_IL_08db;
														case 108:
															goto end_IL_08eb;
														case 109:
															goto end_IL_08fb;
														case 3:
															goto IL_0916;
														}
														goto IL_000e;
													}
													goto IL_0916;
													IL_0916:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0867:
													break;
												}
												goto IL_0092;
												IL_0565:
												if (9 <= b)
												{
													continue;
												}
												goto IL_05dc;
												IL_0575:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_05b5;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												goto IL_05dc;
												IL_0033:
												if (b <= 15)
												{
													goto IL_0041;
												}
												goto IL_05dc;
												IL_0041:
												if (8 >= b)
												{
													goto IL_004f;
												}
												goto IL_034c;
												IL_004f:
												if (8 > b)
												{
													goto IL_005d;
												}
												goto IL_0334;
												IL_005d:
												if (4 >= b)
												{
													goto IL_006b;
												}
												goto IL_0203;
												IL_006b:
												if (4 > b)
												{
													goto IL_0079;
												}
												goto IL_01c4;
												IL_0079:
												if (2 >= b)
												{
													goto IL_0087;
												}
												goto IL_015d;
												IL_0087:
												if (2 <= b)
												{
													goto IL_0092;
												}
												goto IL_00f9;
												IL_0092:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_00d2;
												IL_00d2:
												array[num5 - 2] = 0;
												goto IL_00e6;
												IL_00e6:
												num5--;
												continue;
												IL_00f9:
												if (1 >= b)
												{
													goto IL_0107;
												}
												goto IL_05dc;
												IL_0107:
												if (1 <= b)
												{
													goto IL_0115;
												}
												goto IL_05dc;
												IL_0115:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_012e;
												IL_012e:
												array[num5] = 0;
												goto IL_013c;
												IL_013c:
												num5++;
												goto IL_014a;
												IL_014a:
												ptr2 += 8;
												continue;
												IL_015d:
												if (3 >= b)
												{
													num = 28;
													goto IL_0174;
												}
												goto IL_05dc;
												IL_05b5:
												array[num5 - 2] = 0;
												goto IL_05c9;
												IL_0174:
												if (3 <= b)
												{
													goto IL_0182;
												}
												goto IL_05dc;
												IL_0182:
												array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
												goto IL_01ab;
												IL_01ab:
												array[num5 - 1] = 5;
												continue;
												IL_01c4:
												array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
												goto IL_01e2;
												IL_01e2:
												ptr2 += 8;
												goto IL_01f0;
												IL_01f0:
												num5--;
												continue;
												IL_0203:
												if (6 < b)
												{
													goto IL_020e;
												}
												goto IL_0274;
												IL_020e:
												if (7 >= b)
												{
													goto IL_021c;
												}
												goto IL_05dc;
												IL_021c:
												if (7 <= b)
												{
													goto IL_022a;
												}
												goto IL_05dc;
												IL_022a:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0253;
												IL_0253:
												ptr2 += 8;
												goto IL_0261;
												IL_0261:
												num5--;
												continue;
												IL_0274:
												if (6 > b)
												{
													goto IL_027f;
												}
												goto IL_02e2;
												IL_027f:
												if (5 >= b)
												{
													goto IL_028d;
												}
												goto IL_05dc;
												IL_028d:
												if (5 <= b)
												{
													goto IL_029b;
												}
												goto IL_05dc;
												IL_029b:
												array[num5] = 5;
												goto IL_02a9;
												IL_02a9:
												array2[num5] = array5[*(int*)(ptr2 + num3)];
												goto IL_02c1;
												IL_02c1:
												num5++;
												goto IL_02cf;
												IL_02cf:
												ptr2 += 8;
												continue;
												IL_02e2:
												((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0321;
												IL_0321:
												num5 -= 3;
												continue;
												IL_0334:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_034c:
												if (12 < b)
												{
													goto IL_035a;
												}
												goto IL_0447;
												IL_035a:
												if (14 < b)
												{
													goto IL_0365;
												}
												num = 6;
												goto IL_038f;
												IL_0365:
												if (15 >= b)
												{
													goto IL_0373;
												}
												goto IL_05dc;
												IL_0373:
												if (15 > b)
												{
												}
												goto IL_05dc;
												IL_05c9:
												num5--;
												continue;
												IL_038f:
												if (14 <= b)
												{
													goto IL_039a;
												}
												goto IL_03b6;
												IL_039a:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_03b6:
												if (13 >= b)
												{
													goto IL_03c4;
												}
												goto IL_05dc;
												IL_03c4:
												if (13 <= b)
												{
													goto IL_03d2;
												}
												goto IL_05dc;
												IL_03d2:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0434;
												IL_0434:
												num5 -= 2;
												continue;
												IL_0447:
												if (12 > b)
												{
													num = 130;
													goto IL_045e;
												}
												goto IL_0575;
												IL_05dc:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_045e:
												if (10 < b)
												{
													goto IL_046c;
												}
												goto IL_04f3;
												IL_046c:
												if (11 >= b)
												{
													goto IL_047a;
												}
												goto IL_05dc;
												IL_047a:
												if (11 <= b)
												{
													goto IL_0488;
												}
												goto IL_05dc;
												IL_0488:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
												goto IL_04cc;
												IL_04cc:
												array[num5 - 2] = 0;
												goto IL_04e0;
												IL_04e0:
												num5--;
												continue;
												IL_04f3:
												if (10 <= b)
												{
													goto IL_04fe;
												}
												goto IL_055a;
												IL_04fe:
												array[num5] = 0;
												goto IL_050c;
												IL_050c:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_052f;
												IL_052f:
												array2[num5] = null;
												goto IL_0539;
												IL_0539:
												num5++;
												goto IL_0547;
												IL_0547:
												ptr2 += 8;
												continue;
												IL_055a:
												if (9 >= b)
												{
													goto IL_0565;
												}
												goto IL_05dc;
												continue;
												end_IL_087a:
												break;
											}
											continue;
											end_IL_088d:
											break;
										}
										continue;
										end_IL_0897:
										break;
									}
									continue;
									end_IL_08a2:
									break;
								}
								continue;
								end_IL_08b2:
								break;
							}
							continue;
							end_IL_08c2:
							break;
						}
						continue;
						end_IL_08db:
						break;
					}
					continue;
					end_IL_08eb:
					break;
				}
				continue;
				end_IL_08fb:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_4, int int_5)
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VTUNKNOWNNoName.getDeploymentProviderCodebaseTryGetTarget);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0303:
															num = 15;
															while (true)
															{
																IL_02ef:
																byte b = *ptr2;
																num = 60;
																while (true)
																{
																	IL_02df:
																	ptr2++;
																	while (true)
																	{
																		IL_02cf:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_02af:
																					if (6 >= b)
																					{
																						while (6 > b)
																						{
																							while (true)
																							{
																								IL_0292:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0282:
																										if (4 >= b)
																										{
																											while (4 <= b)
																											{
																												while (true)
																												{
																													IL_0247:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_022e:
																														ptr2 += 8;
																														num = 131;
																														while (true)
																														{
																															if (num != 131)
																															{
																																if (num != 1112)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 86:
																																	goto IL_022e;
																																case 20:
																																case 72:
																																	goto IL_0247;
																																case 59:
																																	goto IL_0272;
																																case 94:
																																	goto IL_0282;
																																case 17:
																																case 119:
																																	goto IL_0292;
																																case 101:
																																	goto IL_029f;
																																case 88:
																																	goto IL_02af;
																																case 58:
																																	goto IL_02bf;
																																case 41:
																																	goto IL_02cf;
																																case 60:
																																	goto IL_02df;
																																case 15:
																																	goto IL_02ef;
																																case 38:
																																	goto IL_0303;
																																case 52:
																																	goto IL_030e;
																																case 37:
																																case 66:
																																	goto IL_031c;
																																case 74:
																																case 75:
																																	goto IL_036a;
																																case 1:
																																	goto IL_0378;
																																case 83:
																																	goto IL_0386;
																																case 49:
																																case 67:
																																	goto IL_0391;
																																case 18:
																																case 87:
																																	goto IL_03a4;
																																case 48:
																																	goto IL_03b2;
																																case 8:
																																case 98:
																																	goto IL_03c0;
																																case 80:
																																	goto IL_03d4;
																																case 54:
																																	goto IL_0413;
																																case 100:
																																	goto IL_0426;
																																case 47:
																																	goto IL_043a;
																																case 44:
																																case 106:
																																	goto IL_044d;
																																case 61:
																																	goto IL_0458;
																																case 25:
																																	goto IL_046b;
																																case 53:
																																	goto IL_0479;
																																case 107:
																																	goto IL_0495;
																																case 16:
																																case 103:
																																	goto IL_04ac;
																																case 45:
																																	goto IL_04ba;
																																case 0:
																																	goto IL_04c8;
																																case 32:
																																case 77:
																																	goto IL_04d6;
																																case 7:
																																	goto IL_04ef;
																																case 93:
																																	goto IL_04fd;
																																case 102:
																																	goto IL_050b;
																																case 12:
																																case 108:
																																	goto IL_051e;
																																case 104:
																																	goto IL_058c;
																																case 42:
																																case 112:
																																	goto IL_059f;
																																case 30:
																																	goto IL_05ad;
																																case 35:
																																case 82:
																																	goto IL_05bb;
																																case 92:
																																case 115:
																																	goto IL_05d7;
																																case 22:
																																	goto IL_0617;
																																case 76:
																																	goto IL_062b;
																																case 121:
																																	goto IL_063e;
																																case 3:
																																case 109:
																																	goto IL_064c;
																																case 33:
																																	goto IL_065a;
																																case 34:
																																	goto IL_0686;
																																case 95:
																																	goto IL_0690;
																																case 111:
																																	goto IL_069e;
																																case 96:
																																	goto IL_06c4;
																																case 120:
																																	goto IL_06cf;
																																case 70:
																																case 110:
																																	goto IL_06da;
																																case 2:
																																case 5:
																																case 9:
																																case 14:
																																case 19:
																																case 21:
																																case 23:
																																case 24:
																																case 27:
																																case 40:
																																case 43:
																																case 46:
																																case 50:
																																case 51:
																																case 56:
																																case 57:
																																case 81:
																																case 91:
																																case 97:
																																case 99:
																																case 117:
																																case 118:
																																case 124:
																																	goto end_IL_0272;
																																case 78:
																																	goto IL_071b;
																																case 113:
																																	goto IL_0729;
																																case 114:
																																	goto IL_0737;
																																case 4:
																																case 10:
																																case 13:
																																case 28:
																																case 29:
																																case 31:
																																case 36:
																																case 55:
																																case 62:
																																case 63:
																																case 79:
																																case 90:
																																case 105:
																																case 116:
																																case 123:
																																	goto end_IL_029f;
																																case 26:
																																	goto end_IL_021b;
																																case 64:
																																	goto end_IL_0758;
																																case 71:
																																	goto end_IL_0762;
																																case 122:
																																	goto end_IL_076d;
																																case 39:
																																	goto end_IL_0782;
																																case 11:
																																case 68:
																																	goto end_IL_0797;
																																case 6:
																																	goto end_IL_07a7;
																																case 69:
																																case 73:
																																	goto end_IL_07b7;
																																case 84:
																																	goto end_IL_07c7;
																																case 85:
																																	goto end_IL_07d7;
																																case 65:
																																case 89:
																																	goto IL_07f2;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_029f;
																															continue;
																															end_IL_021b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_0745;
																												continue;
																												end_IL_0272:
																												break;
																												IL_0272:;
																											}
																											break;
																										}
																										goto IL_06c4;
																										IL_06da:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_029f;
																										IL_06c4:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_06cf;
																										IL_06cf:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_06da;
																									}
																									break;
																								}
																								goto IL_030e;
																								IL_051e:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_058c;
																								IL_030e:
																								if (3 <= b)
																								{
																									goto IL_031c;
																								}
																								goto IL_044d;
																								IL_031c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 100;
																								goto IL_0426;
																								IL_0426:
																								array[num5 - 2] = 0;
																								goto IL_043a;
																								IL_043a:
																								num5--;
																								goto end_IL_029f;
																								IL_044d:
																								if (1 >= b)
																								{
																									goto IL_0458;
																								}
																								goto IL_046b;
																								IL_0458:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_046b:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_0479;
																								IL_0479:
																								if (2 > b)
																								{
																									break;
																								}
																								num = 108;
																								goto IL_051e;
																								IL_058c:
																								num5 -= 2;
																								goto end_IL_029f;
																							}
																							goto end_IL_02bf;
																							continue;
																							end_IL_029f:
																							break;
																							IL_029f:;
																						}
																						break;
																					}
																					goto IL_036a;
																					IL_0617:
																					array[num5 - 2] = 0;
																					goto IL_062b;
																					IL_036a:
																					if (9 < b)
																					{
																						goto IL_0378;
																					}
																					goto IL_0495;
																					IL_0378:
																					if (11 >= b)
																					{
																						goto IL_0386;
																					}
																					goto IL_059f;
																					IL_0386:
																					if (11 <= b)
																					{
																						goto IL_0391;
																					}
																					goto IL_03a4;
																					IL_0391:
																					num5--;
																					break;
																					IL_03a4:
																					if (10 < b)
																					{
																						goto end_IL_02bf;
																					}
																					goto IL_03b2;
																					IL_03b2:
																					if (10 > b)
																					{
																						goto end_IL_02bf;
																					}
																					goto IL_03c0;
																					IL_03c0:
																					array[num5 - 1] = 0;
																					goto IL_03d4;
																					IL_03d4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ServerSecurityNumLockOn[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0413;
																					IL_0413:
																					ptr2 += 8;
																					break;
																					IL_059f:
																					if (12 < b)
																					{
																						goto end_IL_02bf;
																					}
																					goto IL_05ad;
																					IL_05ad:
																					if (12 > b)
																					{
																						goto end_IL_02bf;
																					}
																					goto IL_05bb;
																					IL_05bb:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0495:
																					if (9 > b)
																					{
																						num = 103;
																						goto IL_04ac;
																					}
																					goto IL_05d7;
																					IL_062b:
																					num5--;
																					break;
																					IL_04ac:
																					if (7 < b)
																					{
																						goto IL_04ba;
																					}
																					goto IL_063e;
																					IL_04ba:
																					if (8 < b)
																					{
																						goto end_IL_02bf;
																					}
																					goto IL_04c8;
																					IL_04c8:
																					if (8 > b)
																					{
																						goto end_IL_02bf;
																					}
																					goto IL_04d6;
																					IL_04d6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_04ef;
																					IL_04ef:
																					array[num5] = 0;
																					goto IL_04fd;
																					IL_04fd:
																					num5++;
																					goto IL_050b;
																					IL_050b:
																					ptr2 += 8;
																					break;
																					IL_063e:
																					if (7 > b)
																					{
																						goto end_IL_02bf;
																					}
																					goto IL_064c;
																					IL_064c:
																					array[num5] = 0;
																					goto IL_065a;
																					IL_065a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					num = 34;
																					goto IL_0686;
																					IL_0686:
																					array2[num5] = null;
																					goto IL_0690;
																					IL_0690:
																					num5++;
																					goto IL_069e;
																					IL_069e:
																					ptr2 += 8;
																					break;
																					IL_05d7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0617;
																				}
																				goto end_IL_02cf;
																				continue;
																				end_IL_02bf:
																				break;
																				IL_02bf:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 78;
																		goto IL_071b;
																		IL_0737:
																		ptr2 += 8;
																		break;
																		IL_0729:
																		num5++;
																		goto IL_0737;
																		IL_071b:
																		array[num5] = 0;
																		goto IL_0729;
																		continue;
																		end_IL_02cf:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07f2;
													IL_07f2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0745:
													break;
												}
												continue;
												end_IL_0758:
												break;
											}
											continue;
											end_IL_0762:
											break;
										}
										continue;
										end_IL_076d:
										break;
									}
									continue;
									end_IL_0782:
									break;
								}
								continue;
								end_IL_0797:
								break;
							}
							continue;
							end_IL_07a7:
							break;
						}
						continue;
						end_IL_07b7:
						break;
					}
					continue;
					end_IL_07c7:
					break;
				}
				continue;
				end_IL_07d7:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_4)
	{
		int num = 53;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetManifestResourceNamesAddResourceFile.RemoveAuditRuleContextProperties);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 29;
											while (true)
											{
												IL_0653:
												if (num4 != 1)
												{
													goto IL_000e;
												}
												num = 122;
												while (true)
												{
													if (num != 122)
													{
														if (num != 1103)
														{
															break;
														}
														switch (num)
														{
														case 47:
														case 92:
															break;
														case 19:
															goto IL_0017;
														case 91:
															goto IL_0025;
														case 115:
															goto IL_0033;
														case 45:
															goto IL_0041;
														case 25:
														case 90:
															goto IL_004f;
														case 86:
														case 106:
															goto IL_005a;
														case 35:
															goto IL_0065;
														case 16:
															goto IL_0073;
														case 56:
															goto IL_008f;
														case 38:
														case 97:
															goto IL_009d;
														case 40:
															goto IL_00b9;
														case 41:
														case 81:
															goto IL_00c4;
														case 96:
															goto IL_0126;
														case 21:
															goto IL_0139;
														case 108:
															goto IL_0144;
														case 36:
														case 110:
															goto IL_0152;
														case 100:
															goto IL_0192;
														case 65:
															goto IL_01a6;
														case 1:
														case 58:
															goto IL_01b9;
														case 5:
															goto IL_01c7;
														case 3:
														case 109:
															goto IL_01d5;
														case 73:
															goto IL_01f8;
														case 43:
															goto IL_0206;
														case 12:
															goto IL_0214;
														case 17:
															goto IL_0227;
														case 51:
														case 74:
															goto IL_0232;
														case 34:
															goto IL_0272;
														case 93:
															goto end_IL_0640;
														case 49:
															goto IL_0299;
														case 10:
															goto IL_02a7;
														case 23:
														case 76:
															goto IL_02b5;
														case 54:
															goto IL_02c0;
														case 59:
														case 70:
															goto IL_02ce;
														case 30:
															goto IL_02e7;
														case 84:
															goto IL_02f5;
														case 27:
															goto IL_0303;
														case 72:
															goto IL_0316;
														case 60:
															goto IL_0324;
														case 20:
														case 39:
															goto IL_0332;
														case 14:
															goto IL_035b;
														case 46:
															goto IL_0369;
														case 63:
														case 67:
															goto IL_037c;
														case 62:
														case 71:
															goto IL_03a6;
														case 101:
														case 114:
															goto IL_03b1;
														case 105:
															goto IL_03bc;
														case 11:
														case 99:
															goto IL_03c7;
														case 82:
															goto IL_03d5;
														case 66:
															goto IL_03f8;
														case 28:
															goto IL_0402;
														case 44:
															goto IL_0410;
														case 78:
															goto IL_0423;
														case 2:
														case 7:
														case 8:
														case 13:
														case 18:
														case 22:
														case 24:
														case 26:
														case 37:
														case 61:
														case 64:
														case 77:
														case 79:
														case 80:
														case 83:
														case 85:
														case 88:
														case 94:
														case 95:
														case 102:
														case 107:
														case 113:
															goto IL_0431;
														default:
															continue;
														case 0:
														case 4:
														case 6:
														case 9:
														case 15:
														case 29:
														case 33:
														case 57:
														case 68:
														case 75:
														case 87:
														case 98:
														case 104:
														case 112:
															goto IL_0653;
														case 69:
															goto end_IL_0653;
														case 48:
															goto end_IL_0666;
														case 31:
															goto end_IL_0679;
														case 111:
															goto end_IL_0684;
														case 89:
														case 103:
															goto end_IL_0699;
														case 50:
															goto end_IL_06a9;
														case 32:
														case 42:
															goto end_IL_06b9;
														case 52:
															goto end_IL_06c9;
														case 53:
															goto end_IL_06d9;
														case 55:
															goto IL_06f4;
														}
														goto IL_000e;
													}
													goto IL_06f4;
													IL_06f4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0640:
													break;
												}
												goto IL_0286;
												IL_0402:
												num5++;
												goto IL_0410;
												IL_0410:
												ptr2 += 8;
												continue;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												goto IL_0431;
												IL_0033:
												if (b <= 11)
												{
													goto IL_0041;
												}
												goto IL_0431;
												IL_0041:
												if (6 < b)
												{
													goto IL_004f;
												}
												goto IL_0227;
												IL_004f:
												if (9 < b)
												{
													goto IL_005a;
												}
												goto IL_00b9;
												IL_005a:
												if (10 < b)
												{
													goto IL_0065;
												}
												num = 56;
												goto IL_008f;
												IL_0065:
												if (11 >= b)
												{
													goto IL_0073;
												}
												goto IL_0431;
												IL_0073:
												if (11 > b)
												{
												}
												goto IL_0431;
												IL_0423:
												if (4 <= b)
												{
													continue;
												}
												goto IL_0431;
												IL_008f:
												if (10 <= b)
												{
													goto IL_009d;
												}
												goto IL_0431;
												IL_009d:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_00b9:
												if (9 <= b)
												{
													goto IL_00c4;
												}
												goto IL_0139;
												IL_00c4:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0126;
												IL_0126:
												num5 -= 2;
												continue;
												IL_0139:
												if (7 >= b)
												{
													goto IL_0144;
												}
												goto IL_01b9;
												IL_0144:
												if (7 <= b)
												{
													goto IL_0152;
												}
												goto IL_0431;
												IL_0152:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0192;
												IL_0192:
												array[num5 - 2] = 0;
												goto IL_01a6;
												IL_01a6:
												num5--;
												continue;
												IL_01b9:
												if (8 >= b)
												{
													goto IL_01c7;
												}
												goto IL_0431;
												IL_01c7:
												if (8 <= b)
												{
													goto IL_01d5;
												}
												goto IL_0431;
												IL_01d5:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_01f8;
												IL_01f8:
												array[num5] = 0;
												goto IL_0206;
												IL_0206:
												num5++;
												goto IL_0214;
												IL_0214:
												ptr2 += 8;
												continue;
												IL_0227:
												if (6 <= b)
												{
													goto IL_0232;
												}
												goto IL_0299;
												IL_0232:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0272;
												IL_0272:
												array[num5 - 2] = 0;
												goto IL_0286;
												IL_0286:
												num5--;
												continue;
												IL_0299:
												if (3 >= b)
												{
													goto IL_02a7;
												}
												num = 62;
												goto IL_03a6;
												IL_02a7:
												if (3 > b)
												{
													goto IL_02b5;
												}
												goto IL_037c;
												IL_02b5:
												if (1 >= b)
												{
													goto IL_02c0;
												}
												goto IL_0316;
												IL_02c0:
												if (1 <= b)
												{
													goto IL_02ce;
												}
												goto IL_0431;
												IL_02ce:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_02e7;
												IL_02e7:
												array[num5] = 0;
												goto IL_02f5;
												IL_02f5:
												num5++;
												goto IL_0303;
												IL_0303:
												ptr2 += 8;
												continue;
												IL_0316:
												if (2 >= b)
												{
													goto IL_0324;
												}
												goto IL_0431;
												IL_0324:
												if (2 <= b)
												{
													goto IL_0332;
												}
												goto IL_0431;
												IL_0332:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_035b;
												IL_035b:
												ptr2 += 8;
												goto IL_0369;
												IL_0369:
												num5--;
												continue;
												IL_037c:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 112;
												continue;
												IL_0431:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_03a6:
												if (4 < b)
												{
													goto IL_03b1;
												}
												goto IL_0423;
												IL_03b1:
												if (5 >= b)
												{
													goto IL_03bc;
												}
												goto IL_0431;
												IL_03bc:
												if (5 <= b)
												{
													goto IL_03c7;
												}
												goto IL_0431;
												IL_03c7:
												array[num5] = 0;
												goto IL_03d5;
												IL_03d5:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_03f8;
												IL_03f8:
												array2[num5] = null;
												goto IL_0402;
												continue;
												end_IL_0653:
												break;
											}
											continue;
											end_IL_0666:
											break;
										}
										continue;
										end_IL_0679:
										break;
									}
									continue;
									end_IL_0684:
									break;
								}
								continue;
								end_IL_0699:
								break;
							}
							continue;
							end_IL_06a9:
							break;
						}
						continue;
						end_IL_06b9:
						break;
					}
					continue;
					end_IL_06c9:
					break;
				}
				continue;
				end_IL_06d9:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_4, int int_5)
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_0584:
					byte[] array = new byte[2];
					num = 8;
					while (true)
					{
						IL_0574:
						object[] array2 = new object[2];
						while (true)
						{
							IL_0564:
							int[] array3 = new int[3];
							while (true)
							{
								IL_0554:
								long[] array4 = new long[2];
								while (true)
								{
									IL_053f:
									array3[0] = int_4;
									while (true)
									{
										IL_052a:
										array3[1] = int_5;
										while (true)
										{
											IL_051f:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BinaryObjectWithMapTypedCOREENDOFSTREAM.getStoreIsInherited);
											while (true)
											{
												IL_0515:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0502:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0223:
															byte b = *ptr2;
															while (true)
															{
																IL_0213:
																ptr2++;
																while (true)
																{
																	IL_0203:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e3:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01d3:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01c3:
																								if (7 >= b)
																								{
																									while (7 <= b)
																									{
																										num = 96;
																										while (true)
																										{
																											if (num != 96)
																											{
																												if (num != 1077)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 4:
																													goto IL_01b0;
																												case 63:
																												case 79:
																													goto IL_01c3;
																												case 53:
																													goto IL_01d3;
																												case 46:
																													goto IL_01e3;
																												case 48:
																													goto IL_01f3;
																												case 55:
																													goto IL_0203;
																												case 13:
																													goto IL_0213;
																												case 50:
																												case 81:
																													goto IL_0223;
																												case 68:
																													goto IL_022e;
																												case 61:
																													goto IL_023c;
																												case 76:
																													goto IL_025f;
																												case 20:
																													goto IL_0269;
																												case 18:
																													goto IL_0277;
																												case 27:
																													goto IL_028a;
																												case 17:
																													goto IL_0298;
																												case 9:
																												case 73:
																													goto IL_02a6;
																												case 57:
																													goto IL_02c2;
																												case 10:
																												case 37:
																													goto IL_02d0;
																												case 78:
																													goto IL_02de;
																												case 32:
																												case 77:
																													goto IL_02ec;
																												case 72:
																													goto IL_0304;
																												case 12:
																													goto IL_0312;
																												case 5:
																													goto IL_0320;
																												case 16:
																												case 19:
																													goto IL_032e;
																												case 83:
																													goto IL_039c;
																												case 40:
																												case 60:
																													goto IL_03b8;
																												case 15:
																													goto IL_03c6;
																												case 25:
																													goto IL_03e2;
																												case 11:
																													goto IL_03f0;
																												case 3:
																												case 70:
																													goto IL_03fe;
																												case 64:
																													goto IL_043e;
																												case 43:
																													goto IL_0452;
																												case 24:
																												case 51:
																													goto IL_0465;
																												case 31:
																													goto IL_048e;
																												case 84:
																													goto IL_049c;
																												case 2:
																												case 14:
																												case 21:
																												case 23:
																												case 26:
																												case 28:
																												case 30:
																												case 34:
																												case 36:
																												case 38:
																												case 39:
																												case 41:
																												case 42:
																												case 66:
																												case 71:
																												case 74:
																												case 75:
																												case 86:
																													goto end_IL_01b0;
																												case 52:
																													goto IL_04d8;
																												case 69:
																													goto IL_04e6;
																												case 87:
																													goto IL_04f4;
																												case 1:
																												case 29:
																												case 33:
																												case 45:
																												case 47:
																												case 49:
																												case 58:
																												case 59:
																												case 62:
																												case 82:
																												case 85:
																													goto IL_0502;
																												case 44:
																													goto IL_0515;
																												case 67:
																													goto IL_051f;
																												case 65:
																													goto IL_052a;
																												case 56:
																													goto IL_053f;
																												case 6:
																													goto IL_0554;
																												case 22:
																												case 35:
																													goto IL_0564;
																												case 8:
																													goto IL_0574;
																												case 7:
																												case 54:
																													goto IL_0584;
																												case 88:
																													goto end_IL_019d;
																												case 89:
																													goto end_IL_059d;
																												case 0:
																												case 80:
																													goto IL_05b8;
																												}
																												continue;
																											}
																											goto IL_022e;
																											IL_0269:
																											num5++;
																											goto IL_0277;
																											IL_0277:
																											ptr2 += 8;
																											goto IL_0502;
																											IL_022e:
																											array[num5] = 0;
																											goto IL_023c;
																											IL_023c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_025f;
																											IL_025f:
																											array2[num5] = null;
																											goto IL_0269;
																											continue;
																											end_IL_019d:
																											break;
																										}
																										goto end_IL_0203;
																										continue;
																										end_IL_01b0:
																										break;
																										IL_01b0:;
																									}
																									break;
																								}
																								goto IL_028a;
																								IL_02a6:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto IL_0502;
																								IL_028a:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_0298;
																								IL_0298:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_02a6;
																							}
																							break;
																						}
																						goto IL_02c2;
																						IL_02ec:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_0502;
																						IL_02c2:
																						if (6 <= b)
																						{
																							goto IL_0502;
																						}
																						goto IL_02d0;
																						IL_02d0:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_02de;
																						IL_02de:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_02ec;
																					}
																					break;
																				}
																				goto IL_0304;
																				IL_0465:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_048e;
																				IL_0304:
																				if (4 > b)
																				{
																					goto IL_0312;
																				}
																				goto IL_0465;
																				IL_0312:
																				if (2 >= b)
																				{
																					goto IL_0320;
																				}
																				goto IL_03e2;
																				IL_0320:
																				if (2 <= b)
																				{
																					goto IL_032e;
																				}
																				num = 60;
																				goto IL_03b8;
																				IL_032e:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_039c;
																				IL_039c:
																				num5 -= 2;
																				goto IL_0502;
																				IL_048e:
																				ptr2 += 8;
																				goto IL_049c;
																				IL_03b8:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_03c6;
																				IL_03c6:
																				if (1 > b)
																				{
																					num = 74;
																				}
																				break;
																				IL_049c:
																				num5--;
																				num = 82;
																				goto IL_0502;
																				IL_03e2:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_03f0;
																				IL_03f0:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_03fe;
																				IL_03fe:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_043e;
																				IL_043e:
																				array[num5 - 2] = 0;
																				goto IL_0452;
																				IL_0452:
																				num5--;
																				goto IL_0502;
																			}
																			break;
																			IL_01f3:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d8;
																	IL_04f4:
																	ptr2 += 8;
																	goto IL_0502;
																	IL_04e6:
																	num5++;
																	goto IL_04f4;
																	IL_04d8:
																	array[num5] = 0;
																	goto IL_04e6;
																	continue;
																	end_IL_0203:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_05b8;
													IL_05b8:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_059d:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_4, int int_5)
	{
		int num = 51;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDateTimeSetLastWriteTimeUtc.EventArgsMarshalerCltUn);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_01f8:
															byte b = *ptr2;
															while (true)
															{
																IL_01e8:
																ptr2++;
																while (true)
																{
																	IL_01d8:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01b5:
																				if (4 >= b)
																				{
																					num = 98;
																					while (true)
																					{
																						if (num != 98)
																						{
																							if (num != 1079)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 12:
																								goto IL_01b5;
																							case 37:
																								goto IL_01c8;
																							case 13:
																								goto IL_01d8;
																							case 76:
																								goto IL_01e8;
																							case 6:
																							case 45:
																								goto IL_01f8;
																							case 7:
																							case 23:
																								goto IL_020e;
																							case 47:
																								goto IL_0237;
																							case 34:
																								goto IL_0245;
																							case 31:
																								goto IL_0258;
																							case 1:
																							case 65:
																								goto IL_0266;
																							case 87:
																								goto IL_0274;
																							case 60:
																							case 75:
																								goto IL_0282;
																							case 48:
																								goto IL_02c2;
																							case 9:
																								goto IL_02d6;
																							case 63:
																								goto IL_02e9;
																							case 25:
																							case 61:
																								goto IL_02f4;
																							case 19:
																								goto IL_0302;
																							case 29:
																							case 85:
																								goto IL_031e;
																							case 77:
																								goto IL_038c;
																							case 91:
																								goto IL_039f;
																							case 36:
																							case 59:
																								goto IL_03ad;
																							case 67:
																							case 68:
																								goto IL_03b8;
																							case 69:
																								goto IL_03c6;
																							case 10:
																							case 84:
																								goto IL_03d4;
																							case 38:
																								goto IL_03f9;
																							case 16:
																							case 20:
																								goto IL_0407;
																							case 64:
																								goto IL_0415;
																							case 56:
																								goto IL_0438;
																							case 81:
																								goto IL_044b;
																							case 90:
																								goto IL_0459;
																							case 32:
																								goto IL_046c;
																							case 80:
																								goto IL_047a;
																							case 46:
																								goto IL_048e;
																							case 28:
																							case 83:
																								goto IL_0499;
																							case 0:
																							case 2:
																							case 5:
																							case 8:
																							case 11:
																							case 17:
																							case 27:
																							case 35:
																							case 41:
																							case 43:
																							case 52:
																							case 54:
																							case 55:
																							case 58:
																							case 62:
																							case 66:
																							case 73:
																							case 74:
																							case 79:
																								goto end_IL_01c8;
																							case 26:
																								goto IL_04da;
																							case 44:
																								goto IL_04e8;
																							case 49:
																								goto IL_04f6;
																							case 4:
																							case 15:
																							case 22:
																							case 24:
																							case 30:
																							case 39:
																							case 40:
																							case 53:
																							case 72:
																							case 86:
																							case 89:
																								goto end_IL_01a5;
																							case 18:
																								goto end_IL_0504;
																							case 82:
																								goto end_IL_0517;
																							case 57:
																								goto end_IL_0521;
																							case 21:
																								goto end_IL_052c;
																							case 33:
																								goto end_IL_0541;
																							case 71:
																							case 88:
																								goto end_IL_0556;
																							case 42:
																								goto end_IL_0566;
																							case 3:
																							case 70:
																								goto end_IL_0576;
																							case 50:
																								goto end_IL_0586;
																							case 51:
																								goto end_IL_0596;
																							case 14:
																							case 78:
																								goto IL_05b1;
																							}
																							continue;
																						}
																						if (4 <= b)
																						{
																							goto IL_020e;
																						}
																						goto IL_0258;
																						IL_0302:
																						if (1 > b)
																						{
																							num = 11;
																						}
																						goto end_IL_01c8;
																						IL_031e:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_038c;
																						IL_038c:
																						num5 -= 2;
																						break;
																						IL_020e:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0237;
																						IL_0237:
																						ptr2 += 8;
																						goto IL_0245;
																						IL_0245:
																						num5--;
																						break;
																						IL_0258:
																						if (2 < b)
																						{
																							goto IL_0266;
																						}
																						goto IL_02e9;
																						IL_0266:
																						if (3 < b)
																						{
																							goto end_IL_01c8;
																						}
																						goto IL_0274;
																						IL_0274:
																						if (3 > b)
																						{
																							goto end_IL_01c8;
																						}
																						goto IL_0282;
																						IL_0282:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02c2;
																						IL_02c2:
																						array[num5 - 2] = 0;
																						goto IL_02d6;
																						IL_02d6:
																						num5--;
																						break;
																						IL_02e9:
																						if (2 > b)
																						{
																							goto IL_02f4;
																						}
																						goto IL_031e;
																						IL_02f4:
																						if (1 < b)
																						{
																							goto end_IL_01c8;
																						}
																						goto IL_0302;
																						continue;
																						end_IL_01a5:
																						break;
																					}
																					break;
																				}
																				goto IL_039f;
																				IL_0499:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 89;
																				break;
																				IL_048e:
																				if (5 > b)
																				{
																					goto end_IL_01c8;
																				}
																				goto IL_0499;
																				IL_039f:
																				if (6 < b)
																				{
																					goto IL_03ad;
																				}
																				goto IL_046c;
																				IL_03ad:
																				if (7 < b)
																				{
																					goto IL_03b8;
																				}
																				goto IL_03f9;
																				IL_03b8:
																				if (8 < b)
																				{
																					goto end_IL_01c8;
																				}
																				goto IL_03c6;
																				IL_03c6:
																				if (8 > b)
																				{
																					goto end_IL_01c8;
																				}
																				goto IL_03d4;
																				IL_03d4:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 22;
																				break;
																				IL_03f9:
																				if (7 > b)
																				{
																					goto end_IL_01c8;
																				}
																				goto IL_0407;
																				IL_0407:
																				array[num5] = 0;
																				goto IL_0415;
																				IL_0415:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0438;
																				IL_0438:
																				array2[num5] = null;
																				num = 81;
																				goto IL_044b;
																				IL_044b:
																				num5++;
																				goto IL_0459;
																				IL_0459:
																				ptr2 += 8;
																				break;
																				IL_046c:
																				if (6 <= b)
																				{
																					break;
																				}
																				goto IL_047a;
																				IL_047a:
																				if (5 < b)
																				{
																					goto end_IL_01c8;
																				}
																				num = 46;
																				goto IL_048e;
																			}
																			goto end_IL_01d8;
																			continue;
																			end_IL_01c8:
																			break;
																			IL_01c8:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04da;
																	IL_04f6:
																	ptr2 += 8;
																	break;
																	IL_04e8:
																	num5++;
																	goto IL_04f6;
																	IL_04da:
																	array[num5] = 0;
																	goto IL_04e8;
																	continue;
																	end_IL_01d8:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05b1;
													IL_05b1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0504:
													break;
												}
												continue;
												end_IL_0517:
												break;
											}
											continue;
											end_IL_0521:
											break;
										}
										continue;
										end_IL_052c:
										break;
									}
									continue;
									end_IL_0541:
									break;
								}
								continue;
								end_IL_0556:
								break;
							}
							continue;
							end_IL_0566:
							break;
						}
						continue;
						end_IL_0576:
						break;
					}
					continue;
					end_IL_0586:
					break;
				}
				continue;
				end_IL_0596:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_4)
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BeginCriticalRegionStrongName.ILAssemblygetWorkingSet);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0291:
														byte b = *ptr2;
														while (true)
														{
															IL_0281:
															ptr2++;
															while (true)
															{
																IL_0271:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0251:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0244:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_0234:
																							array[num5] = 0;
																							while (true)
																							{
																								IL_020f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_0203:
																									array2[num5] = null;
																									while (true)
																									{
																										IL_01f3:
																										num5++;
																										while (true)
																										{
																											IL_01da:
																											ptr2 += 8;
																											num = 110;
																											while (num != 110)
																											{
																												if (num != 1091)
																												{
																													goto IL_0234;
																												}
																												switch (num)
																												{
																												case 48:
																													goto IL_01da;
																												case 79:
																													goto IL_01f3;
																												case 56:
																													goto IL_0203;
																												case 98:
																													goto IL_020f;
																												case 35:
																												case 39:
																													goto IL_0234;
																												case 65:
																													goto IL_0244;
																												case 54:
																													goto IL_0251;
																												case 96:
																													goto IL_0261;
																												case 11:
																													goto IL_0271;
																												case 94:
																													goto IL_0281;
																												case 97:
																												case 102:
																													goto IL_0291;
																												case 99:
																													goto IL_029c;
																												case 24:
																													goto IL_02aa;
																												case 6:
																												case 20:
																													goto IL_02b5;
																												case 34:
																													goto IL_02c3;
																												case 0:
																												case 85:
																													goto IL_02d1;
																												case 45:
																													goto IL_02f3;
																												case 69:
																													goto IL_0301;
																												case 19:
																													goto IL_030f;
																												case 33:
																												case 43:
																													goto IL_0322;
																												case 23:
																													goto IL_034b;
																												case 8:
																													goto IL_0359;
																												case 75:
																													goto IL_036c;
																												case 103:
																													goto IL_0377;
																												case 52:
																												case 68:
																													goto IL_0385;
																												case 81:
																													goto IL_039d;
																												case 90:
																													goto IL_03ab;
																												case 30:
																												case 76:
																													goto IL_03be;
																												case 50:
																													goto IL_03cc;
																												case 41:
																												case 42:
																													goto IL_03da;
																												case 9:
																												case 51:
																													goto IL_03e5;
																												case 101:
																													goto IL_03f3;
																												case 59:
																												case 82:
																													goto IL_0401;
																												case 61:
																													goto IL_0424;
																												case 53:
																													goto IL_0432;
																												case 74:
																													goto IL_0440;
																												case 62:
																													goto IL_0453;
																												case 5:
																												case 73:
																													goto IL_0461;
																												case 14:
																													goto IL_04a1;
																												case 93:
																													goto IL_04be;
																												case 18:
																												case 70:
																													goto IL_04d1;
																												case 71:
																													goto IL_0533;
																												case 92:
																													goto IL_0543;
																												case 25:
																													goto IL_054e;
																												case 31:
																												case 83:
																													goto IL_0559;
																												case 12:
																													goto IL_0572;
																												case 78:
																													goto IL_057d;
																												case 15:
																												case 16:
																												case 21:
																												case 27:
																												case 32:
																												case 38:
																												case 46:
																												case 49:
																												case 55:
																												case 57:
																												case 58:
																												case 60:
																												case 63:
																												case 67:
																												case 80:
																												case 86:
																												case 87:
																												case 95:
																												case 100:
																													goto end_IL_0261;
																												case 2:
																												case 17:
																												case 22:
																												case 26:
																												case 40:
																												case 44:
																												case 64:
																												case 72:
																												case 77:
																												case 88:
																												case 89:
																												case 91:
																													goto end_IL_01c7;
																												case 36:
																													goto end_IL_059b;
																												case 37:
																													goto end_IL_05ae;
																												case 13:
																													goto end_IL_05b8;
																												case 7:
																													goto end_IL_05c3;
																												case 29:
																												case 47:
																													goto end_IL_05d8;
																												case 28:
																													goto end_IL_05e8;
																												case 10:
																												case 66:
																													goto end_IL_05f8;
																												case 3:
																													goto end_IL_0608;
																												case 4:
																													goto end_IL_0618;
																												case 1:
																												case 84:
																													goto IL_0633;
																												}
																												continue;
																												end_IL_01c7:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_029c;
																					IL_03ab:
																					if (4 <= b)
																					{
																						break;
																					}
																					goto end_IL_0261;
																					IL_029c:
																					if (2 >= b)
																					{
																						goto IL_02aa;
																					}
																					goto IL_036c;
																					IL_02aa:
																					if (2 > b)
																					{
																						goto IL_02b5;
																					}
																					goto IL_0322;
																					IL_02b5:
																					if (1 < b)
																					{
																						goto end_IL_0261;
																					}
																					goto IL_02c3;
																					IL_02c3:
																					if (1 > b)
																					{
																						goto end_IL_0261;
																					}
																					goto IL_02d1;
																					IL_02d1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 45;
																					goto IL_02f3;
																					IL_02f3:
																					array[num5] = 0;
																					goto IL_0301;
																					IL_0301:
																					num5++;
																					goto IL_030f;
																					IL_030f:
																					ptr2 += 8;
																					break;
																					IL_0322:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_034b;
																					IL_034b:
																					ptr2 += 8;
																					goto IL_0359;
																					IL_0359:
																					num5--;
																					break;
																					IL_036c:
																					if (3 >= b)
																					{
																						goto IL_0377;
																					}
																					goto IL_039d;
																					IL_0377:
																					if (3 > b)
																					{
																						goto end_IL_0261;
																					}
																					goto IL_0385;
																					IL_0385:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_039d:
																					if (4 < b)
																					{
																						goto end_IL_0261;
																					}
																					goto IL_03ab;
																				}
																				break;
																			}
																			goto IL_03be;
																			IL_057d:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_0261;
																			IL_03be:
																			if (8 >= b)
																			{
																				goto IL_03cc;
																			}
																			goto IL_0543;
																			IL_03cc:
																			if (8 > b)
																			{
																				goto IL_03da;
																			}
																			goto IL_04d1;
																			IL_03da:
																			if (6 < b)
																			{
																				goto IL_03e5;
																			}
																			goto IL_0453;
																			IL_03e5:
																			if (7 < b)
																			{
																				goto end_IL_0261;
																			}
																			goto IL_03f3;
																			IL_03f3:
																			if (7 > b)
																			{
																				goto end_IL_0261;
																			}
																			goto IL_0401;
																			IL_0401:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0424;
																			IL_0424:
																			array[num5] = 0;
																			goto IL_0432;
																			IL_0432:
																			num5++;
																			goto IL_0440;
																			IL_0440:
																			ptr2 += 8;
																			break;
																			IL_0453:
																			if (6 > b)
																			{
																				goto end_IL_0261;
																			}
																			goto IL_0461;
																			IL_0461:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04a1;
																			IL_04a1:
																			array[num5 - 2] = 0;
																			num = 93;
																			goto IL_04be;
																			IL_04be:
																			num5--;
																			break;
																			IL_04d1:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0533;
																			IL_0533:
																			num5 -= 2;
																			break;
																			IL_0543:
																			if (9 >= b)
																			{
																				goto IL_054e;
																			}
																			goto IL_0572;
																			IL_054e:
																			if (9 > b)
																			{
																				goto end_IL_0261;
																			}
																			goto IL_0559;
																			IL_0559:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0572:
																			if (10 < b)
																			{
																				goto end_IL_0261;
																			}
																			goto IL_057d;
																		}
																		goto end_IL_0271;
																		continue;
																		end_IL_0261:
																		break;
																		IL_0261:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0271:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0633;
												IL_0633:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_059b:
												break;
											}
											continue;
											end_IL_05ae:
											break;
										}
										continue;
										end_IL_05b8:
										break;
									}
									continue;
									end_IL_05c3:
									break;
								}
								continue;
								end_IL_05d8:
								break;
							}
							continue;
							end_IL_05e8:
							break;
						}
						continue;
						end_IL_05f8:
						break;
					}
					continue;
					end_IL_0608:
					break;
				}
				continue;
				end_IL_0618:
				break;
			}
		}
	}

	static Class102()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 4:
							case 5:
								goto end_IL_0039;
							case 2:
								goto end_IL_0046;
							case 3:
								goto end_IL_005b;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_005b:
				break;
			}
		}
	}
}
