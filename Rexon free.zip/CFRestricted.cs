using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 37)]
internal struct CFRestricted
{
	internal static CFRestricted TimerTimeSpanResult/* Not supported: data(01 6B 00 00 00 00 00 00 0E 0E 00 00 00 27 6B 0A 6B 0C 6B 2C 6B 1E 6B 05 6B 6B 6B 02 00 00 00 00 00 00 00 00 03) */;
}
