using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Core.Patches;
using UnityEngine;

[Mod("Back Track", "Rig", "Fake lag with delayed rig.", false, 30, ModType.const_0, false)]
internal class Class171 : MonoBehaviour
{
	internal class V3T
	{
		public float float_0;

		public Vector3 vector3_0;

		public Quaternion quaternion_0;

		public V3T(float t, Vector3 p, Quaternion r)
		{
			object obj = this;
			double num = t;
			((V3T)obj).float_0 = (float)num;
			obj = this;
			object obj2 = p;
			((V3T)obj).vector3_0 = (Vector3)obj2;
			obj = this;
			obj2 = r;
			((V3T)obj).quaternion_0 = (Quaternion)obj2;
		}

		static V3T()
		{
			int num = 1;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					num = 9;
					while (true)
					{
						if (num != 9)
						{
							if (num != 990)
							{
								break;
							}
							switch (num)
							{
							case 0:
								goto end_IL_002d;
							case 1:
								goto end_IL_003a;
							case 2:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_002d:
						break;
					}
					continue;
					end_IL_003a:
					break;
				}
			}
		}
	}

	public static float float_0;

	internal static bool bool_0;

	internal static bool bool_1;

	internal static Vector3 vector3_0;

	internal static Quaternion quaternion_0;

	internal static Vector3 vector3_1;

	internal static Quaternion quaternion_1;

	internal static Vector3 vector3_2;

	internal static Quaternion quaternion_2;

	internal static Vector3 vector3_3;

	internal static Quaternion quaternion_3;

	private static List<V3T> list_0;

	private static List<V3T> list_1;

	private static List<V3T> list_2;

	private static List<V3T> list_3;

	internal static VRRig vrrig_0;

	private static Material material_0;

	private static double double_0;

	private static double double_1;

	private static bool bool_2;

	private static double double_2;

	private static int int_0;

	private static double double_3;

	private static int int_1;

	private static IntPtr[] GetFileNamesDebuggerHiddenAttribute;

	private static IntPtr[] HasKeyUpgrade;

	private static IntPtr[] AlphaBoolNotOnFaulted;

	private static IntPtr[] FDispatchableResolveField;

	private unsafe void OnEnable()
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReflectionOnlyLoadFromGetTypeInfoType.GetTypeInfoCountThreadPoolDequeueWork);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_0325:
														if (b >= 1)
														{
															while (b <= 14)
															{
																while (true)
																{
																	IL_0305:
																	if (7 >= b)
																	{
																		while (true)
																		{
																			IL_02f5:
																			if (7 > b)
																			{
																				while (true)
																				{
																					IL_02e5:
																					if (3 < b)
																					{
																						while (true)
																						{
																							IL_02d5:
																							if (5 >= b)
																							{
																								while (true)
																								{
																									IL_02c8:
																									if (5 <= b)
																									{
																										while (true)
																										{
																											IL_027d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 37;
																											while (true)
																											{
																												IL_025e:
																												array[num5 - 2] = 0;
																												num = 143;
																												while (true)
																												{
																													if (num != 143)
																													{
																														if (num != 1124)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 37:
																															goto IL_025e;
																														case 76:
																														case 102:
																															goto IL_027d;
																														case 106:
																															goto IL_02c8;
																														case 15:
																														case 81:
																															goto IL_02d5;
																														case 49:
																														case 128:
																															goto IL_02e5;
																														case 110:
																															goto IL_02f5;
																														case 69:
																															goto IL_0305;
																														case 117:
																															goto IL_0315;
																														case 83:
																															goto IL_0325;
																														case 123:
																															goto end_IL_0325;
																														case 34:
																														case 40:
																															goto end_IL_0335;
																														case 64:
																															goto IL_0350;
																														case 29:
																															goto IL_035e;
																														case 90:
																														case 112:
																															goto IL_036c;
																														case 24:
																															goto IL_037a;
																														case 18:
																															goto IL_039d;
																														case 50:
																														case 130:
																															goto IL_03ac;
																														case 16:
																															goto IL_03ba;
																														case 57:
																														case 62:
																															goto IL_03c8;
																														case 1:
																															goto IL_0408;
																														case 39:
																															goto IL_041c;
																														case 133:
																															goto IL_042f;
																														case 23:
																															goto IL_043d;
																														case 66:
																															goto IL_0463;
																														case 88:
																														case 101:
																															goto IL_046e;
																														case 32:
																															goto IL_0497;
																														case 72:
																															goto IL_04a5;
																														case 7:
																															goto IL_04b8;
																														case 73:
																															goto IL_04c3;
																														case 31:
																															goto IL_04d6;
																														case 94:
																															goto IL_04e4;
																														case 85:
																														case 131:
																															goto IL_04f2;
																														case 135:
																															goto IL_0532;
																														case 61:
																															goto IL_0546;
																														case 36:
																														case 60:
																															goto IL_0559;
																														case 109:
																															goto IL_0599;
																														case 89:
																															goto IL_05b6;
																														case 28:
																															goto IL_05c9;
																														case 41:
																															goto IL_05d7;
																														case 92:
																															goto IL_05e5;
																														case 11:
																															goto IL_05f3;
																														case 79:
																														case 125:
																															goto IL_05fe;
																														case 33:
																															goto IL_060c;
																														case 30:
																														case 116:
																															goto IL_061a;
																														case 67:
																														case 86:
																															goto IL_062d;
																														case 127:
																															goto IL_066d;
																														case 12:
																															goto IL_068a;
																														case 45:
																														case 78:
																															goto IL_069d;
																														case 75:
																															goto IL_06ab;
																														case 95:
																														case 119:
																															goto IL_06b9;
																														case 53:
																															goto IL_071b;
																														case 25:
																														case 136:
																															goto IL_072e;
																														case 87:
																															goto IL_073c;
																														case 4:
																															goto IL_0747;
																														case 38:
																															goto IL_0755;
																														case 82:
																														case 103:
																															goto IL_0763;
																														case 84:
																															goto IL_077d;
																														case 2:
																														case 35:
																															goto IL_0790;
																														case 111:
																															goto IL_07b3;
																														case 68:
																															goto IL_07c3;
																														case 10:
																															goto IL_07ce;
																														case 0:
																														case 47:
																															goto IL_07d9;
																														case 3:
																														case 6:
																														case 9:
																														case 13:
																														case 14:
																														case 17:
																														case 19:
																														case 20:
																														case 26:
																														case 27:
																														case 43:
																														case 48:
																														case 52:
																														case 55:
																														case 58:
																														case 63:
																														case 71:
																														case 77:
																														case 93:
																														case 107:
																														case 108:
																														case 113:
																														case 114:
																														case 115:
																															goto end_IL_024b;
																														case 118:
																															goto IL_0814;
																														case 129:
																															goto IL_0822;
																														case 54:
																															goto IL_0830;
																														case 5:
																														case 22:
																														case 46:
																														case 51:
																														case 56:
																														case 65:
																														case 70:
																														case 74:
																														case 96:
																														case 97:
																														case 100:
																														case 104:
																														case 105:
																														case 120:
																														case 121:
																														case 124:
																														case 126:
																															goto end_IL_0345;
																														case 59:
																															goto end_IL_083e;
																														case 134:
																															goto end_IL_084e;
																														case 91:
																															goto end_IL_0858;
																														case 122:
																														case 132:
																															goto end_IL_0863;
																														case 21:
																															goto end_IL_0873;
																														case 8:
																														case 44:
																															goto end_IL_0883;
																														case 98:
																															goto end_IL_0893;
																														case 99:
																															goto end_IL_08a3;
																														case 42:
																														case 80:
																															return;
																														}
																														continue;
																													}
																													num5--;
																													goto end_IL_0345;
																													continue;
																													end_IL_024b:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0350;
																									IL_043d:
																									ptr2 += 8;
																									goto end_IL_0345;
																									IL_0350:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_035e;
																									IL_035e:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_036c;
																									IL_036c:
																									array[num5] = 0;
																									goto IL_037a;
																									IL_037a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_039d;
																									IL_039d:
																									array2[num5] = null;
																									goto IL_042f;
																									IL_042f:
																									num5++;
																									goto IL_043d;
																								}
																								break;
																							}
																							goto IL_03ac;
																							IL_041c:
																							num5--;
																							goto end_IL_0345;
																							IL_03ac:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_03ba;
																							IL_03ba:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_03c8;
																							IL_03c8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0408;
																							IL_0408:
																							array[num5 - 2] = 0;
																							goto IL_041c;
																						}
																						break;
																					}
																					goto IL_0463;
																					IL_0546:
																					num5--;
																					goto end_IL_0345;
																					IL_0463:
																					if (3 <= b)
																					{
																						goto IL_046e;
																					}
																					goto IL_04b8;
																					IL_046e:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0497;
																					IL_0497:
																					ptr2 += 8;
																					goto IL_04a5;
																					IL_04a5:
																					num5--;
																					goto end_IL_0345;
																					IL_04b8:
																					if (1 >= b)
																					{
																						goto IL_04c3;
																					}
																					goto IL_04d6;
																					IL_04c3:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_04d6:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_04e4;
																					IL_04e4:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_04f2;
																					IL_04f2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0532;
																					IL_0532:
																					array[num5 - 2] = 0;
																					goto IL_0546;
																				}
																				break;
																			}
																			goto IL_0559;
																			IL_05b6:
																			num5--;
																			goto end_IL_0345;
																			IL_0559:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0599;
																			IL_0599:
																			array[num5 - 2] = 0;
																			num = 89;
																			goto IL_05b6;
																		}
																		break;
																	}
																	goto IL_05c9;
																	IL_07d9:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_0345;
																	IL_05c9:
																	if (11 >= b)
																	{
																		goto IL_05d7;
																	}
																	goto IL_072e;
																	IL_05d7:
																	if (11 <= b)
																	{
																		goto end_IL_0345;
																	}
																	goto IL_05e5;
																	IL_05e5:
																	if (9 >= b)
																	{
																		goto IL_05f3;
																	}
																	goto IL_069d;
																	IL_05f3:
																	if (9 > b)
																	{
																		goto IL_05fe;
																	}
																	goto IL_062d;
																	IL_05fe:
																	if (8 < b)
																	{
																		break;
																	}
																	goto IL_060c;
																	IL_060c:
																	if (8 > b)
																	{
																		break;
																	}
																	goto IL_061a;
																	IL_061a:
																	num5--;
																	goto end_IL_0345;
																	IL_062d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_066d;
																	IL_066d:
																	array[num5 - 2] = 0;
																	num = 12;
																	goto IL_068a;
																	IL_068a:
																	num5--;
																	goto end_IL_0345;
																	IL_069d:
																	if (10 < b)
																	{
																		break;
																	}
																	goto IL_06ab;
																	IL_06ab:
																	if (10 > b)
																	{
																		break;
																	}
																	goto IL_06b9;
																	IL_06b9:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_071b;
																	IL_071b:
																	num5 -= 2;
																	goto end_IL_0345;
																	IL_072e:
																	if (13 >= b)
																	{
																		goto IL_073c;
																	}
																	goto IL_07c3;
																	IL_073c:
																	if (13 > b)
																	{
																		goto IL_0747;
																	}
																	goto IL_0790;
																	IL_0747:
																	if (12 < b)
																	{
																		break;
																	}
																	goto IL_0755;
																	IL_0755:
																	if (12 > b)
																	{
																		break;
																	}
																	goto IL_0763;
																	IL_0763:
																	bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																	goto IL_077d;
																	IL_077d:
																	num5--;
																	goto end_IL_0345;
																	IL_0790:
																	bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																	num = 111;
																	goto IL_07b3;
																	IL_07b3:
																	num5--;
																	goto end_IL_0345;
																	IL_07c3:
																	if (14 < b)
																	{
																		num = 48;
																		break;
																	}
																	goto IL_07ce;
																	IL_07ce:
																	if (14 > b)
																	{
																		break;
																	}
																	goto IL_07d9;
																}
																break;
																IL_0315:;
															}
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
														goto IL_0814;
														IL_0830:
														ptr2 += 8;
														goto end_IL_0345;
														IL_0822:
														num5++;
														goto IL_0830;
														IL_0814:
														array[num5] = 0;
														goto IL_0822;
														continue;
														end_IL_0325:
														break;
													}
													continue;
													end_IL_0335:
													break;
												}
												continue;
												end_IL_0345:
												break;
											}
											continue;
											end_IL_083e:
											break;
										}
										continue;
										end_IL_084e:
										break;
									}
									continue;
									end_IL_0858:
									break;
								}
								continue;
								end_IL_0863:
								break;
							}
							continue;
							end_IL_0873:
							break;
						}
						continue;
						end_IL_0883:
						break;
					}
					continue;
					end_IL_0893:
					break;
				}
				continue;
				end_IL_08a3:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 117;
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IgnoreSectsetContextAttributes.SwitchLayoutMask);
									num = 59;
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_05cc:
														if (b >= 1)
														{
															while (b <= 34)
															{
																while (true)
																{
																	IL_05ac:
																	if (17 >= b)
																	{
																		while (true)
																		{
																			IL_059c:
																			if (17 > b)
																			{
																				while (true)
																				{
																					IL_058f:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_057f:
																							if (12 >= b)
																							{
																								while (true)
																								{
																									IL_056f:
																									if (12 > b)
																									{
																										while (true)
																										{
																											IL_055c:
																											if (10 < b)
																											{
																												num = 331;
																												while (true)
																												{
																													if (num != 331)
																													{
																														if (num != 1312)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 232:
																														case 277:
																															goto IL_055c;
																														case 201:
																															goto IL_056f;
																														case 322:
																															goto IL_057f;
																														case 38:
																														case 183:
																															goto IL_058f;
																														case 304:
																															goto IL_059c;
																														case 19:
																															goto IL_05ac;
																														case 13:
																															goto end_IL_05ac;
																														case 56:
																															goto IL_05cc;
																														case 185:
																															goto end_IL_05cc;
																														case 79:
																														case 278:
																															goto end_IL_05dc;
																														case 42:
																															goto IL_05f7;
																														case 81:
																															goto IL_0605;
																														case 34:
																															goto IL_0613;
																														case 99:
																															goto IL_0623;
																														case 41:
																														case 158:
																															goto IL_0630;
																														case 195:
																															goto IL_063e;
																														case 96:
																															goto IL_0661;
																														case 116:
																															goto IL_066b;
																														case 103:
																														case 221:
																															goto IL_067e;
																														case 119:
																															goto IL_068c;
																														case 105:
																														case 231:
																															goto IL_069c;
																														case 242:
																															goto IL_0703;
																														case 168:
																														case 247:
																															goto IL_0716;
																														case 121:
																														case 257:
																															goto IL_075b;
																														case 133:
																															goto IL_0769;
																														case 6:
																														case 258:
																															goto IL_0774;
																														case 205:
																															goto IL_07b2;
																														case 64:
																															goto IL_07c0;
																														case 112:
																														case 265:
																															goto IL_07d3;
																														case 48:
																														case 128:
																															goto IL_07e1;
																														case 229:
																															goto IL_07ef;
																														case 111:
																														case 200:
																															goto IL_07fd;
																														case 120:
																															goto IL_0811;
																														case 53:
																															goto IL_085e;
																														case 222:
																															goto IL_086c;
																														case 214:
																															goto IL_0888;
																														case 3:
																															goto IL_0896;
																														case 174:
																														case 210:
																															goto IL_08a4;
																														case 82:
																															goto IL_08ae;
																														case 190:
																															goto IL_08bc;
																														case 25:
																															goto IL_08cf;
																														case 95:
																															goto IL_08da;
																														case 8:
																														case 246:
																															goto IL_08e8;
																														case 199:
																															goto IL_093a;
																														case 65:
																															goto IL_094d;
																														case 171:
																															goto IL_095b;
																														case 20:
																														case 160:
																															goto IL_0969;
																														case 193:
																															goto IL_09a6;
																														case 134:
																															goto IL_09b4;
																														case 267:
																															goto IL_09c4;
																														case 270:
																															goto IL_09d7;
																														case 23:
																															goto IL_09e5;
																														case 49:
																														case 234:
																															goto IL_09f3;
																														case 164:
																															goto IL_0a51;
																														case 273:
																															goto IL_0a64;
																														case 27:
																														case 274:
																															goto IL_0a77;
																														case 70:
																														case 191:
																															goto IL_0a85;
																														case 18:
																														case 149:
																															goto IL_0a90;
																														case 52:
																															goto IL_0a9e;
																														case 51:
																														case 249:
																															goto IL_0aac;
																														case 90:
																															goto IL_0ac8;
																														case 129:
																														case 155:
																															goto IL_0ad3;
																														case 220:
																															goto IL_0ae1;
																														case 26:
																														case 109:
																															goto IL_0aef;
																														case 113:
																														case 196:
																															goto end_IL_0549;
																														case 181:
																															goto IL_0b1c;
																														case 108:
																															goto IL_0b2f;
																														case 21:
																														case 269:
																															goto IL_0b3a;
																														case 188:
																															goto IL_0b63;
																														case 271:
																															goto IL_0b7a;
																														case 85:
																															goto IL_0b8d;
																														case 176:
																															goto IL_0b9b;
																														case 132:
																															goto IL_0ba9;
																														case 243:
																															goto IL_0bb7;
																														case 87:
																														case 107:
																															goto IL_0bc5;
																														case 31:
																															goto IL_0be3;
																														case 248:
																															goto IL_0bf1;
																														case 54:
																															goto IL_0bff;
																														case 275:
																															goto IL_0c12;
																														case 1:
																															goto IL_0c26;
																														case 151:
																														case 280:
																															goto IL_0c39;
																														case 104:
																															goto IL_0c47;
																														case 208:
																															goto IL_0c65;
																														case 286:
																															goto IL_0c78;
																														case 213:
																															goto IL_0c86;
																														case 60:
																														case 146:
																															goto IL_0c91;
																														case 9:
																															goto IL_0cd1;
																														case 283:
																															goto IL_0ce5;
																														case 16:
																														case 91:
																															goto IL_0cf8;
																														case 40:
																															goto IL_0d06;
																														case 102:
																														case 239:
																															goto IL_0d14;
																														case 253:
																															goto IL_0d2d;
																														case 84:
																															goto IL_0d3b;
																														case 93:
																															goto IL_0d49;
																														case 223:
																															goto IL_0d5c;
																														case 15:
																															goto IL_0d6a;
																														case 61:
																														case 122:
																															goto IL_0d78;
																														case 28:
																															goto IL_0da1;
																														case 45:
																															goto IL_0db8;
																														case 263:
																														case 289:
																															goto IL_0dd4;
																														case 281:
																															goto IL_0ddf;
																														case 69:
																														case 261:
																															goto IL_0ded;
																														case 127:
																															goto IL_0e01;
																														case 67:
																															goto IL_0e39;
																														case 290:
																															goto IL_0e63;
																														case 186:
																														case 294:
																															goto IL_0e76;
																														case 126:
																															goto IL_0e81;
																														case 167:
																															goto IL_0e8f;
																														case 264:
																															goto IL_0e9d;
																														case 98:
																														case 285:
																															goto IL_0eab;
																														case 288:
																															goto IL_0ef0;
																														case 295:
																															goto IL_0f03;
																														case 240:
																															goto IL_0f17;
																														case 227:
																														case 298:
																															goto IL_0f2a;
																														case 306:
																															goto IL_0f3d;
																														case 206:
																														case 308:
																															goto IL_0f50;
																														case 178:
																															goto IL_0f5e;
																														case 310:
																															goto IL_0f71;
																														case 137:
																															goto IL_0f8e;
																														case 163:
																														case 311:
																															goto IL_0fa1;
																														case 238:
																															goto IL_0fb5;
																														case 86:
																															goto IL_1002;
																														case 300:
																															goto IL_1010;
																														case 115:
																														case 315:
																															goto IL_1023;
																														case 202:
																															goto IL_106c;
																														case 152:
																															goto IL_1080;
																														case 169:
																														case 316:
																															goto IL_1093;
																														case 225:
																															goto IL_10aa;
																														case 118:
																															goto IL_10ce;
																														case 284:
																															goto IL_10dc;
																														case 321:
																															goto IL_10f8;
																														case 154:
																														case 175:
																															goto IL_1106;
																														case 192:
																															goto IL_1146;
																														case 35:
																															goto IL_115a;
																														case 323:
																															goto IL_1176;
																														case 58:
																															goto IL_1184;
																														case 72:
																														case 92:
																															goto IL_1192;
																														case 148:
																															goto IL_11b0;
																														case 68:
																															goto IL_11be;
																														case 260:
																															goto IL_11cc;
																														case 256:
																															goto IL_11df;
																														case 235:
																															goto IL_11ed;
																														case 12:
																														case 292:
																															goto IL_1200;
																														case 291:
																															goto IL_121a;
																														case 71:
																														case 162:
																															goto IL_1236;
																														case 216:
																															goto IL_1244;
																														case 55:
																														case 75:
																															goto IL_124f;
																														case 251:
																															goto IL_126d;
																														case 161:
																															goto IL_127b;
																														case 123:
																															goto IL_1289;
																														case 217:
																															goto IL_129c;
																														case 194:
																															goto IL_12aa;
																														case 57:
																														case 179:
																															goto IL_12b8;
																														case 184:
																															goto IL_12d2;
																														case 250:
																															goto IL_12e5;
																														case 180:
																														case 226:
																															goto IL_12f0;
																														case 7:
																															goto IL_12fe;
																														case 100:
																														case 303:
																															goto IL_130c;
																														case 276:
																															goto IL_132a;
																														case 22:
																															goto IL_1341;
																														case 177:
																															goto IL_134f;
																														case 77:
																															goto IL_1362;
																														case 78:
																														case 228:
																															goto IL_1370;
																														case 88:
																															goto IL_1399;
																														case 182:
																															goto IL_13a7;
																														case 29:
																														case 215:
																															goto IL_13b7;
																														case 237:
																															goto IL_13d5;
																														case 153:
																															goto IL_13e3;
																														case 255:
																															goto IL_13f1;
																														case 5:
																														case 10:
																														case 11:
																														case 17:
																														case 24:
																														case 32:
																														case 33:
																														case 37:
																														case 43:
																														case 44:
																														case 46:
																														case 50:
																														case 63:
																														case 66:
																														case 80:
																														case 83:
																														case 94:
																														case 97:
																														case 101:
																														case 106:
																														case 124:
																														case 125:
																														case 130:
																														case 140:
																														case 141:
																														case 143:
																														case 144:
																														case 147:
																														case 150:
																														case 156:
																														case 159:
																														case 165:
																														case 172:
																														case 187:
																														case 209:
																														case 211:
																														case 224:
																														case 230:
																														case 233:
																														case 241:
																														case 252:
																														case 254:
																														case 259:
																														case 268:
																														case 279:
																														case 282:
																														case 293:
																														case 296:
																														case 299:
																														case 301:
																														case 302:
																														case 305:
																														case 307:
																														case 309:
																														case 312:
																														case 314:
																														case 317:
																														case 324:
																															goto end_IL_05bc;
																														case 0:
																														case 2:
																														case 4:
																														case 36:
																														case 39:
																														case 47:
																														case 62:
																														case 110:
																														case 114:
																														case 131:
																														case 135:
																														case 136:
																														case 138:
																														case 139:
																														case 145:
																														case 157:
																														case 166:
																														case 170:
																														case 173:
																														case 189:
																														case 197:
																														case 203:
																														case 204:
																														case 207:
																														case 212:
																														case 218:
																														case 219:
																														case 244:
																														case 245:
																														case 262:
																														case 266:
																														case 272:
																														case 287:
																														case 297:
																														case 318:
																														case 319:
																														case 320:
																															goto end_IL_05ec;
																														case 59:
																															goto end_IL_1414;
																														case 142:
																															goto end_IL_1427;
																														case 76:
																															goto end_IL_1431;
																														case 14:
																														case 117:
																															goto end_IL_1445;
																														case 198:
																															goto end_IL_1455;
																														case 236:
																														case 313:
																															goto end_IL_1465;
																														case 73:
																															goto end_IL_147e;
																														case 74:
																															goto end_IL_148e;
																														case 30:
																														case 89:
																															return;
																														}
																														continue;
																													}
																													goto IL_11df;
																													IL_11df:
																													if (11 < b)
																													{
																														goto end_IL_05bc;
																													}
																													goto IL_11ed;
																													IL_11ed:
																													if (11 <= b)
																													{
																														goto end_IL_05ec;
																													}
																													goto end_IL_05bc;
																													continue;
																													end_IL_0549:
																													break;
																												}
																												break;
																											}
																											goto IL_0623;
																											IL_0f03:
																											array[num5 - 2] = 0;
																											goto IL_0f17;
																											IL_0f17:
																											num5--;
																											goto end_IL_05ec;
																											IL_0623:
																											if (10 > b)
																											{
																												goto IL_067e;
																											}
																											goto IL_069c;
																											IL_069c:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_09c4;
																											IL_09c4:
																											num5 -= 2;
																											goto end_IL_05ec;
																											IL_067e:
																											if (9 < b)
																											{
																												goto end_IL_05bc;
																											}
																											goto IL_068c;
																											IL_068c:
																											if (9 > b)
																											{
																												goto end_IL_05bc;
																											}
																											goto IL_0716;
																											IL_0716:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0f03;
																										}
																										break;
																									}
																									goto IL_1200;
																									IL_121a:
																									num5--;
																									goto end_IL_05ec;
																									IL_1200:
																									bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																									goto IL_121a;
																								}
																								break;
																							}
																							num = 162;
																							goto IL_1236;
																							IL_1399:
																							num5--;
																							goto IL_13a7;
																							IL_13a7:
																							ptr2 += 8;
																							goto end_IL_05ec;
																							IL_1236:
																							if (14 >= b)
																							{
																								goto IL_1244;
																							}
																							goto IL_12e5;
																							IL_1244:
																							if (14 <= b)
																							{
																								goto IL_124f;
																							}
																							goto IL_129c;
																							IL_124f:
																							array2[num5] = ((delegate*<List<V3T>>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])();
																							goto IL_126d;
																							IL_126d:
																							array[num5] = 5;
																							goto IL_127b;
																							IL_127b:
																							num5++;
																							goto IL_1289;
																							IL_1289:
																							ptr2 += 8;
																							goto end_IL_05ec;
																							IL_129c:
																							if (13 < b)
																							{
																								goto end_IL_05bc;
																							}
																							goto IL_12aa;
																							IL_12aa:
																							if (13 > b)
																							{
																								goto end_IL_05bc;
																							}
																							goto IL_12b8;
																							IL_12b8:
																							bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																							goto IL_12d2;
																							IL_12d2:
																							num5--;
																							goto end_IL_05ec;
																							IL_12e5:
																							if (15 < b)
																							{
																								goto IL_12f0;
																							}
																							goto IL_1362;
																							IL_12f0:
																							if (16 < b)
																							{
																								goto end_IL_05bc;
																							}
																							goto IL_12fe;
																							IL_12fe:
																							if (16 > b)
																							{
																								goto end_IL_05bc;
																							}
																							goto IL_130c;
																							IL_130c:
																							array2[num5] = ((delegate*<List<V3T>>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])();
																							goto IL_132a;
																							IL_132a:
																							array[num5] = 5;
																							num = 22;
																							goto IL_1341;
																							IL_1341:
																							num5++;
																							goto IL_134f;
																							IL_134f:
																							ptr2 += 8;
																							goto end_IL_05ec;
																							IL_1362:
																							if (15 > b)
																							{
																								goto end_IL_05bc;
																							}
																							goto IL_1370;
																							IL_1370:
																							((delegate*<List<V3T>, void>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])((List<V3T>)array2[num5 - 1]);
																							goto IL_1399;
																						}
																						break;
																					}
																					goto IL_05f7;
																					IL_0f2a:
																					num5--;
																					goto end_IL_05ec;
																					IL_05f7:
																					if (8 > b)
																					{
																						goto IL_0605;
																					}
																					goto IL_0f2a;
																					IL_0605:
																					if (4 >= b)
																					{
																						goto IL_0613;
																					}
																					goto IL_0e76;
																					IL_0613:
																					if (4 <= b)
																					{
																						goto IL_0630;
																					}
																					goto IL_0c78;
																					IL_0630:
																					array[num5] = 0;
																					goto IL_063e;
																					IL_063e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0661;
																					IL_0661:
																					array2[num5] = null;
																					goto IL_066b;
																					IL_066b:
																					num5++;
																					goto IL_0703;
																					IL_0703:
																					ptr2 += 8;
																					goto end_IL_05ec;
																					IL_0c78:
																					if (2 >= b)
																					{
																						goto IL_0c86;
																					}
																					goto IL_0d5c;
																					IL_0c86:
																					if (2 <= b)
																					{
																						goto IL_0c91;
																					}
																					goto IL_0cf8;
																					IL_0c91:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0cd1;
																					IL_0cd1:
																					array[num5 - 2] = 0;
																					goto IL_0ce5;
																					IL_0ce5:
																					num5--;
																					goto end_IL_05ec;
																					IL_0cf8:
																					if (1 < b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_0d06;
																					IL_0d06:
																					if (1 > b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_0d14;
																					IL_0d14:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0d2d;
																					IL_0d2d:
																					array[num5] = 0;
																					goto IL_0d3b;
																					IL_0d3b:
																					num5++;
																					goto IL_0d49;
																					IL_0d49:
																					ptr2 += 8;
																					goto end_IL_05ec;
																					IL_0d5c:
																					if (3 < b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_0d6a;
																					IL_0d6a:
																					if (3 > b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_0d78;
																					IL_0d78:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0da1;
																					IL_0da1:
																					ptr2 += 8;
																					num = 45;
																					goto IL_0db8;
																					IL_0db8:
																					num5--;
																					num = 36;
																					goto end_IL_05ec;
																					IL_0e76:
																					if (6 >= b)
																					{
																						goto IL_0e81;
																					}
																					goto IL_0ef0;
																					IL_0e81:
																					if (6 > b)
																					{
																						goto IL_0e8f;
																					}
																					goto IL_1023;
																					IL_0e8f:
																					if (5 < b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_0e9d;
																					IL_0e9d:
																					if (5 > b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_0eab;
																					IL_0eab:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0f71;
																					IL_0f71:
																					array[num5 - 2] = 0;
																					num = 137;
																					goto IL_0f8e;
																					IL_0f8e:
																					num5--;
																					goto end_IL_05ec;
																					IL_1023:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 202;
																					goto IL_106c;
																					IL_106c:
																					array[num5 - 2] = 0;
																					goto IL_1080;
																					IL_1080:
																					num5--;
																					goto end_IL_05ec;
																					IL_0ef0:
																					if (7 < b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_10f8;
																					IL_10f8:
																					if (7 > b)
																					{
																						goto end_IL_05bc;
																					}
																					goto IL_1106;
																					IL_1106:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_1146;
																					IL_1146:
																					array[num5 - 2] = 0;
																					goto IL_115a;
																					IL_115a:
																					num5--;
																					num = 39;
																					goto end_IL_05ec;
																				}
																				break;
																			}
																			goto IL_13b7;
																			IL_13f1:
																			ptr2 += 8;
																			goto end_IL_05ec;
																			IL_13b7:
																			array2[num5] = ((delegate*<List<V3T>>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])();
																			goto IL_13d5;
																			IL_13d5:
																			array[num5] = 5;
																			goto IL_13e3;
																			IL_13e3:
																			num5++;
																			goto IL_13f1;
																		}
																		goto IL_0b08;
																	}
																	goto IL_075b;
																	IL_0e39:
																	ptr2 += 8;
																	num = 219;
																	goto end_IL_05ec;
																	IL_075b:
																	if (26 >= b)
																	{
																		goto IL_0769;
																	}
																	goto IL_0a77;
																	IL_0769:
																	if (26 <= b)
																	{
																		goto IL_0774;
																	}
																	goto IL_07d3;
																	IL_0774:
																	((delegate*<Behaviour, bool, void>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																	goto IL_07b2;
																	IL_07b2:
																	num5 -= 2;
																	goto IL_07c0;
																	IL_07c0:
																	ptr2 += 8;
																	goto end_IL_05ec;
																	IL_07d3:
																	if (21 < b)
																	{
																		goto IL_07e1;
																	}
																	goto IL_09a6;
																	IL_07e1:
																	if (23 >= b)
																	{
																		goto IL_07ef;
																	}
																	goto IL_08cf;
																	IL_07ef:
																	if (23 <= b)
																	{
																		goto IL_07fd;
																	}
																	goto IL_0888;
																	IL_07fd:
																	array[num5 - 2] = 0;
																	goto IL_0811;
																	IL_0811:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																	goto IL_085e;
																	IL_085e:
																	num5--;
																	goto IL_086c;
																	IL_086c:
																	ptr2 += 8;
																	num = 244;
																	goto end_IL_05ec;
																	IL_0888:
																	if (22 < b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0896;
																	IL_0896:
																	if (22 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_08a4;
																	IL_08a4:
																	array2[num5] = null;
																	goto IL_08ae;
																	IL_08ae:
																	array[num5] = 5;
																	goto IL_08bc;
																	IL_08bc:
																	num5++;
																	goto end_IL_05ec;
																	IL_08cf:
																	if (24 >= b)
																	{
																		goto IL_08da;
																	}
																	goto IL_094d;
																	IL_08da:
																	if (24 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_08e8;
																	IL_08e8:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_093a;
																	IL_093a:
																	num5--;
																	goto end_IL_05ec;
																	IL_094d:
																	if (25 < b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_095b;
																	IL_095b:
																	if (25 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0969;
																	IL_0969:
																	array2[num5 - 1] = ((delegate*<GorillaTagger, VRRig>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																	goto IL_0c12;
																	IL_0c12:
																	array[num5 - 1] = 5;
																	goto IL_0c26;
																	IL_0c26:
																	ptr2 += 8;
																	goto end_IL_05ec;
																	IL_09a6:
																	if (21 > b)
																	{
																		goto IL_09b4;
																	}
																	goto IL_0c39;
																	IL_09b4:
																	if (19 < b)
																	{
																		goto IL_09d7;
																	}
																	goto IL_0a64;
																	IL_0a64:
																	if (19 <= b)
																	{
																		goto IL_1093;
																	}
																	goto IL_1176;
																	IL_1093:
																	array[num5] = 0;
																	num = 225;
																	goto IL_10aa;
																	IL_10aa:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])() ? 1 : 0);
																	goto IL_10ce;
																	IL_10ce:
																	num5++;
																	goto IL_10dc;
																	IL_10dc:
																	ptr2 += 8;
																	num = 4;
																	goto end_IL_05ec;
																	IL_1176:
																	if (18 < b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_1184;
																	IL_1184:
																	if (18 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_1192;
																	IL_1192:
																	array2[num5] = ((delegate*<List<V3T>>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])();
																	goto IL_11b0;
																	IL_11b0:
																	array[num5] = 5;
																	goto IL_11be;
																	IL_11be:
																	num5++;
																	goto IL_11cc;
																	IL_11cc:
																	ptr2 += 8;
																	goto end_IL_05ec;
																	IL_09d7:
																	if (20 < b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_09e5;
																	IL_09e5:
																	if (20 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_09f3;
																	IL_09f3:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0a51;
																	IL_0a51:
																	num5--;
																	goto end_IL_05ec;
																	IL_0c39:
																	array[num5] = 5;
																	goto IL_0c47;
																	IL_0c47:
																	array2[num5] = ((delegate*<GorillaTagger>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])();
																	goto IL_0c65;
																	IL_0c65:
																	num5++;
																	goto IL_0f3d;
																	IL_0f3d:
																	ptr2 += 8;
																	goto end_IL_05ec;
																	IL_0a77:
																	if (30 < b)
																	{
																		goto IL_0a85;
																	}
																	goto IL_0b2f;
																	IL_0a85:
																	if (32 < b)
																	{
																		goto IL_0a90;
																	}
																	goto IL_0ac8;
																	IL_0a90:
																	if (33 >= b)
																	{
																		goto IL_0a9e;
																	}
																	goto IL_0f50;
																	IL_0a9e:
																	if (33 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0aac;
																	IL_0aac:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_05ec;
																	IL_0f50:
																	if (34 < b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0f5e;
																	IL_0f5e:
																	if (34 > b)
																	{
																	}
																	goto end_IL_05bc;
																	IL_0ac8:
																	if (32 > b)
																	{
																		goto IL_0ad3;
																	}
																	goto IL_0b08;
																	IL_0ad3:
																	if (31 < b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0ae1;
																	IL_0ae1:
																	if (31 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0aef;
																	IL_0aef:
																	vrrig_0 = (VRRig)array2[num5 - 1];
																	goto IL_0e63;
																	IL_0e63:
																	num5--;
																	goto end_IL_05ec;
																	IL_0b08:
																	material_0 = (Material)array2[num5 - 1];
																	goto IL_0b1c;
																	IL_0b1c:
																	num5--;
																	goto end_IL_05ec;
																	IL_0b2f:
																	if (30 <= b)
																	{
																		goto IL_0b3a;
																	}
																	goto IL_0b8d;
																	IL_0b3a:
																	((delegate*<UnityEngine.Object, void>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])((GameObject)array2[num5 - 1]);
																	goto IL_0b63;
																	IL_0b63:
																	num5--;
																	num = 271;
																	goto IL_0b7a;
																	IL_0b7a:
																	ptr2 += 8;
																	goto end_IL_05ec;
																	IL_0b8d:
																	if (28 >= b)
																	{
																		goto IL_0b9b;
																	}
																	goto IL_0dd4;
																	IL_0b9b:
																	if (28 > b)
																	{
																		goto IL_0ba9;
																	}
																	goto IL_0fa1;
																	IL_0ba9:
																	if (27 < b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0bb7;
																	IL_0bb7:
																	if (27 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0bc5;
																	IL_0bc5:
																	array2[num5] = ((delegate*<VRRig>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])();
																	goto IL_0be3;
																	IL_0be3:
																	array[num5] = 5;
																	goto IL_0bf1;
																	IL_0bf1:
																	num5++;
																	goto IL_0bff;
																	IL_0bff:
																	ptr2 += 8;
																	goto end_IL_05ec;
																	IL_0fa1:
																	array[num5 - 2] = 0;
																	goto IL_0fb5;
																	IL_0fb5:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																	goto IL_1002;
																	IL_1002:
																	num5--;
																	goto IL_1010;
																	IL_1010:
																	ptr2 += 8;
																	goto end_IL_05ec;
																	IL_0dd4:
																	if (29 < b)
																	{
																		num = 317;
																		goto end_IL_05bc;
																	}
																	goto IL_0ddf;
																	IL_0ddf:
																	if (29 > b)
																	{
																		goto end_IL_05bc;
																	}
																	goto IL_0ded;
																	IL_0ded:
																	array[num5 - 1] = 5;
																	goto IL_0e01;
																	IL_0e01:
																	array2[num5 - 1] = ((delegate*<Component, GameObject>)GetFileNamesDebuggerHiddenAttribute[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																	goto IL_0e39;
																	continue;
																	end_IL_05ac:
																	break;
																}
																continue;
																end_IL_05bc:
																break;
															}
														}
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto end_IL_05ec;
														continue;
														end_IL_05cc:
														break;
													}
													continue;
													end_IL_05dc:
													break;
												}
												continue;
												end_IL_05ec:
												break;
											}
											continue;
											end_IL_1414:
											break;
										}
										continue;
										end_IL_1427:
										break;
									}
									continue;
									end_IL_1431:
									break;
								}
								continue;
								end_IL_1445:
								break;
							}
							continue;
							end_IL_1455:
							break;
						}
						continue;
						end_IL_1465:
						break;
					}
					continue;
					end_IL_147e:
					break;
				}
				continue;
				end_IL_148e:
				break;
			}
		}
	}

	private void Update()
	{
		int num = 112;
		num = 56;
		num = 624;
		num = 48;
		num = 56;
		num = 8;
		num = 56;
		num = 56;
		num = 42;
		num = 21;
		num = 140;
		num = 20;
		num = 21;
		num = 41;
		num = 397;
		num = 397;
		num = 453;
		num = 560;
		num = 112;
		object obj = "m";
		object obj2 = obj;
		obj = "K";
		object obj3 = obj;
		obj = "o";
		object obj4 = obj;
		obj = "L";
		object obj5 = obj;
		obj = "/";
		object obj6 = obj;
		obj = "S";
		object obj7 = obj;
		obj = "g";
		object obj8 = obj;
		obj = "l";
		object obj9 = obj;
		obj = "b";
		object obj10 = obj;
		obj = " ";
		object obj11 = obj;
		obj = "r";
		object obj12 = obj;
		obj = "s";
		object obj13 = obj;
		obj = "_";
		object obj14 = obj;
		obj = "R";
		object obj15 = obj;
		obj = "e";
		object obj16 = obj;
		obj = "V";
		object obj17 = obj;
		obj = "f";
		object obj18 = obj;
		obj = "A";
		object obj19 = obj;
		obj = "d";
		object obj20 = obj;
		obj = "t";
		object obj21 = obj;
		obj = "u";
		object obj22 = obj;
		obj = "C";
		object obj23 = obj;
		obj = "I";
		object obj24 = obj;
		obj = "n";
		object obj25 = obj;
		obj = "h";
		object obj26 = obj;
		obj = "a";
		object obj27 = obj;
		obj = "i";
		object obj28 = obj;
		num = 235;
		num = 47;
		obj = new string[47];
		object obj29 = obj;
		object obj30 = obj17;
		((string[])obj29)[0] = (string)obj30;
		obj29 = obj;
		obj30 = obj15;
		((string[])obj29)[1] = (string)obj30;
		obj29 = obj;
		obj30 = obj11;
		((string[])obj29)[2] = (string)obj30;
		obj29 = obj;
		obj30 = obj23;
		((string[])obj29)[3] = (string)obj30;
		obj29 = obj;
		obj30 = obj4;
		((string[])obj29)[4] = (string)obj30;
		obj29 = obj;
		obj30 = obj25;
		((string[])obj29)[5] = (string)obj30;
		obj29 = obj;
		obj30 = obj13;
		((string[])obj29)[6] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[7] = (string)obj30;
		obj29 = obj;
		obj30 = obj12;
		((string[])obj29)[8] = (string)obj30;
		obj29 = obj;
		obj30 = obj27;
		((string[])obj29)[9] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[10] = (string)obj30;
		obj29 = obj;
		obj30 = obj25;
		((string[])obj29)[11] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[12] = (string)obj30;
		obj29 = obj;
		obj30 = obj13;
		((string[])obj29)[13] = (string)obj30;
		obj29 = obj;
		obj30 = obj6;
		((string[])obj29)[14] = (string)obj30;
		obj29 = obj;
		obj30 = obj15;
		((string[])obj29)[15] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[16] = (string)obj30;
		obj29 = obj;
		obj30 = obj8;
		((string[])obj29)[17] = (string)obj30;
		obj29 = obj;
		obj30 = obj26;
		((string[])obj29)[18] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[19] = (string)obj30;
		obj29 = obj;
		obj30 = obj19;
		((string[])obj29)[20] = (string)obj30;
		obj29 = obj;
		obj30 = obj12;
		((string[])obj29)[21] = (string)obj30;
		obj29 = obj;
		obj30 = obj2;
		((string[])obj29)[22] = (string)obj30;
		obj29 = obj;
		obj30 = obj6;
		((string[])obj29)[23] = (string)obj30;
		obj29 = obj;
		obj30 = obj15;
		((string[])obj29)[24] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[25] = (string)obj30;
		obj29 = obj;
		obj30 = obj8;
		((string[])obj29)[26] = (string)obj30;
		obj29 = obj;
		obj30 = obj26;
		((string[])obj29)[27] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[28] = (string)obj30;
		obj29 = obj;
		obj30 = obj11;
		((string[])obj29)[29] = (string)obj30;
		obj29 = obj;
		obj30 = obj19;
		((string[])obj29)[30] = (string)obj30;
		obj29 = obj;
		obj30 = obj12;
		((string[])obj29)[31] = (string)obj30;
		obj29 = obj;
		obj30 = obj2;
		((string[])obj29)[32] = (string)obj30;
		obj29 = obj;
		obj30 = obj11;
		((string[])obj29)[33] = (string)obj30;
		obj29 = obj;
		obj30 = obj24;
		((string[])obj29)[34] = (string)obj30;
		obj29 = obj;
		obj30 = obj3;
		((string[])obj29)[35] = (string)obj30;
		obj29 = obj;
		obj30 = obj6;
		((string[])obj29)[36] = (string)obj30;
		obj29 = obj;
		obj30 = obj7;
		((string[])obj29)[37] = (string)obj30;
		obj29 = obj;
		obj30 = obj9;
		((string[])obj29)[38] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[39] = (string)obj30;
		obj29 = obj;
		obj30 = obj20;
		((string[])obj29)[40] = (string)obj30;
		obj29 = obj;
		obj30 = obj16;
		((string[])obj29)[41] = (string)obj30;
		obj29 = obj;
		obj30 = obj19;
		((string[])obj29)[42] = (string)obj30;
		obj29 = obj;
		obj30 = obj22;
		((string[])obj29)[43] = (string)obj30;
		obj29 = obj;
		obj30 = obj20;
		((string[])obj29)[44] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[45] = (string)obj30;
		obj29 = obj;
		obj30 = obj4;
		((string[])obj29)[46] = (string)obj30;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj31 = obj;
		num = 135;
		num = 45;
		obj = new string[45];
		obj29 = obj;
		obj30 = obj17;
		((string[])obj29)[0] = (string)obj30;
		obj29 = obj;
		obj30 = obj15;
		((string[])obj29)[1] = (string)obj30;
		obj29 = obj;
		obj30 = obj11;
		((string[])obj29)[2] = (string)obj30;
		obj29 = obj;
		obj30 = obj23;
		((string[])obj29)[3] = (string)obj30;
		obj29 = obj;
		obj30 = obj4;
		((string[])obj29)[4] = (string)obj30;
		obj29 = obj;
		obj30 = obj25;
		((string[])obj29)[5] = (string)obj30;
		obj29 = obj;
		obj30 = obj13;
		((string[])obj29)[6] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[7] = (string)obj30;
		obj29 = obj;
		obj30 = obj12;
		((string[])obj29)[8] = (string)obj30;
		obj29 = obj;
		obj30 = obj27;
		((string[])obj29)[9] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[10] = (string)obj30;
		obj29 = obj;
		obj30 = obj25;
		((string[])obj29)[11] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[12] = (string)obj30;
		obj29 = obj;
		obj30 = obj13;
		((string[])obj29)[13] = (string)obj30;
		obj29 = obj;
		obj30 = obj6;
		((string[])obj29)[14] = (string)obj30;
		obj29 = obj;
		obj30 = obj5;
		((string[])obj29)[15] = (string)obj30;
		obj29 = obj;
		obj30 = obj16;
		((string[])obj29)[16] = (string)obj30;
		obj29 = obj;
		obj30 = obj18;
		((string[])obj29)[17] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[18] = (string)obj30;
		obj29 = obj;
		obj30 = obj19;
		((string[])obj29)[19] = (string)obj30;
		obj29 = obj;
		obj30 = obj12;
		((string[])obj29)[20] = (string)obj30;
		obj29 = obj;
		obj30 = obj2;
		((string[])obj29)[21] = (string)obj30;
		obj29 = obj;
		obj30 = obj6;
		((string[])obj29)[22] = (string)obj30;
		obj29 = obj;
		obj30 = obj5;
		((string[])obj29)[23] = (string)obj30;
		obj29 = obj;
		obj30 = obj16;
		((string[])obj29)[24] = (string)obj30;
		obj29 = obj;
		obj30 = obj18;
		((string[])obj29)[25] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[26] = (string)obj30;
		obj29 = obj;
		obj30 = obj11;
		((string[])obj29)[27] = (string)obj30;
		obj29 = obj;
		obj30 = obj19;
		((string[])obj29)[28] = (string)obj30;
		obj29 = obj;
		obj30 = obj12;
		((string[])obj29)[29] = (string)obj30;
		obj29 = obj;
		obj30 = obj2;
		((string[])obj29)[30] = (string)obj30;
		obj29 = obj;
		obj30 = obj11;
		((string[])obj29)[31] = (string)obj30;
		obj29 = obj;
		obj30 = obj24;
		((string[])obj29)[32] = (string)obj30;
		obj29 = obj;
		obj30 = obj3;
		((string[])obj29)[33] = (string)obj30;
		obj29 = obj;
		obj30 = obj6;
		((string[])obj29)[34] = (string)obj30;
		obj29 = obj;
		obj30 = obj7;
		((string[])obj29)[35] = (string)obj30;
		obj29 = obj;
		obj30 = obj9;
		((string[])obj29)[36] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[37] = (string)obj30;
		obj29 = obj;
		obj30 = obj20;
		((string[])obj29)[38] = (string)obj30;
		obj29 = obj;
		obj30 = obj16;
		((string[])obj29)[39] = (string)obj30;
		obj29 = obj;
		obj30 = obj19;
		((string[])obj29)[40] = (string)obj30;
		obj29 = obj;
		obj30 = obj22;
		((string[])obj29)[41] = (string)obj30;
		obj29 = obj;
		obj30 = obj20;
		((string[])obj29)[42] = (string)obj30;
		obj29 = obj;
		obj30 = obj28;
		((string[])obj29)[43] = (string)obj30;
		obj29 = obj;
		obj30 = obj4;
		((string[])obj29)[44] = (string)obj30;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj32 = obj;
		num = 10;
		num = 5;
		obj = new string[5];
		obj29 = obj;
		obj30 = obj10;
		((string[])obj29)[0] = (string)obj30;
		obj29 = obj;
		obj30 = obj21;
		((string[])obj29)[1] = (string)obj30;
		obj29 = obj;
		obj30 = obj14;
		((string[])obj29)[2] = (string)obj30;
		obj29 = obj;
		obj30 = obj8;
		((string[])obj29)[3] = (string)obj30;
		obj29 = obj;
		obj30 = obj26;
		((string[])obj29)[4] = (string)obj30;
		string text3 = string.Concat((string[])obj);
		obj = text3;
		object obj33 = obj;
		float time = Time.time;
		double num2 = time;
		global::_003CModule_003E.float_108 = (float)num2;
		GTPlayer instance = GTPlayer.Instance;
		obj = instance;
		obj = ((GTPlayer)obj).headCollider;
		Transform transform = ((SphereCollider)obj).transform;
		obj = transform;
		global::_003CModule_003E.transform_13 = (Transform)obj;
		obj = list_0;
		double num3 = global::_003CModule_003E.float_108;
		object transform_ = global::_003CModule_003E.transform_13;
		Vector3 position = ((Transform)transform_).position;
		transform_ = position;
		obj30 = global::_003CModule_003E.transform_13;
		Quaternion rotation = ((Transform)obj30).rotation;
		obj30 = rotation;
		V3T v3T = new V3T((float)num3, (Vector3)transform_, (Quaternion)obj30);
		obj29 = v3T;
		((List<V3T>)obj).Add((V3T)obj29);
		obj = list_1;
		num3 = global::_003CModule_003E.float_108;
		transform_ = global::_003CModule_003E.transform_13;
		Vector3 position2 = ((Transform)transform_).position;
		transform_ = position2;
		double num4 = 0.0;
		object transform_2 = global::_003CModule_003E.transform_13;
		Quaternion rotation2 = ((Transform)transform_2).rotation;
		transform_2 = rotation2;
		global::_003CModule_003E.quaternion_5 = (Quaternion)transform_2;
		Vector3 eulerAngles = global::_003CModule_003E.quaternion_5.eulerAngles;
		transform_2 = eulerAngles;
		double num5 = ((Vector3)transform_2).y;
		double num6 = 0.0;
		Quaternion quaternion = Quaternion.Euler((float)num4, (float)num5, (float)num6);
		obj30 = quaternion;
		V3T v3T2 = new V3T((float)num3, (Vector3)transform_, (Quaternion)obj30);
		obj29 = v3T2;
		((List<V3T>)obj).Add((V3T)obj29);
		obj = list_2;
		num3 = global::_003CModule_003E.float_108;
		GorillaTagger instance2 = GorillaTagger.Instance;
		transform_ = instance2;
		transform_ = ((GorillaTagger)transform_).leftHandTransform;
		Vector3 position3 = ((Transform)transform_).position;
		transform_ = position3;
		GorillaTagger instance3 = GorillaTagger.Instance;
		obj30 = instance3;
		obj30 = ((GorillaTagger)obj30).leftHandTransform;
		Quaternion rotation3 = ((Transform)obj30).rotation;
		obj30 = rotation3;
		V3T v3T3 = new V3T((float)num3, (Vector3)transform_, (Quaternion)obj30);
		obj29 = v3T3;
		((List<V3T>)obj).Add((V3T)obj29);
		obj = list_3;
		num3 = global::_003CModule_003E.float_108;
		GorillaTagger instance4 = GorillaTagger.Instance;
		transform_ = instance4;
		transform_ = ((GorillaTagger)transform_).rightHandTransform;
		Vector3 position4 = ((Transform)transform_).position;
		transform_ = position4;
		GorillaTagger instance5 = GorillaTagger.Instance;
		obj30 = instance5;
		obj30 = ((GorillaTagger)obj30).rightHandTransform;
		Quaternion rotation4 = ((Transform)obj30).rotation;
		obj30 = rotation4;
		V3T v3T4 = new V3T((float)num3, (Vector3)transform_, (Quaternion)obj30);
		obj29 = v3T4;
		((List<V3T>)obj).Add((V3T)obj29);
		while (true)
		{
			obj = list_1;
			int count = ((List<V3T>)obj).Count;
			num = count;
			if (num > 0)
			{
				num2 = global::_003CModule_003E.float_108;
				obj29 = list_1;
				V3T v3T5 = ((List<V3T>)obj29)[0];
				obj29 = v3T5;
				num3 = ((V3T)obj29).float_0;
				num2 -= num3;
				num3 = float_0;
				if (num2 < num3)
				{
					break;
				}
				obj = list_1;
				V3T v3T6 = ((List<V3T>)obj)[0];
				obj = v3T6;
				obj29 = list_1;
				((List<V3T>)obj29).RemoveAt(0);
				obj29 = obj;
				obj29 = ((V3T)obj29).vector3_0;
				vector3_0 = (Vector3)obj29;
				obj = ((V3T)obj).quaternion_0;
				quaternion_0 = (Quaternion)obj;
				num = 1;
				bool_1 = true;
				continue;
			}
			break;
		}
		while (true)
		{
			obj = list_0;
			int count2 = ((List<V3T>)obj).Count;
			num = count2;
			if (num > 0)
			{
				num2 = global::_003CModule_003E.float_108;
				obj29 = list_0;
				V3T v3T7 = ((List<V3T>)obj29)[0];
				obj29 = v3T7;
				num3 = ((V3T)obj29).float_0;
				num2 -= num3;
				num3 = float_0;
				if (num2 < num3)
				{
					break;
				}
				obj = list_0;
				V3T v3T8 = ((List<V3T>)obj)[0];
				obj = v3T8;
				obj29 = list_0;
				((List<V3T>)obj29).RemoveAt(0);
				obj29 = obj;
				obj29 = ((V3T)obj29).vector3_0;
				vector3_1 = (Vector3)obj29;
				obj = ((V3T)obj).quaternion_0;
				quaternion_1 = (Quaternion)obj;
				continue;
			}
			break;
		}
		while (true)
		{
			obj = list_2;
			int count3 = ((List<V3T>)obj).Count;
			num = count3;
			if (num > 0)
			{
				num2 = global::_003CModule_003E.float_108;
				obj29 = list_2;
				V3T v3T9 = ((List<V3T>)obj29)[0];
				obj29 = v3T9;
				num3 = ((V3T)obj29).float_0;
				num2 -= num3;
				num3 = float_0;
				if (num2 < num3)
				{
					break;
				}
				obj = list_2;
				V3T v3T10 = ((List<V3T>)obj)[0];
				obj = v3T10;
				obj29 = list_2;
				((List<V3T>)obj29).RemoveAt(0);
				obj29 = obj;
				obj29 = ((V3T)obj29).vector3_0;
				vector3_2 = (Vector3)obj29;
				obj = ((V3T)obj).quaternion_0;
				num3 = -21.0;
				double num7 = -5.0;
				num4 = 175.0;
				Quaternion quaternion2 = Quaternion.Euler((float)num3, (float)num7, (float)num4);
				obj29 = quaternion2;
				Quaternion quaternion3 = (Quaternion)obj * (Quaternion)obj29;
				obj = quaternion3;
				quaternion_2 = (Quaternion)obj;
				continue;
			}
			break;
		}
		while (true)
		{
			obj = list_3;
			int count4 = ((List<V3T>)obj).Count;
			num = count4;
			if (num <= 0)
			{
				break;
			}
			num2 = global::_003CModule_003E.float_108;
			obj29 = list_3;
			V3T v3T11 = ((List<V3T>)obj29)[0];
			obj29 = v3T11;
			num3 = ((V3T)obj29).float_0;
			num2 -= num3;
			num3 = float_0;
			if (num2 < num3)
			{
				break;
			}
			obj = list_3;
			V3T v3T12 = ((List<V3T>)obj)[0];
			obj = v3T12;
			obj29 = list_3;
			((List<V3T>)obj29).RemoveAt(0);
			obj29 = obj;
			obj29 = ((V3T)obj29).vector3_0;
			vector3_3 = (Vector3)obj29;
			obj = ((V3T)obj).quaternion_0;
			num3 = -21.0;
			double num7 = -5.0;
			num4 = 175.0;
			Quaternion quaternion4 = Quaternion.Euler((float)num3, (float)num7, (float)num4);
			obj29 = quaternion4;
			Quaternion quaternion5 = (Quaternion)obj * (Quaternion)obj29;
			obj = quaternion5;
			quaternion_3 = (Quaternion)obj;
		}
		try
		{
			obj = vrrig_0;
			obj29 = null;
			if ((VRRig)obj == (UnityEngine.Object)obj29)
			{
				obj = obj33;
				GameObject gameObject = new GameObject((string)obj);
				obj = gameObject;
				global::_003CModule_003E.gameObject_25 = (GameObject)obj;
				obj = global::_003CModule_003E.gameObject_25;
				((GameObject)obj).SetActive(value: false);
				GorillaTagger instance6 = GorillaTagger.Instance;
				obj = instance6;
				obj = ((GorillaTagger)obj).offlineVRRig;
				GTPlayer instance7 = GTPlayer.Instance;
				obj29 = instance7;
				Transform transform2 = ((GTPlayer)obj29).transform;
				obj29 = transform2;
				Vector3 position5 = ((Transform)obj29).position;
				obj29 = position5;
				GTPlayer instance8 = GTPlayer.Instance;
				transform_ = instance8;
				Transform transform3 = ((GTPlayer)transform_).transform;
				transform_ = transform3;
				Quaternion rotation5 = ((Transform)transform_).rotation;
				transform_ = rotation5;
				obj30 = global::_003CModule_003E.gameObject_25;
				Transform transform4 = ((GameObject)obj30).transform;
				obj30 = transform4;
				VRRig vRRig = UnityEngine.Object.Instantiate((VRRig)obj, (Vector3)obj29, (Quaternion)transform_, (Transform)obj30);
				obj = vRRig;
				vrrig_0 = (VRRig)obj;
				obj = vrrig_0;
				Vector3 zero = Vector3.zero;
				obj29 = zero;
				((VRRig)obj).headBodyOffset = (Vector3)obj29;
				obj = vrrig_0;
				GameObject gameObject2 = ((VRRig)obj).gameObject;
				obj = gameObject2;
				((GameObject)obj).SetActive(value: false);
				obj = vrrig_0;
				Transform transform5 = ((VRRig)obj).transform;
				obj = transform5;
				GorillaTagger instance9 = GorillaTagger.Instance;
				obj29 = instance9;
				obj29 = ((GorillaTagger)obj29).offlineVRRig;
				Transform transform6 = ((VRRig)obj29).transform;
				obj29 = transform6;
				Transform parent = ((Transform)obj29).parent;
				obj29 = parent;
				((Transform)obj).SetParent((Transform)obj29);
				obj = global::_003CModule_003E.gameObject_25;
				UnityEngine.Object.Destroy((GameObject)obj);
				obj = vrrig_0;
				Transform transform7 = ((VRRig)obj).transform;
				obj = transform7;
				obj29 = obj32;
				Transform transform8 = ((Transform)obj).Find((string)obj29);
				obj = transform8;
				global::_003CModule_003E.transform_14 = (Transform)obj;
				obj = vrrig_0;
				Transform transform9 = ((VRRig)obj).transform;
				obj = transform9;
				obj29 = obj31;
				Transform transform10 = ((Transform)obj).Find((string)obj29);
				obj = transform10;
				global::_003CModule_003E.transform_15 = (Transform)obj;
				obj = global::_003CModule_003E.transform_14;
				obj29 = null;
				if ((Transform)obj != (UnityEngine.Object)obj29)
				{
					obj = global::_003CModule_003E.transform_14;
					GameObject gameObject3 = ((Transform)obj).gameObject;
					obj = gameObject3;
					((GameObject)obj).SetActive(value: false);
				}
				obj = global::_003CModule_003E.transform_15;
				obj29 = null;
				if ((Transform)obj != (UnityEngine.Object)obj29)
				{
					obj = global::_003CModule_003E.transform_15;
					GameObject gameObject4 = ((Transform)obj).gameObject;
					obj = gameObject4;
					((GameObject)obj).SetActive(value: false);
				}
				obj = vrrig_0;
				global::OwnershipGaurd component = ((VRRig)obj).GetComponent<global::OwnershipGaurd>();
				obj = component;
				((global::OwnershipGaurd)obj).enabled = false;
				obj = vrrig_0;
				GameObject gameObject5 = ((VRRig)obj).gameObject;
				obj = gameObject5;
				((GameObject)obj).SetActive(value: true);
			}
			obj = material_0;
			obj29 = null;
			double num7;
			if ((Material)obj == (UnityEngine.Object)obj29)
			{
				num2 = 0.1899999976158142;
				num3 = 0.5299999713897705;
				num7 = 0.7400000095367432;
				num4 = 0.20000000298023224;
				Color color = new Color((float)num2, (float)num3, (float)num7, (float)num4);
				obj = color;
				Material material = ShaderPatch.CreateTransparentMat((Color)obj);
				obj = material;
				material_0 = (Material)obj;
			}
			obj = material_0;
			num3 = 0.1899999976158142;
			num7 = 0.5299999713897705;
			num4 = 0.7400000095367432;
			num5 = 0.20000000298023224;
			Color color2 = new Color((float)num3, (float)num7, (float)num4, (float)num5);
			obj29 = color2;
			((Material)obj).color = (Color)obj29;
			obj = vrrig_0;
			obj = ((VRRig)obj).mainSkin;
			obj29 = material_0;
			((SkinnedMeshRenderer)obj).material = (Material)obj29;
			obj = vrrig_0;
			obj = ((VRRig)obj).headConstraint;
			Transform transform11 = ((Transform)obj).transform;
			obj = transform11;
			GTPlayer instance10 = GTPlayer.Instance;
			obj29 = instance10;
			obj29 = ((GTPlayer)obj29).headCollider;
			Transform transform12 = ((SphereCollider)obj29).transform;
			obj29 = transform12;
			Vector3 position6 = ((Transform)obj29).position;
			obj29 = position6;
			GTPlayer instance11 = GTPlayer.Instance;
			transform_ = instance11;
			transform_ = ((GTPlayer)transform_).headCollider;
			Transform transform13 = ((SphereCollider)transform_).transform;
			transform_ = transform13;
			Quaternion rotation6 = ((Transform)transform_).rotation;
			transform_ = rotation6;
			((Transform)obj).SetPositionAndRotation((Vector3)obj29, (Quaternion)transform_);
			obj = vrrig_0;
			obj = ((VRRig)obj).leftHandTransform;
			GorillaTagger instance12 = GorillaTagger.Instance;
			obj29 = instance12;
			obj29 = ((GorillaTagger)obj29).leftHandTransform;
			Vector3 position7 = ((Transform)obj29).position;
			obj29 = position7;
			GorillaTagger instance13 = GorillaTagger.Instance;
			transform_ = instance13;
			transform_ = ((GorillaTagger)transform_).leftHandTransform;
			Quaternion rotation7 = ((Transform)transform_).rotation;
			transform_ = rotation7;
			((Transform)obj).SetPositionAndRotation((Vector3)obj29, (Quaternion)transform_);
			obj = vrrig_0;
			obj = ((VRRig)obj).rightHandTransform;
			GorillaTagger instance14 = GorillaTagger.Instance;
			obj29 = instance14;
			obj29 = ((GorillaTagger)obj29).rightHandTransform;
			Vector3 position8 = ((Transform)obj29).position;
			obj29 = position8;
			GorillaTagger instance15 = GorillaTagger.Instance;
			transform_ = instance15;
			transform_ = ((GorillaTagger)transform_).rightHandTransform;
			Quaternion rotation8 = ((Transform)transform_).rotation;
			transform_ = rotation8;
			((Transform)obj).SetPositionAndRotation((Vector3)obj29, (Quaternion)transform_);
			obj = vrrig_0;
			Transform transform14 = ((VRRig)obj).transform;
			obj = transform14;
			GTPlayer instance16 = GTPlayer.Instance;
			obj29 = instance16;
			Transform transform15 = ((GTPlayer)obj29).transform;
			obj29 = transform15;
			Vector3 position9 = ((Transform)obj29).position;
			obj29 = position9;
			GTPlayer instance17 = GTPlayer.Instance;
			transform_ = instance17;
			Transform transform16 = ((GTPlayer)transform_).transform;
			transform_ = transform16;
			Quaternion rotation9 = ((Transform)transform_).rotation;
			transform_ = rotation9;
			((Transform)obj).SetPositionAndRotation((Vector3)obj29, (Quaternion)transform_);
		}
		catch
		{
		}
	}

	public Class171()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class171()
	{
		int num = 31;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2 = 1;
					num = 61;
					while (true)
					{
						int num3 = num2 * 4;
						while (true)
						{
							byte[] array = new byte[1];
							while (true)
							{
								object[] array2 = new object[1];
								num = 70;
								while (true)
								{
									long[] array3 = new long[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemotingSurrogateSelectorToday.StoreOperationStageComponentFileEverything);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 == 1)
												{
													return;
												}
												while (true)
												{
													IL_028a:
													byte b = *ptr2;
													while (true)
													{
														IL_0271:
														ptr2++;
														num = 29;
														while (true)
														{
															IL_0261:
															if (b >= 1)
															{
																while (b <= 11)
																{
																	num = 43;
																	while (true)
																	{
																		IL_0241:
																		if (6 >= b)
																		{
																			while (true)
																			{
																				IL_0234:
																				if (6 > b)
																				{
																					while (true)
																					{
																						IL_0224:
																						if (3 >= b)
																						{
																							while (true)
																							{
																								IL_0214:
																								if (3 <= b)
																								{
																									while (true)
																									{
																										IL_01fd:
																										((delegate*<void>)HasKeyUpgrade[*(int*)(ptr2 + num3)])();
																										while (true)
																										{
																											IL_01e4:
																											ptr2 += 8;
																											num = 109;
																											while (num != 109)
																											{
																												if (num != 1090)
																												{
																													goto IL_0428;
																												}
																												switch (num)
																												{
																												case 69:
																													goto IL_01e4;
																												case 83:
																												case 102:
																													goto IL_01fd;
																												case 39:
																													goto IL_0214;
																												case 37:
																													goto IL_0224;
																												case 57:
																													goto IL_0234;
																												case 43:
																													goto IL_0241;
																												case 90:
																													goto IL_024e;
																												case 29:
																													goto IL_0261;
																												case 74:
																													goto IL_0271;
																												case 17:
																												case 51:
																													goto IL_028a;
																												case 3:
																													goto IL_0295;
																												case 11:
																													goto IL_02a0;
																												case 7:
																												case 13:
																													goto IL_02b3;
																												case 9:
																													goto IL_02c1;
																												case 73:
																													goto IL_02e4;
																												case 2:
																													goto IL_02ef;
																												case 62:
																													goto IL_02fa;
																												case 21:
																												case 40:
																													goto IL_0308;
																												case 33:
																													goto IL_0321;
																												case 41:
																													goto IL_0334;
																												case 66:
																													goto IL_0342;
																												case 4:
																												case 16:
																													goto IL_0355;
																												case 77:
																													goto IL_037c;
																												case 50:
																													goto IL_038a;
																												case 67:
																												case 78:
																													goto IL_0398;
																												case 84:
																													goto IL_03b4;
																												case 46:
																													goto IL_03c2;
																												case 53:
																												case 86:
																													goto IL_03d5;
																												case 45:
																													goto IL_03ee;
																												case 91:
																													goto IL_0401;
																												case 36:
																												case 58:
																													goto IL_040f;
																												case 44:
																													goto IL_0428;
																												case 99:
																													goto IL_043b;
																												case 35:
																													goto IL_044e;
																												case 60:
																													goto IL_0459;
																												case 92:
																													goto IL_046c;
																												case 6:
																													goto IL_047a;
																												case 88:
																												case 98:
																													goto IL_0488;
																												case 1:
																													goto IL_049d;
																												case 80:
																													goto IL_04b0;
																												case 28:
																													goto IL_04bb;
																												case 47:
																												case 96:
																													goto IL_04c9;
																												case 97:
																													goto IL_04e3;
																												case 49:
																													goto IL_04fa;
																												case 18:
																													goto IL_0508;
																												case 34:
																													goto IL_0518;
																												case 75:
																													goto IL_0523;
																												case 82:
																												case 89:
																													goto IL_052e;
																												case 10:
																													goto IL_0548;
																												case 0:
																												case 14:
																												case 15:
																												case 19:
																												case 20:
																												case 22:
																												case 24:
																												case 25:
																												case 48:
																												case 54:
																												case 55:
																												case 72:
																												case 76:
																												case 94:
																													goto end_IL_024e;
																												case 42:
																													goto IL_056d;
																												case 5:
																												case 8:
																												case 12:
																												case 23:
																												case 27:
																												case 59:
																												case 64:
																												case 65:
																												case 71:
																												case 95:
																												case 100:
																												case 101:
																													goto end_IL_01d1;
																												case 87:
																													goto end_IL_057b;
																												case 63:
																													goto end_IL_058e;
																												case 70:
																												case 79:
																													goto end_IL_0598;
																												case 32:
																													goto end_IL_05a3;
																												case 26:
																												case 56:
																													goto end_IL_05b3;
																												case 61:
																													goto end_IL_05cc;
																												case 52:
																												case 68:
																												case 81:
																												case 85:
																													goto end_IL_05dc;
																												case 30:
																													goto end_IL_05ec;
																												case 31:
																													goto end_IL_0609;
																												case 38:
																												case 93:
																													return;
																												}
																												continue;
																												end_IL_01d1:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_044e;
																								IL_049d:
																								ptr2 += 8;
																								break;
																								IL_044e:
																								if (1 >= b)
																								{
																									goto IL_0459;
																								}
																								goto IL_046c;
																								IL_0459:
																								if (1 > b)
																								{
																								}
																								goto end_IL_024e;
																								IL_046c:
																								if (2 < b)
																								{
																									goto end_IL_024e;
																								}
																								goto IL_047a;
																								IL_047a:
																								if (2 > b)
																								{
																									goto end_IL_024e;
																								}
																								goto IL_0488;
																								IL_0488:
																								((delegate*<void>)HasKeyUpgrade[*(int*)(ptr2 + num3)])();
																								goto IL_049d;
																							}
																							break;
																						}
																						goto IL_04b0;
																						IL_0548:
																						num5--;
																						break;
																						IL_04b0:
																						if (4 >= b)
																						{
																							goto IL_04bb;
																						}
																						goto IL_0518;
																						IL_04bb:
																						if (4 > b)
																						{
																							goto end_IL_024e;
																						}
																						goto IL_04c9;
																						IL_04c9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(float*)(ptr2 + num3);
																						goto IL_04e3;
																						IL_04e3:
																						array[num5] = 3;
																						num = 49;
																						goto IL_04fa;
																						IL_04fa:
																						num5++;
																						goto IL_0508;
																						IL_0508:
																						ptr2 += 8;
																						break;
																						IL_0518:
																						if (5 < b)
																						{
																							goto end_IL_024e;
																						}
																						goto IL_0523;
																						IL_0523:
																						if (5 > b)
																						{
																							goto end_IL_024e;
																						}
																						goto IL_052e;
																						IL_052e:
																						float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]));
																						goto IL_0548;
																					}
																					break;
																				}
																				goto IL_02b3;
																				IL_03c2:
																				ptr2 += 8;
																				break;
																				IL_02b3:
																				array[num5] = 5;
																				goto IL_02c1;
																				IL_02c1:
																				array2[num5] = ((delegate*<List<V3T>>)HasKeyUpgrade[*(int*)(ptr2 + num3)])();
																				goto IL_03b4;
																				IL_03b4:
																				num5++;
																				goto IL_03c2;
																			}
																			break;
																		}
																		goto IL_0295;
																		IL_043b:
																		num5--;
																		break;
																		IL_0295:
																		if (9 < b)
																		{
																			goto IL_02a0;
																		}
																		goto IL_02e4;
																		IL_02a0:
																		if (10 < b)
																		{
																			goto IL_037c;
																		}
																		goto IL_0401;
																		IL_0401:
																		if (10 > b)
																		{
																			goto end_IL_024e;
																		}
																		goto IL_040f;
																		IL_040f:
																		list_3 = (List<V3T>)array2[num5 - 1];
																		goto IL_0428;
																		IL_0428:
																		num5--;
																		break;
																		IL_037c:
																		if (11 < b)
																		{
																			goto end_IL_024e;
																		}
																		goto IL_038a;
																		IL_038a:
																		if (11 > b)
																		{
																			goto end_IL_024e;
																		}
																		goto IL_0398;
																		IL_0398:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		break;
																		IL_02e4:
																		if (9 > b)
																		{
																			goto IL_02ef;
																		}
																		goto IL_0355;
																		IL_02ef:
																		if (7 >= b)
																		{
																			goto IL_02fa;
																		}
																		goto IL_0334;
																		IL_02fa:
																		if (7 > b)
																		{
																			goto end_IL_024e;
																		}
																		goto IL_0308;
																		IL_0308:
																		list_0 = (List<V3T>)array2[num5 - 1];
																		goto IL_0321;
																		IL_0321:
																		num5--;
																		break;
																		IL_0334:
																		if (8 < b)
																		{
																			goto end_IL_024e;
																		}
																		goto IL_0342;
																		IL_0342:
																		if (8 > b)
																		{
																			goto end_IL_024e;
																		}
																		goto IL_03d5;
																		IL_03d5:
																		list_1 = (List<V3T>)array2[num5 - 1];
																		goto IL_03ee;
																		IL_03ee:
																		num5--;
																		break;
																		IL_0355:
																		list_2 = (List<V3T>)array2[num5 - 1];
																		num = 99;
																		goto IL_043b;
																	}
																	goto end_IL_0261;
																	continue;
																	end_IL_024e:
																	break;
																	IL_024e:;
																}
															}
															((delegate*<void>)HasKeyUpgrade[*(int*)(ptr2 + num3)])();
															goto IL_056d;
															IL_056d:
															ptr2 += 8;
															break;
															continue;
															end_IL_0261:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_057b:
												break;
											}
											continue;
											end_IL_058e:
											break;
										}
										continue;
										end_IL_0598:
										break;
									}
									continue;
									end_IL_05a3:
									break;
								}
								continue;
								end_IL_05b3:
								break;
							}
							continue;
							end_IL_05cc:
							break;
						}
						continue;
						end_IL_05dc:
						break;
					}
					continue;
					end_IL_05ec:
					break;
				}
				continue;
				end_IL_0609:
				break;
			}
		}
	}

	private unsafe static int smethod_0()
	{
		int num = 47;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 103;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AssemblyReferenceDependentAssemblyEntryFieldIdVersionAdded.LegalKeySizesGlobalResourceContextBestFitCultureInfo);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 87;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 48;
															while (true)
															{
																IL_02ff:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02f2:
																		if (b <= 15)
																		{
																			while (true)
																			{
																				IL_02e2:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02d2:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02c5:
																								if (12 <= b)
																								{
																									while (true)
																									{
																										IL_027a:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 150;
																										while (true)
																										{
																											if (num != 150)
																											{
																												if (num != 1131)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 85:
																												case 128:
																													goto IL_027a;
																												case 20:
																													goto IL_02c5;
																												case 134:
																												case 143:
																													goto IL_02d2;
																												case 104:
																													goto IL_02e2;
																												case 33:
																													goto IL_02f2;
																												case 48:
																													goto IL_02ff;
																												case 6:
																													goto end_IL_02ff;
																												case 9:
																												case 21:
																													goto end_IL_030f;
																												case 52:
																												case 107:
																													goto IL_0341;
																												case 76:
																													goto IL_034c;
																												case 15:
																													goto IL_035a;
																												case 94:
																													goto IL_0368;
																												case 64:
																													goto IL_0384;
																												case 38:
																													goto IL_0392;
																												case 14:
																												case 23:
																													goto IL_03a0;
																												case 66:
																													goto IL_03e4;
																												case 124:
																													goto IL_03f8;
																												case 26:
																												case 127:
																													goto IL_040b;
																												case 80:
																													goto IL_0419;
																												case 36:
																													goto IL_043c;
																												case 68:
																													goto IL_0446;
																												case 88:
																													goto IL_0454;
																												case 91:
																													goto IL_047b;
																												case 31:
																													goto IL_048e;
																												case 30:
																													goto IL_049c;
																												case 13:
																												case 112:
																													goto IL_04a7;
																												case 122:
																													goto IL_04c3;
																												case 28:
																													goto IL_04d1;
																												case 4:
																												case 53:
																													goto IL_04df;
																												case 133:
																													goto IL_0541;
																												case 109:
																													goto IL_0554;
																												case 73:
																													goto IL_0562;
																												case 126:
																													goto IL_0575;
																												case 19:
																													goto IL_0583;
																												case 54:
																													goto IL_0591;
																												case 61:
																												case 69:
																													goto IL_059c;
																												case 101:
																													goto IL_05ba;
																												case 82:
																													goto IL_05c8;
																												case 105:
																												case 110:
																													goto IL_05db;
																												case 63:
																													goto IL_05e9;
																												case 90:
																													goto IL_05f4;
																												case 12:
																													goto IL_0602;
																												case 125:
																												case 138:
																													goto IL_0610;
																												case 120:
																													goto IL_0629;
																												case 97:
																													goto IL_0637;
																												case 18:
																													goto IL_0645;
																												case 71:
																												case 135:
																													goto IL_0658;
																												case 129:
																													goto IL_0698;
																												case 60:
																													goto IL_06ac;
																												case 56:
																													goto IL_06bf;
																												case 96:
																													goto IL_06cd;
																												case 11:
																												case 27:
																													goto IL_06e4;
																												case 89:
																													goto IL_070d;
																												case 117:
																													goto IL_0726;
																												case 25:
																													goto IL_0734;
																												case 22:
																												case 65:
																													goto IL_073f;
																												case 37:
																													goto IL_077e;
																												case 114:
																													goto IL_0791;
																												case 113:
																													goto IL_079f;
																												case 10:
																												case 139:
																													goto IL_07ad;
																												case 3:
																													goto IL_07bb;
																												case 0:
																													goto IL_07d3;
																												case 51:
																													goto IL_07e1;
																												case 83:
																													goto IL_07f4;
																												case 72:
																													goto IL_07ff;
																												case 43:
																												case 93:
																													goto IL_080a;
																												case 57:
																													goto IL_0833;
																												case 130:
																													goto IL_0841;
																												case 1:
																												case 98:
																													goto IL_0851;
																												case 5:
																												case 7:
																												case 8:
																												case 16:
																												case 32:
																												case 35:
																												case 39:
																												case 50:
																												case 58:
																												case 59:
																												case 67:
																												case 70:
																												case 74:
																												case 75:
																												case 78:
																												case 79:
																												case 81:
																												case 84:
																												case 92:
																												case 100:
																												case 115:
																												case 118:
																												case 119:
																												case 121:
																												case 132:
																												case 137:
																												case 140:
																													goto end_IL_0267;
																												case 17:
																												case 24:
																												case 29:
																												case 34:
																												case 40:
																												case 41:
																												case 42:
																												case 44:
																												case 45:
																												case 49:
																												case 77:
																												case 86:
																												case 87:
																												case 95:
																												case 99:
																												case 102:
																												case 141:
																												case 142:
																													goto end_IL_0328;
																												case 116:
																													goto end_IL_0879;
																												case 106:
																													goto end_IL_088c;
																												case 108:
																													goto end_IL_089f;
																												case 2:
																													goto end_IL_08aa;
																												case 62:
																												case 136:
																													goto end_IL_08ba;
																												case 103:
																													goto end_IL_08ca;
																												case 111:
																												case 131:
																													goto end_IL_08da;
																												case 46:
																													goto end_IL_08ea;
																												case 47:
																													goto end_IL_0903;
																												case 55:
																												case 123:
																													goto IL_091e;
																												}
																												continue;
																											}
																											array[num5 - 2] = 0;
																											goto IL_047b;
																											IL_047b:
																											num5--;
																											goto end_IL_0328;
																											continue;
																											end_IL_0267:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0341;
																								IL_03e4:
																								array[num5 - 2] = 0;
																								goto IL_03f8;
																								IL_0341:
																								if (10 >= b)
																								{
																									goto IL_034c;
																								}
																								goto IL_0384;
																								IL_034c:
																								if (10 > b)
																								{
																									goto IL_035a;
																								}
																								goto IL_040b;
																								IL_035a:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_0368;
																								IL_0368:
																								if (9 <= b)
																								{
																									goto end_IL_0328;
																								}
																								num = 58;
																								break;
																								IL_03f8:
																								num5--;
																								goto end_IL_0328;
																								IL_040b:
																								array[num5] = 0;
																								goto IL_0419;
																								IL_0419:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_043c;
																								IL_043c:
																								array2[num5] = null;
																								goto IL_0446;
																								IL_0446:
																								num5++;
																								goto IL_0454;
																								IL_0454:
																								ptr2 += 8;
																								goto end_IL_0328;
																								IL_0384:
																								if (11 < b)
																								{
																									break;
																								}
																								goto IL_0392;
																								IL_0392:
																								if (11 > b)
																								{
																									break;
																								}
																								goto IL_03a0;
																								IL_03a0:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_03e4;
																							}
																							break;
																						}
																						goto IL_048e;
																						IL_0562:
																						if (15 > b)
																						{
																						}
																						break;
																						IL_048e:
																						if (14 >= b)
																						{
																							goto IL_049c;
																						}
																						goto IL_0554;
																						IL_049c:
																						if (14 <= b)
																						{
																							goto IL_04a7;
																						}
																						goto IL_04c3;
																						IL_04a7:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0328;
																						IL_04c3:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_04d1;
																						IL_04d1:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_04df;
																						IL_04df:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0541;
																						IL_0541:
																						num5 -= 2;
																						goto end_IL_0328;
																						IL_0554:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_0562;
																					}
																					break;
																				}
																				goto IL_0575;
																				IL_0841:
																				num5--;
																				goto end_IL_0328;
																				IL_0575:
																				if (8 > b)
																				{
																					goto IL_0583;
																				}
																				goto IL_0851;
																				IL_0583:
																				if (4 >= b)
																				{
																					goto IL_0591;
																				}
																				goto IL_0726;
																				IL_0591:
																				if (4 <= b)
																				{
																					goto IL_059c;
																				}
																				goto IL_05db;
																				IL_059c:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_05ba;
																				IL_05ba:
																				ptr2 += 8;
																				goto IL_05c8;
																				IL_05c8:
																				num5--;
																				goto end_IL_0328;
																				IL_05db:
																				if (2 >= b)
																				{
																					goto IL_05e9;
																				}
																				goto IL_06bf;
																				IL_05e9:
																				if (2 > b)
																				{
																					goto IL_05f4;
																				}
																				goto IL_0658;
																				IL_05f4:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0602;
																				IL_0602:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0610;
																				IL_0610:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0629;
																				IL_0629:
																				array[num5] = 0;
																				goto IL_0637;
																				IL_0637:
																				num5++;
																				goto IL_0645;
																				IL_0645:
																				ptr2 += 8;
																				goto end_IL_0328;
																				IL_0658:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0698;
																				IL_0698:
																				array[num5 - 2] = 0;
																				goto IL_06ac;
																				IL_06ac:
																				num5--;
																				goto end_IL_0328;
																				IL_06bf:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_06cd;
																				IL_06cd:
																				if (3 > b)
																				{
																					break;
																				}
																				num = 11;
																				goto IL_06e4;
																				IL_0851:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0328;
																				IL_06e4:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_070d;
																				IL_070d:
																				array[num5 - 1] = 5;
																				goto end_IL_0328;
																				IL_0726:
																				if (6 >= b)
																				{
																					goto IL_0734;
																				}
																				goto IL_07f4;
																				IL_0734:
																				if (6 <= b)
																				{
																					goto IL_073f;
																				}
																				goto IL_0791;
																				IL_073f:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_077e;
																				IL_077e:
																				num5 -= 3;
																				goto end_IL_0328;
																				IL_0791:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_079f;
																				IL_079f:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_07ad;
																				IL_07ad:
																				array[num5] = 5;
																				goto IL_07bb;
																				IL_07bb:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_07d3;
																				IL_07d3:
																				num5++;
																				goto IL_07e1;
																				IL_07e1:
																				ptr2 += 8;
																				goto end_IL_0328;
																				IL_07f4:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_07ff;
																				IL_07ff:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_080a;
																				IL_080a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0833;
																				IL_0833:
																				ptr2 += 8;
																				goto IL_0841;
																			}
																		}
																		else
																		{
																			num = 140;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0328;
																continue;
																end_IL_02ff:
																break;
															}
															continue;
															end_IL_030f:
															break;
														}
														continue;
														end_IL_0328:
														break;
													}
													continue;
												}
												goto IL_091e;
												IL_091e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0879:
												break;
											}
											continue;
											end_IL_088c:
											break;
										}
										continue;
										end_IL_089f:
										break;
									}
									continue;
									end_IL_08aa:
									break;
								}
								continue;
								end_IL_08ba:
								break;
							}
							continue;
							end_IL_08ca:
							break;
						}
						continue;
						end_IL_08da:
						break;
					}
					continue;
					end_IL_08ea:
					break;
				}
				continue;
				end_IL_0903:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UserDirectoriesMetadataToken.StrongNameIdentityPermissionParenthesisFormat);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_032f:
														num = 26;
														while (true)
														{
															IL_0324:
															byte b = *ptr2;
															while (true)
															{
																IL_0314:
																ptr2++;
																while (true)
																{
																	IL_0304:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02e4:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02d7:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02c7:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_02b7:
																										if (10 >= b)
																										{
																											while (true)
																											{
																												IL_02a7:
																												if (10 > b)
																												{
																													while (9 >= b)
																													{
																														num = 153;
																														while (true)
																														{
																															if (num != 153)
																															{
																																if (num != 1134)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 0:
																																case 60:
																																	goto IL_0294;
																																case 15:
																																	goto IL_02a7;
																																case 106:
																																	goto IL_02b7;
																																case 62:
																																	goto IL_02c7;
																																case 29:
																																case 37:
																																	goto IL_02d7;
																																case 36:
																																	goto IL_02e4;
																																case 131:
																																	goto IL_02f4;
																																case 101:
																																	goto IL_0304;
																																case 16:
																																	goto IL_0314;
																																case 26:
																																	goto IL_0324;
																																case 88:
																																	goto IL_032f;
																																case 2:
																																case 114:
																																	goto IL_033a;
																																case 46:
																																	goto IL_0348;
																																case 5:
																																	goto IL_0356;
																																case 40:
																																	goto IL_0364;
																																case 4:
																																case 76:
																																	goto IL_0372;
																																case 119:
																																	goto IL_03d4;
																																case 33:
																																case 134:
																																	goto IL_03e7;
																																case 67:
																																case 145:
																																	goto IL_0403;
																																case 7:
																																	goto IL_0411;
																																case 73:
																																case 96:
																																	goto IL_0437;
																																case 70:
																																	goto IL_0445;
																																case 121:
																																	goto IL_0468;
																																case 47:
																																	goto IL_0472;
																																case 89:
																																	goto IL_0480;
																																case 20:
																																case 113:
																																	goto IL_0493;
																																case 146:
																																	goto IL_04aa;
																																case 8:
																																case 68:
																																	goto IL_04b8;
																																case 63:
																																	goto IL_04fc;
																																case 9:
																																	goto IL_0510;
																																case 17:
																																case 116:
																																	goto IL_0523;
																																case 50:
																																	goto IL_0563;
																																case 53:
																																	goto IL_0577;
																																case 10:
																																	goto IL_058a;
																																case 66:
																																case 98:
																																	goto IL_0595;
																																case 109:
																																	goto IL_05ad;
																																case 91:
																																case 110:
																																	goto IL_05bb;
																																case 130:
																																	goto IL_05c9;
																																case 42:
																																case 44:
																																	goto IL_05d4;
																																case 125:
																																	goto IL_0613;
																																case 141:
																																	goto IL_0626;
																																case 133:
																																	goto IL_0634;
																																case 18:
																																case 108:
																																	goto IL_064b;
																																case 11:
																																	goto IL_0659;
																																case 21:
																																	goto IL_0671;
																																case 93:
																																	goto IL_067f;
																																case 3:
																																	goto IL_0692;
																																case 104:
																																	goto IL_06a0;
																																case 45:
																																case 138:
																																	goto IL_06ae;
																																case 64:
																																	goto IL_06d7;
																																case 69:
																																	goto IL_06e5;
																																case 102:
																																	goto IL_0701;
																																case 83:
																																case 122:
																																	goto IL_070c;
																																case 82:
																																	goto IL_072a;
																																case 1:
																																	goto IL_0738;
																																case 59:
																																	goto IL_074b;
																																case 79:
																																case 137:
																																	goto IL_0756;
																																case 32:
																																	goto IL_0764;
																																case 39:
																																case 112:
																																	goto IL_0772;
																																case 65:
																																	goto IL_079b;
																																case 75:
																																	goto IL_07b4;
																																case 19:
																																	goto IL_07bf;
																																case 129:
																																	goto IL_07cd;
																																case 24:
																																case 80:
																																	goto IL_07db;
																																case 144:
																																	goto IL_07f4;
																																case 142:
																																	goto IL_0802;
																																case 139:
																																	goto IL_0810;
																																case 86:
																																case 107:
																																	goto IL_0829;
																																case 23:
																																	goto IL_0869;
																																case 128:
																																	goto IL_087d;
																																case 6:
																																case 12:
																																case 13:
																																case 28:
																																case 31:
																																case 34:
																																case 35:
																																case 41:
																																case 49:
																																case 54:
																																case 57:
																																case 58:
																																case 61:
																																case 77:
																																case 81:
																																case 90:
																																case 92:
																																case 94:
																																case 105:
																																case 115:
																																case 118:
																																case 126:
																																case 127:
																																case 132:
																																case 140:
																																case 143:
																																	goto end_IL_0294;
																																case 14:
																																case 22:
																																case 25:
																																case 27:
																																case 30:
																																case 38:
																																case 43:
																																case 51:
																																case 52:
																																case 55:
																																case 56:
																																case 72:
																																case 100:
																																case 103:
																																case 111:
																																case 117:
																																case 135:
																																case 136:
																																	goto end_IL_0281;
																																case 124:
																																	goto end_IL_08a0;
																																case 99:
																																	goto end_IL_08b3;
																																case 71:
																																	goto end_IL_08bd;
																																case 78:
																																	goto end_IL_08c8;
																																case 87:
																																case 120:
																																	goto end_IL_08d8;
																																case 74:
																																	goto end_IL_08e8;
																																case 95:
																																case 123:
																																	goto end_IL_08f8;
																																case 84:
																																	goto end_IL_0908;
																																case 85:
																																	goto end_IL_0918;
																																case 48:
																																case 97:
																																	goto IL_0933;
																																}
																																continue;
																															}
																															if (9 > b)
																															{
																																goto end_IL_0294;
																															}
																															break;
																															continue;
																															end_IL_0281:
																															break;
																														}
																														goto end_IL_0304;
																														continue;
																														end_IL_0294:
																														break;
																														IL_0294:;
																													}
																													break;
																												}
																												goto IL_0437;
																												IL_0480:
																												ptr2 += 8;
																												goto end_IL_0304;
																												IL_0437:
																												array[num5] = 0;
																												goto IL_0445;
																												IL_0445:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0468;
																												IL_0468:
																												array2[num5] = null;
																												goto IL_0472;
																												IL_0472:
																												num5++;
																												goto IL_0480;
																											}
																											break;
																										}
																										goto IL_0493;
																										IL_04fc:
																										array[num5 - 2] = 0;
																										goto IL_0510;
																										IL_0493:
																										if (11 < b)
																										{
																											break;
																										}
																										num = 146;
																										goto IL_04aa;
																										IL_0510:
																										num5--;
																										goto end_IL_0304;
																										IL_04aa:
																										if (11 > b)
																										{
																											break;
																										}
																										goto IL_04b8;
																										IL_04b8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_04fc;
																									}
																									break;
																								}
																								goto IL_0523;
																								IL_0577:
																								num5--;
																								goto end_IL_0304;
																								IL_0523:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0563;
																								IL_0563:
																								array[num5 - 2] = 0;
																								goto IL_0577;
																							}
																							break;
																						}
																						goto IL_033a;
																						IL_0411:
																						if (15 <= b)
																						{
																						}
																						break;
																						IL_033a:
																						if (14 >= b)
																						{
																							goto IL_0348;
																						}
																						goto IL_0403;
																						IL_0348:
																						if (14 > b)
																						{
																							goto IL_0356;
																						}
																						goto IL_03e7;
																						IL_0356:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_0364;
																						IL_0364:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_0372;
																						IL_0372:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_03d4;
																						IL_03d4:
																						num5 -= 2;
																						goto end_IL_0304;
																						IL_03e7:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0304;
																						IL_0403:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_0411;
																					}
																					break;
																				}
																				goto IL_058a;
																				IL_0869:
																				array[num5 - 2] = 0;
																				goto IL_087d;
																				IL_058a:
																				if (8 <= b)
																				{
																					goto IL_0595;
																				}
																				goto IL_05ad;
																				IL_0595:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0304;
																				IL_05ad:
																				if (4 < b)
																				{
																					goto IL_05bb;
																				}
																				goto IL_0701;
																				IL_05bb:
																				if (6 >= b)
																				{
																					goto IL_05c9;
																				}
																				goto IL_0692;
																				IL_05c9:
																				if (6 <= b)
																				{
																					goto IL_05d4;
																				}
																				goto IL_0626;
																				IL_05d4:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0613;
																				IL_0613:
																				num5 -= 3;
																				goto end_IL_0304;
																				IL_0626:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0634;
																				IL_0634:
																				if (5 > b)
																				{
																					break;
																				}
																				num = 108;
																				goto IL_064b;
																				IL_087d:
																				num5--;
																				goto end_IL_0304;
																				IL_064b:
																				array[num5] = 5;
																				goto IL_0659;
																				IL_0659:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0671;
																				IL_0671:
																				num5++;
																				goto IL_067f;
																				IL_067f:
																				ptr2 += 8;
																				goto end_IL_0304;
																				IL_0692:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_06a0;
																				IL_06a0:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_06ae;
																				IL_06ae:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06d7;
																				IL_06d7:
																				ptr2 += 8;
																				goto IL_06e5;
																				IL_06e5:
																				num5--;
																				num = 103;
																				goto end_IL_0304;
																				IL_0701:
																				if (4 <= b)
																				{
																					goto IL_070c;
																				}
																				goto IL_074b;
																				IL_070c:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_072a;
																				IL_072a:
																				ptr2 += 8;
																				goto IL_0738;
																				IL_0738:
																				num5--;
																				goto end_IL_0304;
																				IL_074b:
																				if (2 < b)
																				{
																					goto IL_0756;
																				}
																				goto IL_07b4;
																				IL_0756:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0764;
																				IL_0764:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0772;
																				IL_0772:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_079b;
																				IL_079b:
																				array[num5 - 1] = 5;
																				goto end_IL_0304;
																				IL_07b4:
																				if (2 > b)
																				{
																					goto IL_07bf;
																				}
																				goto IL_0829;
																				IL_07bf:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_07cd;
																				IL_07cd:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_07db;
																				IL_07db:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_07f4;
																				IL_07f4:
																				array[num5] = 0;
																				goto IL_0802;
																				IL_0802:
																				num5++;
																				goto IL_0810;
																				IL_0810:
																				ptr2 += 8;
																				num = 51;
																				goto end_IL_0304;
																				IL_0829:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0869;
																			}
																			break;
																			IL_02f4:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0304:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0933;
												IL_0933:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a0:
												break;
											}
											continue;
											end_IL_08b3:
											break;
										}
										continue;
										end_IL_08bd:
										break;
									}
									continue;
									end_IL_08c8:
									break;
								}
								continue;
								end_IL_08d8:
								break;
							}
							continue;
							end_IL_08e8:
							break;
						}
						continue;
						end_IL_08f8:
						break;
					}
					continue;
					end_IL_0908:
					break;
				}
				continue;
				end_IL_0918:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 68;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 99;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetNativeVariantForObjectUsingNamespace.CalendricalCalculationsHelperMultitargetingHelpers);
										num = 79;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 3;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0276:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0256:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0246:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0236:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0226:
																										if (2 > b)
																										{
																											while (true)
																											{
																												IL_0216:
																												if (1 >= b)
																												{
																													while (1 <= b)
																													{
																														while (true)
																														{
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_01d2:
																																array[num5] = 0;
																																num = 108;
																																while (true)
																																{
																																	if (num != 108)
																																	{
																																		if (num != 1089)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 37:
																																			goto IL_01d2;
																																		case 2:
																																		case 92:
																																			goto end_IL_01bf;
																																		case 14:
																																			goto end_IL_01eb;
																																		case 78:
																																		case 93:
																																			goto IL_0216;
																																		case 76:
																																			goto IL_0226;
																																		case 28:
																																		case 55:
																																			goto IL_0236;
																																		case 30:
																																			goto IL_0246;
																																		case 98:
																																			goto IL_0256;
																																		case 87:
																																			goto IL_0266;
																																		case 89:
																																			goto IL_0276;
																																		case 75:
																																			goto end_IL_0276;
																																		case 3:
																																			goto end_IL_0286;
																																		case 96:
																																			goto end_IL_0296;
																																		case 83:
																																			goto IL_02ba;
																																		case 38:
																																		case 48:
																																			goto IL_02db;
																																		case 60:
																																			goto IL_0304;
																																		case 41:
																																			goto IL_0312;
																																		case 25:
																																			goto IL_0325;
																																		case 11:
																																			goto IL_0330;
																																		case 73:
																																		case 80:
																																			goto IL_033e;
																																		case 43:
																																			goto IL_0356;
																																		case 33:
																																			goto IL_0364;
																																		case 58:
																																		case 94:
																																			goto IL_0380;
																																		case 51:
																																			goto IL_038e;
																																		case 95:
																																			goto IL_03b1;
																																		case 66:
																																			goto IL_03bb;
																																		case 64:
																																			goto IL_03c9;
																																		case 15:
																																			goto IL_03dc;
																																		case 23:
																																			goto IL_03ea;
																																		case 82:
																																			goto IL_03f8;
																																		case 90:
																																			goto IL_0403;
																																		case 39:
																																		case 69:
																																			goto IL_0411;
																																		case 34:
																																			goto IL_0451;
																																		case 40:
																																			goto IL_0465;
																																		case 44:
																																			goto IL_0478;
																																		case 81:
																																			goto IL_0486;
																																		case 35:
																																		case 61:
																																			goto IL_0494;
																																		case 26:
																																			goto IL_04c0;
																																		case 86:
																																			goto IL_04ce;
																																		case 24:
																																			goto IL_04dc;
																																		case 8:
																																		case 74:
																																			goto IL_04ef;
																																		case 88:
																																			goto IL_0551;
																																		case 10:
																																			goto IL_0561;
																																		case 27:
																																		case 47:
																																			goto IL_056c;
																																		case 6:
																																			goto IL_0577;
																																		case 77:
																																			goto IL_0584;
																																		case 59:
																																		case 70:
																																			goto IL_058f;
																																		case 0:
																																		case 1:
																																		case 4:
																																		case 5:
																																		case 13:
																																		case 17:
																																		case 20:
																																		case 21:
																																		case 22:
																																		case 50:
																																		case 57:
																																		case 63:
																																		case 65:
																																		case 72:
																																		case 84:
																																		case 85:
																																		case 91:
																																		case 100:
																																			goto end_IL_0206;
																																		case 7:
																																		case 9:
																																		case 16:
																																		case 29:
																																		case 32:
																																		case 45:
																																		case 46:
																																		case 49:
																																		case 52:
																																		case 54:
																																		case 56:
																																		case 62:
																																		case 101:
																																			goto end_IL_02a1;
																																		case 79:
																																			goto end_IL_05bb;
																																		case 31:
																																			goto end_IL_05ce;
																																		case 99:
																																			goto end_IL_05d8;
																																		case 12:
																																			goto end_IL_05ec;
																																		case 18:
																																		case 71:
																																			goto end_IL_0601;
																																		case 97:
																																			goto end_IL_061a;
																																		case 19:
																																		case 53:
																																			goto end_IL_062a;
																																		case 67:
																																			goto end_IL_063a;
																																		case 68:
																																			goto end_IL_064a;
																																		case 36:
																																		case 42:
																																			goto IL_0665;
																																		}
																																		continue;
																																	}
																																	num5++;
																																	goto IL_02ba;
																																	IL_02ba:
																																	ptr2 += 8;
																																	goto end_IL_02a1;
																																	continue;
																																	end_IL_01bf:
																																	break;
																																}
																																break;
																															}
																															continue;
																															end_IL_01eb:
																															break;
																														}
																														continue;
																														end_IL_0206:
																														break;
																													}
																												}
																												else
																												{
																													num = 84;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02db;
																										IL_0312:
																										num5--;
																										goto end_IL_02a1;
																										IL_02db:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0304;
																										IL_0304:
																										ptr2 += 8;
																										goto IL_0312;
																									}
																									break;
																								}
																								goto IL_0325;
																								IL_0364:
																								if (4 <= b)
																								{
																									goto end_IL_02a1;
																								}
																								num = 50;
																								break;
																								IL_0325:
																								if (3 >= b)
																								{
																									goto IL_0330;
																								}
																								goto IL_0356;
																								IL_0330:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_033e;
																								IL_033e:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02a1;
																								IL_0356:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0364;
																							}
																							break;
																						}
																						goto IL_0380;
																						IL_03c9:
																						ptr2 += 8;
																						goto end_IL_02a1;
																						IL_0380:
																						array[num5] = 0;
																						goto IL_038e;
																						IL_038e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03b1;
																						IL_03b1:
																						array2[num5] = null;
																						goto IL_03bb;
																						IL_03bb:
																						num5++;
																						goto IL_03c9;
																					}
																					break;
																				}
																				goto IL_03dc;
																				IL_058f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02a1;
																				IL_03dc:
																				if (8 >= b)
																				{
																					goto IL_03ea;
																				}
																				goto IL_0561;
																				IL_03ea:
																				if (8 > b)
																				{
																					goto IL_03f8;
																				}
																				goto IL_04ef;
																				IL_03f8:
																				if (6 >= b)
																				{
																					goto IL_0403;
																				}
																				goto IL_0478;
																				IL_0403:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0411;
																				IL_0411:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0451;
																				IL_0451:
																				array[num5 - 2] = 0;
																				goto IL_0465;
																				IL_0465:
																				num5--;
																				goto end_IL_02a1;
																				IL_0478:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0486;
																				IL_0486:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0494;
																				IL_0494:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 26;
																				goto IL_04c0;
																				IL_04c0:
																				array[num5] = 0;
																				goto IL_04ce;
																				IL_04ce:
																				num5++;
																				goto IL_04dc;
																				IL_04dc:
																				ptr2 += 8;
																				goto end_IL_02a1;
																				IL_04ef:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0551;
																				IL_0551:
																				num5 -= 2;
																				goto end_IL_02a1;
																				IL_0561:
																				if (9 < b)
																				{
																					goto IL_056c;
																				}
																				goto IL_0584;
																				IL_056c:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0577;
																				IL_0577:
																				if (10 > b)
																				{
																				}
																				break;
																				IL_0584:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_058f;
																			}
																			break;
																			IL_0266:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02a1;
																	continue;
																	end_IL_0276:
																	break;
																}
																continue;
																end_IL_0286:
																break;
															}
															continue;
															end_IL_0296:
															break;
														}
														continue;
														end_IL_02a1:
														break;
													}
													continue;
												}
												goto IL_0665;
												IL_0665:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05bb:
												break;
											}
											continue;
											end_IL_05ce:
											break;
										}
										continue;
										end_IL_05d8:
										break;
									}
									continue;
									end_IL_05ec:
									break;
								}
								continue;
								end_IL_0601:
								break;
							}
							continue;
							end_IL_061a:
							break;
						}
						continue;
						end_IL_062a:
						break;
					}
					continue;
					end_IL_063a:
					break;
				}
				continue;
				end_IL_064a:
				break;
			}
		}
	}

	private static int smethod_3(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_2;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private static int smethod_4(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_2;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 22;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRightsgetOutArgCount.TargetTypeTokengetDeclaredNestedTypesd);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0218:
																byte b = *ptr2;
																num = 9;
																while (true)
																{
																	IL_0208:
																	ptr2++;
																	while (true)
																	{
																		IL_01f8:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01d8:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01c8:
																							if (6 >= b)
																							{
																								while (true)
																								{
																									IL_01b8:
																									if (6 <= b)
																									{
																										num = 98;
																										while (num != 98)
																										{
																											if (num != 1079)
																											{
																												goto end_IL_01e8;
																											}
																											switch (num)
																											{
																											case 90:
																												goto IL_01b8;
																											case 78:
																											case 81:
																												goto IL_01c8;
																											case 12:
																												goto IL_01d8;
																											case 64:
																												goto IL_01e8;
																											case 10:
																												goto IL_01f8;
																											case 9:
																												goto IL_0208;
																											case 18:
																											case 66:
																												goto IL_0218;
																											case 37:
																												goto IL_022c;
																											case 48:
																												goto IL_0237;
																											case 46:
																											case 91:
																												goto IL_0245;
																											case 51:
																											case 71:
																												goto IL_0274;
																											case 44:
																											case 72:
																												goto IL_027f;
																											case 77:
																												goto IL_0298;
																											case 21:
																											case 42:
																												goto IL_02a6;
																											case 75:
																												goto IL_02c2;
																											case 14:
																											case 43:
																												goto IL_02d0;
																											case 34:
																												goto IL_02de;
																											case 88:
																												goto IL_0301;
																											case 11:
																												goto IL_030b;
																											case 89:
																												goto IL_0319;
																											case 19:
																												goto IL_032c;
																											case 5:
																											case 60:
																												goto IL_033a;
																											case 29:
																											case 73:
																												goto IL_0348;
																											case 70:
																												goto IL_0356;
																											case 7:
																											case 53:
																												goto IL_0364;
																											case 20:
																												goto IL_03a4;
																											case 82:
																												goto IL_03b8;
																											case 45:
																												goto IL_03cb;
																											case 17:
																											case 28:
																												goto IL_03d9;
																											case 84:
																												goto IL_0447;
																											case 68:
																												goto IL_045a;
																											case 40:
																												goto IL_0465;
																											case 39:
																											case 50:
																												goto IL_0472;
																											case 30:
																												goto IL_049b;
																											case 76:
																												goto IL_04a9;
																											case 1:
																											case 3:
																											case 4:
																											case 25:
																											case 26:
																											case 27:
																											case 31:
																											case 35:
																											case 49:
																											case 57:
																											case 62:
																											case 63:
																											case 69:
																											case 74:
																											case 79:
																											case 80:
																											case 83:
																											case 86:
																												goto end_IL_01e8;
																											case 67:
																												goto IL_04dc;
																											case 58:
																												goto IL_04ea;
																											case 47:
																												goto IL_04f8;
																											case 0:
																											case 8:
																											case 13:
																											case 15:
																											case 36:
																											case 38:
																											case 54:
																											case 55:
																											case 56:
																											case 59:
																												goto end_IL_01a5;
																											case 24:
																												goto end_IL_0506;
																											case 23:
																												goto end_IL_0519;
																											case 87:
																												goto end_IL_0523;
																											case 16:
																												goto end_IL_052e;
																											case 2:
																												goto end_IL_0543;
																											case 22:
																												goto end_IL_0558;
																											case 41:
																												goto end_IL_0568;
																											case 61:
																												goto end_IL_0578;
																											case 65:
																											case 85:
																												goto end_IL_0583;
																											case 32:
																												goto end_IL_0593;
																											case 33:
																												goto end_IL_05a3;
																											case 6:
																											case 52:
																												goto IL_05be;
																											}
																											continue;
																											end_IL_01a5:
																											break;
																										}
																										break;
																									}
																									goto IL_022c;
																									IL_0237:
																									if (5 > b)
																									{
																										goto end_IL_01e8;
																									}
																									goto IL_0245;
																									IL_0245:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									break;
																									IL_022c:
																									if (5 < b)
																									{
																										num = 31;
																										goto end_IL_01e8;
																									}
																									goto IL_0237;
																								}
																								break;
																							}
																							num = 51;
																							goto IL_0274;
																							IL_0301:
																							array2[num5] = null;
																							goto IL_030b;
																							IL_030b:
																							num5++;
																							goto IL_0319;
																							IL_0274:
																							if (7 < b)
																							{
																								goto IL_027f;
																							}
																							goto IL_02c2;
																							IL_027f:
																							if (8 < b)
																							{
																								num = 62;
																								goto end_IL_01e8;
																							}
																							goto IL_0298;
																							IL_0319:
																							ptr2 += 8;
																							break;
																							IL_0298:
																							if (8 > b)
																							{
																								goto end_IL_01e8;
																							}
																							goto IL_02a6;
																							IL_02a6:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							break;
																							IL_02c2:
																							if (7 > b)
																							{
																								goto end_IL_01e8;
																							}
																							goto IL_02d0;
																							IL_02d0:
																							array[num5] = 0;
																							goto IL_02de;
																							IL_02de:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0301;
																						}
																						break;
																					}
																					goto IL_032c;
																					IL_04a9:
																					num5--;
																					break;
																					IL_032c:
																					if (4 > b)
																					{
																						goto IL_033a;
																					}
																					goto IL_0472;
																					IL_033a:
																					if (2 < b)
																					{
																						goto IL_0348;
																					}
																					goto IL_03cb;
																					IL_0348:
																					if (3 < b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_0356;
																					IL_0356:
																					if (3 > b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_0364;
																					IL_0364:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03a4;
																					IL_03a4:
																					array[num5 - 2] = 0;
																					goto IL_03b8;
																					IL_03b8:
																					num5--;
																					break;
																					IL_03cb:
																					if (2 <= b)
																					{
																						goto IL_03d9;
																					}
																					goto IL_045a;
																					IL_03d9:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0447;
																					IL_0447:
																					num5 -= 2;
																					break;
																					IL_045a:
																					if (1 < b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_0465;
																					IL_0465:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_01e8;
																					IL_0472:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_049b;
																					IL_049b:
																					ptr2 += 8;
																					goto IL_04a9;
																				}
																				goto end_IL_01f8;
																				continue;
																				end_IL_01e8:
																				break;
																				IL_01e8:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04dc;
																		IL_04f8:
																		ptr2 += 8;
																		break;
																		IL_04ea:
																		num5++;
																		goto IL_04f8;
																		IL_04dc:
																		array[num5] = 0;
																		goto IL_04ea;
																		continue;
																		end_IL_01f8:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_05be;
														IL_05be:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0506:
														break;
													}
													continue;
													end_IL_0519:
													break;
												}
												continue;
												end_IL_0523:
												break;
											}
											continue;
											end_IL_052e:
											break;
										}
										continue;
										end_IL_0543:
										break;
									}
									continue;
									end_IL_0558:
									break;
								}
								continue;
								end_IL_0568:
								break;
							}
							continue;
							end_IL_0578:
							break;
						}
						continue;
						end_IL_0583:
						break;
					}
					continue;
					end_IL_0593:
					break;
				}
				continue;
				end_IL_05a3:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 59;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 58;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 86;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LIBFLAGFHASDISKIMAGEComplete.setStripAfterObfuscationAutoDual);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_029a:
																		if (b >= 1)
																		{
																			while (b <= 11)
																			{
																				while (true)
																				{
																					if (6 >= b)
																					{
																						while (true)
																						{
																							IL_026d:
																							if (6 <= b)
																							{
																								while (true)
																								{
																									IL_0222:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 128;
																									while (true)
																									{
																										if (num != 128)
																										{
																											if (num != 1109)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 90:
																											case 118:
																												goto IL_0222;
																											case 105:
																												goto IL_026d;
																											case 48:
																												goto end_IL_026d;
																											case 81:
																												goto end_IL_027a;
																											case 25:
																												goto IL_029a;
																											case 73:
																												goto end_IL_029a;
																											case 0:
																											case 31:
																												goto end_IL_02aa;
																											case 8:
																											case 117:
																												goto IL_02c5;
																											case 3:
																											case 39:
																												goto end_IL_020f;
																											case 95:
																											case 102:
																												goto IL_02de;
																											case 23:
																												goto IL_02ec;
																											case 13:
																											case 108:
																												goto IL_02fa;
																											case 30:
																												goto IL_0308;
																											case 72:
																												goto IL_032b;
																											case 103:
																												goto IL_0335;
																											case 94:
																												goto IL_0343;
																											case 50:
																												goto IL_0356;
																											case 32:
																											case 101:
																												goto IL_0364;
																											case 24:
																												goto IL_03a4;
																											case 47:
																												goto IL_03b8;
																											case 91:
																												goto IL_03cb;
																											case 75:
																											case 76:
																												goto IL_03d6;
																											case 85:
																												goto IL_03ff;
																											case 28:
																												goto IL_040d;
																											case 77:
																												goto IL_0420;
																											case 61:
																												goto IL_042b;
																											case 2:
																											case 120:
																												goto IL_043e;
																											case 46:
																												goto IL_044c;
																											case 74:
																											case 80:
																												goto IL_045a;
																											case 11:
																												goto IL_049a;
																											case 106:
																												goto IL_04b7;
																											case 71:
																												goto IL_04de;
																											case 54:
																												goto IL_04f1;
																											case 35:
																											case 88:
																												goto IL_04fc;
																											case 57:
																												goto IL_0507;
																											case 66:
																												goto IL_0515;
																											case 19:
																											case 119:
																												goto IL_0523;
																											case 92:
																												goto IL_053f;
																											case 7:
																											case 68:
																												goto IL_054d;
																											case 69:
																												goto IL_0560;
																											case 70:
																											case 78:
																												goto IL_056b;
																											case 10:
																												goto IL_057f;
																											case 96:
																												goto IL_05be;
																											case 1:
																											case 84:
																												goto IL_05d1;
																											case 33:
																												goto IL_05dc;
																											case 9:
																											case 82:
																												goto IL_05ea;
																											case 60:
																												goto IL_060c;
																											case 111:
																												goto IL_0623;
																											case 26:
																												goto IL_0631;
																											case 17:
																												goto IL_0644;
																											case 18:
																												goto IL_064f;
																											case 38:
																											case 89:
																												goto IL_065a;
																											case 45:
																												goto IL_069a;
																											case 116:
																												goto IL_06ae;
																											case 4:
																											case 5:
																											case 6:
																											case 15:
																											case 27:
																											case 29:
																											case 37:
																											case 43:
																											case 44:
																											case 62:
																											case 63:
																											case 65:
																											case 67:
																											case 87:
																											case 93:
																											case 97:
																											case 99:
																											case 109:
																											case 110:
																											case 113:
																											case 115:
																												goto end_IL_028a;
																											case 64:
																												goto IL_06e1;
																											case 56:
																												goto IL_06ef;
																											case 104:
																												goto IL_06fd;
																											case 12:
																											case 16:
																											case 20:
																											case 22:
																											case 36:
																											case 42:
																											case 51:
																											case 53:
																											case 79:
																											case 83:
																											case 107:
																											case 112:
																											case 121:
																												goto end_IL_02ba;
																											case 34:
																												goto end_IL_070b;
																											case 52:
																												goto end_IL_071e;
																											case 40:
																												goto end_IL_0728;
																											case 100:
																												goto end_IL_0733;
																											case 49:
																												goto end_IL_0748;
																											case 86:
																												goto end_IL_075d;
																											case 21:
																												goto end_IL_076d;
																											case 14:
																												goto end_IL_077d;
																											case 55:
																											case 114:
																												goto end_IL_0788;
																											case 58:
																												goto end_IL_0798;
																											case 59:
																												goto end_IL_07a8;
																											case 41:
																											case 98:
																												goto IL_07cc;
																											}
																											continue;
																										}
																										array[num5 - 2] = 0;
																										goto IL_04de;
																										IL_04de:
																										num5--;
																										goto end_IL_02ba;
																										continue;
																										end_IL_020f:
																										break;
																									}
																									break;
																								}
																								goto IL_02d3;
																							}
																							goto IL_02c5;
																							IL_04b7:
																							num5--;
																							goto end_IL_02ba;
																							IL_02c5:
																							if (3 < b)
																							{
																								goto IL_02d3;
																							}
																							goto IL_03cb;
																							IL_02d3:
																							if (4 < b)
																							{
																								goto IL_02de;
																							}
																							goto IL_0356;
																							IL_02de:
																							if (5 < b)
																							{
																								goto end_IL_028a;
																							}
																							goto IL_02ec;
																							IL_02ec:
																							if (5 > b)
																							{
																								goto end_IL_028a;
																							}
																							goto IL_02fa;
																							IL_02fa:
																							array[num5] = 0;
																							goto IL_0308;
																							IL_0308:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_032b;
																							IL_032b:
																							array2[num5] = null;
																							goto IL_0335;
																							IL_0335:
																							num5++;
																							goto IL_0343;
																							IL_0343:
																							ptr2 += 8;
																							goto end_IL_02ba;
																							IL_0356:
																							if (4 > b)
																							{
																								goto end_IL_028a;
																							}
																							goto IL_0364;
																							IL_0364:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03a4;
																							IL_03a4:
																							array[num5 - 2] = 0;
																							goto IL_03b8;
																							IL_03b8:
																							num5--;
																							goto end_IL_02ba;
																							IL_03cb:
																							if (3 <= b)
																							{
																								goto IL_03d6;
																							}
																							goto IL_0420;
																							IL_03d6:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03ff;
																							IL_03ff:
																							ptr2 += 8;
																							goto IL_040d;
																							IL_040d:
																							num5--;
																							goto end_IL_02ba;
																							IL_0420:
																							if (1 >= b)
																							{
																								goto IL_042b;
																							}
																							goto IL_043e;
																							IL_042b:
																							if (1 <= b)
																							{
																							}
																							goto end_IL_028a;
																							IL_043e:
																							if (2 < b)
																							{
																								goto end_IL_028a;
																							}
																							goto IL_044c;
																							IL_044c:
																							if (2 > b)
																							{
																								goto end_IL_028a;
																							}
																							goto IL_045a;
																							IL_045a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_049a;
																							IL_049a:
																							array[num5 - 2] = 0;
																							num = 106;
																							goto IL_04b7;
																							continue;
																							end_IL_026d:
																							break;
																						}
																						continue;
																					}
																					goto IL_04f1;
																					IL_06ae:
																					num5--;
																					goto end_IL_02ba;
																					IL_04f1:
																					if (9 < b)
																					{
																						goto IL_04fc;
																					}
																					goto IL_0560;
																					IL_04fc:
																					if (10 < b)
																					{
																						goto IL_0507;
																					}
																					goto IL_053f;
																					IL_0507:
																					if (11 < b)
																					{
																						goto end_IL_028a;
																					}
																					goto IL_0515;
																					IL_0515:
																					if (11 > b)
																					{
																						goto end_IL_028a;
																					}
																					goto IL_0523;
																					IL_0523:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02ba;
																					IL_053f:
																					if (10 > b)
																					{
																						goto end_IL_028a;
																					}
																					goto IL_054d;
																					IL_054d:
																					num5--;
																					goto end_IL_02ba;
																					IL_0560:
																					if (9 <= b)
																					{
																						goto IL_056b;
																					}
																					goto IL_05d1;
																					IL_056b:
																					array[num5 - 1] = 0;
																					goto IL_057f;
																					IL_057f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)AlphaBoolNotOnFaulted[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_05be;
																					IL_05be:
																					ptr2 += 8;
																					goto end_IL_02ba;
																					IL_05d1:
																					if (7 >= b)
																					{
																						goto IL_05dc;
																					}
																					goto IL_0644;
																					IL_05dc:
																					if (7 > b)
																					{
																						goto end_IL_028a;
																					}
																					goto IL_05ea;
																					IL_05ea:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 60;
																					goto IL_060c;
																					IL_060c:
																					array[num5] = 0;
																					num = 111;
																					goto IL_0623;
																					IL_0623:
																					num5++;
																					goto IL_0631;
																					IL_0631:
																					ptr2 += 8;
																					goto end_IL_02ba;
																					IL_0644:
																					if (8 < b)
																					{
																						goto end_IL_028a;
																					}
																					goto IL_064f;
																					IL_064f:
																					if (8 > b)
																					{
																						goto end_IL_028a;
																					}
																					goto IL_065a;
																					IL_065a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_069a;
																					IL_069a:
																					array[num5 - 2] = 0;
																					goto IL_06ae;
																					continue;
																					end_IL_027a:
																					break;
																				}
																				continue;
																				end_IL_028a:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_06e1;
																		IL_06fd:
																		ptr2 += 8;
																		goto end_IL_02ba;
																		IL_06ef:
																		num5++;
																		goto IL_06fd;
																		IL_06e1:
																		array[num5] = 0;
																		goto IL_06ef;
																		continue;
																		end_IL_029a:
																		break;
																	}
																	continue;
																	end_IL_02aa:
																	break;
																}
																continue;
																end_IL_02ba:
																break;
															}
															continue;
														}
														goto IL_07cc;
														IL_07cc:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_070b:
														break;
													}
													continue;
													end_IL_071e:
													break;
												}
												continue;
												end_IL_0728:
												break;
											}
											continue;
											end_IL_0733:
											break;
										}
										continue;
										end_IL_0748:
										break;
									}
									continue;
									end_IL_075d:
									break;
								}
								continue;
								end_IL_076d:
								break;
							}
							continue;
							end_IL_077d:
							break;
						}
						continue;
						end_IL_0788:
						break;
					}
					continue;
					end_IL_0798:
					break;
				}
				continue;
				end_IL_07a8:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 79;
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 45;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MembershipConditionNextSpinWillYield.ActivationTypeNameCache);
										num = 172;
										while (true)
										{
											if (num != 172)
											{
												if (num != 1153)
												{
													goto IL_0650;
												}
												switch (num)
												{
												case 117:
													goto end_IL_02bf;
												case 61:
													goto end_IL_02d2;
												case 60:
													goto end_IL_02e6;
												case 53:
												case 55:
													goto end_IL_02f6;
												case 131:
													goto end_IL_0306;
												case 45:
												case 99:
													goto end_IL_0316;
												case 78:
													goto end_IL_0326;
												case 79:
													goto end_IL_0336;
												case 26:
												case 35:
												case 42:
												case 62:
												case 74:
												case 76:
												case 84:
												case 89:
												case 90:
												case 93:
												case 95:
												case 98:
												case 107:
												case 110:
												case 112:
												case 122:
												case 126:
												case 133:
												case 152:
												case 155:
													goto IL_0362;
												case 12:
												case 100:
													goto IL_0372;
												case 56:
													goto IL_037b;
												case 154:
													goto IL_0389;
												case 136:
													goto IL_0397;
												case 130:
													goto IL_03a5;
												case 15:
													goto IL_03b3;
												case 43:
												case 67:
													goto IL_03be;
												case 5:
													goto IL_03cc;
												case 88:
												case 91:
													goto IL_03da;
												case 123:
												case 137:
													goto IL_03e5;
												case 10:
													goto IL_03f3;
												case 127:
												case 145:
													goto IL_0401;
												case 140:
													goto IL_042a;
												case 124:
													goto IL_0443;
												case 24:
													goto IL_044e;
												case 128:
													goto IL_045c;
												case 27:
												case 87:
													goto IL_046a;
												case 18:
													goto IL_0483;
												case 41:
													goto IL_0491;
												case 20:
													goto IL_049f;
												case 29:
												case 146:
													goto IL_04b2;
												case 114:
													goto IL_04f2;
												case 120:
													goto IL_0506;
												case 49:
												case 163:
													goto IL_0519;
												case 21:
													goto IL_0540;
												case 68:
													goto IL_054e;
												case 75:
													goto IL_0561;
												case 51:
												case 94:
													goto IL_056f;
												case 134:
													goto IL_057a;
												case 17:
												case 86:
													goto IL_0588;
												case 158:
													goto IL_05b1;
												case 22:
													goto IL_05bf;
												case 162:
													goto IL_05d2;
												case 7:
													goto IL_05e0;
												case 109:
												case 150:
													goto IL_05ee;
												case 70:
													goto IL_0606;
												case 116:
												case 149:
													goto IL_0611;
												case 16:
													goto IL_0650;
												case 156:
													goto IL_066c;
												case 39:
													goto IL_067a;
												case 46:
												case 119:
													goto IL_0688;
												case 66:
													goto IL_0696;
												case 1:
													goto IL_06ae;
												case 31:
													goto IL_06bc;
												case 71:
													goto IL_06cf;
												case 113:
													goto IL_06dd;
												case 101:
												case 125:
													goto IL_06eb;
												case 72:
												case 102:
													goto IL_06f9;
												case 85:
													goto IL_0707;
												case 82:
												case 138:
													goto IL_0715;
												case 106:
													goto IL_0755;
												case 65:
													goto IL_0769;
												case 30:
													goto IL_077c;
												case 19:
												case 54:
													goto IL_0790;
												case 73:
													goto IL_07d4;
												case 38:
													goto IL_07e8;
												case 161:
													goto IL_07fb;
												case 36:
													goto IL_0809;
												case 52:
												case 153:
													goto IL_0817;
												case 77:
													goto IL_0825;
												case 118:
													goto IL_0848;
												case 83:
													goto IL_0852;
												case 96:
													goto IL_0860;
												case 81:
												case 115:
													goto IL_0873;
												case 148:
													goto IL_08d5;
												case 6:
													goto IL_08e8;
												case 139:
													goto IL_08f6;
												case 104:
												case 160:
													goto IL_0901;
												case 32:
													goto IL_0914;
												case 129:
													goto IL_0922;
												case 50:
												case 59:
													goto IL_0930;
												case 58:
													goto IL_0944;
												case 121:
													goto IL_0998;
												case 141:
													goto IL_09a6;
												case 105:
													goto IL_09c2;
												case 64:
													goto IL_09cd;
												case 111:
												case 132:
													goto IL_09d8;
												case 0:
													goto IL_09ff;
												case 11:
													goto IL_0a0a;
												case 2:
												case 4:
												case 8:
												case 9:
												case 13:
												case 14:
												case 23:
												case 25:
												case 28:
												case 33:
												case 34:
												case 37:
												case 40:
												case 44:
												case 47:
												case 48:
												case 57:
												case 69:
												case 80:
												case 92:
												case 97:
												case 103:
												case 108:
												case 135:
												case 142:
												case 143:
												case 144:
												case 147:
												case 151:
												case 157:
												case 159:
												case 164:
												case 165:
													goto IL_0a15;
												case 3:
												case 63:
													goto IL_0a2d;
												}
												continue;
											}
											ptr2 = ptr;
											goto IL_0362;
											IL_09d8:
											byte* num4 = ptr2;
											num5 = 1;
											ptr2 = num4 + -200;
											goto IL_0362;
											IL_09ff:
											if (17 >= b)
											{
												goto IL_0a0a;
											}
											goto IL_0a15;
											IL_0a15:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0362;
											IL_0362:
											if (num5 != 1)
											{
												goto IL_0372;
											}
											goto IL_0a2d;
											IL_0a2d:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											IL_0372:
											b = *ptr2;
											goto IL_037b;
											IL_037b:
											ptr2++;
											goto IL_0389;
											IL_0389:
											if (b >= 1)
											{
												goto IL_0397;
											}
											goto IL_0a15;
											IL_0397:
											if (b <= 17)
											{
												goto IL_03a5;
											}
											goto IL_0a15;
											IL_03a5:
											if (9 >= b)
											{
												goto IL_03b3;
											}
											goto IL_06cf;
											IL_03b3:
											if (9 <= b)
											{
												goto IL_0362;
											}
											goto IL_03be;
											IL_03be:
											if (4 >= b)
											{
												goto IL_03cc;
											}
											goto IL_0561;
											IL_03cc:
											if (4 > b)
											{
												goto IL_03da;
											}
											goto IL_0519;
											IL_03da:
											if (2 < b)
											{
												goto IL_03e5;
											}
											goto IL_0443;
											IL_03e5:
											if (3 >= b)
											{
												goto IL_03f3;
											}
											goto IL_0a15;
											IL_03f3:
											if (3 <= b)
											{
												goto IL_0401;
											}
											goto IL_0a15;
											IL_0401:
											array2[num6 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
											goto IL_042a;
											IL_042a:
											array[num6 - 1] = 5;
											goto IL_0362;
											IL_0443:
											if (2 > b)
											{
												goto IL_044e;
											}
											goto IL_04b2;
											IL_044e:
											if (1 >= b)
											{
												goto IL_045c;
											}
											goto IL_0a15;
											IL_045c:
											if (1 <= b)
											{
												goto IL_046a;
											}
											goto IL_0a15;
											IL_046a:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
											goto IL_0483;
											IL_0483:
											array[num6] = 0;
											goto IL_0491;
											IL_0491:
											num6++;
											goto IL_049f;
											IL_049f:
											ptr2 += 8;
											goto IL_0362;
											IL_04b2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											goto IL_04f2;
											IL_04f2:
											array[num6 - 2] = 0;
											goto IL_0506;
											IL_0506:
											num6--;
											goto IL_0362;
											IL_0519:
											array5[*(int*)(ptr2 + num3)] = array2[num6 - 1];
											num = 21;
											goto IL_0540;
											IL_0540:
											ptr2 += 8;
											goto IL_054e;
											IL_054e:
											num6--;
											goto IL_0362;
											IL_0561:
											if (6 < b)
											{
												goto IL_056f;
											}
											goto IL_0606;
											IL_056f:
											if (7 >= b)
											{
												goto IL_057a;
											}
											goto IL_05d2;
											IL_057a:
											if (7 <= b)
											{
												goto IL_0588;
											}
											goto IL_0a15;
											IL_0588:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											goto IL_05b1;
											IL_05b1:
											ptr2 += 8;
											goto IL_05bf;
											IL_05bf:
											num6--;
											goto IL_0362;
											IL_05d2:
											if (8 >= b)
											{
												goto IL_05e0;
											}
											goto IL_0a15;
											IL_05e0:
											if (8 <= b)
											{
												goto IL_05ee;
											}
											goto IL_0a15;
											IL_05ee:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0362;
											IL_0606:
											if (6 <= b)
											{
												goto IL_0611;
											}
											goto IL_066c;
											IL_0611:
											((int[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											goto IL_0650;
											IL_0650:
											num6 -= 3;
											num = 74;
											goto IL_0362;
											IL_066c:
											if (5 >= b)
											{
												goto IL_067a;
											}
											goto IL_0a15;
											IL_067a:
											if (5 <= b)
											{
												goto IL_0688;
											}
											goto IL_0a15;
											IL_0688:
											array[num6] = 5;
											goto IL_0696;
											IL_0696:
											array2[num6] = array5[*(int*)(ptr2 + num3)];
											goto IL_06ae;
											IL_06ae:
											num6++;
											goto IL_06bc;
											IL_06bc:
											ptr2 += 8;
											goto IL_0362;
											IL_06cf:
											if (13 >= b)
											{
												goto IL_06dd;
											}
											goto IL_08e8;
											IL_06dd:
											if (13 > b)
											{
												goto IL_06eb;
											}
											goto IL_0873;
											IL_06eb:
											if (11 < b)
											{
												goto IL_06f9;
											}
											goto IL_077c;
											IL_06f9:
											if (12 >= b)
											{
												goto IL_0707;
											}
											goto IL_0a15;
											IL_0707:
											if (12 <= b)
											{
												goto IL_0715;
											}
											goto IL_0a15;
											IL_0715:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											goto IL_0755;
											IL_0755:
											array[num6 - 2] = 0;
											goto IL_0769;
											IL_0769:
											num6--;
											goto IL_0362;
											IL_077c:
											if (11 <= b)
											{
												num = 19;
												goto IL_0790;
											}
											goto IL_07fb;
											IL_0a0a:
											if (17 <= b)
											{
											}
											goto IL_0a15;
											IL_0790:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((int[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
											goto IL_07d4;
											IL_07d4:
											array[num6 - 2] = 0;
											goto IL_07e8;
											IL_07e8:
											num6--;
											goto IL_0362;
											IL_07fb:
											if (10 >= b)
											{
												goto IL_0809;
											}
											goto IL_0a15;
											IL_0809:
											if (10 <= b)
											{
												goto IL_0817;
											}
											goto IL_0a15;
											IL_0817:
											array[num6] = 0;
											goto IL_0825;
											IL_0825:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
											goto IL_0848;
											IL_0848:
											array2[num6] = null;
											goto IL_0852;
											IL_0852:
											num6++;
											goto IL_0860;
											IL_0860:
											ptr2 += 8;
											goto IL_0362;
											IL_0873:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_08d5;
											IL_08d5:
											num6 -= 2;
											goto IL_0362;
											IL_08e8:
											if (15 >= b)
											{
												goto IL_08f6;
											}
											goto IL_09c2;
											IL_08f6:
											if (15 <= b)
											{
												goto IL_0901;
											}
											goto IL_0914;
											IL_0901:
											num6--;
											goto IL_0362;
											IL_0914:
											if (14 >= b)
											{
												goto IL_0922;
											}
											goto IL_0a15;
											IL_0922:
											if (14 <= b)
											{
												goto IL_0930;
											}
											goto IL_0a15;
											IL_0930:
											array[num6 - 2] = 0;
											goto IL_0944;
											IL_0944:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)FDispatchableResolveField[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
											goto IL_0998;
											IL_0998:
											num6--;
											goto IL_09a6;
											IL_09a6:
											ptr2 += 8;
											num = 84;
											goto IL_0362;
											IL_09c2:
											if (16 >= b)
											{
												goto IL_09cd;
											}
											goto IL_09ff;
											IL_09cd:
											if (16 <= b)
											{
												goto IL_09d8;
											}
											num = 135;
											goto IL_0a15;
											continue;
											end_IL_02bf:
											break;
										}
										continue;
										end_IL_02d2:
										break;
									}
									continue;
									end_IL_02e6:
									break;
								}
								continue;
								end_IL_02f6:
								break;
							}
							continue;
							end_IL_0306:
							break;
						}
						continue;
						end_IL_0316:
						break;
					}
					continue;
					end_IL_0326:
					break;
				}
				continue;
				end_IL_0336:
				break;
			}
		}
	}
}
