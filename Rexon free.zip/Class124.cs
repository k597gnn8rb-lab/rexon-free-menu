using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Auto Load: Off", "Settings", "Save and load mods on startup", false, 11, ModType.const_1, false)]
internal class Class124 : MonoBehaviour
{
	private static int int_0;

	private static int int_1;

	private static double double_0;

	private static float float_0;

	private static double double_1;

	private static double double_2;

	private static IntPtr[] IsNeutralCultureLessThan;

	private static IntPtr[] setResourceManagerControlPadLeft;

	private static IntPtr[] IMPALWAYSFLOWSidNameUse;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001e, IL_03f3, IL_0406, IL_041f, IL_0435, IL_0477, IL_0487, IL_0497, IL_04a7, IL_04b7, IL_04c7, IL_04d7, IL_04e7, IL_04f7, IL_050b, IL_0516, IL_051f, IL_052a, IL_053a, IL_0548, IL_0556, IL_0569, IL_05a9, IL_05bd, IL_05d9, IL_05e7, IL_05f5, IL_0603, IL_0611, IL_0673, IL_0686, IL_0694, IL_06a2, IL_06bf, IL_070e, IL_0718, IL_0745, IL_0759, IL_0767, IL_077a, IL_0785, IL_07c5, IL_07d9, IL_07ec, IL_07fa, IL_0805, IL_082e, IL_083c, IL_084f, IL_085a, IL_0868, IL_0881, IL_0898, IL_08af, IL_08c2, IL_08d0, IL_08de, IL_0927, IL_093b, IL_094e, IL_0959, IL_0967, IL_0975, IL_0998, IL_09a2, IL_09b9, IL_09cc, IL_09da, IL_09e5, IL_09f3, IL_0a33, IL_0a50, IL_0a63, IL_0a81, IL_0a8f, IL_0aa2, IL_0ab0, IL_0abe, IL_0ac9, IL_0ad7, IL_0aea, IL_0af5, IL_0b03, IL_0b0c, IL_0b1a, IL_0b43, IL_0b51, IL_0b64, IL_0b80, IL_0b8e, IL_0b99, IL_0ba7, IL_0bb5, IL_0bcd, IL_0bdb, IL_0c39, IL_0c4c, IL_0c60, IL_0cac, IL_0cba, IL_0ccd, IL_0cd6, IL_0ce4, IL_0cf2, IL_0cfd, IL_0d0b, IL_0d19, IL_0d2e, IL_0d41, IL_0d4c, IL_0d5a, IL_0d68, IL_0da6, IL_0db9, IL_0dcd, IL_0e05, IL_0e18, IL_0e26, IL_0e31, IL_0e3f, IL_0e68, IL_0e8a, IL_0e98, IL_0ea6, IL_0ebe, IL_0edc, IL_0f00, IL_0f18, IL_0f2b, IL_0f42, IL_0f5a, IL_0f71, IL_0f8a, IL_0f98, IL_0fbc, IL_0fd3, IL_0fe3, IL_0ff6, IL_1009, IL_1013, IL_101e, IL_102e, IL_103e, IL_104e, IL_105e, IL_106e, IL_107e, IL_108e are reachable both inside and outside the pinned region starting at IL_10a3. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 223;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num6;
			byte* num7;
			int __rxRef38 = default(int);
			ref int reference = ref __rxRef38;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_108e:
					num2 = 1;
					while (true)
					{
						IL_107e:
						num3 = num2 * 4;
						while (true)
						{
							IL_106e:
							array2 = new byte[4];
							while (true)
							{
								IL_105e:
								array3 = new object[4];
								while (true)
								{
									IL_104e:
									array4 = new int[4];
									while (true)
									{
										IL_103e:
										array5 = new int[6];
										while (true)
										{
											IL_102e:
											array6 = new long[4];
											while (true)
											{
												IL_101e:
												array7 = new object[16];
												while (true)
												{
													IL_1013:
													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getThreeLetterWindowsLanguageNameNestedPublic.SetActorAsReferenceWhenCopyingClaimsIdentityprocessorCount);
													while (true)
													{
														IL_1009:
														ptr2 = ptr;
														while (true)
														{
															if (num4 == 1)
															{
																return;
															}
															while (true)
															{
																IL_050b:
																num = 67;
																while (true)
																{
																	IL_04f7:
																	byte b = *ptr2;
																	num = 146;
																	while (true)
																	{
																		IL_04e7:
																		ptr2++;
																		while (true)
																		{
																			IL_04d7:
																			if (b >= 1)
																			{
																				while (b <= 26)
																				{
																					while (true)
																					{
																						IL_04b7:
																						if (13 >= b)
																						{
																							while (true)
																							{
																								IL_04a7:
																								if (13 > b)
																								{
																									while (true)
																									{
																										IL_0497:
																										if (6 < b)
																										{
																											while (true)
																											{
																												IL_0487:
																												if (9 >= b)
																												{
																													while (true)
																													{
																														IL_0477:
																														if (9 <= b)
																														{
																															while (true)
																															{
																																IL_0435:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																while (true)
																																{
																																	IL_041f:
																																	array2[num5 - 2] = 0;
																																	while (true)
																																	{
																																		IL_0406:
																																		num5--;
																																		num = 249;
																																		while (num != 249)
																																		{
																																			if (num != 1230)
																																			{
																																				goto end_IL_04c7;
																																			}
																																			switch (num)
																																			{
																																			case 223:
																																				break;
																																			default:
																																				continue;
																																			case 28:
																																				goto IL_0406;
																																			case 62:
																																				goto IL_041f;
																																			case 95:
																																			case 138:
																																				goto IL_0435;
																																			case 123:
																																				goto IL_0477;
																																			case 17:
																																			case 193:
																																				goto IL_0487;
																																			case 126:
																																			case 175:
																																				goto IL_0497;
																																			case 75:
																																				goto IL_04a7;
																																			case 91:
																																				goto IL_04b7;
																																			case 184:
																																				goto IL_04c7;
																																			case 36:
																																				goto IL_04d7;
																																			case 146:
																																				goto IL_04e7;
																																			case 67:
																																				goto IL_04f7;
																																			case 149:
																																				goto IL_050b;
																																			case 64:
																																			case 173:
																																				goto IL_051f;
																																			case 108:
																																				goto IL_052a;
																																			case 136:
																																				goto IL_053a;
																																			case 70:
																																				goto IL_0548;
																																			case 27:
																																			case 144:
																																				goto IL_0556;
																																			case 170:
																																			case 203:
																																				goto IL_0569;
																																			case 165:
																																				goto IL_05a9;
																																			case 186:
																																				goto IL_05bd;
																																			case 115:
																																				goto IL_05d9;
																																			case 147:
																																				goto IL_05e7;
																																			case 71:
																																			case 90:
																																				goto IL_05f5;
																																			case 210:
																																				goto IL_0603;
																																			case 135:
																																			case 179:
																																				goto IL_0611;
																																			case 39:
																																				goto IL_0673;
																																			case 26:
																																				goto IL_0686;
																																			case 229:
																																				goto IL_0694;
																																			case 105:
																																			case 110:
																																				goto IL_06a2;
																																			case 236:
																																				goto IL_0759;
																																			case 59:
																																				goto IL_0767;
																																			case 206:
																																				goto IL_077a;
																																			case 65:
																																			case 97:
																																				goto IL_0785;
																																			case 212:
																																				goto IL_07c5;
																																			case 151:
																																				goto IL_07d9;
																																			case 140:
																																				goto IL_07ec;
																																			case 51:
																																				goto IL_07fa;
																																			case 47:
																																			case 238:
																																				goto IL_0805;
																																			case 56:
																																				goto IL_082e;
																																			case 230:
																																				goto IL_083c;
																																			case 216:
																																				goto IL_084f;
																																			case 182:
																																				goto IL_085a;
																																			case 101:
																																			case 189:
																																				goto IL_0868;
																																			case 100:
																																				goto IL_0881;
																																			case 81:
																																				goto IL_0898;
																																			case 55:
																																				goto IL_08af;
																																			case 169:
																																				goto IL_08c2;
																																			case 2:
																																				goto IL_08d0;
																																			case 195:
																																			case 217:
																																				goto IL_08de;
																																			case 228:
																																				goto IL_0927;
																																			case 80:
																																				goto IL_093b;
																																			case 178:
																																				goto IL_094e;
																																			case 52:
																																				goto IL_0959;
																																			case 104:
																																			case 122:
																																				goto IL_0967;
																																			case 161:
																																				goto IL_0975;
																																			case 89:
																																				goto IL_0998;
																																			case 79:
																																				goto IL_09a2;
																																			case 103:
																																				goto IL_09b9;
																																			case 137:
																																				goto IL_09cc;
																																			case 181:
																																				goto IL_09da;
																																			case 21:
																																			case 111:
																																				goto IL_09f3;
																																			case 150:
																																				goto IL_0a33;
																																			case 214:
																																				goto IL_0a50;
																																			case 99:
																																			case 141:
																																				goto IL_0a63;
																																			case 25:
																																				goto IL_0a81;
																																			case 168:
																																				goto IL_0a8f;
																																			case 154:
																																				goto IL_0aa2;
																																			case 83:
																																				goto IL_0ab0;
																																			case 14:
																																			case 187:
																																				goto IL_0abe;
																																			case 20:
																																			case 23:
																																				goto IL_0ac9;
																																			case 15:
																																				goto IL_0ad7;
																																			case 139:
																																				goto IL_0aea;
																																			case 125:
																																				goto IL_0af5;
																																			case 57:
																																				goto IL_0b0c;
																																			case 127:
																																			case 167:
																																				goto IL_0b1a;
																																			case 12:
																																				goto IL_0b43;
																																			case 44:
																																				goto IL_0b51;
																																			case 114:
																																			case 237:
																																				goto IL_0b64;
																																			case 42:
																																				goto IL_0b80;
																																			case 66:
																																				goto IL_0b8e;
																																			case 32:
																																			case 191:
																																				goto IL_0b99;
																																			case 16:
																																				goto IL_0ba7;
																																			case 78:
																																			case 134:
																																				goto IL_0bb5;
																																			case 53:
																																				goto IL_0bcd;
																																			case 50:
																																			case 119:
																																				goto IL_0bdb;
																																			case 183:
																																				goto IL_0c39;
																																			case 82:
																																			case 219:
																																				goto IL_0c4c;
																																			case 226:
																																				goto IL_0c60;
																																			case 207:
																																				goto IL_0cac;
																																			case 68:
																																				goto IL_0cba;
																																			case 6:
																																				goto IL_0cd6;
																																			case 172:
																																			case 185:
																																				goto IL_0ce4;
																																			case 174:
																																				goto IL_0cf2;
																																			case 48:
																																				goto IL_0cfd;
																																			case 209:
																																				goto IL_0d0b;
																																			case 86:
																																			case 166:
																																				goto IL_0d19;
																																			case 194:
																																				goto IL_0d2e;
																																			case 227:
																																				goto IL_0d41;
																																			case 88:
																																			case 180:
																																				goto IL_0d4c;
																																			case 7:
																																				goto IL_0d5a;
																																			case 4:
																																			case 94:
																																				goto IL_0d68;
																																			case 215:
																																				goto IL_0da6;
																																			case 96:
																																			case 107:
																																				goto IL_0db9;
																																			case 152:
																																				goto IL_0dcd;
																																			case 213:
																																				goto IL_0e05;
																																			case 201:
																																				goto IL_0e18;
																																			case 74:
																																			case 188:
																																				goto IL_0e26;
																																			case 224:
																																				goto IL_0e31;
																																			case 54:
																																			case 73:
																																				goto IL_0e3f;
																																			case 117:
																																				goto IL_0e68;
																																			case 142:
																																				goto IL_0e8a;
																																			case 132:
																																				goto IL_0e98;
																																			case 131:
																																			case 220:
																																				goto IL_0ea6;
																																			case 176:
																																				goto IL_0ebe;
																																			case 43:
																																				goto IL_0edc;
																																			case 156:
																																				goto IL_0f00;
																																			case 30:
																																				goto IL_0f18;
																																			case 118:
																																			case 159:
																																				goto IL_0f2b;
																																			case 45:
																																				goto IL_0f42;
																																			case 155:
																																				goto IL_0f5a;
																																			case 148:
																																				goto IL_0f71;
																																			case 130:
																																			case 231:
																																				goto IL_0f8a;
																																			case 13:
																																				goto IL_0f98;
																																			case 240:
																																				goto IL_0fbc;
																																			case 232:
																																				goto IL_0fd3;
																																			case 5:
																																			case 8:
																																			case 9:
																																			case 10:
																																			case 11:
																																			case 18:
																																			case 24:
																																			case 29:
																																			case 31:
																																			case 33:
																																			case 34:
																																			case 35:
																																			case 38:
																																			case 49:
																																			case 69:
																																			case 72:
																																			case 76:
																																			case 77:
																																			case 92:
																																			case 106:
																																			case 109:
																																			case 112:
																																			case 121:
																																			case 124:
																																			case 133:
																																			case 143:
																																			case 162:
																																			case 163:
																																			case 177:
																																			case 190:
																																			case 192:
																																			case 196:
																																			case 197:
																																			case 199:
																																			case 200:
																																			case 202:
																																			case 204:
																																			case 211:
																																			case 218:
																																			case 225:
																																			case 233:
																																				goto end_IL_04c7;
																																			case 0:
																																			case 1:
																																			case 3:
																																			case 19:
																																			case 22:
																																			case 37:
																																			case 58:
																																			case 60:
																																			case 61:
																																			case 63:
																																			case 84:
																																			case 85:
																																			case 116:
																																			case 120:
																																			case 128:
																																			case 129:
																																			case 145:
																																			case 157:
																																			case 158:
																																			case 171:
																																			case 198:
																																			case 208:
																																			case 221:
																																			case 234:
																																			case 235:
																																			case 239:
																																			case 241:
																																			case 242:
																																				goto end_IL_03f3;
																																			case 87:
																																				goto IL_1009;
																																			case 46:
																																				goto IL_1013;
																																			case 98:
																																				goto IL_101e;
																																			case 160:
																																				goto IL_102e;
																																			case 40:
																																				goto IL_103e;
																																			case 153:
																																				goto IL_104e;
																																			case 113:
																																				goto IL_105e;
																																			case 93:
																																			case 102:
																																				goto IL_106e;
																																			case 205:
																																				goto IL_107e;
																																			case 222:
																																				goto IL_108e;
																																			case 41:
																																			case 164:
																																				return;
																																			}
																																			goto end_IL_0ff6;
																																			continue;
																																			end_IL_03f3:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														num = 173;
																														goto IL_051f;
																														IL_0548:
																														if (8 > b)
																														{
																															goto end_IL_04c7;
																														}
																														goto IL_0556;
																														IL_0556:
																														num5--;
																														break;
																														IL_051f:
																														if (7 >= b)
																														{
																															goto IL_052a;
																														}
																														goto IL_053a;
																														IL_052a:
																														if (7 > b)
																														{
																															goto end_IL_04c7;
																														}
																														goto IL_0569;
																														IL_0569:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_05a9;
																														IL_05a9:
																														array2[num5 - 2] = 0;
																														goto IL_05bd;
																														IL_05bd:
																														num5--;
																														num = 235;
																														break;
																														IL_053a:
																														if (8 < b)
																														{
																															goto end_IL_04c7;
																														}
																														goto IL_0548;
																													}
																													break;
																												}
																												goto IL_05d9;
																												IL_0759:
																												array2[num5] = 5;
																												goto IL_0767;
																												IL_05d9:
																												if (11 >= b)
																												{
																													goto IL_05e7;
																												}
																												goto IL_0686;
																												IL_05e7:
																												if (11 <= b)
																												{
																													break;
																												}
																												goto IL_05f5;
																												IL_05f5:
																												if (10 < b)
																												{
																													goto end_IL_04c7;
																												}
																												goto IL_0603;
																												IL_0603:
																												if (10 > b)
																												{
																													goto end_IL_04c7;
																												}
																												goto IL_0611;
																												IL_0611:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0673;
																												IL_0673:
																												num5 -= 2;
																												break;
																												IL_0686:
																												if (12 < b)
																												{
																													goto end_IL_04c7;
																												}
																												goto IL_0694;
																												IL_0694:
																												if (12 > b)
																												{
																													goto end_IL_04c7;
																												}
																												goto IL_06a2;
																												IL_06a2:
																												array8 = array3;
																												num6 = num5;
																												if (array == null)
																												{
																													goto IL_06b1;
																												}
																												num7 = ptr2;
																												byte b2 = *num7;
																												ptr2 = num7 + 4;
																												int num8 = *(int*)(ptr2 + num3);
																												ptr2 += 8;
																												byte* ptr3 = ptr2 + num8;
																												byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																												while (ptr2 != ptr3)
																												{
																													*ptr4 = (byte)(*ptr2 ^ b2);
																													ptr2++;
																													ptr4++;
																												}
																												array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																												goto IL_0759;
																												IL_0767:
																												num5++;
																												break;
																											}
																											break;
																										}
																										goto IL_077a;
																										IL_0a33:
																										array2[num5 - 2] = 0;
																										num = 214;
																										goto IL_0a50;
																										IL_077a:
																										if (6 <= b)
																										{
																											goto IL_0785;
																										}
																										goto IL_07ec;
																										IL_0785:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_07c5;
																										IL_07c5:
																										array2[num5 - 2] = 0;
																										goto IL_07d9;
																										IL_07d9:
																										num5--;
																										break;
																										IL_07ec:
																										if (3 >= b)
																										{
																											goto IL_07fa;
																										}
																										goto IL_094e;
																										IL_07fa:
																										if (3 <= b)
																										{
																											goto IL_0805;
																										}
																										goto IL_084f;
																										IL_0805:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_082e;
																										IL_082e:
																										ptr2 += 8;
																										goto IL_083c;
																										IL_083c:
																										num5--;
																										break;
																										IL_084f:
																										if (1 >= b)
																										{
																											goto IL_085a;
																										}
																										goto IL_08c2;
																										IL_085a:
																										if (1 > b)
																										{
																											goto end_IL_04c7;
																										}
																										goto IL_0868;
																										IL_0868:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																										goto IL_0881;
																										IL_0881:
																										array2[num5] = 0;
																										num = 81;
																										goto IL_0898;
																										IL_0898:
																										num5++;
																										num = 55;
																										goto IL_08af;
																										IL_08af:
																										ptr2 += 8;
																										break;
																										IL_08c2:
																										if (2 < b)
																										{
																											goto end_IL_04c7;
																										}
																										goto IL_08d0;
																										IL_08d0:
																										if (2 > b)
																										{
																											goto end_IL_04c7;
																										}
																										goto IL_08de;
																										IL_08de:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										num = 228;
																										goto IL_0927;
																										IL_0927:
																										array2[num5 - 2] = 0;
																										goto IL_093b;
																										IL_093b:
																										num5--;
																										break;
																										IL_094e:
																										if (4 >= b)
																										{
																											goto IL_0959;
																										}
																										goto IL_09cc;
																										IL_0959:
																										if (4 > b)
																										{
																											goto end_IL_04c7;
																										}
																										goto IL_0967;
																										IL_0967:
																										array2[num5] = 0;
																										goto IL_0975;
																										IL_0975:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_0998;
																										IL_0998:
																										array3[num5] = null;
																										goto IL_09a2;
																										IL_09a2:
																										num5++;
																										num = 103;
																										goto IL_09b9;
																										IL_09b9:
																										ptr2 += 8;
																										break;
																										IL_09cc:
																										if (5 < b)
																										{
																											goto end_IL_04c7;
																										}
																										goto IL_09da;
																										IL_09da:
																										if (5 > b)
																										{
																											num = 49;
																											goto end_IL_04c7;
																										}
																										goto IL_09f3;
																										IL_0a50:
																										num5--;
																										break;
																										IL_09f3:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_0a33;
																									}
																									break;
																								}
																								goto IL_0a63;
																								IL_0a8f:
																								num5--;
																								break;
																								IL_0a63:
																								array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																								goto IL_0a81;
																								IL_0a81:
																								ptr2 += 8;
																								goto IL_0a8f;
																							}
																							break;
																						}
																						goto IL_0aa2;
																						IL_0f98:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_0fbc;
																						IL_0aa2:
																						if (20 < b)
																						{
																							goto IL_0ab0;
																						}
																						num = 6;
																						goto IL_0cd6;
																						IL_0ab0:
																						if (23 < b)
																						{
																							goto IL_0abe;
																						}
																						goto IL_0b80;
																						IL_0abe:
																						if (25 < b)
																						{
																							goto IL_0ac9;
																						}
																						goto IL_0aea;
																						IL_0ac9:
																						if (26 < b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0ad7;
																						IL_0ad7:
																						if (26 <= b)
																						{
																						}
																						goto end_IL_04c7;
																						IL_0aea:
																						if (25 > b)
																						{
																							goto IL_0af5;
																						}
																						goto IL_0b64;
																						IL_0af5:
																						if (24 < b)
																						{
																							goto end_IL_04c7;
																						}
																						num = 57;
																						goto IL_0b0c;
																						IL_0fd3:
																						ptr2 += 8;
																						break;
																						IL_0b0c:
																						if (24 > b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0b1a;
																						IL_0b1a:
																						((delegate*<string, void>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																						goto IL_0b43;
																						IL_0b43:
																						num5--;
																						goto IL_0b51;
																						IL_0b51:
																						ptr2 += 8;
																						break;
																						IL_0b64:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						break;
																						IL_0b80:
																						if (23 > b)
																						{
																							goto IL_0b8e;
																						}
																						goto IL_0c4c;
																						IL_0b8e:
																						if (21 < b)
																						{
																							goto IL_0b99;
																						}
																						goto IL_0bcd;
																						IL_0b99:
																						if (22 < b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0ba7;
																						IL_0ba7:
																						if (22 > b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0bb5;
																						IL_0bb5:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_0bcd:
																						if (21 > b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0bdb;
																						IL_0bdb:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0c39;
																						IL_0c39:
																						num5--;
																						break;
																						IL_0c4c:
																						array2[num5 - 2] = 5;
																						goto IL_0c60;
																						IL_0c60:
																						array3[num5 - 2] = ((delegate*<string, string, string>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																						goto IL_0cac;
																						IL_0cac:
																						num5--;
																						goto IL_0cba;
																						IL_0cba:
																						ptr2 += 8;
																						break;
																						IL_0fbc:
																						num5++;
																						num = 232;
																						goto IL_0fd3;
																						IL_0cd6:
																						if (20 > b)
																						{
																							goto IL_0ce4;
																						}
																						goto IL_0f8a;
																						IL_0ce4:
																						if (16 < b)
																						{
																							goto IL_0cf2;
																						}
																						goto IL_0e18;
																						IL_0cf2:
																						if (18 < b)
																						{
																							goto IL_0cfd;
																						}
																						goto IL_0d41;
																						IL_0cfd:
																						if (19 < b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0d0b;
																						IL_0d0b:
																						if (19 > b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0d19;
																						IL_0d19:
																						((delegate*<void>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])();
																						goto IL_0d2e;
																						IL_0d2e:
																						ptr2 += 8;
																						break;
																						IL_0d41:
																						if (18 > b)
																						{
																							goto IL_0d4c;
																						}
																						goto IL_0db9;
																						IL_0d4c:
																						if (17 < b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0d5a;
																						IL_0d5a:
																						if (17 > b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0d68;
																						IL_0d68:
																						((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																						goto IL_0da6;
																						IL_0da6:
																						num5 -= 3;
																						break;
																						IL_0db9:
																						array2[num5 - 1] = 5;
																						goto IL_0dcd;
																						IL_0dcd:
																						array3[num5 - 1] = ((delegate*<string[], string>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																						goto IL_0e05;
																						IL_0e05:
																						ptr2 += 8;
																						break;
																						IL_0e18:
																						if (16 > b)
																						{
																							goto IL_0e26;
																						}
																						goto IL_0f2b;
																						IL_0e26:
																						if (14 >= b)
																						{
																							goto IL_0e31;
																						}
																						goto IL_0e8a;
																						IL_0e31:
																						if (14 > b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0e3f;
																						IL_0e3f:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_0e68;
																						IL_0e68:
																						array2[num5 - 1] = 5;
																						num = 61;
																						break;
																						IL_0e8a:
																						if (15 < b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0e98;
																						IL_0e98:
																						if (15 > b)
																						{
																							goto end_IL_04c7;
																						}
																						goto IL_0ea6;
																						IL_0ea6:
																						array2[num5] = array2[num5 - 1];
																						goto IL_0ebe;
																						IL_0ebe:
																						array4[num5 - 0] = array4[num5 - 1];
																						goto IL_0edc;
																						IL_0edc:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0f00;
																						IL_0f00:
																						array3[num5] = array3[num5 - 1];
																						goto IL_0f18;
																						IL_0f18:
																						num5++;
																						break;
																						IL_0f2b:
																						array2[num5] = 5;
																						num = 45;
																						goto IL_0f42;
																						IL_0f42:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_0f5a;
																						IL_0f5a:
																						num5++;
																						num = 148;
																						goto IL_0f71;
																						IL_0f71:
																						ptr2 += 8;
																						num = 208;
																						break;
																						IL_0f8a:
																						array2[num5] = 0;
																						goto IL_0f98;
																					}
																					goto end_IL_04d7;
																					continue;
																					end_IL_04c7:
																					break;
																					IL_04c7:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_04d7:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
															end_IL_0ff6:
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_06b1:
			while (true)
			{
				IL_06b1_2:
				array = new byte[4];
				while (true)
				{
					IL_06bf:
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num5] = 5;
						while (true)
						{
							IL_0767_2:
							num5++;
							while (true)
							{
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									IL_050b_2:
									num = 67;
									while (true)
									{
										IL_04f7_2:
										byte b = *ptr2;
										num = 146;
										while (true)
										{
											IL_04e7_2:
											ptr2++;
											while (true)
											{
												IL_04d7_2:
												if (b >= 1)
												{
													while (b <= 26)
													{
														while (true)
														{
															IL_04b7_2:
															if (13 >= b)
															{
																while (true)
																{
																	IL_04a7_2:
																	if (13 > b)
																	{
																		while (true)
																		{
																			IL_0497_2:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0487_2:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0477_2:
																							if (9 <= b)
																							{
																								while (true)
																								{
																									IL_0435_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									while (true)
																									{
																										IL_041f_2:
																										array2[num5 - 2] = 0;
																										while (true)
																										{
																											IL_0406_2:
																											num5--;
																											num = 249;
																											while (num != 249)
																											{
																												if (num != 1230)
																												{
																													goto end_IL_04c7_2;
																												}
																												switch (num)
																												{
																												case 28:
																													goto IL_0406_2;
																												case 62:
																													goto IL_041f_2;
																												case 95:
																												case 138:
																													goto IL_0435_2;
																												case 123:
																													goto IL_0477_2;
																												case 17:
																												case 193:
																													goto IL_0487_2;
																												case 126:
																												case 175:
																													goto IL_0497_2;
																												case 75:
																													goto IL_04a7_2;
																												case 91:
																													goto IL_04b7_2;
																												case 184:
																													goto IL_04c7_2;
																												case 36:
																													goto IL_04d7_2;
																												case 146:
																													goto IL_04e7_2;
																												case 67:
																													goto IL_04f7_2;
																												case 149:
																													goto IL_050b_2;
																												case 64:
																												case 173:
																													goto IL_051f_2;
																												case 108:
																													goto IL_052a_2;
																												case 136:
																													goto IL_053a_2;
																												case 70:
																													goto IL_0548_2;
																												case 27:
																												case 144:
																													goto IL_0556_2;
																												case 170:
																												case 203:
																													goto IL_0569_2;
																												case 165:
																													goto IL_05a9_2;
																												case 186:
																													goto IL_05bd_2;
																												case 115:
																													goto IL_05d9_2;
																												case 147:
																													goto IL_05e7_2;
																												case 71:
																												case 90:
																													goto IL_05f5_2;
																												case 210:
																													goto IL_0603_2;
																												case 135:
																												case 179:
																													goto IL_0611_2;
																												case 39:
																													goto IL_0673_2;
																												case 26:
																													goto IL_0686_2;
																												case 229:
																													goto IL_0694_2;
																												case 105:
																												case 110:
																													goto IL_06a2_2;
																												case 236:
																													goto end_IL_0ff6_2;
																												case 59:
																													goto IL_0767_2;
																												case 206:
																													goto IL_077a_2;
																												case 65:
																												case 97:
																													goto IL_0785_2;
																												case 212:
																													goto IL_07c5_2;
																												case 151:
																													goto IL_07d9_2;
																												case 140:
																													goto IL_07ec_2;
																												case 51:
																													goto IL_07fa_2;
																												case 47:
																												case 238:
																													goto IL_0805_2;
																												case 56:
																													goto IL_082e_2;
																												case 230:
																													goto IL_083c_2;
																												case 216:
																													goto IL_084f_2;
																												case 182:
																													goto IL_085a_2;
																												case 101:
																												case 189:
																													goto IL_0868_2;
																												case 100:
																													goto IL_0881_2;
																												case 81:
																													goto IL_0898_2;
																												case 55:
																													goto IL_08af_2;
																												case 169:
																													goto IL_08c2_2;
																												case 2:
																													goto IL_08d0_2;
																												case 195:
																												case 217:
																													goto IL_08de_2;
																												case 228:
																													goto IL_0927_2;
																												case 80:
																													goto IL_093b_2;
																												case 178:
																													goto IL_094e_2;
																												case 52:
																													goto IL_0959_2;
																												case 104:
																												case 122:
																													goto IL_0967_2;
																												case 161:
																													goto IL_0975_2;
																												case 89:
																													goto IL_0998_2;
																												case 79:
																													goto IL_09a2_2;
																												case 103:
																													goto IL_09b9_2;
																												case 137:
																													goto IL_09cc_2;
																												case 181:
																													goto IL_09da_2;
																												case 21:
																												case 111:
																													goto IL_09f3_2;
																												case 150:
																													goto IL_0a33_2;
																												case 214:
																													goto IL_0a50_2;
																												case 99:
																												case 141:
																													goto IL_0a63_2;
																												case 25:
																													goto IL_0a81_2;
																												case 168:
																													goto IL_0a8f_2;
																												case 154:
																													goto IL_0aa2_2;
																												case 83:
																													goto IL_0ab0_2;
																												case 14:
																												case 187:
																													goto IL_0abe_2;
																												case 20:
																												case 23:
																													goto IL_0ac9_2;
																												case 15:
																													goto IL_0ad7_2;
																												case 139:
																													goto IL_0aea_2;
																												case 125:
																													goto IL_0af5_2;
																												case 57:
																													goto IL_0b0c_2;
																												case 127:
																												case 167:
																													goto IL_0b1a_2;
																												case 12:
																													goto IL_0b43_2;
																												case 44:
																													goto IL_0b51_2;
																												case 114:
																												case 237:
																													goto IL_0b64_2;
																												case 42:
																													goto IL_0b80_2;
																												case 66:
																													goto IL_0b8e_2;
																												case 32:
																												case 191:
																													goto IL_0b99_2;
																												case 16:
																													goto IL_0ba7_2;
																												case 78:
																												case 134:
																													goto IL_0bb5_2;
																												case 53:
																													goto IL_0bcd_2;
																												case 50:
																												case 119:
																													goto IL_0bdb_2;
																												case 183:
																													goto IL_0c39_2;
																												case 82:
																												case 219:
																													goto IL_0c4c_2;
																												case 226:
																													goto IL_0c60_2;
																												case 207:
																													goto IL_0cac_2;
																												case 68:
																													goto IL_0cba_2;
																												case 6:
																													goto IL_0cd6_2;
																												case 172:
																												case 185:
																													goto IL_0ce4_2;
																												case 174:
																													goto IL_0cf2_2;
																												case 48:
																													goto IL_0cfd_2;
																												case 209:
																													goto IL_0d0b_2;
																												case 86:
																												case 166:
																													goto IL_0d19_2;
																												case 194:
																													goto IL_0d2e_2;
																												case 227:
																													goto IL_0d41_2;
																												case 88:
																												case 180:
																													goto IL_0d4c_2;
																												case 7:
																													goto IL_0d5a_2;
																												case 4:
																												case 94:
																													goto IL_0d68_2;
																												case 215:
																													goto IL_0da6_2;
																												case 96:
																												case 107:
																													goto IL_0db9_2;
																												case 152:
																													goto IL_0dcd_2;
																												case 213:
																													goto IL_0e05_2;
																												case 201:
																													goto IL_0e18_2;
																												case 74:
																												case 188:
																													goto IL_0e26_2;
																												case 224:
																													goto IL_0e31_2;
																												case 54:
																												case 73:
																													goto IL_0e3f_2;
																												case 117:
																													goto IL_0e68_2;
																												case 142:
																													goto IL_0e8a_2;
																												case 132:
																													goto IL_0e98_2;
																												case 131:
																												case 220:
																													goto IL_0ea6_2;
																												case 176:
																													goto IL_0ebe_2;
																												case 43:
																													goto IL_0edc_2;
																												case 156:
																													goto IL_0f00_2;
																												case 30:
																													goto IL_0f18_2;
																												case 118:
																												case 159:
																													goto IL_0f2b_2;
																												case 45:
																													goto IL_0f42_2;
																												case 155:
																													goto IL_0f5a_2;
																												case 148:
																													goto IL_0f71_2;
																												case 130:
																												case 231:
																													goto IL_0f8a_2;
																												case 13:
																													goto IL_0f98_2;
																												case 240:
																													goto IL_0fbc_2;
																												case 232:
																													goto IL_0fd3_2;
																												case 5:
																												case 8:
																												case 9:
																												case 10:
																												case 11:
																												case 18:
																												case 24:
																												case 29:
																												case 31:
																												case 33:
																												case 34:
																												case 35:
																												case 38:
																												case 49:
																												case 69:
																												case 72:
																												case 76:
																												case 77:
																												case 92:
																												case 106:
																												case 109:
																												case 112:
																												case 121:
																												case 124:
																												case 133:
																												case 143:
																												case 162:
																												case 163:
																												case 177:
																												case 190:
																												case 192:
																												case 196:
																												case 197:
																												case 199:
																												case 200:
																												case 202:
																												case 204:
																												case 211:
																												case 218:
																												case 225:
																												case 233:
																													goto end_IL_04c7_2;
																												case 0:
																												case 1:
																												case 3:
																												case 19:
																												case 22:
																												case 37:
																												case 58:
																												case 60:
																												case 61:
																												case 63:
																												case 84:
																												case 85:
																												case 116:
																												case 120:
																												case 128:
																												case 129:
																												case 145:
																												case 157:
																												case 158:
																												case 171:
																												case 198:
																												case 208:
																												case 221:
																												case 234:
																												case 235:
																												case 239:
																												case 241:
																												case 242:
																													goto end_IL_03f3_2;
																												case 87:
																													ptr2 = ptr;
																													goto end_IL_03f3_2;
																												case 46:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getThreeLetterWindowsLanguageNameNestedPublic.SetActorAsReferenceWhenCopyingClaimsIdentityprocessorCount);
																													goto case 87;
																												case 98:
																													array7 = new object[16];
																													goto case 46;
																												case 160:
																													array6 = new long[4];
																													goto case 98;
																												case 40:
																													array5 = new int[6];
																													goto case 160;
																												case 153:
																													array4 = new int[4];
																													goto case 40;
																												case 113:
																													array3 = new object[4];
																													goto case 153;
																												case 93:
																												case 102:
																													array2 = new byte[4];
																													goto case 113;
																												case 205:
																													num3 = num2 * 4;
																													goto case 93;
																												case 222:
																													num2 = 1;
																													goto case 205;
																												case 223:
																													goto end_IL_0759;
																												case 41:
																												case 164:
																													return;
																												}
																												continue;
																												end_IL_03f3_2:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							num = 173;
																							goto IL_051f_2;
																							IL_0548_2:
																							if (8 > b)
																							{
																								goto end_IL_04c7_2;
																							}
																							goto IL_0556_2;
																							IL_0556_2:
																							num5--;
																							break;
																							IL_051f_2:
																							if (7 >= b)
																							{
																								goto IL_052a_2;
																							}
																							goto IL_053a_2;
																							IL_052a_2:
																							if (7 > b)
																							{
																								goto end_IL_04c7_2;
																							}
																							goto IL_0569_2;
																							IL_0569_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_05a9_2;
																							IL_05a9_2:
																							array2[num5 - 2] = 0;
																							goto IL_05bd_2;
																							IL_05bd_2:
																							num5--;
																							num = 235;
																							break;
																							IL_053a_2:
																							if (8 < b)
																							{
																								goto end_IL_04c7_2;
																							}
																							goto IL_0548_2;
																						}
																						break;
																					}
																					goto IL_05d9_2;
																					IL_06a2_2:
																					array8 = array3;
																					num6 = num5;
																					if (array == null)
																					{
																						goto IL_06b1_2;
																					}
																					goto IL_06bf;
																					IL_05d9_2:
																					if (11 >= b)
																					{
																						goto IL_05e7_2;
																					}
																					goto IL_0686_2;
																					IL_05e7_2:
																					if (11 <= b)
																					{
																						break;
																					}
																					goto IL_05f5_2;
																					IL_05f5_2:
																					if (10 < b)
																					{
																						goto end_IL_04c7_2;
																					}
																					goto IL_0603_2;
																					IL_0603_2:
																					if (10 > b)
																					{
																						goto end_IL_04c7_2;
																					}
																					goto IL_0611_2;
																					IL_0611_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0673_2;
																					IL_0673_2:
																					num5 -= 2;
																					break;
																					IL_0686_2:
																					if (12 < b)
																					{
																						goto end_IL_04c7_2;
																					}
																					goto IL_0694_2;
																					IL_0694_2:
																					if (12 > b)
																					{
																						goto end_IL_04c7_2;
																					}
																					goto IL_06a2_2;
																				}
																				break;
																			}
																			goto IL_077a_2;
																			IL_0a33_2:
																			array2[num5 - 2] = 0;
																			num = 214;
																			goto IL_0a50_2;
																			IL_077a_2:
																			if (6 <= b)
																			{
																				goto IL_0785_2;
																			}
																			goto IL_07ec_2;
																			IL_0785_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_07c5_2;
																			IL_07c5_2:
																			array2[num5 - 2] = 0;
																			goto IL_07d9_2;
																			IL_07d9_2:
																			num5--;
																			break;
																			IL_07ec_2:
																			if (3 >= b)
																			{
																				goto IL_07fa_2;
																			}
																			goto IL_094e_2;
																			IL_07fa_2:
																			if (3 <= b)
																			{
																				goto IL_0805_2;
																			}
																			goto IL_084f_2;
																			IL_0805_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_082e_2;
																			IL_082e_2:
																			ptr2 += 8;
																			goto IL_083c_2;
																			IL_083c_2:
																			num5--;
																			break;
																			IL_084f_2:
																			if (1 >= b)
																			{
																				goto IL_085a_2;
																			}
																			goto IL_08c2_2;
																			IL_085a_2:
																			if (1 > b)
																			{
																				goto end_IL_04c7_2;
																			}
																			goto IL_0868_2;
																			IL_0868_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0881_2;
																			IL_0881_2:
																			array2[num5] = 0;
																			num = 81;
																			goto IL_0898_2;
																			IL_0898_2:
																			num5++;
																			num = 55;
																			goto IL_08af_2;
																			IL_08af_2:
																			ptr2 += 8;
																			break;
																			IL_08c2_2:
																			if (2 < b)
																			{
																				goto end_IL_04c7_2;
																			}
																			goto IL_08d0_2;
																			IL_08d0_2:
																			if (2 > b)
																			{
																				goto end_IL_04c7_2;
																			}
																			goto IL_08de_2;
																			IL_08de_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			num = 228;
																			goto IL_0927_2;
																			IL_0927_2:
																			array2[num5 - 2] = 0;
																			goto IL_093b_2;
																			IL_093b_2:
																			num5--;
																			break;
																			IL_094e_2:
																			if (4 >= b)
																			{
																				goto IL_0959_2;
																			}
																			goto IL_09cc_2;
																			IL_0959_2:
																			if (4 > b)
																			{
																				goto end_IL_04c7_2;
																			}
																			goto IL_0967_2;
																			IL_0967_2:
																			array2[num5] = 0;
																			goto IL_0975_2;
																			IL_0975_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_0998_2;
																			IL_0998_2:
																			array3[num5] = null;
																			goto IL_09a2_2;
																			IL_09a2_2:
																			num5++;
																			num = 103;
																			goto IL_09b9_2;
																			IL_09b9_2:
																			ptr2 += 8;
																			break;
																			IL_09cc_2:
																			if (5 < b)
																			{
																				goto end_IL_04c7_2;
																			}
																			goto IL_09da_2;
																			IL_09da_2:
																			if (5 > b)
																			{
																				num = 49;
																				goto end_IL_04c7_2;
																			}
																			goto IL_09f3_2;
																			IL_0a50_2:
																			num5--;
																			break;
																			IL_09f3_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0a33_2;
																		}
																		break;
																	}
																	goto IL_0a63_2;
																	IL_0a8f_2:
																	num5--;
																	break;
																	IL_0a63_2:
																	array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																	goto IL_0a81_2;
																	IL_0a81_2:
																	ptr2 += 8;
																	goto IL_0a8f_2;
																}
																break;
															}
															goto IL_0aa2_2;
															IL_0f98_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])() ? 1 : 0);
															goto IL_0fbc_2;
															IL_0aa2_2:
															if (20 < b)
															{
																goto IL_0ab0_2;
															}
															num = 6;
															goto IL_0cd6_2;
															IL_0ab0_2:
															if (23 < b)
															{
																goto IL_0abe_2;
															}
															goto IL_0b80_2;
															IL_0abe_2:
															if (25 < b)
															{
																goto IL_0ac9_2;
															}
															goto IL_0aea_2;
															IL_0ac9_2:
															if (26 < b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0ad7_2;
															IL_0ad7_2:
															if (26 <= b)
															{
															}
															goto end_IL_04c7_2;
															IL_0aea_2:
															if (25 > b)
															{
																goto IL_0af5_2;
															}
															goto IL_0b64_2;
															IL_0af5_2:
															if (24 < b)
															{
																goto end_IL_04c7_2;
															}
															num = 57;
															goto IL_0b0c_2;
															IL_0fd3_2:
															ptr2 += 8;
															break;
															IL_0b0c_2:
															if (24 > b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0b1a_2;
															IL_0b1a_2:
															((delegate*<string, void>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
															goto IL_0b43_2;
															IL_0b43_2:
															num5--;
															goto IL_0b51_2;
															IL_0b51_2:
															ptr2 += 8;
															break;
															IL_0b64_2:
															num9 = ptr2;
															num10 = -200;
															num4 = 1;
															ptr2 = num9 + num10;
															break;
															IL_0b80_2:
															if (23 > b)
															{
																goto IL_0b8e_2;
															}
															goto IL_0c4c_2;
															IL_0b8e_2:
															if (21 < b)
															{
																goto IL_0b99_2;
															}
															goto IL_0bcd_2;
															IL_0b99_2:
															if (22 < b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0ba7_2;
															IL_0ba7_2:
															if (22 > b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0bb5_2;
															IL_0bb5_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															IL_0bcd_2:
															if (21 > b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0bdb_2;
															IL_0bdb_2:
															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0c39_2;
															IL_0c39_2:
															num5--;
															break;
															IL_0c4c_2:
															array2[num5 - 2] = 5;
															goto IL_0c60_2;
															IL_0c60_2:
															array3[num5 - 2] = ((delegate*<string, string, string>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
															goto IL_0cac_2;
															IL_0cac_2:
															num5--;
															goto IL_0cba_2;
															IL_0cba_2:
															ptr2 += 8;
															break;
															IL_0fbc_2:
															num5++;
															num = 232;
															goto IL_0fd3_2;
															IL_0cd6_2:
															if (20 > b)
															{
																goto IL_0ce4_2;
															}
															goto IL_0f8a_2;
															IL_0ce4_2:
															if (16 < b)
															{
																goto IL_0cf2_2;
															}
															goto IL_0e18_2;
															IL_0cf2_2:
															if (18 < b)
															{
																goto IL_0cfd_2;
															}
															goto IL_0d41_2;
															IL_0cfd_2:
															if (19 < b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0d0b_2;
															IL_0d0b_2:
															if (19 > b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0d19_2;
															IL_0d19_2:
															((delegate*<void>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])();
															goto IL_0d2e_2;
															IL_0d2e_2:
															ptr2 += 8;
															break;
															IL_0d41_2:
															if (18 > b)
															{
																goto IL_0d4c_2;
															}
															goto IL_0db9_2;
															IL_0d4c_2:
															if (17 < b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0d5a_2;
															IL_0d5a_2:
															if (17 > b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0d68_2;
															IL_0d68_2:
															((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
															goto IL_0da6_2;
															IL_0da6_2:
															num5 -= 3;
															break;
															IL_0db9_2:
															array2[num5 - 1] = 5;
															goto IL_0dcd_2;
															IL_0dcd_2:
															array3[num5 - 1] = ((delegate*<string[], string>)IsNeutralCultureLessThan[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
															goto IL_0e05_2;
															IL_0e05_2:
															ptr2 += 8;
															break;
															IL_0e18_2:
															if (16 > b)
															{
																goto IL_0e26_2;
															}
															goto IL_0f2b_2;
															IL_0e26_2:
															if (14 >= b)
															{
																goto IL_0e31_2;
															}
															goto IL_0e8a_2;
															IL_0e31_2:
															if (14 > b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0e3f_2;
															IL_0e3f_2:
															array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
															goto IL_0e68_2;
															IL_0e68_2:
															array2[num5 - 1] = 5;
															num = 61;
															break;
															IL_0e8a_2:
															if (15 < b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0e98_2;
															IL_0e98_2:
															if (15 > b)
															{
																goto end_IL_04c7_2;
															}
															goto IL_0ea6_2;
															IL_0ea6_2:
															array2[num5] = array2[num5 - 1];
															goto IL_0ebe_2;
															IL_0ebe_2:
															array4[num5 - 0] = array4[num5 - 1];
															goto IL_0edc_2;
															IL_0edc_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0f00_2;
															IL_0f00_2:
															array3[num5] = array3[num5 - 1];
															goto IL_0f18_2;
															IL_0f18_2:
															num5++;
															break;
															IL_0f2b_2:
															array2[num5] = 5;
															num = 45;
															goto IL_0f42_2;
															IL_0f42_2:
															array3[num5] = array7[*(int*)(ptr2 + num3)];
															goto IL_0f5a_2;
															IL_0f5a_2:
															num5++;
															num = 148;
															goto IL_0f71_2;
															IL_0f71_2:
															ptr2 += 8;
															num = 208;
															break;
															IL_0f8a_2:
															array2[num5] = 0;
															goto IL_0f98_2;
														}
														goto end_IL_04d7_2;
														continue;
														end_IL_04c7_2:
														break;
														IL_04c7_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												break;
												continue;
												end_IL_04d7_2:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_0ff6_2:
								break;
							}
							break;
						}
						continue;
						end_IL_0759:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public Class124()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 3;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DaylightTransitionStartDomainManager.GenericWriteWindowsRuntimeResourceManagerBase);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 42;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02a5:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0288:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0278:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_0268:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_0258:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_0228:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_0203:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_01ee:
																																array2[num5] = null;
																																num = 115;
																																while (true)
																																{
																																	if (num != 115)
																																	{
																																		if (num != 1096)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 23:
																																			goto IL_01ee;
																																		case 26:
																																			goto IL_0203;
																																		case 21:
																																		case 94:
																																			goto IL_0228;
																																		case 73:
																																			goto IL_0238;
																																		case 101:
																																			goto IL_0248;
																																		case 1:
																																		case 4:
																																			goto IL_0258;
																																		case 71:
																																			goto IL_0268;
																																		case 46:
																																			goto IL_0278;
																																		case 96:
																																			goto IL_0288;
																																		case 102:
																																			goto IL_0295;
																																		case 30:
																																			goto IL_02a5;
																																		case 92:
																																			goto end_IL_02a5;
																																		case 82:
																																		case 108:
																																			goto end_IL_02b5;
																																		case 56:
																																			goto IL_02d0;
																																		case 34:
																																		case 55:
																																			goto IL_02de;
																																		case 60:
																																			goto IL_02ec;
																																		case 52:
																																		case 78:
																																			goto IL_02fa;
																																		case 10:
																																			goto IL_0368;
																																		case 12:
																																		case 93:
																																			goto IL_037b;
																																		case 61:
																																			goto IL_0389;
																																		case 40:
																																		case 95:
																																			goto IL_039c;
																																		case 57:
																																		case 99:
																																			goto end_IL_01db;
																																		case 77:
																																			goto IL_03c8;
																																		case 28:
																																		case 65:
																																			goto IL_03d6;
																																		case 67:
																																			goto IL_0416;
																																		case 39:
																																			goto IL_042a;
																																		case 20:
																																		case 69:
																																			goto IL_043d;
																																		case 58:
																																			goto IL_044b;
																																		case 43:
																																		case 91:
																																			goto IL_0459;
																																		case 103:
																																			goto IL_0482;
																																		case 24:
																																			goto IL_0490;
																																		case 75:
																																			goto IL_04b1;
																																		case 70:
																																			goto IL_04cd;
																																		case 31:
																																		case 87:
																																			goto IL_04e9;
																																		case 9:
																																			goto IL_04f7;
																																		case 38:
																																			goto IL_051b;
																																		case 106:
																																			goto IL_0529;
																																		case 11:
																																			goto IL_053c;
																																		case 35:
																																			goto IL_0547;
																																		case 15:
																																		case 68:
																																			goto IL_0552;
																																		case 33:
																																			goto IL_0565;
																																		case 63:
																																			goto IL_0570;
																																		case 6:
																																		case 47:
																																			goto IL_0584;
																																		case 0:
																																		case 5:
																																		case 7:
																																		case 13:
																																		case 17:
																																		case 18:
																																		case 22:
																																		case 27:
																																		case 41:
																																		case 49:
																																		case 50:
																																		case 51:
																																		case 54:
																																		case 62:
																																		case 64:
																																		case 66:
																																		case 76:
																																		case 79:
																																		case 83:
																																		case 84:
																																		case 85:
																																		case 90:
																																			goto end_IL_0238;
																																		case 29:
																																			goto IL_05c0;
																																		case 37:
																																			goto IL_05ce;
																																		case 25:
																																			goto IL_05dc;
																																		case 8:
																																		case 16:
																																		case 36:
																																		case 42:
																																		case 48:
																																		case 59:
																																		case 74:
																																		case 80:
																																		case 88:
																																		case 89:
																																		case 98:
																																		case 105:
																																		case 107:
																																			goto end_IL_02c5;
																																		case 81:
																																			goto end_IL_05ea;
																																		case 44:
																																			goto end_IL_05fd;
																																		case 32:
																																			goto end_IL_0610;
																																		case 53:
																																			goto end_IL_061b;
																																		case 100:
																																			goto end_IL_0630;
																																		case 19:
																																		case 72:
																																			goto end_IL_0645;
																																		case 14:
																																			goto end_IL_0655;
																																		case 45:
																																		case 104:
																																			goto end_IL_0665;
																																		case 2:
																																			goto end_IL_0675;
																																		case 3:
																																			goto end_IL_0685;
																																		case 86:
																																		case 97:
																																			goto IL_06a0;
																																		}
																																		continue;
																																	}
																																	num5++;
																																	goto IL_04b1;
																																	IL_04b1:
																																	ptr2 += 8;
																																	goto end_IL_02c5;
																																	continue;
																																	end_IL_01db:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_03bd;
																													continue;
																													end_IL_0238:
																													break;
																													IL_0238:;
																												}
																												break;
																												IL_0248:;
																											}
																											break;
																										}
																										num = 70;
																										goto IL_04cd;
																										IL_04cd:
																										if (6 <= b)
																										{
																											goto end_IL_02c5;
																										}
																										num = 18;
																										break;
																									}
																									break;
																								}
																								goto IL_04e9;
																								IL_0529:
																								ptr2 += 8;
																								goto end_IL_02c5;
																								IL_04e9:
																								array[num5] = 0;
																								goto IL_04f7;
																								IL_04f7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)setResourceManagerControlPadLeft[*(int*)(ptr2 + num3)])();
																								goto IL_051b;
																								IL_051b:
																								num5++;
																								goto IL_0529;
																							}
																							break;
																						}
																						goto IL_053c;
																						IL_0584:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02c5;
																						IL_053c:
																						if (9 >= b)
																						{
																							goto IL_0547;
																						}
																						goto IL_0565;
																						IL_0547:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0552;
																						IL_0552:
																						num5--;
																						goto end_IL_02c5;
																						IL_0565:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0570;
																						IL_0570:
																						if (10 > b)
																						{
																							break;
																						}
																						num = 47;
																						goto IL_0584;
																					}
																					break;
																				}
																				goto IL_02d0;
																				IL_039c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 80;
																				goto end_IL_02c5;
																				IL_02d0:
																				if (5 > b)
																				{
																					goto IL_02de;
																				}
																				goto IL_039c;
																				IL_02de:
																				if (2 >= b)
																				{
																					goto IL_02ec;
																				}
																				goto IL_03bd;
																				IL_02ec:
																				if (2 <= b)
																				{
																					goto IL_02fa;
																				}
																				goto IL_037b;
																				IL_02fa:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0368;
																				IL_0368:
																				num5 -= 2;
																				goto end_IL_02c5;
																				IL_037b:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0389;
																				IL_0389:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_03bd:
																				if (3 >= b)
																				{
																					goto IL_03c8;
																				}
																				goto IL_043d;
																				IL_03c8:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_03d6;
																				IL_03d6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0416;
																				IL_0416:
																				array[num5 - 2] = 0;
																				goto IL_042a;
																				IL_042a:
																				num5--;
																				goto end_IL_02c5;
																				IL_043d:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_044b;
																				IL_044b:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0459;
																				IL_0459:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0482;
																				IL_0482:
																				ptr2 += 8;
																				goto IL_0490;
																				IL_0490:
																				num5--;
																				goto end_IL_02c5;
																			}
																			break;
																			IL_0295:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05c0;
																	IL_05dc:
																	ptr2 += 8;
																	goto end_IL_02c5;
																	IL_05ce:
																	num5++;
																	goto IL_05dc;
																	IL_05c0:
																	array[num5] = 0;
																	goto IL_05ce;
																	continue;
																	end_IL_02a5:
																	break;
																}
																continue;
																end_IL_02b5:
																break;
															}
															continue;
															end_IL_02c5:
															break;
														}
														continue;
													}
													goto IL_06a0;
													IL_06a0:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05ea:
													break;
												}
												continue;
												end_IL_05fd:
												break;
											}
											continue;
											end_IL_0610:
											break;
										}
										continue;
										end_IL_061b:
										break;
									}
									continue;
									end_IL_0630:
									break;
								}
								continue;
								end_IL_0645:
								break;
							}
							continue;
							end_IL_0655:
							break;
						}
						continue;
						end_IL_0665:
						break;
					}
					continue;
					end_IL_0675:
					break;
				}
				continue;
				end_IL_0685:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 123;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 133;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 144;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BuiltinPerformanceMonitoringUsersSidIsClass.SecurityActionMngdNativeArrayMarshaler);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0372:
														byte b = *ptr2;
														while (true)
														{
															IL_0359:
															ptr2++;
															num = 99;
															while (true)
															{
																IL_0349:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_032c:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_031c:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_030c:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02fc:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02ec:
																											if (2 < b)
																											{
																												while (3 >= b)
																												{
																													while (3 <= b)
																													{
																														while (true)
																														{
																															IL_02a1:
																															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																															while (true)
																															{
																																IL_0282:
																																array[num5 - 1] = 5;
																																num = 152;
																																while (num != 152)
																																{
																																	if (num != 1133)
																																	{
																																		goto IL_0396;
																																	}
																																	switch (num)
																																	{
																																	case 51:
																																		goto IL_0282;
																																	case 39:
																																	case 76:
																																		goto IL_02a1;
																																	case 97:
																																		goto IL_02cc;
																																	case 68:
																																	case 73:
																																		goto IL_02dc;
																																	case 77:
																																		goto IL_02ec;
																																	case 84:
																																		goto IL_02fc;
																																	case 45:
																																		goto IL_030c;
																																	case 115:
																																		goto IL_031c;
																																	case 35:
																																		goto IL_032c;
																																	case 117:
																																		goto IL_0339;
																																	case 99:
																																		goto IL_0349;
																																	case 140:
																																		goto IL_0359;
																																	case 86:
																																	case 121:
																																		goto IL_0372;
																																	case 37:
																																	case 87:
																																		goto IL_037d;
																																	case 27:
																																		goto IL_0388;
																																	case 2:
																																		goto IL_0396;
																																	case 28:
																																		goto IL_03a1;
																																	case 62:
																																		goto IL_03af;
																																	case 69:
																																		goto IL_03c6;
																																	case 38:
																																		goto IL_03d9;
																																	case 59:
																																		goto IL_03e7;
																																	case 88:
																																		goto IL_03f7;
																																	case 26:
																																		goto IL_0402;
																																	case 17:
																																		goto IL_0412;
																																	case 12:
																																		goto IL_0420;
																																	case 21:
																																	case 94:
																																		goto IL_0433;
																																	case 47:
																																	case 105:
																																		goto IL_0485;
																																	case 78:
																																		goto IL_0493;
																																	case 8:
																																	case 53:
																																		goto IL_04a1;
																																	case 104:
																																		goto IL_0503;
																																	case 95:
																																	case 107:
																																		goto IL_0516;
																																	case 83:
																																	case 108:
																																		goto IL_052e;
																																	case 116:
																																		goto IL_053c;
																																	case 101:
																																	case 128:
																																		goto IL_0561;
																																	case 113:
																																		goto IL_05a1;
																																	case 34:
																																		goto IL_05b5;
																																	case 135:
																																		goto IL_05d1;
																																	case 66:
																																		goto IL_05db;
																																	case 41:
																																		goto IL_05e9;
																																	case 141:
																																		goto IL_05fc;
																																	case 112:
																																		goto IL_0610;
																																	case 40:
																																	case 142:
																																		goto IL_0623;
																																	case 90:
																																		goto IL_063f;
																																	case 44:
																																	case 106:
																																		goto IL_064a;
																																	case 3:
																																		goto IL_0658;
																																	case 20:
																																	case 79:
																																		goto IL_0666;
																																	case 30:
																																		goto IL_067f;
																																	case 130:
																																		goto IL_068d;
																																	case 55:
																																		goto IL_069b;
																																	case 0:
																																	case 33:
																																		goto IL_06ae;
																																	case 70:
																																		goto IL_06ee;
																																	case 60:
																																		goto IL_070b;
																																	case 125:
																																	case 127:
																																		goto IL_071e;
																																	case 109:
																																		goto IL_073c;
																																	case 10:
																																		goto IL_074a;
																																	case 63:
																																		goto IL_075d;
																																	case 14:
																																	case 50:
																																		goto IL_0768;
																																	case 31:
																																		goto IL_0776;
																																	case 93:
																																	case 136:
																																		goto IL_0784;
																																	case 100:
																																		goto IL_07b6;
																																	case 61:
																																		goto IL_07c4;
																																	case 19:
																																		goto IL_07d7;
																																	case 9:
																																	case 81:
																																		goto IL_07e2;
																																	case 24:
																																		goto IL_0821;
																																	case 16:
																																		goto IL_0831;
																																	case 6:
																																		goto IL_083c;
																																	case 72:
																																	case 98:
																																		goto IL_0847;
																																	case 131:
																																		goto IL_0855;
																																	case 5:
																																		goto IL_0876;
																																	case 118:
																																		goto IL_0884;
																																	case 11:
																																	case 15:
																																	case 22:
																																	case 29:
																																	case 36:
																																	case 42:
																																	case 43:
																																	case 46:
																																	case 48:
																																	case 49:
																																	case 52:
																																	case 54:
																																	case 65:
																																	case 74:
																																	case 85:
																																	case 89:
																																	case 91:
																																	case 92:
																																	case 96:
																																	case 110:
																																	case 111:
																																	case 126:
																																	case 129:
																																	case 132:
																																	case 134:
																																	case 137:
																																	case 138:
																																		goto end_IL_02cc;
																																	case 7:
																																	case 18:
																																	case 23:
																																	case 25:
																																	case 32:
																																	case 57:
																																	case 58:
																																	case 64:
																																	case 67:
																																	case 71:
																																	case 75:
																																	case 80:
																																	case 102:
																																	case 114:
																																	case 119:
																																	case 139:
																																	case 143:
																																		goto end_IL_026f;
																																	case 13:
																																		goto end_IL_08a7;
																																	case 144:
																																		goto end_IL_08ba;
																																	case 103:
																																		goto end_IL_08c4;
																																	case 1:
																																		goto end_IL_08cf;
																																	case 124:
																																	case 133:
																																		goto end_IL_08e8;
																																	case 145:
																																		goto end_IL_08f8;
																																	case 56:
																																	case 120:
																																		goto end_IL_0908;
																																	case 122:
																																		goto end_IL_0921;
																																	case 123:
																																		goto end_IL_0931;
																																	case 4:
																																	case 82:
																																		goto IL_094c;
																																	}
																																	continue;
																																	end_IL_026f:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_0349;
																														continue;
																														end_IL_02cc:
																														break;
																														IL_02cc:;
																													}
																													break;
																													IL_02dc:;
																												}
																												break;
																											}
																											goto IL_063f;
																											IL_070b:
																											num5--;
																											goto end_IL_0349;
																											IL_063f:
																											if (2 > b)
																											{
																												goto IL_064a;
																											}
																											goto IL_06ae;
																											IL_064a:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_0658;
																											IL_0658:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0666;
																											IL_0666:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_067f;
																											IL_067f:
																											array[num5] = 0;
																											goto IL_068d;
																											IL_068d:
																											num5++;
																											goto IL_069b;
																											IL_069b:
																											ptr2 += 8;
																											goto end_IL_0349;
																											IL_06ae:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_06ee;
																											IL_06ee:
																											array[num5 - 2] = 0;
																											num = 60;
																											goto IL_070b;
																										}
																										break;
																									}
																									goto IL_071e;
																									IL_074a:
																									num5--;
																									goto end_IL_0349;
																									IL_071e:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_073c;
																									IL_073c:
																									ptr2 += 8;
																									goto IL_074a;
																								}
																								break;
																							}
																							goto IL_075d;
																							IL_0884:
																							ptr2 += 8;
																							goto end_IL_0349;
																							IL_075d:
																							if (6 < b)
																							{
																								goto IL_0768;
																							}
																							goto IL_07d7;
																							IL_0768:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0776;
																							IL_0776:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0784;
																							IL_0784:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 100;
																							goto IL_07b6;
																							IL_07b6:
																							ptr2 += 8;
																							goto IL_07c4;
																							IL_07c4:
																							num5--;
																							goto end_IL_0349;
																							IL_07d7:
																							if (6 <= b)
																							{
																								goto IL_07e2;
																							}
																							goto IL_0831;
																							IL_07e2:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0821;
																							IL_0821:
																							num5 -= 3;
																							goto end_IL_0349;
																							IL_0831:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_083c;
																							IL_083c:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0847;
																							IL_0847:
																							array[num5] = 5;
																							goto IL_0855;
																							IL_0855:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							num = 5;
																							goto IL_0876;
																							IL_0876:
																							num5++;
																							goto IL_0884;
																						}
																						break;
																					}
																					goto IL_0516;
																					IL_0516:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0349;
																				}
																				break;
																			}
																			goto IL_037d;
																			IL_0412:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0420;
																			IL_037d:
																			if (12 >= b)
																			{
																				goto IL_0388;
																			}
																			goto IL_03f7;
																			IL_0388:
																			if (12 > b)
																			{
																				goto IL_0396;
																			}
																			goto IL_0561;
																			IL_0396:
																			if (10 >= b)
																			{
																				goto IL_03a1;
																			}
																			goto IL_03d9;
																			IL_03a1:
																			if (10 > b)
																			{
																				goto IL_03af;
																			}
																			goto IL_052e;
																			IL_03af:
																			if (9 < b)
																			{
																				break;
																			}
																			num = 69;
																			goto IL_03c6;
																			IL_0420:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_03c6:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_0349;
																			IL_052e:
																			array[num5] = 0;
																			goto IL_053c;
																			IL_053c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05d1;
																			IL_05d1:
																			array2[num5] = null;
																			goto IL_05db;
																			IL_05db:
																			num5++;
																			goto IL_05e9;
																			IL_05e9:
																			ptr2 += 8;
																			goto end_IL_0349;
																			IL_03d9:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_03e7;
																			IL_03e7:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0433;
																			IL_0433:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 141;
																			goto IL_05fc;
																			IL_05fc:
																			array[num5 - 2] = 0;
																			goto IL_0610;
																			IL_0610:
																			num5--;
																			goto end_IL_0349;
																			IL_0561:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05a1;
																			IL_05a1:
																			array[num5 - 2] = 0;
																			goto IL_05b5;
																			IL_05b5:
																			num5--;
																			num = 18;
																			goto end_IL_0349;
																			IL_03f7:
																			if (14 >= b)
																			{
																				goto IL_0402;
																			}
																			goto IL_0412;
																			IL_0402:
																			if (14 > b)
																			{
																				goto IL_0485;
																			}
																			goto IL_0623;
																			IL_0485:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0493;
																			IL_0493:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_04a1;
																			IL_04a1:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0503;
																			IL_0503:
																			num5 -= 2;
																			goto end_IL_0349;
																			IL_0623:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0349;
																		}
																		break;
																		IL_0339:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0349:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_094c;
												IL_094c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a7:
												break;
											}
											continue;
											end_IL_08ba:
											break;
										}
										continue;
										end_IL_08c4:
										break;
									}
									continue;
									end_IL_08cf:
									break;
								}
								continue;
								end_IL_08e8:
								break;
							}
							continue;
							end_IL_08f8:
							break;
						}
						continue;
						end_IL_0908:
						break;
					}
					continue;
					end_IL_0921:
					break;
				}
				continue;
				end_IL_0931:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 53;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ArgMapperSafeCertContextHandle.SetDiscretionaryAclProtectionEnumAssemblyInstallReferenceFlags);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_028f:
															byte b = *ptr2;
															while (true)
															{
																IL_027f:
																ptr2++;
																while (true)
																{
																	IL_026f:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0252:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0242:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_0232:
																								if (7 <= b)
																								{
																									while (true)
																									{
																										IL_0217:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										while (true)
																										{
																											IL_0207:
																											array[num5] = 0;
																											while (true)
																											{
																												IL_01f7:
																												num5++;
																												while (true)
																												{
																													IL_01de:
																													ptr2 += 8;
																													num = 111;
																													while (num != 111)
																													{
																														if (num != 1092)
																														{
																															goto IL_0652;
																														}
																														switch (num)
																														{
																														case 79:
																															goto IL_01de;
																														case 45:
																															goto IL_01f7;
																														case 101:
																															goto IL_0207;
																														case 29:
																														case 71:
																															goto IL_0217;
																														case 103:
																															goto IL_0232;
																														case 12:
																														case 90:
																															goto IL_0242;
																														case 17:
																															goto IL_0252;
																														case 68:
																															goto IL_025f;
																														case 76:
																															goto IL_026f;
																														case 36:
																															goto IL_027f;
																														case 13:
																														case 55:
																															goto IL_028f;
																														case 34:
																															goto IL_029a;
																														case 27:
																														case 35:
																															goto IL_02ae;
																														case 0:
																														case 62:
																															goto IL_02be;
																														case 38:
																															goto IL_02cc;
																														case 15:
																														case 64:
																															goto IL_02f4;
																														case 51:
																															goto IL_0302;
																														case 23:
																														case 28:
																															goto IL_0319;
																														case 41:
																															goto IL_0342;
																														case 73:
																															goto IL_0350;
																														case 81:
																															goto IL_0363;
																														case 14:
																														case 18:
																															goto IL_036e;
																														case 19:
																															goto IL_03ae;
																														case 47:
																															goto IL_03c2;
																														case 43:
																														case 85:
																															goto IL_03de;
																														case 72:
																															goto IL_03e9;
																														case 59:
																														case 92:
																															goto IL_040a;
																														case 32:
																															goto IL_0415;
																														case 16:
																														case 50:
																															goto IL_0423;
																														case 40:
																															goto IL_0471;
																														case 83:
																															goto IL_0488;
																														case 93:
																															goto IL_0498;
																														case 22:
																															goto IL_04a2;
																														case 24:
																															goto IL_04b0;
																														case 10:
																														case 96:
																															goto IL_04c3;
																														case 99:
																															goto IL_04df;
																														case 49:
																															goto IL_04ed;
																														case 4:
																														case 88:
																															goto IL_04fb;
																														case 87:
																															goto IL_053b;
																														case 21:
																															goto IL_054f;
																														case 104:
																															goto IL_0562;
																														case 58:
																															goto IL_0576;
																														case 7:
																														case 89:
																															goto IL_0592;
																														case 95:
																															goto IL_05a0;
																														case 57:
																														case 63:
																															goto IL_05ab;
																														case 60:
																															goto IL_05f4;
																														case 20:
																															goto IL_0608;
																														case 2:
																														case 3:
																														case 8:
																														case 9:
																														case 26:
																														case 44:
																														case 48:
																														case 65:
																														case 69:
																														case 70:
																														case 75:
																														case 78:
																														case 80:
																														case 82:
																														case 91:
																														case 94:
																															goto end_IL_025f;
																														case 77:
																															goto IL_0644;
																														case 98:
																															goto IL_0652;
																														case 66:
																															goto IL_0660;
																														case 1:
																														case 6:
																														case 30:
																														case 33:
																														case 56:
																														case 61:
																														case 74:
																														case 84:
																														case 97:
																														case 102:
																															goto end_IL_01cb;
																														case 54:
																															goto end_IL_066e;
																														case 31:
																															goto end_IL_0681;
																														case 39:
																															goto end_IL_068b;
																														case 67:
																															goto end_IL_0696;
																														case 5:
																															goto end_IL_06ab;
																														case 11:
																														case 42:
																															goto end_IL_06c0;
																														case 100:
																															goto end_IL_06d0;
																														case 25:
																														case 46:
																															goto end_IL_06e0;
																														case 52:
																															goto end_IL_06f0;
																														case 53:
																															goto end_IL_0700;
																														case 37:
																														case 86:
																															goto IL_071b;
																														}
																														continue;
																														end_IL_01cb:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								num = 7;
																								goto IL_0592;
																								IL_05f4:
																								array[num5 - 2] = 0;
																								goto IL_0608;
																								IL_0608:
																								num5--;
																								num = 30;
																								break;
																								IL_0592:
																								if (6 < b)
																								{
																									goto end_IL_025f;
																								}
																								goto IL_05a0;
																								IL_05a0:
																								if (6 > b)
																								{
																									goto end_IL_025f;
																								}
																								goto IL_05ab;
																								IL_05ab:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 60;
																								goto IL_05f4;
																							}
																							break;
																						}
																						goto IL_040a;
																						IL_0488:
																						if (9 > b)
																						{
																							goto end_IL_025f;
																						}
																						goto IL_04c3;
																						IL_040a:
																						if (8 >= b)
																						{
																							goto IL_0415;
																						}
																						goto IL_0471;
																						IL_0415:
																						if (8 > b)
																						{
																							goto end_IL_025f;
																						}
																						goto IL_0423;
																						IL_0423:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 104;
																						goto IL_0562;
																						IL_0562:
																						array[num5 - 2] = 0;
																						goto IL_0576;
																						IL_0576:
																						num5--;
																						break;
																						IL_0471:
																						if (9 < b)
																						{
																							goto end_IL_025f;
																						}
																						num = 83;
																						goto IL_0488;
																						IL_04c3:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																					}
																					break;
																				}
																				goto IL_029a;
																				IL_02cc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0498;
																				IL_029a:
																				if (5 > b)
																				{
																					num = 27;
																					goto IL_02ae;
																				}
																				goto IL_02be;
																				IL_0498:
																				array2[num5] = null;
																				goto IL_04a2;
																				IL_02ae:
																				if (2 < b)
																				{
																					goto IL_02f4;
																				}
																				goto IL_0363;
																				IL_02f4:
																				if (3 >= b)
																				{
																					goto IL_0302;
																				}
																				goto IL_04df;
																				IL_0302:
																				if (3 > b)
																				{
																					goto end_IL_025f;
																				}
																				num = 28;
																				goto IL_0319;
																				IL_04a2:
																				num5++;
																				goto IL_04b0;
																				IL_0319:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0342;
																				IL_0342:
																				ptr2 += 8;
																				goto IL_0350;
																				IL_0350:
																				num5--;
																				break;
																				IL_04df:
																				if (4 < b)
																				{
																					goto end_IL_025f;
																				}
																				goto IL_04ed;
																				IL_04ed:
																				if (4 > b)
																				{
																					goto end_IL_025f;
																				}
																				goto IL_04fb;
																				IL_04fb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_053b;
																				IL_053b:
																				array[num5 - 2] = 0;
																				goto IL_054f;
																				IL_054f:
																				num5--;
																				break;
																				IL_0363:
																				if (2 <= b)
																				{
																					goto IL_036e;
																				}
																				goto IL_03de;
																				IL_036e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03ae;
																				IL_03ae:
																				array[num5 - 2] = 0;
																				goto IL_03c2;
																				IL_03c2:
																				num5--;
																				num = 102;
																				break;
																				IL_03de:
																				if (1 < b)
																				{
																					num = 3;
																					goto end_IL_025f;
																				}
																				goto IL_03e9;
																				IL_03e9:
																				if (1 > b)
																				{
																				}
																				goto end_IL_025f;
																				IL_04b0:
																				ptr2 += 8;
																				break;
																				IL_02be:
																				array[num5] = 0;
																				goto IL_02cc;
																			}
																			goto end_IL_026f;
																			continue;
																			end_IL_025f:
																			break;
																			IL_025f:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0644;
																	IL_0660:
																	ptr2 += 8;
																	break;
																	IL_0652:
																	num5++;
																	goto IL_0660;
																	IL_0644:
																	array[num5] = 0;
																	goto IL_0652;
																	continue;
																	end_IL_026f:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_071b;
													IL_071b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_066e:
													break;
												}
												continue;
												end_IL_0681:
												break;
											}
											continue;
											end_IL_068b:
											break;
										}
										continue;
										end_IL_0696:
										break;
									}
									continue;
									end_IL_06ab:
									break;
								}
								continue;
								end_IL_06c0:
								break;
							}
							continue;
							end_IL_06d0:
							break;
						}
						continue;
						end_IL_06e0:
						break;
					}
					continue;
					end_IL_06f0:
					break;
				}
				continue;
				end_IL_0700:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2, int int_3)
	{
		int num = 65;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentAppDomainGetApplicationManifestBytes.SectionIDAllowReversePInvokeCallsAttribute);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													IL_04fd:
													if (num4 != 1)
													{
														goto IL_000e;
													}
													num = 96;
													while (true)
													{
														if (num != 96)
														{
															if (num != 1077)
															{
																break;
															}
															switch (num)
															{
															case 24:
															case 84:
																break;
															case 48:
																goto IL_0017;
															case 52:
																goto IL_0025;
															case 0:
																goto IL_0033;
															case 21:
																goto IL_0041;
															case 31:
																goto IL_004f;
															case 27:
																goto IL_005d;
															case 35:
																goto IL_006b;
															case 45:
															case 58:
																goto IL_0079;
															case 2:
																goto IL_00e7;
															case 62:
																goto end_IL_04ea;
															case 46:
																goto IL_0108;
															case 63:
																goto IL_011b;
															case 36:
																goto IL_0129;
															case 38:
															case 68:
																goto IL_0137;
															case 6:
																goto IL_0177;
															case 74:
																goto IL_018b;
															case 26:
															case 80:
																goto IL_01a7;
															case 41:
																goto IL_01d9;
															case 51:
																goto IL_01e7;
															case 67:
															case 81:
																goto IL_01fa;
															case 73:
																goto IL_0205;
															case 39:
																goto IL_0213;
															case 16:
																goto IL_0221;
															case 19:
															case 55:
																goto IL_022f;
															case 33:
															case 79:
																goto IL_0247;
															case 61:
																goto IL_0252;
															case 7:
															case 10:
																goto IL_0260;
															case 59:
																goto IL_026e;
															case 34:
																goto IL_0291;
															case 18:
																goto IL_029b;
															case 72:
																goto IL_02a9;
															case 54:
															case 78:
																goto IL_02bc;
															case 82:
																goto IL_02d0;
															case 1:
															case 32:
																goto IL_02db;
															case 3:
															case 12:
															case 13:
															case 15:
															case 17:
															case 23:
															case 25:
															case 28:
															case 29:
															case 49:
															case 53:
															case 56:
															case 60:
															case 66:
															case 75:
															case 77:
															case 83:
															case 89:
																goto IL_0300;
															case 47:
																goto IL_032c;
															case 87:
																goto IL_033a;
															case 37:
																goto IL_0348;
															default:
																continue;
															case 4:
															case 8:
															case 9:
															case 14:
															case 20:
															case 40:
															case 44:
															case 50:
															case 57:
															case 76:
															case 86:
																goto IL_04fd;
															case 88:
																goto end_IL_04fd;
															case 43:
																goto end_IL_0510;
															case 69:
																goto end_IL_051a;
															case 5:
																goto end_IL_0525;
															case 22:
																goto end_IL_053a;
															case 71:
															case 85:
																goto end_IL_054f;
															case 70:
																goto end_IL_055f;
															case 11:
															case 42:
																goto end_IL_056f;
															case 64:
																goto end_IL_057f;
															case 65:
																goto end_IL_058f;
															case 30:
																goto IL_05aa;
															}
															goto IL_000e;
														}
														goto IL_05aa;
														IL_05aa:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04ea:
														break;
													}
													goto IL_00fa;
													IL_0348:
													ptr2 += 8;
													continue;
													IL_0300:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													num = 47;
													goto IL_032c;
													IL_000e:
													b = *ptr2;
													goto IL_0017;
													IL_0017:
													ptr2++;
													goto IL_0025;
													IL_0025:
													if (b >= 1)
													{
														goto IL_0033;
													}
													goto IL_0300;
													IL_0033:
													if (b <= 8)
													{
														goto IL_0041;
													}
													goto IL_0300;
													IL_0041:
													if (4 >= b)
													{
														goto IL_004f;
													}
													goto IL_01fa;
													IL_004f:
													if (4 > b)
													{
														goto IL_005d;
													}
													num = 26;
													goto IL_01a7;
													IL_005d:
													if (2 >= b)
													{
														goto IL_006b;
													}
													goto IL_011b;
													IL_006b:
													if (2 <= b)
													{
														goto IL_0079;
													}
													goto IL_00fa;
													IL_0079:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_00e7;
													IL_00e7:
													num5 -= 2;
													continue;
													IL_00fa:
													if (1 >= b)
													{
														goto IL_0108;
													}
													goto IL_0300;
													IL_0108:
													if (1 <= b)
													{
													}
													goto IL_0300;
													IL_011b:
													if (3 >= b)
													{
														goto IL_0129;
													}
													goto IL_0300;
													IL_0129:
													if (3 <= b)
													{
														goto IL_0137;
													}
													goto IL_0300;
													IL_0137:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_0177;
													IL_0177:
													array[num5 - 2] = 0;
													goto IL_018b;
													IL_018b:
													num5--;
													continue;
													IL_032c:
													array[num5] = 0;
													goto IL_033a;
													IL_01a7:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													num = 41;
													goto IL_01d9;
													IL_01d9:
													ptr2 += 8;
													goto IL_01e7;
													IL_01e7:
													num5--;
													continue;
													IL_01fa:
													if (6 >= b)
													{
														goto IL_0205;
													}
													goto IL_0247;
													IL_0205:
													if (6 <= b)
													{
														continue;
													}
													goto IL_0213;
													IL_0213:
													if (5 >= b)
													{
														goto IL_0221;
													}
													goto IL_0300;
													IL_0221:
													if (5 <= b)
													{
														goto IL_022f;
													}
													goto IL_0300;
													IL_022f:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													continue;
													IL_0247:
													if (7 >= b)
													{
														goto IL_0252;
													}
													goto IL_02bc;
													IL_0252:
													if (7 <= b)
													{
														goto IL_0260;
													}
													goto IL_0300;
													IL_0260:
													array[num5] = 0;
													goto IL_026e;
													IL_026e:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0291;
													IL_0291:
													array2[num5] = null;
													goto IL_029b;
													IL_029b:
													num5++;
													goto IL_02a9;
													IL_02a9:
													ptr2 += 8;
													continue;
													IL_02bc:
													if (8 >= b)
													{
														num = 82;
														goto IL_02d0;
													}
													goto IL_0300;
													IL_033a:
													num5++;
													goto IL_0348;
													IL_02d0:
													if (8 <= b)
													{
														goto IL_02db;
													}
													num = 3;
													goto IL_0300;
													IL_02db:
													byte* num6 = ptr2;
													num4 = 1;
													ptr2 = num6 + -200;
													continue;
													end_IL_04fd:
													break;
												}
												continue;
												end_IL_0510:
												break;
											}
											continue;
											end_IL_051a:
											break;
										}
										continue;
										end_IL_0525:
										break;
									}
									continue;
									end_IL_053a:
									break;
								}
								continue;
								end_IL_054f:
								break;
							}
							continue;
							end_IL_055f:
							break;
						}
						continue;
						end_IL_056f:
						break;
					}
					continue;
					end_IL_057f:
					break;
				}
				continue;
				end_IL_058f:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 46;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DnsNameBreak.AllClipboardTriggerFailure);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 76;
																while (true)
																{
																	IL_0250:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0233:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0223:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0213:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_0203:
																										if (3 >= b)
																										{
																											while (3 <= b)
																											{
																												num = 112;
																												while (true)
																												{
																													if (num != 112)
																													{
																														if (num != 1093)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 91:
																															goto IL_01f0;
																														case 61:
																														case 99:
																															goto IL_0203;
																														case 77:
																														case 102:
																															goto IL_0213;
																														case 8:
																															goto IL_0223;
																														case 55:
																															goto IL_0233;
																														case 17:
																															goto IL_0240;
																														case 76:
																															goto IL_0250;
																														case 62:
																															goto end_IL_0250;
																														case 25:
																														case 101:
																															goto end_IL_0260;
																														case 41:
																															goto IL_0284;
																														case 42:
																															goto IL_0297;
																														case 20:
																															goto IL_02b0;
																														case 26:
																														case 72:
																															goto IL_02be;
																														case 60:
																															goto IL_02fe;
																														case 30:
																															goto IL_0312;
																														case 78:
																															goto IL_0325;
																														case 3:
																														case 59:
																															goto IL_0330;
																														case 18:
																															goto IL_033e;
																														case 9:
																														case 36:
																															goto IL_034c;
																														case 2:
																															goto IL_0368;
																														case 47:
																														case 53:
																															goto IL_0381;
																														case 24:
																															goto IL_03c1;
																														case 66:
																															goto IL_03d5;
																														case 88:
																															goto IL_03e8;
																														case 48:
																														case 75:
																															goto IL_03f3;
																														case 57:
																															goto IL_040c;
																														case 85:
																															goto end_IL_01dd;
																														case 14:
																															goto IL_0428;
																														case 33:
																														case 103:
																															goto IL_043b;
																														case 79:
																															goto IL_0449;
																														case 6:
																														case 82:
																															goto IL_0457;
																														case 12:
																															goto IL_0497;
																														case 52:
																															goto IL_04ab;
																														case 39:
																															goto IL_04be;
																														case 92:
																															goto IL_04e7;
																														case 49:
																															goto IL_04f5;
																														case 81:
																															goto IL_0508;
																														case 40:
																														case 83:
																															goto IL_0513;
																														case 90:
																															goto IL_0553;
																														case 22:
																															goto IL_0567;
																														case 7:
																															goto IL_057a;
																														case 95:
																															goto IL_0585;
																														case 1:
																														case 5:
																														case 10:
																														case 11:
																														case 23:
																														case 35:
																														case 37:
																														case 50:
																														case 56:
																														case 58:
																														case 63:
																														case 64:
																														case 65:
																														case 68:
																														case 80:
																														case 87:
																														case 89:
																														case 96:
																														case 98:
																															goto end_IL_01f0;
																														case 74:
																															goto IL_05b3;
																														case 32:
																															goto IL_05c1;
																														case 13:
																															goto IL_05cf;
																														case 15:
																														case 29:
																															goto IL_05df;
																														case 105:
																															goto IL_05ed;
																														case 70:
																															goto IL_0610;
																														case 71:
																															goto IL_061a;
																														case 86:
																															goto IL_0628;
																														case 0:
																														case 4:
																														case 19:
																														case 21:
																														case 28:
																														case 31:
																														case 43:
																														case 44:
																														case 54:
																														case 69:
																														case 94:
																															goto end_IL_0279;
																														case 84:
																															goto end_IL_0636;
																														case 97:
																															goto end_IL_0649;
																														case 73:
																															goto end_IL_0653;
																														case 104:
																															goto end_IL_065e;
																														case 34:
																															goto end_IL_0673;
																														case 16:
																														case 93:
																															goto end_IL_0688;
																														case 51:
																															goto end_IL_0698;
																														case 67:
																														case 100:
																															goto end_IL_06a8;
																														case 45:
																															goto end_IL_06b8;
																														case 46:
																															goto end_IL_06c8;
																														case 27:
																														case 38:
																															goto IL_06e3;
																														}
																														continue;
																													}
																													goto IL_04be;
																													IL_04e7:
																													ptr2 += 8;
																													goto IL_04f5;
																													IL_04f5:
																													num5--;
																													goto end_IL_0279;
																													IL_04be:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_04e7;
																													continue;
																													end_IL_01dd:
																													break;
																												}
																												goto IL_041a;
																												continue;
																												end_IL_01f0:
																												break;
																												IL_01f0:;
																											}
																											break;
																										}
																										goto IL_0297;
																										IL_02fe:
																										array[num5 - 2] = 0;
																										goto IL_0312;
																										IL_0297:
																										if (4 < b)
																										{
																											num = 5;
																											break;
																										}
																										goto IL_02b0;
																										IL_0312:
																										num5--;
																										goto end_IL_0279;
																										IL_02b0:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_02be;
																										IL_02be:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_02fe;
																									}
																									break;
																								}
																								goto IL_0508;
																								IL_0585:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0508:
																								if (2 <= b)
																								{
																									goto IL_0513;
																								}
																								goto IL_057a;
																								IL_0513:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0553;
																								IL_0553:
																								array[num5 - 2] = 0;
																								goto IL_0567;
																								IL_0567:
																								num5--;
																								goto end_IL_0279;
																								IL_057a:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0585;
																							}
																							break;
																						}
																						goto IL_05df;
																						IL_0628:
																						ptr2 += 8;
																						goto end_IL_0279;
																						IL_05df:
																						array[num5] = 0;
																						goto IL_05ed;
																						IL_05ed:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0610;
																						IL_0610:
																						array2[num5] = null;
																						goto IL_061a;
																						IL_061a:
																						num5++;
																						goto IL_0628;
																					}
																					break;
																				}
																				goto IL_0284;
																				IL_03c1:
																				array[num5 - 2] = 0;
																				goto IL_03d5;
																				IL_0284:
																				if (7 < b)
																				{
																					goto IL_0325;
																				}
																				goto IL_03e8;
																				IL_03e8:
																				if (7 <= b)
																				{
																					goto IL_03f3;
																				}
																				goto IL_043b;
																				IL_03f3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_040c;
																				IL_040c:
																				array[num5] = 0;
																				goto IL_041a;
																				IL_041a:
																				num5++;
																				goto IL_0428;
																				IL_0428:
																				ptr2 += 8;
																				goto end_IL_0279;
																				IL_043b:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0449;
																				IL_0449:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0457;
																				IL_0457:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0497;
																				IL_0497:
																				array[num5 - 2] = 0;
																				goto IL_04ab;
																				IL_04ab:
																				num5--;
																				goto end_IL_0279;
																				IL_0325:
																				if (8 < b)
																				{
																					goto IL_0330;
																				}
																				goto IL_0368;
																				IL_0330:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_033e;
																				IL_033e:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_034c;
																				IL_034c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0279;
																				IL_0368:
																				if (8 > b)
																				{
																					num = 56;
																					break;
																				}
																				goto IL_0381;
																				IL_03d5:
																				num5--;
																				goto end_IL_0279;
																				IL_0381:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03c1;
																			}
																			break;
																			IL_0240:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05b3;
																	IL_05cf:
																	ptr2 += 8;
																	goto end_IL_0279;
																	IL_05c1:
																	num5++;
																	goto IL_05cf;
																	IL_05b3:
																	array[num5] = 0;
																	goto IL_05c1;
																	continue;
																	end_IL_0250:
																	break;
																}
																continue;
																end_IL_0260:
																break;
															}
															continue;
															end_IL_0279:
															break;
														}
														continue;
													}
													goto IL_06e3;
													IL_06e3:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0636:
													break;
												}
												continue;
												end_IL_0649:
												break;
											}
											continue;
											end_IL_0653:
											break;
										}
										continue;
										end_IL_065e:
										break;
									}
									continue;
									end_IL_0673:
									break;
								}
								continue;
								end_IL_0688:
								break;
							}
							continue;
							end_IL_0698:
							break;
						}
						continue;
						end_IL_06a8:
						break;
					}
					continue;
					end_IL_06b8:
					break;
				}
				continue;
				end_IL_06c8:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 114;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NullTextWriterINVOKEPROPERTYPUTREF.HexBinarygetDeclaredConstructors);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0318:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02fb:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02eb:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02db:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02cb:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_02bb:
																											if (6 > b)
																											{
																												while (5 >= b)
																												{
																													while (true)
																													{
																														IL_0298:
																														if (5 > b)
																														{
																															num = 154;
																															while (num != 154 && num == 1135)
																															{
																																switch (num)
																																{
																																case 88:
																																	goto IL_0298;
																																case 57:
																																case 89:
																																	goto IL_02ab;
																																case 64:
																																	goto IL_02bb;
																																case 107:
																																	goto IL_02cb;
																																case 18:
																																case 27:
																																	goto IL_02db;
																																case 77:
																																	goto IL_02eb;
																																case 55:
																																	goto IL_02fb;
																																case 41:
																																	goto IL_0308;
																																case 94:
																																	goto IL_0318;
																																case 62:
																																	goto end_IL_0318;
																																case 112:
																																case 140:
																																	goto end_IL_0328;
																																case 9:
																																case 119:
																																	goto IL_0343;
																																case 53:
																																case 84:
																																	goto IL_034e;
																																case 105:
																																	goto IL_035c;
																																case 0:
																																case 6:
																																	goto IL_036a;
																																case 58:
																																	goto IL_0378;
																																case 5:
																																	goto IL_038b;
																																case 38:
																																	goto IL_0396;
																																case 31:
																																case 35:
																																	goto IL_03a9;
																																case 93:
																																	goto IL_03f2;
																																case 118:
																																	goto IL_0406;
																																case 48:
																																case 122:
																																	goto IL_0419;
																																case 39:
																																	goto IL_047b;
																																case 126:
																																	goto IL_048e;
																																case 130:
																																	goto IL_04aa;
																																case 54:
																																case 87:
																																	goto IL_04b8;
																																case 104:
																																	goto IL_04c6;
																																case 61:
																																	goto IL_04e9;
																																case 69:
																																	goto IL_04f3;
																																case 90:
																																	goto IL_0501;
																																case 134:
																																	goto IL_0514;
																																case 1:
																																	goto IL_0522;
																																case 23:
																																case 101:
																																	goto IL_0530;
																																case 12:
																																	goto IL_0574;
																																case 76:
																																	goto IL_0588;
																																case 71:
																																case 136:
																																	goto IL_059b;
																																case 138:
																																	goto IL_05b7;
																																case 50:
																																case 144:
																																	goto IL_05ca;
																																case 129:
																																	goto IL_05d8;
																																case 146:
																																	goto IL_05eb;
																																case 15:
																																case 19:
																																	goto IL_05f9;
																																case 37:
																																case 108:
																																	goto IL_0604;
																																case 85:
																																	goto IL_0612;
																																case 40:
																																case 47:
																																	goto IL_0620;
																																case 137:
																																	goto IL_0649;
																																case 63:
																																	goto IL_0662;
																																case 74:
																																case 139:
																																	goto IL_066d;
																																case 3:
																																	goto IL_06ad;
																																case 45:
																																	goto IL_06c1;
																																case 92:
																																	goto IL_06dd;
																																case 145:
																																	goto IL_06eb;
																																case 25:
																																case 110:
																																	goto IL_06f9;
																																case 95:
																																	goto IL_0712;
																																case 123:
																																	goto IL_0720;
																																case 42:
																																	goto IL_072e;
																																case 98:
																																case 135:
																																	goto IL_0741;
																																case 143:
																																	goto IL_075f;
																																case 67:
																																	goto IL_076d;
																																case 34:
																																case 60:
																																	goto IL_0780;
																																case 75:
																																	goto IL_078e;
																																case 124:
																																	goto IL_07a6;
																																case 86:
																																	goto IL_07b4;
																																case 59:
																																case 68:
																																	goto IL_07c7;
																																case 26:
																																	goto IL_0806;
																																case 83:
																																case 120:
																																	goto IL_0819;
																																case 52:
																																	goto IL_0824;
																																case 79:
																																case 111:
																																	goto IL_082f;
																																case 17:
																																	goto IL_0858;
																																case 103:
																																	goto IL_0866;
																																case 4:
																																case 121:
																																	goto IL_0876;
																																case 13:
																																case 14:
																																case 24:
																																case 28:
																																case 30:
																																case 33:
																																case 43:
																																case 49:
																																case 51:
																																case 66:
																																case 70:
																																case 78:
																																case 82:
																																case 96:
																																case 97:
																																case 100:
																																case 106:
																																case 116:
																																case 131:
																																case 132:
																																case 133:
																																case 141:
																																case 142:
																																case 147:
																																	goto end_IL_0285;
																																case 7:
																																case 8:
																																case 10:
																																case 11:
																																case 16:
																																case 20:
																																case 21:
																																case 32:
																																case 36:
																																case 46:
																																case 73:
																																case 80:
																																case 81:
																																case 99:
																																case 102:
																																case 117:
																																case 127:
																																case 128:
																																	goto end_IL_0338;
																																case 56:
																																	goto end_IL_089e;
																																case 44:
																																	goto end_IL_08b1;
																																case 125:
																																	goto end_IL_08bb;
																																case 2:
																																	goto end_IL_08c6;
																																case 22:
																																case 115:
																																	goto end_IL_08d6;
																																case 109:
																																	goto end_IL_08e6;
																																case 65:
																																case 91:
																																	goto end_IL_08f6;
																																case 113:
																																	goto end_IL_0906;
																																case 114:
																																	goto end_IL_0916;
																																case 29:
																																case 72:
																																	goto IL_0931;
																																}
																																continue;
																																end_IL_0285:
																																break;
																															}
																															break;
																														}
																														goto IL_0780;
																														IL_07a6:
																														num5++;
																														goto IL_07b4;
																														IL_07b4:
																														ptr2 += 8;
																														goto end_IL_0338;
																														IL_0780:
																														array[num5] = 5;
																														goto IL_078e;
																														IL_078e:
																														array2[num5] = array5[*(int*)(ptr2 + num3)];
																														goto IL_07a6;
																													}
																													break;
																													IL_02ab:;
																												}
																												break;
																											}
																											goto IL_07c7;
																											IL_0806:
																											num5 -= 3;
																											goto end_IL_0338;
																											IL_07c7:
																											((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0806;
																										}
																										break;
																									}
																									goto IL_0819;
																									IL_0866:
																									num5--;
																									goto end_IL_0338;
																									IL_0819:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_0824;
																									IL_0824:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_082f;
																									IL_082f:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0858;
																									IL_0858:
																									ptr2 += 8;
																									goto IL_0866;
																								}
																								break;
																							}
																							goto IL_05eb;
																							IL_076d:
																							num5--;
																							goto end_IL_0338;
																							IL_05eb:
																							if (4 > b)
																							{
																								goto IL_05f9;
																							}
																							goto IL_0741;
																							IL_05f9:
																							if (2 < b)
																							{
																								goto IL_0604;
																							}
																							goto IL_0662;
																							IL_0604:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0612;
																							IL_0612:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0620;
																							IL_0620:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_0649;
																							IL_0649:
																							array[num5 - 1] = 5;
																							goto end_IL_0338;
																							IL_0662:
																							if (2 <= b)
																							{
																								goto IL_066d;
																							}
																							goto IL_06dd;
																							IL_066d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_06ad;
																							IL_06ad:
																							array[num5 - 2] = 0;
																							goto IL_06c1;
																							IL_06c1:
																							num5--;
																							num = 10;
																							goto end_IL_0338;
																							IL_06dd:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_06eb;
																							IL_06eb:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_06f9;
																							IL_06f9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0712;
																							IL_0712:
																							array[num5] = 0;
																							goto IL_0720;
																							IL_0720:
																							num5++;
																							goto IL_072e;
																							IL_072e:
																							ptr2 += 8;
																							goto end_IL_0338;
																							IL_0741:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_075f;
																							IL_075f:
																							ptr2 += 8;
																							goto IL_076d;
																						}
																						break;
																					}
																					goto IL_0876;
																					IL_0876:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0338;
																				}
																				break;
																			}
																			goto IL_0343;
																			IL_03f2:
																			array[num5 - 2] = 0;
																			goto IL_0406;
																			IL_0343:
																			if (12 < b)
																			{
																				goto IL_034e;
																			}
																			goto IL_038b;
																			IL_034e:
																			if (14 >= b)
																			{
																				goto IL_035c;
																			}
																			goto IL_048e;
																			IL_035c:
																			if (14 > b)
																			{
																				goto IL_036a;
																			}
																			goto IL_059b;
																			IL_036a:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0378;
																			IL_0378:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0419;
																			IL_0419:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_047b;
																			IL_047b:
																			num5 -= 2;
																			goto end_IL_0338;
																			IL_059b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0338;
																			IL_048e:
																			if (15 < b)
																			{
																				break;
																			}
																			num = 138;
																			goto IL_05b7;
																			IL_0406:
																			num5--;
																			goto end_IL_0338;
																			IL_05b7:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_038b:
																			if (12 > b)
																			{
																				goto IL_0396;
																			}
																			goto IL_03a9;
																			IL_0396:
																			if (10 >= b)
																			{
																				goto IL_04aa;
																			}
																			goto IL_0514;
																			IL_04aa:
																			if (10 <= b)
																			{
																				goto IL_04b8;
																			}
																			goto IL_05ca;
																			IL_04b8:
																			array[num5] = 0;
																			goto IL_04c6;
																			IL_04c6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04e9;
																			IL_04e9:
																			array2[num5] = null;
																			goto IL_04f3;
																			IL_04f3:
																			num5++;
																			goto IL_0501;
																			IL_0501:
																			ptr2 += 8;
																			goto end_IL_0338;
																			IL_05ca:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_05d8;
																			IL_05d8:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_0338;
																			IL_0514:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0522;
																			IL_0522:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0530;
																			IL_0530:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0574;
																			IL_0574:
																			array[num5 - 2] = 0;
																			goto IL_0588;
																			IL_0588:
																			num5--;
																			goto end_IL_0338;
																			IL_03a9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 93;
																			goto IL_03f2;
																		}
																		break;
																		IL_0308:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0338;
																continue;
																end_IL_0318:
																break;
															}
															continue;
															end_IL_0328:
															break;
														}
														continue;
														end_IL_0338:
														break;
													}
													continue;
												}
												goto IL_0931;
												IL_0931:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_089e:
												break;
											}
											continue;
											end_IL_08b1:
											break;
										}
										continue;
										end_IL_08bb:
										break;
									}
									continue;
									end_IL_08c6:
									break;
								}
								continue;
								end_IL_08d6:
								break;
							}
							continue;
							end_IL_08e6:
							break;
						}
						continue;
						end_IL_08f6:
						break;
					}
					continue;
					end_IL_0906:
					break;
				}
				continue;
				end_IL_0916:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FileSystemInfoAllowDecimalPoint.RemoveAccessSpecificBuiltinNetworkConfigurationOperatorsSid);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0318:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02fb:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_02eb:
																					if (10 >= b)
																					{
																						while (true)
																						{
																							IL_02db:
																							if (10 > b)
																							{
																								while (true)
																								{
																									IL_02cb:
																									if (8 >= b)
																									{
																										while (8 <= b)
																										{
																											while (true)
																											{
																												IL_024e:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												num = 139;
																												while (true)
																												{
																													if (num != 139)
																													{
																														if (num != 1120)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 114:
																														case 120:
																															goto IL_024e;
																														case 54:
																															goto IL_02bb;
																														case 4:
																														case 105:
																															goto IL_02cb;
																														case 43:
																															goto IL_02db;
																														case 40:
																															goto IL_02eb;
																														case 119:
																															goto IL_02fb;
																														case 103:
																															goto IL_0308;
																														case 86:
																															goto IL_0318;
																														case 71:
																															goto end_IL_0318;
																														case 89:
																														case 91:
																															goto end_IL_0328;
																														case 42:
																															goto IL_0343;
																														case 5:
																														case 50:
																															goto IL_0351;
																														case 62:
																															goto IL_037f;
																														case 59:
																															goto IL_038d;
																														case 68:
																															goto IL_0398;
																														case 85:
																															goto IL_03a6;
																														case 112:
																															goto IL_03b6;
																														case 20:
																															goto IL_03c4;
																														case 97:
																															goto IL_03d2;
																														case 27:
																														case 115:
																															goto IL_03e5;
																														case 76:
																														case 117:
																															goto IL_0401;
																														case 67:
																														case 125:
																															goto IL_0414;
																														case 88:
																															goto IL_0422;
																														case 81:
																														case 84:
																															goto IL_0430;
																														case 49:
																															goto IL_043b;
																														case 80:
																															goto IL_0449;
																														case 61:
																														case 100:
																															goto IL_0457;
																														case 0:
																															goto IL_0480;
																														case 16:
																															goto IL_048e;
																														case 37:
																															goto IL_04a1;
																														case 25:
																														case 122:
																															goto IL_04af;
																														case 1:
																															goto IL_04c8;
																														case 55:
																															goto IL_04d6;
																														case 107:
																															goto IL_04e4;
																														case 3:
																														case 78:
																															goto IL_04f7;
																														case 111:
																															goto IL_050f;
																														case 75:
																														case 79:
																															goto IL_051d;
																														case 110:
																															goto IL_052b;
																														case 10:
																														case 44:
																															goto IL_0539;
																														case 36:
																															goto IL_0579;
																														case 12:
																															goto IL_058d;
																														case 70:
																															goto IL_05a0;
																														case 23:
																														case 127:
																															goto IL_05ad;
																														case 41:
																															goto IL_05bb;
																														case 92:
																														case 130:
																															goto IL_05ce;
																														case 31:
																															goto IL_05dc;
																														case 22:
																															goto IL_05ff;
																														case 83:
																															goto IL_0609;
																														case 116:
																															goto IL_0617;
																														case 124:
																														case 131:
																															goto IL_062a;
																														case 17:
																															goto IL_0638;
																														case 39:
																															goto IL_065e;
																														case 108:
																															goto IL_0669;
																														case 29:
																														case 48:
																															goto IL_0677;
																														case 18:
																															goto IL_06b7;
																														case 104:
																															goto IL_06cb;
																														case 58:
																														case 99:
																															goto IL_06ec;
																														case 30:
																															goto IL_0700;
																														case 94:
																															goto IL_0754;
																														case 93:
																															goto IL_0762;
																														case 6:
																														case 8:
																														case 9:
																														case 14:
																														case 15:
																														case 21:
																														case 26:
																														case 34:
																														case 35:
																														case 38:
																														case 46:
																														case 47:
																														case 51:
																														case 52:
																														case 63:
																														case 66:
																														case 69:
																														case 72:
																														case 73:
																														case 82:
																														case 90:
																														case 95:
																														case 102:
																														case 109:
																														case 113:
																														case 121:
																															goto end_IL_023b;
																														case 7:
																														case 11:
																														case 13:
																														case 24:
																														case 28:
																														case 45:
																														case 60:
																														case 64:
																														case 74:
																														case 77:
																														case 98:
																														case 101:
																														case 106:
																														case 118:
																														case 126:
																														case 132:
																															goto end_IL_0338;
																														case 57:
																															goto end_IL_0785;
																														case 65:
																															goto end_IL_0798;
																														case 129:
																															goto end_IL_07a2;
																														case 56:
																															goto end_IL_07ad;
																														case 2:
																														case 87:
																															goto end_IL_07c2;
																														case 96:
																															goto end_IL_07d2;
																														case 19:
																														case 123:
																															goto end_IL_07e2;
																														case 32:
																															goto end_IL_07f2;
																														case 33:
																															goto end_IL_0802;
																														case 53:
																														case 128:
																															goto IL_081d;
																														}
																														continue;
																													}
																													num5 -= 2;
																													goto end_IL_0338;
																													continue;
																													end_IL_023b:
																													break;
																												}
																												break;
																											}
																											break;
																											IL_02bb:;
																										}
																										break;
																									}
																									goto IL_065e;
																									IL_06cb:
																									num5--;
																									goto end_IL_0338;
																									IL_065e:
																									if (9 < b)
																									{
																										num = 35;
																										break;
																									}
																									goto IL_0669;
																									IL_0669:
																									if (9 > b)
																									{
																										break;
																									}
																									goto IL_0677;
																									IL_0677:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_06b7;
																									IL_06b7:
																									array[num5 - 2] = 0;
																									goto IL_06cb;
																								}
																								break;
																							}
																							goto IL_06ec;
																							IL_0762:
																							ptr2 += 8;
																							goto end_IL_0338;
																							IL_06ec:
																							array[num5 - 2] = 0;
																							goto IL_0700;
																							IL_0700:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)IMPALWAYSFLOWSidNameUse[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_0754;
																							IL_0754:
																							num5--;
																							goto IL_0762;
																						}
																						break;
																					}
																					goto IL_037f;
																					IL_05bb:
																					if (13 <= b)
																					{
																					}
																					break;
																					IL_037f:
																					if (12 >= b)
																					{
																						goto IL_038d;
																					}
																					goto IL_05ad;
																					IL_038d:
																					if (12 > b)
																					{
																						goto IL_0398;
																					}
																					goto IL_03e5;
																					IL_0398:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_03a6;
																					IL_03a6:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0401;
																					IL_0401:
																					num5--;
																					goto end_IL_0338;
																					IL_03e5:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0338;
																					IL_05ad:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_05bb;
																				}
																				break;
																			}
																			goto IL_0343;
																			IL_0617:
																			ptr2 += 8;
																			goto end_IL_0338;
																			IL_0343:
																			if (7 <= b)
																			{
																				goto IL_0351;
																			}
																			goto IL_0414;
																			IL_0351:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 112;
																			goto IL_03b6;
																			IL_03b6:
																			array[num5] = 0;
																			goto IL_03c4;
																			IL_03c4:
																			num5++;
																			goto IL_03d2;
																			IL_03d2:
																			ptr2 += 8;
																			goto end_IL_0338;
																			IL_0414:
																			if (3 >= b)
																			{
																				goto IL_0422;
																			}
																			goto IL_050f;
																			IL_0422:
																			if (3 > b)
																			{
																				goto IL_0430;
																			}
																			goto IL_04f7;
																			IL_0430:
																			if (1 < b)
																			{
																				goto IL_043b;
																			}
																			goto IL_04a1;
																			IL_043b:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0449;
																			IL_0449:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0457;
																			IL_0457:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0480;
																			IL_0480:
																			ptr2 += 8;
																			goto IL_048e;
																			IL_048e:
																			num5--;
																			goto end_IL_0338;
																			IL_04a1:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04af;
																			IL_04af:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04c8;
																			IL_04c8:
																			array[num5] = 0;
																			goto IL_04d6;
																			IL_04d6:
																			num5++;
																			goto IL_04e4;
																			IL_04e4:
																			ptr2 += 8;
																			goto end_IL_0338;
																			IL_04f7:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0338;
																			IL_050f:
																			if (5 < b)
																			{
																				goto IL_051d;
																			}
																			goto IL_05a0;
																			IL_051d:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_052b;
																			IL_052b:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0539;
																			IL_0539:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0579;
																			IL_0579:
																			array[num5 - 2] = 0;
																			goto IL_058d;
																			IL_058d:
																			num5--;
																			goto end_IL_0338;
																			IL_05a0:
																			if (5 <= b)
																			{
																				goto IL_05ce;
																			}
																			goto IL_062a;
																			IL_062a:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0638;
																			IL_0638:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0338;
																			IL_05ce:
																			array[num5] = 0;
																			goto IL_05dc;
																			IL_05dc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05ff;
																			IL_05ff:
																			array2[num5] = null;
																			goto IL_0609;
																			IL_0609:
																			num5++;
																			goto IL_0617;
																		}
																		break;
																		IL_0308:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0338;
																continue;
																end_IL_0318:
																break;
															}
															continue;
															end_IL_0328:
															break;
														}
														continue;
														end_IL_0338:
														break;
													}
													continue;
												}
												goto IL_081d;
												IL_081d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0785:
												break;
											}
											continue;
											end_IL_0798:
											break;
										}
										continue;
										end_IL_07a2:
										break;
									}
									continue;
									end_IL_07ad:
									break;
								}
								continue;
								end_IL_07c2:
								break;
							}
							continue;
							end_IL_07d2:
							break;
						}
						continue;
						end_IL_07e2:
						break;
					}
					continue;
					end_IL_07f2:
					break;
				}
				continue;
				end_IL_0802:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 103;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setApplicationIdentityDisposition.CustomAttributesaddCancelKeyPress);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0221:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 < b)
																				{
																					while (true)
																					{
																						if (7 < b)
																						{
																							num = 113;
																							while (true)
																							{
																								if (num == 113)
																								{
																									goto IL_0539;
																								}
																								if (num != 1094)
																								{
																									goto IL_0592;
																								}
																								switch (num)
																								{
																								case 50:
																									goto end_IL_01e1;
																								case 99:
																									goto end_IL_01f4;
																								case 22:
																									goto end_IL_0204;
																								case 98:
																									goto IL_0221;
																								case 1:
																									goto end_IL_0221;
																								case 8:
																								case 36:
																									goto end_IL_0231;
																								case 49:
																									goto IL_024c;
																								case 27:
																								case 43:
																									goto IL_0257;
																								case 30:
																								case 66:
																									goto IL_0272;
																								case 70:
																									goto IL_0285;
																								case 76:
																									goto IL_0295;
																								case 67:
																								case 81:
																									goto IL_02ae;
																								case 37:
																									goto IL_02bc;
																								case 24:
																									goto IL_02df;
																								case 29:
																									goto IL_02e9;
																								case 3:
																									goto IL_02f7;
																								case 89:
																									goto IL_030a;
																								case 13:
																									goto IL_0318;
																								case 94:
																									goto IL_032b;
																								case 4:
																								case 62:
																									goto IL_0339;
																								case 87:
																									goto IL_0382;
																								case 5:
																									goto IL_0396;
																								case 16:
																								case 106:
																									goto IL_03a9;
																								case 44:
																									goto IL_03b7;
																								case 35:
																								case 47:
																									goto IL_03c2;
																								case 14:
																									goto IL_03d0;
																								case 80:
																								case 86:
																									goto IL_03ec;
																								case 17:
																									goto IL_042c;
																								case 21:
																									goto IL_0440;
																								case 65:
																									goto IL_0453;
																								case 34:
																									goto IL_045e;
																								case 41:
																								case 104:
																									goto IL_046c;
																								case 64:
																									goto IL_0495;
																								case 101:
																									goto IL_04a3;
																								case 52:
																									goto IL_04b6;
																								case 55:
																									goto IL_04c4;
																								case 48:
																								case 96:
																									goto IL_04d2;
																								case 28:
																									goto IL_0512;
																								case 26:
																									goto IL_0526;
																								case 58:
																									goto IL_0539;
																								case 42:
																								case 74:
																									goto IL_0544;
																								case 63:
																									goto IL_0552;
																								case 15:
																								case 51:
																									goto IL_0560;
																								case 88:
																									goto IL_057c;
																								case 18:
																								case 91:
																									goto IL_0592;
																								case 84:
																									goto IL_05d2;
																								case 38:
																									goto IL_05e6;
																								case 0:
																								case 9:
																								case 19:
																								case 20:
																								case 31:
																								case 32:
																								case 56:
																								case 61:
																								case 68:
																								case 69:
																								case 71:
																								case 73:
																								case 77:
																								case 78:
																								case 79:
																								case 85:
																								case 93:
																								case 95:
																								case 97:
																									goto end_IL_0211;
																								case 72:
																									goto IL_0622;
																								case 100:
																									goto IL_0630;
																								case 53:
																									goto IL_063e;
																								case 6:
																								case 7:
																								case 11:
																								case 12:
																								case 40:
																								case 54:
																								case 59:
																								case 83:
																								case 90:
																								case 92:
																								case 105:
																									goto end_IL_0241;
																								case 46:
																									goto end_IL_064c;
																								case 2:
																									goto end_IL_065f;
																								case 82:
																									goto end_IL_0669;
																								case 33:
																									goto end_IL_0674;
																								case 10:
																									goto end_IL_0689;
																								case 25:
																								case 57:
																									goto end_IL_069e;
																								case 39:
																									goto end_IL_06ae;
																								case 23:
																								case 45:
																									goto end_IL_06be;
																								case 102:
																									goto end_IL_06ce;
																								case 103:
																									goto end_IL_06de;
																								case 60:
																								case 75:
																									goto IL_0702;
																								}
																								continue;
																								IL_0592:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05d2;
																								IL_05d2:
																								array[num5 - 2] = 0;
																								goto IL_05e6;
																								IL_0539:
																								if (8 < b)
																								{
																									goto IL_0544;
																								}
																								goto IL_057c;
																								IL_0544:
																								if (9 < b)
																								{
																									goto end_IL_0211;
																								}
																								goto IL_0552;
																								IL_0552:
																								if (9 > b)
																								{
																									goto end_IL_0211;
																								}
																								goto IL_0560;
																								IL_0560:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_0241;
																								IL_057c:
																								if (8 > b)
																								{
																									num = 79;
																									goto end_IL_0211;
																								}
																								goto IL_0592;
																								IL_05e6:
																								num5--;
																								num = 105;
																								goto end_IL_0241;
																								continue;
																								end_IL_01e1:
																								break;
																							}
																							continue;
																						}
																						goto IL_024c;
																						IL_0382:
																						array[num5 - 2] = 0;
																						goto IL_0396;
																						IL_0396:
																						num5--;
																						goto end_IL_0241;
																						IL_024c:
																						if (7 <= b)
																						{
																							goto IL_0257;
																						}
																						goto IL_0272;
																						IL_0257:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0295;
																						IL_0295:
																						array[num5] = 0;
																						num = 89;
																						goto IL_030a;
																						IL_030a:
																						num5++;
																						goto IL_0318;
																						IL_0318:
																						ptr2 += 8;
																						goto end_IL_0241;
																						IL_0272:
																						if (6 < b)
																						{
																							goto end_IL_0211;
																						}
																						goto IL_032b;
																						IL_032b:
																						if (6 > b)
																						{
																							goto end_IL_0211;
																						}
																						goto IL_0339;
																						IL_0339:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 87;
																						goto IL_0382;
																						continue;
																						end_IL_01f4:
																						break;
																					}
																					continue;
																				}
																				goto IL_0285;
																				IL_02e9:
																				num5++;
																				goto IL_02f7;
																				IL_0285:
																				if (5 <= b)
																				{
																					goto IL_02ae;
																				}
																				goto IL_03a9;
																				IL_03a9:
																				if (2 >= b)
																				{
																					goto IL_03b7;
																				}
																				goto IL_0453;
																				IL_03b7:
																				if (2 > b)
																				{
																					goto IL_03c2;
																				}
																				goto IL_03ec;
																				IL_03c2:
																				if (1 < b)
																				{
																					goto end_IL_0211;
																				}
																				goto IL_03d0;
																				IL_03d0:
																				if (1 <= b)
																				{
																					num = 97;
																				}
																				goto end_IL_0211;
																				IL_02f7:
																				ptr2 += 8;
																				goto end_IL_0241;
																				IL_03ec:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_042c;
																				IL_042c:
																				array[num5 - 2] = 0;
																				goto IL_0440;
																				IL_0440:
																				num5--;
																				goto end_IL_0241;
																				IL_0453:
																				if (3 >= b)
																				{
																					goto IL_045e;
																				}
																				goto IL_04b6;
																				IL_045e:
																				if (3 > b)
																				{
																					goto end_IL_0211;
																				}
																				goto IL_046c;
																				IL_046c:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0495;
																				IL_0495:
																				ptr2 += 8;
																				goto IL_04a3;
																				IL_04a3:
																				num5--;
																				goto end_IL_0241;
																				IL_04b6:
																				if (4 < b)
																				{
																					goto end_IL_0211;
																				}
																				goto IL_04c4;
																				IL_04c4:
																				if (4 > b)
																				{
																					goto end_IL_0211;
																				}
																				goto IL_04d2;
																				IL_04d2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0512;
																				IL_0512:
																				array[num5 - 2] = 0;
																				goto IL_0526;
																				IL_0526:
																				num5--;
																				goto end_IL_0241;
																				IL_02ae:
																				array[num5] = 0;
																				goto IL_02bc;
																				IL_02bc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_02df;
																				IL_02df:
																				array2[num5] = null;
																				goto IL_02e9;
																				continue;
																				end_IL_0204:
																				break;
																			}
																			continue;
																			end_IL_0211:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0622;
																	IL_063e:
																	ptr2 += 8;
																	goto end_IL_0241;
																	IL_0630:
																	num5++;
																	goto IL_063e;
																	IL_0622:
																	array[num5] = 0;
																	goto IL_0630;
																	continue;
																	end_IL_0221:
																	break;
																}
																continue;
																end_IL_0231:
																break;
															}
															continue;
															end_IL_0241:
															break;
														}
														continue;
													}
													num = 75;
													goto IL_0702;
													IL_0702:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_064c:
													break;
												}
												continue;
												end_IL_065f:
												break;
											}
											continue;
											end_IL_0669:
											break;
										}
										continue;
										end_IL_0674:
										break;
									}
									continue;
									end_IL_0689:
									break;
								}
								continue;
								end_IL_069e:
								break;
							}
							continue;
							end_IL_06ae:
							break;
						}
						continue;
						end_IL_06be:
						break;
					}
					continue;
					end_IL_06ce:
					break;
				}
				continue;
				end_IL_06de:
				break;
			}
		}
	}

	static Class124()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 2:
							case 3:
								goto end_IL_0039;
							case 4:
								goto end_IL_0046;
							case 5:
								goto end_IL_005b;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_005b:
				break;
			}
		}
	}
}
