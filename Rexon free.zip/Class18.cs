using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;
using UnityEngine.XR;

[Mod("Legit Speed Boost [BOTH GRIPS]", "World", "Moves your hands to boost speed naturally.", false, 38, ModType.const_0, false)]
internal class Class18 : MonoBehaviour
{
	private bool bool_0;

	private bool bool_1;

	private static int int_0;

	private static bool bool_2;

	private static int int_1;

	private static bool bool_3;

	private static IntPtr[] OrderablePartitionerSafeViewOfFileHandle;

	private static IntPtr[] IMPLTYPEFLAGFRESTRICTEDDivRem;

	private static IntPtr[] IResourceReadergetStructuralEqualityComparer;

	private static IntPtr[] CheckedOneWaygetPathDiscovery;

	private unsafe void Update()
	{
		int num = 12;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[5];
						while (true)
						{
							object[] array2 = new object[5];
							while (true)
							{
								int[] array3 = new int[5];
								num = 43;
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[5];
										while (true)
										{
											object[] array6 = new object[1];
											while (true)
											{
												array6[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref XMLDaylightDelta.getCurrencyGroupSeparatorSpn);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_0a29:
																			if (b >= 1)
																			{
																				while (b <= 71)
																				{
																					num = 422;
																					while (true)
																					{
																						IL_0a06:
																						if (36 >= b)
																						{
																							while (true)
																							{
																								IL_09f6:
																								if (36 > b)
																								{
																									while (true)
																									{
																										IL_09e6:
																										if (18 >= b)
																										{
																											while (true)
																											{
																												IL_09d9:
																												if (18 > b)
																												{
																													while (true)
																													{
																														IL_09c9:
																														if (9 < b)
																														{
																															while (true)
																															{
																																IL_09b9:
																																if (13 < b)
																																{
																																	while (true)
																																	{
																																		IL_09a9:
																																		if (15 >= b)
																																		{
																																			while (true)
																																			{
																																				IL_0999:
																																				if (15 > b)
																																				{
																																					while (14 >= b)
																																					{
																																						while (14 <= b)
																																						{
																																							num = 590;
																																							while (true)
																																							{
																																								if (num != 590)
																																								{
																																									if (num != 1571)
																																									{
																																										break;
																																									}
																																									switch (num)
																																									{
																																									case 67:
																																										goto IL_0976;
																																									case 517:
																																										goto IL_0989;
																																									case 412:
																																										goto IL_0999;
																																									case 474:
																																										goto IL_09a9;
																																									case 191:
																																										goto IL_09b9;
																																									case 335:
																																										goto IL_09c9;
																																									case 240:
																																										goto IL_09d9;
																																									case 221:
																																										goto IL_09e6;
																																									case 161:
																																										goto IL_09f6;
																																									case 422:
																																										goto IL_0a06;
																																									case 379:
																																										goto IL_0a16;
																																									case 572:
																																										goto IL_0a29;
																																									case 578:
																																										goto end_IL_0a29;
																																									case 387:
																																									case 416:
																																										goto end_IL_0a39;
																																									case 14:
																																									case 16:
																																										goto IL_0a54;
																																									case 314:
																																										goto IL_0a6f;
																																									case 24:
																																									case 61:
																																										goto IL_0a7d;
																																									case 318:
																																										goto IL_0ac2;
																																									case 344:
																																										goto IL_0ad0;
																																									case 380:
																																										goto IL_0ade;
																																									case 426:
																																										goto IL_0afa;
																																									case 259:
																																									case 437:
																																										goto IL_0b0d;
																																									case 109:
																																										goto IL_0b21;
																																									case 92:
																																									case 472:
																																										goto IL_0b74;
																																									case 475:
																																										goto IL_0bcb;
																																									case 201:
																																										goto IL_0be2;
																																									case 476:
																																										goto IL_0bf5;
																																									case 72:
																																										goto IL_0c09;
																																									case 499:
																																										goto IL_0c1c;
																																									case 115:
																																										goto IL_0c2a;
																																									case 394:
																																										goto IL_0c38;
																																									case 348:
																																										goto IL_0c46;
																																									case 123:
																																									case 260:
																																										goto IL_0c54;
																																									case 28:
																																										goto IL_0cbf;
																																									case 323:
																																										goto IL_0cd2;
																																									case 374:
																																										goto IL_0ce0;
																																									case 5:
																																									case 26:
																																										goto IL_0cee;
																																									case 439:
																																										goto IL_0d07;
																																									case 436:
																																										goto IL_0d15;
																																									case 265:
																																										goto IL_0d23;
																																									case 506:
																																										goto IL_0d3f;
																																									case 25:
																																										goto IL_0d4d;
																																									case 155:
																																									case 338:
																																										goto IL_0d58;
																																									case 0:
																																										goto IL_0d66;
																																									case 15:
																																										goto IL_0d8e;
																																									case 306:
																																										goto IL_0d99;
																																									case 63:
																																										goto IL_0da7;
																																									case 367:
																																										goto IL_0db5;
																																									case 183:
																																									case 413:
																																										goto IL_0dc3;
																																									case 188:
																																										goto IL_0ddc;
																																									case 37:
																																										goto IL_0def;
																																									case 406:
																																										goto IL_0dfd;
																																									case 310:
																																									case 332:
																																										goto IL_0e14;
																																									case 491:
																																										goto IL_0e3d;
																																									case 464:
																																										goto IL_0e4d;
																																									case 337:
																																										goto IL_0e5b;
																																									case 211:
																																										goto IL_0e69;
																																									case 471:
																																										goto IL_0e77;
																																									case 244:
																																									case 427:
																																										goto IL_0e85;
																																									case 511:
																																										goto IL_0e98;
																																									case 193:
																																										goto IL_0ea2;
																																									case 206:
																																										goto IL_0eb0;
																																									case 512:
																																										goto IL_0ec3;
																																									case 516:
																																										goto IL_0ed6;
																																									case 518:
																																										goto IL_0ee9;
																																									case 68:
																																										goto IL_0ef7;
																																									case 522:
																																										goto IL_0f0a;
																																									case 84:
																																									case 288:
																																										goto IL_0f15;
																																									case 102:
																																										goto IL_0f5a;
																																									case 27:
																																										goto IL_0f68;
																																									case 184:
																																									case 308:
																																										goto IL_0f76;
																																									case 356:
																																										goto IL_0fb6;
																																									case 227:
																																										goto IL_0fca;
																																									case 524:
																																										goto IL_0fdd;
																																									case 529:
																																										goto IL_0ff0;
																																									case 291:
																																										goto IL_1004;
																																									case 365:
																																									case 545:
																																										goto IL_1017;
																																									case 313:
																																										goto IL_1057;
																																									case 336:
																																										goto IL_106b;
																																									case 441:
																																									case 562:
																																										goto IL_107e;
																																									case 493:
																																									case 580:
																																										goto IL_1096;
																																									case 178:
																																										goto IL_10d6;
																																									case 311:
																																										goto IL_10ea;
																																									case 537:
																																										goto IL_10fd;
																																									case 33:
																																										goto IL_113e;
																																									case 431:
																																										goto IL_1152;
																																									case 372:
																																										goto IL_1165;
																																									case 388:
																																										goto IL_1170;
																																									case 55:
																																									case 358:
																																										goto IL_117e;
																																									case 504:
																																										goto IL_1196;
																																									case 502:
																																										goto IL_11a4;
																																									case 485:
																																										goto IL_11b2;
																																									case 70:
																																										goto IL_11c5;
																																									case 539:
																																										goto IL_11d3;
																																									case 205:
																																									case 424:
																																										goto IL_11e1;
																																									case 90:
																																										goto IL_1218;
																																									case 251:
																																										goto IL_122b;
																																									case 163:
																																										goto IL_1239;
																																									case 254:
																																										goto IL_1247;
																																									case 449:
																																										goto IL_1255;
																																									case 430:
																																									case 478:
																																										goto IL_1260;
																																									case 214:
																																										goto IL_126e;
																																									case 322:
																																										goto IL_1281;
																																									case 231:
																																										goto IL_128f;
																																									case 233:
																																										goto IL_12a2;
																																									case 381:
																																										goto IL_12ad;
																																									case 583:
																																										goto IL_12bb;
																																									case 79:
																																									case 165:
																																										goto IL_12c9;
																																									case 327:
																																										goto IL_12ee;
																																									case 88:
																																									case 196:
																																										goto IL_12f9;
																																									case 210:
																																										goto IL_130d;
																																									case 262:
																																										goto IL_134c;
																																									case 54:
																																										goto IL_135f;
																																									case 458:
																																										goto IL_136d;
																																									case 21:
																																									case 114:
																																										goto IL_137b;
																																									case 526:
																																										goto IL_13bb;
																																									case 414:
																																										goto IL_13cf;
																																									case 341:
																																										goto IL_13e2;
																																									case 64:
																																										goto IL_13f0;
																																									case 208:
																																									case 320:
																																										goto IL_13fb;
																																									case 292:
																																										goto IL_1415;
																																									case 38:
																																										goto IL_1423;
																																									case 307:
																																										goto IL_1431;
																																									case 513:
																																										goto IL_1444;
																																									case 226:
																																										goto IL_1452;
																																									case 417:
																																									case 455:
																																										goto IL_1460;
																																									case 329:
																																										goto IL_1474;
																																									case 60:
																																										goto IL_14e4;
																																									case 142:
																																										goto IL_1500;
																																									case 299:
																																										goto IL_150e;
																																									case 149:
																																										goto IL_151c;
																																									case 278:
																																									case 391:
																																										goto IL_1533;
																																									case 523:
																																										goto IL_1547;
																																									case 107:
																																										goto IL_158f;
																																									case 581:
																																										goto IL_15a2;
																																									case 198:
																																									case 544:
																																										goto IL_15b0;
																																									case 325:
																																										goto IL_161b;
																																									case 97:
																																									case 237:
																																										goto IL_1637;
																																									case 152:
																																										goto IL_1677;
																																									case 435:
																																										goto IL_168b;
																																									case 328:
																																										goto IL_169e;
																																									case 346:
																																										goto IL_16ac;
																																									case 180:
																																									case 217:
																																										goto IL_16b7;
																																									case 440:
																																										goto IL_16c5;
																																									case 225:
																																										goto IL_16e3;
																																									case 268:
																																										goto IL_16f1;
																																									case 317:
																																										goto IL_1704;
																																									case 470:
																																										goto IL_1712;
																																									case 62:
																																										goto IL_1720;
																																									case 479:
																																										goto IL_172e;
																																									case 404:
																																									case 556:
																																										goto IL_173c;
																																									case 147:
																																										goto IL_1750;
																																									case 438:
																																										goto IL_178f;
																																									case 122:
																																									case 200:
																																										goto IL_17a2;
																																									case 219:
																																										goto IL_17b0;
																																									case 324:
																																										goto IL_17ce;
																																									case 305:
																																										goto IL_17dc;
																																									case 452:
																																										goto IL_17ef;
																																									case 255:
																																										goto IL_17fd;
																																									case 45:
																																									case 164:
																																										goto IL_180b;
																																									case 235:
																																										goto IL_1843;
																																									case 541:
																																										goto IL_1857;
																																									case 567:
																																										goto IL_186a;
																																									case 157:
																																										goto IL_1878;
																																									case 132:
																																										goto IL_1886;
																																									case 454:
																																										goto IL_1894;
																																									case 80:
																																									case 228:
																																										goto end_IL_0963;
																																									case 296:
																																										goto IL_18bf;
																																									case 284:
																																										goto IL_1922;
																																									case 295:
																																										goto IL_1930;
																																									case 261:
																																										goto IL_194c;
																																									case 77:
																																									case 81:
																																										goto IL_195a;
																																									case 409:
																																										goto IL_196e;
																																									case 223:
																																										goto IL_19ab;
																																									case 536:
																																										goto IL_19c7;
																																									case 401:
																																										goto IL_19d2;
																																									case 20:
																																										goto IL_19e0;
																																									case 1:
																																									case 573:
																																										goto IL_19ee;
																																									case 551:
																																										goto IL_1a26;
																																									case 500:
																																										goto IL_1a3a;
																																									case 91:
																																									case 496:
																																										goto IL_1a4d;
																																									case 236:
																																										goto IL_1a61;
																																									case 245:
																																										goto IL_1a99;
																																									case 95:
																																										goto IL_1aac;
																																									case 316:
																																										goto IL_1aba;
																																									case 331:
																																									case 347:
																																										goto IL_1ac5;
																																									case 405:
																																										goto IL_1ad9;
																																									case 419:
																																										goto IL_1b18;
																																									case 103:
																																										goto IL_1b2b;
																																									case 249:
																																										goto IL_1b39;
																																									case 501:
																																									case 520:
																																										goto IL_1b44;
																																									case 267:
																																										goto IL_1b5b;
																																									case 460:
																																										goto IL_1b6e;
																																									case 446:
																																										goto IL_1b85;
																																									case 570:
																																										goto IL_1b98;
																																									case 373:
																																										goto IL_1ba6;
																																									case 110:
																																									case 579:
																																										goto IL_1bb1;
																																									case 548:
																																										goto IL_1bee;
																																									case 224:
																																										goto IL_1bfc;
																																									case 104:
																																										goto IL_1c0f;
																																									case 34:
																																										goto IL_1c1d;
																																									case 171:
																																									case 220:
																																										goto IL_1c28;
																																									case 51:
																																										goto IL_1c3c;
																																									case 41:
																																										goto IL_1c74;
																																									case 560:
																																										goto IL_1c87;
																																									case 453:
																																										goto IL_1c9e;
																																									case 98:
																																									case 120:
																																										goto IL_1cac;
																																									case 486:
																																										goto IL_1cba;
																																									case 357:
																																										goto IL_1cd8;
																																									case 96:
																																										goto IL_1ce6;
																																									case 400:
																																										goto IL_1cf9;
																																									case 31:
																																										goto IL_1d07;
																																									case 167:
																																									case 257:
																																										goto IL_1d15;
																																									case 105:
																																										goto IL_1d29;
																																									case 22:
																																										goto IL_1d66;
																																									case 309:
																																										goto IL_1d79;
																																									case 418:
																																										goto IL_1d87;
																																									case 10:
																																									case 85:
																																										goto IL_1d9b;
																																									case 411:
																																										goto IL_1ddb;
																																									case 566:
																																										goto IL_1def;
																																									case 415:
																																										goto IL_1e02;
																																									case 494:
																																										goto IL_1e10;
																																									case 283:
																																									case 301:
																																										goto IL_1e1e;
																																									case 272:
																																										goto IL_1e32;
																																									case 49:
																																										goto IL_1e71;
																																									case 145:
																																										goto IL_1e84;
																																									case 396:
																																										goto IL_1e92;
																																									case 86:
																																									case 266:
																																										goto IL_1ea0;
																																									case 448:
																																										goto IL_1f0e;
																																									case 23:
																																										goto IL_1f21;
																																									case 177:
																																										goto IL_1f2f;
																																									case 213:
																																									case 463:
																																										goto IL_1f3d;
																																									case 408:
																																										goto IL_1f51;
																																									case 156:
																																										goto IL_1f90;
																																									case 555:
																																										goto IL_1fa3;
																																									case 370:
																																										goto IL_1fb1;
																																									case 148:
																																									case 393:
																																										goto IL_1fbc;
																																									case 362:
																																										goto IL_1fd0;
																																									case 315:
																																										goto IL_200d;
																																									case 489:
																																										goto IL_2020;
																																									case 425:
																																										goto IL_202e;
																																									case 53:
																																									case 153:
																																										goto IL_2039;
																																									case 246:
																																										goto IL_204d;
																																									case 209:
																																										goto IL_208a;
																																									case 158:
																																										goto IL_209d;
																																									case 543:
																																										goto IL_20ab;
																																									case 355:
																																									case 508:
																																										goto IL_20b9;
																																									case 519:
																																										goto IL_20f1;
																																									case 343:
																																										goto IL_2105;
																																									case 547:
																																										goto IL_2118;
																																									case 383:
																																										goto IL_2126;
																																									case 48:
																																									case 462:
																																										goto IL_213d;
																																									case 270:
																																										goto IL_214b;
																																									case 65:
																																										goto IL_216e;
																																									case 126:
																																										goto IL_217c;
																																									case 457:
																																										goto IL_218f;
																																									case 351:
																																										goto IL_219d;
																																									case 119:
																																									case 130:
																																										goto IL_21a8;
																																									case 89:
																																										goto IL_21e6;
																																									case 40:
																																										goto IL_21fa;
																																									case 326:
																																										goto IL_220d;
																																									case 36:
																																										goto IL_221b;
																																									case 87:
																																									case 168:
																																										goto IL_2229;
																																									case 345:
																																										goto IL_223d;
																																									case 93:
																																										goto IL_22d5;
																																									case 131:
																																										goto IL_22e3;
																																									case 407:
																																										goto IL_22f6;
																																									case 559:
																																										goto IL_2304;
																																									case 52:
																																									case 451:
																																										goto IL_231b;
																																									case 138:
																																										goto IL_2379;
																																									case 561:
																																										goto IL_238c;
																																									case 564:
																																										goto IL_239a;
																																									case 170:
																																									case 303:
																																										goto IL_23a8;
																																									case 569:
																																										goto IL_23bc;
																																									case 402:
																																										goto IL_2404;
																																									case 113:
																																										goto IL_2417;
																																									case 273:
																																										goto IL_2425;
																																									case 433:
																																									case 576:
																																										goto IL_2430;
																																									case 350:
																																										goto IL_244d;
																																									case 465:
																																										goto IL_248c;
																																									case 363:
																																										goto IL_249f;
																																									case 398:
																																										goto IL_24ad;
																																									case 181:
																																										goto IL_24bb;
																																									case 354:
																																										goto IL_24c6;
																																									case 287:
																																										goto IL_24d4;
																																									case 169:
																																									case 423:
																																										goto IL_24eb;
																																									case 503:
																																										goto IL_2519;
																																									case 277:
																																									case 456:
																																										goto IL_252c;
																																									case 111:
																																										goto IL_2540;
																																									case 44:
																																										goto IL_257f;
																																									case 146:
																																										goto IL_2592;
																																									case 377:
																																										goto IL_259d;
																																									case 410:
																																									case 571:
																																										goto IL_25ab;
																																									case 241:
																																										goto IL_25bf;
																																									case 342:
																																										goto IL_25fe;
																																									case 264:
																																										goto IL_2611;
																																									case 498:
																																										goto IL_261f;
																																									case 302:
																																									case 359:
																																										goto IL_262d;
																																									case 279:
																																										goto IL_2641;
																																									case 392:
																																										goto IL_2680;
																																									case 349:
																																										goto IL_2693;
																																									case 420:
																																									case 450:
																																										goto IL_269e;
																																									case 129:
																																										goto IL_26dc;
																																									case 432:
																																										goto IL_26f0;
																																									case 495:
																																										goto IL_2703;
																																									case 94:
																																										goto IL_2711;
																																									case 222:
																																									case 558:
																																										goto IL_271c;
																																									case 258:
																																										goto IL_2740;
																																									case 298:
																																										goto IL_2757;
																																									case 176:
																																										goto IL_2765;
																																									case 487:
																																										goto IL_2778;
																																									case 179:
																																										goto IL_2786;
																																									case 333:
																																									case 483:
																																										goto IL_2794;
																																									case 30:
																																										goto IL_27f6;
																																									case 66:
																																										goto IL_2809;
																																									case 276:
																																										goto IL_2817;
																																									case 234:
																																									case 510:
																																										goto IL_2825;
																																									case 535:
																																										goto IL_2850;
																																									case 274:
																																										goto IL_2869;
																																									case 364:
																																										goto IL_2877;
																																									case 135:
																																										goto IL_2885;
																																									case 32:
																																										goto IL_2893;
																																									case 232:
																																										goto IL_28a1;
																																									case 7:
																																										goto IL_28af;
																																									case 73:
																																									case 154:
																																										goto IL_28bd;
																																									case 192:
																																										goto IL_28d1;
																																									case 290:
																																										goto IL_2910;
																																									case 128:
																																									case 490:
																																										goto IL_2923;
																																									case 294:
																																										goto IL_293d;
																																									case 35:
																																										goto IL_2950;
																																									case 509:
																																										goto IL_295e;
																																									case 185:
																																									case 428:
																																										goto IL_296c;
																																									case 69:
																																										goto IL_29ad;
																																									case 339:
																																										goto IL_29c1;
																																									case 421:
																																									case 534:
																																										goto IL_29dd;
																																									case 29:
																																										goto IL_29f1;
																																									case 4:
																																										goto IL_2a30;
																																									case 429:
																																										goto IL_2a43;
																																									case 121:
																																										goto IL_2a51;
																																									case 56:
																																										goto IL_2a5f;
																																									case 143:
																																										goto IL_2a6d;
																																									case 253:
																																									case 538:
																																										goto IL_2a7b;
																																									case 289:
																																										goto IL_2add;
																																									case 136:
																																									case 281:
																																										goto IL_2af9;
																																									case 112:
																																										goto IL_2b0d;
																																									case 353:
																																										goto IL_2b4c;
																																									case 397:
																																										goto IL_2b5f;
																																									case 59:
																																										goto IL_2b6a;
																																									case 42:
																																									case 482:
																																										goto IL_2b75;
																																									case 532:
																																										goto IL_2bad;
																																									case 127:
																																										goto IL_2bc1;
																																									case 82:
																																										goto IL_2bd1;
																																									case 74:
																																										goto IL_2bdc;
																																									case 2:
																																									case 6:
																																									case 9:
																																									case 13:
																																									case 18:
																																									case 39:
																																									case 57:
																																									case 71:
																																									case 78:
																																									case 83:
																																									case 100:
																																									case 116:
																																									case 117:
																																									case 125:
																																									case 134:
																																									case 141:
																																									case 144:
																																									case 159:
																																									case 162:
																																									case 166:
																																									case 173:
																																									case 175:
																																									case 182:
																																									case 189:
																																									case 195:
																																									case 203:
																																									case 207:
																																									case 212:
																																									case 216:
																																									case 229:
																																									case 230:
																																									case 239:
																																									case 243:
																																									case 247:
																																									case 248:
																																									case 250:
																																									case 256:
																																									case 263:
																																									case 275:
																																									case 282:
																																									case 286:
																																									case 293:
																																									case 330:
																																									case 334:
																																									case 340:
																																									case 360:
																																									case 361:
																																									case 366:
																																									case 371:
																																									case 376:
																																									case 382:
																																									case 384:
																																									case 385:
																																									case 395:
																																									case 399:
																																									case 403:
																																									case 434:
																																									case 445:
																																									case 461:
																																									case 473:
																																									case 477:
																																									case 480:
																																									case 488:
																																									case 514:
																																									case 515:
																																									case 521:
																																									case 525:
																																									case 530:
																																									case 540:
																																									case 542:
																																									case 549:
																																									case 552:
																																									case 565:
																																									case 575:
																																										goto end_IL_0976;
																																									case 3:
																																									case 17:
																																									case 19:
																																									case 46:
																																									case 47:
																																									case 50:
																																									case 58:
																																									case 75:
																																									case 76:
																																									case 99:
																																									case 101:
																																									case 106:
																																									case 118:
																																									case 124:
																																									case 133:
																																									case 137:
																																									case 139:
																																									case 140:
																																									case 150:
																																									case 151:
																																									case 172:
																																									case 186:
																																									case 187:
																																									case 190:
																																									case 197:
																																									case 199:
																																									case 202:
																																									case 204:
																																									case 215:
																																									case 218:
																																									case 242:
																																									case 252:
																																									case 269:
																																									case 271:
																																									case 280:
																																									case 285:
																																									case 297:
																																									case 304:
																																									case 312:
																																									case 319:
																																									case 321:
																																									case 352:
																																									case 368:
																																									case 369:
																																									case 375:
																																									case 378:
																																									case 386:
																																									case 389:
																																									case 390:
																																									case 442:
																																									case 443:
																																									case 459:
																																									case 466:
																																									case 467:
																																									case 468:
																																									case 469:
																																									case 481:
																																									case 484:
																																									case 492:
																																									case 497:
																																									case 505:
																																									case 507:
																																									case 527:
																																									case 528:
																																									case 533:
																																									case 546:
																																									case 550:
																																									case 554:
																																									case 557:
																																									case 563:
																																									case 568:
																																									case 574:
																																									case 577:
																																									case 582:
																																										goto end_IL_0a49;
																																									case 531:
																																										goto end_IL_2c03;
																																									case 174:
																																										goto end_IL_2c16;
																																									case 8:
																																										goto end_IL_2c20;
																																									case 194:
																																										goto end_IL_2c2b;
																																									case 238:
																																										goto end_IL_2c3b;
																																									case 43:
																																										goto end_IL_2c4b;
																																									case 108:
																																										goto end_IL_2c5b;
																																									case 447:
																																										goto end_IL_2c6b;
																																									case 444:
																																										goto end_IL_2c84;
																																									case 160:
																																										goto end_IL_2c94;
																																									case 11:
																																										goto end_IL_2ca4;
																																									case 12:
																																										goto end_IL_2cb4;
																																									case 300:
																																									case 553:
																																										return;
																																									}
																																									continue;
																																								}
																																								goto IL_10fd;
																																								IL_113e:
																																								array[num6 - 2] = 0;
																																								goto IL_1152;
																																								IL_1152:
																																								num6--;
																																								goto end_IL_0a49;
																																								IL_10fd:
																																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																																								goto IL_113e;
																																								continue;
																																								end_IL_0963:
																																								break;
																																							}
																																							goto IL_18a2;
																																							continue;
																																							end_IL_0976:
																																							break;
																																							IL_0976:;
																																						}
																																						break;
																																						IL_0989:;
																																					}
																																					break;
																																				}
																																				goto IL_0b74;
																																				IL_0ed6:
																																				num6--;
																																				goto end_IL_0a49;
																																				IL_0b74:
																																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																				goto IL_0ed6;
																																			}
																																			break;
																																		}
																																		goto IL_1165;
																																		IL_1218:
																																		num6 -= 2;
																																		goto end_IL_0a49;
																																		IL_1165:
																																		if (16 >= b)
																																		{
																																			goto IL_1170;
																																		}
																																		goto IL_11c5;
																																		IL_1170:
																																		if (16 > b)
																																		{
																																			break;
																																		}
																																		goto IL_117e;
																																		IL_117e:
																																		array2[num6] = array6[*(int*)(ptr2 + num3)];
																																		goto IL_1196;
																																		IL_1196:
																																		array[num6] = 5;
																																		goto IL_11a4;
																																		IL_11a4:
																																		num6++;
																																		goto IL_11b2;
																																		IL_11b2:
																																		ptr2 += 8;
																																		goto end_IL_0a49;
																																		IL_11c5:
																																		if (17 < b)
																																		{
																																			break;
																																		}
																																		goto IL_11d3;
																																		IL_11d3:
																																		if (17 > b)
																																		{
																																			break;
																																		}
																																		goto IL_11e1;
																																		IL_11e1:
																																		((Class18)array2[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0;
																																		num = 90;
																																		goto IL_1218;
																																	}
																																	break;
																																}
																																goto IL_0afa;
																																IL_0d23:
																																ptr2 += 16;
																																num = 304;
																																goto end_IL_0a49;
																																IL_0afa:
																																if (13 > b)
																																{
																																	goto IL_0c1c;
																																}
																																goto IL_107e;
																																IL_107e:
																																ptr2 = ptr + *(int*)(ptr2 + num3);
																																goto end_IL_0a49;
																																IL_0c1c:
																																if (11 >= b)
																																{
																																	goto IL_0c2a;
																																}
																																goto IL_0cd2;
																																IL_0c2a:
																																if (11 <= b)
																																{
																																	goto end_IL_0a49;
																																}
																																goto IL_0c38;
																																IL_0c38:
																																if (10 < b)
																																{
																																	break;
																																}
																																goto IL_0c46;
																																IL_0c46:
																																if (10 > b)
																																{
																																	break;
																																}
																																goto IL_0c54;
																																IL_0c54:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																num = 28;
																																goto IL_0cbf;
																																IL_0cbf:
																																num6 -= 2;
																																goto end_IL_0a49;
																																IL_0cd2:
																																if (12 < b)
																																{
																																	break;
																																}
																																goto IL_0ce0;
																																IL_0ce0:
																																if (12 > b)
																																{
																																	break;
																																}
																																goto IL_0cee;
																																IL_0cee:
																																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																																goto IL_0d07;
																																IL_0d07:
																																array[num6] = 1;
																																goto IL_0d15;
																																IL_0d15:
																																num6++;
																																goto IL_0d23;
																															}
																															break;
																														}
																														goto IL_0a6f;
																														IL_0fb6:
																														array[num6 - 2] = 0;
																														goto IL_0fca;
																														IL_0a6f:
																														if (9 <= b)
																														{
																															goto IL_0a7d;
																														}
																														goto IL_0d3f;
																														IL_0a7d:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0bf5;
																														IL_0bf5:
																														array[num6 - 2] = 0;
																														goto IL_0c09;
																														IL_0c09:
																														num6--;
																														goto end_IL_0a49;
																														IL_0d3f:
																														if (4 >= b)
																														{
																															goto IL_0d4d;
																														}
																														goto IL_0e4d;
																														IL_0d4d:
																														if (4 <= b)
																														{
																															goto IL_0d58;
																														}
																														goto IL_0d8e;
																														IL_0d58:
																														array[num6] = 0;
																														goto IL_0d66;
																														IL_0d66:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																														goto IL_0e98;
																														IL_0e98:
																														array2[num6] = null;
																														goto IL_0ea2;
																														IL_0ea2:
																														num6++;
																														goto IL_0eb0;
																														IL_0eb0:
																														ptr2 += 8;
																														goto end_IL_0a49;
																														IL_0d8e:
																														if (2 >= b)
																														{
																															goto IL_0d99;
																														}
																														goto IL_0def;
																														IL_0d99:
																														if (2 > b)
																														{
																															goto IL_0da7;
																														}
																														goto IL_1017;
																														IL_0da7:
																														if (1 < b)
																														{
																															break;
																														}
																														goto IL_0db5;
																														IL_0db5:
																														if (1 > b)
																														{
																															break;
																														}
																														goto IL_0dc3;
																														IL_0dc3:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																														goto IL_0ddc;
																														IL_0ddc:
																														array[num6] = 0;
																														goto IL_0ee9;
																														IL_0ee9:
																														num6++;
																														goto IL_0ef7;
																														IL_0ef7:
																														ptr2 += 8;
																														goto end_IL_0a49;
																														IL_1017:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_1057;
																														IL_1057:
																														array[num6 - 2] = 0;
																														goto IL_106b;
																														IL_106b:
																														num6--;
																														goto end_IL_0a49;
																														IL_0def:
																														if (3 < b)
																														{
																															break;
																														}
																														goto IL_0dfd;
																														IL_0dfd:
																														if (3 > b)
																														{
																															break;
																														}
																														num = 310;
																														goto IL_0e14;
																														IL_0fca:
																														num6--;
																														goto end_IL_0a49;
																														IL_0e14:
																														ref int reference = ref array4[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0e3d;
																														IL_0e3d:
																														ptr2 += 8;
																														goto IL_0ec3;
																														IL_0ec3:
																														num6--;
																														goto end_IL_0a49;
																														IL_0e4d:
																														if (6 < b)
																														{
																															goto IL_0e5b;
																														}
																														goto IL_0f0a;
																														IL_0e5b:
																														if (7 < b)
																														{
																															goto IL_0e69;
																														}
																														goto IL_0fdd;
																														IL_0e69:
																														if (8 < b)
																														{
																															break;
																														}
																														goto IL_0e77;
																														IL_0e77:
																														if (8 > b)
																														{
																															break;
																														}
																														goto IL_0e85;
																														IL_0e85:
																														num6--;
																														goto end_IL_0a49;
																														IL_0fdd:
																														if (7 > b)
																														{
																															break;
																														}
																														goto IL_1096;
																														IL_1096:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_10d6;
																														IL_10d6:
																														array[num6 - 2] = 0;
																														goto IL_10ea;
																														IL_10ea:
																														num6--;
																														goto end_IL_0a49;
																														IL_0f0a:
																														if (6 <= b)
																														{
																															goto IL_0f15;
																														}
																														goto IL_0f5a;
																														IL_0f15:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0ff0;
																														IL_0ff0:
																														array[num6 - 2] = 0;
																														goto IL_1004;
																														IL_1004:
																														num6--;
																														goto end_IL_0a49;
																														IL_0f5a:
																														if (5 < b)
																														{
																															break;
																														}
																														goto IL_0f68;
																														IL_0f68:
																														if (5 > b)
																														{
																															break;
																														}
																														goto IL_0f76;
																														IL_0f76:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0fb6;
																													}
																													break;
																												}
																												goto IL_0a54;
																												IL_0ade:
																												ptr2 += 16;
																												num = 133;
																												goto end_IL_0a49;
																												IL_0a54:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(double*)(ptr2 + num4);
																												goto IL_0ac2;
																												IL_0ac2:
																												array[num6] = 3;
																												goto IL_0ad0;
																												IL_0ad0:
																												num6++;
																												goto IL_0ade;
																											}
																											break;
																										}
																										goto IL_122b;
																										IL_1a26:
																										array[num6 - 1] = 5;
																										goto IL_1a3a;
																										IL_122b:
																										if (27 >= b)
																										{
																											goto IL_1239;
																										}
																										goto IL_169e;
																										IL_1239:
																										if (27 > b)
																										{
																											goto IL_1247;
																										}
																										goto IL_1637;
																										IL_1247:
																										if (22 >= b)
																										{
																											goto IL_1255;
																										}
																										goto IL_13e2;
																										IL_1255:
																										if (22 <= b)
																										{
																											goto IL_1260;
																										}
																										goto IL_12a2;
																										IL_1260:
																										array[num6] = 15;
																										goto IL_126e;
																										IL_126e:
																										array3[num6] = *(int*)(ptr2 + num3);
																										goto IL_1281;
																										IL_1281:
																										ptr2 += 8;
																										goto IL_128f;
																										IL_128f:
																										num6++;
																										goto end_IL_0a49;
																										IL_12a2:
																										if (20 < b)
																										{
																											goto IL_12ad;
																										}
																										num = 327;
																										goto IL_12ee;
																										IL_12ad:
																										if (21 < b)
																										{
																											break;
																										}
																										goto IL_12bb;
																										IL_12bb:
																										if (21 > b)
																										{
																											break;
																										}
																										goto IL_12c9;
																										IL_12c9:
																										byte* num7 = ptr2;
																										num5 = 1;
																										ptr2 = num7 + -200;
																										goto end_IL_0a49;
																										IL_1a3a:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_12ee:
																										if (20 <= b)
																										{
																											goto IL_12f9;
																										}
																										goto IL_135f;
																										IL_12f9:
																										array[num6 - 1] = 0;
																										goto IL_130d;
																										IL_130d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_134c;
																										IL_134c:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_135f:
																										if (19 < b)
																										{
																											break;
																										}
																										goto IL_136d;
																										IL_136d:
																										if (19 > b)
																										{
																											break;
																										}
																										goto IL_137b;
																										IL_137b:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_13bb;
																										IL_13bb:
																										array[num6 - 2] = 3;
																										goto IL_13cf;
																										IL_13cf:
																										num6--;
																										goto end_IL_0a49;
																										IL_13e2:
																										if (24 >= b)
																										{
																											goto IL_13f0;
																										}
																										goto IL_1500;
																										IL_13f0:
																										if (24 <= b)
																										{
																											goto IL_13fb;
																										}
																										goto IL_1444;
																										IL_13fb:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																										goto IL_1415;
																										IL_1415:
																										array[num6] = 3;
																										goto IL_1423;
																										IL_1423:
																										num6++;
																										goto IL_1431;
																										IL_1431:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_1444:
																										if (23 < b)
																										{
																											break;
																										}
																										goto IL_1452;
																										IL_1452:
																										if (23 > b)
																										{
																											break;
																										}
																										goto IL_1460;
																										IL_1460:
																										array[num6 - 1] = 3;
																										goto IL_1474;
																										IL_1474:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<ref RaycastHit, float>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref RaycastHit>)OrderablePartitionerSafeViewOfFileHandle[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																										goto IL_14e4;
																										IL_14e4:
																										ptr2 += 8;
																										num = 76;
																										goto end_IL_0a49;
																										IL_1500:
																										if (25 < b)
																										{
																											goto IL_150e;
																										}
																										goto IL_15a2;
																										IL_150e:
																										if (26 < b)
																										{
																											break;
																										}
																										goto IL_151c;
																										IL_151c:
																										if (26 > b)
																										{
																											break;
																										}
																										num = 278;
																										goto IL_1533;
																										IL_1a4d:
																										array[num6 - 1] = 5;
																										goto IL_1a61;
																										IL_1533:
																										array[num6 - 1] = 3;
																										goto IL_1547;
																										IL_1547:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										num = 107;
																										goto IL_158f;
																										IL_158f:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_15a2:
																										if (25 > b)
																										{
																											break;
																										}
																										goto IL_15b0;
																										IL_15b0:
																										ptr2 = ((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]))) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										num = 325;
																										goto IL_161b;
																										IL_161b:
																										num6 -= 2;
																										num = 269;
																										goto end_IL_0a49;
																										IL_1637:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_1677;
																										IL_1677:
																										array[num6 - 2] = 3;
																										goto IL_168b;
																										IL_168b:
																										num6--;
																										goto end_IL_0a49;
																										IL_169e:
																										if (31 >= b)
																										{
																											goto IL_16ac;
																										}
																										goto IL_186a;
																										IL_16ac:
																										if (31 <= b)
																										{
																											goto IL_16b7;
																										}
																										goto IL_1704;
																										IL_16b7:
																										array[num6] = 5;
																										goto IL_16c5;
																										IL_16c5:
																										array2[num6] = ((delegate*<GorillaTagger>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])();
																										goto IL_16e3;
																										IL_16e3:
																										num6++;
																										goto IL_16f1;
																										IL_16f1:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_1704:
																										if (29 >= b)
																										{
																											goto IL_1712;
																										}
																										goto IL_17ef;
																										IL_1712:
																										if (29 > b)
																										{
																											goto IL_1720;
																										}
																										goto IL_17a2;
																										IL_1720:
																										if (28 < b)
																										{
																											break;
																										}
																										goto IL_172e;
																										IL_172e:
																										if (28 > b)
																										{
																											break;
																										}
																										goto IL_173c;
																										IL_173c:
																										array[num6 - 1] = 3;
																										goto IL_1750;
																										IL_1750:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_178f;
																										IL_178f:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_17a2:
																										array[num6] = 5;
																										goto IL_17b0;
																										IL_17b0:
																										array2[num6] = ((delegate*<GorillaTagger>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])();
																										goto IL_17ce;
																										IL_17ce:
																										num6++;
																										goto IL_17dc;
																										IL_17dc:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_17ef:
																										if (30 < b)
																										{
																											break;
																										}
																										goto IL_17fd;
																										IL_17fd:
																										if (30 > b)
																										{
																											break;
																										}
																										goto IL_180b;
																										IL_180b:
																										array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																										goto IL_1843;
																										IL_1843:
																										array[num6 - 1] = 5;
																										goto IL_1857;
																										IL_1857:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_186a:
																										if (33 < b)
																										{
																											goto IL_1878;
																										}
																										num = 536;
																										goto IL_19c7;
																										IL_1878:
																										if (34 < b)
																										{
																											goto IL_1886;
																										}
																										num = 261;
																										goto IL_194c;
																										IL_1886:
																										if (35 < b)
																										{
																											break;
																										}
																										goto IL_1894;
																										IL_1894:
																										if (35 > b)
																										{
																											break;
																										}
																										goto IL_18a2;
																										IL_18a2:
																										array[num6 - 3] = 5;
																										num = 296;
																										goto IL_18bf;
																										IL_18bf:
																										array2[num6 - 3] = ((delegate*<float, float, float, object>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																										goto IL_1922;
																										IL_1922:
																										num6 -= 2;
																										goto IL_1930;
																										IL_1930:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_1a99:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_194c:
																										if (34 > b)
																										{
																											break;
																										}
																										goto IL_195a;
																										IL_195a:
																										array[num6 - 1] = 4;
																										goto IL_196e;
																										IL_196e:
																										array2[num6 - 1] = ((delegate*<Transform, Vector3>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																										goto IL_19ab;
																										IL_19ab:
																										ptr2 += 8;
																										goto end_IL_0a49;
																										IL_1a61:
																										array2[num6 - 1] = ((delegate*<Component, Transform>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																										goto IL_1a99;
																										IL_19c7:
																										if (33 > b)
																										{
																											goto IL_19d2;
																										}
																										goto IL_1a4d;
																										IL_19d2:
																										if (32 < b)
																										{
																											break;
																										}
																										goto IL_19e0;
																										IL_19e0:
																										if (32 > b)
																										{
																											break;
																										}
																										goto IL_19ee;
																										IL_19ee:
																										array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																										goto IL_1a26;
																									}
																									break;
																								}
																								goto IL_0b0d;
																								IL_0be2:
																								ptr2 += 8;
																								goto end_IL_0a49;
																								IL_0b0d:
																								array[num6 - 2] = 4;
																								goto IL_0b21;
																								IL_0b21:
																								array2[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																								goto IL_0bcb;
																								IL_0bcb:
																								num6--;
																								num = 201;
																								goto IL_0be2;
																							}
																							break;
																						}
																						goto IL_1aac;
																						IL_2b5f:
																						if (70 >= b)
																						{
																							goto IL_2b6a;
																						}
																						goto IL_2bd1;
																						IL_1aac:
																						if (54 >= b)
																						{
																							goto IL_1aba;
																						}
																						goto IL_2417;
																						IL_1aba:
																						if (54 <= b)
																						{
																							goto IL_1ac5;
																						}
																						goto IL_1b2b;
																						IL_1ac5:
																						array[num6 - 1] = 3;
																						goto IL_1ad9;
																						IL_1ad9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_1b18;
																						IL_1b18:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_1b2b:
																						if (45 >= b)
																						{
																							goto IL_1b39;
																						}
																						goto IL_1fa3;
																						IL_1b39:
																						if (45 <= b)
																						{
																							goto IL_1b44;
																						}
																						goto IL_1b98;
																						IL_1b44:
																						array[num6] = 15;
																						num = 267;
																						goto IL_1b5b;
																						IL_1b5b:
																						array3[num6] = *(int*)(ptr2 + num3);
																						goto IL_1b6e;
																						IL_1b6e:
																						ptr2 += 8;
																						num = 446;
																						goto IL_1b85;
																						IL_1b85:
																						num6++;
																						goto end_IL_0a49;
																						IL_1b98:
																						if (40 >= b)
																						{
																							goto IL_1ba6;
																						}
																						goto IL_1d79;
																						IL_1ba6:
																						if (40 <= b)
																						{
																							goto IL_1bb1;
																						}
																						goto IL_1c0f;
																						IL_1bb1:
																						((delegate*<Transform, Vector3, void>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																						goto IL_1bee;
																						IL_1bee:
																						num6 -= 2;
																						goto IL_1bfc;
																						IL_1bfc:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_1c0f:
																						if (38 >= b)
																						{
																							goto IL_1c1d;
																						}
																						goto IL_1cf9;
																						IL_1c1d:
																						if (38 <= b)
																						{
																							goto IL_1c28;
																						}
																						goto IL_1c87;
																						IL_1c28:
																						array[num6 - 1] = 5;
																						goto IL_1c3c;
																						IL_1c3c:
																						array2[num6 - 1] = ((delegate*<Component, Transform>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																						goto IL_1c74;
																						IL_1c74:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_1c87:
																						if (37 < b)
																						{
																							break;
																						}
																						num = 453;
																						goto IL_1c9e;
																						IL_2b6a:
																						if (70 > b)
																						{
																							break;
																						}
																						goto IL_2b75;
																						IL_1c9e:
																						if (37 > b)
																						{
																							break;
																						}
																						goto IL_1cac;
																						IL_1cac:
																						array[num6] = 5;
																						goto IL_1cba;
																						IL_1cba:
																						array2[num6] = ((delegate*<GorillaTagger>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])();
																						goto IL_1cd8;
																						IL_1cd8:
																						num6++;
																						goto IL_1ce6;
																						IL_1ce6:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_1cf9:
																						if (39 < b)
																						{
																							break;
																						}
																						goto IL_1d07;
																						IL_1d07:
																						if (39 > b)
																						{
																							break;
																						}
																						goto IL_1d15;
																						IL_1d15:
																						array[num6 - 1] = 4;
																						goto IL_1d29;
																						IL_1d29:
																						array2[num6 - 1] = ((delegate*<Transform, Vector3>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																						goto IL_1d66;
																						IL_1d66:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_1d79:
																						if (42 >= b)
																						{
																							goto IL_1d87;
																						}
																						goto IL_1e84;
																						IL_1d87:
																						if (42 <= b)
																						{
																							num = 85;
																							goto IL_1d9b;
																						}
																						goto IL_1e02;
																						IL_2b75:
																						array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																						goto IL_2bad;
																						IL_1d9b:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_1ddb;
																						IL_1ddb:
																						array[num6 - 2] = 3;
																						goto IL_1def;
																						IL_1def:
																						num6--;
																						goto end_IL_0a49;
																						IL_1e02:
																						if (41 < b)
																						{
																							break;
																						}
																						goto IL_1e10;
																						IL_1e10:
																						if (41 > b)
																						{
																							break;
																						}
																						goto IL_1e1e;
																						IL_1e1e:
																						array[num6 - 1] = 3;
																						goto IL_1e32;
																						IL_1e32:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_1e71;
																						IL_1e71:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_1e84:
																						if (43 >= b)
																						{
																							goto IL_1e92;
																						}
																						goto IL_1f21;
																						IL_1e92:
																						if (43 > b)
																						{
																							break;
																						}
																						goto IL_1ea0;
																						IL_1ea0:
																						ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1f0e;
																						IL_1f0e:
																						num6 -= 2;
																						goto end_IL_0a49;
																						IL_1f21:
																						if (44 < b)
																						{
																							break;
																						}
																						goto IL_1f2f;
																						IL_1f2f:
																						if (44 > b)
																						{
																							break;
																						}
																						goto IL_1f3d;
																						IL_1f3d:
																						array[num6 - 1] = 3;
																						goto IL_1f51;
																						IL_1f51:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_1f90;
																						IL_1f90:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_1fa3:
																						if (49 >= b)
																						{
																							goto IL_1fb1;
																						}
																						goto IL_218f;
																						IL_1fb1:
																						if (49 <= b)
																						{
																							goto IL_1fbc;
																						}
																						goto IL_2020;
																						IL_1fbc:
																						array[num6 - 1] = 4;
																						goto IL_1fd0;
																						IL_1fd0:
																						array2[num6 - 1] = ((delegate*<Vector3, Vector3>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 1]);
																						goto IL_200d;
																						IL_200d:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2020:
																						if (47 >= b)
																						{
																							goto IL_202e;
																						}
																						goto IL_2118;
																						IL_202e:
																						if (47 <= b)
																						{
																							goto IL_2039;
																						}
																						goto IL_209d;
																						IL_2039:
																						array[num6 - 1] = 4;
																						goto IL_204d;
																						IL_204d:
																						array2[num6 - 1] = ((delegate*<Transform, Vector3>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																						goto IL_208a;
																						IL_208a:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_209d:
																						if (46 < b)
																						{
																							break;
																						}
																						goto IL_20ab;
																						IL_20ab:
																						if (46 > b)
																						{
																							break;
																						}
																						goto IL_20b9;
																						IL_20b9:
																						array2[num6 - 1] = ((delegate*<VRRig, Transform>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																						goto IL_20f1;
																						IL_20f1:
																						array[num6 - 1] = 5;
																						goto IL_2105;
																						IL_2105:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2118:
																						if (48 < b)
																						{
																							break;
																						}
																						goto IL_2126;
																						IL_2126:
																						if (48 > b)
																						{
																							break;
																						}
																						num = 48;
																						goto IL_213d;
																						IL_2bad:
																						array[num6 - 1] = 5;
																						goto IL_2bc1;
																						IL_213d:
																						array[num6] = 4;
																						goto IL_214b;
																						IL_214b:
																						array2[num6] = ((delegate*<Vector3>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])();
																						goto IL_216e;
																						IL_216e:
																						num6++;
																						goto IL_217c;
																						IL_217c:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_218f:
																						if (51 >= b)
																						{
																							goto IL_219d;
																						}
																						goto IL_22f6;
																						IL_219d:
																						if (51 <= b)
																						{
																							goto IL_21a8;
																						}
																						goto IL_220d;
																						IL_21a8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (((delegate*<Class18, bool>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Class18)array2[num6 - 1]) ? 1 : 0);
																						goto IL_21e6;
																						IL_21e6:
																						array[num6 - 1] = 0;
																						goto IL_21fa;
																						IL_21fa:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_220d:
																						if (50 < b)
																						{
																							break;
																						}
																						goto IL_221b;
																						IL_221b:
																						if (50 > b)
																						{
																							break;
																						}
																						goto IL_2229;
																						IL_2229:
																						array[num6 - 3] = 0;
																						goto IL_223d;
																						IL_223d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 3]) = (((delegate*<Vector3, Vector3, ref RaycastHit, bool>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 3], (Vector3)array2[num6 - 2], ref ((delegate*<object, IntPtr, object[], int[], ref RaycastHit>)OrderablePartitionerSafeViewOfFileHandle[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4)) ? 1 : 0);
																						goto IL_22d5;
																						IL_22d5:
																						num6 -= 2;
																						goto IL_22e3;
																						IL_22e3:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_22f6:
																						if (52 >= b)
																						{
																							goto IL_2304;
																						}
																						goto IL_238c;
																						IL_2304:
																						if (52 > b)
																						{
																							break;
																						}
																						num = 451;
																						goto IL_231b;
																						IL_2bc1:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_231b:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_2379;
																						IL_2379:
																						num6--;
																						goto end_IL_0a49;
																						IL_238c:
																						if (53 < b)
																						{
																							break;
																						}
																						goto IL_239a;
																						IL_239a:
																						if (53 > b)
																						{
																							break;
																						}
																						goto IL_23a8;
																						IL_23a8:
																						array[num6 - 1] = 3;
																						goto IL_23bc;
																						IL_23bc:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						num = 402;
																						goto IL_2404;
																						IL_2404:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2417:
																						if (63 >= b)
																						{
																							goto IL_2425;
																						}
																						goto IL_2869;
																						IL_2425:
																						if (63 <= b)
																						{
																							goto IL_2430;
																						}
																						goto IL_249f;
																						IL_2430:
																						array[num6 - 1] = 0;
																						num = 350;
																						goto IL_244d;
																						IL_244d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_248c;
																						IL_248c:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_249f:
																						if (58 < b)
																						{
																							goto IL_24ad;
																						}
																						goto IL_2693;
																						IL_24ad:
																						if (60 >= b)
																						{
																							goto IL_24bb;
																						}
																						goto IL_2592;
																						IL_24bb:
																						if (60 > b)
																						{
																							goto IL_24c6;
																						}
																						goto IL_252c;
																						IL_24c6:
																						if (59 < b)
																						{
																							break;
																						}
																						goto IL_24d4;
																						IL_24d4:
																						if (59 > b)
																						{
																							break;
																						}
																						num = 169;
																						goto IL_24eb;
																						IL_2bd1:
																						if (71 < b)
																						{
																							break;
																						}
																						goto IL_2bdc;
																						IL_24eb:
																						((Class18)array2[num6 - 2]).bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0;
																						goto IL_2519;
																						IL_2519:
																						num6 -= 2;
																						goto end_IL_0a49;
																						IL_252c:
																						array[num6 - 1] = 3;
																						goto IL_2540;
																						IL_2540:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_257f;
																						IL_257f:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2592:
																						if (61 >= b)
																						{
																							goto IL_259d;
																						}
																						goto IL_2611;
																						IL_259d:
																						if (61 > b)
																						{
																							break;
																						}
																						goto IL_25ab;
																						IL_25ab:
																						array[num6 - 1] = 3;
																						goto IL_25bf;
																						IL_25bf:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<XRNode, float>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(XRNode*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_25fe;
																						IL_25fe:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2611:
																						if (62 < b)
																						{
																							break;
																						}
																						goto IL_261f;
																						IL_261f:
																						if (62 > b)
																						{
																							break;
																						}
																						goto IL_262d;
																						IL_262d:
																						array[num6 - 1] = 3;
																						goto IL_2641;
																						IL_2641:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_2680;
																						IL_2680:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2693:
																						if (58 <= b)
																						{
																							goto IL_269e;
																						}
																						goto IL_2703;
																						IL_269e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (((delegate*<Class18, bool>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((Class18)array2[num6 - 1]) ? 1 : 0);
																						goto IL_26dc;
																						IL_26dc:
																						array[num6 - 1] = 0;
																						goto IL_26f0;
																						IL_26f0:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2703:
																						if (56 >= b)
																						{
																							goto IL_2711;
																						}
																						goto IL_2809;
																						IL_2711:
																						if (56 <= b)
																						{
																							goto IL_271c;
																						}
																						goto IL_2778;
																						IL_271c:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])();
																						goto IL_2740;
																						IL_2740:
																						array[num6] = 3;
																						num = 298;
																						goto IL_2757;
																						IL_2757:
																						num6++;
																						goto IL_2765;
																						IL_2765:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2778:
																						if (55 < b)
																						{
																							break;
																						}
																						goto IL_2786;
																						IL_2786:
																						if (55 > b)
																						{
																							break;
																						}
																						goto IL_2794;
																						IL_2794:
																						ptr2 = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_27f6;
																						IL_27f6:
																						num6 -= 2;
																						goto end_IL_0a49;
																						IL_2809:
																						if (57 < b)
																						{
																							break;
																						}
																						goto IL_2817;
																						IL_2817:
																						if (57 > b)
																						{
																							break;
																						}
																						goto IL_2825;
																						IL_2825:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_2850;
																						IL_2850:
																						array[num6 - 1] = 0;
																						goto end_IL_0a49;
																						IL_2869:
																						if (67 >= b)
																						{
																							goto IL_2877;
																						}
																						goto IL_2a43;
																						IL_2877:
																						if (67 > b)
																						{
																							goto IL_2885;
																						}
																						goto IL_29dd;
																						IL_2885:
																						if (65 >= b)
																						{
																							goto IL_2893;
																						}
																						goto IL_2950;
																						IL_2893:
																						if (65 > b)
																						{
																							goto IL_28a1;
																						}
																						goto IL_2923;
																						IL_28a1:
																						if (64 < b)
																						{
																							break;
																						}
																						goto IL_28af;
																						IL_28af:
																						if (64 > b)
																						{
																							break;
																						}
																						goto IL_28bd;
																						IL_28bd:
																						array[num6 - 1] = 3;
																						goto IL_28d1;
																						IL_28d1:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<XRNode, float>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(XRNode*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_2910;
																						IL_2910:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2923:
																						global::_003CModule_003E.float_38 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_293d;
																						IL_293d:
																						num6--;
																						goto end_IL_0a49;
																						IL_2950:
																						if (66 < b)
																						{
																							break;
																						}
																						goto IL_295e;
																						IL_295e:
																						if (66 > b)
																						{
																							break;
																						}
																						goto IL_296c;
																						IL_296c:
																						array2[num6 - 1] = ((delegate*<VRRig, Transform>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																						num = 69;
																						goto IL_29ad;
																						IL_29ad:
																						array[num6 - 1] = 5;
																						goto IL_29c1;
																						IL_29c1:
																						ptr2 += 8;
																						num = 469;
																						goto end_IL_0a49;
																						IL_29dd:
																						array[num6 - 1] = 3;
																						goto IL_29f1;
																						IL_29f1:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_2a30;
																						IL_2a30:
																						ptr2 += 8;
																						goto end_IL_0a49;
																						IL_2a43:
																						if (69 >= b)
																						{
																							goto IL_2a51;
																						}
																						goto IL_2b5f;
																						IL_2a51:
																						if (69 > b)
																						{
																							goto IL_2a5f;
																						}
																						num = 281;
																						goto IL_2af9;
																						IL_2a5f:
																						if (68 < b)
																						{
																							break;
																						}
																						goto IL_2a6d;
																						IL_2a6d:
																						if (68 > b)
																						{
																							break;
																						}
																						goto IL_2a7b;
																						IL_2a7b:
																						ptr2 = ((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]))) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_2add;
																						IL_2add:
																						num6 -= 2;
																						goto end_IL_0a49;
																						IL_2bdc:
																						if (71 <= b)
																						{
																							num = 125;
																						}
																						break;
																						IL_2af9:
																						array[num6 - 1] = 3;
																						goto IL_2b0d;
																						IL_2b0d:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)OrderablePartitionerSafeViewOfFileHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_2b4c;
																						IL_2b4c:
																						ptr2 += 8;
																						goto end_IL_0a49;
																					}
																					break;
																					IL_0a16:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0a49;
																			continue;
																			end_IL_0a29:
																			break;
																		}
																		continue;
																		end_IL_0a39:
																		break;
																	}
																	continue;
																	end_IL_0a49:
																	break;
																}
																continue;
															}
															num = 553;
															return;
															continue;
															end_IL_2c03:
															break;
														}
														continue;
														end_IL_2c16:
														break;
													}
													continue;
													end_IL_2c20:
													break;
												}
												continue;
												end_IL_2c2b:
												break;
											}
											continue;
											end_IL_2c3b:
											break;
										}
										continue;
										end_IL_2c4b:
										break;
									}
									continue;
									end_IL_2c5b:
									break;
								}
								continue;
								end_IL_2c6b:
								break;
							}
							continue;
							end_IL_2c84:
							break;
						}
						continue;
						end_IL_2c94:
						break;
					}
					continue;
					end_IL_2ca4:
					break;
				}
				continue;
				end_IL_2cb4:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 27;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SystemProfileFrameSecurityDescriptorWithResolver.CommonProgramFilesAccountSchemaAdminsSid);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																if (b >= 1)
																{
																	while (true)
																	{
																		if (b <= 16)
																		{
																			while (true)
																			{
																				if (8 >= b)
																				{
																					while (true)
																					{
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02e7:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_02d4:
																										if (4 > b)
																										{
																											num = 169;
																											while (true)
																											{
																												if (num != 169)
																												{
																													if (num != 1150)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 86:
																														goto IL_02d4;
																													case 107:
																													case 126:
																														goto IL_02e7;
																													case 48:
																														goto end_IL_02e7;
																													case 152:
																														goto end_IL_02f4;
																													case 150:
																														goto end_IL_0304;
																													case 6:
																														goto end_IL_0314;
																													case 12:
																														goto end_IL_0324;
																													case 50:
																													case 96:
																														goto end_IL_0334;
																													case 77:
																													case 114:
																														goto IL_034f;
																													case 63:
																													case 65:
																														goto IL_035a;
																													case 84:
																														goto IL_0368;
																													case 87:
																														goto end_IL_02c1;
																													case 45:
																														goto IL_0386;
																													case 30:
																														goto IL_0394;
																													case 64:
																													case 110:
																														goto IL_03a2;
																													case 58:
																													case 116:
																														goto IL_03e7;
																													case 46:
																														goto IL_0427;
																													case 102:
																													case 121:
																														goto IL_043d;
																													case 115:
																														goto IL_047d;
																													case 117:
																														goto IL_0491;
																													case 132:
																														goto IL_04ad;
																													case 141:
																														goto IL_04c0;
																													case 69:
																														goto IL_04d4;
																													case 21:
																														goto IL_04e7;
																													case 32:
																														goto IL_04f5;
																													case 10:
																														goto IL_0500;
																													case 31:
																														goto IL_050e;
																													case 108:
																													case 146:
																														goto IL_0521;
																													case 140:
																														goto IL_0561;
																													case 54:
																														goto IL_0575;
																													case 130:
																														goto IL_0588;
																													case 106:
																														goto IL_0596;
																													case 35:
																													case 42:
																														goto IL_05a4;
																													case 93:
																														goto IL_05cd;
																													case 56:
																														goto IL_05db;
																													case 97:
																													case 147:
																														goto IL_05ee;
																													case 66:
																														goto IL_05fc;
																													case 14:
																														goto IL_0628;
																													case 23:
																														goto IL_0632;
																													case 95:
																														goto IL_0640;
																													case 40:
																													case 52:
																														goto IL_0653;
																													case 22:
																													case 153:
																														goto IL_0666;
																													case 76:
																													case 89:
																														goto IL_0674;
																													case 80:
																														goto IL_0682;
																													case 5:
																													case 78:
																														goto IL_068d;
																													case 101:
																														goto IL_069b;
																													case 3:
																													case 160:
																														goto IL_06a9;
																													case 85:
																														goto IL_06c1;
																													case 72:
																														goto IL_06cf;
																													case 71:
																														goto IL_06dd;
																													case 55:
																													case 57:
																														goto IL_06f0;
																													case 39:
																														goto IL_071e;
																													case 8:
																													case 159:
																														goto IL_0731;
																													case 33:
																													case 74:
																														goto IL_0745;
																													case 119:
																														goto IL_075e;
																													case 16:
																													case 136:
																														goto IL_076c;
																													case 37:
																														goto IL_0788;
																													case 129:
																													case 138:
																														goto IL_0796;
																													case 151:
																														goto IL_07c4;
																													case 155:
																														goto IL_07d7;
																													case 44:
																														goto IL_07e5;
																													case 25:
																													case 144:
																														goto IL_07f3;
																													case 4:
																														goto IL_0801;
																													case 92:
																													case 109:
																														goto IL_080f;
																													case 68:
																														goto IL_0823;
																													case 122:
																														goto IL_0862;
																													case 34:
																														goto IL_0875;
																													case 13:
																													case 61:
																														goto IL_0880;
																													case 131:
																														goto IL_08e2;
																													case 11:
																													case 161:
																														goto IL_08fe;
																													case 105:
																														goto IL_0909;
																													case 15:
																													case 111:
																														goto IL_0914;
																													case 94:
																														goto IL_0954;
																													case 148:
																														goto IL_0968;
																													case 0:
																													case 9:
																													case 18:
																													case 19:
																													case 36:
																													case 47:
																													case 49:
																													case 53:
																													case 59:
																													case 62:
																													case 67:
																													case 70:
																													case 75:
																													case 81:
																													case 82:
																													case 103:
																													case 112:
																													case 123:
																													case 127:
																													case 128:
																													case 133:
																													case 134:
																													case 137:
																													case 139:
																													case 142:
																													case 143:
																													case 149:
																													case 162:
																														goto IL_0981;
																													case 120:
																														goto IL_099a;
																													case 156:
																														goto IL_09a8;
																													case 88:
																														goto IL_09b6;
																													case 7:
																													case 17:
																													case 20:
																													case 24:
																													case 29:
																													case 38:
																													case 41:
																													case 43:
																													case 73:
																													case 98:
																													case 99:
																													case 100:
																													case 104:
																													case 118:
																													case 125:
																													case 135:
																													case 145:
																													case 157:
																													case 158:
																														goto end_IL_0344;
																													case 154:
																														goto end_IL_09c4;
																													case 28:
																														goto end_IL_09d7;
																													case 90:
																														goto end_IL_09e1;
																													case 1:
																														goto end_IL_09ec;
																													case 51:
																														goto end_IL_09fc;
																													case 113:
																													case 124:
																														goto end_IL_0a0c;
																													case 91:
																														goto end_IL_0a1c;
																													case 60:
																													case 79:
																														goto end_IL_0a2c;
																													case 26:
																														goto end_IL_0a3c;
																													case 27:
																														goto end_IL_0a4c;
																													case 2:
																													case 83:
																														return;
																													}
																													continue;
																												}
																												goto IL_04e7;
																												IL_05cd:
																												ptr2 += 8;
																												goto IL_05db;
																												IL_05db:
																												num5--;
																												goto end_IL_0344;
																												IL_04e7:
																												if (2 >= b)
																												{
																													goto IL_04f5;
																												}
																												goto IL_0588;
																												IL_04f5:
																												if (2 > b)
																												{
																													goto IL_0500;
																												}
																												goto IL_0521;
																												IL_0500:
																												if (1 >= b)
																												{
																													goto IL_050e;
																												}
																												goto IL_0981;
																												IL_050e:
																												if (1 <= b)
																												{
																												}
																												goto IL_0981;
																												IL_0521:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0561;
																												IL_0561:
																												array[num5 - 2] = 0;
																												goto IL_0575;
																												IL_0575:
																												num5--;
																												goto end_IL_0344;
																												IL_0588:
																												if (3 >= b)
																												{
																													goto IL_0596;
																												}
																												goto IL_0981;
																												IL_0596:
																												if (3 <= b)
																												{
																													goto IL_05a4;
																												}
																												goto IL_0981;
																												IL_05a4:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_05cd;
																												continue;
																												end_IL_02c1:
																												break;
																											}
																											break;
																										}
																										goto IL_05ee;
																										IL_0632:
																										num5++;
																										goto IL_0640;
																										IL_0640:
																										ptr2 += 8;
																										goto end_IL_0344;
																										IL_05ee:
																										array[num5] = 0;
																										goto IL_05fc;
																										IL_05fc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										num = 14;
																										goto IL_0628;
																										IL_0628:
																										array2[num5] = null;
																										goto IL_0632;
																									}
																									goto IL_037b;
																								}
																								goto IL_034f;
																								IL_04ad:
																								num5--;
																								goto end_IL_0344;
																								IL_034f:
																								if (6 < b)
																								{
																									goto IL_035a;
																								}
																								goto IL_037b;
																								IL_035a:
																								if (7 >= b)
																								{
																									goto IL_0368;
																								}
																								goto IL_0981;
																								IL_0368:
																								if (7 <= b)
																								{
																									goto IL_043d;
																								}
																								goto IL_0981;
																								IL_043d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_047d;
																								IL_047d:
																								array[num5 - 2] = 0;
																								goto IL_0491;
																								IL_0491:
																								num5--;
																								num = 158;
																								goto end_IL_0344;
																								IL_037b:
																								if (6 > b)
																								{
																									goto IL_0386;
																								}
																								goto IL_03e7;
																								IL_0386:
																								if (5 >= b)
																								{
																									goto IL_0394;
																								}
																								goto IL_0981;
																								IL_0394:
																								if (5 <= b)
																								{
																									goto IL_03a2;
																								}
																								goto IL_0981;
																								IL_03a2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04c0;
																								IL_04c0:
																								array[num5 - 2] = 0;
																								goto IL_04d4;
																								IL_04d4:
																								num5--;
																								goto end_IL_0344;
																								IL_03e7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0427;
																								IL_0427:
																								array[num5 - 2] = 0;
																								goto IL_04ad;
																								continue;
																								end_IL_02e7:
																								break;
																							}
																							continue;
																						}
																						goto IL_0653;
																						IL_0653:
																						num5--;
																						goto end_IL_0344;
																						continue;
																						end_IL_02f4:
																						break;
																					}
																					continue;
																				}
																				goto IL_0666;
																				IL_0909:
																				if (9 <= b)
																				{
																					goto IL_0914;
																				}
																				goto IL_0981;
																				IL_0666:
																				if (12 < b)
																				{
																					goto IL_0674;
																				}
																				goto IL_07d7;
																				IL_0674:
																				if (14 >= b)
																				{
																					goto IL_0682;
																				}
																				goto IL_0731;
																				IL_0682:
																				if (14 > b)
																				{
																					goto IL_068d;
																				}
																				goto IL_06f0;
																				IL_068d:
																				if (13 >= b)
																				{
																					goto IL_069b;
																				}
																				goto IL_0981;
																				IL_069b:
																				if (13 <= b)
																				{
																					goto IL_06a9;
																				}
																				goto IL_0981;
																				IL_06a9:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_06c1;
																				IL_06c1:
																				array[num5] = 5;
																				goto IL_06cf;
																				IL_06cf:
																				num5++;
																				goto IL_06dd;
																				IL_06dd:
																				ptr2 += 8;
																				goto end_IL_0344;
																				IL_06f0:
																				((Class18)array2[num5 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																				goto IL_071e;
																				IL_071e:
																				num5 -= 2;
																				goto end_IL_0344;
																				IL_0731:
																				if (15 < b)
																				{
																					num = 74;
																					goto IL_0745;
																				}
																				goto IL_0788;
																				IL_0914:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0954;
																				IL_0745:
																				if (16 >= b)
																				{
																					goto IL_075e;
																				}
																				num = 103;
																				goto IL_0981;
																				IL_0954:
																				array[num5 - 2] = 0;
																				goto IL_0968;
																				IL_075e:
																				if (16 <= b)
																				{
																					goto IL_076c;
																				}
																				goto IL_0981;
																				IL_076c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0344;
																				IL_0788:
																				if (15 <= b)
																				{
																					goto IL_0796;
																				}
																				goto IL_0981;
																				IL_0796:
																				((Class18)array2[num5 - 2]).bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																				goto IL_07c4;
																				IL_07c4:
																				num5 -= 2;
																				goto end_IL_0344;
																				IL_07d7:
																				if (12 <= b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_07e5;
																				IL_07e5:
																				if (10 < b)
																				{
																					goto IL_07f3;
																				}
																				goto IL_0875;
																				IL_07f3:
																				if (11 >= b)
																				{
																					goto IL_0801;
																				}
																				goto IL_0981;
																				IL_0801:
																				if (11 <= b)
																				{
																					goto IL_080f;
																				}
																				goto IL_0981;
																				IL_080f:
																				array[num5 - 1] = 0;
																				goto IL_0823;
																				IL_0823:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)IMPLTYPEFLAGFRESTRICTEDDivRem[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0862;
																				IL_0862:
																				ptr2 += 8;
																				goto end_IL_0344;
																				IL_0875:
																				if (10 <= b)
																				{
																					goto IL_0880;
																				}
																				num = 161;
																				goto IL_08fe;
																				IL_0880:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_08e2;
																				IL_08e2:
																				num5 -= 2;
																				goto end_IL_0344;
																				IL_0968:
																				num5--;
																				goto end_IL_0344;
																				IL_08fe:
																				if (9 >= b)
																				{
																					goto IL_0909;
																				}
																				goto IL_0981;
																				continue;
																				end_IL_0304:
																				break;
																			}
																			continue;
																		}
																		num = 128;
																		goto IL_0981;
																		continue;
																		end_IL_0314:
																		break;
																	}
																	continue;
																}
																goto IL_0981;
																IL_09b6:
																ptr2 += 8;
																goto end_IL_0344;
																IL_0981:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_099a;
																IL_099a:
																array[num5] = 0;
																goto IL_09a8;
																IL_09a8:
																num5++;
																goto IL_09b6;
																continue;
																end_IL_0324:
																break;
															}
															continue;
															end_IL_0334:
															break;
														}
														continue;
														end_IL_0344:
														break;
													}
													continue;
													end_IL_09c4:
													break;
												}
												continue;
												end_IL_09d7:
												break;
											}
											continue;
											end_IL_09e1:
											break;
										}
										continue;
										end_IL_09ec:
										break;
									}
									continue;
									end_IL_09fc:
									break;
								}
								continue;
								end_IL_0a0c:
								break;
							}
							continue;
							end_IL_0a1c:
							break;
						}
						continue;
						end_IL_0a2c:
						break;
					}
					continue;
					end_IL_0a3c:
					break;
				}
				continue;
				end_IL_0a4c:
				break;
			}
		}
	}

	public Class18()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 41;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								IL_05df:
								long[] array4 = new long[2];
								while (true)
								{
									IL_05ca:
									array3[0] = int_2;
									while (true)
									{
										IL_05bf:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReportEventBaseChannelObjectWithProperties.EnumeratorToIteratorAdapterCookiePath);
										while (true)
										{
											IL_05b5:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_05a2:
												if (num4 != 1)
												{
													while (true)
													{
														IL_01d7:
														num = 110;
														while (true)
														{
															if (num != 110)
															{
																if (num != 1091)
																{
																	break;
																}
																switch (num)
																{
																case 88:
																	goto IL_01d7;
																case 3:
																	goto IL_01eb;
																case 86:
																	goto IL_01f9;
																case 23:
																	goto IL_0207;
																case 55:
																	goto IL_0215;
																case 56:
																	goto IL_0223;
																case 18:
																	goto IL_0231;
																case 63:
																case 81:
																	goto IL_023f;
																case 79:
																	goto IL_024a;
																case 48:
																case 68:
																	goto IL_0258;
																case 47:
																	goto IL_0298;
																case 46:
																	goto IL_02ac;
																case 37:
																case 84:
																	goto IL_02bf;
																case 58:
																	goto IL_02cd;
																case 78:
																case 85:
																	goto IL_02db;
																case 67:
																	goto IL_02fe;
																case 4:
																	goto IL_030c;
																case 94:
																	goto IL_031a;
																case 12:
																case 22:
																	goto IL_032d;
																case 32:
																	goto IL_038f;
																case 14:
																	goto IL_03a2;
																case 71:
																	goto IL_03ad;
																case 30:
																case 91:
																	goto IL_03c4;
																case 38:
																	goto IL_03e0;
																case 43:
																	goto IL_03ee;
																case 90:
																	goto IL_0401;
																case 49:
																case 87:
																	goto IL_040f;
																case 31:
																	goto IL_041d;
																case 35:
																case 99:
																	goto IL_0428;
																case 54:
																	goto IL_0451;
																case 27:
																	goto IL_045f;
																case 44:
																	goto IL_0472;
																case 98:
																	goto IL_0480;
																case 39:
																case 64:
																	goto IL_048b;
																case 42:
																	goto IL_04a4;
																case 16:
																	goto IL_04b2;
																case 69:
																	goto IL_04c0;
																case 2:
																	goto IL_04e1;
																case 66:
																case 80:
																	goto IL_04ec;
																case 92:
																	goto IL_04fa;
																case 59:
																	goto IL_050d;
																case 1:
																case 52:
																	goto IL_0518;
																case 26:
																case 75:
																	goto IL_052d;
																case 5:
																	goto IL_053b;
																case 74:
																	goto IL_055e;
																case 57:
																	goto IL_0571;
																case 82:
																	goto IL_057f;
																case 6:
																case 7:
																case 9:
																case 11:
																case 13:
																case 15:
																case 25:
																case 36:
																case 45:
																case 50:
																case 51:
																case 53:
																case 60:
																case 62:
																case 65:
																case 70:
																case 73:
																case 76:
																case 102:
																	goto IL_058f;
																case 10:
																case 19:
																case 20:
																case 21:
																case 28:
																case 29:
																case 33:
																case 83:
																case 89:
																case 93:
																case 96:
																case 97:
																case 100:
																	goto IL_05a2;
																case 77:
																	goto IL_05b5;
																case 95:
																	goto IL_05bf;
																case 34:
																	goto IL_05ca;
																case 103:
																	goto IL_05df;
																case 8:
																case 24:
																	goto end_IL_01c7;
																case 17:
																	goto end_IL_05ef;
																case 61:
																case 72:
																	goto end_IL_05ff;
																case 40:
																	goto end_IL_060f;
																case 41:
																	goto end_IL_061f;
																case 0:
																case 101:
																	goto IL_063a;
																}
																continue;
															}
															b = *ptr2;
															goto IL_01eb;
															IL_053b:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_055e;
															IL_0571:
															num5++;
															goto IL_057f;
															IL_055e:
															array2[num5] = null;
															num = 57;
															goto IL_0571;
															IL_01eb:
															ptr2++;
															goto IL_01f9;
															IL_01f9:
															if (b >= 1)
															{
																goto IL_0207;
															}
															goto IL_058f;
															IL_0207:
															if (b <= 10)
															{
																goto IL_0215;
															}
															goto IL_058f;
															IL_0215:
															if (5 < b)
															{
																goto IL_0223;
															}
															goto IL_0401;
															IL_0223:
															if (8 >= b)
															{
																goto IL_0231;
															}
															goto IL_03a2;
															IL_0231:
															if (8 > b)
															{
																goto IL_023f;
															}
															goto IL_032d;
															IL_023f:
															if (6 >= b)
															{
																goto IL_024a;
															}
															goto IL_02bf;
															IL_024a:
															if (6 <= b)
															{
																goto IL_0258;
															}
															goto IL_058f;
															IL_0258:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0298;
															IL_0298:
															array[num5 - 2] = 0;
															goto IL_02ac;
															IL_02ac:
															num5--;
															goto IL_05a2;
															IL_02bf:
															if (7 >= b)
															{
																goto IL_02cd;
															}
															goto IL_058f;
															IL_02cd:
															if (7 <= b)
															{
																goto IL_02db;
															}
															goto IL_058f;
															IL_02db:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_02fe;
															IL_02fe:
															array[num5] = 0;
															goto IL_030c;
															IL_030c:
															num5++;
															goto IL_031a;
															IL_031a:
															ptr2 += 8;
															goto IL_05a2;
															IL_032d:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_038f;
															IL_038f:
															num5 -= 2;
															goto IL_05a2;
															IL_03a2:
															if (9 >= b)
															{
																goto IL_03ad;
															}
															goto IL_03e0;
															IL_03ad:
															if (9 <= b)
															{
																num = 30;
																goto IL_03c4;
															}
															goto IL_058f;
															IL_057f:
															ptr2 += 8;
															goto IL_05a2;
															IL_03c4:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto IL_05a2;
															IL_03e0:
															if (10 >= b)
															{
																goto IL_03ee;
															}
															goto IL_058f;
															IL_03ee:
															if (10 <= b)
															{
															}
															goto IL_058f;
															IL_0401:
															if (5 > b)
															{
																goto IL_040f;
															}
															goto IL_052d;
															IL_040f:
															if (2 >= b)
															{
																goto IL_041d;
															}
															goto IL_04e1;
															IL_041d:
															if (2 <= b)
															{
																goto IL_0428;
															}
															goto IL_0472;
															IL_0428:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0451;
															IL_0451:
															ptr2 += 8;
															goto IL_045f;
															IL_045f:
															num5--;
															goto IL_05a2;
															IL_0472:
															if (1 >= b)
															{
																goto IL_0480;
															}
															goto IL_058f;
															IL_0480:
															if (1 <= b)
															{
																goto IL_048b;
															}
															num = 9;
															goto IL_058f;
															IL_048b:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_04a4;
															IL_04a4:
															array[num5] = 0;
															goto IL_04b2;
															IL_04b2:
															num5++;
															goto IL_04c0;
															IL_04c0:
															ptr2 += 8;
															goto IL_05a2;
															IL_058f:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_05a2;
															IL_04e1:
															if (3 < b)
															{
																goto IL_04ec;
															}
															goto IL_050d;
															IL_04ec:
															if (4 >= b)
															{
																goto IL_04fa;
															}
															goto IL_058f;
															IL_04fa:
															if (4 <= b)
															{
																goto IL_05a2;
															}
															goto IL_058f;
															IL_050d:
															if (3 <= b)
															{
																goto IL_0518;
															}
															goto IL_058f;
															IL_0518:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_05a2;
															IL_052d:
															array[num5] = 0;
															goto IL_053b;
															continue;
															end_IL_01c7:
															break;
														}
														break;
													}
													break;
												}
												goto IL_063a;
												IL_063a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_05ef:
							break;
						}
						continue;
						end_IL_05ff:
						break;
					}
					continue;
					end_IL_060f:
					break;
				}
				continue;
				end_IL_061f:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 58;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 57;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								num = 40;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LineSeparatorremoveDomainUnload.ContractClassForAttributeIsBoxed);
											num = 101;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 131;
															while (true)
															{
																if (num != 131)
																{
																	if (num != 1112)
																	{
																		goto IL_06a7;
																	}
																	switch (num)
																	{
																	case 1:
																	case 62:
																		goto end_IL_021b;
																	case 86:
																		goto IL_024d;
																	case 45:
																		goto IL_0264;
																	case 65:
																		goto IL_0272;
																	case 17:
																		goto IL_0280;
																	case 26:
																	case 90:
																		goto IL_028e;
																	case 56:
																	case 73:
																		goto IL_029c;
																	case 28:
																	case 55:
																		goto IL_02a7;
																	case 21:
																		goto IL_02b5;
																	case 103:
																	case 108:
																		goto IL_02ce;
																	case 123:
																		goto IL_02e6;
																	case 12:
																	case 98:
																		goto IL_02f4;
																	case 88:
																		goto IL_031d;
																	case 49:
																		goto IL_032b;
																	case 106:
																		goto IL_033e;
																	case 37:
																	case 111:
																		goto IL_034c;
																	case 83:
																		goto IL_035a;
																	case 119:
																		goto IL_0368;
																	case 42:
																	case 69:
																		goto IL_0376;
																	case 54:
																		goto IL_03e4;
																	case 114:
																		goto IL_03f7;
																	case 13:
																	case 113:
																		goto IL_040a;
																	case 102:
																		goto IL_044a;
																	case 81:
																		goto IL_045e;
																	case 43:
																	case 66:
																		goto IL_0471;
																	case 50:
																		goto IL_047f;
																	case 24:
																	case 41:
																		goto IL_048a;
																	case 79:
																		goto IL_04ca;
																	case 117:
																		goto IL_04de;
																	case 30:
																	case 80:
																		goto IL_04f1;
																	case 29:
																	case 121:
																		goto IL_04fc;
																	case 5:
																		goto IL_050a;
																	case 77:
																	case 84:
																		goto IL_0518;
																	case 4:
																		goto IL_0531;
																	case 75:
																		goto IL_053f;
																	case 33:
																		goto IL_054d;
																	case 109:
																		goto IL_0560;
																	case 19:
																	case 61:
																		goto IL_056e;
																	case 35:
																		goto IL_057c;
																	case 25:
																		goto IL_059f;
																	case 3:
																		goto IL_05a9;
																	case 74:
																		goto IL_05b7;
																	case 7:
																		goto IL_05ca;
																	case 112:
																		goto IL_05d8;
																	case 10:
																	case 99:
																		goto IL_05e6;
																	case 92:
																		goto IL_05f4;
																	case 6:
																	case 51:
																		goto IL_0602;
																	case 14:
																		goto IL_0616;
																	case 52:
																		goto IL_0655;
																	case 2:
																	case 9:
																		goto IL_0668;
																	case 22:
																		goto IL_0678;
																	case 38:
																		goto IL_0683;
																	case 68:
																	case 122:
																		goto IL_068e;
																	case 0:
																	case 8:
																	case 18:
																	case 48:
																	case 67:
																	case 70:
																	case 71:
																	case 72:
																	case 78:
																	case 82:
																	case 87:
																	case 91:
																	case 94:
																	case 95:
																	case 96:
																	case 97:
																	case 105:
																	case 115:
																	case 116:
																	case 118:
																	case 124:
																		goto IL_06a7;
																	case 110:
																		goto IL_06ca;
																	case 100:
																		goto IL_06d8;
																	case 47:
																		goto IL_06e6;
																	case 16:
																	case 20:
																	case 23:
																	case 27:
																	case 32:
																	case 36:
																	case 39:
																	case 44:
																	case 46:
																	case 59:
																	case 60:
																	case 85:
																	case 93:
																	case 104:
																	case 120:
																		goto end_IL_022b;
																	case 101:
																		goto end_IL_06f4;
																	case 31:
																		goto end_IL_0707;
																	case 34:
																		goto end_IL_0711;
																	case 40:
																		goto end_IL_0725;
																	case 89:
																		goto end_IL_073a;
																	case 53:
																	case 64:
																		goto end_IL_074f;
																	case 63:
																		goto end_IL_0768;
																	case 11:
																	case 107:
																		goto end_IL_0778;
																	case 57:
																		goto end_IL_0788;
																	case 58:
																		goto end_IL_0798;
																	case 15:
																	case 76:
																		goto IL_07bc;
																	}
																	continue;
																}
																ptr2++;
																goto IL_024d;
																IL_068e:
																byte* num5 = ptr2;
																num4 = 1;
																ptr2 = num5 + -200;
																goto end_IL_022b;
																IL_06ca:
																array[num6] = 0;
																goto IL_06d8;
																IL_06a7:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_06ca;
																IL_024d:
																if (b >= 1)
																{
																	num = 45;
																	goto IL_0264;
																}
																goto IL_06a7;
																IL_06d8:
																num6++;
																goto IL_06e6;
																IL_0264:
																if (b <= 12)
																{
																	goto IL_0272;
																}
																goto IL_06a7;
																IL_0272:
																if (6 >= b)
																{
																	goto IL_0280;
																}
																goto IL_0471;
																IL_0280:
																if (6 <= b)
																{
																	goto end_IL_022b;
																}
																goto IL_028e;
																IL_028e:
																if (3 < b)
																{
																	goto IL_029c;
																}
																goto IL_033e;
																IL_029c:
																if (4 < b)
																{
																	goto IL_02a7;
																}
																goto IL_02e6;
																IL_02a7:
																if (5 >= b)
																{
																	goto IL_02b5;
																}
																goto IL_06a7;
																IL_02b5:
																if (5 <= b)
																{
																	goto IL_02ce;
																}
																num = 97;
																goto IL_06a7;
																IL_06e6:
																ptr2 += 8;
																goto end_IL_022b;
																IL_02ce:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_022b;
																IL_02e6:
																if (4 <= b)
																{
																	goto IL_02f4;
																}
																goto IL_06a7;
																IL_02f4:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_031d;
																IL_031d:
																ptr2 += 8;
																goto IL_032b;
																IL_032b:
																num6--;
																goto end_IL_022b;
																IL_033e:
																if (3 > b)
																{
																	goto IL_034c;
																}
																goto IL_040a;
																IL_034c:
																if (1 < b)
																{
																	goto IL_035a;
																}
																goto IL_03f7;
																IL_035a:
																if (2 >= b)
																{
																	goto IL_0368;
																}
																goto IL_06a7;
																IL_0368:
																if (2 <= b)
																{
																	goto IL_0376;
																}
																goto IL_06a7;
																IL_0376:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_03e4;
																IL_03e4:
																num6 -= 2;
																goto end_IL_022b;
																IL_03f7:
																if (1 > b)
																{
																}
																goto IL_06a7;
																IL_040a:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_044a;
																IL_044a:
																array[num6 - 2] = 0;
																goto IL_045e;
																IL_045e:
																num6--;
																goto end_IL_022b;
																IL_0471:
																if (9 >= b)
																{
																	goto IL_047f;
																}
																goto IL_05ca;
																IL_047f:
																if (9 <= b)
																{
																	goto IL_048a;
																}
																goto IL_04f1;
																IL_048a:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_04ca;
																IL_04ca:
																array[num6 - 2] = 0;
																goto IL_04de;
																IL_04de:
																num6--;
																goto end_IL_022b;
																IL_04f1:
																if (7 < b)
																{
																	goto IL_04fc;
																}
																goto IL_0560;
																IL_04fc:
																if (8 >= b)
																{
																	goto IL_050a;
																}
																goto IL_06a7;
																IL_050a:
																if (8 <= b)
																{
																	goto IL_0518;
																}
																goto IL_06a7;
																IL_0518:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																goto IL_0531;
																IL_0531:
																array[num6] = 0;
																goto IL_053f;
																IL_053f:
																num6++;
																goto IL_054d;
																IL_054d:
																ptr2 += 8;
																goto end_IL_022b;
																IL_0560:
																if (7 <= b)
																{
																	goto IL_056e;
																}
																goto IL_06a7;
																IL_056e:
																array[num6] = 0;
																goto IL_057c;
																IL_057c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_059f;
																IL_059f:
																array2[num6] = null;
																goto IL_05a9;
																IL_05a9:
																num6++;
																goto IL_05b7;
																IL_05b7:
																ptr2 += 8;
																goto end_IL_022b;
																IL_05ca:
																if (11 >= b)
																{
																	goto IL_05d8;
																}
																goto IL_0678;
																IL_05d8:
																if (11 > b)
																{
																	goto IL_05e6;
																}
																goto IL_0668;
																IL_05e6:
																if (10 >= b)
																{
																	goto IL_05f4;
																}
																goto IL_06a7;
																IL_05f4:
																if (10 <= b)
																{
																	goto IL_0602;
																}
																goto IL_06a7;
																IL_0602:
																array[num6 - 1] = 0;
																goto IL_0616;
																IL_0616:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)IResourceReadergetStructuralEqualityComparer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																goto IL_0655;
																IL_0655:
																ptr2 += 8;
																goto end_IL_022b;
																IL_0668:
																num6--;
																goto end_IL_022b;
																IL_0678:
																if (12 >= b)
																{
																	goto IL_0683;
																}
																goto IL_06a7;
																IL_0683:
																if (12 <= b)
																{
																	goto IL_068e;
																}
																goto IL_06a7;
																continue;
																end_IL_021b:
																break;
															}
															continue;
															end_IL_022b:
															break;
														}
														continue;
													}
													goto IL_07bc;
													IL_07bc:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_06f4:
													break;
												}
												continue;
												end_IL_0707:
												break;
											}
											continue;
											end_IL_0711:
											break;
										}
										continue;
										end_IL_0725:
										break;
									}
									continue;
									end_IL_073a:
									break;
								}
								continue;
								end_IL_074f:
								break;
							}
							continue;
							end_IL_0768:
							break;
						}
						continue;
						end_IL_0778:
						break;
					}
					continue;
					end_IL_0788:
					break;
				}
				continue;
				end_IL_0798:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 36;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 46;
								while (true)
								{
									array3[0] = int_2;
									num = 23;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DMRuntimeCompatibilityAttribute.GetRuntimeEventsPathDiscovery);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 10;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 81;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0285:
																if (b >= 1)
																{
																	while (b <= 12)
																	{
																		while (true)
																		{
																			IL_0268:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_025b:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_024b:
																							if (11 >= b)
																							{
																								while (true)
																								{
																									IL_023b:
																									if (11 > b)
																									{
																										while (10 >= b)
																										{
																											while (10 <= b)
																											{
																												num = 122;
																												while (true)
																												{
																													if (num != 122)
																													{
																														if (num != 1103)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 78:
																															goto IL_0218;
																														case 57:
																															goto IL_022b;
																														case 43:
																															goto IL_023b;
																														case 20:
																															goto IL_024b;
																														case 80:
																															goto IL_025b;
																														case 44:
																															goto IL_0268;
																														case 99:
																															goto IL_0275;
																														case 71:
																															goto IL_0285;
																														case 81:
																															goto end_IL_0285;
																														case 12:
																														case 39:
																															goto end_IL_0295;
																														case 7:
																															goto IL_02b9;
																														case 63:
																															goto IL_02cc;
																														case 19:
																														case 26:
																															goto IL_02d7;
																														case 40:
																															goto IL_02eb;
																														case 11:
																															goto IL_032a;
																														case 68:
																															goto IL_033d;
																														case 61:
																															goto IL_0348;
																														case 18:
																															goto IL_0356;
																														case 67:
																														case 79:
																															goto IL_0369;
																														case 93:
																															goto IL_0385;
																														case 72:
																														case 96:
																															goto IL_0395;
																														case 8:
																														case 102:
																															goto IL_03a5;
																														case 82:
																															goto IL_03c8;
																														case 32:
																															goto IL_03d6;
																														case 104:
																															goto IL_03e4;
																														case 56:
																														case 105:
																															goto IL_03f7;
																														case 25:
																														case 27:
																															goto IL_0402;
																														case 42:
																															goto IL_0410;
																														case 4:
																														case 13:
																															goto end_IL_0205;
																														case 54:
																															goto IL_042c;
																														case 16:
																															goto IL_044f;
																														case 51:
																															goto IL_0459;
																														case 62:
																															goto IL_0467;
																														case 74:
																															goto IL_047a;
																														case 28:
																														case 107:
																															goto IL_048d;
																														case 84:
																															goto IL_04cd;
																														case 15:
																															goto IL_04e1;
																														case 95:
																														case 113:
																															goto IL_04f4;
																														case 49:
																															goto IL_0556;
																														case 115:
																															goto IL_0569;
																														case 31:
																														case 66:
																															goto IL_0577;
																														case 69:
																															goto IL_0582;
																														case 75:
																														case 97:
																															goto IL_0590;
																														case 77:
																															goto IL_05a9;
																														case 98:
																															goto IL_05b7;
																														case 83:
																															goto IL_05c5;
																														case 101:
																														case 109:
																															goto IL_05e1;
																														case 60:
																															goto IL_05ef;
																														case 9:
																														case 111:
																															goto IL_05fd;
																														case 73:
																															goto IL_0626;
																														case 114:
																															goto IL_0634;
																														case 33:
																														case 103:
																															goto IL_0644;
																														case 48:
																															goto IL_0662;
																														case 64:
																															goto IL_0672;
																														case 45:
																															goto IL_067d;
																														case 0:
																														case 3:
																														case 5:
																														case 6:
																														case 17:
																														case 21:
																														case 22:
																														case 34:
																														case 37:
																														case 50:
																														case 53:
																														case 59:
																														case 70:
																														case 85:
																														case 89:
																														case 91:
																														case 94:
																														case 100:
																															goto end_IL_0218;
																														case 1:
																														case 10:
																														case 29:
																														case 30:
																														case 38:
																														case 47:
																														case 52:
																														case 55:
																														case 58:
																														case 76:
																														case 86:
																														case 87:
																														case 88:
																														case 106:
																														case 108:
																															goto end_IL_02a5;
																														case 41:
																															goto end_IL_06a4;
																														case 23:
																															goto end_IL_06b7;
																														case 46:
																															goto end_IL_06ca;
																														case 65:
																															goto end_IL_06d5;
																														case 110:
																														case 112:
																															goto end_IL_06f3;
																														case 92:
																															goto end_IL_070c;
																														case 14:
																														case 90:
																															goto end_IL_071c;
																														case 35:
																															goto end_IL_072c;
																														case 36:
																															goto end_IL_073c;
																														case 2:
																														case 24:
																															goto IL_0757;
																														}
																														continue;
																													}
																													goto IL_0662;
																													IL_0662:
																													num5--;
																													goto end_IL_02a5;
																													continue;
																													end_IL_0205:
																													break;
																												}
																												goto IL_041e;
																												continue;
																												end_IL_0218:
																												break;
																												IL_0218:;
																											}
																											break;
																											IL_022b:;
																										}
																										break;
																									}
																									goto IL_0369;
																									IL_0369:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_02a5;
																								}
																								break;
																							}
																							goto IL_0672;
																							IL_067d:
																							if (12 <= b)
																							{
																							}
																							break;
																							IL_0672:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_067d;
																						}
																						break;
																					}
																					goto IL_02cc;
																					IL_03e4:
																					ptr2 += 8;
																					goto end_IL_02a5;
																					IL_02cc:
																					if (9 <= b)
																					{
																						goto IL_02d7;
																					}
																					goto IL_033d;
																					IL_02d7:
																					array[num5 - 1] = 0;
																					goto IL_02eb;
																					IL_02eb:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)CheckedOneWaygetPathDiscovery[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_032a;
																					IL_032a:
																					ptr2 += 8;
																					goto end_IL_02a5;
																					IL_033d:
																					if (7 < b)
																					{
																						goto IL_0348;
																					}
																					goto IL_0385;
																					IL_0348:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0356;
																					IL_0356:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_04f4;
																					IL_04f4:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0556;
																					IL_0556:
																					num5 -= 2;
																					goto end_IL_02a5;
																					IL_0385:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_03a5;
																					IL_03a5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03c8;
																					IL_03c8:
																					array[num5] = 0;
																					goto IL_03d6;
																					IL_03d6:
																					num5++;
																					goto IL_03e4;
																				}
																				break;
																			}
																			goto IL_02b9;
																			IL_04cd:
																			array[num5 - 2] = 0;
																			goto IL_04e1;
																			IL_02b9:
																			if (6 > b)
																			{
																				goto IL_0395;
																			}
																			goto IL_048d;
																			IL_0395:
																			if (3 < b)
																			{
																				goto IL_03f7;
																			}
																			goto IL_0569;
																			IL_03f7:
																			if (4 < b)
																			{
																				goto IL_0402;
																			}
																			goto IL_047a;
																			IL_0402:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0410;
																			IL_0410:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_041e;
																			IL_041e:
																			array[num5] = 0;
																			goto IL_042c;
																			IL_042c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_044f;
																			IL_044f:
																			array2[num5] = null;
																			goto IL_0459;
																			IL_0459:
																			num5++;
																			goto IL_0467;
																			IL_0467:
																			ptr2 += 8;
																			goto end_IL_02a5;
																			IL_047a:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02a5;
																			IL_0569:
																			if (3 > b)
																			{
																				goto IL_0577;
																			}
																			goto IL_0644;
																			IL_0577:
																			if (1 >= b)
																			{
																				goto IL_0582;
																			}
																			num = 109;
																			goto IL_05e1;
																			IL_0582:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0590;
																			IL_0590:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_05a9;
																			IL_05a9:
																			array[num5] = 0;
																			goto IL_05b7;
																			IL_05b7:
																			num5++;
																			goto IL_05c5;
																			IL_05c5:
																			ptr2 += 8;
																			goto end_IL_02a5;
																			IL_04e1:
																			num5--;
																			goto end_IL_02a5;
																			IL_05e1:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_05ef;
																			IL_05ef:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_05fd;
																			IL_05fd:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0626;
																			IL_0626:
																			ptr2 += 8;
																			goto IL_0634;
																			IL_0634:
																			num5--;
																			goto end_IL_02a5;
																			IL_0644:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 108;
																			goto end_IL_02a5;
																			IL_048d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04cd;
																		}
																		break;
																		IL_0275:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 29;
																goto end_IL_02a5;
																continue;
																end_IL_0285:
																break;
															}
															continue;
															end_IL_0295:
															break;
														}
														continue;
														end_IL_02a5:
														break;
													}
													continue;
												}
												goto IL_0757;
												IL_0757:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06a4:
												break;
											}
											continue;
											end_IL_06b7:
											break;
										}
										continue;
										end_IL_06ca:
										break;
									}
									continue;
									end_IL_06d5:
									break;
								}
								continue;
								end_IL_06f3:
								break;
							}
							continue;
							end_IL_070c:
							break;
						}
						continue;
						end_IL_071c:
						break;
					}
					continue;
					end_IL_072c:
					break;
				}
				continue;
				end_IL_073c:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2, int int_3)
	{
		int num = 44;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 43;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetTagUpgradeToWriterLock.SEPDateNotCurrentlyProcessing);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0271:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0254:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_0241:
																						if (4 > b)
																						{
																							num = 27;
																							while (true)
																							{
																								IL_0231:
																								if (2 < b)
																								{
																									while (3 >= b)
																									{
																										while (3 <= b)
																										{
																											while (true)
																											{
																												IL_01cf:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01b0:
																													array[num5 - 2] = 0;
																													num = 96;
																													while (true)
																													{
																														if (num != 96)
																														{
																															if (num != 1077)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 35:
																																goto IL_01b0;
																															case 20:
																															case 33:
																																goto IL_01cf;
																															case 84:
																																goto IL_0211;
																															case 56:
																															case 59:
																																goto IL_0221;
																															case 27:
																															case 52:
																																goto IL_0231;
																															case 36:
																																goto IL_0241;
																															case 49:
																																goto IL_0254;
																															case 37:
																																goto IL_0261;
																															case 38:
																																goto IL_0271;
																															case 8:
																																goto end_IL_0271;
																															case 61:
																															case 67:
																																goto end_IL_0281;
																															case 82:
																																goto IL_029c;
																															case 11:
																															case 51:
																																goto IL_02aa;
																															case 50:
																															case 55:
																																goto IL_02b5;
																															case 70:
																																goto IL_02c3;
																															case 4:
																															case 73:
																																goto IL_02d1;
																															case 28:
																																goto IL_02ed;
																															case 7:
																															case 45:
																																goto IL_02fb;
																															case 26:
																																goto IL_0309;
																															case 1:
																																goto IL_032c;
																															case 69:
																																goto IL_0336;
																															case 39:
																																goto end_IL_019d;
																															case 31:
																																goto IL_0357;
																															case 53:
																																goto IL_0365;
																															case 14:
																																goto IL_0373;
																															case 2:
																															case 85:
																																goto IL_0381;
																															case 71:
																																goto IL_03ac;
																															case 25:
																															case 29:
																																goto IL_03ba;
																															case 40:
																																goto IL_0428;
																															case 9:
																																goto IL_043b;
																															case 78:
																																goto IL_0446;
																															case 13:
																															case 46:
																																goto IL_0453;
																															case 12:
																																goto IL_047c;
																															case 6:
																																goto IL_048a;
																															case 0:
																															case 15:
																															case 16:
																															case 18:
																															case 19:
																															case 21:
																															case 41:
																															case 48:
																															case 54:
																															case 58:
																															case 63:
																															case 64:
																															case 66:
																															case 75:
																															case 76:
																															case 81:
																															case 89:
																																goto end_IL_0211;
																															case 62:
																																goto IL_04bd;
																															case 77:
																																goto IL_04cb;
																															case 57:
																																goto IL_04d9;
																															case 3:
																															case 17:
																															case 22:
																															case 23:
																															case 32:
																															case 42:
																															case 47:
																															case 65:
																															case 68:
																															case 72:
																															case 74:
																																goto end_IL_0291;
																															case 88:
																																goto end_IL_04e7;
																															case 79:
																																goto end_IL_04fa;
																															case 86:
																																goto end_IL_0504;
																															case 24:
																																goto end_IL_050f;
																															case 87:
																																goto end_IL_0524;
																															case 30:
																															case 80:
																																goto end_IL_0539;
																															case 10:
																																goto end_IL_0549;
																															case 5:
																															case 34:
																																goto end_IL_0559;
																															case 43:
																																goto end_IL_0569;
																															case 44:
																																goto end_IL_0579;
																															case 60:
																															case 83:
																																goto IL_059d;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_0291;
																														continue;
																														end_IL_019d:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0344;
																											continue;
																											end_IL_0211:
																											break;
																											IL_0211:;
																										}
																										break;
																										IL_0221:;
																									}
																									break;
																								}
																								goto IL_03ac;
																								IL_0446:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_03ac:
																								if (2 <= b)
																								{
																									goto IL_03ba;
																								}
																								goto IL_043b;
																								IL_03ba:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0428;
																								IL_0428:
																								num5 -= 2;
																								goto end_IL_0291;
																								IL_043b:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0446;
																							}
																							break;
																						}
																						goto IL_0453;
																						IL_047c:
																						ptr2 += 8;
																						goto IL_048a;
																						IL_048a:
																						num5--;
																						goto end_IL_0291;
																						IL_0453:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_047c;
																					}
																					break;
																				}
																				goto IL_029c;
																				IL_0381:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0291;
																				IL_029c:
																				if (6 < b)
																				{
																					goto IL_02aa;
																				}
																				goto IL_0357;
																				IL_02aa:
																				if (7 < b)
																				{
																					goto IL_02b5;
																				}
																				goto IL_02ed;
																				IL_02b5:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_02c3;
																				IL_02c3:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_02d1;
																				IL_02d1:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0291;
																				IL_02ed:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_02fb;
																				IL_02fb:
																				array[num5] = 0;
																				goto IL_0309;
																				IL_0309:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_032c;
																				IL_032c:
																				array2[num5] = null;
																				goto IL_0336;
																				IL_0336:
																				num5++;
																				goto IL_0344;
																				IL_0344:
																				ptr2 += 8;
																				goto end_IL_0291;
																				IL_0357:
																				if (6 <= b)
																				{
																					goto end_IL_0291;
																				}
																				goto IL_0365;
																				IL_0365:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0373;
																				IL_0373:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0381;
																			}
																			break;
																			IL_0261:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04bd;
																	IL_04d9:
																	ptr2 += 8;
																	goto end_IL_0291;
																	IL_04cb:
																	num5++;
																	goto IL_04d9;
																	IL_04bd:
																	array[num5] = 0;
																	goto IL_04cb;
																	continue;
																	end_IL_0271:
																	break;
																}
																continue;
																end_IL_0281:
																break;
															}
															continue;
															end_IL_0291:
															break;
														}
														continue;
													}
													goto IL_059d;
													IL_059d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04e7:
													break;
												}
												continue;
												end_IL_04fa:
												break;
											}
											continue;
											end_IL_0504:
											break;
										}
										continue;
										end_IL_050f:
										break;
									}
									continue;
									end_IL_0524:
									break;
								}
								continue;
								end_IL_0539:
								break;
							}
							continue;
							end_IL_0549:
							break;
						}
						continue;
						end_IL_0559:
						break;
					}
					continue;
					end_IL_0569:
					break;
				}
				continue;
				end_IL_0579:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 51;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 50;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ISODecoderRegistryValueOptions.BitArrayEnumeratorSimplegetPermissionType);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0281:
															byte b = *ptr2;
															while (true)
															{
																IL_0271:
																ptr2++;
																while (true)
																{
																	IL_0261:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0241:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0234:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_0224:
																								if (8 < b)
																								{
																									while (9 >= b)
																									{
																										while (9 <= b)
																										{
																											while (true)
																											{
																												IL_01e2:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												num = 112;
																												while (num != 112)
																												{
																													if (num != 1093)
																													{
																														goto IL_0379;
																													}
																													switch (num)
																													{
																													case 20:
																													case 71:
																														goto IL_01e2;
																													case 33:
																														goto IL_0204;
																													case 68:
																													case 97:
																														goto IL_0214;
																													case 84:
																														goto IL_0224;
																													case 14:
																													case 40:
																														goto IL_0234;
																													case 12:
																														goto IL_0241;
																													case 74:
																														goto IL_0251;
																													case 15:
																														goto IL_0261;
																													case 23:
																														goto IL_0271;
																													case 60:
																													case 81:
																														goto IL_0281;
																													case 52:
																														goto IL_028c;
																													case 27:
																													case 77:
																														goto IL_0297;
																													case 83:
																														goto IL_02b0;
																													case 16:
																														goto IL_02be;
																													case 59:
																														goto IL_02cc;
																													case 79:
																													case 96:
																														goto IL_02df;
																													case 63:
																														goto IL_02ed;
																													case 17:
																													case 37:
																														goto IL_02fb;
																													case 44:
																														goto IL_033b;
																													case 67:
																														goto IL_034f;
																													case 87:
																														goto IL_036b;
																													case 5:
																													case 100:
																														goto IL_0379;
																													case 99:
																														goto IL_03b9;
																													case 104:
																														goto IL_03cd;
																													case 70:
																														goto IL_03e9;
																													case 10:
																													case 76:
																														goto IL_03f7;
																													case 89:
																													case 93:
																														goto IL_0405;
																													case 98:
																														goto IL_0413;
																													case 49:
																														goto IL_0421;
																													case 34:
																													case 46:
																														goto IL_042f;
																													case 11:
																														goto IL_046f;
																													case 39:
																														goto IL_0483;
																													case 18:
																														goto IL_0496;
																													case 0:
																													case 82:
																														goto IL_04a4;
																													case 35:
																														goto IL_04cd;
																													case 55:
																														goto IL_04db;
																													case 54:
																														goto IL_04f7;
																													case 6:
																													case 78:
																														goto IL_0502;
																													case 30:
																														goto IL_0542;
																													case 57:
																														goto IL_055f;
																													case 38:
																														goto IL_057b;
																													case 21:
																														goto IL_0586;
																													case 88:
																													case 95:
																														goto IL_0593;
																													case 43:
																														goto IL_05a1;
																													case 53:
																														goto IL_05c4;
																													case 26:
																														goto IL_05ce;
																													case 48:
																														goto IL_05dc;
																													case 1:
																													case 3:
																													case 4:
																													case 7:
																													case 8:
																													case 13:
																													case 28:
																													case 36:
																													case 41:
																													case 42:
																													case 45:
																													case 62:
																													case 65:
																													case 69:
																													case 85:
																													case 91:
																													case 101:
																													case 105:
																														goto end_IL_0204;
																													case 86:
																														goto IL_060f;
																													case 32:
																														goto IL_061d;
																													case 61:
																														goto IL_062b;
																													case 9:
																													case 29:
																													case 47:
																													case 56:
																													case 58:
																													case 66:
																													case 75:
																													case 92:
																													case 94:
																													case 103:
																														goto end_IL_01cf;
																													case 24:
																														goto end_IL_0639;
																													case 19:
																														goto end_IL_064c;
																													case 22:
																														goto end_IL_0656;
																													case 73:
																														goto end_IL_0661;
																													case 31:
																														goto end_IL_0676;
																													case 72:
																													case 90:
																														goto end_IL_068b;
																													case 25:
																														goto end_IL_069b;
																													case 64:
																													case 102:
																														goto end_IL_06ab;
																													case 50:
																														goto end_IL_06bb;
																													case 51:
																														goto end_IL_06cb;
																													case 2:
																													case 80:
																														goto IL_06ef;
																													}
																													continue;
																													end_IL_01cf:
																													break;
																												}
																												break;
																											}
																											goto end_IL_0261;
																											continue;
																											end_IL_0204:
																											break;
																											IL_0204:;
																										}
																										break;
																										IL_0214:;
																									}
																									break;
																								}
																								goto IL_036b;
																								IL_03cd:
																								num6--;
																								num = 47;
																								goto end_IL_0261;
																								IL_036b:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_0379;
																								IL_0379:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_03b9;
																								IL_03b9:
																								array[num6 - 2] = 0;
																								goto IL_03cd;
																							}
																							break;
																						}
																						goto IL_028c;
																						IL_034f:
																						num6--;
																						num = 56;
																						goto end_IL_0261;
																						IL_028c:
																						if (7 <= b)
																						{
																							goto IL_0297;
																						}
																						goto IL_02df;
																						IL_0297:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_02b0;
																						IL_02b0:
																						array[num6] = 0;
																						goto IL_02be;
																						IL_02be:
																						num6++;
																						goto IL_02cc;
																						IL_02cc:
																						ptr2 += 8;
																						goto end_IL_0261;
																						IL_02df:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_02ed;
																						IL_02ed:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_02fb;
																						IL_02fb:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_033b;
																						IL_033b:
																						array[num6 - 2] = 0;
																						goto IL_034f;
																					}
																					break;
																				}
																				goto IL_03e9;
																				IL_05dc:
																				ptr2 += 8;
																				goto end_IL_0261;
																				IL_03e9:
																				if (5 > b)
																				{
																					goto IL_03f7;
																				}
																				goto IL_0593;
																				IL_03f7:
																				if (2 < b)
																				{
																					goto IL_0405;
																				}
																				goto IL_04f7;
																				IL_0405:
																				if (3 < b)
																				{
																					goto IL_0413;
																				}
																				goto IL_0496;
																				IL_0413:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0421;
																				IL_0421:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_042f;
																				IL_042f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_046f;
																				IL_046f:
																				array[num6 - 2] = 0;
																				goto IL_0483;
																				IL_0483:
																				num6--;
																				goto end_IL_0261;
																				IL_0496:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_04a4;
																				IL_04a4:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04cd;
																				IL_04cd:
																				ptr2 += 8;
																				goto IL_04db;
																				IL_04db:
																				num6--;
																				num = 9;
																				goto end_IL_0261;
																				IL_04f7:
																				if (2 <= b)
																				{
																					goto IL_0502;
																				}
																				goto IL_057b;
																				IL_0502:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0542;
																				IL_0542:
																				array[num6 - 2] = 0;
																				num = 57;
																				goto IL_055f;
																				IL_055f:
																				num6--;
																				num = 75;
																				goto end_IL_0261;
																				IL_057b:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0586;
																				IL_0586:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0593:
																				array[num6] = 0;
																				goto IL_05a1;
																				IL_05a1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05c4;
																				IL_05c4:
																				array2[num6] = null;
																				goto IL_05ce;
																				IL_05ce:
																				num6++;
																				goto IL_05dc;
																			}
																			break;
																			IL_0251:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_060f;
																	IL_062b:
																	ptr2 += 8;
																	break;
																	IL_061d:
																	num6++;
																	goto IL_062b;
																	IL_060f:
																	array[num6] = 0;
																	goto IL_061d;
																	continue;
																	end_IL_0261:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06ef;
													IL_06ef:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0639:
													break;
												}
												continue;
												end_IL_064c:
												break;
											}
											continue;
											end_IL_0656:
											break;
										}
										continue;
										end_IL_0661:
										break;
									}
									continue;
									end_IL_0676:
									break;
								}
								continue;
								end_IL_068b:
								break;
							}
							continue;
							end_IL_069b:
							break;
						}
						continue;
						end_IL_06ab:
						break;
					}
					continue;
					end_IL_06bb:
					break;
				}
				continue;
				end_IL_06cb:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 40;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										num = 101;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OtherOrganizationSidRemove.InvalidOperationEnumEndedAppendChar);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0665:
													num = 91;
													while (true)
													{
														IL_0652:
														if (num4 != 1)
														{
															while (true)
															{
																IL_02e5:
																byte b = *ptr2;
																while (true)
																{
																	IL_02cc:
																	ptr2++;
																	num = 75;
																	while (true)
																	{
																		IL_02bc:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				num = 38;
																				while (true)
																				{
																					IL_029c:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_028c:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_027f:
																									if (2 < b)
																									{
																										while (true)
																										{
																											IL_0272:
																											if (3 < b)
																											{
																												while (4 >= b)
																												{
																													while (4 <= b)
																													{
																														while (true)
																														{
																															IL_0207:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															num = 43;
																															while (true)
																															{
																																IL_01e8:
																																array[num5 - 2] = 0;
																																num = 110;
																																while (true)
																																{
																																	if (num != 110)
																																	{
																																		if (num != 1091)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 43:
																																			goto IL_01e8;
																																		case 46:
																																		case 57:
																																			goto IL_0207;
																																		case 55:
																																			goto IL_0252;
																																		case 22:
																																		case 94:
																																			goto IL_0262;
																																		case 61:
																																			goto IL_0272;
																																		case 45:
																																			goto IL_027f;
																																		case 92:
																																			goto IL_028c;
																																		case 38:
																																			goto IL_029c;
																																		case 33:
																																			goto IL_02a9;
																																		case 75:
																																			goto IL_02bc;
																																		case 41:
																																			goto IL_02cc;
																																		case 8:
																																		case 16:
																																			goto IL_02e5;
																																		case 9:
																																			goto IL_02f0;
																																		case 30:
																																			goto IL_0303;
																																		case 64:
																																		case 78:
																																			goto IL_0316;
																																		case 82:
																																			goto IL_0324;
																																		case 6:
																																		case 74:
																																			goto IL_032f;
																																		case 19:
																																			goto IL_033d;
																																		case 23:
																																		case 47:
																																			goto IL_034b;
																																		case 51:
																																			goto IL_0367;
																																		case 5:
																																		case 53:
																																			goto IL_0375;
																																		case 73:
																																			goto IL_03b5;
																																		case 56:
																																			goto IL_03c9;
																																		case 70:
																																		case 87:
																																			goto IL_03dc;
																																		case 63:
																																			goto IL_041c;
																																		case 89:
																																			goto IL_0430;
																																		case 49:
																																		case 90:
																																			goto IL_0443;
																																		case 81:
																																			goto IL_046c;
																																		case 26:
																																			goto IL_047a;
																																		case 93:
																																			goto IL_0496;
																																		case 0:
																																		case 50:
																																			goto IL_04a1;
																																		case 80:
																																			goto IL_04ba;
																																		case 20:
																																			goto IL_04c8;
																																		case 15:
																																			goto IL_04d6;
																																		case 29:
																																			goto IL_04f2;
																																		case 42:
																																			goto IL_0500;
																																		case 25:
																																		case 39:
																																			goto IL_050e;
																																		case 11:
																																			goto IL_054e;
																																		case 83:
																																			goto IL_0562;
																																		case 99:
																																			goto IL_0575;
																																		case 27:
																																			goto IL_0583;
																																		case 7:
																																		case 77:
																																			goto IL_05ac;
																																		case 102:
																																			goto IL_05ba;
																																		case 31:
																																			goto IL_05dd;
																																		case 4:
																																			goto IL_05e7;
																																		case 28:
																																			goto IL_05f5;
																																		case 2:
																																		case 17:
																																		case 18:
																																		case 21:
																																		case 24:
																																		case 34:
																																		case 35:
																																		case 36:
																																		case 37:
																																		case 52:
																																		case 60:
																																		case 65:
																																		case 68:
																																		case 71:
																																		case 76:
																																		case 84:
																																		case 98:
																																		case 103:
																																			goto end_IL_0252;
																																		case 67:
																																			goto IL_0628;
																																		case 32:
																																			goto IL_0636;
																																		case 72:
																																			goto IL_0644;
																																		case 1:
																																		case 3:
																																		case 12:
																																		case 14:
																																		case 48:
																																		case 62:
																																		case 66:
																																		case 91:
																																		case 96:
																																		case 100:
																																			goto IL_0652;
																																		case 69:
																																			goto IL_0665;
																																		case 44:
																																			goto end_IL_01d5;
																																		case 101:
																																			goto end_IL_0670;
																																		case 54:
																																			goto end_IL_067a;
																																		case 88:
																																			goto end_IL_0685;
																																		case 10:
																																			goto end_IL_06a3;
																																		case 13:
																																		case 59:
																																			goto end_IL_06b8;
																																		case 40:
																																			goto end_IL_06c8;
																																		case 58:
																																		case 79:
																																			goto end_IL_06d8;
																																		case 85:
																																			goto end_IL_06e8;
																																		case 86:
																																			goto end_IL_0701;
																																		case 95:
																																		case 97:
																																			goto IL_071c;
																																		}
																																		continue;
																																	}
																																	num5--;
																																	goto IL_0652;
																																	continue;
																																	end_IL_01d5:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02bc;
																														continue;
																														end_IL_0252:
																														break;
																														IL_0252:;
																													}
																													break;
																													IL_0262:;
																												}
																												break;
																											}
																											goto IL_02f0;
																											IL_047a:
																											num5--;
																											num = 12;
																											goto IL_0652;
																											IL_02f0:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_0443;
																											IL_0443:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_046c;
																											IL_046c:
																											ptr2 += 8;
																											goto IL_047a;
																										}
																										break;
																									}
																									goto IL_0303;
																									IL_0583:
																									if (1 <= b)
																									{
																									}
																									break;
																									IL_0303:
																									if (2 <= b)
																									{
																										goto IL_03dc;
																									}
																									goto IL_0575;
																									IL_03dc:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_041c;
																									IL_041c:
																									array[num5 - 2] = 0;
																									goto IL_0430;
																									IL_0430:
																									num5--;
																									goto IL_0652;
																									IL_0575:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_0583;
																								}
																								break;
																							}
																							num = 77;
																							goto IL_05ac;
																							IL_05e7:
																							num5++;
																							goto IL_05f5;
																							IL_05f5:
																							ptr2 += 8;
																							goto IL_0652;
																							IL_05ac:
																							array[num5] = 0;
																							goto IL_05ba;
																							IL_05ba:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05dd;
																							IL_05dd:
																							array2[num5] = null;
																							goto IL_05e7;
																						}
																						break;
																					}
																					goto IL_0316;
																					IL_0562:
																					num5--;
																					goto IL_0652;
																					IL_0316:
																					if (7 < b)
																					{
																						goto IL_0324;
																					}
																					goto IL_0496;
																					IL_0324:
																					if (8 < b)
																					{
																						goto IL_032f;
																					}
																					goto IL_0367;
																					IL_032f:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_033d;
																					IL_033d:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_034b;
																					IL_034b:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_0652;
																					IL_0367:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0375;
																					IL_0375:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03b5;
																					IL_03b5:
																					array[num5 - 2] = 0;
																					goto IL_03c9;
																					IL_03c9:
																					num5--;
																					goto IL_0652;
																					IL_0496:
																					if (7 <= b)
																					{
																						goto IL_04a1;
																					}
																					goto IL_04f2;
																					IL_04a1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_04ba;
																					IL_04ba:
																					array[num5] = 0;
																					goto IL_04c8;
																					IL_04c8:
																					num5++;
																					goto IL_04d6;
																					IL_04d6:
																					ptr2 += 8;
																					num = 14;
																					goto IL_0652;
																					IL_04f2:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_0500;
																					IL_0500:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_050e;
																					IL_050e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_054e;
																					IL_054e:
																					array[num5 - 2] = 0;
																					goto IL_0562;
																				}
																				break;
																				IL_02a9:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0628;
																		IL_0644:
																		ptr2 += 8;
																		goto IL_0652;
																		IL_0636:
																		num5++;
																		goto IL_0644;
																		IL_0628:
																		array[num5] = 0;
																		goto IL_0636;
																		continue;
																		end_IL_02bc:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														goto IL_071c;
														IL_071c:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													}
													break;
												}
												continue;
												end_IL_0670:
												break;
											}
											continue;
											end_IL_067a:
											break;
										}
										continue;
										end_IL_0685:
										break;
									}
									continue;
									end_IL_06a3:
									break;
								}
								continue;
								end_IL_06b8:
								break;
							}
							continue;
							end_IL_06c8:
							break;
						}
						continue;
						end_IL_06d8:
						break;
					}
					continue;
					end_IL_06e8:
					break;
				}
				continue;
				end_IL_0701:
				break;
			}
		}
	}

	private static int smethod_6(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		if (num <= num2)
		{
			num = int_3;
			num2 = int_2;
			return num - num2;
		}
		num = int_2;
		num2 = int_3;
		return num - num2;
	}

	private unsafe static int smethod_7()
	{
		int num = 16;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 69;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TKINDENUMLanguage.AllowParenthesisGetExecutingAssembly);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b1:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0291:
																			if (8 < b)
																			{
																				goto IL_05d1;
																			}
																			while (true)
																			{
																				IL_0281:
																				if (8 <= b)
																				{
																					num = 149;
																					while (true)
																					{
																						if (num != 149)
																						{
																							if (num != 1130)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 61:
																								goto IL_0281;
																							case 113:
																								goto IL_0291;
																							case 38:
																								goto end_IL_0291;
																							case 105:
																								goto IL_02b1;
																							case 7:
																								goto end_IL_02b1;
																							case 17:
																							case 26:
																								goto end_IL_02c1;
																							case 98:
																								goto IL_02dc;
																							case 135:
																								goto IL_02f4;
																							case 90:
																								goto IL_0302;
																							case 91:
																								goto IL_0310;
																							case 19:
																								goto IL_031b;
																							case 85:
																								goto IL_0329;
																							case 22:
																							case 139:
																								goto IL_0337;
																							case 102:
																								goto IL_0345;
																							case 119:
																								goto IL_035d;
																							case 63:
																								goto IL_036b;
																							case 2:
																							case 59:
																								goto IL_037e;
																							case 50:
																								goto IL_03bd;
																							case 47:
																							case 78:
																								goto IL_03d0;
																							case 130:
																								goto IL_03de;
																							case 28:
																							case 39:
																								goto IL_03ec;
																							case 116:
																								goto IL_0415;
																							case 128:
																								goto IL_0423;
																							case 44:
																								goto IL_0436;
																							case 29:
																							case 66:
																								goto IL_0441;
																							case 40:
																								goto IL_045f;
																							case 25:
																								goto IL_0476;
																							case 87:
																								goto IL_0489;
																							case 126:
																							case 137:
																								goto IL_0494;
																							case 86:
																								goto IL_04a2;
																							case 45:
																							case 80:
																								goto IL_04b0;
																							case 120:
																								goto IL_04d9;
																							case 41:
																								goto IL_04f2;
																							case 18:
																								goto IL_04fd;
																							case 33:
																								goto IL_050b;
																							case 76:
																							case 123:
																								goto IL_0519;
																							case 109:
																								goto IL_0532;
																							case 95:
																								goto IL_0540;
																							case 58:
																								goto IL_054e;
																							case 114:
																							case 140:
																								goto IL_0561;
																							case 77:
																								goto IL_05a1;
																							case 32:
																								goto IL_05be;
																							case 141:
																								goto IL_05d1;
																							case 4:
																								goto IL_05df;
																							case 1:
																							case 30:
																								goto IL_05ed;
																							case 6:
																								goto IL_05fb;
																							case 53:
																							case 65:
																								goto IL_0606;
																							case 133:
																								goto IL_0614;
																							case 31:
																							case 118:
																								goto end_IL_0271;
																							case 68:
																								goto IL_0635;
																							case 79:
																								goto IL_0658;
																							case 122:
																								goto IL_0662;
																							case 103:
																								goto IL_0670;
																							case 142:
																								goto IL_0683;
																							case 110:
																								goto IL_0691;
																							case 11:
																							case 71:
																								goto IL_069f;
																							case 35:
																								goto IL_06e3;
																							case 93:
																								goto IL_06f7;
																							case 34:
																							case 125:
																								goto IL_070a;
																							case 136:
																								goto IL_074a;
																							case 3:
																								goto IL_075e;
																							case 70:
																								goto IL_0771;
																							case 127:
																								goto IL_077f;
																							case 57:
																								goto IL_078d;
																							case 129:
																								goto IL_079b;
																							case 20:
																							case 42:
																								goto IL_07a9;
																							case 5:
																								goto IL_080b;
																							case 48:
																							case 96:
																								goto IL_0824;
																							case 138:
																								goto IL_083d;
																							case 27:
																								goto IL_0848;
																							case 0:
																							case 10:
																							case 13:
																							case 14:
																							case 21:
																							case 23:
																							case 24:
																							case 36:
																							case 43:
																							case 49:
																							case 55:
																							case 62:
																							case 72:
																							case 73:
																							case 83:
																							case 89:
																							case 92:
																							case 100:
																							case 104:
																							case 106:
																							case 107:
																							case 108:
																							case 112:
																							case 131:
																							case 132:
																								goto end_IL_02a1;
																							case 8:
																							case 9:
																							case 12:
																							case 37:
																							case 51:
																							case 52:
																							case 56:
																							case 67:
																							case 84:
																							case 88:
																							case 94:
																							case 99:
																							case 101:
																							case 111:
																							case 117:
																							case 121:
																							case 124:
																							case 134:
																								goto end_IL_02d1;
																							case 60:
																								goto end_IL_086f;
																							case 97:
																								goto end_IL_0882;
																							case 69:
																								goto end_IL_088c;
																							case 46:
																								goto end_IL_0897;
																							case 54:
																							case 81:
																								goto end_IL_08a7;
																							case 82:
																								goto end_IL_08c0;
																							case 64:
																							case 75:
																								goto end_IL_08d0;
																							case 15:
																								goto end_IL_08e0;
																							case 16:
																								goto end_IL_08f0;
																							case 74:
																							case 115:
																								goto IL_090b;
																							}
																							continue;
																						}
																						goto IL_02dc;
																						IL_02dc:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_02d1;
																						continue;
																						end_IL_0271:
																						break;
																					}
																					break;
																				}
																				goto IL_02f4;
																				IL_05a1:
																				array[num5 - 2] = 0;
																				num = 32;
																				goto IL_05be;
																				IL_05be:
																				num5--;
																				goto end_IL_02d1;
																				IL_02f4:
																				if (4 < b)
																				{
																					goto IL_0302;
																				}
																				goto IL_0436;
																				IL_0302:
																				if (6 >= b)
																				{
																					goto IL_0310;
																				}
																				goto IL_03d0;
																				IL_0310:
																				if (6 > b)
																				{
																					goto IL_031b;
																				}
																				goto IL_037e;
																				IL_031b:
																				if (5 < b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_0329;
																				IL_0329:
																				if (5 > b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_0337;
																				IL_0337:
																				array[num5] = 5;
																				goto IL_0345;
																				IL_0345:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_035d;
																				IL_035d:
																				num5++;
																				goto IL_036b;
																				IL_036b:
																				ptr2 += 8;
																				goto end_IL_02d1;
																				IL_037e:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03bd;
																				IL_03bd:
																				num5 -= 3;
																				goto end_IL_02d1;
																				IL_03d0:
																				if (7 < b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_03de;
																				IL_03de:
																				if (7 > b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_03ec;
																				IL_03ec:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0415;
																				IL_0415:
																				ptr2 += 8;
																				goto IL_0423;
																				IL_0423:
																				num5--;
																				goto end_IL_02d1;
																				IL_0436:
																				if (4 <= b)
																				{
																					goto IL_0441;
																				}
																				goto IL_0489;
																				IL_0441:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_045f;
																				IL_045f:
																				ptr2 += 8;
																				num = 25;
																				goto IL_0476;
																				IL_0476:
																				num5--;
																				goto end_IL_02d1;
																				IL_0489:
																				if (2 < b)
																				{
																					goto IL_0494;
																				}
																				goto IL_04f2;
																				IL_0494:
																				if (3 < b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_04a2;
																				IL_04a2:
																				if (3 > b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_04b0;
																				IL_04b0:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_04d9;
																				IL_04d9:
																				array[num5 - 1] = 5;
																				goto end_IL_02d1;
																				IL_04f2:
																				if (2 > b)
																				{
																					goto IL_04fd;
																				}
																				goto IL_0561;
																				IL_04fd:
																				if (1 < b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_050b;
																				IL_050b:
																				if (1 > b)
																				{
																					goto end_IL_02a1;
																				}
																				goto IL_0519;
																				IL_0519:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0532;
																				IL_0532:
																				array[num5] = 0;
																				goto IL_0540;
																				IL_0540:
																				num5++;
																				goto IL_054e;
																				IL_054e:
																				ptr2 += 8;
																				goto end_IL_02d1;
																				IL_0561:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05a1;
																			}
																			goto IL_0627;
																			IL_083d:
																			if (15 < b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_0848;
																			IL_05d1:
																			if (12 >= b)
																			{
																				goto IL_05df;
																			}
																			goto IL_0771;
																			IL_05df:
																			if (12 > b)
																			{
																				goto IL_05ed;
																			}
																			goto IL_070a;
																			IL_05ed:
																			if (10 >= b)
																			{
																				goto IL_05fb;
																			}
																			goto IL_0683;
																			IL_05fb:
																			if (10 > b)
																			{
																				goto IL_0606;
																			}
																			goto IL_0627;
																			IL_0606:
																			if (9 < b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_0614;
																			IL_0614:
																			if (9 > b)
																			{
																				goto end_IL_02a1;
																			}
																			goto end_IL_02d1;
																			IL_0627:
																			array[num5] = 0;
																			goto IL_0635;
																			IL_0635:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0658;
																			IL_0658:
																			array2[num5] = null;
																			goto IL_0662;
																			IL_0662:
																			num5++;
																			goto IL_0670;
																			IL_0670:
																			ptr2 += 8;
																			goto end_IL_02d1;
																			IL_0683:
																			if (11 < b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_0691;
																			IL_0691:
																			if (11 > b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_069f;
																			IL_069f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06e3;
																			IL_06e3:
																			array[num5 - 2] = 0;
																			goto IL_06f7;
																			IL_06f7:
																			num5--;
																			goto end_IL_02d1;
																			IL_070a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_074a;
																			IL_074a:
																			array[num5 - 2] = 0;
																			goto IL_075e;
																			IL_075e:
																			num5--;
																			goto end_IL_02d1;
																			IL_0771:
																			if (14 >= b)
																			{
																				goto IL_077f;
																			}
																			goto IL_083d;
																			IL_077f:
																			if (14 > b)
																			{
																				goto IL_078d;
																			}
																			num = 48;
																			goto IL_0824;
																			IL_078d:
																			if (13 < b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_079b;
																			IL_079b:
																			if (13 > b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_07a9;
																			IL_07a9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_080b;
																			IL_080b:
																			num5 -= 2;
																			goto end_IL_02d1;
																			IL_0848:
																			if (15 > b)
																			{
																				num = 104;
																			}
																			goto end_IL_02a1;
																			IL_0824:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02d1;
																			continue;
																			end_IL_0291:
																			break;
																		}
																		continue;
																		end_IL_02a1:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d1;
																continue;
																end_IL_02b1:
																break;
															}
															continue;
															end_IL_02c1:
															break;
														}
														continue;
														end_IL_02d1:
														break;
													}
													continue;
												}
												goto IL_090b;
												IL_090b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_086f:
												break;
											}
											continue;
											end_IL_0882:
											break;
										}
										continue;
										end_IL_088c:
										break;
									}
									continue;
									end_IL_0897:
									break;
								}
								continue;
								end_IL_08a7:
								break;
							}
							continue;
							end_IL_08c0:
							break;
						}
						continue;
						end_IL_08d0:
						break;
					}
					continue;
					end_IL_08e0:
					break;
				}
				continue;
				end_IL_08f0:
				break;
			}
		}
	}

	static Class18()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 1:
							case 2:
							case 3:
							case 6:
								goto end_IL_003d;
							case 4:
								goto end_IL_004a;
							case 5:
								goto end_IL_005f;
							case 0:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					continue;
					end_IL_004a:
					break;
				}
				continue;
				end_IL_005f:
				break;
			}
		}
	}
}
