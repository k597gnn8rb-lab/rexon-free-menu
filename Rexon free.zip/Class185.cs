using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Less Insane Auto Run [RIGHT GRIP]", "Rig", "Slower automatic running forward.", false, 11, ModType.const_0, false)]
internal class Class185 : MonoBehaviour
{
	private static bool bool_0;

	private static bool bool_1;

	private static double double_0;

	private static float float_0;

	private static int int_0;

	private static bool bool_2;

	private static IntPtr[] OIsetDescription;

	private static IntPtr[] EventLogClassicModeHalfwidthKatakana;

	private static IntPtr[] InputEncodingMulticastDelegate;

	private static string WrapperIsNull(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private static Transform SectionNameBrS(Component component_0)
	{
		return component_0.transform;
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 68;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct97.ReadKeyRSASignaturePaddingMode);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 33;
																while (true)
																{
																	IL_01f4:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				if (4 >= b)
																				{
																					while (true)
																					{
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01b7:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01a4:
																										if (2 > b)
																										{
																											num = 93;
																											while (true)
																											{
																												if (num != 93)
																												{
																													if (num != 1074)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 66:
																														goto IL_01a4;
																													case 53:
																													case 82:
																														goto IL_01b7;
																													case 35:
																														goto end_IL_01b7;
																													case 26:
																														goto end_IL_01c4;
																													case 55:
																														goto end_IL_01d4;
																													case 33:
																														goto IL_01f4;
																													case 70:
																														goto end_IL_01f4;
																													case 49:
																													case 59:
																														goto end_IL_0204;
																													case 77:
																														goto IL_0228;
																													case 37:
																														goto IL_0236;
																													case 46:
																													case 75:
																														goto IL_0244;
																													case 32:
																														goto end_IL_0191;
																													case 17:
																														goto IL_0298;
																													case 21:
																														goto IL_02ab;
																													case 51:
																														goto IL_02b6;
																													case 6:
																													case 14:
																														goto IL_02d7;
																													case 58:
																														goto IL_034e;
																													case 47:
																													case 85:
																														goto IL_0361;
																													case 18:
																														goto IL_038a;
																													case 12:
																														goto IL_0398;
																													case 72:
																													case 78:
																														goto IL_03ab;
																													case 3:
																														goto IL_03b6;
																													case 31:
																													case 52:
																														goto IL_03c4;
																													case 56:
																														goto IL_03d2;
																													case 22:
																													case 50:
																														goto IL_03e0;
																													case 23:
																														goto IL_03f8;
																													case 1:
																														goto IL_0403;
																													case 9:
																													case 57:
																														goto IL_0411;
																													case 64:
																														goto IL_041f;
																													case 81:
																														goto IL_0442;
																													case 2:
																														goto IL_044c;
																													case 48:
																														goto IL_045a;
																													case 45:
																														goto IL_046d;
																													case 84:
																														goto IL_0478;
																													case 25:
																													case 62:
																														goto IL_0483;
																													case 5:
																													case 7:
																													case 20:
																													case 27:
																													case 29:
																													case 30:
																													case 36:
																													case 39:
																													case 41:
																													case 43:
																													case 61:
																													case 65:
																													case 69:
																													case 73:
																														goto end_IL_01e4;
																													case 4:
																														goto IL_04c8;
																													case 19:
																														goto IL_04d6;
																													case 86:
																														goto IL_04e4;
																													case 10:
																													case 11:
																													case 16:
																													case 24:
																													case 28:
																													case 34:
																													case 40:
																													case 42:
																													case 54:
																													case 76:
																													case 80:
																														goto end_IL_021d;
																													case 71:
																														goto end_IL_04f2;
																													case 13:
																														goto end_IL_0505;
																													case 79:
																														goto end_IL_050f;
																													case 38:
																														goto end_IL_051a;
																													case 0:
																														goto end_IL_052f;
																													case 8:
																													case 15:
																														goto end_IL_0544;
																													case 83:
																														goto end_IL_0554;
																													case 44:
																													case 63:
																														goto end_IL_0564;
																													case 67:
																														goto end_IL_0574;
																													case 68:
																														goto end_IL_0584;
																													case 60:
																													case 74:
																														goto IL_059f;
																													}
																													continue;
																												}
																												goto IL_02ab;
																												IL_02ab:
																												if (1 < b)
																												{
																													num = 61;
																													goto end_IL_01e4;
																												}
																												goto IL_02b6;
																												IL_02b6:
																												if (1 > b)
																												{
																												}
																												goto end_IL_01e4;
																												continue;
																												end_IL_0191:
																												break;
																											}
																											break;
																										}
																										goto IL_02d7;
																										IL_02d7:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										num = 58;
																										goto IL_034e;
																										IL_034e:
																										num5 -= 2;
																										goto end_IL_021d;
																									}
																									goto IL_0284;
																								}
																								goto IL_0228;
																								IL_0298:
																								num5--;
																								goto end_IL_021d;
																								IL_0228:
																								if (3 < b)
																								{
																									goto end_IL_01e4;
																								}
																								goto IL_0236;
																								IL_0236:
																								if (3 > b)
																								{
																									goto end_IL_01e4;
																								}
																								goto IL_0244;
																								IL_0244:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0284;
																								IL_0284:
																								array[num5 - 2] = 0;
																								goto IL_0298;
																								continue;
																								end_IL_01b7:
																								break;
																							}
																							continue;
																						}
																						goto IL_0361;
																						IL_0398:
																						num5--;
																						goto end_IL_021d;
																						IL_0361:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_038a;
																						IL_038a:
																						ptr2 += 8;
																						goto IL_0398;
																						continue;
																						end_IL_01c4:
																						break;
																					}
																					continue;
																				}
																				goto IL_03ab;
																				IL_0483:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 16;
																				goto end_IL_021d;
																				IL_03ab:
																				if (6 >= b)
																				{
																					goto IL_03b6;
																				}
																				goto IL_03f8;
																				IL_03b6:
																				if (6 <= b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_03c4;
																				IL_03c4:
																				if (5 < b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03d2;
																				IL_03d2:
																				if (5 > b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03e0;
																				IL_03e0:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_021d;
																				IL_03f8:
																				if (7 >= b)
																				{
																					goto IL_0403;
																				}
																				goto IL_046d;
																				IL_0403:
																				if (7 > b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_0411;
																				IL_0411:
																				array[num5] = 0;
																				goto IL_041f;
																				IL_041f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0442;
																				IL_0442:
																				array2[num5] = null;
																				goto IL_044c;
																				IL_044c:
																				num5++;
																				goto IL_045a;
																				IL_045a:
																				ptr2 += 8;
																				goto end_IL_021d;
																				IL_046d:
																				if (8 < b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_0478;
																				IL_0478:
																				if (8 > b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_0483;
																				continue;
																				end_IL_01d4:
																				break;
																			}
																			continue;
																			end_IL_01e4:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c8;
																	IL_04e4:
																	ptr2 += 8;
																	goto end_IL_021d;
																	IL_04d6:
																	num5++;
																	goto IL_04e4;
																	IL_04c8:
																	array[num5] = 0;
																	goto IL_04d6;
																	continue;
																	end_IL_01f4:
																	break;
																}
																continue;
																end_IL_0204:
																break;
															}
															continue;
															end_IL_021d:
															break;
														}
														continue;
													}
													goto IL_059f;
													IL_059f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f2:
													break;
												}
												continue;
												end_IL_0505:
												break;
											}
											continue;
											end_IL_050f:
											break;
										}
										continue;
										end_IL_051a:
										break;
									}
									continue;
									end_IL_052f:
									break;
								}
								continue;
								end_IL_0544:
								break;
							}
							continue;
							end_IL_0554:
							break;
						}
						continue;
						end_IL_0564:
						break;
					}
					continue;
					end_IL_0574:
					break;
				}
				continue;
				end_IL_0584:
				break;
			}
		}
	}

	private static double EncodingProviderSecurityContextDisableFlow(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private static int smethod_1(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			return num - num2;
		}
		num = int_1;
		num2 = int_2;
		return num - num2;
	}

	private static Vector3 VARDISPATCHsetParamTypes(Vector3 vector3_0, Vector3 vector3_1)
	{
		return vector3_0 + vector3_1;
	}

	private static Vector3 IsUdtReturnASSEMBLYFLAGSTOKENMASK(Transform transform_0)
	{
		return transform_0.forward;
	}

	private static double RuntimeWrappedExceptionCheckOpenSubKeyPermission(double double_1)
	{
		return Math.Round(double_1);
	}

	public Class185()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int CollectCategoryMembershipDataEntryFieldId(string[] string_0)
	{
		return LayerMask.GetMask(string_0);
	}

	private static void StoreOperationScavengeSid(Transform transform_0, Vector3 vector3_0)
	{
		transform_0.position = vector3_0;
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 48;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										IL_07c4:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setDiscretionaryAclGetDaysInMonth.COMRedirectionSectionCreateLink);
										while (true)
										{
											IL_07ba:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_07a7:
												if (num4 != 1)
												{
													while (true)
													{
														IL_0325:
														byte b = *ptr2;
														while (true)
														{
															IL_030c:
															ptr2++;
															num = 93;
															while (true)
															{
																IL_02f9:
																if (b >= 1)
																{
																	num = 92;
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02dc:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02cc:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02bc:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_02ac:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_029c:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_0248:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															num = 134;
																															while (true)
																															{
																																if (num != 134)
																																{
																																	if (num != 1115)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 72:
																																	case 80:
																																		goto IL_0248;
																																	case 121:
																																		goto IL_027c;
																																	case 4:
																																	case 111:
																																		goto IL_028c;
																																	case 9:
																																		goto IL_029c;
																																	case 6:
																																		goto IL_02ac;
																																	case 39:
																																		goto IL_02bc;
																																	case 99:
																																		goto IL_02cc;
																																	case 37:
																																		goto IL_02dc;
																																	case 92:
																																		goto IL_02e9;
																																	case 93:
																																		goto IL_02f9;
																																	case 27:
																																		goto IL_030c;
																																	case 77:
																																	case 118:
																																		goto IL_0325;
																																	case 8:
																																		goto IL_0330;
																																	case 5:
																																		goto IL_033b;
																																	case 19:
																																		goto IL_0348;
																																	case 41:
																																		goto IL_0358;
																																	case 12:
																																		goto IL_0366;
																																	case 42:
																																		goto IL_0379;
																																	case 25:
																																		goto IL_0387;
																																	case 34:
																																	case 67:
																																		goto IL_039a;
																																	case 2:
																																		goto IL_03a8;
																																	case 40:
																																	case 71:
																																		goto IL_03bb;
																																	case 75:
																																		goto IL_03d3;
																																	case 53:
																																	case 55:
																																		goto IL_03de;
																																	case 82:
																																		goto IL_0407;
																																	case 74:
																																		goto IL_0415;
																																	case 73:
																																		goto IL_0423;
																																	case 61:
																																	case 96:
																																		goto IL_0436;
																																	case 94:
																																		goto IL_0441;
																																	case 51:
																																		goto IL_044f;
																																	case 62:
																																		goto IL_0462;
																																	case 32:
																																		goto IL_0470;
																																	case 31:
																																	case 68:
																																		goto IL_047e;
																																	case 90:
																																		goto IL_04be;
																																	case 11:
																																	case 103:
																																		goto IL_04d7;
																																	case 13:
																																		goto IL_04f4;
																																	case 107:
																																		goto IL_054a;
																																	case 36:
																																	case 87:
																																		goto IL_0558;
																																	case 108:
																																		goto IL_056b;
																																	case 101:
																																		goto IL_0579;
																																	case 109:
																																		goto IL_058c;
																																	case 20:
																																	case 26:
																																		goto IL_059a;
																																	case 69:
																																		goto IL_05fc;
																																	case 117:
																																		goto IL_060f;
																																	case 119:
																																		goto IL_0622;
																																	case 70:
																																	case 120:
																																		goto IL_0635;
																																	case 110:
																																		goto IL_0658;
																																	case 50:
																																		goto IL_0666;
																																	case 112:
																																		goto IL_0674;
																																	case 122:
																																		goto IL_0687;
																																	case 95:
																																	case 123:
																																		goto IL_069a;
																																	case 113:
																																	case 124:
																																		goto IL_06b6;
																																	case 7:
																																		goto IL_06c4;
																																	case 35:
																																		goto IL_06e7;
																																	case 54:
																																		goto IL_06f1;
																																	case 115:
																																		goto IL_06ff;
																																	case 14:
																																	case 126:
																																		goto IL_0712;
																																	case 43:
																																		goto IL_0752;
																																	case 127:
																																		goto IL_0766;
																																	case 78:
																																		goto IL_0784;
																																	case 0:
																																	case 3:
																																	case 16:
																																	case 17:
																																	case 21:
																																	case 29:
																																	case 49:
																																	case 52:
																																	case 56:
																																	case 57:
																																	case 58:
																																	case 59:
																																	case 60:
																																	case 64:
																																	case 66:
																																	case 83:
																																	case 85:
																																	case 88:
																																	case 89:
																																	case 98:
																																	case 104:
																																	case 105:
																																	case 106:
																																	case 125:
																																		goto end_IL_027c;
																																	case 1:
																																	case 10:
																																	case 24:
																																	case 28:
																																	case 38:
																																	case 44:
																																	case 45:
																																	case 46:
																																	case 65:
																																	case 76:
																																	case 79:
																																	case 81:
																																	case 97:
																																	case 100:
																																	case 114:
																																	case 116:
																																		goto IL_07a7;
																																	case 23:
																																		goto IL_07ba;
																																	case 15:
																																		goto IL_07c4;
																																	case 30:
																																		goto end_IL_0235;
																																	case 22:
																																		goto end_IL_07cf;
																																	case 18:
																																	case 86:
																																		goto end_IL_07e4;
																																	case 102:
																																		goto end_IL_07f4;
																																	case 33:
																																	case 63:
																																		goto end_IL_0804;
																																	case 47:
																																		goto end_IL_0814;
																																	case 48:
																																		goto end_IL_0824;
																																	case 84:
																																	case 91:
																																		goto IL_083f;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto IL_0784;
																																IL_0784:
																																num5--;
																																goto IL_07a7;
																																continue;
																																end_IL_0235:
																																break;
																															}
																															break;
																														}
																														goto end_IL_02f9;
																														continue;
																														end_IL_027c:
																														break;
																														IL_027c:;
																													}
																													break;
																													IL_028c:;
																												}
																												break;
																											}
																											goto IL_03d3;
																											IL_0423:
																											ptr2 += 8;
																											goto IL_07a7;
																											IL_03d3:
																											if (1 > b)
																											{
																												num = 66;
																												break;
																											}
																											goto IL_03de;
																											IL_03de:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0407;
																											IL_0407:
																											array[num5] = 0;
																											goto IL_0415;
																											IL_0415:
																											num5++;
																											goto IL_0423;
																										}
																										break;
																									}
																									goto IL_03bb;
																									IL_03bb:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_07a7;
																								}
																								break;
																							}
																							goto IL_0436;
																							IL_0687:
																							num5--;
																							goto IL_07a7;
																							IL_0436:
																							if (5 >= b)
																							{
																								goto IL_0441;
																							}
																							goto IL_0462;
																							IL_0441:
																							if (5 > b)
																							{
																								goto IL_044f;
																							}
																							goto IL_06b6;
																							IL_044f:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_060f;
																							IL_060f:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_07a7;
																							IL_06b6:
																							array[num5] = 0;
																							goto IL_06c4;
																							IL_06c4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_06e7;
																							IL_06e7:
																							array2[num5] = null;
																							goto IL_06f1;
																							IL_06f1:
																							num5++;
																							goto IL_06ff;
																							IL_06ff:
																							ptr2 += 8;
																							goto IL_07a7;
																							IL_0462:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0470;
																							IL_0470:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_047e;
																							IL_047e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04be;
																							IL_04be:
																							array[num5 - 2] = 0;
																							goto IL_0687;
																						}
																						break;
																					}
																					goto IL_0635;
																					IL_0674:
																					ptr2 += 8;
																					goto IL_07a7;
																					IL_0635:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0658;
																					IL_0658:
																					array[num5] = 0;
																					goto IL_0666;
																					IL_0666:
																					num5++;
																					goto IL_0674;
																				}
																				break;
																			}
																			goto IL_0330;
																			IL_0579:
																			ptr2 += 8;
																			goto IL_07a7;
																			IL_0330:
																			if (10 < b)
																			{
																				goto IL_033b;
																			}
																			goto IL_0348;
																			IL_033b:
																			if (12 < b)
																			{
																				goto IL_0358;
																			}
																			goto IL_0379;
																			IL_0379:
																			if (12 > b)
																			{
																				goto IL_0387;
																			}
																			goto IL_069a;
																			IL_0387:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_054a;
																			IL_054a:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0558;
																			IL_0558:
																			num5--;
																			goto IL_07a7;
																			IL_069a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_07a7;
																			IL_0358:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0366;
																			IL_0366:
																			if (13 <= b)
																			{
																			}
																			break;
																			IL_0348:
																			if (10 > b)
																			{
																				goto IL_039a;
																			}
																			goto IL_04d7;
																			IL_039a:
																			if (8 < b)
																			{
																				goto IL_03a8;
																			}
																			goto IL_058c;
																			IL_03a8:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0622;
																			IL_0622:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0712;
																			IL_0712:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0752;
																			IL_0752:
																			array[num5 - 2] = 0;
																			goto IL_0766;
																			IL_0766:
																			num5--;
																			goto IL_07a7;
																			IL_058c:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_059a;
																			IL_059a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05fc;
																			IL_05fc:
																			num5 -= 2;
																			goto IL_07a7;
																			IL_04d7:
																			array[num5 - 2] = 0;
																			num = 13;
																			goto IL_04f4;
																			IL_04f4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)InputEncodingMulticastDelegate[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_056b;
																			IL_056b:
																			num5--;
																			goto IL_0579;
																		}
																		break;
																		IL_02e9:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_07a7;
																continue;
																end_IL_02f9:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_083f;
												IL_083f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									continue;
									end_IL_07cf:
									break;
								}
								continue;
								end_IL_07e4:
								break;
							}
							continue;
							end_IL_07f4:
							break;
						}
						continue;
						end_IL_0804:
						break;
					}
					continue;
					end_IL_0814:
					break;
				}
				continue;
				end_IL_0824:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 22;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 21;
			while (true)
			{
				int num3 = num2 * 4;
				num = 82;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 30;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setAttributesHasProperties.InvariantValueTuple);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_028e:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_026e:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_025e:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0251:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_0241:
																										if (3 < b)
																										{
																											while (4 >= b)
																											{
																												while (4 <= b)
																												{
																													while (true)
																													{
																														IL_01d6:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														num = 109;
																														while (true)
																														{
																															if (num != 109)
																															{
																																if (num != 1090)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 45:
																																case 67:
																																	goto IL_01d6;
																																case 18:
																																	goto IL_0221;
																																case 6:
																																case 10:
																																	goto IL_0231;
																																case 50:
																																	goto IL_0241;
																																case 102:
																																	goto IL_0251;
																																case 25:
																																	goto IL_025e;
																																case 86:
																																	goto IL_026e;
																																case 42:
																																	goto IL_027e;
																																case 5:
																																	goto IL_028e;
																																case 63:
																																	goto end_IL_028e;
																																case 7:
																																case 27:
																																	goto end_IL_029e;
																																case 23:
																																	goto IL_02b9;
																																case 19:
																																case 60:
																																	goto IL_02c7;
																																case 26:
																																case 71:
																																	goto IL_0315;
																																case 49:
																																	goto IL_0323;
																																case 55:
																																	goto IL_0346;
																																case 61:
																																	goto IL_0350;
																																case 84:
																																	goto IL_0360;
																																case 56:
																																	goto IL_036e;
																																case 96:
																																	goto IL_0381;
																																case 100:
																																	goto IL_039d;
																																case 14:
																																	goto IL_03b1;
																																case 3:
																																	goto IL_03e1;
																																case 68:
																																	goto IL_03f4;
																																case 12:
																																case 35:
																																	goto IL_0402;
																																case 11:
																																	goto IL_042b;
																																case 39:
																																	goto IL_0439;
																																case 90:
																																	goto IL_044c;
																																case 8:
																																	goto IL_045a;
																																case 13:
																																case 59:
																																	goto IL_0465;
																																case 34:
																																	goto IL_047e;
																																case 41:
																																	goto IL_048c;
																																case 77:
																																	goto IL_049a;
																																case 57:
																																	goto IL_04ad;
																																case 16:
																																	goto IL_04bb;
																																case 2:
																																case 76:
																																	goto IL_04c9;
																																case 99:
																																	goto IL_0509;
																																case 20:
																																	goto IL_051d;
																																case 88:
																																	goto IL_0539;
																																case 47:
																																case 48:
																																	goto IL_0544;
																																case 1:
																																	goto IL_0552;
																																case 33:
																																case 98:
																																	goto IL_0560;
																																case 93:
																																	goto IL_057c;
																																case 15:
																																case 44:
																																	goto IL_0587;
																																case 46:
																																	goto IL_05c7;
																																case 29:
																																	goto IL_05db;
																																case 32:
																																case 37:
																																case 43:
																																case 52:
																																case 53:
																																case 58:
																																case 62:
																																case 66:
																																case 69:
																																case 70:
																																case 72:
																																case 73:
																																case 74:
																																case 79:
																																case 80:
																																case 83:
																																case 89:
																																case 101:
																																	goto end_IL_01c3;
																																case 75:
																																	goto IL_060e;
																																case 64:
																																	goto IL_061c;
																																case 65:
																																	goto IL_062a;
																																case 9:
																																case 24:
																																case 31:
																																case 36:
																																case 40:
																																case 51:
																																case 87:
																																case 91:
																																case 94:
																																case 95:
																																case 97:
																																	goto end_IL_02ae;
																																case 78:
																																	goto end_IL_0638;
																																case 0:
																																	goto end_IL_064b;
																																case 17:
																																	goto end_IL_0655;
																																case 30:
																																	goto end_IL_0660;
																																case 92:
																																	goto end_IL_0675;
																																case 4:
																																case 81:
																																	goto end_IL_068a;
																																case 85:
																																	goto end_IL_06a3;
																																case 38:
																																case 82:
																																	goto end_IL_06b3;
																																case 21:
																																	goto end_IL_06c3;
																																case 22:
																																	goto end_IL_06d3;
																																case 28:
																																case 54:
																																	goto IL_0700;
																																}
																																continue;
																															}
																															array[num5 - 2] = 0;
																															num = 3;
																															goto IL_03e1;
																															IL_03e1:
																															num5--;
																															goto end_IL_02ae;
																															continue;
																															end_IL_01c3:
																															break;
																														}
																														break;
																													}
																													break;
																													IL_0221:;
																												}
																												break;
																												IL_0231:;
																											}
																											break;
																										}
																										goto IL_03f4;
																										IL_0439:
																										num5--;
																										goto end_IL_02ae;
																										IL_03f4:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0402;
																										IL_0402:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_042b;
																										IL_042b:
																										ptr2 += 8;
																										goto IL_0439;
																									}
																									break;
																								}
																								goto IL_02b9;
																								IL_036e:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_02b9:
																								if (2 <= b)
																								{
																									goto IL_02c7;
																								}
																								goto IL_0360;
																								IL_02c7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 100;
																								goto IL_039d;
																								IL_039d:
																								array[num5 - 2] = 0;
																								goto IL_03b1;
																								IL_03b1:
																								num5--;
																								goto end_IL_02ae;
																								IL_0360:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_036e;
																							}
																							break;
																						}
																						goto IL_0315;
																						IL_0381:
																						ptr2 += 8;
																						num = 91;
																						goto end_IL_02ae;
																						IL_0315:
																						array[num5] = 0;
																						goto IL_0323;
																						IL_0323:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0346;
																						IL_0346:
																						array2[num5] = null;
																						goto IL_0350;
																						IL_0350:
																						num5++;
																						goto IL_0381;
																					}
																					break;
																				}
																				goto IL_044c;
																				IL_05db:
																				num5--;
																				goto end_IL_02ae;
																				IL_044c:
																				if (7 >= b)
																				{
																					goto IL_045a;
																				}
																				goto IL_0539;
																				IL_045a:
																				if (7 <= b)
																				{
																					goto IL_0465;
																				}
																				goto IL_04ad;
																				IL_0465:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_047e;
																				IL_047e:
																				array[num5] = 0;
																				goto IL_048c;
																				IL_048c:
																				num5++;
																				goto IL_049a;
																				IL_049a:
																				ptr2 += 8;
																				goto end_IL_02ae;
																				IL_04ad:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_04bb;
																				IL_04bb:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_04c9;
																				IL_04c9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0509;
																				IL_0509:
																				array[num5 - 2] = 0;
																				goto IL_051d;
																				IL_051d:
																				num5--;
																				num = 24;
																				goto end_IL_02ae;
																				IL_0539:
																				if (8 < b)
																				{
																					goto IL_0544;
																				}
																				goto IL_057c;
																				IL_0544:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0552;
																				IL_0552:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0560;
																				IL_0560:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02ae;
																				IL_057c:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0587;
																				IL_0587:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05c7;
																				IL_05c7:
																				array[num5 - 2] = 0;
																				goto IL_05db;
																			}
																			break;
																			IL_027e:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_060e;
																	IL_062a:
																	ptr2 += 8;
																	goto end_IL_02ae;
																	IL_061c:
																	num5++;
																	goto IL_062a;
																	IL_060e:
																	array[num5] = 0;
																	goto IL_061c;
																	continue;
																	end_IL_028e:
																	break;
																}
																continue;
																end_IL_029e:
																break;
															}
															continue;
															end_IL_02ae:
															break;
														}
														continue;
													}
													goto IL_0700;
													IL_0700:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0638:
													break;
												}
												continue;
												end_IL_064b:
												break;
											}
											continue;
											end_IL_0655:
											break;
										}
										continue;
										end_IL_0660:
										break;
									}
									continue;
									end_IL_0675:
									break;
								}
								continue;
								end_IL_068a:
								break;
							}
							continue;
							end_IL_06a3:
							break;
						}
						continue;
						end_IL_06b3:
						break;
					}
					continue;
					end_IL_06c3:
					break;
				}
				continue;
				end_IL_06d3:
				break;
			}
		}
	}

	private static object ForkJoinLinkedSlot(float float_1, float float_2, float float_3)
	{
		return new Vector3(float_1, float_2, float_3);
	}

	private static Transform IsEnteredThreadTransferReceiveHandledObj(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.leftHandTransform;
	}

	private static Vector3 GetModuleCerHashtable()
	{
		return global::_003CModule_003E.vector3_144;
	}

	private static double PaddingModeCompleteOnCountdownPromise(double double_1)
	{
		return Math.Log(double_1);
	}

	private static Vector3 IsAccountSidGetTimeOfLastChange()
	{
		return global::_003CModule_003E.vector3_142;
	}

	private unsafe void Update()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					num3 = 0;
					while (true)
					{
						IL_0094:
						if (num3 == 63)
						{
							while (true)
							{
								IL_0086:
								num3 = 0;
								num = 14;
								while (true)
								{
									if (num == 14 || num != 995)
									{
										return;
									}
									switch (num)
									{
									case 5:
										break;
									default:
										continue;
									case 4:
										goto IL_0086;
									case 3:
									case 6:
										goto IL_0094;
									case 7:
										goto end_IL_0094;
									case 0:
										goto end_IL_009f;
									case 1:
										goto end_IL_00a4;
									case 2:
										return;
									}
									break;
								}
								break;
							}
						}
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, void>)OIsetDescription[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref num11);
						continue;
						end_IL_0094:
						break;
					}
					continue;
					end_IL_009f:
					break;
				}
				continue;
				end_IL_00a4:
				break;
			}
		}
	}

	private static Vector3 AptcagetMDStreamVersion(Transform transform_0)
	{
		return transform_0.right;
	}

	private static bool InitInitLocals(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightGrab;
	}

	private static object getPositiveInfinitySymbolUIntPtr(float float_1, float float_2, float float_3)
	{
		return new Vector3(float_1, float_2, float_3);
	}

	private static double ReferenceToTextBufferInlineI(double double_1)
	{
		return Math.Sin(double_1);
	}

	private static int RequireHexPrefixInternalSerializerTypeE(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static Vector3 TextToReferencesetActivityOptions(ref Vector3 vector3_0)
	{
		return vector3_0.normalized;
	}

	private static Vector3 PathTooLongExceptionMEMORYSTATUSEX()
	{
		return global::_003CModule_003E.vector3_143;
	}

	private static float MethodNameTryAddCount(Vector3 vector3_0)
	{
		return vector3_0.x;
	}

	private static Vector3 EnsureSufficientExecutionStackNTAuthoritySid()
	{
		return Vector3.up;
	}

	private static double InlineSwitchcoreNewLine(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static Vector3 TaskToApmLowercaseLetter(ref RaycastHit raycastHit_0)
	{
		return raycastHit_0.point;
	}

	private static Vector3 KeyStoreMuiResourceMapEntry()
	{
		return global::_003CModule_003E.vector3_150;
	}

	private static int KeyPropertysetExternalThreading(LayerMask layerMask_0)
	{
		return layerMask_0;
	}

	private static double MdConstantDP(double double_1)
	{
		return Math.Abs(double_1);
	}

	private static Vector3 ToEventKeywordssetSite(Vector3 vector3_0, float float_1)
	{
		return vector3_0 * float_1;
	}

	private static int queueListToBindableVectorViewAdapter(int int_1)
	{
		return smethod_8(int_1);
	}

	private static Vector3 StringExpressionSetSequencePointCount()
	{
		return global::_003CModule_003E.vector3_146;
	}

	private static float CreateRangesdNetworkSid()
	{
		return global::_003CModule_003E.float_114;
	}

	private static Vector3 SafeHashHandlegetIsRetval(Vector3 vector3_0, float float_1)
	{
		return vector3_0 * float_1;
	}

	private static SphereCollider MonitorCreateDecryptor(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.headCollider;
	}

	private static Vector3 NativeCppClassAttributeUnspecified(Vector3 vector3_0, Vector3 vector3_1, float float_1)
	{
		return Vector3.Lerp(vector3_0, vector3_1, float_1);
	}

	private static Vector3 NodeUInt(Transform transform_0)
	{
		return transform_0.position;
	}

	private static LayerMask processorCountPlatformID(int int_1)
	{
		return int_1;
	}

	private static Vector3 FailedgetString()
	{
		return global::_003CModule_003E.vector3_147;
	}

	private static CapsuleCollider ArgRegSetStrArrNullRemoveAccessRuleAll(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.bodyCollider;
	}

	private static float GetStoreWriteOnlyArrayAttribute(float float_1)
	{
		return Mathf.Cos(float_1);
	}

	private static LayerMask PostalCodegetCheckId()
	{
		return global::_003CModule_003E.layerMask_2;
	}

	private static void TypeContractsAreForCreateDomain(Transform transform_0, Quaternion quaternion_0)
	{
		transform_0.rotation = quaternion_0;
	}

	private static ControllerInputPoller smethod_5()
	{
		return ControllerInputPoller.instance;
	}

	private static Vector3 getKeysOrderedAcrossPartitionsConcat()
	{
		return global::_003CModule_003E.vector3_145;
	}

	private static float FromCurrentSynchronizationContextFUNCSTATIC(Vector3 vector3_0)
	{
		return vector3_0.y;
	}

	private static double NumberDecimalDigitsgetCount(double double_1)
	{
		return Math.Log10(double_1);
	}

	private static int smethod_7(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		int num3;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_1;
			num2 = int_2;
			num -= num2;
			num3 = num;
		}
		num = num3;
		num2 = 42;
		num2 = 21;
		int num4 = smethod_1(21, 45);
		num2 = num4;
		return num;
	}

	private static bool WriteDataDefineManifestResource(Vector3 vector3_0, Vector3 vector3_1, ref RaycastHit raycastHit_0, float float_1, int int_1)
	{
		return Physics.Raycast(vector3_0, vector3_1, out raycastHit_0, float_1, int_1);
	}

	private static Vector3 CanSkipCSEvaluationGetStringBuilder()
	{
		return global::_003CModule_003E.vector3_148;
	}

	private static float RemoveAuditHostEvidence(float float_1)
	{
		return Mathf.Sin(float_1);
	}

	private static double ImportAsAgnosticgetThreeLetterWindowsRegionName(double double_1)
	{
		return Math.Floor(double_1);
	}

	private unsafe static int smethod_8(int int_1)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CrossContextChannelgetWindowTop.IAPPIDAUTHORITYAREREFERENCESEQUALFLAGIGNOREVERSIONReleaseMutex);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0664:
												if (num4 != 1)
												{
													goto IL_000e;
												}
												num = 119;
												while (true)
												{
													if (num != 119)
													{
														if (num != 1100)
														{
															break;
														}
														switch (num)
														{
														case 72:
														case 80:
															break;
														case 75:
															goto IL_0017;
														case 71:
															goto IL_0025;
														case 45:
															goto IL_0033;
														case 16:
															goto IL_0041;
														case 7:
															goto IL_004f;
														case 18:
														case 106:
															goto IL_005d;
														case 53:
														case 101:
															goto IL_006b;
														case 38:
														case 110:
															goto IL_0079;
														case 1:
															goto IL_0087;
														case 4:
														case 27:
															goto IL_0095;
														case 17:
															goto IL_00a3;
														case 54:
															goto IL_00c6;
														case 55:
															goto IL_00d0;
														case 26:
															goto IL_00e7;
														case 62:
															goto IL_00fa;
														case 9:
															goto IL_010d;
														case 32:
														case 93:
															goto IL_0118;
														case 108:
															goto end_IL_0651;
														case 12:
															goto IL_013b;
														case 109:
															goto IL_0149;
														case 83:
														case 98:
															goto IL_0157;
														case 48:
															goto IL_0180;
														case 15:
															goto IL_018e;
														case 65:
															goto IL_01aa;
														case 13:
														case 86:
															goto IL_01b8;
														case 11:
															goto IL_01d1;
														case 57:
															goto IL_01df;
														case 35:
															goto IL_01ed;
														case 10:
														case 49:
															goto IL_0200;
														case 20:
															goto IL_0240;
														case 74:
															goto IL_0254;
														case 34:
															goto IL_0267;
														case 67:
														case 76:
															goto IL_0272;
														case 24:
															goto IL_027d;
														case 64:
														case 81:
															goto IL_028b;
														case 23:
															goto IL_02a7;
														case 52:
															goto IL_02b5;
														case 33:
															goto IL_02c8;
														case 68:
														case 70:
															goto IL_02d3;
														case 22:
															goto IL_0335;
														case 99:
															goto IL_0348;
														case 51:
														case 59:
															goto IL_0353;
														case 39:
															goto IL_0361;
														case 50:
														case 95:
															goto IL_036f;
														case 8:
															goto IL_0392;
														case 100:
															goto IL_03a9;
														case 19:
															goto IL_03b7;
														case 107:
															goto IL_03ca;
														case 47:
														case 77:
															goto IL_03d5;
														case 91:
															goto IL_0415;
														case 112:
															goto IL_0429;
														case 2:
														case 5:
														case 6:
														case 14:
														case 29:
														case 30:
														case 31:
														case 37:
														case 43:
														case 61:
														case 66:
														case 73:
														case 78:
														case 84:
														case 87:
														case 88:
														case 89:
														case 97:
														case 105:
														case 111:
															goto IL_044e;
														default:
															continue;
														case 0:
														case 3:
														case 25:
														case 36:
														case 46:
														case 56:
														case 63:
														case 85:
														case 90:
														case 94:
														case 96:
														case 102:
														case 103:
														case 104:
															goto IL_0664;
														case 58:
															goto end_IL_0664;
														case 92:
															goto end_IL_0677;
														case 79:
															goto end_IL_0681;
														case 44:
															goto end_IL_068c;
														case 21:
														case 82:
															goto end_IL_06a1;
														case 42:
															goto end_IL_06b1;
														case 28:
														case 69:
															goto end_IL_06c1;
														case 40:
															goto end_IL_06d1;
														case 41:
															goto end_IL_06e1;
														case 60:
															goto IL_06fc;
														}
														goto IL_000e;
													}
													goto IL_06fc;
													IL_06fc:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0651:
													break;
												}
												goto IL_0130;
												IL_0415:
												array[num5 - 2] = 0;
												goto IL_0429;
												IL_0429:
												num5--;
												num = 63;
												continue;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												goto IL_044e;
												IL_0033:
												if (b <= 11)
												{
													goto IL_0041;
												}
												goto IL_044e;
												IL_0041:
												if (6 >= b)
												{
													goto IL_004f;
												}
												goto IL_0267;
												IL_004f:
												if (6 > b)
												{
													goto IL_005d;
												}
												goto IL_0200;
												IL_005d:
												if (3 < b)
												{
													goto IL_006b;
												}
												goto IL_010d;
												IL_006b:
												if (4 < b)
												{
													goto IL_0079;
												}
												goto IL_00fa;
												IL_0079:
												if (5 >= b)
												{
													goto IL_0087;
												}
												goto IL_044e;
												IL_0087:
												if (5 <= b)
												{
													goto IL_0095;
												}
												goto IL_044e;
												IL_0095:
												array[num5] = 0;
												goto IL_00a3;
												IL_00a3:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_00c6;
												IL_00c6:
												array2[num5] = null;
												goto IL_00d0;
												IL_00d0:
												num5++;
												num = 26;
												goto IL_00e7;
												IL_00e7:
												ptr2 += 8;
												continue;
												IL_00fa:
												if (4 <= b)
												{
													continue;
												}
												goto IL_044e;
												IL_010d:
												if (3 <= b)
												{
													goto IL_0118;
												}
												goto IL_0130;
												IL_0118:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_0130:
												if (1 < b)
												{
													goto IL_013b;
												}
												num = 65;
												goto IL_01aa;
												IL_013b:
												if (2 >= b)
												{
													goto IL_0149;
												}
												goto IL_044e;
												IL_0149:
												if (2 <= b)
												{
													goto IL_0157;
												}
												goto IL_044e;
												IL_0157:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0180;
												IL_0180:
												ptr2 += 8;
												goto IL_018e;
												IL_018e:
												num5--;
												continue;
												IL_044e:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_01aa:
												if (1 <= b)
												{
													goto IL_01b8;
												}
												goto IL_044e;
												IL_01b8:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_01d1;
												IL_01d1:
												array[num5] = 0;
												goto IL_01df;
												IL_01df:
												num5++;
												goto IL_01ed;
												IL_01ed:
												ptr2 += 8;
												continue;
												IL_0200:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0240;
												IL_0240:
												array[num5 - 2] = 0;
												goto IL_0254;
												IL_0254:
												num5--;
												continue;
												IL_0267:
												if (9 < b)
												{
													goto IL_0272;
												}
												goto IL_02c8;
												IL_0272:
												if (10 >= b)
												{
													goto IL_027d;
												}
												goto IL_02a7;
												IL_027d:
												if (10 <= b)
												{
													goto IL_028b;
												}
												goto IL_044e;
												IL_028b:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_02a7:
												if (11 >= b)
												{
													goto IL_02b5;
												}
												goto IL_044e;
												IL_02b5:
												if (11 <= b)
												{
												}
												goto IL_044e;
												IL_02c8:
												if (9 <= b)
												{
													goto IL_02d3;
												}
												goto IL_0348;
												IL_02d3:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0335;
												IL_0335:
												num5 -= 2;
												continue;
												IL_0348:
												if (7 < b)
												{
													goto IL_0353;
												}
												goto IL_03ca;
												IL_0353:
												if (8 >= b)
												{
													goto IL_0361;
												}
												goto IL_044e;
												IL_0361:
												if (8 <= b)
												{
													goto IL_036f;
												}
												goto IL_044e;
												IL_036f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0392;
												IL_0392:
												array[num5] = 0;
												num = 100;
												goto IL_03a9;
												IL_03a9:
												num5++;
												goto IL_03b7;
												IL_03b7:
												ptr2 += 8;
												continue;
												IL_03ca:
												if (7 <= b)
												{
													goto IL_03d5;
												}
												num = 111;
												goto IL_044e;
												IL_03d5:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0415;
												continue;
												end_IL_0664:
												break;
											}
											continue;
											end_IL_0677:
											break;
										}
										continue;
										end_IL_0681:
										break;
									}
									continue;
									end_IL_068c:
									break;
								}
								continue;
								end_IL_06a1:
								break;
							}
							continue;
							end_IL_06b1:
							break;
						}
						continue;
						end_IL_06c1:
						break;
					}
					continue;
					end_IL_06d1:
					break;
				}
				continue;
				end_IL_06e1:
				break;
			}
		}
	}

	private unsafe static int smethod_9(int int_1, int int_2)
	{
		int num = 38;
		int num4 = default(int);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 113;
								while (true)
								{
									if (num != 113)
									{
										if (num != 1094)
										{
											goto IL_030a;
										}
										switch (num)
										{
										case 76:
											goto end_IL_01d3;
										case 36:
										case 90:
											goto end_IL_01e3;
										case 81:
											goto end_IL_01fc;
										case 12:
										case 79:
											goto end_IL_020c;
										case 37:
											goto end_IL_021c;
										case 38:
											goto end_IL_022c;
										case 40:
											goto IL_025a;
										case 83:
											goto IL_026d;
										case 102:
											goto IL_027f;
										case 3:
										case 11:
										case 18:
										case 19:
										case 27:
										case 51:
										case 52:
										case 63:
										case 70:
										case 94:
										case 96:
											goto IL_0287;
										case 30:
										case 85:
											goto IL_0297;
										case 29:
											goto IL_02a0;
										case 8:
											goto IL_02ae;
										case 2:
											goto IL_02bc;
										case 21:
											goto IL_02ca;
										case 95:
											goto IL_02d8;
										case 64:
										case 73:
											goto IL_02e6;
										case 84:
											goto IL_02f4;
										case 17:
											goto IL_02ff;
										case 0:
										case 46:
											goto IL_030a;
										case 104:
											goto IL_0333;
										case 100:
											goto IL_0341;
										case 26:
										case 71:
											goto IL_0362;
										case 53:
											goto IL_0379;
										case 41:
										case 82:
											goto IL_0387;
										case 61:
											goto IL_03c7;
										case 69:
											goto IL_03e4;
										case 22:
											goto IL_03f7;
										case 10:
										case 15:
											goto IL_0402;
										case 24:
											goto IL_0410;
										case 7:
										case 97:
											goto IL_0423;
										case 72:
											goto IL_046c;
										case 99:
											goto IL_0489;
										case 20:
										case 56:
											goto IL_04a5;
										case 47:
											goto IL_04b3;
										case 75:
											goto IL_04d6;
										case 80:
											goto IL_04e0;
										case 50:
											goto IL_04ee;
										case 23:
											goto IL_0501;
										case 98:
											goto IL_050f;
										case 6:
										case 103:
											goto IL_051a;
										case 77:
											goto IL_0533;
										case 1:
											goto IL_0541;
										case 39:
											goto IL_054f;
										case 5:
										case 66:
											goto IL_0562;
										case 34:
											goto IL_056d;
										case 9:
										case 88:
											goto IL_057b;
										case 74:
											goto IL_05bb;
										case 58:
											goto IL_05cf;
										case 57:
										case 91:
											goto IL_05f0;
										case 33:
										case 35:
											goto IL_05fb;
										case 67:
											goto IL_0609;
										case 68:
										case 78:
											goto IL_0617;
										case 54:
											goto IL_0633;
										case 49:
										case 87:
											goto IL_0641;
										case 45:
											goto IL_0681;
										case 92:
											goto IL_0695;
										case 65:
											goto IL_06a8;
										case 13:
											goto IL_06b6;
										case 25:
											goto IL_06c4;
										case 4:
										case 14:
										case 16:
										case 28:
										case 31:
										case 32:
										case 42:
										case 43:
										case 44:
										case 59:
										case 60:
										case 62:
										case 86:
										case 89:
										case 93:
										case 101:
										case 105:
										case 106:
											goto IL_06e0;
										case 48:
										case 55:
											goto IL_0705;
										}
										continue;
									}
									array3[0] = int_1;
									goto IL_025a;
									IL_0681:
									array[num4 - 2] = 0;
									goto IL_0695;
									IL_06e0:
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
									goto IL_06a8;
									IL_0695:
									num4--;
									goto IL_0287;
									IL_025a:
									array3[1] = int_2;
									goto IL_026d;
									IL_026d:
									ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InputRecordgetEnumName.SameMachineAssemblyTitleAttribute);
									num = 102;
									goto IL_027f;
									IL_027f:
									ptr = ptr2;
									goto IL_0287;
									IL_0287:
									if (num5 != 1)
									{
										goto IL_0297;
									}
									goto IL_0705;
									IL_0705:
									return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
									IL_0297:
									b = *ptr;
									goto IL_02a0;
									IL_02a0:
									ptr++;
									goto IL_02ae;
									IL_02ae:
									if (b >= 1)
									{
										goto IL_02bc;
									}
									goto IL_06e0;
									IL_02bc:
									if (b <= 9)
									{
										goto IL_02ca;
									}
									goto IL_06e0;
									IL_02ca:
									if (5 >= b)
									{
										goto IL_02d8;
									}
									goto IL_0501;
									IL_02d8:
									if (5 > b)
									{
										goto IL_02e6;
									}
									goto IL_04a5;
									IL_02e6:
									if (2 < b)
									{
										goto IL_02f4;
									}
									goto IL_03f7;
									IL_02f4:
									if (3 >= b)
									{
										goto IL_02ff;
									}
									goto IL_0362;
									IL_02ff:
									if (3 <= b)
									{
										goto IL_030a;
									}
									num = 59;
									goto IL_06e0;
									IL_030a:
									ref int reference = ref array3[*(int*)(ptr + num3)];
									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
									goto IL_0333;
									IL_0333:
									ptr += 8;
									goto IL_0341;
									IL_0341:
									num4--;
									goto IL_0287;
									IL_06a8:
									array[num4] = 0;
									goto IL_06b6;
									IL_0362:
									if (4 >= b)
									{
										num = 53;
										goto IL_0379;
									}
									goto IL_06e0;
									IL_06b6:
									num4++;
									goto IL_06c4;
									IL_0379:
									if (4 <= b)
									{
										goto IL_0387;
									}
									goto IL_06e0;
									IL_0387:
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
									goto IL_03c7;
									IL_03c7:
									array[num4 - 2] = 0;
									num = 69;
									goto IL_03e4;
									IL_03e4:
									num4--;
									goto IL_0287;
									IL_03f7:
									if (2 > b)
									{
										goto IL_0402;
									}
									goto IL_0423;
									IL_0402:
									if (1 >= b)
									{
										goto IL_0410;
									}
									goto IL_06e0;
									IL_0410:
									if (1 <= b)
									{
									}
									goto IL_06e0;
									IL_0423:
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
									num = 72;
									goto IL_046c;
									IL_046c:
									array[num4 - 2] = 0;
									num = 99;
									goto IL_0489;
									IL_0489:
									num4--;
									num = 3;
									goto IL_0287;
									IL_04a5:
									array[num4] = 0;
									goto IL_04b3;
									IL_04b3:
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
									goto IL_04d6;
									IL_04d6:
									array2[num4] = null;
									goto IL_04e0;
									IL_04e0:
									num4++;
									goto IL_04ee;
									IL_04ee:
									ptr += 8;
									goto IL_0287;
									IL_0501:
									if (7 >= b)
									{
										goto IL_050f;
									}
									goto IL_05f0;
									IL_050f:
									if (7 <= b)
									{
										goto IL_051a;
									}
									goto IL_0562;
									IL_051a:
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
									goto IL_0533;
									IL_0533:
									array[num4] = 0;
									goto IL_0541;
									IL_0541:
									num4++;
									goto IL_054f;
									IL_054f:
									ptr += 8;
									goto IL_0287;
									IL_0562:
									if (6 >= b)
									{
										goto IL_056d;
									}
									num = 4;
									goto IL_06e0;
									IL_056d:
									if (6 <= b)
									{
										goto IL_057b;
									}
									goto IL_06e0;
									IL_057b:
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
									goto IL_05bb;
									IL_05bb:
									array[num4 - 2] = 0;
									goto IL_05cf;
									IL_05cf:
									num4--;
									goto IL_0287;
									IL_06c4:
									ptr += 8;
									num = 70;
									goto IL_0287;
									IL_05f0:
									if (8 < b)
									{
										goto IL_05fb;
									}
									goto IL_0633;
									IL_05fb:
									if (9 >= b)
									{
										goto IL_0609;
									}
									goto IL_06e0;
									IL_0609:
									if (9 <= b)
									{
										goto IL_0617;
									}
									goto IL_06e0;
									IL_0617:
									byte* num6 = ptr;
									num5 = 1;
									ptr = num6 + -200;
									goto IL_0287;
									IL_0633:
									if (8 <= b)
									{
										goto IL_0641;
									}
									goto IL_06e0;
									IL_0641:
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
									goto IL_0681;
									continue;
									end_IL_01d3:
									break;
								}
								continue;
								end_IL_01e3:
								break;
							}
							continue;
							end_IL_01fc:
							break;
						}
						continue;
						end_IL_020c:
						break;
					}
					continue;
					end_IL_021c:
					break;
				}
				continue;
				end_IL_022c:
				break;
			}
		}
	}

	private static Transform FileDialogPermissionAccessSpinLockFastPathFailed(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rightHandTransform;
	}

	private static GorillaTagger ForkJoinOperationTypeGetInvocationList()
	{
		return GorillaTagger.Instance;
	}

	private static float IsRunningAccess(Vector3 vector3_0)
	{
		return vector3_0.z;
	}

	private static Transform NumTimesuffVTUI(Component component_0)
	{
		return component_0.transform;
	}

	private static Vector3 BitConverterCLRConfig()
	{
		return global::_003CModule_003E.vector3_149;
	}

	private static Vector3 EvidenceLockHolderTraceFormat()
	{
		return global::_003CModule_003E.DO_002ExoRNC_003Cf;
	}

	private static Vector3 getStringMetadataSectionResourceTypeManifestResourcesDependency(Vector3 vector3_0, Vector3 vector3_1)
	{
		return vector3_0 + vector3_1;
	}

	private static Quaternion WeekFreeHGlobal(Vector3 vector3_0)
	{
		return Quaternion.LookRotation(vector3_0);
	}

	private static float getIsPrivateLdlen()
	{
		return Time.time;
	}

	private static double PropagateOutParametersNullStreamReader(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private unsafe static int smethod_10(int int_1)
	{
		int num = 123;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 68;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 37;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StrongNameCompareAssembliesCCMAX.InternalGCCollectionModeStrongNameFreeBuffer);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 119;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02f7:
																	if (b >= 1)
																	{
																		while (b <= 13)
																		{
																			while (true)
																			{
																				IL_02d7:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_02c7:
																						if (7 > b)
																						{
																							while (true)
																							{
																								IL_02b7:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_02a7:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0297:
																												if (1 >= b)
																												{
																													while (1 <= b)
																													{
																														while (true)
																														{
																															IL_026c:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_0253:
																																array[num5] = 0;
																																num = 118;
																																while (true)
																																{
																																	IL_023a:
																																	num5++;
																																	num = 134;
																																	while (true)
																																	{
																																		if (num != 134)
																																		{
																																			if (num != 1115)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 118:
																																				goto IL_023a;
																																			case 3:
																																				goto IL_0253;
																																			case 6:
																																			case 80:
																																				goto IL_026c;
																																			case 103:
																																				goto IL_0287;
																																			case 52:
																																			case 112:
																																				goto IL_0297;
																																			case 125:
																																				goto IL_02a7;
																																			case 26:
																																			case 76:
																																				goto IL_02b7;
																																			case 21:
																																				goto IL_02c7;
																																			case 53:
																																				goto IL_02d7;
																																			case 50:
																																				goto IL_02e7;
																																			case 58:
																																				goto IL_02f7;
																																			case 78:
																																				goto end_IL_02f7;
																																			case 89:
																																			case 113:
																																				goto end_IL_0307;
																																			case 30:
																																				goto IL_0335;
																																			case 92:
																																				goto IL_0343;
																																			case 97:
																																			case 102:
																																				goto IL_0351;
																																			case 34:
																																				goto IL_037a;
																																			case 27:
																																				goto IL_0391;
																																			case 13:
																																			case 46:
																																				goto IL_03a4;
																																			case 39:
																																				goto IL_03bc;
																																			case 73:
																																				goto IL_03ca;
																																			case 84:
																																				goto IL_03d8;
																																			case 66:
																																			case 81:
																																				goto IL_03e6;
																																			case 1:
																																				goto IL_0426;
																																			case 57:
																																				goto IL_043a;
																																			case 29:
																																				goto IL_044d;
																																			case 83:
																																				goto IL_0458;
																																			case 82:
																																				goto IL_0466;
																																			case 77:
																																			case 121:
																																				goto end_IL_0227;
																																			case 35:
																																				goto IL_0490;
																																			case 42:
																																				goto IL_04b3;
																																			case 67:
																																				goto IL_04bd;
																																			case 116:
																																				goto IL_04cb;
																																			case 0:
																																			case 49:
																																				goto IL_04de;
																																			case 75:
																																				goto IL_051e;
																																			case 101:
																																				goto IL_0532;
																																			case 115:
																																				goto IL_0545;
																																			case 94:
																																				goto IL_0553;
																																			case 19:
																																			case 48:
																																				goto IL_055e;
																																			case 54:
																																				goto IL_0572;
																																			case 64:
																																				goto IL_05b1;
																																			case 14:
																																			case 23:
																																				goto IL_05cd;
																																			case 109:
																																				goto IL_05e1;
																																			case 40:
																																			case 127:
																																				goto IL_05ef;
																																			case 25:
																																				goto IL_0612;
																																			case 126:
																																				goto IL_0620;
																																			case 69:
																																				goto IL_062e;
																																			case 59:
																																				goto IL_0641;
																																			case 74:
																																				goto IL_064f;
																																			case 56:
																																			case 61:
																																				goto IL_065d;
																																			case 17:
																																				goto IL_06bf;
																																			case 124:
																																				goto IL_06d2;
																																			case 22:
																																			case 105:
																																				goto IL_06dd;
																																			case 110:
																																				goto IL_06e8;
																																			case 9:
																																				goto IL_06f5;
																																			case 100:
																																				goto IL_0700;
																																			case 111:
																																				goto IL_070b;
																																			case 11:
																																			case 45:
																																				goto IL_0716;
																																			case 31:
																																			case 88:
																																				goto IL_072f;
																																			case 2:
																																			case 4:
																																			case 12:
																																			case 18:
																																			case 24:
																																			case 28:
																																			case 32:
																																			case 33:
																																			case 36:
																																			case 38:
																																			case 41:
																																			case 44:
																																			case 51:
																																			case 55:
																																			case 62:
																																			case 70:
																																			case 71:
																																			case 86:
																																			case 87:
																																			case 90:
																																			case 106:
																																			case 107:
																																			case 108:
																																			case 117:
																																				goto end_IL_0287;
																																			case 5:
																																			case 8:
																																			case 10:
																																			case 16:
																																			case 20:
																																			case 47:
																																			case 60:
																																			case 63:
																																			case 72:
																																			case 85:
																																			case 93:
																																			case 95:
																																			case 99:
																																			case 114:
																																			case 119:
																																				goto end_IL_0317;
																																			case 15:
																																				goto end_IL_075b;
																																			case 120:
																																				goto end_IL_076e;
																																			case 65:
																																				goto end_IL_0779;
																																			case 7:
																																				goto end_IL_0783;
																																			case 37:
																																				goto end_IL_078e;
																																			case 43:
																																			case 96:
																																				goto end_IL_07a3;
																																			case 68:
																																				goto end_IL_07b3;
																																			case 79:
																																			case 91:
																																				goto end_IL_07cc;
																																			case 122:
																																				goto end_IL_07dc;
																																			case 123:
																																				goto end_IL_07f5;
																																			case 98:
																																			case 104:
																																				goto IL_0810;
																																			}
																																			continue;
																																		}
																																		ptr2 += 8;
																																		goto end_IL_0317;
																																		continue;
																																		end_IL_0227:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0479;
																														continue;
																														end_IL_0287:
																														break;
																														IL_0287:;
																													}
																													break;
																												}
																												goto IL_0335;
																												IL_0391:
																												num5--;
																												goto end_IL_0317;
																												IL_0335:
																												if (2 < b)
																												{
																													break;
																												}
																												goto IL_0343;
																												IL_0343:
																												if (2 > b)
																												{
																													break;
																												}
																												goto IL_0351;
																												IL_0351:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_037a;
																												IL_037a:
																												ptr2 += 8;
																												num = 27;
																												goto IL_0391;
																											}
																											break;
																										}
																										goto IL_03a4;
																										IL_03a4:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_0317;
																									}
																									break;
																								}
																								goto IL_03bc;
																								IL_04cb:
																								ptr2 += 8;
																								goto end_IL_0317;
																								IL_03bc:
																								if (5 < b)
																								{
																									goto IL_03ca;
																								}
																								goto IL_044d;
																								IL_03ca:
																								if (6 < b)
																								{
																									break;
																								}
																								goto IL_03d8;
																								IL_03d8:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_03e6;
																								IL_03e6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0426;
																								IL_0426:
																								array[num5 - 2] = 0;
																								goto IL_043a;
																								IL_043a:
																								num5--;
																								goto end_IL_0317;
																								IL_044d:
																								if (5 > b)
																								{
																									goto IL_0458;
																								}
																								goto IL_0479;
																								IL_0458:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0466;
																								IL_0466:
																								if (4 <= b)
																								{
																									goto end_IL_0317;
																								}
																								break;
																								IL_0479:
																								array[num5] = 0;
																								num = 35;
																								goto IL_0490;
																								IL_0490:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_04b3;
																								IL_04b3:
																								array2[num5] = null;
																								goto IL_04bd;
																								IL_04bd:
																								num5++;
																								goto IL_04cb;
																							}
																							break;
																						}
																						goto IL_04de;
																						IL_0532:
																						num5--;
																						goto end_IL_0317;
																						IL_04de:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_051e;
																						IL_051e:
																						array[num5 - 2] = 0;
																						goto IL_0532;
																					}
																					break;
																				}
																				goto IL_0545;
																				IL_070b:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0716;
																				IL_0545:
																				if (10 >= b)
																				{
																					goto IL_0553;
																				}
																				goto IL_06d2;
																				IL_0553:
																				if (10 <= b)
																				{
																					goto IL_055e;
																				}
																				num = 23;
																				goto IL_05cd;
																				IL_055e:
																				array[num5 - 1] = 0;
																				goto IL_0572;
																				IL_0572:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)EventLogClassicModeHalfwidthKatakana[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_05b1;
																				IL_05b1:
																				ptr2 += 8;
																				goto end_IL_0317;
																				IL_0716:
																				num5--;
																				goto end_IL_0317;
																				IL_05cd:
																				if (8 >= b)
																				{
																					num = 109;
																					goto IL_05e1;
																				}
																				goto IL_0641;
																				IL_072f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0317;
																				IL_05e1:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_05ef;
																				IL_05ef:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0612;
																				IL_0612:
																				array[num5] = 0;
																				goto IL_0620;
																				IL_0620:
																				num5++;
																				goto IL_062e;
																				IL_062e:
																				ptr2 += 8;
																				goto end_IL_0317;
																				IL_0641:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_064f;
																				IL_064f:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_065d;
																				IL_065d:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06bf;
																				IL_06bf:
																				num5 -= 2;
																				goto end_IL_0317;
																				IL_06d2:
																				if (12 < b)
																				{
																					goto IL_06dd;
																				}
																				goto IL_06f5;
																				IL_06dd:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_06e8;
																				IL_06e8:
																				if (13 > b)
																				{
																				}
																				break;
																				IL_06f5:
																				if (12 > b)
																				{
																					goto IL_0700;
																				}
																				num = 88;
																				goto IL_072f;
																				IL_0700:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_070b;
																			}
																			break;
																			IL_02e7:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0317;
																	continue;
																	end_IL_02f7:
																	break;
																}
																continue;
																end_IL_0307:
																break;
															}
															continue;
															end_IL_0317:
															break;
														}
														continue;
													}
													goto IL_0810;
													IL_0810:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_075b:
													break;
												}
												continue;
												end_IL_076e:
												break;
											}
											continue;
											end_IL_0779:
											break;
										}
										continue;
										end_IL_0783:
										break;
									}
									continue;
									end_IL_078e:
									break;
								}
								continue;
								end_IL_07a3:
								break;
							}
							continue;
							end_IL_07b3:
							break;
						}
						continue;
						end_IL_07cc:
						break;
					}
					continue;
					end_IL_07dc:
					break;
				}
				continue;
				end_IL_07f5:
				break;
			}
		}
	}

	private static Vector3 ReferenceMatchesDefinitionremoveCancelKeyPress()
	{
		return Vector3.down;
	}

	static Class185()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0068:
				Class300.smethod_0();
				while (true)
				{
					IL_0056:
					num = 4;
					while (true)
					{
						IL_004a:
						num = 13;
						while (true)
						{
							if (num != 13)
							{
								if (num != 994)
								{
									break;
								}
								switch (num)
								{
								case 4:
									goto IL_004a;
								case 0:
								case 1:
								case 6:
									goto IL_0056;
								case 2:
									goto IL_0068;
								case 3:
									goto end_IL_003d;
								case 5:
									return;
								}
								continue;
							}
							return;
							continue;
							end_IL_003d:
							break;
						}
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
