using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Auto Run", "Rig", "Hold right grab to auto run.", false, 9, ModType.const_0, false)]
internal class Class170 : MonoBehaviour
{
	private static double double_0;

	private static double double_1;

	private static float float_0;

	private static int int_0;

	private static float float_1;

	private static IntPtr[] BrowserStopParseFlags;

	private static IntPtr[] getKeyboardLayoutIdTupleElementNamesAttribute;

	private static IntPtr[] StreetAddressCreateActContextParametersSourceDefinitionAppid;

	private static IntPtr[] ApplicationIdentityArgumentOutOfRangeCount;

	private static IntPtr[] SyncStreamGetTypeComp;

	private static Vector3 getKeysGetHashToMatch(Vector3 vector3_0, Vector3 vector3_1, float float_2)
	{
		return Vector3.Lerp(vector3_0, vector3_1, float_2);
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 31;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LocallocFormKDDisallowUnassigned.SendToInlineSwitch);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0281:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0261:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0251:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0241:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0234:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_01e6:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													num = 113;
																													while (true)
																													{
																														if (num != 113)
																														{
																															if (num != 1094)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 42:
																															case 105:
																																goto IL_01e6;
																															case 78:
																																goto IL_0214;
																															case 44:
																																goto IL_0224;
																															case 97:
																																goto IL_0234;
																															case 55:
																																goto IL_0241;
																															case 52:
																															case 87:
																																goto IL_0251;
																															case 96:
																																goto IL_0261;
																															case 72:
																																goto IL_0271;
																															case 37:
																																goto IL_0281;
																															case 30:
																																goto end_IL_0281;
																															case 39:
																															case 60:
																																goto end_IL_0291;
																															case 33:
																																goto end_IL_01d3;
																															case 75:
																															case 103:
																																goto IL_02c5;
																															case 71:
																																goto IL_0305;
																															case 49:
																																goto IL_0319;
																															case 92:
																																goto IL_033a;
																															case 22:
																																goto IL_0348;
																															case 14:
																															case 73:
																																goto IL_035b;
																															case 35:
																																goto IL_03bd;
																															case 12:
																															case 63:
																																goto IL_03d0;
																															case 18:
																																goto IL_03db;
																															case 2:
																															case 106:
																																goto IL_03e9;
																															case 5:
																																goto IL_0405;
																															case 82:
																																goto IL_0413;
																															case 89:
																																goto IL_0426;
																															case 95:
																																goto IL_0434;
																															case 9:
																															case 36:
																																goto IL_043f;
																															case 11:
																															case 58:
																																goto IL_044a;
																															case 20:
																																goto IL_0458;
																															case 38:
																																goto IL_046b;
																															case 54:
																															case 102:
																																goto IL_0479;
																															case 62:
																																goto IL_0491;
																															case 16:
																															case 19:
																																goto IL_049c;
																															case 1:
																																goto IL_04c5;
																															case 45:
																																goto IL_04d3;
																															case 7:
																															case 26:
																																goto IL_04e6;
																															case 21:
																																goto IL_04f4;
																															case 43:
																															case 68:
																																goto IL_0502;
																															case 48:
																																goto IL_051b;
																															case 81:
																																goto IL_0529;
																															case 104:
																																goto IL_0537;
																															case 25:
																															case 86:
																																goto IL_0547;
																															case 70:
																																goto IL_055e;
																															case 91:
																																goto IL_0581;
																															case 24:
																																goto IL_0594;
																															case 66:
																																goto IL_05a2;
																															case 0:
																															case 3:
																															case 4:
																															case 6:
																															case 17:
																															case 28:
																															case 29:
																															case 46:
																															case 50:
																															case 51:
																															case 53:
																															case 57:
																															case 59:
																															case 61:
																															case 77:
																															case 79:
																															case 80:
																															case 83:
																															case 93:
																															case 94:
																															case 101:
																																goto end_IL_0214;
																															case 13:
																															case 27:
																															case 34:
																															case 56:
																															case 64:
																															case 67:
																															case 74:
																															case 76:
																															case 88:
																															case 90:
																															case 98:
																															case 99:
																															case 100:
																																goto end_IL_02a1;
																															case 15:
																																goto end_IL_05c5;
																															case 69:
																																goto end_IL_05d8;
																															case 40:
																																goto end_IL_05e2;
																															case 23:
																																goto end_IL_05ed;
																															case 10:
																															case 41:
																																goto end_IL_0602;
																															case 47:
																																goto end_IL_0612;
																															case 8:
																															case 65:
																																goto end_IL_0622;
																															case 31:
																																goto end_IL_0632;
																															case 32:
																																goto end_IL_0642;
																															case 84:
																															case 85:
																																goto IL_0666;
																															}
																															continue;
																														}
																														array[num5] = 0;
																														goto IL_033a;
																														IL_033a:
																														num5++;
																														goto IL_0348;
																														IL_0348:
																														ptr2 += 8;
																														goto end_IL_02a1;
																														continue;
																														end_IL_01d3:
																														break;
																													}
																													break;
																												}
																												goto IL_02ac;
																												continue;
																												end_IL_0214:
																												break;
																												IL_0214:;
																											}
																											break;
																											IL_0224:;
																										}
																										break;
																									}
																									goto IL_02ac;
																									IL_0305:
																									array[num5 - 2] = 0;
																									goto IL_0319;
																									IL_02ac:
																									if (6 > b)
																									{
																										num = 50;
																										break;
																									}
																									goto IL_02c5;
																									IL_0319:
																									num5--;
																									goto end_IL_02a1;
																									IL_02c5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0305;
																								}
																								break;
																							}
																							goto IL_035b;
																							IL_03bd:
																							num5 -= 2;
																							goto end_IL_02a1;
																							IL_035b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03bd;
																						}
																						break;
																					}
																					goto IL_03d0;
																					IL_0413:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_03d0:
																					if (9 >= b)
																					{
																						goto IL_03db;
																					}
																					goto IL_0405;
																					IL_03db:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_03e9;
																					IL_03e9:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02a1;
																					IL_0405:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0413;
																				}
																				break;
																			}
																			goto IL_0426;
																			IL_05a2:
																			ptr2 += 8;
																			goto end_IL_02a1;
																			IL_0426:
																			if (5 > b)
																			{
																				goto IL_0434;
																			}
																			goto IL_0547;
																			IL_0434:
																			if (2 < b)
																			{
																				goto IL_043f;
																			}
																			goto IL_0491;
																			IL_043f:
																			if (3 < b)
																			{
																				goto IL_044a;
																			}
																			goto IL_046b;
																			IL_044a:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0458;
																			IL_0458:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02a1;
																			IL_046b:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0479;
																			IL_0479:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02a1;
																			IL_0491:
																			if (2 <= b)
																			{
																				goto IL_049c;
																			}
																			goto IL_04e6;
																			IL_049c:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04c5;
																			IL_04c5:
																			ptr2 += 8;
																			goto IL_04d3;
																			IL_04d3:
																			num5--;
																			goto end_IL_02a1;
																			IL_04e6:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04f4;
																			IL_04f4:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0502;
																			IL_0502:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_051b;
																			IL_051b:
																			array[num5] = 0;
																			goto IL_0529;
																			IL_0529:
																			num5++;
																			goto IL_0537;
																			IL_0537:
																			ptr2 += 8;
																			goto end_IL_02a1;
																			IL_0547:
																			array[num5] = 0;
																			num = 70;
																			goto IL_055e;
																			IL_055e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0581;
																			IL_0581:
																			array2[num5] = null;
																			num = 24;
																			goto IL_0594;
																			IL_0594:
																			num5++;
																			goto IL_05a2;
																		}
																		break;
																		IL_0271:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a1;
																continue;
																end_IL_0281:
																break;
															}
															continue;
															end_IL_0291:
															break;
														}
														continue;
														end_IL_02a1:
														break;
													}
													continue;
												}
												goto IL_0666;
												IL_0666:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05c5:
												break;
											}
											continue;
											end_IL_05d8:
											break;
										}
										continue;
										end_IL_05e2:
										break;
									}
									continue;
									end_IL_05ed:
									break;
								}
								continue;
								end_IL_0602:
								break;
							}
							continue;
							end_IL_0612:
							break;
						}
						continue;
						end_IL_0622:
						break;
					}
					continue;
					end_IL_0632:
					break;
				}
				continue;
				end_IL_0642:
				break;
			}
		}
	}

	private static Vector3 EphemeralKeySetgetControlPolicy(Vector3 vector3_0, Vector3 vector3_1)
	{
		return vector3_0 + vector3_1;
	}

	private static int smethod_1(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_1;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private static Vector3 PrincipalPermissionAttributegetTypeInfo(ref RaycastHit raycastHit_0)
	{
		return raycastHit_0.point;
	}

	private static Vector3 KeyAvailableISCIIEncoding(Vector3 vector3_0, float float_2)
	{
		return vector3_0 * float_2;
	}

	private static object EventManifestOptionsMaximumAge(float float_2, float float_3, float float_4)
	{
		return new Vector3(float_2, float_3, float_4);
	}

	private static double MemberReferenceVectorViewToReadOnlyCollectionAdapter(double double_2)
	{
		return Math.Round(double_2);
	}

	private static float getExceptionStateLastCalledMethodClass()
	{
		return global::_003CModule_003E.float_107;
	}

	public Class170()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static float OpcodegetArgCount(Vector3 vector3_0)
	{
		return vector3_0.y;
	}

	private static double cFuncsopEquality(double double_2)
	{
		return Math.Log10(double_2);
	}

	private static Vector3 NoDefineVersionResourceInsufficientExecutionStackException()
	{
		return global::_003CModule_003E.vector3_122;
	}

	private static Vector3 getSchedulerPairImageRuntimeVersion()
	{
		return global::_003CModule_003E.vector3_114;
	}

	private static float SignDataIMethodCallMessage()
	{
		return Time.time;
	}

	private static int getJustificationConvertPermissionSet(LayerMask layerMask_0)
	{
		return layerMask_0;
	}

	private static Transform OemClearsetVersionAdded(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rightHandTransform;
	}

	private static int CDataBeginScope(string[] string_0)
	{
		return LayerMask.GetMask(string_0);
	}

	private static double BraceFormatScope(double double_2)
	{
		return Math.Floor(double_2);
	}

	private static Vector3 DecoderFallbackExceptionApplication(Vector3 vector3_0, Vector3 vector3_1)
	{
		return vector3_0 + vector3_1;
	}

	private static void IEnumeratorUnrecognized(Transform transform_0, Vector3 vector3_0)
	{
		transform_0.position = vector3_0;
	}

	private static int BeginReadSizedArray(double double_2)
	{
		return Convert.ToInt32(double_2);
	}

	private static double CModReqdOnStop(double double_2)
	{
		return Math.Sin(double_2);
	}

	private static Vector3 getIsInvalidgetMinSize()
	{
		return global::_003CModule_003E.vector3_117;
	}

	private static double smethod_3(double double_2)
	{
		return Math.Tanh(double_2);
	}

	private static Vector3 EmitCallDeleteValue()
	{
		return global::_003CModule_003E.vector3_115;
	}

	private static LayerMask getResolverReleaseAllResources(int int_1)
	{
		return int_1;
	}

	private static double JulianEragetDefaultIcon(double double_2)
	{
		return Math.Ceiling(double_2);
	}

	private static Transform AppDomainInitializerInfoAccessControlType(Component component_0)
	{
		return component_0.transform;
	}

	private static bool VARFLAGFDEFAULTBINDgetCreate(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightGrab;
	}

	private static Vector3 FUNCFLAGFBINDABLEGetElementType()
	{
		return Vector3.down;
	}

	private static double SystemPageSizeCOREFILELOAD(double double_2)
	{
		return Math.Tan(double_2);
	}

	private static Vector3 DEFAULTIMuiResourceTypeIdStringEntry(Transform transform_0)
	{
		return transform_0.forward;
	}

	private static bool IsPunctuationResourceWriter(Vector3 vector3_0, Vector3 vector3_1, ref RaycastHit raycastHit_0, float float_2, int int_1)
	{
		return Physics.Raycast(vector3_0, vector3_1, out raycastHit_0, float_2, int_1);
	}

	private static double GetClassLayoutEnvoyTerminatorSink(double double_2)
	{
		return Math.Log(double_2);
	}

	private static CapsuleCollider SetSwitchgetSourceLength(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.bodyCollider;
	}

	private static SphereCollider GetPrimaryInteropAssemblygetInstantiationArgs(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.headCollider;
	}

	private static Vector3 CpblkCkfinite(Vector3 vector3_0, float float_2)
	{
		return vector3_0 * float_2;
	}

	private unsafe static int smethod_4()
	{
		int num = 144;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 143;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref creationOptionsForReplicasPortable.setMonthGenitiveNamesSparselyPopulatedArray);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03cf:
														byte b = *ptr2;
														while (true)
														{
															IL_03bf:
															ptr2++;
															while (true)
															{
																IL_03ac:
																if (b >= 1)
																{
																	num = 91;
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_038c:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_036c:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_035c:
																								if (4 > b)
																								{
																									while (true)
																									{
																										IL_034c:
																										if (2 >= b)
																										{
																											while (true)
																											{
																												IL_033c:
																												if (2 > b)
																												{
																													while (1 >= b)
																													{
																														while (1 <= b)
																														{
																															while (true)
																															{
																																IL_0301:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																while (true)
																																{
																																	IL_02f1:
																																	array[num5] = 0;
																																	while (true)
																																	{
																																		IL_02d8:
																																		num5++;
																																		num = 170;
																																		while (true)
																																		{
																																			if (num != 170)
																																			{
																																				if (num != 1151)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 103:
																																					goto IL_02d8;
																																				case 99:
																																					goto IL_02f1;
																																				case 48:
																																				case 159:
																																					goto IL_0301;
																																				case 95:
																																					goto IL_031c;
																																				case 7:
																																					goto IL_032c;
																																				case 121:
																																					goto IL_033c;
																																				case 72:
																																				case 75:
																																					goto IL_034c;
																																				case 129:
																																					goto IL_035c;
																																				case 46:
																																					goto IL_036c;
																																				case 90:
																																					goto IL_037c;
																																				case 112:
																																					goto IL_038c;
																																				case 91:
																																					goto IL_039c;
																																				case 111:
																																					goto IL_03ac;
																																				case 89:
																																					goto IL_03bf;
																																				case 34:
																																				case 38:
																																					goto IL_03cf;
																																				case 119:
																																				case 152:
																																					goto IL_03ed;
																																				case 23:
																																					goto IL_042d;
																																				case 127:
																																					goto IL_0441;
																																				case 55:
																																				case 122:
																																					goto IL_045d;
																																				case 41:
																																					goto IL_046b;
																																				case 133:
																																				case 151:
																																					goto IL_0479;
																																				case 9:
																																					goto IL_04ab;
																																				case 109:
																																				case 138:
																																					goto IL_04c4;
																																				case 131:
																																					goto IL_04e2;
																																				case 73:
																																					goto IL_04f0;
																																				case 124:
																																				case 145:
																																					goto IL_050c;
																																				case 66:
																																				case 125:
																																					goto IL_051a;
																																				case 27:
																																					goto IL_052e;
																																				case 3:
																																				case 45:
																																					goto IL_053c;
																																				case 146:
																																					goto IL_0565;
																																				case 141:
																																					goto IL_0573;
																																				case 51:
																																					goto IL_0586;
																																				case 140:
																																					goto IL_0591;
																																				case 88:
																																				case 102:
																																					goto IL_059f;
																																				case 63:
																																					goto IL_05c5;
																																				case 32:
																																				case 62:
																																					goto IL_05d0;
																																				case 117:
																																					goto IL_05de;
																																				case 108:
																																				case 163:
																																					goto IL_05ec;
																																				case 16:
																																					goto IL_05fa;
																																				case 18:
																																					goto IL_0612;
																																				case 156:
																																					goto IL_0620;
																																				case 22:
																																				case 50:
																																					goto IL_0633;
																																				case 67:
																																					goto IL_0672;
																																				case 20:
																																				case 110:
																																					goto IL_0685;
																																				case 77:
																																				case 123:
																																					goto IL_0693;
																																				case 14:
																																					goto IL_069e;
																																				case 74:
																																					goto IL_06a9;
																																				case 118:
																																				case 142:
																																					goto IL_06b7;
																																				case 60:
																																					goto IL_06d3;
																																				case 137:
																																					goto IL_06e1;
																																				case 85:
																																					goto IL_06f4;
																																				case 65:
																																				case 104:
																																					goto IL_06ff;
																																				case 42:
																																					goto IL_0712;
																																				case 84:
																																					goto IL_0720;
																																				case 105:
																																				case 116:
																																					goto IL_072e;
																																				case 44:
																																					goto IL_074b;
																																				case 26:
																																					goto IL_078a;
																																				case 162:
																																					goto IL_07a6;
																																				case 58:
																																				case 97:
																																					goto IL_07b4;
																																				case 4:
																																				case 128:
																																					goto IL_07c2;
																																				case 115:
																																					goto IL_07d0;
																																				case 53:
																																				case 76:
																																					goto IL_07de;
																																				case 12:
																																					goto IL_081e;
																																				case 106:
																																					goto IL_0832;
																																				case 139:
																																					goto IL_0845;
																																				case 1:
																																				case 98:
																																					goto IL_0850;
																																				case 5:
																																					goto IL_0894;
																																				case 15:
																																					goto IL_08a8;
																																				case 33:
																																					goto IL_08bb;
																																				case 79:
																																					goto IL_08d1;
																																				case 82:
																																				case 87:
																																					goto end_IL_02c5;
																																				case 83:
																																					goto IL_08ea;
																																				case 54:
																																					goto IL_090d;
																																				case 94:
																																					goto IL_0920;
																																				case 28:
																																					goto IL_092e;
																																				case 0:
																																				case 2:
																																				case 6:
																																				case 13:
																																				case 17:
																																				case 25:
																																				case 35:
																																				case 37:
																																				case 40:
																																				case 43:
																																				case 47:
																																				case 49:
																																				case 52:
																																				case 56:
																																				case 61:
																																				case 69:
																																				case 78:
																																				case 80:
																																				case 81:
																																				case 86:
																																				case 101:
																																				case 113:
																																				case 126:
																																				case 136:
																																				case 148:
																																				case 149:
																																				case 150:
																																				case 155:
																																				case 160:
																																					goto end_IL_031c;
																																				case 29:
																																				case 135:
																																					goto IL_0956;
																																				case 71:
																																					goto IL_09b8;
																																				case 8:
																																				case 10:
																																				case 19:
																																				case 30:
																																				case 36:
																																				case 39:
																																				case 57:
																																				case 68:
																																				case 70:
																																				case 92:
																																				case 96:
																																				case 100:
																																				case 107:
																																				case 114:
																																				case 120:
																																				case 132:
																																				case 134:
																																				case 153:
																																				case 158:
																																				case 161:
																																					goto end_IL_037c;
																																				case 31:
																																					goto end_IL_09c6;
																																				case 11:
																																					goto end_IL_09d9;
																																				case 59:
																																					goto end_IL_09e3;
																																				case 24:
																																					goto end_IL_09ee;
																																				case 21:
																																				case 93:
																																					goto end_IL_09fe;
																																				case 130:
																																					goto end_IL_0a0e;
																																				case 64:
																																				case 157:
																																					goto end_IL_0a1e;
																																				case 143:
																																					goto end_IL_0a2e;
																																				case 144:
																																					goto end_IL_0a3e;
																																				case 147:
																																				case 154:
																																					goto IL_0a6b;
																																				}
																																				continue;
																																			}
																																			ptr2 += 8;
																																			goto end_IL_037c;
																																			continue;
																																			end_IL_02c5:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_08dc;
																															continue;
																															end_IL_031c:
																															break;
																															IL_031c:;
																														}
																														break;
																														IL_032c:;
																													}
																													break;
																												}
																												goto IL_03ed;
																												IL_0441:
																												num5--;
																												num = 36;
																												goto end_IL_037c;
																												IL_03ed:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_042d;
																												IL_042d:
																												array[num5 - 2] = 0;
																												goto IL_0441;
																											}
																											break;
																										}
																										goto IL_045d;
																										IL_04ab:
																										array[num5 - 1] = 5;
																										goto end_IL_037c;
																										IL_045d:
																										if (3 < b)
																										{
																											break;
																										}
																										goto IL_046b;
																										IL_046b:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0479;
																										IL_0479:
																										array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										num = 9;
																										goto IL_04ab;
																									}
																									break;
																								}
																								goto IL_04c4;
																								IL_04f0:
																								num5--;
																								goto end_IL_037c;
																								IL_04c4:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_04e2;
																								IL_04e2:
																								ptr2 += 8;
																								goto IL_04f0;
																							}
																							break;
																						}
																						num = 145;
																						goto IL_050c;
																						IL_0612:
																						num5++;
																						goto IL_0620;
																						IL_0620:
																						ptr2 += 8;
																						goto end_IL_037c;
																						IL_050c:
																						if (6 < b)
																						{
																							goto IL_051a;
																						}
																						goto IL_05c5;
																						IL_051a:
																						if (7 >= b)
																						{
																							num = 27;
																							goto IL_052e;
																						}
																						goto IL_0586;
																						IL_0633:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0672;
																						IL_052e:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_053c;
																						IL_053c:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0565;
																						IL_0565:
																						ptr2 += 8;
																						goto IL_0573;
																						IL_0573:
																						num5--;
																						goto end_IL_037c;
																						IL_0586:
																						if (8 < b)
																						{
																							num = 101;
																							break;
																						}
																						goto IL_0591;
																						IL_0591:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_059f;
																						IL_059f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_037c;
																						IL_0672:
																						num5 -= 3;
																						goto end_IL_037c;
																						IL_05c5:
																						if (6 > b)
																						{
																							goto IL_05d0;
																						}
																						goto IL_0633;
																						IL_05d0:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_05de;
																						IL_05de:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_05ec;
																						IL_05ec:
																						array[num5] = 5;
																						goto IL_05fa;
																						IL_05fa:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0612;
																					}
																					goto end_IL_039c;
																					continue;
																					end_IL_037c:
																					break;
																					IL_037c:;
																				}
																				break;
																			}
																			goto IL_0685;
																			IL_0956:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_09b8;
																			IL_0685:
																			if (13 < b)
																			{
																				goto IL_0693;
																			}
																			goto IL_07a6;
																			IL_0693:
																			if (15 < b)
																			{
																				goto IL_069e;
																			}
																			goto IL_06f4;
																			IL_069e:
																			if (16 >= b)
																			{
																				goto IL_06a9;
																			}
																			goto IL_06d3;
																			IL_06a9:
																			if (16 > b)
																			{
																				goto end_IL_039c;
																			}
																			goto IL_06b7;
																			IL_06b7:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_06d3:
																			if (17 < b)
																			{
																				goto end_IL_039c;
																			}
																			goto IL_06e1;
																			IL_06e1:
																			if (17 > b)
																			{
																			}
																			goto end_IL_039c;
																			IL_06f4:
																			if (15 <= b)
																			{
																				goto IL_06ff;
																			}
																			goto IL_0712;
																			IL_06ff:
																			num5--;
																			break;
																			IL_0712:
																			if (14 < b)
																			{
																				goto end_IL_039c;
																			}
																			goto IL_0720;
																			IL_0720:
																			if (14 > b)
																			{
																				goto end_IL_039c;
																			}
																			goto IL_072e;
																			IL_072e:
																			array[num5 - 1] = 0;
																			num = 44;
																			goto IL_074b;
																			IL_074b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ApplicationIdentityArgumentOutOfRangeCount[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_078a;
																			IL_078a:
																			ptr2 += 8;
																			num = 19;
																			break;
																			IL_07a6:
																			if (13 > b)
																			{
																				goto IL_07b4;
																			}
																			goto IL_0956;
																			IL_07b4:
																			if (11 < b)
																			{
																				goto IL_07c2;
																			}
																			goto IL_0845;
																			IL_07c2:
																			if (12 < b)
																			{
																				goto end_IL_039c;
																			}
																			goto IL_07d0;
																			IL_07d0:
																			if (12 > b)
																			{
																				goto end_IL_039c;
																			}
																			goto IL_07de;
																			IL_07de:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_081e;
																			IL_081e:
																			array[num5 - 2] = 0;
																			goto IL_0832;
																			IL_0832:
																			num5--;
																			break;
																			IL_0845:
																			if (11 <= b)
																			{
																				goto IL_0850;
																			}
																			goto IL_08bb;
																			IL_0850:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0894;
																			IL_0894:
																			array[num5 - 2] = 0;
																			goto IL_08a8;
																			IL_08a8:
																			num5--;
																			break;
																			IL_08bb:
																			if (10 < b)
																			{
																				num = 81;
																				goto end_IL_039c;
																			}
																			goto IL_08d1;
																			IL_09b8:
																			num5 -= 2;
																			break;
																			IL_08d1:
																			if (10 > b)
																			{
																				goto end_IL_039c;
																			}
																			goto IL_08dc;
																			IL_08dc:
																			array[num5] = 0;
																			goto IL_08ea;
																			IL_08ea:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_090d;
																			IL_090d:
																			array2[num5] = null;
																			num = 94;
																			goto IL_0920;
																			IL_0920:
																			num5++;
																			goto IL_092e;
																			IL_092e:
																			ptr2 += 8;
																			break;
																		}
																		goto end_IL_03ac;
																		continue;
																		end_IL_039c:
																		break;
																		IL_039c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_03ac:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 154;
												goto IL_0a6b;
												IL_0a6b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09c6:
												break;
											}
											continue;
											end_IL_09d9:
											break;
										}
										continue;
										end_IL_09e3:
										break;
									}
									continue;
									end_IL_09ee:
									break;
								}
								continue;
								end_IL_09fe:
								break;
							}
							continue;
							end_IL_0a0e:
							break;
						}
						continue;
						end_IL_0a1e:
						break;
					}
					continue;
					end_IL_0a2e:
					break;
				}
				continue;
				end_IL_0a3e:
				break;
			}
		}
	}

	private static Transform GetMethodTokenIAssemblyReferenceEntry(Component component_0)
	{
		return component_0.transform;
	}

	private static Vector3 CompilerGlobalScopeAttributeGetDeploymentManifestBytes()
	{
		return global::_003CModule_003E.vector3_119;
	}

	private static GorillaTagger ExceptionInfoOpenFile()
	{
		return GorillaTagger.Instance;
	}

	private static Vector3 SecurityContextDisableFlowAsType(ref Vector3 vector3_0)
	{
		return vector3_0.normalized;
	}

	private unsafe void Update()
	{
		int num = 2;
		int num3 = default(int);
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			num = 14;
			while (true)
			{
				if (num != 14)
				{
					if (num == 995)
					{
						switch (num)
						{
						case 2:
							goto end_IL_0041;
						case 7:
							goto IL_005f;
						case 0:
							goto IL_0064;
						case 4:
						case 5:
							goto IL_0097;
						case 3:
							goto IL_009d;
						case 1:
						case 6:
							return;
						}
						continue;
					}
				}
				else
				{
					num3 = 0;
				}
				goto IL_005f;
				IL_0097:
				if (num3 != 66)
				{
					goto IL_0064;
				}
				goto IL_009d;
				IL_0064:
				((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, void>)BrowserStopParseFlags[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref num11);
				goto IL_0097;
				IL_009d:
				num3 = 0;
				return;
				IL_005f:
				num3 = 0;
				goto IL_0097;
				continue;
				end_IL_0041:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 60;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UIntPtrTypegetAreAccessRulesCanonical.getMaxSizegetSignature);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_026c:
															byte b = *ptr2;
															while (true)
															{
																IL_025c:
																ptr2++;
																while (true)
																{
																	IL_024c:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_022f:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_021f:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_020f:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01ff:
																										if (3 >= b)
																										{
																											while (3 <= b)
																											{
																												num = 111;
																												while (true)
																												{
																													if (num != 111)
																													{
																														if (num != 1092)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 5:
																															goto IL_01ec;
																														case 24:
																															goto IL_01ff;
																														case 34:
																														case 71:
																															goto IL_020f;
																														case 61:
																															goto IL_021f;
																														case 35:
																															goto IL_022f;
																														case 10:
																															goto IL_023c;
																														case 92:
																															goto IL_024c;
																														case 98:
																															goto IL_025c;
																														case 39:
																														case 74:
																															goto IL_026c;
																														case 4:
																														case 28:
																															goto IL_0277;
																														case 17:
																														case 70:
																															goto IL_0282;
																														case 0:
																															goto IL_028d;
																														case 55:
																															goto IL_029b;
																														case 7:
																														case 65:
																															goto IL_02a9;
																														case 72:
																															goto IL_02d3;
																														case 26:
																														case 30:
																															goto IL_02de;
																														case 82:
																															goto IL_02f7;
																														case 53:
																															goto IL_0305;
																														case 86:
																															goto IL_0313;
																														case 1:
																														case 99:
																															goto IL_0326;
																														case 33:
																															goto IL_0334;
																														case 13:
																														case 68:
																															goto IL_0342;
																														case 101:
																															goto IL_0382;
																														case 16:
																															goto IL_0396;
																														case 103:
																															goto IL_03a9;
																														case 6:
																														case 52:
																															goto IL_03b7;
																														case 43:
																															goto IL_03f7;
																														case 93:
																															goto IL_040b;
																														case 45:
																															goto IL_041e;
																														case 57:
																															goto IL_0447;
																														case 87:
																															goto IL_0455;
																														case 32:
																															goto IL_0468;
																														case 46:
																															goto IL_0476;
																														case 12:
																														case 96:
																															goto IL_0484;
																														case 81:
																															goto IL_04c4;
																														case 21:
																															goto IL_04d8;
																														case 100:
																															goto IL_04eb;
																														case 3:
																														case 19:
																															goto IL_04f6;
																														case 90:
																															goto IL_0536;
																														case 78:
																															goto IL_054a;
																														case 56:
																															goto IL_055d;
																														case 85:
																															goto IL_0568;
																														case 2:
																														case 75:
																															goto IL_0575;
																														case 36:
																															goto IL_0583;
																														case 29:
																															goto IL_05a6;
																														case 50:
																															goto IL_05b0;
																														case 69:
																															goto IL_05be;
																														case 11:
																														case 14:
																														case 15:
																														case 18:
																														case 20:
																														case 22:
																														case 23:
																														case 44:
																														case 49:
																														case 58:
																														case 63:
																														case 64:
																														case 66:
																														case 76:
																														case 79:
																														case 83:
																														case 89:
																														case 97:
																															goto end_IL_01ec;
																														case 47:
																															goto IL_05f1;
																														case 25:
																															goto IL_05ff;
																														case 73:
																															goto IL_060d;
																														case 8:
																														case 38:
																														case 40:
																														case 54:
																														case 62:
																														case 67:
																														case 80:
																														case 84:
																														case 91:
																														case 94:
																														case 102:
																															goto end_IL_01d9;
																														case 104:
																															goto end_IL_061b;
																														case 31:
																															goto end_IL_062e;
																														case 48:
																															goto end_IL_0638;
																														case 77:
																															goto end_IL_0643;
																														case 41:
																															goto end_IL_0658;
																														case 42:
																														case 88:
																															goto end_IL_066d;
																														case 37:
																															goto end_IL_067d;
																														case 9:
																														case 95:
																															goto end_IL_068d;
																														case 59:
																															goto end_IL_069d;
																														case 60:
																															goto end_IL_06ad;
																														case 27:
																														case 51:
																															goto IL_06c8;
																														}
																														continue;
																													}
																													goto IL_041e;
																													IL_0447:
																													ptr2 += 8;
																													goto IL_0455;
																													IL_0455:
																													num5--;
																													break;
																													IL_041e:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0447;
																													continue;
																													end_IL_01d9:
																													break;
																												}
																												goto end_IL_024c;
																												continue;
																												end_IL_01ec:
																												break;
																												IL_01ec:;
																											}
																											break;
																										}
																										goto IL_0468;
																										IL_04d8:
																										num5--;
																										goto end_IL_024c;
																										IL_0468:
																										if (4 < b)
																										{
																											break;
																										}
																										goto IL_0476;
																										IL_0476:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_0484;
																										IL_0484:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_04c4;
																										IL_04c4:
																										array[num5 - 2] = 0;
																										goto IL_04d8;
																									}
																									break;
																								}
																								goto IL_04eb;
																								IL_0568:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_04eb:
																								if (2 <= b)
																								{
																									goto IL_04f6;
																								}
																								goto IL_055d;
																								IL_04f6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0536;
																								IL_0536:
																								array[num5 - 2] = 0;
																								goto IL_054a;
																								IL_054a:
																								num5--;
																								goto end_IL_024c;
																								IL_055d:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0568;
																							}
																							break;
																						}
																						goto IL_0575;
																						IL_05be:
																						ptr2 += 8;
																						goto end_IL_024c;
																						IL_0575:
																						array[num5] = 0;
																						goto IL_0583;
																						IL_0583:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05a6;
																						IL_05a6:
																						array2[num5] = null;
																						goto IL_05b0;
																						IL_05b0:
																						num5++;
																						goto IL_05be;
																					}
																					break;
																				}
																				goto IL_0277;
																				IL_0382:
																				array[num5 - 2] = 0;
																				goto IL_0396;
																				IL_0277:
																				if (7 < b)
																				{
																					goto IL_0282;
																				}
																				goto IL_02d3;
																				IL_0282:
																				if (8 < b)
																				{
																					goto IL_028d;
																				}
																				num = 103;
																				goto IL_03a9;
																				IL_028d:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_029b;
																				IL_029b:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_02a9;
																				IL_02a9:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_024c;
																				IL_0396:
																				num5--;
																				goto end_IL_024c;
																				IL_03a9:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_03b7;
																				IL_03b7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03f7;
																				IL_03f7:
																				array[num5 - 2] = 0;
																				goto IL_040b;
																				IL_040b:
																				num5--;
																				goto end_IL_024c;
																				IL_02d3:
																				if (7 <= b)
																				{
																					goto IL_02de;
																				}
																				goto IL_0326;
																				IL_02de:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_02f7;
																				IL_02f7:
																				array[num5] = 0;
																				goto IL_0305;
																				IL_0305:
																				num5++;
																				goto IL_0313;
																				IL_0313:
																				ptr2 += 8;
																				goto end_IL_024c;
																				IL_0326:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0334;
																				IL_0334:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0342;
																				IL_0342:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0382;
																			}
																			break;
																			IL_023c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05f1;
																	IL_060d:
																	ptr2 += 8;
																	break;
																	IL_05ff:
																	num5++;
																	goto IL_060d;
																	IL_05f1:
																	array[num5] = 0;
																	goto IL_05ff;
																	continue;
																	end_IL_024c:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06c8;
													IL_06c8:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_061b:
													break;
												}
												continue;
												end_IL_062e:
												break;
											}
											continue;
											end_IL_0638:
											break;
										}
										continue;
										end_IL_0643:
										break;
									}
									continue;
									end_IL_0658:
									break;
								}
								continue;
								end_IL_066d:
								break;
							}
							continue;
							end_IL_067d:
							break;
						}
						continue;
						end_IL_068d:
						break;
					}
					continue;
					end_IL_069d:
					break;
				}
				continue;
				end_IL_06ad:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 54;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BindToTypePERSIAN.CurrentThreadGetDeploymentComponentManifest);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02dc:
															byte b = *ptr2;
															while (true)
															{
																IL_02cc:
																ptr2++;
																while (true)
																{
																	IL_02bc:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_029c:
																				if (6 >= b)
																				{
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_027c:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_026c:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_025f:
																											if (1 >= b)
																											{
																												while (1 > b)
																												{
																													num = 135;
																													while (num != 135)
																													{
																														if (num != 1116)
																														{
																															goto IL_024c;
																														}
																														switch (num)
																														{
																														case 96:
																															goto IL_024c;
																														case 23:
																															goto IL_025f;
																														case 48:
																															goto IL_026c;
																														case 34:
																														case 47:
																															goto IL_027c;
																														case 12:
																															goto IL_028c;
																														case 71:
																															goto IL_029c;
																														case 80:
																															goto IL_02ac;
																														case 10:
																															goto IL_02bc;
																														case 106:
																															goto IL_02cc;
																														case 2:
																														case 103:
																															goto IL_02dc;
																														case 38:
																														case 65:
																															goto IL_02e7;
																														case 22:
																															goto IL_02f5;
																														case 33:
																														case 57:
																															goto IL_0303;
																														case 24:
																															goto IL_0371;
																														case 52:
																														case 114:
																															goto IL_0384;
																														case 85:
																															goto IL_03c4;
																														case 112:
																															goto IL_03e1;
																														case 83:
																															goto IL_03f4;
																														case 35:
																															goto IL_03ff;
																														case 3:
																														case 28:
																															goto IL_040d;
																														case 30:
																															goto IL_0436;
																														case 93:
																															goto IL_044d;
																														case 6:
																														case 109:
																															goto IL_0469;
																														case 18:
																															goto IL_0477;
																														case 9:
																														case 108:
																															goto IL_0485;
																														case 4:
																															goto IL_049d;
																														case 74:
																															goto IL_04ab;
																														case 11:
																														case 36:
																															goto IL_04b9;
																														case 20:
																															goto IL_04c4;
																														case 107:
																															goto IL_04d2;
																														case 55:
																														case 76:
																															goto IL_04e0;
																														case 25:
																															goto IL_04f9;
																														case 37:
																															goto IL_0507;
																														case 81:
																															goto IL_0515;
																														case 42:
																															goto IL_0528;
																														case 40:
																														case 94:
																															goto IL_0533;
																														case 63:
																															goto IL_0541;
																														case 88:
																															goto IL_0564;
																														case 27:
																															goto IL_056e;
																														case 8:
																															goto IL_0585;
																														case 97:
																														case 116:
																															goto IL_05af;
																														case 51:
																															goto IL_05ef;
																														case 69:
																															goto IL_0603;
																														case 64:
																														case 89:
																															goto IL_0616;
																														case 44:
																															goto IL_0624;
																														case 59:
																														case 117:
																															goto IL_062f;
																														case 43:
																															goto IL_0642;
																														case 100:
																															goto IL_0650;
																														case 29:
																														case 56:
																															goto IL_065e;
																														case 68:
																															goto IL_0672;
																														case 119:
																															goto IL_06c6;
																														case 70:
																															goto IL_06d4;
																														case 128:
																															goto IL_06e4;
																														case 61:
																															goto IL_06ef;
																														case 98:
																														case 110:
																															goto IL_06fa;
																														case 5:
																														case 7:
																														case 13:
																														case 15:
																														case 17:
																														case 26:
																														case 31:
																														case 41:
																														case 45:
																														case 46:
																														case 72:
																														case 73:
																														case 78:
																														case 86:
																														case 87:
																														case 91:
																														case 92:
																														case 95:
																														case 102:
																														case 105:
																														case 111:
																														case 118:
																														case 120:
																														case 122:
																														case 125:
																														case 126:
																															goto end_IL_0239;
																														case 0:
																															goto IL_0736;
																														case 60:
																															goto IL_0744;
																														case 77:
																															goto IL_0752;
																														case 1:
																														case 14:
																														case 16:
																														case 19:
																														case 21:
																														case 39:
																														case 62:
																														case 79:
																														case 84:
																														case 101:
																														case 104:
																														case 115:
																														case 121:
																														case 124:
																														case 127:
																															goto end_IL_028c;
																														case 58:
																															goto end_IL_0760;
																														case 82:
																															goto end_IL_0773;
																														case 99:
																															goto end_IL_077d;
																														case 90:
																															goto end_IL_0788;
																														case 67:
																															goto end_IL_079d;
																														case 32:
																														case 49:
																															goto end_IL_07b2;
																														case 50:
																															goto end_IL_07c2;
																														case 66:
																														case 123:
																															goto end_IL_07d2;
																														case 53:
																															goto end_IL_07e2;
																														case 54:
																															goto end_IL_07f2;
																														case 75:
																														case 113:
																															goto IL_080d;
																														}
																														continue;
																														end_IL_0239:
																														break;
																													}
																													break;
																													IL_024c:;
																												}
																												break;
																											}
																											goto IL_02e7;
																											IL_0371:
																											num5 -= 2;
																											goto end_IL_028c;
																											IL_02e7:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_02f5;
																											IL_02f5:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0303;
																											IL_0303:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0371;
																										}
																										break;
																									}
																									goto IL_0384;
																									IL_03e1:
																									num5--;
																									goto end_IL_028c;
																									IL_0384:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03c4;
																									IL_03c4:
																									array[num5 - 2] = 0;
																									num = 112;
																									goto IL_03e1;
																								}
																								break;
																							}
																							goto IL_03f4;
																							IL_0477:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0485;
																							IL_03f4:
																							if (4 >= b)
																							{
																								goto IL_03ff;
																							}
																							num = 109;
																							goto IL_0469;
																							IL_03ff:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_040d;
																							IL_040d:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0436;
																							IL_0436:
																							ptr2 += 8;
																							num = 93;
																							goto IL_044d;
																							IL_044d:
																							num5--;
																							goto end_IL_028c;
																							IL_0485:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_028c;
																							IL_0469:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0477;
																						}
																						goto end_IL_02ac;
																						continue;
																						end_IL_028c:
																						break;
																						IL_028c:;
																					}
																					break;
																				}
																				goto IL_049d;
																				IL_06ef:
																				if (12 > b)
																				{
																					goto end_IL_02ac;
																				}
																				goto IL_06fa;
																				IL_049d:
																				if (9 >= b)
																				{
																					goto IL_04ab;
																				}
																				goto IL_0616;
																				IL_04ab:
																				if (9 > b)
																				{
																					goto IL_04b9;
																				}
																				goto IL_05af;
																				IL_04b9:
																				if (7 < b)
																				{
																					goto IL_04c4;
																				}
																				goto IL_0528;
																				IL_04c4:
																				if (8 < b)
																				{
																					goto end_IL_02ac;
																				}
																				goto IL_04d2;
																				IL_04d2:
																				if (8 > b)
																				{
																					goto end_IL_02ac;
																				}
																				goto IL_04e0;
																				IL_04e0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04f9;
																				IL_04f9:
																				array[num5] = 0;
																				goto IL_0507;
																				IL_0507:
																				num5++;
																				goto IL_0515;
																				IL_0515:
																				ptr2 += 8;
																				break;
																				IL_0528:
																				if (7 > b)
																				{
																					num = 7;
																					goto end_IL_02ac;
																				}
																				goto IL_0533;
																				IL_0533:
																				array[num5] = 0;
																				goto IL_0541;
																				IL_0541:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0564;
																				IL_0564:
																				array2[num5] = null;
																				goto IL_056e;
																				IL_056e:
																				num5++;
																				num = 8;
																				goto IL_0585;
																				IL_0585:
																				ptr2 += 8;
																				num = 121;
																				break;
																				IL_06fa:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_05af:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05ef;
																				IL_05ef:
																				array[num5 - 2] = 0;
																				goto IL_0603;
																				IL_0603:
																				num5--;
																				break;
																				IL_0616:
																				if (11 >= b)
																				{
																					goto IL_0624;
																				}
																				goto IL_06e4;
																				IL_0624:
																				if (11 <= b)
																				{
																					goto IL_062f;
																				}
																				goto IL_0642;
																				IL_062f:
																				num5--;
																				break;
																				IL_0642:
																				if (10 < b)
																				{
																					goto end_IL_02ac;
																				}
																				goto IL_0650;
																				IL_0650:
																				if (10 > b)
																				{
																					goto end_IL_02ac;
																				}
																				goto IL_065e;
																				IL_065e:
																				array[num5 - 2] = 0;
																				goto IL_0672;
																				IL_0672:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)StreetAddressCreateActContextParametersSourceDefinitionAppid[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_06c6;
																				IL_06c6:
																				num5--;
																				goto IL_06d4;
																				IL_06d4:
																				ptr2 += 8;
																				break;
																				IL_06e4:
																				if (12 < b)
																				{
																					goto end_IL_02ac;
																				}
																				goto IL_06ef;
																			}
																			goto end_IL_02bc;
																			continue;
																			end_IL_02ac:
																			break;
																			IL_02ac:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0736;
																	IL_0752:
																	ptr2 += 8;
																	break;
																	IL_0744:
																	num5++;
																	goto IL_0752;
																	IL_0736:
																	array[num5] = 0;
																	goto IL_0744;
																	continue;
																	end_IL_02bc:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_080d;
													IL_080d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0760:
													break;
												}
												continue;
												end_IL_0773:
												break;
											}
											continue;
											end_IL_077d:
											break;
										}
										continue;
										end_IL_0788:
										break;
									}
									continue;
									end_IL_079d:
									break;
								}
								continue;
								end_IL_07b2:
								break;
							}
							continue;
							end_IL_07c2:
							break;
						}
						continue;
						end_IL_07d2:
						break;
					}
					continue;
					end_IL_07e2:
					break;
				}
				continue;
				end_IL_07f2:
				break;
			}
		}
	}

	private static float getIsStoppedResourceTypeIdString(Vector3 vector3_0)
	{
		return vector3_0.z;
	}

	private static Quaternion HashElementTransformMetadataSizeCharArray(Vector3 vector3_0)
	{
		return Quaternion.LookRotation(vector3_0);
	}

	private static Vector3 MessageSurrogateFiltergetDefaultContext()
	{
		return global::_003CModule_003E.vector3_116;
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setKeyAllCultures.GetFilterAsTupledObjectUrl);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 133;
																while (true)
																{
																	if (num != 133)
																	{
																		if (num != 1114)
																		{
																			goto IL_03c0;
																		}
																		switch (num)
																		{
																		case 59:
																			goto end_IL_0223;
																		case 64:
																		case 69:
																			goto end_IL_0233;
																		case 105:
																			goto IL_0265;
																		case 115:
																			goto IL_0273;
																		case 53:
																		case 77:
																			goto IL_0281;
																		case 28:
																		case 43:
																			goto IL_028f;
																		case 94:
																			goto IL_029d;
																		case 13:
																			goto IL_02ab;
																		case 106:
																			goto IL_02b9;
																		case 4:
																		case 42:
																			goto IL_02c7;
																		case 90:
																			goto IL_02db;
																		case 74:
																			goto IL_0323;
																		case 23:
																		case 98:
																			goto IL_033f;
																		case 36:
																			goto IL_0352;
																		case 107:
																			goto IL_036b;
																		case 37:
																		case 73:
																			goto IL_0379;
																		case 52:
																			goto IL_0395;
																		case 0:
																		case 114:
																			goto IL_03ac;
																		case 6:
																		case 118:
																			goto IL_03c0;
																		case 125:
																			goto IL_03ce;
																		case 10:
																		case 86:
																			goto IL_03dc;
																		case 44:
																			goto IL_03f5;
																		case 20:
																			goto IL_0403;
																		case 47:
																			goto IL_0411;
																		case 103:
																			goto IL_0424;
																		case 39:
																		case 96:
																			goto IL_0432;
																		case 109:
																			goto IL_0440;
																		case 79:
																			goto IL_0463;
																		case 110:
																			goto IL_046d;
																		case 82:
																			goto IL_047b;
																		case 14:
																		case 117:
																			goto IL_0497;
																		case 76:
																			goto IL_04d7;
																		case 126:
																			goto IL_04eb;
																		case 93:
																			goto IL_04fe;
																		case 120:
																			goto IL_050c;
																		case 22:
																			goto IL_051a;
																		case 2:
																		case 18:
																			goto IL_0525;
																		case 123:
																			goto IL_0533;
																		case 58:
																		case 92:
																			goto IL_0541;
																		case 26:
																			goto IL_0559;
																		case 11:
																		case 49:
																			goto IL_0567;
																		case 3:
																			goto IL_0590;
																		case 95:
																			goto IL_059e;
																		case 60:
																			goto IL_05ba;
																		case 27:
																		case 85:
																			goto IL_05c8;
																		case 1:
																		case 9:
																			goto IL_05d6;
																		case 21:
																			goto IL_05e4;
																		case 67:
																		case 119:
																			goto IL_05f2;
																		case 40:
																			goto IL_0660;
																		case 54:
																			goto IL_0673;
																		case 57:
																		case 111:
																			goto IL_0680;
																		case 5:
																			goto IL_06c0;
																		case 116:
																			goto IL_06d4;
																		case 19:
																		case 33:
																		case 38:
																		case 41:
																		case 45:
																		case 48:
																		case 61:
																		case 66:
																		case 68:
																		case 70:
																		case 78:
																		case 81:
																		case 84:
																		case 88:
																		case 89:
																		case 91:
																		case 97:
																		case 99:
																		case 100:
																		case 101:
																		case 108:
																		case 112:
																		case 113:
																		case 121:
																			goto IL_06e4;
																		case 16:
																			goto IL_0707;
																		case 24:
																			goto IL_0715;
																		case 8:
																			goto IL_0723;
																		case 12:
																		case 17:
																		case 25:
																		case 30:
																		case 31:
																		case 35:
																		case 46:
																		case 50:
																		case 51:
																		case 75:
																		case 80:
																		case 102:
																		case 104:
																		case 122:
																		case 124:
																			goto end_IL_024c;
																		case 56:
																			goto end_IL_0731;
																		case 83:
																			goto end_IL_0744;
																		case 32:
																			goto end_IL_074e;
																		case 15:
																			goto end_IL_0759;
																		case 63:
																			goto end_IL_076e;
																		case 29:
																		case 65:
																			goto end_IL_0783;
																		case 55:
																			goto end_IL_0793;
																		case 7:
																		case 87:
																			goto end_IL_07a3;
																		case 71:
																			goto end_IL_07b3;
																		case 72:
																			goto end_IL_07c3;
																		case 34:
																		case 62:
																			goto IL_07de;
																		}
																		continue;
																	}
																	if (b >= 1)
																	{
																		goto IL_0265;
																	}
																	goto IL_06e4;
																	IL_0680:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_06c0;
																	IL_06d4:
																	num5--;
																	goto end_IL_024c;
																	IL_06c0:
																	array[num5 - 2] = 0;
																	goto IL_06d4;
																	IL_0265:
																	if (b <= 12)
																	{
																		goto IL_0273;
																	}
																	goto IL_06e4;
																	IL_0273:
																	if (6 < b)
																	{
																		goto IL_0281;
																	}
																	goto IL_04fe;
																	IL_0281:
																	if (9 < b)
																	{
																		goto IL_028f;
																	}
																	goto IL_0395;
																	IL_028f:
																	if (11 >= b)
																	{
																		goto IL_029d;
																	}
																	goto IL_0352;
																	IL_029d:
																	if (11 > b)
																	{
																		goto IL_02ab;
																	}
																	goto IL_033f;
																	IL_02ab:
																	if (10 >= b)
																	{
																		goto IL_02b9;
																	}
																	goto IL_06e4;
																	IL_02b9:
																	if (10 <= b)
																	{
																		goto IL_02c7;
																	}
																	goto IL_06e4;
																	IL_02c7:
																	array[num5 - 1] = 0;
																	goto IL_02db;
																	IL_02db:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SyncStreamGetTypeComp[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																	num = 74;
																	goto IL_0323;
																	IL_0323:
																	ptr2 += 8;
																	num = 25;
																	goto end_IL_024c;
																	IL_033f:
																	num5--;
																	goto end_IL_024c;
																	IL_0352:
																	if (12 >= b)
																	{
																		goto IL_036b;
																	}
																	num = 89;
																	goto IL_06e4;
																	IL_06e4:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0707;
																	IL_036b:
																	if (12 <= b)
																	{
																		goto IL_0379;
																	}
																	goto IL_06e4;
																	IL_0379:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_024c;
																	IL_0395:
																	if (9 > b)
																	{
																		num = 114;
																		goto IL_03ac;
																	}
																	goto IL_0497;
																	IL_0707:
																	array[num5] = 0;
																	goto IL_0715;
																	IL_03ac:
																	if (7 < b)
																	{
																		num = 6;
																		goto IL_03c0;
																	}
																	goto IL_0424;
																	IL_0715:
																	num5++;
																	goto IL_0723;
																	IL_03c0:
																	if (8 >= b)
																	{
																		goto IL_03ce;
																	}
																	goto IL_06e4;
																	IL_03ce:
																	if (8 <= b)
																	{
																		goto IL_03dc;
																	}
																	goto IL_06e4;
																	IL_03dc:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_03f5;
																	IL_03f5:
																	array[num5] = 0;
																	goto IL_0403;
																	IL_0403:
																	num5++;
																	goto IL_0411;
																	IL_0411:
																	ptr2 += 8;
																	goto end_IL_024c;
																	IL_0424:
																	if (7 <= b)
																	{
																		goto IL_0432;
																	}
																	goto IL_06e4;
																	IL_0432:
																	array[num5] = 0;
																	goto IL_0440;
																	IL_0440:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0463;
																	IL_0463:
																	array2[num5] = null;
																	goto IL_046d;
																	IL_046d:
																	num5++;
																	goto IL_047b;
																	IL_047b:
																	ptr2 += 8;
																	num = 12;
																	goto end_IL_024c;
																	IL_0497:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04d7;
																	IL_04d7:
																	array[num5 - 2] = 0;
																	goto IL_04eb;
																	IL_04eb:
																	num5--;
																	goto end_IL_024c;
																	IL_04fe:
																	if (6 <= b)
																	{
																		goto end_IL_024c;
																	}
																	goto IL_050c;
																	IL_050c:
																	if (3 < b)
																	{
																		goto IL_051a;
																	}
																	num = 60;
																	goto IL_05ba;
																	IL_051a:
																	if (4 < b)
																	{
																		goto IL_0525;
																	}
																	goto IL_0559;
																	IL_0525:
																	if (5 >= b)
																	{
																		goto IL_0533;
																	}
																	goto IL_06e4;
																	IL_0533:
																	if (5 <= b)
																	{
																		goto IL_0541;
																	}
																	goto IL_06e4;
																	IL_0541:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_024c;
																	IL_0559:
																	if (4 <= b)
																	{
																		goto IL_0567;
																	}
																	goto IL_06e4;
																	IL_0567:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0590;
																	IL_0590:
																	ptr2 += 8;
																	goto IL_059e;
																	IL_059e:
																	num5--;
																	goto end_IL_024c;
																	IL_0723:
																	ptr2 += 8;
																	goto end_IL_024c;
																	IL_05ba:
																	if (3 > b)
																	{
																		goto IL_05c8;
																	}
																	goto IL_0680;
																	IL_05c8:
																	if (1 < b)
																	{
																		goto IL_05d6;
																	}
																	goto IL_0673;
																	IL_05d6:
																	if (2 >= b)
																	{
																		goto IL_05e4;
																	}
																	goto IL_06e4;
																	IL_05e4:
																	if (2 <= b)
																	{
																		goto IL_05f2;
																	}
																	goto IL_06e4;
																	IL_05f2:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0660;
																	IL_0660:
																	num5 -= 2;
																	goto end_IL_024c;
																	IL_0673:
																	if (1 > b)
																	{
																	}
																	goto IL_06e4;
																	continue;
																	end_IL_0223:
																	break;
																}
																continue;
																end_IL_0233:
																break;
															}
															continue;
															end_IL_024c:
															break;
														}
														continue;
													}
													goto IL_07de;
													IL_07de:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0731:
													break;
												}
												continue;
												end_IL_0744:
												break;
											}
											continue;
											end_IL_074e:
											break;
										}
										continue;
										end_IL_0759:
										break;
									}
									continue;
									end_IL_076e:
									break;
								}
								continue;
								end_IL_0783:
								break;
							}
							continue;
							end_IL_0793:
							break;
						}
						continue;
						end_IL_07a3:
						break;
					}
					continue;
					end_IL_07b3:
					break;
				}
				continue;
				end_IL_07c3:
				break;
			}
		}
	}

	private static Vector3 FormKCDisallowUnassignedMakeVersionSafeName()
	{
		return global::_003CModule_003E.vector3_121;
	}

	private static Vector3 GetServerContextSinkIMapView()
	{
		return global::_003CModule_003E.vector3_120;
	}

	private unsafe static int smethod_8(int int_1, int int_2)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsLcidSafeHandleZeroOrMinusOneIsInvalid.PropagateOutParametersRemoveAllEventHandlers);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_028f:
															byte b = *ptr2;
															while (true)
															{
																IL_027f:
																ptr2++;
																while (true)
																{
																	IL_026f:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			num = 71;
																			while (true)
																			{
																				IL_024c:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_023f:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_022f:
																								if (7 >= b)
																								{
																									while (7 <= b)
																									{
																										while (true)
																										{
																											IL_020f:
																											array[num5] = 0;
																											while (true)
																											{
																												IL_01e1:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												num = 57;
																												while (true)
																												{
																													IL_01d5:
																													array2[num5] = null;
																													while (true)
																													{
																														IL_01c5:
																														num5++;
																														while (true)
																														{
																															IL_01ac:
																															ptr2 += 8;
																															num = 95;
																															while (num != 95)
																															{
																																if (num != 1076)
																																{
																																	goto end_IL_021f;
																																}
																																switch (num)
																																{
																																case 42:
																																	goto IL_01ac;
																																case 2:
																																	goto IL_01c5;
																																case 57:
																																	goto IL_01d5;
																																case 11:
																																	goto IL_01e1;
																																case 56:
																																case 70:
																																	goto IL_020f;
																																case 22:
																																	goto IL_021f;
																																case 0:
																																	goto IL_022f;
																																case 8:
																																case 75:
																																	goto IL_023f;
																																case 71:
																																	goto IL_024c;
																																case 31:
																																	goto IL_025c;
																																case 69:
																																	goto IL_026f;
																																case 86:
																																	goto IL_027f;
																																case 43:
																																case 49:
																																	goto IL_028f;
																																case 54:
																																	goto IL_029a;
																																case 37:
																																	goto IL_02a8;
																																case 12:
																																	goto IL_02b6;
																																case 19:
																																case 29:
																																	goto IL_02c4;
																																case 16:
																																	goto IL_02dc;
																																case 3:
																																	goto IL_02ea;
																																case 32:
																																case 48:
																																	goto IL_02f8;
																																case 73:
																																	goto IL_0314;
																																case 34:
																																case 55:
																																	goto IL_031f;
																																case 21:
																																	goto IL_0348;
																																case 58:
																																	goto IL_0356;
																																case 14:
																																case 20:
																																	goto IL_0372;
																																case 53:
																																	goto IL_0380;
																																case 68:
																																case 87:
																																	goto IL_038e;
																																case 33:
																																	goto IL_03fc;
																																case 88:
																																	goto IL_040f;
																																case 77:
																																	goto IL_041d;
																																case 9:
																																	goto IL_042a;
																																case 38:
																																	goto IL_0435;
																																case 23:
																																case 63:
																																	goto IL_0440;
																																case 27:
																																	goto IL_0480;
																																case 44:
																																	goto IL_0494;
																																case 5:
																																case 7:
																																case 13:
																																case 25:
																																case 30:
																																case 39:
																																case 41:
																																case 45:
																																case 46:
																																case 50:
																																case 51:
																																case 59:
																																case 65:
																																case 74:
																																case 76:
																																case 78:
																																case 80:
																																case 83:
																																	goto end_IL_021f;
																																case 66:
																																	goto IL_04c7;
																																case 82:
																																	goto IL_04d5;
																																case 4:
																																	goto IL_04e3;
																																case 10:
																																case 15:
																																case 18:
																																case 24:
																																case 40:
																																case 52:
																																case 64:
																																case 72:
																																case 84:
																																case 85:
																																	goto end_IL_0199;
																																case 28:
																																	goto end_IL_04f1;
																																case 60:
																																	goto end_IL_0504;
																																case 35:
																																	goto end_IL_050e;
																																case 17:
																																	goto end_IL_0519;
																																case 6:
																																	goto end_IL_052e;
																																case 67:
																																case 79:
																																	goto end_IL_0543;
																																case 36:
																																	goto end_IL_0553;
																																case 1:
																																case 81:
																																	goto end_IL_0563;
																																case 61:
																																	goto end_IL_0573;
																																case 62:
																																	goto end_IL_0583;
																																case 26:
																																case 47:
																																	goto IL_059e;
																																}
																																continue;
																																end_IL_0199:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto end_IL_026f;
																										continue;
																										end_IL_021f:
																										break;
																										IL_021f:;
																									}
																									break;
																								}
																								goto IL_02dc;
																								IL_02f8:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_026f;
																								IL_02dc:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_02ea;
																								IL_02ea:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_02f8;
																							}
																							break;
																						}
																						goto IL_029a;
																						IL_02c4:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_026f;
																						IL_029a:
																						if (6 <= b)
																						{
																							goto end_IL_026f;
																						}
																						goto IL_02a8;
																						IL_02a8:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_02b6;
																						IL_02b6:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_02c4;
																					}
																					break;
																				}
																				goto IL_0314;
																				IL_0480:
																				array[num5 - 2] = 0;
																				goto IL_0494;
																				IL_0314:
																				if (4 <= b)
																				{
																					goto IL_031f;
																				}
																				num = 20;
																				goto IL_0372;
																				IL_031f:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0348;
																				IL_0348:
																				ptr2 += 8;
																				goto IL_0356;
																				IL_0356:
																				num5--;
																				goto end_IL_026f;
																				IL_0494:
																				num5--;
																				goto end_IL_026f;
																				IL_0372:
																				if (2 >= b)
																				{
																					goto IL_0380;
																				}
																				goto IL_042a;
																				IL_0380:
																				if (2 <= b)
																				{
																					goto IL_038e;
																				}
																				goto IL_040f;
																				IL_038e:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03fc;
																				IL_03fc:
																				num5 -= 2;
																				goto end_IL_026f;
																				IL_040f:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_041d;
																				IL_041d:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_042a:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0435;
																				IL_0435:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0440;
																				IL_0440:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0480;
																			}
																			break;
																			IL_025c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c7;
																	IL_04e3:
																	ptr2 += 8;
																	break;
																	IL_04d5:
																	num5++;
																	goto IL_04e3;
																	IL_04c7:
																	array[num5] = 0;
																	goto IL_04d5;
																	continue;
																	end_IL_026f:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_059e;
													IL_059e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f1:
													break;
												}
												continue;
												end_IL_0504:
												break;
											}
											continue;
											end_IL_050e:
											break;
										}
										continue;
										end_IL_0519:
										break;
									}
									continue;
									end_IL_052e:
									break;
								}
								continue;
								end_IL_0543:
								break;
							}
							continue;
							end_IL_0553:
							break;
						}
						continue;
						end_IL_0563:
						break;
					}
					continue;
					end_IL_0573:
					break;
				}
				continue;
				end_IL_0583:
				break;
			}
		}
	}

	private static float UseSoapFormatFromDays(float float_2)
	{
		return Mathf.Sin(float_2);
	}

	private static Vector3 getSupportsDynamicPartitionsPartialTrustVisibilityLevel(Transform transform_0)
	{
		return transform_0.position;
	}

	private static ControllerInputPoller StringToHGlobalAutoUCOMIRunningObjectTable()
	{
		return ControllerInputPoller.instance;
	}

	private unsafe static int smethod_9(int int_1)
	{
		int num = 3;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 34;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DenyChildAttachPreferredBit.SafeBSTRHandleSetConfigurationBytes);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 65;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02cd:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			if (7 < b)
																			{
																				num = 13;
																				while (true)
																				{
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_028a:
																							if (11 <= b)
																							{
																								goto IL_072f;
																							}
																							num = 147;
																							while (true)
																							{
																								if (num != 147)
																								{
																									if (num != 1128)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 61:
																										goto IL_028a;
																									case 4:
																									case 13:
																										goto end_IL_028a;
																									case 138:
																										goto end_IL_029d;
																									case 84:
																										goto end_IL_02ad;
																									case 70:
																										goto IL_02cd;
																									case 65:
																										goto end_IL_02cd;
																									case 96:
																									case 104:
																										goto end_IL_02dd;
																									case 23:
																										goto IL_0301;
																									case 19:
																									case 53:
																										goto IL_030c;
																									case 67:
																										goto IL_031a;
																									case 29:
																									case 47:
																										goto IL_0325;
																									case 64:
																									case 73:
																										goto IL_033d;
																									case 0:
																										goto IL_0348;
																									case 51:
																										goto IL_035b;
																									case 52:
																										goto IL_0369;
																									case 72:
																									case 91:
																										goto IL_037c;
																									case 57:
																										goto IL_03bc;
																									case 54:
																										goto IL_03d0;
																									case 9:
																									case 107:
																										goto IL_03e3;
																									case 55:
																										goto IL_03fc;
																									case 59:
																										goto IL_040a;
																									case 45:
																									case 127:
																										goto IL_041a;
																									case 132:
																										goto IL_0443;
																									case 15:
																										goto IL_0451;
																									case 135:
																										goto IL_0464;
																									case 137:
																										goto IL_0477;
																									case 46:
																									case 81:
																										goto IL_0485;
																									case 106:
																										goto IL_0493;
																									case 31:
																									case 50:
																										goto IL_04a1;
																									case 88:
																										goto IL_04e1;
																									case 119:
																										goto IL_04f5;
																									case 134:
																										goto IL_0508;
																									case 103:
																									case 124:
																										goto IL_0513;
																									case 120:
																										goto IL_0521;
																									case 16:
																									case 122:
																										goto IL_0534;
																									case 24:
																										goto IL_0542;
																									case 140:
																										goto IL_0565;
																									case 93:
																										goto IL_056f;
																									case 66:
																										goto IL_057d;
																									case 36:
																										goto IL_0590;
																									case 33:
																									case 79:
																										goto IL_059e;
																									case 37:
																										goto IL_05ac;
																									case 42:
																									case 113:
																										goto IL_05c3;
																									case 22:
																										goto IL_0603;
																									case 86:
																										goto IL_0617;
																									case 7:
																										goto IL_062a;
																									case 118:
																									case 131:
																										goto IL_0638;
																									case 102:
																										goto IL_0643;
																									case 20:
																									case 48:
																										goto IL_0651;
																									case 92:
																										goto IL_0674;
																									case 100:
																										goto IL_068b;
																									case 68:
																										goto IL_0699;
																									case 71:
																									case 114:
																										goto IL_06ba;
																									case 76:
																										goto IL_071c;
																									case 10:
																									case 125:
																										goto IL_072f;
																									case 63:
																										goto IL_0743;
																									case 117:
																										goto end_IL_0277;
																									case 26:
																										goto IL_0795;
																									case 18:
																										goto IL_07a0;
																									case 8:
																										goto IL_07ab;
																									case 123:
																										goto IL_07b8;
																									case 27:
																									case 40:
																										goto IL_07c3;
																									case 130:
																										goto IL_07ce;
																									case 78:
																									case 98:
																										goto IL_07d9;
																									case 25:
																									case 133:
																										goto IL_07e9;
																									case 12:
																									case 14:
																									case 17:
																									case 30:
																									case 35:
																									case 39:
																									case 49:
																									case 62:
																									case 69:
																									case 77:
																									case 80:
																									case 82:
																									case 90:
																									case 94:
																									case 95:
																									case 97:
																									case 99:
																									case 101:
																									case 105:
																									case 109:
																									case 112:
																									case 116:
																									case 121:
																									case 126:
																									case 129:
																										goto end_IL_02bd;
																									case 1:
																									case 6:
																									case 21:
																									case 28:
																									case 32:
																									case 38:
																									case 41:
																									case 58:
																									case 75:
																									case 85:
																									case 87:
																									case 89:
																									case 108:
																									case 110:
																									case 115:
																									case 128:
																									case 136:
																										goto end_IL_02ed;
																									case 5:
																										goto end_IL_0815;
																									case 139:
																										goto end_IL_0828;
																									case 34:
																										goto end_IL_0832;
																									case 56:
																										goto end_IL_083d;
																									case 44:
																									case 74:
																										goto end_IL_0852;
																									case 83:
																										goto end_IL_086b;
																									case 43:
																									case 111:
																										goto end_IL_087b;
																									case 2:
																										goto end_IL_088b;
																									case 3:
																										goto end_IL_089b;
																									case 11:
																									case 60:
																										goto IL_08bf;
																									}
																									continue;
																								}
																								goto IL_0590;
																								IL_0699:
																								ptr2 += 8;
																								goto end_IL_02ed;
																								IL_071c:
																								num5 -= 2;
																								goto end_IL_02ed;
																								IL_0590:
																								if (9 < b)
																								{
																									goto IL_059e;
																								}
																								goto IL_062a;
																								IL_059e:
																								if (10 < b)
																								{
																									goto end_IL_02bd;
																								}
																								goto IL_05ac;
																								IL_05ac:
																								if (10 > b)
																								{
																									goto end_IL_02bd;
																								}
																								num = 113;
																								goto IL_05c3;
																								IL_06ba:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_071c;
																								IL_05c3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0603;
																								IL_0603:
																								array[num5 - 2] = 0;
																								goto IL_0617;
																								IL_0617:
																								num5--;
																								goto end_IL_02ed;
																								IL_062a:
																								if (9 > b)
																								{
																									goto IL_0638;
																								}
																								goto IL_06ba;
																								IL_0638:
																								if (8 < b)
																								{
																									num = 101;
																									goto end_IL_02bd;
																								}
																								goto IL_0643;
																								IL_0643:
																								if (8 > b)
																								{
																									goto end_IL_02bd;
																								}
																								goto IL_0651;
																								IL_0651:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0674;
																								IL_0674:
																								array[num5] = 0;
																								num = 100;
																								goto IL_068b;
																								IL_068b:
																								num5++;
																								goto IL_0699;
																								continue;
																								end_IL_0277:
																								break;
																							}
																							goto IL_0782;
																							IL_0743:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getKeyboardLayoutIdTupleElementNamesAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_0782;
																							IL_0782:
																							ptr2 += 8;
																							goto end_IL_02ed;
																							IL_072f:
																							array[num5 - 1] = 0;
																							goto IL_0743;
																							continue;
																							end_IL_028a:
																							break;
																						}
																						continue;
																					}
																					goto IL_0795;
																					IL_07e9:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02ed;
																					IL_0795:
																					if (13 < b)
																					{
																						goto IL_07a0;
																					}
																					goto IL_07b8;
																					IL_07a0:
																					if (14 < b)
																					{
																						goto end_IL_02bd;
																					}
																					goto IL_07ab;
																					IL_07ab:
																					if (14 > b)
																					{
																					}
																					goto end_IL_02bd;
																					IL_07b8:
																					if (13 > b)
																					{
																						goto IL_07c3;
																					}
																					goto IL_07e9;
																					IL_07c3:
																					if (12 < b)
																					{
																						goto end_IL_02bd;
																					}
																					goto IL_07ce;
																					IL_07ce:
																					if (12 > b)
																					{
																						goto end_IL_02bd;
																					}
																					goto IL_07d9;
																					IL_07d9:
																					num5--;
																					goto end_IL_02ed;
																					continue;
																					end_IL_029d:
																					break;
																				}
																				continue;
																			}
																			goto IL_0301;
																			IL_03bc:
																			array[num5 - 2] = 0;
																			goto IL_03d0;
																			IL_03d0:
																			num5--;
																			goto end_IL_02ed;
																			IL_0301:
																			if (7 > b)
																			{
																				goto IL_030c;
																			}
																			goto IL_037c;
																			IL_030c:
																			if (3 >= b)
																			{
																				goto IL_031a;
																			}
																			goto IL_0477;
																			IL_031a:
																			if (3 <= b)
																			{
																				goto IL_0325;
																			}
																			goto IL_033d;
																			IL_0325:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02ed;
																			IL_033d:
																			if (1 >= b)
																			{
																				goto IL_0348;
																			}
																			goto IL_035b;
																			IL_0348:
																			if (1 > b)
																			{
																				goto end_IL_02bd;
																			}
																			goto IL_03e3;
																			IL_03e3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_03fc;
																			IL_03fc:
																			array[num5] = 0;
																			goto IL_040a;
																			IL_040a:
																			num5++;
																			goto IL_0464;
																			IL_0464:
																			ptr2 += 8;
																			goto end_IL_02ed;
																			IL_035b:
																			if (2 < b)
																			{
																				goto end_IL_02bd;
																			}
																			goto IL_0369;
																			IL_0369:
																			if (2 > b)
																			{
																				goto end_IL_02bd;
																			}
																			goto IL_041a;
																			IL_041a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0443;
																			IL_0443:
																			ptr2 += 8;
																			goto IL_0451;
																			IL_0451:
																			num5--;
																			goto end_IL_02ed;
																			IL_0477:
																			if (5 < b)
																			{
																				goto IL_0485;
																			}
																			goto IL_0508;
																			IL_0485:
																			if (6 < b)
																			{
																				goto end_IL_02bd;
																			}
																			goto IL_0493;
																			IL_0493:
																			if (6 > b)
																			{
																				goto end_IL_02bd;
																			}
																			goto IL_04a1;
																			IL_04a1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e1;
																			IL_04e1:
																			array[num5 - 2] = 0;
																			goto IL_04f5;
																			IL_04f5:
																			num5--;
																			goto end_IL_02ed;
																			IL_0508:
																			if (5 > b)
																			{
																				goto IL_0513;
																			}
																			goto IL_0534;
																			IL_0513:
																			if (4 < b)
																			{
																				goto end_IL_02bd;
																			}
																			goto IL_0521;
																			IL_0521:
																			if (4 <= b)
																			{
																				goto end_IL_02ed;
																			}
																			goto end_IL_02bd;
																			IL_0534:
																			array[num5] = 0;
																			goto IL_0542;
																			IL_0542:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0565;
																			IL_0565:
																			array2[num5] = null;
																			goto IL_056f;
																			IL_056f:
																			num5++;
																			goto IL_057d;
																			IL_057d:
																			ptr2 += 8;
																			goto end_IL_02ed;
																			IL_037c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03bc;
																			continue;
																			end_IL_02ad:
																			break;
																		}
																		continue;
																		end_IL_02bd:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02ed;
																continue;
																end_IL_02cd:
																break;
															}
															continue;
															end_IL_02dd:
															break;
														}
														continue;
														end_IL_02ed:
														break;
													}
													continue;
												}
												num = 60;
												goto IL_08bf;
												IL_08bf:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0815:
												break;
											}
											continue;
											end_IL_0828:
											break;
										}
										continue;
										end_IL_0832:
										break;
									}
									continue;
									end_IL_083d:
									break;
								}
								continue;
								end_IL_0852:
								break;
							}
							continue;
							end_IL_086b:
							break;
						}
						continue;
						end_IL_087b:
						break;
					}
					continue;
					end_IL_088b:
					break;
				}
				continue;
				end_IL_089b:
				break;
			}
		}
	}

	private static object IActivationFactoryItems(float float_2, float float_3, float float_4)
	{
		return new Vector3(float_2, float_3, float_4);
	}

	private static void ExpandPrimeISectionWithStringKey(Transform transform_0, Quaternion quaternion_0)
	{
		transform_0.rotation = quaternion_0;
	}

	private static double GetSecurityDescriptorSddlFormXUtils(double double_2)
	{
		return Math.Abs(double_2);
	}

	private static Vector3 PropGetgetIsLcid(ref RaycastHit raycastHit_0)
	{
		return raycastHit_0.normal;
	}

	private static string VerifyContextSetSwitch(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private static LayerMask getIsInterfacePrelinkAll()
	{
		return global::_003CModule_003E.layerMask_0;
	}

	private static double ExceptionDispatchInfoANSIX(double double_2)
	{
		return Math.Sqrt(double_2);
	}

	private static Transform CCCDECLLSATRUSTINFORMATION(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.leftHandTransform;
	}

	private static float GetRootObjectRectangularOffset(float float_2)
	{
		return Mathf.Cos(float_2);
	}

	private static Vector3 ISectionWithReferenceIdentityKeyFileLoadException()
	{
		return global::_003CModule_003E.vector3_124;
	}

	private static double getIsRightToLeftPrelinkAll(double double_2)
	{
		return Math.Cos(double_2);
	}

	private static float OpenNamespaceGetInteropTypeFromXmlElement(Vector3 vector3_0)
	{
		return vector3_0.x;
	}

	private static Vector3 MarkAbortedCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGALLOWDELAYEDBINDING()
	{
		return global::_003CModule_003E.vector3_123;
	}

	private static Vector3 CleanupWorkListElementgetTickCount(Transform transform_0)
	{
		return transform_0.right;
	}

	static Class170()
	{
		int num = 7;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_004e:
					num = 14;
					while (true)
					{
						if (num != 14)
						{
							if (num != 995)
							{
								break;
							}
							switch (num)
							{
							case 2:
							case 3:
								goto IL_004e;
							case 6:
								goto end_IL_0041;
							case 7:
								goto end_IL_005d;
							case 0:
								return;
							case 1:
								return;
							case 4:
								return;
							case 5:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0041:
						break;
					}
					break;
				}
				continue;
				end_IL_005d:
				break;
			}
		}
	}
}
