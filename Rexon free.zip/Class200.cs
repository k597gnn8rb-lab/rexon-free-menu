using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Core.Patches;
using UnityEngine;

[Mod("Schizophrenia Gun", "Rig", "Make players only see you.", false, 37, ModType.const_0, false)]
internal class Class200 : MonoBehaviour
{
	private static string string_0;

	private List<Player> list_0;

	private Dictionary<int, GameObject> dictionary_0;

	private Dictionary<int, float> dictionary_1;

	private Dictionary<int, float> dictionary_2;

	private Dictionary<int, bool> dictionary_3;

	private float float_0;

	private float float_1;

	private static float float_2;

	private static double double_0;

	private static double double_1;

	private static bool bool_0;

	private static IntPtr[] ResourceTypeIdIntSizeTYPEFLAGFAGGREGATABLE;

	private static IntPtr[] SoapTimeAssemblyBuilderLock;

	private static IntPtr[] ReadOnlyArrayAttributeTypeLibrary;

	private static Dictionary<int, GameObject>.Enumerator CheckNameSourceLength;

	private static KeyValuePair<int, GameObject> ObjectAccessRuleReorderArgumentArray;

	private static IntPtr[] SerializationMonkeyTYPEFLAGFDUAL;

	private static IntPtr[] FormIdnaCreateSubKey;

	private static IntPtr[] ContextBoundObjectNewKeyset;

	private static IntPtr[] getRevisionNumbersetShadowCopyFiles;

	private static IntPtr[] FormKDDTDSubset;

	private static PhotonNetworkController EnumHelpervalue()
	{
		return PhotonNetworkController.Instance;
	}

	private unsafe void OnDisable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_03e5, IL_03f8, IL_042c, IL_043c, IL_044c, IL_0459, IL_0469, IL_0479, IL_0489, IL_0499, IL_04ac, IL_04bc, IL_04c7, IL_04e1, IL_04ef, IL_04fd, IL_0510, IL_051b, IL_0553, IL_056c, IL_057a, IL_0585, IL_0590, IL_059e, IL_05a7, IL_05d0, IL_05e9, IL_05fc, IL_0605, IL_0613, IL_062b, IL_0639, IL_064c, IL_0657, IL_0665, IL_0673, IL_0683, IL_0691, IL_069f, IL_06b7, IL_06c5, IL_06d3, IL_06e6, IL_06f9, IL_0737, IL_0753, IL_0767, IL_07a1, IL_07af, IL_07c7, IL_07ee, IL_081d, IL_0830, IL_0848, IL_085b, IL_0869, IL_087c, IL_088a, IL_0898, IL_08c1, IL_08cf, IL_08e2, IL_08ed, IL_08fb, IL_0909, IL_0925, IL_092e, IL_0939, IL_0962, IL_0970, IL_0983, IL_0991, IL_099f, IL_09c9, IL_09d7, IL_09ea, IL_09f3, IL_0a01, IL_0a0f, IL_0a1a, IL_0a5a, IL_0a77, IL_0a8a, IL_0a98, IL_0aa3, IL_0acc, IL_0ada, IL_0aed, IL_0af8, IL_0b0b, IL_0b19, IL_0b27, IL_0b67, IL_0b84, IL_0b97, IL_0ba5, IL_0bb3, IL_0bc1, IL_0bcf, IL_0bd8, IL_0bef, IL_0c12, IL_0c1c, IL_0c2a, IL_0c3d, IL_0c7d, IL_0c9a, IL_0cb6, IL_0cc4, IL_0cd2, IL_0cdb, IL_0d1b, IL_0d2f, IL_0d42, IL_0d50, IL_0d5e, IL_0d69, IL_0d77, IL_0d8a, IL_0d98, IL_0da6, IL_0de6, IL_0dfa, IL_0e0d, IL_0e78, IL_0e8b, IL_0e99, IL_0ea7, IL_0eb5, IL_0ec3, IL_0ed7, IL_0f16, IL_0f29, IL_0f37, IL_0f45, IL_0f62, IL_0fb1, IL_0fbb, IL_0fe8, IL_0ffc, IL_100a, IL_101a, IL_1038, IL_1046, IL_1056, IL_106f, IL_107d, IL_108b, IL_1099, IL_10ac, IL_10b6, IL_10c1, IL_10d1, IL_10e1, IL_10f1, IL_1101, IL_1111, IL_112a, IL_113a, IL_114a, IL_1165 are reachable both inside and outside the pinned region starting at IL_115f. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num6;
			int num7;
			int __rxRef94 = default(int);
			ref int reference = ref __rxRef94;
			object[] array8;
			int num8;
			byte* num9;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_114a:
					num2 = 1;
					while (true)
					{
						IL_113a:
						num3 = num2 * 4;
						while (true)
						{
							IL_112a:
							array2 = new byte[4];
							while (true)
							{
								IL_1111:
								array3 = new object[4];
								num = 113;
								while (true)
								{
									IL_1101:
									array4 = new int[4];
									while (true)
									{
										IL_10f1:
										array5 = new int[6];
										while (true)
										{
											IL_10e1:
											array6 = new long[4];
											while (true)
											{
												IL_10d1:
												array7 = new object[15];
												while (true)
												{
													IL_10c1:
													array7[0] = this;
													while (true)
													{
														IL_10b6:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IEnumConnectionPointsAccessMask.getDemandedResourcesGetAllParamCustData);
														while (true)
														{
															IL_10ac:
															ptr2 = ptr;
															while (true)
															{
																IL_1099:
																if (num4 != 1)
																{
																	while (true)
																	{
																		IL_04bc:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_04ac:
																			ptr2++;
																			while (true)
																			{
																				IL_0499:
																				if (b >= 1)
																				{
																					num = 165;
																					while (b <= 27)
																					{
																						while (true)
																						{
																							IL_0479:
																							if (14 < b)
																							{
																								while (true)
																								{
																									IL_0469:
																									if (21 < b)
																									{
																										while (true)
																										{
																											IL_0459:
																											if (24 >= b)
																											{
																												while (true)
																												{
																													IL_044c:
																													if (24 > b)
																													{
																														while (true)
																														{
																															IL_043c:
																															if (22 >= b)
																															{
																																while (22 <= b)
																																{
																																	while (true)
																																	{
																																		IL_03f8:
																																		((delegate*<List<Player>, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((List<Player>)array3[num5 - 1]);
																																		num = 242;
																																		while (true)
																																		{
																																			if (num != 242)
																																			{
																																				if (num != 1223)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 61:
																																					break;
																																				default:
																																					continue;
																																				case 0:
																																				case 228:
																																					goto IL_03f8;
																																				case 145:
																																					goto IL_042c;
																																				case 196:
																																					goto IL_043c;
																																				case 90:
																																					goto IL_044c;
																																				case 217:
																																					goto IL_0459;
																																				case 134:
																																					goto IL_0469;
																																				case 162:
																																					goto IL_0479;
																																				case 165:
																																					goto IL_0489;
																																				case 199:
																																					goto IL_0499;
																																				case 164:
																																					goto IL_04ac;
																																				case 21:
																																				case 225:
																																					goto IL_04bc;
																																				case 36:
																																				case 38:
																																					goto IL_04c7;
																																				case 46:
																																					goto IL_04e1;
																																				case 84:
																																					goto IL_04ef;
																																				case 155:
																																					goto IL_04fd;
																																				case 179:
																																					goto IL_0510;
																																				case 31:
																																				case 121:
																																					goto IL_051b;
																																				case 52:
																																					goto IL_0553;
																																				case 185:
																																					goto IL_056c;
																																				case 69:
																																					goto IL_057a;
																																				case 130:
																																					goto IL_0585;
																																				case 19:
																																					goto IL_0590;
																																				case 66:
																																				case 101:
																																					goto IL_05a7;
																																				case 138:
																																					goto IL_05d0;
																																				case 27:
																																					goto IL_05e9;
																																				case 9:
																																				case 129:
																																					goto IL_0605;
																																				case 153:
																																					goto IL_0613;
																																				case 83:
																																					goto IL_062b;
																																				case 8:
																																					goto IL_0639;
																																				case 151:
																																					goto IL_064c;
																																				case 72:
																																					goto IL_0657;
																																				case 67:
																																					goto IL_0665;
																																				case 48:
																																					goto IL_0673;
																																				case 23:
																																					goto IL_0683;
																																				case 202:
																																					goto IL_0691;
																																				case 184:
																																				case 206:
																																					goto IL_069f;
																																				case 3:
																																					goto IL_06b7;
																																				case 152:
																																					goto IL_06c5;
																																				case 140:
																																					goto IL_06d3;
																																				case 211:
																																					goto IL_06e6;
																																				case 50:
																																				case 213:
																																					goto IL_06f9;
																																				case 128:
																																					goto IL_0737;
																																				case 5:
																																				case 220:
																																					goto IL_0753;
																																				case 221:
																																					goto IL_0767;
																																				case 222:
																																					goto IL_07a1;
																																				case 143:
																																				case 203:
																																					goto IL_07af;
																																				case 158:
																																					goto IL_07c7;
																																				case 53:
																																					goto IL_07ee;
																																				case 229:
																																					goto IL_081d;
																																				case 235:
																																					goto IL_0830;
																																				case 127:
																																					goto IL_0848;
																																				case 208:
																																					goto IL_0869;
																																				case 44:
																																					goto IL_087c;
																																				case 78:
																																					goto IL_088a;
																																				case 119:
																																				case 168:
																																					goto IL_0898;
																																				case 82:
																																					goto IL_08c1;
																																				case 198:
																																					goto IL_08cf;
																																				case 4:
																																					goto IL_08e2;
																																				case 120:
																																					goto IL_08ed;
																																				case 133:
																																					goto IL_08fb;
																																				case 173:
																																				case 226:
																																					goto IL_0909;
																																				case 28:
																																					goto IL_092e;
																																				case 15:
																																				case 131:
																																					goto IL_0939;
																																				case 191:
																																					goto IL_0962;
																																				case 141:
																																					goto IL_0970;
																																				case 123:
																																					goto IL_0983;
																																				case 230:
																																					goto IL_0991;
																																				case 64:
																																				case 132:
																																					goto IL_099f;
																																				case 87:
																																					goto IL_09c9;
																																				case 91:
																																					goto IL_09d7;
																																				case 163:
																																					goto IL_09f3;
																																				case 161:
																																					goto IL_0a01;
																																				case 174:
																																					goto IL_0a0f;
																																				case 7:
																																				case 73:
																																					goto IL_0a1a;
																																				case 11:
																																					goto IL_0a5a;
																																				case 157:
																																					goto IL_0a77;
																																				case 231:
																																					goto IL_0a8a;
																																				case 156:
																																					goto IL_0a98;
																																				case 20:
																																				case 30:
																																					goto IL_0aa3;
																																				case 233:
																																					goto IL_0acc;
																																				case 106:
																																					goto IL_0ada;
																																				case 10:
																																					goto IL_0aed;
																																				case 160:
																																					goto IL_0af8;
																																				case 97:
																																					goto IL_0b0b;
																																				case 154:
																																					goto IL_0b19;
																																				case 34:
																																				case 214:
																																					goto IL_0b27;
																																				case 188:
																																					goto IL_0b67;
																																				case 86:
																																					goto IL_0b84;
																																				case 103:
																																					goto IL_0b97;
																																				case 18:
																																					goto IL_0ba5;
																																				case 178:
																																					goto IL_0bb3;
																																				case 35:
																																					goto IL_0bc1;
																																				case 190:
																																				case 216:
																																					goto IL_0bd8;
																																				case 42:
																																					goto IL_0bef;
																																				case 200:
																																					goto IL_0c12;
																																				case 116:
																																					goto IL_0c1c;
																																				case 45:
																																					goto IL_0c2a;
																																				case 96:
																																				case 218:
																																					goto IL_0c3d;
																																				case 117:
																																					goto IL_0c7d;
																																				case 180:
																																					goto IL_0c9a;
																																				case 47:
																																					goto IL_0cb6;
																																				case 100:
																																					goto IL_0cc4;
																																				case 22:
																																				case 74:
																																					goto IL_0cdb;
																																				case 171:
																																					goto IL_0d1b;
																																				case 76:
																																					goto IL_0d2f;
																																				case 32:
																																					goto IL_0d42;
																																				case 51:
																																					goto IL_0d50;
																																				case 25:
																																					goto IL_0d5e;
																																				case 63:
																																					goto IL_0d69;
																																				case 102:
																																				case 125:
																																					goto IL_0d77;
																																				case 107:
																																					goto IL_0d8a;
																																				case 70:
																																					goto IL_0d98;
																																				case 29:
																																				case 39:
																																					goto IL_0da6;
																																				case 204:
																																					goto IL_0de6;
																																				case 187:
																																					goto IL_0dfa;
																																				case 58:
																																				case 75:
																																					goto IL_0e0d;
																																				case 205:
																																					goto IL_0e78;
																																				case 71:
																																					goto IL_0e8b;
																																				case 81:
																																					goto IL_0e99;
																																				case 144:
																																					goto IL_0ea7;
																																				case 41:
																																					goto IL_0eb5;
																																				case 2:
																																				case 201:
																																					goto IL_0ec3;
																																				case 111:
																																					goto IL_0ed7;
																																				case 182:
																																					goto IL_0f16;
																																				case 142:
																																					goto IL_0f29;
																																				case 193:
																																					goto IL_0f37;
																																				case 118:
																																				case 234:
																																					goto IL_0f45;
																																				case 95:
																																					goto IL_0ffc;
																																				case 80:
																																					goto IL_100a;
																																				case 209:
																																				case 227:
																																					goto IL_101a;
																																				case 43:
																																					goto IL_1038;
																																				case 186:
																																					goto end_IL_03e5;
																																				case 1:
																																				case 6:
																																				case 12:
																																				case 16:
																																				case 26:
																																				case 40:
																																				case 55:
																																				case 68:
																																				case 77:
																																				case 88:
																																				case 89:
																																				case 93:
																																				case 94:
																																				case 99:
																																				case 104:
																																				case 109:
																																				case 122:
																																				case 136:
																																				case 139:
																																				case 146:
																																				case 147:
																																				case 166:
																																				case 170:
																																				case 176:
																																				case 183:
																																				case 189:
																																				case 194:
																																				case 207:
																																				case 212:
																																				case 232:
																																					goto end_IL_042c;
																																				case 159:
																																					goto IL_106f;
																																				case 150:
																																					goto IL_107d;
																																				case 79:
																																					goto IL_108b;
																																				case 13:
																																				case 14:
																																				case 17:
																																				case 24:
																																				case 33:
																																				case 49:
																																				case 54:
																																				case 56:
																																				case 57:
																																				case 59:
																																				case 65:
																																				case 85:
																																				case 105:
																																				case 110:
																																				case 112:
																																				case 126:
																																				case 135:
																																				case 137:
																																				case 148:
																																				case 149:
																																				case 169:
																																				case 172:
																																				case 175:
																																				case 177:
																																				case 181:
																																				case 195:
																																				case 197:
																																				case 210:
																																				case 215:
																																				case 223:
																																					goto IL_1099;
																																				case 192:
																																					goto IL_10ac;
																																				case 92:
																																					goto IL_10b6;
																																				case 114:
																																					goto IL_10c1;
																																				case 224:
																																					goto IL_10d1;
																																				case 108:
																																					goto IL_10e1;
																																				case 115:
																																					goto IL_10f1;
																																				case 113:
																																					goto IL_1101;
																																				case 37:
																																					goto IL_1111;
																																				case 98:
																																				case 219:
																																					goto IL_112a;
																																				case 62:
																																					goto IL_113a;
																																				case 60:
																																					goto IL_114a;
																																				case 124:
																																				case 167:
																																					return;
																																				}
																																				goto end_IL_0499;
																																			}
																																			num5--;
																																			goto IL_0869;
																																			IL_0869:
																																			ptr2 += 8;
																																			goto IL_1099;
																																			continue;
																																			end_IL_03e5:
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_1046;
																																	continue;
																																	end_IL_042c:
																																	break;
																																	IL_042c:;
																																}
																																break;
																															}
																															goto IL_087c;
																															IL_08cf:
																															ptr2 += 8;
																															goto IL_1099;
																															IL_087c:
																															if (23 < b)
																															{
																																break;
																															}
																															goto IL_088a;
																															IL_088a:
																															if (23 > b)
																															{
																																break;
																															}
																															goto IL_0898;
																															IL_0898:
																															((delegate*<Class200, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((Class200)array3[num5 - 1]);
																															goto IL_08c1;
																															IL_08c1:
																															num5--;
																															goto IL_08cf;
																														}
																														break;
																													}
																													goto IL_04c7;
																													IL_04fd:
																													ptr2 += 8;
																													goto IL_1099;
																													IL_04c7:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(float*)(ptr2 + num3);
																													goto IL_04e1;
																													IL_04e1:
																													array2[num5] = 3;
																													goto IL_04ef;
																													IL_04ef:
																													num5++;
																													goto IL_04fd;
																												}
																												break;
																											}
																											goto IL_08e2;
																											IL_09c9:
																											num5--;
																											goto IL_09d7;
																											IL_08e2:
																											if (26 < b)
																											{
																												goto IL_08ed;
																											}
																											num = 28;
																											goto IL_092e;
																											IL_08ed:
																											if (27 < b)
																											{
																												break;
																											}
																											goto IL_08fb;
																											IL_08fb:
																											if (27 > b)
																											{
																												break;
																											}
																											goto IL_0909;
																											IL_0909:
																											num6 = ptr2;
																											num7 = -200;
																											num4 = 1;
																											ptr2 = num6 + num7;
																											goto IL_1099;
																											IL_09d7:
																											ptr2 += 8;
																											goto IL_1099;
																											IL_092e:
																											if (26 <= b)
																											{
																												goto IL_0939;
																											}
																											goto IL_0983;
																											IL_0939:
																											((delegate*<string, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																											goto IL_0962;
																											IL_0962:
																											num5--;
																											goto IL_0970;
																											IL_0970:
																											ptr2 += 8;
																											goto IL_1099;
																											IL_0983:
																											if (25 < b)
																											{
																												break;
																											}
																											goto IL_0991;
																											IL_0991:
																											if (25 > b)
																											{
																												break;
																											}
																											goto IL_099f;
																											IL_099f:
																											((delegate*<float, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])));
																											goto IL_09c9;
																										}
																										break;
																									}
																									goto IL_0510;
																									IL_06b7:
																									array2[num5] = 5;
																									goto IL_06c5;
																									IL_0510:
																									if (21 <= b)
																									{
																										goto IL_051b;
																									}
																									goto IL_056c;
																									IL_051b:
																									array3[num5 - 1] = ((delegate*<Class200, List<Player>>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((Class200)array3[num5 - 1]);
																									goto IL_0553;
																									IL_0553:
																									array2[num5 - 1] = 5;
																									goto IL_06e6;
																									IL_06e6:
																									ptr2 += 8;
																									goto IL_1099;
																									IL_056c:
																									if (17 >= b)
																									{
																										goto IL_057a;
																									}
																									goto IL_064c;
																									IL_057a:
																									if (17 > b)
																									{
																										goto IL_0585;
																									}
																									num = 9;
																									goto IL_0605;
																									IL_0585:
																									if (15 >= b)
																									{
																										goto IL_0590;
																									}
																									goto IL_05e9;
																									IL_0590:
																									if (15 > b)
																									{
																										break;
																									}
																									num = 101;
																									goto IL_05a7;
																									IL_06d3:
																									ptr2 += 8;
																									goto IL_1099;
																									IL_05a7:
																									array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																									goto IL_05d0;
																									IL_05d0:
																									array2[num5 - 1] = 5;
																									goto IL_1099;
																									IL_05e9:
																									if (16 < b)
																									{
																										break;
																									}
																									goto IL_07a1;
																									IL_07a1:
																									if (16 > b)
																									{
																										break;
																									}
																									goto IL_07af;
																									IL_07af:
																									array2[num5] = array2[num5 - 1];
																									goto IL_07c7;
																									IL_07c7:
																									array4[num5 - 0] = array4[num5 - 1];
																									num = 53;
																									goto IL_07ee;
																									IL_07ee:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									num = 235;
																									goto IL_0830;
																									IL_0830:
																									array3[num5] = array3[num5 - 1];
																									goto IL_0848;
																									IL_0848:
																									num5++;
																									goto IL_1099;
																									IL_06c5:
																									num5++;
																									goto IL_06d3;
																									IL_0605:
																									array2[num5] = 5;
																									goto IL_0613;
																									IL_0613:
																									array3[num5] = array7[*(int*)(ptr2 + num3)];
																									goto IL_062b;
																									IL_062b:
																									num5++;
																									goto IL_0639;
																									IL_0639:
																									ptr2 += 8;
																									goto IL_1099;
																									IL_064c:
																									if (19 >= b)
																									{
																										goto IL_0657;
																									}
																									goto IL_0683;
																									IL_0657:
																									if (19 > b)
																									{
																										goto IL_0665;
																									}
																									goto IL_0753;
																									IL_0665:
																									if (18 < b)
																									{
																										break;
																									}
																									goto IL_0673;
																									IL_0673:
																									if (18 > b)
																									{
																										break;
																									}
																									goto IL_06f9;
																									IL_06f9:
																									((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																									goto IL_0737;
																									IL_0737:
																									num5 -= 3;
																									num = 181;
																									goto IL_1099;
																									IL_0753:
																									array2[num5 - 1] = 5;
																									goto IL_0767;
																									IL_0767:
																									array3[num5 - 1] = ((delegate*<string[], string>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																									goto IL_081d;
																									IL_081d:
																									ptr2 += 8;
																									goto IL_1099;
																									IL_0683:
																									if (20 < b)
																									{
																										break;
																									}
																									goto IL_0691;
																									IL_0691:
																									if (20 > b)
																									{
																										break;
																									}
																									goto IL_069f;
																									IL_069f:
																									array3[num5] = array7[*(int*)(ptr2 + num3)];
																									goto IL_06b7;
																								}
																								break;
																							}
																							num = 163;
																							goto IL_09f3;
																							IL_1038:
																							ptr2 += 8;
																							goto IL_1046;
																							IL_1046:
																							num5--;
																							goto IL_1099;
																							IL_09f3:
																							if (14 > b)
																							{
																								goto IL_0a01;
																							}
																							goto IL_101a;
																							IL_0a01:
																							if (7 >= b)
																							{
																								goto IL_0a0f;
																							}
																							goto IL_0d42;
																							IL_0a0f:
																							if (7 <= b)
																							{
																								goto IL_0a1a;
																							}
																							goto IL_0a8a;
																							IL_0a1a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0a5a;
																							IL_0a5a:
																							array2[num5 - 2] = 0;
																							num = 157;
																							goto IL_0a77;
																							IL_0a77:
																							num5--;
																							goto IL_1099;
																							IL_0a8a:
																							if (3 >= b)
																							{
																								goto IL_0a98;
																							}
																							goto IL_0b97;
																							IL_0a98:
																							if (3 <= b)
																							{
																								goto IL_0aa3;
																							}
																							goto IL_0aed;
																							IL_0aa3:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0acc;
																							IL_0acc:
																							ptr2 += 8;
																							goto IL_0ada;
																							IL_0ada:
																							num5--;
																							goto IL_1099;
																							IL_0aed:
																							if (1 >= b)
																							{
																								goto IL_0af8;
																							}
																							goto IL_0b0b;
																							IL_0af8:
																							if (1 > b)
																							{
																							}
																							break;
																							IL_0b0b:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0b19;
																							IL_0b19:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0b27;
																							IL_0b27:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0b67;
																							IL_0b67:
																							array2[num5 - 2] = 0;
																							num = 86;
																							goto IL_0b84;
																							IL_0b84:
																							num5--;
																							goto IL_1099;
																							IL_0b97:
																							if (5 >= b)
																							{
																								goto IL_0ba5;
																							}
																							goto IL_0cb6;
																							IL_0ba5:
																							if (5 > b)
																							{
																								goto IL_0bb3;
																							}
																							goto IL_0c3d;
																							IL_0bb3:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0bc1;
																							IL_0bc1:
																							if (4 > b)
																							{
																								break;
																							}
																							num = 216;
																							goto IL_0bd8;
																							IL_0ffc:
																							array2[num5] = 5;
																							goto IL_100a;
																							IL_0bd8:
																							array2[num5] = 0;
																							num = 42;
																							goto IL_0bef;
																							IL_0bef:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0c12;
																							IL_0c12:
																							array3[num5] = null;
																							goto IL_0c1c;
																							IL_0c1c:
																							num5++;
																							goto IL_0c2a;
																							IL_0c2a:
																							ptr2 += 8;
																							goto IL_1099;
																							IL_0c3d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0c7d;
																							IL_0c7d:
																							array2[num5 - 2] = 0;
																							num = 180;
																							goto IL_0c9a;
																							IL_0c9a:
																							num5--;
																							num = 169;
																							goto IL_1099;
																							IL_0cb6:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0cc4;
																							IL_0cc4:
																							if (6 > b)
																							{
																								break;
																							}
																							num = 22;
																							goto IL_0cdb;
																							IL_100a:
																							num5++;
																							goto IL_1099;
																							IL_0cdb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0d1b;
																							IL_0d1b:
																							array2[num5 - 2] = 0;
																							goto IL_0d2f;
																							IL_0d2f:
																							num5--;
																							goto IL_1099;
																							IL_0d42:
																							if (10 >= b)
																							{
																								goto IL_0d50;
																							}
																							goto IL_0e8b;
																							IL_0d50:
																							if (10 > b)
																							{
																								goto IL_0d5e;
																							}
																							goto IL_0e0d;
																							IL_0d5e:
																							if (8 >= b)
																							{
																								goto IL_0d69;
																							}
																							goto IL_0d8a;
																							IL_0d69:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0d77;
																							IL_0d77:
																							num5--;
																							goto IL_1099;
																							IL_0d8a:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_0d98;
																							IL_0d98:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0da6;
																							IL_0da6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0de6;
																							IL_0de6:
																							array2[num5 - 2] = 0;
																							goto IL_0dfa;
																							IL_0dfa:
																							num5--;
																							goto IL_1099;
																							IL_0e0d:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 205;
																							goto IL_0e78;
																							IL_0e78:
																							num5 -= 2;
																							goto IL_1099;
																							IL_0e8b:
																							if (12 >= b)
																							{
																								goto IL_0e99;
																							}
																							goto IL_0f29;
																							IL_0e99:
																							if (12 <= b)
																							{
																								goto IL_1099;
																							}
																							goto IL_0ea7;
																							IL_0ea7:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_0eb5;
																							IL_0eb5:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_0ec3;
																							IL_0ec3:
																							array2[num5 - 1] = 0;
																							goto IL_0ed7;
																							IL_0ed7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																							goto IL_0f16;
																							IL_0f16:
																							ptr2 += 8;
																							goto IL_1099;
																							IL_0f29:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_0f37;
																							IL_0f37:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_0f45;
																							IL_0f45:
																							array8 = array3;
																							num8 = num5;
																							if (array == null)
																							{
																								goto IL_0f54;
																							}
																							num9 = ptr2;
																							byte b2 = *num9;
																							ptr2 = num9 + 4;
																							int num10 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num10;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_0ffc;
																							IL_101a:
																							array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																							goto IL_1038;
																						}
																						break;
																						IL_0489:;
																					}
																				}
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																				goto IL_106f;
																				IL_107d:
																				num5++;
																				goto IL_108b;
																				IL_108b:
																				ptr2 += 8;
																				goto IL_1099;
																				IL_106f:
																				array2[num5] = 0;
																				goto IL_107d;
																				continue;
																				end_IL_0499:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																num = 167;
																return;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0f54:
			while (true)
			{
				IL_0f54_2:
				array = new byte[4];
				while (true)
				{
					IL_0f62:
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num5] = 5;
						while (true)
						{
							IL_100a_2:
							num5++;
							while (true)
							{
								IL_1099_2:
								if (num4 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_0499_2:
												if (b >= 1)
												{
													num = 165;
													while (b <= 27)
													{
														while (true)
														{
															IL_0479_2:
															if (14 < b)
															{
																while (true)
																{
																	IL_0469_2:
																	if (21 < b)
																	{
																		while (true)
																		{
																			IL_0459_2:
																			if (24 >= b)
																			{
																				while (true)
																				{
																					IL_044c_2:
																					if (24 > b)
																					{
																						while (true)
																						{
																							IL_043c_2:
																							if (22 >= b)
																							{
																								while (22 <= b)
																								{
																									while (true)
																									{
																										IL_03f8_2:
																										((delegate*<List<Player>, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((List<Player>)array3[num5 - 1]);
																										num = 242;
																										while (true)
																										{
																											if (num != 242)
																											{
																												if (num != 1223)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 0:
																												case 228:
																													goto IL_03f8_2;
																												case 145:
																													goto IL_042c_2;
																												case 196:
																													goto IL_043c_2;
																												case 90:
																													goto IL_044c_2;
																												case 217:
																													goto IL_0459_2;
																												case 134:
																													goto IL_0469_2;
																												case 162:
																													goto IL_0479_2;
																												case 165:
																													goto IL_0489_2;
																												case 199:
																													goto IL_0499_2;
																												case 164:
																													goto end_IL_0499_2;
																												case 21:
																												case 225:
																													goto end_IL_04ac;
																												case 36:
																												case 38:
																													goto IL_04c7_2;
																												case 46:
																													goto IL_04e1_2;
																												case 84:
																													goto IL_04ef_2;
																												case 155:
																													goto IL_04fd_2;
																												case 179:
																													goto IL_0510_2;
																												case 31:
																												case 121:
																													goto IL_051b_2;
																												case 52:
																													goto IL_0553_2;
																												case 185:
																													goto IL_056c_2;
																												case 69:
																													goto IL_057a_2;
																												case 130:
																													goto IL_0585_2;
																												case 19:
																													goto IL_0590_2;
																												case 66:
																												case 101:
																													goto IL_05a7_2;
																												case 138:
																													goto IL_05d0_2;
																												case 27:
																													goto IL_05e9_2;
																												case 9:
																												case 129:
																													goto IL_0605_2;
																												case 153:
																													goto IL_0613_2;
																												case 83:
																													goto IL_062b_2;
																												case 8:
																													goto IL_0639_2;
																												case 151:
																													goto IL_064c_2;
																												case 72:
																													goto IL_0657_2;
																												case 67:
																													goto IL_0665_2;
																												case 48:
																													goto IL_0673_2;
																												case 23:
																													goto IL_0683_2;
																												case 202:
																													goto IL_0691_2;
																												case 184:
																												case 206:
																													goto IL_069f_2;
																												case 3:
																													goto IL_06b7_2;
																												case 152:
																													goto IL_06c5_2;
																												case 140:
																													goto IL_06d3_2;
																												case 211:
																													goto IL_06e6_2;
																												case 50:
																												case 213:
																													goto IL_06f9_2;
																												case 128:
																													goto IL_0737_2;
																												case 5:
																												case 220:
																													goto IL_0753_2;
																												case 221:
																													goto IL_0767_2;
																												case 222:
																													goto IL_07a1_2;
																												case 143:
																												case 203:
																													goto IL_07af_2;
																												case 158:
																													goto IL_07c7_2;
																												case 53:
																													goto IL_07ee_2;
																												case 229:
																													goto IL_081d_2;
																												case 235:
																													goto IL_0830_2;
																												case 127:
																													goto IL_0848_2;
																												case 208:
																													goto IL_0869_2;
																												case 44:
																													goto IL_087c_2;
																												case 78:
																													goto IL_088a_2;
																												case 119:
																												case 168:
																													goto IL_0898_2;
																												case 82:
																													goto IL_08c1_2;
																												case 198:
																													goto IL_08cf_2;
																												case 4:
																													goto IL_08e2_2;
																												case 120:
																													goto IL_08ed_2;
																												case 133:
																													goto IL_08fb_2;
																												case 173:
																												case 226:
																													goto IL_0909_2;
																												case 28:
																													goto IL_092e_2;
																												case 15:
																												case 131:
																													goto IL_0939_2;
																												case 191:
																													goto IL_0962_2;
																												case 141:
																													goto IL_0970_2;
																												case 123:
																													goto IL_0983_2;
																												case 230:
																													goto IL_0991_2;
																												case 64:
																												case 132:
																													goto IL_099f_2;
																												case 87:
																													goto IL_09c9_2;
																												case 91:
																													goto IL_09d7_2;
																												case 163:
																													goto IL_09f3_2;
																												case 161:
																													goto IL_0a01_2;
																												case 174:
																													goto IL_0a0f_2;
																												case 7:
																												case 73:
																													goto IL_0a1a_2;
																												case 11:
																													goto IL_0a5a_2;
																												case 157:
																													goto IL_0a77_2;
																												case 231:
																													goto IL_0a8a_2;
																												case 156:
																													goto IL_0a98_2;
																												case 20:
																												case 30:
																													goto IL_0aa3_2;
																												case 233:
																													goto IL_0acc_2;
																												case 106:
																													goto IL_0ada_2;
																												case 10:
																													goto IL_0aed_2;
																												case 160:
																													goto IL_0af8_2;
																												case 97:
																													goto IL_0b0b_2;
																												case 154:
																													goto IL_0b19_2;
																												case 34:
																												case 214:
																													goto IL_0b27_2;
																												case 188:
																													goto IL_0b67_2;
																												case 86:
																													goto IL_0b84_2;
																												case 103:
																													goto IL_0b97_2;
																												case 18:
																													goto IL_0ba5_2;
																												case 178:
																													goto IL_0bb3_2;
																												case 35:
																													goto IL_0bc1_2;
																												case 190:
																												case 216:
																													goto IL_0bd8_2;
																												case 42:
																													goto IL_0bef_2;
																												case 200:
																													goto IL_0c12_2;
																												case 116:
																													goto IL_0c1c_2;
																												case 45:
																													goto IL_0c2a_2;
																												case 96:
																												case 218:
																													goto IL_0c3d_2;
																												case 117:
																													goto IL_0c7d_2;
																												case 180:
																													goto IL_0c9a_2;
																												case 47:
																													goto IL_0cb6_2;
																												case 100:
																													goto IL_0cc4_2;
																												case 22:
																												case 74:
																													goto IL_0cdb_2;
																												case 171:
																													goto IL_0d1b_2;
																												case 76:
																													goto IL_0d2f_2;
																												case 32:
																													goto IL_0d42_2;
																												case 51:
																													goto IL_0d50_2;
																												case 25:
																													goto IL_0d5e_2;
																												case 63:
																													goto IL_0d69_2;
																												case 102:
																												case 125:
																													goto IL_0d77_2;
																												case 107:
																													goto IL_0d8a_2;
																												case 70:
																													goto IL_0d98_2;
																												case 29:
																												case 39:
																													goto IL_0da6_2;
																												case 204:
																													goto IL_0de6_2;
																												case 187:
																													goto IL_0dfa_2;
																												case 58:
																												case 75:
																													goto IL_0e0d_2;
																												case 205:
																													goto IL_0e78_2;
																												case 71:
																													goto IL_0e8b_2;
																												case 81:
																													goto IL_0e99_2;
																												case 144:
																													goto IL_0ea7_2;
																												case 41:
																													goto IL_0eb5_2;
																												case 2:
																												case 201:
																													goto IL_0ec3_2;
																												case 111:
																													goto IL_0ed7_2;
																												case 182:
																													goto IL_0f16_2;
																												case 142:
																													goto IL_0f29_2;
																												case 193:
																													goto IL_0f37_2;
																												case 118:
																												case 234:
																													goto IL_0f45_2;
																												case 95:
																													goto end_IL_04bc;
																												case 80:
																													goto IL_100a_2;
																												case 209:
																												case 227:
																													goto IL_101a_2;
																												case 43:
																													goto IL_1038_2;
																												case 186:
																													goto end_IL_03e5_2;
																												case 1:
																												case 6:
																												case 12:
																												case 16:
																												case 26:
																												case 40:
																												case 55:
																												case 68:
																												case 77:
																												case 88:
																												case 89:
																												case 93:
																												case 94:
																												case 99:
																												case 104:
																												case 109:
																												case 122:
																												case 136:
																												case 139:
																												case 146:
																												case 147:
																												case 166:
																												case 170:
																												case 176:
																												case 183:
																												case 189:
																												case 194:
																												case 207:
																												case 212:
																												case 232:
																													goto end_IL_042c_2;
																												case 159:
																													goto IL_106f_2;
																												case 150:
																													goto IL_107d_2;
																												case 79:
																													goto IL_108b_2;
																												case 13:
																												case 14:
																												case 17:
																												case 24:
																												case 33:
																												case 49:
																												case 54:
																												case 56:
																												case 57:
																												case 59:
																												case 65:
																												case 85:
																												case 105:
																												case 110:
																												case 112:
																												case 126:
																												case 135:
																												case 137:
																												case 148:
																												case 149:
																												case 169:
																												case 172:
																												case 175:
																												case 177:
																												case 181:
																												case 195:
																												case 197:
																												case 210:
																												case 215:
																												case 223:
																													goto IL_1099_2;
																												case 192:
																													ptr2 = ptr;
																													goto IL_1099_2;
																												case 92:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IEnumConnectionPointsAccessMask.getDemandedResourcesGetAllParamCustData);
																													goto case 192;
																												case 114:
																													array7[0] = this;
																													goto case 92;
																												case 224:
																													array7 = new object[15];
																													goto case 114;
																												case 108:
																													array6 = new long[4];
																													goto case 224;
																												case 115:
																													array5 = new int[6];
																													goto case 108;
																												case 113:
																													array4 = new int[4];
																													goto case 115;
																												case 37:
																													array3 = new object[4];
																													num = 113;
																													goto case 113;
																												case 98:
																												case 219:
																													array2 = new byte[4];
																													goto case 37;
																												case 62:
																													num3 = num2 * 4;
																													goto case 98;
																												case 60:
																													num2 = 1;
																													goto case 62;
																												case 61:
																													goto end_IL_0ffc;
																												case 124:
																												case 167:
																													return;
																												}
																												continue;
																											}
																											num5--;
																											goto IL_0869_2;
																											IL_0869_2:
																											ptr2 += 8;
																											goto IL_1099_2;
																											continue;
																											end_IL_03e5_2:
																											break;
																										}
																										break;
																									}
																									goto IL_1046_2;
																									continue;
																									end_IL_042c_2:
																									break;
																									IL_042c_2:;
																								}
																								break;
																							}
																							goto IL_087c_2;
																							IL_08cf_2:
																							ptr2 += 8;
																							goto IL_1099_2;
																							IL_087c_2:
																							if (23 < b)
																							{
																								break;
																							}
																							goto IL_088a_2;
																							IL_088a_2:
																							if (23 > b)
																							{
																								break;
																							}
																							goto IL_0898_2;
																							IL_0898_2:
																							((delegate*<Class200, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((Class200)array3[num5 - 1]);
																							goto IL_08c1_2;
																							IL_08c1_2:
																							num5--;
																							goto IL_08cf_2;
																						}
																						break;
																					}
																					goto IL_04c7_2;
																					IL_04fd_2:
																					ptr2 += 8;
																					goto IL_1099_2;
																					IL_04c7_2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(float*)(ptr2 + num3);
																					goto IL_04e1_2;
																					IL_04e1_2:
																					array2[num5] = 3;
																					goto IL_04ef_2;
																					IL_04ef_2:
																					num5++;
																					goto IL_04fd_2;
																				}
																				break;
																			}
																			goto IL_08e2_2;
																			IL_09c9_2:
																			num5--;
																			goto IL_09d7_2;
																			IL_08e2_2:
																			if (26 < b)
																			{
																				goto IL_08ed_2;
																			}
																			num = 28;
																			goto IL_092e_2;
																			IL_08ed_2:
																			if (27 < b)
																			{
																				break;
																			}
																			goto IL_08fb_2;
																			IL_08fb_2:
																			if (27 > b)
																			{
																				break;
																			}
																			goto IL_0909_2;
																			IL_0909_2:
																			num6 = ptr2;
																			num7 = -200;
																			num4 = 1;
																			ptr2 = num6 + num7;
																			goto IL_1099_2;
																			IL_09d7_2:
																			ptr2 += 8;
																			goto IL_1099_2;
																			IL_092e_2:
																			if (26 <= b)
																			{
																				goto IL_0939_2;
																			}
																			goto IL_0983_2;
																			IL_0939_2:
																			((delegate*<string, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																			goto IL_0962_2;
																			IL_0962_2:
																			num5--;
																			goto IL_0970_2;
																			IL_0970_2:
																			ptr2 += 8;
																			goto IL_1099_2;
																			IL_0983_2:
																			if (25 < b)
																			{
																				break;
																			}
																			goto IL_0991_2;
																			IL_0991_2:
																			if (25 > b)
																			{
																				break;
																			}
																			goto IL_099f_2;
																			IL_099f_2:
																			((delegate*<float, void>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])));
																			goto IL_09c9_2;
																		}
																		break;
																	}
																	goto IL_0510_2;
																	IL_06b7_2:
																	array2[num5] = 5;
																	goto IL_06c5_2;
																	IL_0510_2:
																	if (21 <= b)
																	{
																		goto IL_051b_2;
																	}
																	goto IL_056c_2;
																	IL_051b_2:
																	array3[num5 - 1] = ((delegate*<Class200, List<Player>>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((Class200)array3[num5 - 1]);
																	goto IL_0553_2;
																	IL_0553_2:
																	array2[num5 - 1] = 5;
																	goto IL_06e6_2;
																	IL_06e6_2:
																	ptr2 += 8;
																	goto IL_1099_2;
																	IL_056c_2:
																	if (17 >= b)
																	{
																		goto IL_057a_2;
																	}
																	goto IL_064c_2;
																	IL_057a_2:
																	if (17 > b)
																	{
																		goto IL_0585_2;
																	}
																	num = 9;
																	goto IL_0605_2;
																	IL_0585_2:
																	if (15 >= b)
																	{
																		goto IL_0590_2;
																	}
																	goto IL_05e9_2;
																	IL_0590_2:
																	if (15 > b)
																	{
																		break;
																	}
																	num = 101;
																	goto IL_05a7_2;
																	IL_06d3_2:
																	ptr2 += 8;
																	goto IL_1099_2;
																	IL_05a7_2:
																	array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																	goto IL_05d0_2;
																	IL_05d0_2:
																	array2[num5 - 1] = 5;
																	goto IL_1099_2;
																	IL_05e9_2:
																	if (16 < b)
																	{
																		break;
																	}
																	goto IL_07a1_2;
																	IL_07a1_2:
																	if (16 > b)
																	{
																		break;
																	}
																	goto IL_07af_2;
																	IL_07af_2:
																	array2[num5] = array2[num5 - 1];
																	goto IL_07c7_2;
																	IL_07c7_2:
																	array4[num5 - 0] = array4[num5 - 1];
																	num = 53;
																	goto IL_07ee_2;
																	IL_07ee_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	num = 235;
																	goto IL_0830_2;
																	IL_0830_2:
																	array3[num5] = array3[num5 - 1];
																	goto IL_0848_2;
																	IL_0848_2:
																	num5++;
																	goto IL_1099_2;
																	IL_06c5_2:
																	num5++;
																	goto IL_06d3_2;
																	IL_0605_2:
																	array2[num5] = 5;
																	goto IL_0613_2;
																	IL_0613_2:
																	array3[num5] = array7[*(int*)(ptr2 + num3)];
																	goto IL_062b_2;
																	IL_062b_2:
																	num5++;
																	goto IL_0639_2;
																	IL_0639_2:
																	ptr2 += 8;
																	goto IL_1099_2;
																	IL_064c_2:
																	if (19 >= b)
																	{
																		goto IL_0657_2;
																	}
																	goto IL_0683_2;
																	IL_0657_2:
																	if (19 > b)
																	{
																		goto IL_0665_2;
																	}
																	goto IL_0753_2;
																	IL_0665_2:
																	if (18 < b)
																	{
																		break;
																	}
																	goto IL_0673_2;
																	IL_0673_2:
																	if (18 > b)
																	{
																		break;
																	}
																	goto IL_06f9_2;
																	IL_06f9_2:
																	((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																	goto IL_0737_2;
																	IL_0737_2:
																	num5 -= 3;
																	num = 181;
																	goto IL_1099_2;
																	IL_0753_2:
																	array2[num5 - 1] = 5;
																	goto IL_0767_2;
																	IL_0767_2:
																	array3[num5 - 1] = ((delegate*<string[], string>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																	goto IL_081d_2;
																	IL_081d_2:
																	ptr2 += 8;
																	goto IL_1099_2;
																	IL_0683_2:
																	if (20 < b)
																	{
																		break;
																	}
																	goto IL_0691_2;
																	IL_0691_2:
																	if (20 > b)
																	{
																		break;
																	}
																	goto IL_069f_2;
																	IL_069f_2:
																	array3[num5] = array7[*(int*)(ptr2 + num3)];
																	goto IL_06b7_2;
																}
																break;
															}
															num = 163;
															goto IL_09f3_2;
															IL_0f45_2:
															array8 = array3;
															num8 = num5;
															if (array == null)
															{
																goto IL_0f54_2;
															}
															goto IL_0f62;
															IL_101a_2:
															array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
															goto IL_1038_2;
															IL_09f3_2:
															if (14 > b)
															{
																goto IL_0a01_2;
															}
															goto IL_101a_2;
															IL_0a01_2:
															if (7 >= b)
															{
																goto IL_0a0f_2;
															}
															goto IL_0d42_2;
															IL_0a0f_2:
															if (7 <= b)
															{
																goto IL_0a1a_2;
															}
															goto IL_0a8a_2;
															IL_0a1a_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0a5a_2;
															IL_0a5a_2:
															array2[num5 - 2] = 0;
															num = 157;
															goto IL_0a77_2;
															IL_0a77_2:
															num5--;
															goto IL_1099_2;
															IL_0a8a_2:
															if (3 >= b)
															{
																goto IL_0a98_2;
															}
															goto IL_0b97_2;
															IL_0a98_2:
															if (3 <= b)
															{
																goto IL_0aa3_2;
															}
															goto IL_0aed_2;
															IL_0aa3_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0acc_2;
															IL_0acc_2:
															ptr2 += 8;
															goto IL_0ada_2;
															IL_0ada_2:
															num5--;
															goto IL_1099_2;
															IL_0aed_2:
															if (1 >= b)
															{
																goto IL_0af8_2;
															}
															goto IL_0b0b_2;
															IL_0af8_2:
															if (1 > b)
															{
															}
															break;
															IL_0b0b_2:
															if (2 < b)
															{
																break;
															}
															goto IL_0b19_2;
															IL_0b19_2:
															if (2 > b)
															{
																break;
															}
															goto IL_0b27_2;
															IL_0b27_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0b67_2;
															IL_0b67_2:
															array2[num5 - 2] = 0;
															num = 86;
															goto IL_0b84_2;
															IL_0b84_2:
															num5--;
															goto IL_1099_2;
															IL_0b97_2:
															if (5 >= b)
															{
																goto IL_0ba5_2;
															}
															goto IL_0cb6_2;
															IL_0ba5_2:
															if (5 > b)
															{
																goto IL_0bb3_2;
															}
															goto IL_0c3d_2;
															IL_0bb3_2:
															if (4 < b)
															{
																break;
															}
															goto IL_0bc1_2;
															IL_0bc1_2:
															if (4 > b)
															{
																break;
															}
															num = 216;
															goto IL_0bd8_2;
															IL_1038_2:
															ptr2 += 8;
															goto IL_1046_2;
															IL_0bd8_2:
															array2[num5] = 0;
															num = 42;
															goto IL_0bef_2;
															IL_0bef_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0c12_2;
															IL_0c12_2:
															array3[num5] = null;
															goto IL_0c1c_2;
															IL_0c1c_2:
															num5++;
															goto IL_0c2a_2;
															IL_0c2a_2:
															ptr2 += 8;
															goto IL_1099_2;
															IL_0c3d_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0c7d_2;
															IL_0c7d_2:
															array2[num5 - 2] = 0;
															num = 180;
															goto IL_0c9a_2;
															IL_0c9a_2:
															num5--;
															num = 169;
															goto IL_1099_2;
															IL_0cb6_2:
															if (6 < b)
															{
																break;
															}
															goto IL_0cc4_2;
															IL_0cc4_2:
															if (6 > b)
															{
																break;
															}
															num = 22;
															goto IL_0cdb_2;
															IL_1046_2:
															num5--;
															goto IL_1099_2;
															IL_0cdb_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0d1b_2;
															IL_0d1b_2:
															array2[num5 - 2] = 0;
															goto IL_0d2f_2;
															IL_0d2f_2:
															num5--;
															goto IL_1099_2;
															IL_0d42_2:
															if (10 >= b)
															{
																goto IL_0d50_2;
															}
															goto IL_0e8b_2;
															IL_0d50_2:
															if (10 > b)
															{
																goto IL_0d5e_2;
															}
															goto IL_0e0d_2;
															IL_0d5e_2:
															if (8 >= b)
															{
																goto IL_0d69_2;
															}
															goto IL_0d8a_2;
															IL_0d69_2:
															if (8 > b)
															{
																break;
															}
															goto IL_0d77_2;
															IL_0d77_2:
															num5--;
															goto IL_1099_2;
															IL_0d8a_2:
															if (9 < b)
															{
																break;
															}
															goto IL_0d98_2;
															IL_0d98_2:
															if (9 > b)
															{
																break;
															}
															goto IL_0da6_2;
															IL_0da6_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0de6_2;
															IL_0de6_2:
															array2[num5 - 2] = 0;
															goto IL_0dfa_2;
															IL_0dfa_2:
															num5--;
															goto IL_1099_2;
															IL_0e0d_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															num = 205;
															goto IL_0e78_2;
															IL_0e78_2:
															num5 -= 2;
															goto IL_1099_2;
															IL_0e8b_2:
															if (12 >= b)
															{
																goto IL_0e99_2;
															}
															goto IL_0f29_2;
															IL_0e99_2:
															if (12 <= b)
															{
																goto IL_1099_2;
															}
															goto IL_0ea7_2;
															IL_0ea7_2:
															if (11 < b)
															{
																break;
															}
															goto IL_0eb5_2;
															IL_0eb5_2:
															if (11 > b)
															{
																break;
															}
															goto IL_0ec3_2;
															IL_0ec3_2:
															array2[num5 - 1] = 0;
															goto IL_0ed7_2;
															IL_0ed7_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)SerializationMonkeyTYPEFLAGFDUAL[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
															goto IL_0f16_2;
															IL_0f16_2:
															ptr2 += 8;
															goto IL_1099_2;
															IL_0f29_2:
															if (13 < b)
															{
																break;
															}
															goto IL_0f37_2;
															IL_0f37_2:
															if (13 > b)
															{
																break;
															}
															goto IL_0f45_2;
														}
														break;
														IL_0489_2:;
													}
												}
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
												goto IL_106f_2;
												IL_107d_2:
												num5++;
												goto IL_108b_2;
												IL_108b_2:
												ptr2 += 8;
												goto IL_1099_2;
												IL_106f_2:
												array2[num5] = 0;
												goto IL_107d_2;
												continue;
												end_IL_0499_2:
												break;
											}
											continue;
											end_IL_04ac:
											break;
										}
										continue;
										end_IL_04bc:
										break;
									}
									break;
								}
								num = 167;
								return;
							}
							break;
						}
						continue;
						end_IL_0ffc:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe void method_0(int int_0)
	{
		int num = 25;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[8];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											object[] array6 = new object[1];
											num = 329;
											while (true)
											{
												array4[0] = int_0;
												while (true)
												{
													array6[0] = this;
													while (true)
													{
														byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ParseRecordBinaryObjectWithMapTyped.StackCrawlMarkHandleVBByValStrMarshaler);
														while (true)
														{
															byte* ptr2 = ptr;
															while (true)
															{
																if (num5 != 1)
																{
																	while (true)
																	{
																		byte b = *ptr2;
																		while (true)
																		{
																			ptr2++;
																			while (true)
																			{
																				IL_06ca:
																				if (b >= 1)
																				{
																					while (b <= 43)
																					{
																						while (true)
																						{
																							IL_06aa:
																							if (22 < b)
																							{
																								while (true)
																								{
																									IL_069a:
																									if (33 >= b)
																									{
																										while (true)
																										{
																											IL_068a:
																											if (33 > b)
																											{
																												while (true)
																												{
																													IL_067a:
																													if (27 >= b)
																													{
																														while (true)
																														{
																															IL_066d:
																															if (27 > b)
																															{
																																while (true)
																																{
																																	IL_065d:
																																	if (24 < b)
																																	{
																																		while (true)
																																		{
																																			IL_064d:
																																			if (25 >= b)
																																			{
																																				while (25 <= b)
																																				{
																																					while (true)
																																					{
																																						IL_05fa:
																																						array2[num6 - 1] = ((delegate*<Class200, Dictionary<int, float>>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Class200)array2[num6 - 1]);
																																						num = 374;
																																						while (true)
																																						{
																																							if (num != 374)
																																							{
																																								if (num != 1355)
																																								{
																																									break;
																																								}
																																								switch (num)
																																								{
																																								case 155:
																																								case 306:
																																									goto IL_05fa;
																																								case 338:
																																									goto IL_063d;
																																								case 81:
																																									goto IL_064d;
																																								case 253:
																																									goto IL_065d;
																																								case 225:
																																									goto IL_066d;
																																								case 66:
																																									goto IL_067a;
																																								case 341:
																																									goto IL_068a;
																																								case 274:
																																									goto IL_069a;
																																								case 334:
																																									goto IL_06aa;
																																								case 32:
																																									goto IL_06ba;
																																								case 314:
																																									goto IL_06ca;
																																								case 183:
																																									goto end_IL_06ca;
																																								case 266:
																																								case 354:
																																									goto end_IL_06da;
																																								case 71:
																																									goto IL_0700;
																																								case 17:
																																								case 83:
																																									goto IL_070b;
																																								case 113:
																																									goto IL_0724;
																																								case 79:
																																								case 178:
																																									goto IL_0740;
																																								case 255:
																																									goto IL_0783;
																																								case 280:
																																									goto IL_0793;
																																								case 286:
																																									goto IL_07ac;
																																								case 53:
																																									goto IL_07ba;
																																								case 11:
																																									goto IL_07c8;
																																								case 175:
																																									goto IL_07d3;
																																								case 38:
																																									goto IL_07e6;
																																								case 104:
																																									goto IL_07f1;
																																								case 106:
																																								case 223:
																																									goto IL_07ff;
																																								case 98:
																																									goto IL_0812;
																																								case 236:
																																									goto IL_081d;
																																								case 238:
																																									goto IL_082b;
																																								case 279:
																																									goto IL_083e;
																																								case 258:
																																									goto IL_0851;
																																								case 110:
																																									goto IL_085f;
																																								case 173:
																																									goto IL_086d;
																																								case 162:
																																									goto IL_0878;
																																								case 114:
																																								case 166:
																																									goto IL_0883;
																																								case 252:
																																									goto IL_089c;
																																								case 276:
																																									goto IL_08aa;
																																								case 128:
																																									goto IL_08b8;
																																								case 84:
																																									goto IL_08cb;
																																								case 67:
																																									goto IL_08de;
																																								case 117:
																																									goto IL_08ec;
																																								case 198:
																																									goto IL_08fa;
																																								case 154:
																																								case 260:
																																									goto IL_0908;
																																								case 138:
																																									goto IL_0949;
																																								case 139:
																																									goto IL_095d;
																																								case 229:
																																									goto IL_0979;
																																								case 222:
																																								case 267:
																																									goto IL_0987;
																																								case 273:
																																									goto IL_099f;
																																								case 22:
																																									goto IL_09ad;
																																								case 152:
																																									goto IL_09bb;
																																								case 131:
																																									goto IL_09c6;
																																								case 134:
																																								case 227:
																																									goto IL_09d4;
																																								case 272:
																																									goto IL_09ec;
																																								case 197:
																																									goto IL_09fa;
																																								case 172:
																																									goto IL_0a11;
																																								case 228:
																																									goto IL_0a24;
																																								case 257:
																																									goto IL_0a37;
																																								case 180:
																																									goto IL_0a45;
																																								case 100:
																																								case 209:
																																									goto IL_0a53;
																																								case 14:
																																									goto IL_0a70;
																																								case 185:
																																									goto IL_0ac3;
																																								case 141:
																																									goto IL_0ad1;
																																								case 151:
																																									goto IL_0ae4;
																																								case 20:
																																									goto IL_0af2;
																																								case 291:
																																									goto IL_0b05;
																																								case 3:
																																								case 33:
																																									goto IL_0b13;
																																								case 77:
																																									goto IL_0b4b;
																																								case 35:
																																									goto IL_0b5f;
																																								case 270:
																																								case 293:
																																									goto IL_0b72;
																																								case 146:
																																									goto IL_0bdd;
																																								case 294:
																																									goto IL_0bf0;
																																								case 296:
																																									goto IL_0c03;
																																								case 54:
																																								case 298:
																																									goto IL_0c47;
																																								case 60:
																																									goto IL_0c5b;
																																								case 127:
																																									goto IL_0caf;
																																								case 135:
																																									goto IL_0cbd;
																																								case 305:
																																									goto IL_0cd0;
																																								case 1:
																																									goto IL_0cdb;
																																								case 184:
																																								case 218:
																																									goto IL_0ce9;
																																								case 187:
																																									goto IL_0d29;
																																								case 69:
																																									goto IL_0d46;
																																								case 214:
																																									goto IL_0d59;
																																								case 58:
																																									goto IL_0d67;
																																								case 105:
																																								case 108:
																																									goto IL_0d75;
																																								case 278:
																																									goto IL_0db5;
																																								case 18:
																																								case 307:
																																									goto IL_0dce;
																																								case 284:
																																									goto IL_0e17;
																																								case 310:
																																									goto IL_0e30;
																																								case 315:
																																								case 325:
																																									goto IL_0e43;
																																								case 72:
																																									goto IL_0e57;
																																								case 149:
																																									goto IL_0e96;
																																								case 167:
																																								case 327:
																																									goto IL_0ea9;
																																								case 99:
																																									goto IL_0ecc;
																																								case 87:
																																									goto IL_0ee3;
																																								case 210:
																																									goto IL_0ef1;
																																								case 13:
																																								case 328:
																																									goto IL_0f04;
																																								case 94:
																																									goto IL_0f56;
																																								case 43:
																																								case 333:
																																									goto IL_0f69;
																																								case 224:
																																									goto IL_0f8b;
																																								case 89:
																																									goto IL_0f99;
																																								case 171:
																																									goto IL_0fa7;
																																								case 121:
																																								case 336:
																																									goto IL_0fba;
																																								case 82:
																																									goto IL_0ffa;
																																								case 88:
																																									goto IL_1017;
																																								case 344:
																																									goto IL_102a;
																																								case 302:
																																									goto IL_1038;
																																								case 103:
																																								case 300:
																																									goto IL_1043;
																																								case 309:
																																									goto IL_1083;
																																								case 4:
																																									goto IL_1097;
																																								case 41:
																																									goto IL_10aa;
																																								case 95:
																																									goto IL_10c1;
																																								case 74:
																																								case 237:
																																									goto IL_10cf;
																																								case 321:
																																									goto IL_10f1;
																																								case 86:
																																									goto IL_10ff;
																																								case 207:
																																									goto IL_110d;
																																								case 353:
																																									goto IL_1120;
																																								case 133:
																																									goto IL_112b;
																																								case 62:
																																									goto IL_1139;
																																								case 23:
																																								case 295:
																																									goto IL_1147;
																																								case 308:
																																									goto IL_1155;
																																								case 163:
																																									goto IL_1178;
																																								case 115:
																																									goto IL_1187;
																																								case 44:
																																								case 221:
																																									goto IL_1195;
																																								case 75:
																																									goto IL_11c7;
																																								case 124:
																																									goto IL_11d5;
																																								case 356:
																																									goto IL_11e8;
																																								case 359:
																																									goto IL_11fb;
																																								case 362:
																																									goto IL_120e;
																																								case 8:
																																								case 96:
																																									goto IL_121c;
																																								case 230:
																																									goto IL_125c;
																																								case 297:
																																									goto IL_1270;
																																								case 363:
																																									goto IL_1283;
																																								case 346:
																																									goto IL_129a;
																																								case 367:
																																									goto IL_12ad;
																																								case 7:
																																									goto IL_12d4;
																																								case 140:
																																									goto IL_12e7;
																																								case 101:
																																									goto IL_12f5;
																																								case 19:
																																								case 150:
																																									goto IL_1303;
																																								case 262:
																																									goto IL_1317;
																																								case 136:
																																									goto IL_1356;
																																								case 215:
																																									goto IL_1372;
																																								case 160:
																																									goto IL_1380;
																																								case 111:
																																								case 196:
																																									goto IL_1394;
																																								case 268:
																																									goto IL_13d4;
																																								case 176:
																																									goto IL_13e8;
																																								case 277:
																																									goto IL_13fb;
																																								case 282:
																																									goto IL_1409;
																																								case 145:
																																								case 349:
																																									goto IL_1417;
																																								case 261:
																																									goto IL_142b;
																																								case 181:
																																									goto IL_147e;
																																								case 355:
																																									goto IL_148c;
																																								case 164:
																																									goto IL_149f;
																																								case 361:
																																									goto IL_14ad;
																																								case 27:
																																								case 109:
																																									goto IL_14bb;
																																								case 318:
																																									goto IL_14cf;
																																								case 26:
																																									goto IL_150e;
																																								case 90:
																																									goto IL_1521;
																																								case 65:
																																									goto IL_152c;
																																								case 30:
																																								case 40:
																																									goto IL_153a;
																																								case 364:
																																									goto IL_1548;
																																								case 12:
																																									goto IL_155b;
																																								case 76:
																																									goto IL_1569;
																																								case 360:
																																									goto IL_157c;
																																								case 61:
																																									goto IL_158a;
																																								case 46:
																																								case 157:
																																									goto IL_1598;
																																								case 37:
																																									goto IL_15b5;
																																								case 271:
																																									goto IL_164e;
																																								case 165:
																																									goto IL_165c;
																																								case 203:
																																								case 348:
																																									goto IL_166f;
																																								case 179:
																																									goto IL_168d;
																																								case 211:
																																									goto IL_169b;
																																								case 290:
																																									goto IL_16a9;
																																								case 345:
																																									goto IL_16c5;
																																								case 57:
																																									goto IL_16d3;
																																								case 335:
																																									goto IL_16e1;
																																								case 148:
																																								case 213:
																																									goto IL_16ec;
																																								case 85:
																																									goto IL_1700;
																																								case 200:
																																									goto IL_173f;
																																								case 50:
																																									goto IL_1752;
																																								case 337:
																																									goto IL_175d;
																																								case 36:
																																								case 107:
																																									goto IL_176b;
																																								case 177:
																																									goto IL_17a3;
																																								case 365:
																																									goto IL_17b7;
																																								case 259:
																																									goto IL_17ca;
																																								case 275:
																																									goto IL_17d8;
																																								case 56:
																																								case 301:
																																									goto IL_17ef;
																																								case 320:
																																									goto IL_1803;
																																								case 143:
																																									goto IL_1856;
																																								case 204:
																																									goto IL_1864;
																																								case 31:
																																									goto IL_1877;
																																								case 21:
																																									goto end_IL_05e7;
																																								case 112:
																																								case 245:
																																									goto IL_1890;
																																								case 130:
																																									goto IL_18ac;
																																								case 122:
																																									goto IL_18ba;
																																								case 351:
																																									goto IL_18d6;
																																								case 191:
																																								case 303:
																																									goto IL_18e1;
																																								case 246:
																																									goto IL_18f5;
																																								case 147:
																																									goto IL_1934;
																																								case 129:
																																									goto IL_1947;
																																								case 312:
																																									goto IL_1955;
																																								case 6:
																																								case 202:
																																									goto IL_1963;
																																								case 42:
																																									goto IL_1980;
																																								case 256:
																																									goto IL_19d6;
																																								case 324:
																																									goto IL_19e4;
																																								case 319:
																																									goto IL_19f7;
																																								case 243:
																																									goto IL_1a05;
																																								case 269:
																																								case 339:
																																									goto IL_1a13;
																																								case 287:
																																									goto IL_1a1d;
																																								case 242:
																																									goto IL_1a2b;
																																								case 144:
																																									goto IL_1a3e;
																																								case 208:
																																									goto IL_1a49;
																																								case 156:
																																								case 254:
																																									goto IL_1a57;
																																								case 205:
																																									goto IL_1a6b;
																																								case 70:
																																									goto IL_1aaa;
																																								case 240:
																																									goto IL_1abd;
																																								case 186:
																																									goto IL_1ac8;
																																								case 29:
																																								case 132:
																																									goto IL_1ad3;
																																								case 161:
																																									goto IL_1b05;
																																								case 63:
																																									goto IL_1b13;
																																								case 0:
																																								case 5:
																																								case 9:
																																								case 10:
																																								case 15:
																																								case 16:
																																								case 28:
																																								case 34:
																																								case 39:
																																								case 45:
																																								case 48:
																																								case 51:
																																								case 52:
																																								case 59:
																																								case 68:
																																								case 73:
																																								case 93:
																																								case 102:
																																								case 116:
																																								case 119:
																																								case 137:
																																								case 168:
																																								case 170:
																																								case 189:
																																								case 194:
																																								case 195:
																																								case 206:
																																								case 212:
																																								case 217:
																																								case 219:
																																								case 235:
																																								case 247:
																																								case 248:
																																								case 264:
																																								case 285:
																																								case 289:
																																								case 299:
																																								case 311:
																																								case 316:
																																								case 322:
																																								case 323:
																																								case 326:
																																								case 342:
																																								case 347:
																																								case 352:
																																								case 358:
																																									goto end_IL_063d;
																																								case 2:
																																								case 47:
																																								case 49:
																																								case 55:
																																								case 64:
																																								case 80:
																																								case 92:
																																								case 97:
																																								case 118:
																																								case 123:
																																								case 125:
																																								case 126:
																																								case 142:
																																								case 153:
																																								case 158:
																																								case 159:
																																								case 169:
																																								case 174:
																																								case 182:
																																								case 190:
																																								case 192:
																																								case 193:
																																								case 216:
																																								case 220:
																																								case 226:
																																								case 232:
																																								case 233:
																																								case 239:
																																								case 241:
																																								case 244:
																																								case 249:
																																								case 250:
																																								case 251:
																																								case 263:
																																								case 265:
																																								case 283:
																																								case 288:
																																								case 292:
																																								case 304:
																																								case 313:
																																								case 330:
																																								case 332:
																																								case 343:
																																								case 350:
																																								case 357:
																																								case 366:
																																									goto end_IL_06ea;
																																								case 201:
																																									goto end_IL_1b3f;
																																								case 231:
																																									goto end_IL_1b52;
																																								case 331:
																																									goto end_IL_1b5c;
																																								case 329:
																																									goto end_IL_1b67;
																																								case 120:
																																									goto end_IL_1b77;
																																								case 188:
																																									goto end_IL_1b8c;
																																								case 78:
																																									goto end_IL_1ba5;
																																								case 91:
																																									goto end_IL_1bb5;
																																								case 199:
																																									goto end_IL_1bc5;
																																								case 340:
																																									goto end_IL_1bd5;
																																								case 281:
																																									goto end_IL_1be5;
																																								case 24:
																																									goto end_IL_1bf5;
																																								case 25:
																																									goto end_IL_1c05;
																																								case 234:
																																								case 317:
																																									return;
																																								}
																																								continue;
																																							}
																																							array[num6 - 1] = 5;
																																							goto IL_12d4;
																																							IL_12d4:
																																							ptr2 += 8;
																																							goto end_IL_06ea;
																																							continue;
																																							end_IL_05e7:
																																							break;
																																						}
																																						break;
																																					}
																																					goto IL_1882;
																																					continue;
																																					end_IL_063d:
																																					break;
																																					IL_063d:;
																																				}
																																				break;
																																			}
																																			goto IL_12e7;
																																			IL_1356:
																																			ptr2 += 8;
																																			num = 232;
																																			goto end_IL_06ea;
																																			IL_12e7:
																																			if (26 < b)
																																			{
																																				break;
																																			}
																																			goto IL_12f5;
																																			IL_12f5:
																																			if (26 > b)
																																			{
																																				break;
																																			}
																																			goto IL_1303;
																																			IL_1303:
																																			array[num6 - 1] = 3;
																																			goto IL_1317;
																																			IL_1317:
																																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																																			goto IL_1356;
																																		}
																																		break;
																																	}
																																	goto IL_0700;
																																	IL_125c:
																																	array[num6 - 2] = 3;
																																	goto IL_1270;
																																	IL_0700:
																																	if (24 <= b)
																																	{
																																		goto IL_070b;
																																	}
																																	goto IL_0724;
																																	IL_070b:
																																	array[num6 - 1] = 0;
																																	goto IL_0c03;
																																	IL_0c03:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																																	goto IL_0e30;
																																	IL_0e30:
																																	ptr2 += 8;
																																	goto end_IL_06ea;
																																	IL_0724:
																																	if (23 < b)
																																	{
																																		break;
																																	}
																																	num = 362;
																																	goto IL_120e;
																																	IL_1270:
																																	num6--;
																																	goto end_IL_06ea;
																																	IL_120e:
																																	if (23 > b)
																																	{
																																		break;
																																	}
																																	goto IL_121c;
																																	IL_121c:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																	goto IL_125c;
																																}
																																break;
																															}
																															num = 178;
																															goto IL_0740;
																															IL_0793:
																															array[num6 - 1] = 5;
																															goto IL_11e8;
																															IL_11e8:
																															ptr2 += 8;
																															goto end_IL_06ea;
																															IL_0740:
																															array2[num6 - 1] = ((delegate*<Class200, Dictionary<int, GameObject>>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Class200)array2[num6 - 1]);
																															num = 280;
																															goto IL_0793;
																														}
																														break;
																													}
																													goto IL_1372;
																													IL_164e:
																													num6 -= 2;
																													goto IL_165c;
																													IL_1372:
																													if (30 >= b)
																													{
																														goto IL_1380;
																													}
																													goto IL_1521;
																													IL_1380:
																													if (30 <= b)
																													{
																														num = 196;
																														goto IL_1394;
																													}
																													goto IL_13fb;
																													IL_165c:
																													ptr2 += 8;
																													goto end_IL_06ea;
																													IL_1394:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																													goto IL_13d4;
																													IL_13d4:
																													array[num6 - 2] = 3;
																													goto IL_13e8;
																													IL_13e8:
																													num6--;
																													goto end_IL_06ea;
																													IL_13fb:
																													if (28 >= b)
																													{
																														goto IL_1409;
																													}
																													goto IL_149f;
																													IL_1409:
																													if (28 > b)
																													{
																														break;
																													}
																													goto IL_1417;
																													IL_1417:
																													array[num6 - 2] = 0;
																													goto IL_142b;
																													IL_142b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<Dictionary<int, GameObject>, int, bool>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Dictionary<int, GameObject>)array2[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																													goto IL_147e;
																													IL_147e:
																													num6--;
																													goto IL_148c;
																													IL_148c:
																													ptr2 += 8;
																													goto end_IL_06ea;
																													IL_149f:
																													if (29 < b)
																													{
																														break;
																													}
																													goto IL_14ad;
																													IL_14ad:
																													if (29 > b)
																													{
																														break;
																													}
																													goto IL_14bb;
																													IL_14bb:
																													array[num6 - 1] = 3;
																													goto IL_14cf;
																													IL_14cf:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																													goto IL_150e;
																													IL_150e:
																													ptr2 += 8;
																													goto end_IL_06ea;
																													IL_1521:
																													if (31 >= b)
																													{
																														goto IL_152c;
																													}
																													goto IL_157c;
																													IL_152c:
																													if (31 > b)
																													{
																														break;
																													}
																													goto IL_153a;
																													IL_153a:
																													array[num6] = 15;
																													goto IL_1548;
																													IL_1548:
																													array3[num6] = *(int*)(ptr2 + num3);
																													goto IL_155b;
																													IL_155b:
																													ptr2 += 8;
																													goto IL_1569;
																													IL_1569:
																													num6++;
																													goto end_IL_06ea;
																													IL_157c:
																													if (32 < b)
																													{
																														break;
																													}
																													goto IL_158a;
																													IL_158a:
																													if (32 > b)
																													{
																														break;
																													}
																													goto IL_1598;
																													IL_1598:
																													array[num6 - 3] = 0;
																													num = 37;
																													goto IL_15b5;
																													IL_15b5:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 3]) = (((delegate*<Dictionary<int, GameObject>, int, ref GameObject, bool>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Dictionary<int, GameObject>)array2[num6 - 3], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]), ref ((delegate*<object, IntPtr, object[], int[], ref GameObject>)ReadOnlyArrayAttributeTypeLibrary[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4)) ? 1 : 0);
																													goto IL_164e;
																												}
																												break;
																											}
																											goto IL_166f;
																											IL_16a9:
																											ptr2 += 8;
																											num = 332;
																											goto end_IL_06ea;
																											IL_166f:
																											array2[num6] = ((delegate*<GameObject>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])();
																											goto IL_168d;
																											IL_168d:
																											array[num6] = 5;
																											goto IL_169b;
																											IL_169b:
																											num6++;
																											goto IL_16a9;
																										}
																										break;
																									}
																									goto IL_16c5;
																									IL_1ad3:
																									((delegate*<UnityEngine.Object, void>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																									num = 161;
																									goto IL_1b05;
																									IL_16c5:
																									if (38 < b)
																									{
																										goto IL_16d3;
																									}
																									num = 351;
																									goto IL_18d6;
																									IL_16d3:
																									if (41 >= b)
																									{
																										goto IL_16e1;
																									}
																									goto IL_1877;
																									IL_16e1:
																									if (41 <= b)
																									{
																										goto IL_16ec;
																									}
																									goto IL_1752;
																									IL_16ec:
																									array[num6 - 1] = 3;
																									goto IL_1700;
																									IL_1700:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									goto IL_173f;
																									IL_173f:
																									ptr2 += 8;
																									goto end_IL_06ea;
																									IL_1752:
																									if (39 >= b)
																									{
																										goto IL_175d;
																									}
																									goto IL_17ca;
																									IL_175d:
																									if (39 > b)
																									{
																										break;
																									}
																									goto IL_176b;
																									IL_176b:
																									array2[num6 - 1] = ((delegate*<Class200, Dictionary<int, bool>>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Class200)array2[num6 - 1]);
																									goto IL_17a3;
																									IL_17a3:
																									array[num6 - 1] = 5;
																									goto IL_17b7;
																									IL_17b7:
																									ptr2 += 8;
																									goto end_IL_06ea;
																									IL_17ca:
																									if (40 < b)
																									{
																										break;
																									}
																									goto IL_17d8;
																									IL_17d8:
																									if (40 > b)
																									{
																										break;
																									}
																									num = 301;
																									goto IL_17ef;
																									IL_1b13:
																									ptr2 += 8;
																									goto end_IL_06ea;
																									IL_17ef:
																									array[num6 - 2] = 0;
																									goto IL_1803;
																									IL_1803:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<Dictionary<int, bool>, int, bool>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Dictionary<int, bool>)array2[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																									goto IL_1856;
																									IL_1856:
																									num6--;
																									goto IL_1864;
																									IL_1864:
																									ptr2 += 8;
																									goto end_IL_06ea;
																									IL_1877:
																									if (42 >= b)
																									{
																										goto IL_1882;
																									}
																									goto IL_18ac;
																									IL_1882:
																									if (42 > b)
																									{
																										break;
																									}
																									goto IL_1890;
																									IL_1890:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									goto end_IL_06ea;
																									IL_18ac:
																									if (43 < b)
																									{
																										break;
																									}
																									goto IL_18ba;
																									IL_18ba:
																									if (43 > b)
																									{
																									}
																									break;
																									IL_1b05:
																									num6--;
																									goto IL_1b13;
																									IL_18d6:
																									if (38 <= b)
																									{
																										goto IL_18e1;
																									}
																									goto IL_1947;
																									IL_18e1:
																									array[num6 - 1] = 3;
																									goto IL_18f5;
																									IL_18f5:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									goto IL_1934;
																									IL_1934:
																									ptr2 += 8;
																									goto end_IL_06ea;
																									IL_1947:
																									if (35 >= b)
																									{
																										goto IL_1955;
																									}
																									goto IL_1a3e;
																									IL_1955:
																									if (35 <= b)
																									{
																										goto IL_1963;
																									}
																									goto IL_19f7;
																									IL_1963:
																									array[num6 - 2] = 0;
																									num = 42;
																									goto IL_1980;
																									IL_1980:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																									num = 256;
																									goto IL_19d6;
																									IL_19d6:
																									num6--;
																									goto IL_19e4;
																									IL_19e4:
																									ptr2 += 8;
																									goto end_IL_06ea;
																									IL_19f7:
																									if (34 < b)
																									{
																										break;
																									}
																									goto IL_1a05;
																									IL_1a05:
																									if (34 > b)
																									{
																										break;
																									}
																									goto IL_1a13;
																									IL_1a13:
																									array2[num6] = null;
																									goto IL_1a1d;
																									IL_1a1d:
																									array[num6] = 5;
																									goto IL_1a2b;
																									IL_1a2b:
																									num6++;
																									goto end_IL_06ea;
																									IL_1a3e:
																									if (36 >= b)
																									{
																										goto IL_1a49;
																									}
																									goto IL_1abd;
																									IL_1a49:
																									if (36 > b)
																									{
																										break;
																									}
																									goto IL_1a57;
																									IL_1a57:
																									array[num6 - 1] = 3;
																									goto IL_1a6b;
																									IL_1a6b:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									goto IL_1aaa;
																									IL_1aaa:
																									ptr2 += 8;
																									goto end_IL_06ea;
																									IL_1abd:
																									if (37 < b)
																									{
																										break;
																									}
																									goto IL_1ac8;
																									IL_1ac8:
																									if (37 > b)
																									{
																										break;
																									}
																									goto IL_1ad3;
																								}
																								break;
																							}
																							goto IL_0783;
																							IL_0f8b:
																							array[num6] = 3;
																							goto IL_0f99;
																							IL_0783:
																							if (22 > b)
																							{
																								goto IL_07ac;
																							}
																							goto IL_0e43;
																							IL_0e43:
																							array[num6 - 1] = 3;
																							goto IL_0e57;
																							IL_0e57:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_0e96;
																							IL_0e96:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_07ac:
																							if (11 >= b)
																							{
																								goto IL_07ba;
																							}
																							goto IL_0851;
																							IL_07ba:
																							if (11 > b)
																							{
																								goto IL_07c8;
																							}
																							goto IL_0c47;
																							IL_07c8:
																							if (5 >= b)
																							{
																								goto IL_07d3;
																							}
																							goto IL_07e6;
																							IL_07d3:
																							if (5 <= b)
																							{
																								goto IL_0fba;
																							}
																							goto IL_102a;
																							IL_0fba:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0ffa;
																							IL_0ffa:
																							array[num6 - 2] = 0;
																							num = 88;
																							goto IL_1017;
																							IL_1017:
																							num6--;
																							goto end_IL_06ea;
																							IL_102a:
																							if (2 >= b)
																							{
																								goto IL_1038;
																							}
																							goto IL_1120;
																							IL_1038:
																							if (2 <= b)
																							{
																								goto IL_1043;
																							}
																							goto IL_10aa;
																							IL_1043:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_1083;
																							IL_1083:
																							array[num6 - 2] = 0;
																							goto IL_1097;
																							IL_1097:
																							num6--;
																							goto end_IL_06ea;
																							IL_10aa:
																							if (1 < b)
																							{
																								break;
																							}
																							num = 95;
																							goto IL_10c1;
																							IL_0f99:
																							num6++;
																							goto IL_0fa7;
																							IL_10c1:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_10cf;
																							IL_10cf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																							num = 321;
																							goto IL_10f1;
																							IL_10f1:
																							array[num6] = 0;
																							goto IL_10ff;
																							IL_10ff:
																							num6++;
																							goto IL_110d;
																							IL_110d:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_1120:
																							if (3 < b)
																							{
																								goto IL_112b;
																							}
																							goto IL_1187;
																							IL_112b:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_1139;
																							IL_1139:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_1147;
																							IL_1147:
																							array[num6] = 0;
																							goto IL_1155;
																							IL_1155:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																							goto IL_1178;
																							IL_1178:
																							array2[num6] = null;
																							goto IL_1283;
																							IL_1283:
																							num6++;
																							num = 346;
																							goto IL_129a;
																							IL_129a:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_1187:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_1195;
																							IL_1195:
																							ref int reference = ref array4[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							num = 75;
																							goto IL_11c7;
																							IL_11c7:
																							ptr2 += 8;
																							goto IL_11d5;
																							IL_11d5:
																							num6--;
																							goto end_IL_06ea;
																							IL_07e6:
																							if (8 >= b)
																							{
																								goto IL_07f1;
																							}
																							goto IL_0812;
																							IL_07f1:
																							if (8 <= b)
																							{
																								goto IL_07ff;
																							}
																							goto IL_0cd0;
																							IL_07ff:
																							num6--;
																							goto end_IL_06ea;
																							IL_0cd0:
																							if (6 >= b)
																							{
																								goto IL_0cdb;
																							}
																							goto IL_0d59;
																							IL_0cdb:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_0ce9;
																							IL_0ce9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0d29;
																							IL_0d29:
																							array[num6 - 2] = 0;
																							num = 69;
																							goto IL_0d46;
																							IL_0d46:
																							num6--;
																							goto end_IL_06ea;
																							IL_0d59:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0d67;
																							IL_0d67:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0d75;
																							IL_0d75:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0db5;
																							IL_0db5:
																							array[num6 - 2] = 0;
																							goto IL_11fb;
																							IL_11fb:
																							num6--;
																							goto end_IL_06ea;
																							IL_0812:
																							if (9 < b)
																							{
																								goto IL_081d;
																							}
																							goto IL_083e;
																							IL_081d:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_082b;
																							IL_082b:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0b72;
																							IL_0b72:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 146;
																							goto IL_0bdd;
																							IL_0bdd:
																							num6 -= 2;
																							goto end_IL_06ea;
																							IL_083e:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0dce;
																							IL_0dce:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							num = 284;
																							goto IL_0e17;
																							IL_0e17:
																							array[num6 - 2] = 0;
																							goto IL_12ad;
																							IL_12ad:
																							num6--;
																							goto end_IL_06ea;
																							IL_0c47:
																							array[num6 - 2] = 0;
																							goto IL_0c5b;
																							IL_0c5b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<int, int, int>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_0caf;
																							IL_0caf:
																							num6--;
																							goto IL_0cbd;
																							IL_0cbd:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_0851:
																							if (16 >= b)
																							{
																								goto IL_085f;
																							}
																							goto IL_099f;
																							IL_085f:
																							if (16 > b)
																							{
																								goto IL_086d;
																							}
																							goto IL_0f04;
																							IL_086d:
																							if (13 >= b)
																							{
																								goto IL_0878;
																							}
																							goto IL_08de;
																							IL_0878:
																							if (13 <= b)
																							{
																								goto IL_0883;
																							}
																							goto IL_08cb;
																							IL_0883:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																							goto IL_089c;
																							IL_089c:
																							array[num6] = 1;
																							goto IL_08aa;
																							IL_08aa:
																							num6++;
																							goto IL_08b8;
																							IL_08b8:
																							ptr2 += 16;
																							goto end_IL_06ea;
																							IL_08cb:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_0bf0;
																							IL_0bf0:
																							if (12 > b)
																							{
																								break;
																							}
																							goto end_IL_06ea;
																							IL_08de:
																							if (14 < b)
																							{
																								goto IL_08ec;
																							}
																							num = 229;
																							goto IL_0979;
																							IL_08ec:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_08fa;
																							IL_08fa:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_0908;
																							IL_0908:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																							goto IL_0949;
																							IL_0949:
																							array[num6 - 2] = 0;
																							goto IL_095d;
																							IL_095d:
																							num6--;
																							goto end_IL_06ea;
																							IL_0fa7:
																							ptr2 += 16;
																							goto end_IL_06ea;
																							IL_0979:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_0987;
																							IL_0987:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_06ea;
																							IL_0f04:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0f56;
																							IL_0f56:
																							num6--;
																							goto end_IL_06ea;
																							IL_099f:
																							if (19 >= b)
																							{
																								goto IL_09ad;
																							}
																							goto IL_0a37;
																							IL_09ad:
																							if (19 > b)
																							{
																								goto IL_09bb;
																							}
																							goto IL_0ea9;
																							IL_09bb:
																							if (17 >= b)
																							{
																								goto IL_09c6;
																							}
																							goto IL_0a24;
																							IL_09c6:
																							if (17 > b)
																							{
																								break;
																							}
																							goto IL_09d4;
																							IL_09d4:
																							array2[num6] = array6[*(int*)(ptr2 + num3)];
																							goto IL_09ec;
																							IL_09ec:
																							array[num6] = 5;
																							goto IL_09fa;
																							IL_09fa:
																							num6++;
																							num = 172;
																							goto IL_0a11;
																							IL_0a11:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_0a24:
																							if (18 < b)
																							{
																								break;
																							}
																							goto IL_0b05;
																							IL_0b05:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0b13;
																							IL_0b13:
																							array2[num6 - 1] = ((delegate*<Class200, Dictionary<int, float>>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Class200)array2[num6 - 1]);
																							goto IL_0b4b;
																							IL_0b4b:
																							array[num6 - 1] = 5;
																							goto IL_0b5f;
																							IL_0b5f:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_0ea9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																							goto IL_0ecc;
																							IL_0ecc:
																							array[num6] = 0;
																							num = 87;
																							goto IL_0ee3;
																							IL_0ee3:
																							num6++;
																							goto IL_0ef1;
																							IL_0ef1:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_0a37:
																							if (20 >= b)
																							{
																								goto IL_0a45;
																							}
																							goto IL_0ae4;
																							IL_0a45:
																							if (20 > b)
																							{
																								break;
																							}
																							goto IL_0a53;
																							IL_0a53:
																							array[num6 - 2] = 0;
																							num = 14;
																							goto IL_0a70;
																							IL_0a70:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<Dictionary<int, float>, int, bool>)ReadOnlyArrayAttributeTypeLibrary[*(int*)(ptr2 + num3)])((Dictionary<int, float>)array2[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																							goto IL_0ac3;
																							IL_0ac3:
																							num6--;
																							goto IL_0ad1;
																							IL_0ad1:
																							ptr2 += 8;
																							goto end_IL_06ea;
																							IL_0ae4:
																							if (21 < b)
																							{
																								break;
																							}
																							goto IL_0af2;
																							IL_0af2:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_0f69;
																							IL_0f69:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(double*)(ptr2 + num4);
																							num = 224;
																							goto IL_0f8b;
																						}
																						break;
																						IL_06ba:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 97;
																				goto end_IL_06ea;
																				continue;
																				end_IL_06ca:
																				break;
																			}
																			continue;
																			end_IL_06da:
																			break;
																		}
																		continue;
																		end_IL_06ea:
																		break;
																	}
																	continue;
																}
																num = 317;
																return;
																continue;
																end_IL_1b3f:
																break;
															}
															continue;
															end_IL_1b52:
															break;
														}
														continue;
														end_IL_1b5c:
														break;
													}
													continue;
													end_IL_1b67:
													break;
												}
												continue;
												end_IL_1b77:
												break;
											}
											continue;
											end_IL_1b8c:
											break;
										}
										continue;
										end_IL_1ba5:
										break;
									}
									continue;
									end_IL_1bb5:
									break;
								}
								continue;
								end_IL_1bc5:
								break;
							}
							continue;
							end_IL_1bd5:
							break;
						}
						continue;
						end_IL_1be5:
						break;
					}
					continue;
					end_IL_1bf5:
					break;
				}
				continue;
				end_IL_1c05:
				break;
			}
		}
	}

	private unsafe void OnEnable()
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				IL_005c:
				int num3 = 0;
				while (true)
				{
					IL_004e:
					num3 = 0;
					num = 14;
					while (true)
					{
						if (num != 14)
						{
							if (num != 995)
							{
								break;
							}
							switch (num)
							{
							case 0:
								goto IL_004e;
							case 5:
								goto IL_005c;
							case 6:
								goto end_IL_0041;
							case 3:
								goto IL_0066;
							case 7:
								goto IL_0085;
							case 4:
								goto IL_008a;
							case 1:
							case 2:
								return;
							}
							continue;
						}
						goto IL_0085;
						IL_008a:
						num3 = 0;
						return;
						IL_0066:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, void>)ResourceTypeIdIntSizeTYPEFLAGFAGGREGATABLE[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10);
						goto IL_0085;
						IL_0085:
						if (num3 != 3)
						{
							goto IL_0066;
						}
						goto IL_008a;
						continue;
						end_IL_0041:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe static int smethod_0(int int_0)
	{
		int num = 47;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 59;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsSubsetOfPathDiscoveryVARFLAGFHIDDEN.CharLeave);
											num = 89;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 9;
																while (true)
																{
																	IL_02b1:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0291:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0281:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0274:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0264:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_0234:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_020f:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_01fa:
																																array2[num5] = null;
																																num = 118;
																																while (true)
																																{
																																	if (num != 118)
																																	{
																																		if (num != 1099)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 29:
																																			goto IL_01fa;
																																		case 56:
																																			goto IL_020f;
																																		case 1:
																																		case 34:
																																			goto IL_0234;
																																		case 32:
																																			goto IL_0244;
																																		case 93:
																																		case 104:
																																			goto IL_0254;
																																		case 75:
																																			goto IL_0264;
																																		case 109:
																																			goto IL_0274;
																																		case 25:
																																			goto IL_0281;
																																		case 103:
																																			goto IL_0291;
																																		case 39:
																																			goto IL_02a1;
																																		case 9:
																																			goto IL_02b1;
																																		case 86:
																																			goto end_IL_02b1;
																																		case 8:
																																		case 91:
																																			goto end_IL_02c1;
																																		case 49:
																																			goto IL_02e5;
																																		case 0:
																																		case 71:
																																			goto IL_02f3;
																																		case 31:
																																			goto IL_0301;
																																		case 42:
																																		case 72:
																																			goto IL_0314;
																																		case 27:
																																			goto IL_0354;
																																		case 95:
																																			goto IL_0368;
																																		case 50:
																																		case 101:
																																			goto IL_037b;
																																		case 58:
																																		case 102:
																																			goto IL_0393;
																																		case 73:
																																			goto IL_03a1;
																																		case 15:
																																		case 41:
																																			goto IL_03ac;
																																		case 4:
																																			goto IL_040e;
																																		case 44:
																																			goto IL_0421;
																																		case 53:
																																			goto IL_042c;
																																		case 52:
																																		case 54:
																																			goto IL_043a;
																																		case 97:
																																			goto IL_047a;
																																		case 3:
																																			goto IL_048e;
																																		case 30:
																																			goto IL_04a1;
																																		case 67:
																																			goto IL_04af;
																																		case 7:
																																		case 22:
																																			goto IL_04bd;
																																		case 63:
																																			goto IL_04e0;
																																		case 76:
																																			goto IL_04ee;
																																		case 36:
																																		case 40:
																																			goto IL_0501;
																																		case 68:
																																			goto IL_050c;
																																		case 28:
																																			goto IL_051a;
																																		case 66:
																																			goto IL_0536;
																																		case 13:
																																		case 74:
																																			goto IL_0544;
																																		case 61:
																																		case 106:
																																			goto IL_0560;
																																		case 99:
																																			goto IL_0579;
																																		case 107:
																																			goto IL_0589;
																																		case 64:
																																		case 108:
																																			goto IL_059c;
																																		case 69:
																																			goto IL_05aa;
																																		case 19:
																																		case 55:
																																			goto IL_05b8;
																																		case 87:
																																			goto IL_05e1;
																																		case 65:
																																			goto IL_05ef;
																																		case 110:
																																			goto IL_05ff;
																																		case 96:
																																			goto IL_060d;
																																		case 70:
																																			goto IL_062b;
																																		case 88:
																																			goto IL_063b;
																																		case 2:
																																		case 11:
																																		case 17:
																																		case 23:
																																		case 24:
																																		case 26:
																																		case 45:
																																		case 48:
																																		case 57:
																																		case 60:
																																		case 79:
																																		case 80:
																																		case 83:
																																		case 85:
																																		case 90:
																																		case 92:
																																		case 94:
																																		case 98:
																																		case 100:
																																			goto end_IL_01e7;
																																		case 6:
																																		case 12:
																																		case 18:
																																		case 20:
																																		case 21:
																																		case 37:
																																		case 38:
																																		case 51:
																																		case 62:
																																		case 81:
																																		case 82:
																																		case 84:
																																		case 105:
																																		case 111:
																																			goto end_IL_02da;
																																		case 89:
																																			goto end_IL_0659;
																																		case 43:
																																			goto end_IL_066c;
																																		case 16:
																																			goto end_IL_0676;
																																		case 78:
																																			goto end_IL_068a;
																																		case 59:
																																			goto end_IL_069f;
																																		case 35:
																																			goto end_IL_06af;
																																		case 10:
																																			goto end_IL_06bf;
																																		case 14:
																																		case 33:
																																			goto end_IL_06ca;
																																		case 46:
																																			goto end_IL_06da;
																																		case 47:
																																			goto end_IL_06ea;
																																		case 5:
																																		case 77:
																																			goto IL_0705;
																																		}
																																		continue;
																																	}
																																	num5++;
																																	goto IL_062b;
																																	IL_062b:
																																	ptr2 += 8;
																																	goto end_IL_02da;
																																	continue;
																																	end_IL_01e7:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																													IL_0244:;
																												}
																												break;
																												IL_0254:;
																											}
																											break;
																										}
																										goto IL_063b;
																										IL_063b:
																										if (4 <= b)
																										{
																											goto end_IL_02da;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02e5;
																								IL_037b:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02da;
																								IL_02e5:
																								if (3 > b)
																								{
																									goto IL_02f3;
																								}
																								goto IL_037b;
																								IL_02f3:
																								if (1 >= b)
																								{
																									goto IL_0301;
																								}
																								goto IL_059c;
																								IL_0301:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0560;
																								IL_0560:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0579;
																								IL_0579:
																								array[num5] = 0;
																								goto IL_05ff;
																								IL_05ff:
																								num5++;
																								goto IL_060d;
																								IL_060d:
																								ptr2 += 8;
																								goto end_IL_02da;
																								IL_059c:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_05aa;
																								IL_05aa:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_05b8;
																								IL_05b8:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05e1;
																								IL_05e1:
																								ptr2 += 8;
																								goto IL_05ef;
																								IL_05ef:
																								num5--;
																								goto end_IL_02da;
																							}
																							break;
																						}
																						goto IL_0314;
																						IL_0368:
																						num5--;
																						goto end_IL_02da;
																						IL_0314:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0354;
																						IL_0354:
																						array[num5 - 2] = 0;
																						goto IL_0368;
																					}
																					break;
																				}
																				goto IL_0393;
																				IL_0536:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0544;
																				IL_0393:
																				if (9 >= b)
																				{
																					goto IL_03a1;
																				}
																				goto IL_0501;
																				IL_03a1:
																				if (9 <= b)
																				{
																					goto IL_03ac;
																				}
																				goto IL_0421;
																				IL_03ac:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_040e;
																				IL_040e:
																				num5 -= 2;
																				goto end_IL_02da;
																				IL_0421:
																				if (7 >= b)
																				{
																					goto IL_042c;
																				}
																				goto IL_04a1;
																				IL_042c:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_043a;
																				IL_043a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_047a;
																				IL_047a:
																				array[num5 - 2] = 0;
																				goto IL_048e;
																				IL_048e:
																				num5--;
																				goto end_IL_02da;
																				IL_04a1:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_04af;
																				IL_04af:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04bd;
																				IL_04bd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04e0;
																				IL_04e0:
																				array[num5] = 0;
																				goto IL_04ee;
																				IL_04ee:
																				num5++;
																				goto IL_0589;
																				IL_0589:
																				ptr2 += 8;
																				goto end_IL_02da;
																				IL_0501:
																				if (10 < b)
																				{
																					goto IL_050c;
																				}
																				num = 66;
																				goto IL_0536;
																				IL_050c:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_051a;
																				IL_051a:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_0544:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02da;
																			}
																			break;
																			IL_02a1:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02da;
																	continue;
																	end_IL_02b1:
																	break;
																}
																continue;
																end_IL_02c1:
																break;
															}
															continue;
															end_IL_02da:
															break;
														}
														continue;
													}
													goto IL_0705;
													IL_0705:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0659:
													break;
												}
												continue;
												end_IL_066c:
												break;
											}
											continue;
											end_IL_0676:
											break;
										}
										continue;
										end_IL_068a:
										break;
									}
									continue;
									end_IL_069f:
									break;
								}
								continue;
								end_IL_06af:
								break;
							}
							continue;
							end_IL_06bf:
							break;
						}
						continue;
						end_IL_06ca:
						break;
					}
					continue;
					end_IL_06da:
					break;
				}
				continue;
				end_IL_06ea:
				break;
			}
		}
	}

	private void method_1()
	{
		int num = 117;
		num = 39;
		num = 232;
		num = 58;
		num = 39;
		num = 29;
		num = 63;
		num = 63;
		num = 248;
		num = 62;
		num = 54;
		num = 27;
		num = 62;
		num = 89;
		num = 1747;
		num = 1747;
		num = 1810;
		num = 1221;
		num = 111;
		object obj = this;
		obj = ((Class200)obj).dictionary_0;
		Dictionary<int, GameObject>.Enumerator enumerator = ((Dictionary<int, GameObject>)obj).GetEnumerator();
		obj = enumerator;
		Dictionary<int, GameObject>.Enumerator enumerator_ = (Dictionary<int, GameObject>.Enumerator)obj;
		try
		{
			while (enumerator_.MoveNext())
			{
				KeyValuePair<int, GameObject> current = enumerator_.Current;
				obj = current;
				KeyValuePair<int, GameObject> keyValuePair = (KeyValuePair<int, GameObject>)obj;
				GameObject value = keyValuePair.Value;
				obj = value;
				object obj2 = null;
				if ((GameObject)obj != (UnityEngine.Object)obj2)
				{
					GameObject value2 = keyValuePair.Value;
					obj = value2;
					UnityEngine.Object.DestroyImmediate((GameObject)obj);
				}
			}
		}
		finally
		{
			RawDefaultValueAssemblyHashAlgorithm(ref enumerator_);
		}
		obj = this;
		obj = ((Class200)obj).dictionary_0;
		((Dictionary<int, GameObject>)obj).Clear();
		obj = this;
		obj = ((Class200)obj).dictionary_1;
		((Dictionary<int, float>)obj).Clear();
		obj = this;
		obj = ((Class200)obj).dictionary_2;
		((Dictionary<int, float>)obj).Clear();
		obj = this;
		obj = ((Class200)obj).dictionary_3;
		((Dictionary<int, bool>)obj).Clear();
	}

	private unsafe static int smethod_1(int int_0, int int_1)
	{
		int num = 83;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 89;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MulGetInteropFieldTypeAndNameFromXmlAttribute.getIsSecurityTransparentParallelForReplicatingTask);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02d7:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02b7:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02a7:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_029a:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_028a:
																										if (7 < b)
																										{
																											while (8 >= b)
																											{
																												while (8 <= b)
																												{
																													while (true)
																													{
																														IL_024f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_023f:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_0226:
																																num5++;
																																num = 129;
																																while (true)
																																{
																																	if (num != 129)
																																	{
																																		if (num != 1110)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 60:
																																			goto IL_0226;
																																		case 20:
																																			goto IL_023f;
																																		case 24:
																																		case 53:
																																			goto IL_024f;
																																		case 122:
																																			goto IL_026a;
																																		case 19:
																																		case 74:
																																			goto IL_027a;
																																		case 0:
																																		case 96:
																																			goto IL_028a;
																																		case 38:
																																			goto IL_029a;
																																		case 76:
																																			goto IL_02a7;
																																		case 111:
																																			goto IL_02b7;
																																		case 114:
																																			goto IL_02c7;
																																		case 44:
																																			goto IL_02d7;
																																		case 105:
																																			goto end_IL_02d7;
																																		case 14:
																																		case 57:
																																			goto end_IL_02e7;
																																		case 12:
																																		case 47:
																																			goto IL_0302;
																																		case 51:
																																			goto IL_0342;
																																		case 31:
																																			goto IL_0356;
																																		case 71:
																																			goto IL_0369;
																																		case 41:
																																			goto IL_0377;
																																		case 3:
																																			goto IL_038b;
																																		case 75:
																																			goto IL_039b;
																																		case 95:
																																			goto IL_03a6;
																																		case 36:
																																		case 70:
																																			goto IL_03b4;
																																		case 109:
																																			goto IL_03e2;
																																		case 29:
																																			goto IL_03f0;
																																		case 33:
																																		case 112:
																																			goto IL_0403;
																																		case 18:
																																			goto IL_0411;
																																		case 81:
																																		case 110:
																																			goto IL_041f;
																																		case 62:
																																		case 113:
																																			goto IL_0437;
																																		case 21:
																																			goto IL_0477;
																																		case 100:
																																			goto IL_048b;
																																		case 120:
																																			goto IL_049e;
																																		case 15:
																																			goto IL_04ac;
																																		case 72:
																																		case 121:
																																			goto IL_04bf;
																																		case 108:
																																			goto IL_04cd;
																																		case 4:
																																		case 98:
																																			goto IL_04db;
																																		case 79:
																																			goto IL_0549;
																																		case 23:
																																			goto IL_057d;
																																		case 2:
																																		case 30:
																																			goto IL_058b;
																																		case 9:
																																			goto IL_0599;
																																		case 118:
																																			goto IL_05bc;
																																		case 25:
																																			goto IL_05c6;
																																		case 80:
																																			goto IL_05d4;
																																		case 13:
																																		case 35:
																																			goto IL_05e7;
																																		case 46:
																																			goto IL_05f5;
																																		case 91:
																																			goto IL_0603;
																																		case 67:
																																			goto IL_0611;
																																		case 58:
																																		case 68:
																																			goto IL_061f;
																																		case 86:
																																			goto IL_0633;
																																		case 55:
																																			goto IL_0672;
																																		case 69:
																																		case 115:
																																			goto IL_0685;
																																		case 5:
																																		case 119:
																																			goto IL_0695;
																																		case 28:
																																			goto IL_06a0;
																																		case 61:
																																		case 102:
																																			goto IL_06ab;
																																		case 6:
																																		case 7:
																																		case 8:
																																		case 17:
																																		case 22:
																																		case 26:
																																		case 32:
																																		case 34:
																																		case 37:
																																		case 45:
																																		case 49:
																																		case 50:
																																		case 54:
																																		case 84:
																																		case 87:
																																		case 88:
																																		case 93:
																																		case 99:
																																		case 101:
																																		case 116:
																																		case 117:
																																			goto end_IL_0213;
																																		case 103:
																																			goto IL_06e7;
																																		case 90:
																																			goto IL_06f5;
																																		case 73:
																																			goto IL_0703;
																																		case 1:
																																		case 11:
																																		case 16:
																																		case 39:
																																		case 40:
																																		case 42:
																																		case 43:
																																		case 48:
																																		case 63:
																																		case 64:
																																		case 65:
																																		case 78:
																																		case 94:
																																		case 97:
																																		case 104:
																																			goto end_IL_02f7;
																																		case 27:
																																			goto end_IL_0711;
																																		case 77:
																																			goto end_IL_0724;
																																		case 10:
																																			goto end_IL_072e;
																																		case 52:
																																			goto end_IL_0739;
																																		case 92:
																																			goto end_IL_074e;
																																		case 59:
																																		case 89:
																																			goto end_IL_0763;
																																		case 56:
																																			goto end_IL_0773;
																																		case 66:
																																		case 107:
																																			goto end_IL_0783;
																																		case 82:
																																			goto end_IL_079c;
																																		case 83:
																																			goto end_IL_07ac;
																																		case 85:
																																		case 106:
																																			goto IL_07c7;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_02f7;
																																	continue;
																																	end_IL_0213:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																													IL_026a:;
																												}
																												break;
																												IL_027a:;
																											}
																											break;
																										}
																										goto IL_057d;
																										IL_05d4:
																										ptr2 += 8;
																										goto end_IL_02f7;
																										IL_057d:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_058b;
																										IL_058b:
																										array[num5] = 0;
																										goto IL_0599;
																										IL_0599:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_05bc;
																										IL_05bc:
																										array2[num5] = null;
																										goto IL_05c6;
																										IL_05c6:
																										num5++;
																										goto IL_05d4;
																									}
																									break;
																								}
																								goto IL_0302;
																								IL_0356:
																								num5--;
																								goto end_IL_02f7;
																								IL_0302:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0342;
																								IL_0342:
																								array[num5 - 2] = 0;
																								goto IL_0356;
																							}
																							break;
																						}
																						goto IL_05e7;
																						IL_06ab:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02f7;
																						IL_05e7:
																						if (11 >= b)
																						{
																							goto IL_05f5;
																						}
																						goto IL_0695;
																						IL_05f5:
																						if (11 > b)
																						{
																							goto IL_0603;
																						}
																						goto IL_0685;
																						IL_0603:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0611;
																						IL_0611:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_061f;
																						IL_061f:
																						array[num5 - 1] = 0;
																						goto IL_0633;
																						IL_0633:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getRevisionNumbersetShadowCopyFiles[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_0672;
																						IL_0672:
																						ptr2 += 8;
																						goto end_IL_02f7;
																						IL_0685:
																						num5--;
																						goto end_IL_02f7;
																						IL_0695:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_06a0;
																						IL_06a0:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_06ab;
																					}
																					break;
																				}
																				goto IL_0369;
																				IL_0403:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0411;
																				IL_0369:
																				if (6 <= b)
																				{
																					goto end_IL_02f7;
																				}
																				goto IL_0377;
																				IL_0377:
																				if (3 >= b)
																				{
																					num = 3;
																					goto IL_038b;
																				}
																				goto IL_039b;
																				IL_0411:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_041f;
																				IL_038b:
																				if (3 > b)
																				{
																					goto IL_03e2;
																				}
																				goto IL_0437;
																				IL_0437:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0477;
																				IL_0477:
																				array[num5 - 2] = 0;
																				goto IL_048b;
																				IL_048b:
																				num5--;
																				goto end_IL_02f7;
																				IL_03e2:
																				if (1 >= b)
																				{
																					goto IL_03f0;
																				}
																				goto IL_04bf;
																				IL_03f0:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_04bf:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_04cd;
																				IL_04cd:
																				if (2 > b)
																				{
																					num = 22;
																					break;
																				}
																				goto IL_04db;
																				IL_04db:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0549;
																				IL_0549:
																				num5 -= 2;
																				goto end_IL_02f7;
																				IL_041f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02f7;
																				IL_039b:
																				if (4 >= b)
																				{
																					goto IL_03a6;
																				}
																				goto IL_0403;
																				IL_03a6:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_03b4;
																				IL_03b4:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_049e;
																				IL_049e:
																				ptr2 += 8;
																				goto IL_04ac;
																				IL_04ac:
																				num5--;
																				goto end_IL_02f7;
																			}
																			break;
																			IL_02c7:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e7;
																	IL_0703:
																	ptr2 += 8;
																	goto end_IL_02f7;
																	IL_06f5:
																	num5++;
																	goto IL_0703;
																	IL_06e7:
																	array[num5] = 0;
																	goto IL_06f5;
																	continue;
																	end_IL_02d7:
																	break;
																}
																continue;
																end_IL_02e7:
																break;
															}
															continue;
															end_IL_02f7:
															break;
														}
														continue;
													}
													goto IL_07c7;
													IL_07c7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0711:
													break;
												}
												continue;
												end_IL_0724:
												break;
											}
											continue;
											end_IL_072e:
											break;
										}
										continue;
										end_IL_0739:
										break;
									}
									continue;
									end_IL_074e:
									break;
								}
								continue;
								end_IL_0763:
								break;
							}
							continue;
							end_IL_0773:
							break;
						}
						continue;
						end_IL_0783:
						break;
					}
					continue;
					end_IL_079c:
					break;
				}
				continue;
				end_IL_07ac:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_0)
	{
		int num = 2;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 25;
				while (true)
				{
					num = 22;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							num = 83;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EvidenceCollectionDMN.getOSArchitectureGenericIdentity);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02e4:
															byte b = *ptr2;
															while (true)
															{
																IL_02d4:
																ptr2++;
																while (true)
																{
																	IL_02c4:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02a4:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0294:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0287:
																								if (9 <= b)
																								{
																									while (true)
																									{
																										IL_0223:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										while (true)
																										{
																											IL_020a:
																											num5 -= 2;
																											num = 122;
																											while (num != 122)
																											{
																												if (num != 1103)
																												{
																													goto IL_03e6;
																												}
																												switch (num)
																												{
																												case 41:
																													goto IL_020a;
																												case 32:
																												case 103:
																													goto IL_0223;
																												case 47:
																													goto IL_0287;
																												case 49:
																												case 85:
																													goto IL_0294;
																												case 45:
																													goto IL_02a4;
																												case 3:
																													goto IL_02b4;
																												case 38:
																													goto IL_02c4;
																												case 50:
																													goto IL_02d4;
																												case 29:
																												case 69:
																													goto IL_02e4;
																												case 63:
																												case 73:
																													goto IL_02ef;
																												case 42:
																													goto IL_02fa;
																												case 56:
																													goto IL_0308;
																												case 14:
																												case 98:
																													goto IL_0316;
																												case 51:
																													goto IL_0339;
																												case 20:
																													goto IL_0347;
																												case 48:
																													goto IL_0355;
																												case 107:
																													goto IL_0368;
																												case 12:
																												case 39:
																													goto IL_0376;
																												case 66:
																													goto IL_03b6;
																												case 111:
																													goto IL_03ca;
																												case 6:
																												case 23:
																													goto IL_03e6;
																												case 78:
																												case 81:
																													goto IL_03f1;
																												case 74:
																													goto IL_03fc;
																												case 24:
																													goto IL_041d;
																												case 65:
																												case 108:
																													goto IL_042b;
																												case 93:
																													goto IL_0447;
																												case 7:
																													goto IL_0455;
																												case 64:
																												case 84:
																													goto IL_0463;
																												case 4:
																												case 10:
																													goto IL_046e;
																												case 94:
																													goto IL_047c;
																												case 11:
																												case 106:
																													goto IL_048a;
																												case 96:
																													goto IL_0498;
																												case 21:
																													goto IL_04bb;
																												case 15:
																													goto IL_04c5;
																												case 109:
																													goto IL_04d3;
																												case 91:
																													goto IL_04e6;
																												case 8:
																													goto IL_04f9;
																												case 13:
																												case 60:
																													goto IL_0507;
																												case 0:
																													goto IL_0512;
																												case 99:
																													goto IL_0520;
																												case 40:
																												case 61:
																													goto IL_052e;
																												case 104:
																													goto IL_0557;
																												case 72:
																													goto IL_0565;
																												case 36:
																													goto IL_0578;
																												case 53:
																												case 115:
																													goto IL_0586;
																												case 86:
																													goto IL_059f;
																												case 59:
																													goto IL_05ad;
																												case 97:
																													goto IL_05c4;
																												case 19:
																												case 70:
																													goto IL_05d7;
																												case 37:
																												case 92:
																													goto IL_05ef;
																												case 17:
																													goto IL_062f;
																												case 44:
																													goto IL_0643;
																												case 5:
																												case 9:
																												case 27:
																												case 28:
																												case 30:
																												case 31:
																												case 33:
																												case 46:
																												case 58:
																												case 62:
																												case 68:
																												case 71:
																												case 75:
																												case 77:
																												case 80:
																												case 82:
																												case 88:
																												case 100:
																												case 112:
																												case 113:
																												case 114:
																													goto end_IL_02b4;
																												case 16:
																												case 34:
																												case 35:
																												case 52:
																												case 55:
																												case 67:
																												case 76:
																												case 89:
																												case 90:
																												case 95:
																												case 101:
																												case 102:
																												case 110:
																													goto end_IL_01f7;
																												case 79:
																													goto end_IL_066f;
																												case 18:
																													goto end_IL_0682;
																												case 43:
																													goto end_IL_068c;
																												case 54:
																													goto end_IL_0697;
																												case 26:
																												case 83:
																													goto end_IL_06ac;
																												case 57:
																													goto end_IL_06bc;
																												case 22:
																													goto end_IL_06cc;
																												case 25:
																													goto end_IL_06e5;
																												case 1:
																													goto end_IL_06f5;
																												case 2:
																													goto end_IL_0700;
																												case 87:
																												case 105:
																													goto IL_0724;
																												}
																												continue;
																												end_IL_01f7:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02ef;
																								IL_03ca:
																								num5--;
																								num = 89;
																								break;
																								IL_02ef:
																								if (7 < b)
																								{
																									goto IL_02fa;
																								}
																								goto IL_0368;
																								IL_02fa:
																								if (8 < b)
																								{
																									goto end_IL_02b4;
																								}
																								goto IL_0308;
																								IL_0308:
																								if (8 > b)
																								{
																									goto end_IL_02b4;
																								}
																								goto IL_0316;
																								IL_0316:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0339;
																								IL_0339:
																								array[num5] = 0;
																								goto IL_0347;
																								IL_0347:
																								num5++;
																								goto IL_0355;
																								IL_0355:
																								ptr2 += 8;
																								break;
																								IL_0368:
																								if (7 > b)
																								{
																									goto end_IL_02b4;
																								}
																								goto IL_0376;
																								IL_0376:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03b6;
																								IL_03b6:
																								array[num5 - 2] = 0;
																								goto IL_03ca;
																							}
																							break;
																						}
																						goto IL_03e6;
																						IL_041d:
																						if (10 > b)
																						{
																							goto end_IL_02b4;
																						}
																						goto IL_042b;
																						IL_03e6:
																						if (10 < b)
																						{
																							goto IL_03f1;
																						}
																						goto IL_041d;
																						IL_03f1:
																						if (11 < b)
																						{
																							num = 5;
																							goto end_IL_02b4;
																						}
																						goto IL_03fc;
																						IL_03fc:
																						if (11 <= b)
																						{
																						}
																						goto end_IL_02b4;
																						IL_042b:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																					}
																					break;
																				}
																				goto IL_0447;
																				IL_0643:
																				num5--;
																				num = 102;
																				break;
																				IL_0447:
																				if (6 > b)
																				{
																					goto IL_0455;
																				}
																				goto IL_05ef;
																				IL_0455:
																				if (3 < b)
																				{
																					goto IL_0463;
																				}
																				goto IL_04f9;
																				IL_0463:
																				if (4 < b)
																				{
																					goto IL_046e;
																				}
																				goto IL_04e6;
																				IL_046e:
																				if (5 < b)
																				{
																					goto end_IL_02b4;
																				}
																				goto IL_047c;
																				IL_047c:
																				if (5 > b)
																				{
																					goto end_IL_02b4;
																				}
																				goto IL_048a;
																				IL_048a:
																				array[num5] = 0;
																				goto IL_0498;
																				IL_0498:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04bb;
																				IL_04bb:
																				array2[num5] = null;
																				goto IL_04c5;
																				IL_04c5:
																				num5++;
																				goto IL_04d3;
																				IL_04d3:
																				ptr2 += 8;
																				break;
																				IL_04e6:
																				if (4 > b)
																				{
																					goto end_IL_02b4;
																				}
																				break;
																				IL_04f9:
																				if (3 > b)
																				{
																					goto IL_0507;
																				}
																				goto IL_05d7;
																				IL_0507:
																				if (1 < b)
																				{
																					goto IL_0512;
																				}
																				goto IL_0578;
																				IL_0512:
																				if (2 < b)
																				{
																					goto end_IL_02b4;
																				}
																				goto IL_0520;
																				IL_0520:
																				if (2 > b)
																				{
																					goto end_IL_02b4;
																				}
																				goto IL_052e;
																				IL_052e:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0557;
																				IL_0557:
																				ptr2 += 8;
																				goto IL_0565;
																				IL_0565:
																				num5--;
																				break;
																				IL_0578:
																				if (1 > b)
																				{
																					goto end_IL_02b4;
																				}
																				goto IL_0586;
																				IL_0586:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_059f;
																				IL_059f:
																				array[num5] = 0;
																				goto IL_05ad;
																				IL_05ad:
																				num5++;
																				num = 97;
																				goto IL_05c4;
																				IL_05c4:
																				ptr2 += 8;
																				break;
																				IL_05d7:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_05ef:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_062f;
																				IL_062f:
																				array[num5 - 2] = 0;
																				goto IL_0643;
																			}
																			goto end_IL_02c4;
																			continue;
																			end_IL_02b4:
																			break;
																			IL_02b4:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02c4:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0724;
													IL_0724:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_066f:
													break;
												}
												continue;
												end_IL_0682:
												break;
											}
											continue;
											end_IL_068c:
											break;
										}
										continue;
										end_IL_0697:
										break;
									}
									continue;
									end_IL_06ac:
									break;
								}
								continue;
								end_IL_06bc:
								break;
							}
							continue;
							end_IL_06cc:
							break;
						}
						continue;
						end_IL_06e5:
						break;
					}
					continue;
					end_IL_06f5:
					break;
				}
				continue;
				end_IL_0700:
				break;
			}
		}
	}

	private void method_2()
	{
		int num = 87;
		int num2 = 3;
		num = 29;
		num = 108;
		num2 = 2;
		num = 54;
		num = 29;
		num2 = 54;
		num = 43;
		num2 = 29;
		num2 = 20;
		num = 63;
		num = 63;
		num = 98;
		num2 = 2;
		num = 49;
		num = 897;
		num2 = 13;
		num = 69;
		num = 49;
		num2 = 69;
		num = 118;
		num2 = 49;
		num2 = 3381;
		num = 3395;
		num = 3395;
		num2 = 63;
		num = 3458;
		num = 1794;
		num2 = 13;
		num = 138;
		num2 = 816;
		num2 = 272;
		object obj;
		try
		{
			obj = this;
			obj = ((Class200)obj).list_0;
			if (((List<Player>)obj).Count != 0)
			{
				double num3 = 9999.0;
				Class9.smethod_6((float)num3);
			}
			obj = this;
			obj = ((Class200)obj).list_0;
			if (((List<Player>)obj).Count == 0)
			{
				obj = this;
				obj = ((Class200)obj).dictionary_0;
				int count = ((Dictionary<int, GameObject>)obj).Count;
				num = count;
				num2 = 0;
				if (num > 0)
				{
					obj = this;
					((Class200)obj).method_1();
				}
				float time = Time.time;
				double num3 = time;
				object obj2 = this;
				double num4 = ((Class200)obj2).float_1;
				double num5 = 6.0;
				num4 += num5;
				if (num3 <= num4)
				{
					return;
				}
				obj = this;
				float time2 = Time.time;
				num4 = time2;
				((Class200)obj).float_1 = (float)num4;
				Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
				obj = playerListOthers;
				global::_003CModule_003E.player_95 = (Player[])obj;
				num = 0;
				global::_003CModule_003E.int_214 = 0;
				while (true)
				{
					num = global::_003CModule_003E.int_214;
					obj2 = global::_003CModule_003E.player_95;
					IntPtr intPtr = (nint)((Player[])obj2).LongLength;
					num2 = (int)(nint)intPtr;
					if (num >= num2)
					{
						break;
					}
					obj = global::_003CModule_003E.player_95;
					num2 = global::_003CModule_003E.int_214;
					obj = ((Player[])obj)[num2];
					global::_003CModule_003E.player_96 = (Player)obj;
					num = 1;
					num4 = 999999.0;
					num5 = -999999.0;
					double num6 = 999999.0;
					Vector3 vector = new Vector3((float)num4, (float)num5, (float)num6);
					obj2 = vector;
					object obj3 = new int[1];
					object obj4 = obj3;
					object player_ = global::_003CModule_003E.player_96;
					int actorNumber = ((Player)player_).ActorNumber;
					int num7 = actorNumber;
					((int[])obj4)[0] = num7;
					Vector3 zero = Vector3.zero;
					obj4 = zero;
					Vector3 zero2 = Vector3.zero;
					object obj5 = zero2;
					double num8 = 2.0;
					num8 = -1.0;
					int num9 = Convert.ToInt32(num8);
					num7 = num9;
					Class9.smethod_102(bool_7: true, (Vector3)obj2, (int[])obj3, (Vector3)obj4, (Vector3)obj5, num7);
					num = global::_003CModule_003E.int_214;
					num2 = 1;
					num++;
					global::_003CModule_003E.int_214 = num;
				}
				PhotonNetwork.SendAllOutgoingCommands();
				return;
			}
		}
		catch
		{
		}
		obj = this;
		obj = ((Class200)obj).list_0;
		int count2 = ((List<Player>)obj).Count;
		num = count2;
		num2 = 1;
		num--;
		global::_003CModule_003E.int_215 = num;
		while (true)
		{
			num = global::_003CModule_003E.int_215;
			num2 = 0;
			if (num < 0)
			{
				break;
			}
			obj = this;
			obj = ((Class200)obj).list_0;
			num2 = global::_003CModule_003E.int_215;
			Player player = ((List<Player>)obj)[num2];
			obj = player;
			global::_003CModule_003E.player_97 = (Player)obj;
			obj = global::_003CModule_003E.player_97;
			object obj2;
			if (obj != null)
			{
				num = 0;
				global::_003CModule_003E.bool_42 = false;
				Player[] playerListOthers2 = PhotonNetwork.PlayerListOthers;
				obj = playerListOthers2;
				global::_003CModule_003E.player_95 = (Player[])obj;
				num = 0;
				global::_003CModule_003E.int_214 = 0;
				while (true)
				{
					num = global::_003CModule_003E.int_214;
					obj2 = global::_003CModule_003E.player_95;
					IntPtr intPtr = (nint)((Player[])obj2).LongLength;
					num2 = (int)(nint)intPtr;
					if (num < num2)
					{
						obj = global::_003CModule_003E.player_95;
						num2 = global::_003CModule_003E.int_214;
						obj = ((Player[])obj)[num2];
						obj2 = global::_003CModule_003E.player_97;
						if (obj != obj2)
						{
							num = global::_003CModule_003E.int_214;
							num2 = 1;
							num++;
							global::_003CModule_003E.int_214 = num;
							continue;
						}
						num = 1;
						global::_003CModule_003E.bool_42 = true;
						break;
					}
					break;
				}
				if (global::_003CModule_003E.bool_42)
				{
					obj = global::_003CModule_003E.player_97;
					VRRig vRRig = GClass24.smethod_2((Player)obj);
					obj = vRRig;
					global::_003CModule_003E.vrrig_62 = (VRRig)obj;
					obj = global::_003CModule_003E.vrrig_62;
					obj2 = null;
					if ((VRRig)obj == (UnityEngine.Object)obj2)
					{
						goto IL_0c0f;
					}
					obj = global::_003CModule_003E.player_97;
					int actorNumber2 = ((Player)obj).ActorNumber;
					num = actorNumber2;
					global::_003CModule_003E.int_216 = num;
					obj = this;
					obj = ((Class200)obj).dictionary_0;
					num2 = global::_003CModule_003E.int_216;
					if (((Dictionary<int, GameObject>)obj).TryGetValue(num2, out global::_003CModule_003E.gameObject_28))
					{
						obj = global::_003CModule_003E.gameObject_28;
						obj2 = null;
						if (!((GameObject)obj == (UnityEngine.Object)obj2))
						{
							goto IL_06b7;
						}
					}
					num = 0;
					GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
					obj = gameObject;
					global::_003CModule_003E.gameObject_28 = (GameObject)obj;
					obj = global::_003CModule_003E.gameObject_28;
					Transform transform = ((GameObject)obj).transform;
					obj = transform;
					double num4 = 0.10000000149011612;
					double num5 = 0.10000000149011612;
					double num6 = 0.10000000149011612;
					Vector3 vector2 = new Vector3((float)num4, (float)num5, (float)num6);
					obj2 = vector2;
					((Transform)obj).localScale = (Vector3)obj2;
					obj = global::_003CModule_003E.gameObject_28;
					BoxCollider component = ((GameObject)obj).GetComponent<BoxCollider>();
					obj = component;
					UnityEngine.Object.Destroy((BoxCollider)obj);
					obj = global::_003CModule_003E.gameObject_28;
					Rigidbody component2 = ((GameObject)obj).GetComponent<Rigidbody>();
					obj = component2;
					UnityEngine.Object.Destroy((Rigidbody)obj);
					obj = global::_003CModule_003E.gameObject_28;
					Collider component3 = ((GameObject)obj).GetComponent<Collider>();
					obj = component3;
					UnityEngine.Object.Destroy((Collider)obj);
					ShaderPatch.EnsureCached();
					obj = global::_003CModule_003E.gameObject_28;
					Renderer component4 = ((GameObject)obj).GetComponent<Renderer>();
					obj = component4;
					Material material = ((Renderer)obj).material;
					obj = material;
					Shader cached = ShaderPatch.Cached;
					obj2 = cached;
					((Material)obj).shader = (Shader)obj2;
					obj = global::_003CModule_003E.gameObject_28;
					Renderer component5 = ((GameObject)obj).GetComponent<Renderer>();
					obj = component5;
					Material material2 = ((Renderer)obj).material;
					obj = material2;
					Color cyan = Color.cyan;
					obj2 = cyan;
					((Material)obj).color = (Color)obj2;
					obj = this;
					obj = ((Class200)obj).dictionary_0;
					num2 = global::_003CModule_003E.int_216;
					object obj3 = global::_003CModule_003E.gameObject_28;
					((Dictionary<int, GameObject>)obj)[num2] = (GameObject)obj3;
					goto IL_06b7;
				}
				obj = this;
				obj = ((Class200)obj).list_0;
				num2 = global::_003CModule_003E.int_215;
				((List<Player>)obj).RemoveAt(num2);
				obj = this;
				obj = ((Class200)obj).dictionary_3;
				obj2 = global::_003CModule_003E.player_97;
				int actorNumber3 = ((Player)obj2).ActorNumber;
				num2 = actorNumber3;
				((Dictionary<int, bool>)obj)[num2] = false;
				obj = this;
				obj2 = global::_003CModule_003E.player_97;
				int actorNumber4 = ((Player)obj2).ActorNumber;
				num2 = actorNumber4;
				((Class200)obj).method_0(num2);
				double num3 = 1000.0;
				Class9.smethod_6((float)num3);
				goto IL_0c0f;
			}
			obj = this;
			obj = ((Class200)obj).list_0;
			num2 = global::_003CModule_003E.int_215;
			((List<Player>)obj).RemoveAt(num2);
			goto IL_0c0f;
			IL_06b7:
			obj = global::_003CModule_003E.gameObject_28;
			Transform transform2 = ((GameObject)obj).transform;
			obj = transform2;
			obj2 = global::_003CModule_003E.vrrig_62;
			Transform transform3 = ((VRRig)obj2).transform;
			obj2 = transform3;
			Vector3 position = ((Transform)obj2).position;
			obj2 = position;
			((Transform)obj).position = (Vector3)obj2;
			try
			{
				double num3 = 9999.0;
				Class9.smethod_6((float)num3);
				obj = this;
				obj = ((Class200)obj).dictionary_1;
				num2 = global::_003CModule_003E.int_216;
				if (!((Dictionary<int, float>)obj).TryGetValue(num2, out global::_003CModule_003E.float_117))
				{
					num3 = 0.0;
					global::_003CModule_003E.float_117 = (float)num3;
				}
				obj = this;
				obj = ((Class200)obj).dictionary_3;
				num2 = global::_003CModule_003E.int_216;
				if (!((Dictionary<int, bool>)obj).TryGetValue(num2, out global::_003CModule_003E.bool_43))
				{
					num = 0;
					global::_003CModule_003E.bool_43 = false;
				}
				float time3 = Time.time;
				num3 = time3;
				double num4 = global::_003CModule_003E.float_117;
				double num5 = 6.0;
				num4 += num5;
				if (num3 > num4 || !global::_003CModule_003E.bool_43)
				{
					obj = this;
					obj = ((Class200)obj).dictionary_1;
					num2 = global::_003CModule_003E.int_216;
					float time4 = Time.time;
					num5 = time4;
					((Dictionary<int, float>)obj)[num2] = (float)num5;
					obj = this;
					obj = ((Class200)obj).dictionary_3;
					num2 = global::_003CModule_003E.int_216;
					((Dictionary<int, bool>)obj)[num2] = true;
					Player[] playerListOthers3 = PhotonNetwork.PlayerListOthers;
					obj = playerListOthers3;
					global::_003CModule_003E.player_95 = (Player[])obj;
					num = 0;
					global::_003CModule_003E.int_214 = 0;
					while (true)
					{
						num = global::_003CModule_003E.int_214;
						obj2 = global::_003CModule_003E.player_95;
						IntPtr intPtr = (nint)((Player[])obj2).LongLength;
						num2 = (int)(nint)intPtr;
						if (num >= num2)
						{
							break;
						}
						obj = global::_003CModule_003E.player_95;
						num2 = global::_003CModule_003E.int_214;
						obj = ((Player[])obj)[num2];
						global::_003CModule_003E.player_98 = (Player)obj;
						obj = this;
						obj = ((Class200)obj).list_0;
						obj2 = global::_003CModule_003E.player_98;
						if (!((List<Player>)obj).Contains((Player)obj2))
						{
							num = 1;
							num4 = 1000000000.0;
							num5 = 1000000000.0;
							double num6 = 1000000000.0;
							Vector3 vector3 = new Vector3((float)num4, (float)num5, (float)num6);
							obj2 = vector3;
							object obj3 = new int[1];
							object obj4 = obj3;
							object player_ = global::_003CModule_003E.player_98;
							int actorNumber5 = ((Player)player_).ActorNumber;
							int num7 = actorNumber5;
							((int[])obj4)[0] = num7;
							Vector3 zero3 = Vector3.zero;
							obj4 = zero3;
							Vector3 zero4 = Vector3.zero;
							object obj5 = zero4;
							double num8 = -0.5;
							num8 = -1.0;
							int num10 = Convert.ToInt32(num8);
							num7 = num10;
							Class9.smethod_102(bool_7: true, (Vector3)obj2, (int[])obj3, (Vector3)obj4, (Vector3)obj5, num7);
						}
						num = global::_003CModule_003E.int_214;
						num2 = 1;
						num++;
						global::_003CModule_003E.int_214 = num;
					}
				}
				obj = this;
				obj = ((Class200)obj).dictionary_2;
				num2 = global::_003CModule_003E.int_216;
				if (!((Dictionary<int, float>)obj).TryGetValue(num2, out global::_003CModule_003E.float_118))
				{
					num3 = 0.0;
					global::_003CModule_003E.float_118 = (float)num3;
				}
				float time5 = Time.time;
				num3 = time5;
				num4 = global::_003CModule_003E.float_118;
				num5 = 0.20000000298023224;
				num4 += num5;
				if (!(num3 <= num4))
				{
					obj = this;
					obj = ((Class200)obj).dictionary_2;
					num2 = global::_003CModule_003E.int_216;
					float time6 = Time.time;
					num5 = time6;
					((Dictionary<int, float>)obj)[num2] = (float)num5;
					num = 1;
					GorillaTagger instance = GorillaTagger.Instance;
					obj2 = instance;
					obj2 = ((GorillaTagger)obj2).offlineVRRig;
					Transform transform4 = ((VRRig)obj2).transform;
					obj2 = transform4;
					Vector3 position2 = ((Transform)obj2).position;
					obj2 = position2;
					object obj3 = new int[1];
					object obj4 = obj3;
					int num7 = global::_003CModule_003E.int_216;
					((int[])obj4)[0] = num7;
					Vector3 zero5 = Vector3.zero;
					obj4 = zero5;
					Vector3 zero6 = Vector3.zero;
					object obj5 = zero6;
					double num8 = -0.5;
					num8 = -1.0;
					int num11 = Convert.ToInt32(num8);
					num7 = num11;
					Class9.smethod_102(bool_7: true, (Vector3)obj2, (int[])obj3, (Vector3)obj4, (Vector3)obj5, num7);
				}
				PhotonNetwork.SendAllOutgoingCommands();
			}
			catch
			{
			}
			goto IL_0c0f;
			IL_0c0f:
			num = global::_003CModule_003E.int_215;
			num2 = 1;
			num--;
			global::_003CModule_003E.int_215 = num;
		}
	}

	private unsafe void method_3()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_040d, IL_0420, IL_044e, IL_045e, IL_046e, IL_047e, IL_048e, IL_04a1, IL_04b1, IL_04c1, IL_04d1, IL_04e1, IL_04f1, IL_0501, IL_0511, IL_0521, IL_052c, IL_053a, IL_0548, IL_0588, IL_05a1, IL_05e3, IL_05f1, IL_05fc, IL_060c, IL_061a, IL_062d, IL_0641, IL_0654, IL_0667, IL_0680, IL_068e, IL_069c, IL_06af, IL_06d8, IL_06e6, IL_06f9, IL_0711, IL_0731, IL_0773, IL_0797, IL_07af, IL_07c2, IL_07df, IL_07f2, IL_0832, IL_0846, IL_0859, IL_0863, IL_0871, IL_0884, IL_0892, IL_08a0, IL_08ae, IL_08b9, IL_08f9, IL_090d, IL_0920, IL_092e, IL_093c, IL_094f, IL_095d, IL_096b, IL_09cd, IL_09e0, IL_09ee, IL_09f9, IL_0a17, IL_0a25, IL_0a38, IL_0a46, IL_0a4f, IL_0a5d, IL_0a7a, IL_0ac9, IL_0ad3, IL_0b00, IL_0b14, IL_0b22, IL_0b35, IL_0b43, IL_0b4c, IL_0b5a, IL_0b83, IL_0b9c, IL_0baa, IL_0bb5, IL_0c07, IL_0c1a, IL_0c28, IL_0c36, IL_0c44, IL_0c52, IL_0c93, IL_0ca7, IL_0cba, IL_0cc3, IL_0cce, IL_0ce6, IL_0cf4, IL_0d02, IL_0d1b, IL_0d29, IL_0d37, IL_0d4a, IL_0d53, IL_0d5e, IL_0d67, IL_0d7b, IL_0db3, IL_0dc6, IL_0dd1, IL_0ddf, IL_0ded, IL_0e05, IL_0e13, IL_0e26, IL_0e34, IL_0e42, IL_0e80, IL_0e93, IL_0ea1, IL_0eaf, IL_0ebd, IL_0ecb, IL_0ed9, IL_0eed, IL_0f2c, IL_0f3f, IL_0f4a, IL_0f63, IL_0f71, IL_0f7f, IL_0f9b, IL_0fa9, IL_0fb2, IL_0fc0, IL_0fe9, IL_0ff7, IL_100a, IL_104a, IL_105e, IL_1071, IL_107f, IL_108a, IL_1098, IL_10a6, IL_10ba, IL_10f9, IL_1109, IL_1122, IL_112d, IL_1138, IL_1141, IL_1154, IL_1167, IL_1171, IL_117c, IL_118c, IL_119c, IL_11ac, IL_11bc, IL_11cc, IL_11dc, IL_11f5, IL_120e are reachable both inside and outside the pinned region starting at IL_1223. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 102;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef95 = default(int);
			ref int reference = ref __rxRef95;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_120e:
					num2 = 1;
					while (true)
					{
						IL_11f5:
						num3 = num2 * 4;
						num = 90;
						while (true)
						{
							IL_11dc:
							num4 = num2 * 8;
							num = 173;
							while (true)
							{
								IL_11cc:
								array2 = new byte[4];
								while (true)
								{
									IL_11bc:
									array3 = new object[4];
									while (true)
									{
										IL_11ac:
										array4 = new int[4];
										while (true)
										{
											IL_119c:
											array5 = new int[7];
											while (true)
											{
												IL_118c:
												array6 = new long[4];
												while (true)
												{
													IL_117c:
													array7 = new object[14];
													while (true)
													{
														IL_1171:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ArgumentItemNotExistgetModuleHandle.IsSynchronizedDisableEvents);
														while (true)
														{
															IL_1167:
															ptr2 = ptr;
															while (true)
															{
																IL_1154:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0521:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0511:
																		ptr2++;
																		while (true)
																		{
																			IL_0501:
																			if (b >= 1)
																			{
																				while (b <= 29)
																				{
																					while (true)
																					{
																						IL_04e1:
																						if (15 >= b)
																						{
																							while (true)
																							{
																								IL_04d1:
																								if (15 > b)
																								{
																									while (true)
																									{
																										IL_04c1:
																										if (7 >= b)
																										{
																											while (true)
																											{
																												IL_04b1:
																												if (7 > b)
																												{
																													while (true)
																													{
																														IL_04a1:
																														if (3 < b)
																														{
																															while (true)
																															{
																																IL_048e:
																																if (5 >= b)
																																{
																																	num = 234;
																																	while (true)
																																	{
																																		IL_047e:
																																		if (5 > b)
																																		{
																																			while (4 >= b)
																																			{
																																				while (4 <= b)
																																				{
																																					while (true)
																																					{
																																						IL_044e:
																																						array2[num6] = 0;
																																						while (true)
																																						{
																																							IL_0420:
																																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																							num = 252;
																																							while (true)
																																							{
																																								if (num != 252)
																																								{
																																									if (num != 1233)
																																									{
																																										break;
																																									}
																																									switch (num)
																																									{
																																									case 102:
																																										break;
																																									default:
																																										continue;
																																									case 179:
																																										goto IL_0420;
																																									case 12:
																																									case 25:
																																										goto IL_044e;
																																									case 171:
																																										goto IL_045e;
																																									case 93:
																																										goto IL_046e;
																																									case 234:
																																										goto IL_047e;
																																									case 0:
																																										goto IL_048e;
																																									case 139:
																																										goto IL_04a1;
																																									case 68:
																																										goto IL_04b1;
																																									case 156:
																																										goto IL_04c1;
																																									case 37:
																																										goto IL_04d1;
																																									case 202:
																																										goto IL_04e1;
																																									case 245:
																																										goto IL_04f1;
																																									case 44:
																																										goto IL_0501;
																																									case 6:
																																										goto IL_0511;
																																									case 29:
																																									case 159:
																																										goto IL_0521;
																																									case 70:
																																										goto IL_052c;
																																									case 75:
																																										goto IL_053a;
																																									case 40:
																																									case 89:
																																										goto IL_0548;
																																									case 80:
																																										goto IL_0588;
																																									case 18:
																																									case 108:
																																										goto IL_05a1;
																																									case 126:
																																										goto IL_05e3;
																																									case 121:
																																										goto IL_05f1;
																																									case 110:
																																										goto IL_05fc;
																																									case 36:
																																										goto IL_060c;
																																									case 81:
																																										goto IL_061a;
																																									case 170:
																																										goto IL_062d;
																																									case 196:
																																										goto IL_0641;
																																									case 206:
																																										goto IL_0654;
																																									case 41:
																																									case 212:
																																										goto IL_0667;
																																									case 15:
																																										goto IL_0680;
																																									case 169:
																																										goto IL_068e;
																																									case 136:
																																										goto IL_069c;
																																									case 191:
																																									case 215:
																																										goto IL_06af;
																																									case 138:
																																										goto IL_06d8;
																																									case 216:
																																										goto IL_06e6;
																																									case 16:
																																									case 218:
																																										goto IL_06f9;
																																									case 133:
																																										goto IL_0711;
																																									case 160:
																																									case 220:
																																										goto IL_0731;
																																									case 223:
																																										goto IL_0773;
																																									case 26:
																																										goto IL_0797;
																																									case 183:
																																										goto IL_07af;
																																									case 228:
																																										goto IL_07c2;
																																									case 145:
																																										goto IL_07df;
																																									case 33:
																																									case 239:
																																										goto IL_07f2;
																																									case 242:
																																										goto IL_0832;
																																									case 99:
																																										goto IL_0846;
																																									case 181:
																																										goto IL_0863;
																																									case 1:
																																										goto IL_0871;
																																									case 96:
																																										goto IL_0884;
																																									case 198:
																																										goto IL_0892;
																																									case 226:
																																										goto IL_08a0;
																																									case 94:
																																										goto IL_08ae;
																																									case 58:
																																									case 158:
																																										goto IL_08b9;
																																									case 221:
																																										goto IL_08f9;
																																									case 17:
																																										goto IL_090d;
																																									case 120:
																																										goto IL_0920;
																																									case 62:
																																										goto IL_092e;
																																									case 27:
																																									case 182:
																																										goto IL_093c;
																																									case 98:
																																										goto IL_094f;
																																									case 48:
																																										goto IL_095d;
																																									case 72:
																																									case 142:
																																										goto IL_096b;
																																									case 129:
																																										goto IL_09cd;
																																									case 67:
																																										goto IL_09e0;
																																									case 168:
																																										goto IL_09ee;
																																									case 64:
																																									case 230:
																																										goto IL_09f9;
																																									case 61:
																																										goto IL_0a17;
																																									case 225:
																																										goto IL_0a25;
																																									case 161:
																																										goto end_IL_040d;
																																									case 203:
																																										goto IL_0a4f;
																																									case 19:
																																									case 207:
																																										goto IL_0a5d;
																																									case 28:
																																										goto IL_0b14;
																																									case 87:
																																										goto IL_0b22;
																																									case 55:
																																										goto IL_0b35;
																																									case 149:
																																										goto IL_0b4c;
																																									case 166:
																																									case 195:
																																										goto IL_0b5a;
																																									case 38:
																																										goto IL_0b83;
																																									case 187:
																																										goto IL_0b9c;
																																									case 128:
																																										goto IL_0baa;
																																									case 189:
																																									case 222:
																																										goto IL_0bb5;
																																									case 109:
																																										goto IL_0c07;
																																									case 2:
																																										goto IL_0c1a;
																																									case 119:
																																										goto IL_0c28;
																																									case 116:
																																										goto IL_0c36;
																																									case 69:
																																										goto IL_0c44;
																																									case 32:
																																									case 165:
																																										goto IL_0c52;
																																									case 105:
																																										goto IL_0c93;
																																									case 174:
																																										goto IL_0ca7;
																																									case 42:
																																										goto IL_0cc3;
																																									case 132:
																																									case 194:
																																										goto IL_0cce;
																																									case 66:
																																										goto IL_0ce6;
																																									case 57:
																																										goto IL_0cf4;
																																									case 106:
																																									case 178:
																																										goto IL_0d02;
																																									case 100:
																																										goto IL_0d1b;
																																									case 164:
																																										goto IL_0d29;
																																									case 211:
																																										goto IL_0d37;
																																									case 77:
																																										goto IL_0d53;
																																									case 14:
																																									case 49:
																																										goto IL_0d67;
																																									case 209:
																																										goto IL_0d7b;
																																									case 188:
																																										goto IL_0db3;
																																									case 118:
																																										goto IL_0dc6;
																																									case 154:
																																										goto IL_0dd1;
																																									case 177:
																																									case 180:
																																										goto IL_0ddf;
																																									case 185:
																																										goto IL_0ded;
																																									case 45:
																																										goto IL_0e05;
																																									case 153:
																																										goto IL_0e13;
																																									case 241:
																																										goto IL_0e26;
																																									case 217:
																																										goto IL_0e34;
																																									case 127:
																																									case 141:
																																										goto IL_0e42;
																																									case 134:
																																										goto IL_0e80;
																																									case 91:
																																										goto IL_0e93;
																																									case 54:
																																										goto IL_0ea1;
																																									case 162:
																																										goto IL_0eaf;
																																									case 150:
																																										goto IL_0ebd;
																																									case 210:
																																										goto IL_0ecb;
																																									case 163:
																																									case 224:
																																										goto IL_0ed9;
																																									case 186:
																																										goto IL_0eed;
																																									case 193:
																																										goto IL_0f2c;
																																									case 201:
																																										goto IL_0f3f;
																																									case 47:
																																									case 95:
																																										goto IL_0f4a;
																																									case 190:
																																										goto IL_0f63;
																																									case 97:
																																										goto IL_0f71;
																																									case 205:
																																										goto IL_0f7f;
																																									case 88:
																																										goto IL_0f9b;
																																									case 214:
																																										goto IL_0fb2;
																																									case 60:
																																									case 229:
																																										goto IL_0fc0;
																																									case 123:
																																										goto IL_0fe9;
																																									case 4:
																																										goto IL_0ff7;
																																									case 104:
																																									case 151:
																																										goto IL_100a;
																																									case 115:
																																										goto IL_104a;
																																									case 152:
																																										goto IL_105e;
																																									case 232:
																																										goto IL_1071;
																																									case 13:
																																										goto IL_107f;
																																									case 167:
																																										goto IL_108a;
																																									case 130:
																																										goto IL_1098;
																																									case 22:
																																									case 43:
																																										goto IL_10a6;
																																									case 34:
																																										goto IL_10ba;
																																									case 76:
																																										goto IL_10f9;
																																									case 92:
																																									case 184:
																																										goto IL_1109;
																																									case 240:
																																										goto IL_1122;
																																									case 233:
																																										goto IL_112d;
																																									case 7:
																																									case 10:
																																									case 20:
																																									case 30:
																																									case 31:
																																									case 46:
																																									case 50:
																																									case 53:
																																									case 56:
																																									case 63:
																																									case 82:
																																									case 107:
																																									case 111:
																																									case 112:
																																									case 114:
																																									case 117:
																																									case 124:
																																									case 137:
																																									case 140:
																																									case 144:
																																									case 175:
																																									case 176:
																																									case 192:
																																									case 197:
																																									case 199:
																																									case 200:
																																									case 204:
																																									case 208:
																																									case 227:
																																									case 235:
																																									case 238:
																																									case 244:
																																										goto end_IL_045e;
																																									case 9:
																																									case 11:
																																									case 21:
																																									case 23:
																																									case 24:
																																									case 35:
																																									case 39:
																																									case 51:
																																									case 59:
																																									case 65:
																																									case 71:
																																									case 73:
																																									case 78:
																																									case 79:
																																									case 85:
																																									case 86:
																																									case 103:
																																									case 113:
																																									case 125:
																																									case 143:
																																									case 146:
																																									case 147:
																																									case 148:
																																									case 155:
																																									case 157:
																																									case 172:
																																									case 213:
																																									case 219:
																																									case 231:
																																									case 236:
																																									case 237:
																																									case 243:
																																										goto IL_1154;
																																									case 5:
																																										goto IL_1167;
																																									case 122:
																																										goto IL_1171;
																																									case 74:
																																										goto IL_117c;
																																									case 8:
																																										goto IL_118c;
																																									case 52:
																																										goto IL_119c;
																																									case 131:
																																										goto IL_11ac;
																																									case 135:
																																										goto IL_11bc;
																																									case 173:
																																										goto IL_11cc;
																																									case 90:
																																										goto IL_11dc;
																																									case 83:
																																										goto IL_11f5;
																																									case 101:
																																										goto IL_120e;
																																									case 3:
																																									case 84:
																																										return;
																																									}
																																									goto end_IL_0501;
																																								}
																																								array3[num6] = null;
																																								goto IL_0863;
																																								IL_0863:
																																								num6++;
																																								goto IL_0871;
																																								IL_0871:
																																								ptr2 += 8;
																																								goto IL_1154;
																																								continue;
																																								end_IL_040d:
																																								break;
																																							}
																																							break;
																																						}
																																						break;
																																					}
																																					goto IL_0a38;
																																					continue;
																																					end_IL_045e:
																																					break;
																																					IL_045e:;
																																				}
																																				break;
																																				IL_046e:;
																																			}
																																			break;
																																		}
																																		goto IL_0731;
																																		IL_07df:
																																		num6--;
																																		goto IL_1154;
																																		IL_0731:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		goto IL_07c2;
																																		IL_07c2:
																																		array2[num6 - 2] = 0;
																																		num = 145;
																																		goto IL_07df;
																																	}
																																	break;
																																}
																																goto IL_052c;
																																IL_0588:
																																array2[num6 - 2] = 0;
																																goto IL_0654;
																																IL_0654:
																																num6--;
																																goto IL_1154;
																																IL_052c:
																																if (6 < b)
																																{
																																	break;
																																}
																																goto IL_053a;
																																IL_053a:
																																if (6 > b)
																																{
																																	break;
																																}
																																goto IL_0548;
																																IL_0548:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0588;
																															}
																															break;
																														}
																														goto IL_05e3;
																														IL_06e6:
																														num6--;
																														goto IL_1154;
																														IL_05e3:
																														if (3 > b)
																														{
																															goto IL_05f1;
																														}
																														goto IL_06af;
																														IL_05f1:
																														if (1 >= b)
																														{
																															goto IL_05fc;
																														}
																														goto IL_060c;
																														IL_05fc:
																														if (1 > b)
																														{
																															break;
																														}
																														goto IL_0667;
																														IL_0667:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																														goto IL_0680;
																														IL_0680:
																														array2[num6] = 0;
																														goto IL_068e;
																														IL_068e:
																														num6++;
																														goto IL_069c;
																														IL_069c:
																														ptr2 += 8;
																														goto IL_1154;
																														IL_060c:
																														if (2 < b)
																														{
																															break;
																														}
																														goto IL_061a;
																														IL_061a:
																														if (2 > b)
																														{
																															break;
																														}
																														goto IL_07f2;
																														IL_07f2:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_0832;
																														IL_0832:
																														array2[num6 - 2] = 0;
																														goto IL_0846;
																														IL_0846:
																														num6--;
																														goto IL_1154;
																														IL_06af:
																														reference = ref array5[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_06d8;
																														IL_06d8:
																														ptr2 += 8;
																														goto IL_06e6;
																													}
																													break;
																												}
																												goto IL_05a1;
																												IL_0641:
																												num6--;
																												goto IL_1154;
																												IL_05a1:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_062d;
																												IL_062d:
																												array2[num6 - 2] = 0;
																												goto IL_0641;
																											}
																											break;
																										}
																										goto IL_0884;
																										IL_0b22:
																										num6++;
																										goto IL_1154;
																										IL_0884:
																										if (11 >= b)
																										{
																											goto IL_0892;
																										}
																										goto IL_09e0;
																										IL_0892:
																										if (11 <= b)
																										{
																											goto IL_1154;
																										}
																										goto IL_08a0;
																										IL_08a0:
																										if (9 >= b)
																										{
																											goto IL_08ae;
																										}
																										goto IL_094f;
																										IL_08ae:
																										if (9 <= b)
																										{
																											goto IL_08b9;
																										}
																										goto IL_0920;
																										IL_08b9:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_08f9;
																										IL_08f9:
																										array2[num6 - 2] = 0;
																										goto IL_090d;
																										IL_090d:
																										num6--;
																										goto IL_1154;
																										IL_0920:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_092e;
																										IL_092e:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_093c;
																										IL_093c:
																										num6--;
																										goto IL_1154;
																										IL_094f:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_095d;
																										IL_095d:
																										if (10 > b)
																										{
																											break;
																										}
																										goto IL_096b;
																										IL_096b:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_09cd;
																										IL_09cd:
																										num6 -= 2;
																										goto IL_1154;
																										IL_09e0:
																										if (13 >= b)
																										{
																											goto IL_09ee;
																										}
																										goto IL_0b35;
																										IL_09ee:
																										if (13 <= b)
																										{
																											goto IL_09f9;
																										}
																										goto IL_0a38;
																										IL_09f9:
																										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										goto IL_0a17;
																										IL_0a17:
																										ptr2 += 8;
																										goto IL_0a25;
																										IL_0a25:
																										num6--;
																										goto IL_1154;
																										IL_0a38:
																										if (12 < b)
																										{
																											break;
																										}
																										num = 203;
																										goto IL_0a4f;
																										IL_0b35:
																										if (14 < b)
																										{
																											break;
																										}
																										num = 149;
																										goto IL_0b4c;
																										IL_0a4f:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0a5d;
																										IL_0a5d:
																										array8 = array3;
																										num7 = num6;
																										if (array == null)
																										{
																											goto IL_0a6c;
																										}
																										num8 = ptr2;
																										byte b2 = *num8;
																										ptr2 = num8 + 4;
																										int num9 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num9;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_0b14;
																										IL_0b83:
																										array2[num6 - 1] = 5;
																										goto IL_1154;
																										IL_0b4c:
																										if (14 > b)
																										{
																											break;
																										}
																										goto IL_0b5a;
																										IL_0b5a:
																										array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																										goto IL_0b83;
																										IL_0b14:
																										array2[num6] = 5;
																										goto IL_0b22;
																									}
																									break;
																								}
																								goto IL_06f9;
																								IL_07af:
																								num6++;
																								goto IL_1154;
																								IL_06f9:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0711;
																								IL_0711:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_0773;
																								IL_0773:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0797;
																								IL_0797:
																								array3[num6] = array3[num6 - 1];
																								goto IL_07af;
																							}
																							break;
																						}
																						goto IL_0b9c;
																						IL_10ba:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_10f9;
																						IL_0b9c:
																						if (22 >= b)
																						{
																							goto IL_0baa;
																						}
																						goto IL_0e93;
																						IL_0baa:
																						if (22 <= b)
																						{
																							goto IL_0bb5;
																						}
																						goto IL_0c1a;
																						IL_0bb5:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0c07;
																						IL_0c07:
																						num6--;
																						goto IL_1154;
																						IL_0c1a:
																						if (18 < b)
																						{
																							goto IL_0c28;
																						}
																						num = 77;
																						goto IL_0d53;
																						IL_0c28:
																						if (20 < b)
																						{
																							goto IL_0c36;
																						}
																						num = 42;
																						goto IL_0cc3;
																						IL_0c36:
																						if (21 < b)
																						{
																							break;
																						}
																						goto IL_0c44;
																						IL_0c44:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_0c52;
																						IL_0c52:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_0c93;
																						IL_0c93:
																						array2[num6 - 2] = 0;
																						goto IL_0ca7;
																						IL_0ca7:
																						num6--;
																						goto IL_1154;
																						IL_1109:
																						num10 = ptr2;
																						num11 = -200;
																						num5 = 1;
																						ptr2 = num10 + num11;
																						goto IL_1154;
																						IL_0cc3:
																						if (20 <= b)
																						{
																							goto IL_0cce;
																						}
																						goto IL_0ce6;
																						IL_0cce:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_1154;
																						IL_0ce6:
																						if (19 < b)
																						{
																							break;
																						}
																						goto IL_0cf4;
																						IL_0cf4:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_0d02;
																						IL_0d02:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0d1b;
																						IL_0d1b:
																						array2[num6] = 1;
																						goto IL_0d29;
																						IL_0d29:
																						num6++;
																						goto IL_0d37;
																						IL_0d37:
																						ptr2 += 16;
																						goto IL_1154;
																						IL_10f9:
																						ptr2 += 8;
																						goto IL_1154;
																						IL_0d53:
																						if (18 <= b)
																						{
																							num = 49;
																							goto IL_0d67;
																						}
																						goto IL_0dc6;
																						IL_1122:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_112d;
																						IL_0d67:
																						array2[num6 - 1] = 5;
																						goto IL_0d7b;
																						IL_0d7b:
																						array3[num6 - 1] = ((delegate*<string[], string>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_0db3;
																						IL_0db3:
																						ptr2 += 8;
																						goto IL_1154;
																						IL_0dc6:
																						if (16 >= b)
																						{
																							goto IL_0dd1;
																						}
																						goto IL_0e26;
																						IL_0dd1:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_0ddf;
																						IL_0ddf:
																						array2[num6] = 5;
																						goto IL_0ded;
																						IL_0ded:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_0e05;
																						IL_0e05:
																						num6++;
																						goto IL_0e13;
																						IL_0e13:
																						ptr2 += 8;
																						goto IL_1154;
																						IL_0e26:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0e34;
																						IL_0e34:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0e42;
																						IL_0e42:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_0e80;
																						IL_0e80:
																						num6 -= 3;
																						goto IL_1154;
																						IL_0e93:
																						if (26 >= b)
																						{
																							goto IL_0ea1;
																						}
																						goto IL_1071;
																						IL_0ea1:
																						if (26 > b)
																						{
																							goto IL_0eaf;
																						}
																						goto IL_100a;
																						IL_0eaf:
																						if (24 < b)
																						{
																							goto IL_0ebd;
																						}
																						goto IL_0f3f;
																						IL_0ebd:
																						if (25 < b)
																						{
																							break;
																						}
																						goto IL_0ecb;
																						IL_0ecb:
																						if (25 > b)
																						{
																							break;
																						}
																						goto IL_0ed9;
																						IL_0ed9:
																						array2[num6 - 1] = 3;
																						goto IL_0eed;
																						IL_0eed:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_0f2c;
																						IL_0f2c:
																						ptr2 += 8;
																						goto IL_1154;
																						IL_0f3f:
																						if (24 <= b)
																						{
																							goto IL_0f4a;
																						}
																						goto IL_0f9b;
																						IL_0f4a:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						goto IL_0f63;
																						IL_0f63:
																						array2[num6] = 3;
																						goto IL_0f71;
																						IL_0f71:
																						num6++;
																						goto IL_0f7f;
																						IL_0f7f:
																						ptr2 += 16;
																						num = 243;
																						goto IL_1154;
																						IL_0f9b:
																						if (23 < b)
																						{
																							break;
																						}
																						num = 214;
																						goto IL_0fb2;
																						IL_112d:
																						if (29 <= b)
																						{
																							num = 144;
																						}
																						break;
																						IL_0fb2:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_0fc0;
																						IL_0fc0:
																						((delegate*<string, void>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																						goto IL_0fe9;
																						IL_0fe9:
																						num6--;
																						goto IL_0ff7;
																						IL_0ff7:
																						ptr2 += 8;
																						goto IL_1154;
																						IL_100a:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_104a;
																						IL_104a:
																						array2[num6 - 2] = 3;
																						goto IL_105e;
																						IL_105e:
																						num6--;
																						goto IL_1154;
																						IL_1071:
																						if (28 >= b)
																						{
																							goto IL_107f;
																						}
																						goto IL_1122;
																						IL_107f:
																						if (28 > b)
																						{
																							goto IL_108a;
																						}
																						goto IL_1109;
																						IL_108a:
																						if (27 < b)
																						{
																							break;
																						}
																						goto IL_1098;
																						IL_1098:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_10a6;
																						IL_10a6:
																						array2[num6 - 1] = 0;
																						goto IL_10ba;
																					}
																					break;
																					IL_04f1:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1154;
																			continue;
																			end_IL_0501:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0a6c:
			while (true)
			{
				IL_0a6c_2:
				array = new byte[4];
				while (true)
				{
					IL_0a7a:
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_0b22_2:
							num6++;
							while (true)
							{
								IL_1154_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0501_2:
											if (b >= 1)
											{
												while (b <= 29)
												{
													while (true)
													{
														IL_04e1_2:
														if (15 >= b)
														{
															while (true)
															{
																IL_04d1_2:
																if (15 > b)
																{
																	while (true)
																	{
																		IL_04c1_2:
																		if (7 >= b)
																		{
																			while (true)
																			{
																				IL_04b1_2:
																				if (7 > b)
																				{
																					while (true)
																					{
																						IL_04a1_2:
																						if (3 < b)
																						{
																							while (true)
																							{
																								IL_048e_2:
																								if (5 >= b)
																								{
																									num = 234;
																									while (true)
																									{
																										IL_047e_2:
																										if (5 > b)
																										{
																											while (4 >= b)
																											{
																												while (4 <= b)
																												{
																													while (true)
																													{
																														IL_044e_2:
																														array2[num6] = 0;
																														while (true)
																														{
																															IL_0420_2:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																															num = 252;
																															while (true)
																															{
																																if (num != 252)
																																{
																																	if (num != 1233)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 179:
																																		goto IL_0420_2;
																																	case 12:
																																	case 25:
																																		goto IL_044e_2;
																																	case 171:
																																		goto IL_045e_2;
																																	case 93:
																																		goto IL_046e_2;
																																	case 234:
																																		goto IL_047e_2;
																																	case 0:
																																		goto IL_048e_2;
																																	case 139:
																																		goto IL_04a1_2;
																																	case 68:
																																		goto IL_04b1_2;
																																	case 156:
																																		goto IL_04c1_2;
																																	case 37:
																																		goto IL_04d1_2;
																																	case 202:
																																		goto IL_04e1_2;
																																	case 245:
																																		goto IL_04f1_2;
																																	case 44:
																																		goto IL_0501_2;
																																	case 6:
																																		goto end_IL_0501_2;
																																	case 29:
																																	case 159:
																																		goto end_IL_0511;
																																	case 70:
																																		goto IL_052c_2;
																																	case 75:
																																		goto IL_053a_2;
																																	case 40:
																																	case 89:
																																		goto IL_0548_2;
																																	case 80:
																																		goto IL_0588_2;
																																	case 18:
																																	case 108:
																																		goto IL_05a1_2;
																																	case 126:
																																		goto IL_05e3_2;
																																	case 121:
																																		goto IL_05f1_2;
																																	case 110:
																																		goto IL_05fc_2;
																																	case 36:
																																		goto IL_060c_2;
																																	case 81:
																																		goto IL_061a_2;
																																	case 170:
																																		goto IL_062d_2;
																																	case 196:
																																		goto IL_0641_2;
																																	case 206:
																																		goto IL_0654_2;
																																	case 41:
																																	case 212:
																																		goto IL_0667_2;
																																	case 15:
																																		goto IL_0680_2;
																																	case 169:
																																		goto IL_068e_2;
																																	case 136:
																																		goto IL_069c_2;
																																	case 191:
																																	case 215:
																																		goto IL_06af_2;
																																	case 138:
																																		goto IL_06d8_2;
																																	case 216:
																																		goto IL_06e6_2;
																																	case 16:
																																	case 218:
																																		goto IL_06f9_2;
																																	case 133:
																																		goto IL_0711_2;
																																	case 160:
																																	case 220:
																																		goto IL_0731_2;
																																	case 223:
																																		goto IL_0773_2;
																																	case 26:
																																		goto IL_0797_2;
																																	case 183:
																																		goto IL_07af_2;
																																	case 228:
																																		goto IL_07c2_2;
																																	case 145:
																																		goto IL_07df_2;
																																	case 33:
																																	case 239:
																																		goto IL_07f2_2;
																																	case 242:
																																		goto IL_0832_2;
																																	case 99:
																																		goto IL_0846_2;
																																	case 181:
																																		goto IL_0863_2;
																																	case 1:
																																		goto IL_0871_2;
																																	case 96:
																																		goto IL_0884_2;
																																	case 198:
																																		goto IL_0892_2;
																																	case 226:
																																		goto IL_08a0_2;
																																	case 94:
																																		goto IL_08ae_2;
																																	case 58:
																																	case 158:
																																		goto IL_08b9_2;
																																	case 221:
																																		goto IL_08f9_2;
																																	case 17:
																																		goto IL_090d_2;
																																	case 120:
																																		goto IL_0920_2;
																																	case 62:
																																		goto IL_092e_2;
																																	case 27:
																																	case 182:
																																		goto IL_093c_2;
																																	case 98:
																																		goto IL_094f_2;
																																	case 48:
																																		goto IL_095d_2;
																																	case 72:
																																	case 142:
																																		goto IL_096b_2;
																																	case 129:
																																		goto IL_09cd_2;
																																	case 67:
																																		goto IL_09e0_2;
																																	case 168:
																																		goto IL_09ee_2;
																																	case 64:
																																	case 230:
																																		goto IL_09f9_2;
																																	case 61:
																																		goto IL_0a17_2;
																																	case 225:
																																		goto IL_0a25_2;
																																	case 161:
																																		goto end_IL_040d_2;
																																	case 203:
																																		goto IL_0a4f_2;
																																	case 19:
																																	case 207:
																																		goto IL_0a5d_2;
																																	case 28:
																																		goto end_IL_0521;
																																	case 87:
																																		goto IL_0b22_2;
																																	case 55:
																																		goto IL_0b35_2;
																																	case 149:
																																		goto IL_0b4c_2;
																																	case 166:
																																	case 195:
																																		goto IL_0b5a_2;
																																	case 38:
																																		goto IL_0b83_2;
																																	case 187:
																																		goto IL_0b9c_2;
																																	case 128:
																																		goto IL_0baa_2;
																																	case 189:
																																	case 222:
																																		goto IL_0bb5_2;
																																	case 109:
																																		goto IL_0c07_2;
																																	case 2:
																																		goto IL_0c1a_2;
																																	case 119:
																																		goto IL_0c28_2;
																																	case 116:
																																		goto IL_0c36_2;
																																	case 69:
																																		goto IL_0c44_2;
																																	case 32:
																																	case 165:
																																		goto IL_0c52_2;
																																	case 105:
																																		goto IL_0c93_2;
																																	case 174:
																																		goto IL_0ca7_2;
																																	case 42:
																																		goto IL_0cc3_2;
																																	case 132:
																																	case 194:
																																		goto IL_0cce_2;
																																	case 66:
																																		goto IL_0ce6_2;
																																	case 57:
																																		goto IL_0cf4_2;
																																	case 106:
																																	case 178:
																																		goto IL_0d02_2;
																																	case 100:
																																		goto IL_0d1b_2;
																																	case 164:
																																		goto IL_0d29_2;
																																	case 211:
																																		goto IL_0d37_2;
																																	case 77:
																																		goto IL_0d53_2;
																																	case 14:
																																	case 49:
																																		goto IL_0d67_2;
																																	case 209:
																																		goto IL_0d7b_2;
																																	case 188:
																																		goto IL_0db3_2;
																																	case 118:
																																		goto IL_0dc6_2;
																																	case 154:
																																		goto IL_0dd1_2;
																																	case 177:
																																	case 180:
																																		goto IL_0ddf_2;
																																	case 185:
																																		goto IL_0ded_2;
																																	case 45:
																																		goto IL_0e05_2;
																																	case 153:
																																		goto IL_0e13_2;
																																	case 241:
																																		goto IL_0e26_2;
																																	case 217:
																																		goto IL_0e34_2;
																																	case 127:
																																	case 141:
																																		goto IL_0e42_2;
																																	case 134:
																																		goto IL_0e80_2;
																																	case 91:
																																		goto IL_0e93_2;
																																	case 54:
																																		goto IL_0ea1_2;
																																	case 162:
																																		goto IL_0eaf_2;
																																	case 150:
																																		goto IL_0ebd_2;
																																	case 210:
																																		goto IL_0ecb_2;
																																	case 163:
																																	case 224:
																																		goto IL_0ed9_2;
																																	case 186:
																																		goto IL_0eed_2;
																																	case 193:
																																		goto IL_0f2c_2;
																																	case 201:
																																		goto IL_0f3f_2;
																																	case 47:
																																	case 95:
																																		goto IL_0f4a_2;
																																	case 190:
																																		goto IL_0f63_2;
																																	case 97:
																																		goto IL_0f71_2;
																																	case 205:
																																		goto IL_0f7f_2;
																																	case 88:
																																		goto IL_0f9b_2;
																																	case 214:
																																		goto IL_0fb2_2;
																																	case 60:
																																	case 229:
																																		goto IL_0fc0_2;
																																	case 123:
																																		goto IL_0fe9_2;
																																	case 4:
																																		goto IL_0ff7_2;
																																	case 104:
																																	case 151:
																																		goto IL_100a_2;
																																	case 115:
																																		goto IL_104a_2;
																																	case 152:
																																		goto IL_105e_2;
																																	case 232:
																																		goto IL_1071_2;
																																	case 13:
																																		goto IL_107f_2;
																																	case 167:
																																		goto IL_108a_2;
																																	case 130:
																																		goto IL_1098_2;
																																	case 22:
																																	case 43:
																																		goto IL_10a6_2;
																																	case 34:
																																		goto IL_10ba_2;
																																	case 76:
																																		goto IL_10f9_2;
																																	case 92:
																																	case 184:
																																		goto IL_1109_2;
																																	case 240:
																																		goto IL_1122_2;
																																	case 233:
																																		goto IL_112d_2;
																																	case 7:
																																	case 10:
																																	case 20:
																																	case 30:
																																	case 31:
																																	case 46:
																																	case 50:
																																	case 53:
																																	case 56:
																																	case 63:
																																	case 82:
																																	case 107:
																																	case 111:
																																	case 112:
																																	case 114:
																																	case 117:
																																	case 124:
																																	case 137:
																																	case 140:
																																	case 144:
																																	case 175:
																																	case 176:
																																	case 192:
																																	case 197:
																																	case 199:
																																	case 200:
																																	case 204:
																																	case 208:
																																	case 227:
																																	case 235:
																																	case 238:
																																	case 244:
																																		goto end_IL_045e_2;
																																	case 9:
																																	case 11:
																																	case 21:
																																	case 23:
																																	case 24:
																																	case 35:
																																	case 39:
																																	case 51:
																																	case 59:
																																	case 65:
																																	case 71:
																																	case 73:
																																	case 78:
																																	case 79:
																																	case 85:
																																	case 86:
																																	case 103:
																																	case 113:
																																	case 125:
																																	case 143:
																																	case 146:
																																	case 147:
																																	case 148:
																																	case 155:
																																	case 157:
																																	case 172:
																																	case 213:
																																	case 219:
																																	case 231:
																																	case 236:
																																	case 237:
																																	case 243:
																																		goto IL_1154_2;
																																	case 5:
																																		ptr2 = ptr;
																																		goto IL_1154_2;
																																	case 122:
																																		ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ArgumentItemNotExistgetModuleHandle.IsSynchronizedDisableEvents);
																																		goto case 5;
																																	case 74:
																																		array7 = new object[14];
																																		goto case 122;
																																	case 8:
																																		array6 = new long[4];
																																		goto case 74;
																																	case 52:
																																		array5 = new int[7];
																																		goto case 8;
																																	case 131:
																																		array4 = new int[4];
																																		goto case 52;
																																	case 135:
																																		array3 = new object[4];
																																		goto case 131;
																																	case 173:
																																		array2 = new byte[4];
																																		goto case 135;
																																	case 90:
																																		num4 = num2 * 8;
																																		num = 173;
																																		goto case 173;
																																	case 83:
																																		num3 = num2 * 4;
																																		num = 90;
																																		goto case 90;
																																	case 101:
																																		num2 = 1;
																																		goto case 83;
																																	case 102:
																																		goto end_IL_0b14;
																																	case 3:
																																	case 84:
																																		return;
																																	}
																																	continue;
																																}
																																array3[num6] = null;
																																goto IL_0863_2;
																																IL_0863_2:
																																num6++;
																																goto IL_0871_2;
																																IL_0871_2:
																																ptr2 += 8;
																																goto IL_1154_2;
																																continue;
																																end_IL_040d_2:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0a38_2;
																													continue;
																													end_IL_045e_2:
																													break;
																													IL_045e_2:;
																												}
																												break;
																												IL_046e_2:;
																											}
																											break;
																										}
																										goto IL_0731_2;
																										IL_07df_2:
																										num6--;
																										goto IL_1154_2;
																										IL_0731_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_07c2_2;
																										IL_07c2_2:
																										array2[num6 - 2] = 0;
																										num = 145;
																										goto IL_07df_2;
																									}
																									break;
																								}
																								goto IL_052c_2;
																								IL_0588_2:
																								array2[num6 - 2] = 0;
																								goto IL_0654_2;
																								IL_0654_2:
																								num6--;
																								goto IL_1154_2;
																								IL_052c_2:
																								if (6 < b)
																								{
																									break;
																								}
																								goto IL_053a_2;
																								IL_053a_2:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_0548_2;
																								IL_0548_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0588_2;
																							}
																							break;
																						}
																						goto IL_05e3_2;
																						IL_06e6_2:
																						num6--;
																						goto IL_1154_2;
																						IL_05e3_2:
																						if (3 > b)
																						{
																							goto IL_05f1_2;
																						}
																						goto IL_06af_2;
																						IL_05f1_2:
																						if (1 >= b)
																						{
																							goto IL_05fc_2;
																						}
																						goto IL_060c_2;
																						IL_05fc_2:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_0667_2;
																						IL_0667_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0680_2;
																						IL_0680_2:
																						array2[num6] = 0;
																						goto IL_068e_2;
																						IL_068e_2:
																						num6++;
																						goto IL_069c_2;
																						IL_069c_2:
																						ptr2 += 8;
																						goto IL_1154_2;
																						IL_060c_2:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_061a_2;
																						IL_061a_2:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_07f2_2;
																						IL_07f2_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0832_2;
																						IL_0832_2:
																						array2[num6 - 2] = 0;
																						goto IL_0846_2;
																						IL_0846_2:
																						num6--;
																						goto IL_1154_2;
																						IL_06af_2:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_06d8_2;
																						IL_06d8_2:
																						ptr2 += 8;
																						goto IL_06e6_2;
																					}
																					break;
																				}
																				goto IL_05a1_2;
																				IL_0641_2:
																				num6--;
																				goto IL_1154_2;
																				IL_05a1_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_062d_2;
																				IL_062d_2:
																				array2[num6 - 2] = 0;
																				goto IL_0641_2;
																			}
																			break;
																		}
																		goto IL_0884_2;
																		IL_0b4c_2:
																		if (14 > b)
																		{
																			break;
																		}
																		goto IL_0b5a_2;
																		IL_0884_2:
																		if (11 >= b)
																		{
																			goto IL_0892_2;
																		}
																		goto IL_09e0_2;
																		IL_0892_2:
																		if (11 <= b)
																		{
																			goto IL_1154_2;
																		}
																		goto IL_08a0_2;
																		IL_08a0_2:
																		if (9 >= b)
																		{
																			goto IL_08ae_2;
																		}
																		goto IL_094f_2;
																		IL_08ae_2:
																		if (9 <= b)
																		{
																			goto IL_08b9_2;
																		}
																		goto IL_0920_2;
																		IL_08b9_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_08f9_2;
																		IL_08f9_2:
																		array2[num6 - 2] = 0;
																		goto IL_090d_2;
																		IL_090d_2:
																		num6--;
																		goto IL_1154_2;
																		IL_0920_2:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_092e_2;
																		IL_092e_2:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_093c_2;
																		IL_093c_2:
																		num6--;
																		goto IL_1154_2;
																		IL_094f_2:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_095d_2;
																		IL_095d_2:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_096b_2;
																		IL_096b_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_09cd_2;
																		IL_09cd_2:
																		num6 -= 2;
																		goto IL_1154_2;
																		IL_09e0_2:
																		if (13 >= b)
																		{
																			goto IL_09ee_2;
																		}
																		goto IL_0b35_2;
																		IL_09ee_2:
																		if (13 <= b)
																		{
																			goto IL_09f9_2;
																		}
																		goto IL_0a38_2;
																		IL_09f9_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_0a17_2;
																		IL_0a17_2:
																		ptr2 += 8;
																		goto IL_0a25_2;
																		IL_0a25_2:
																		num6--;
																		goto IL_1154_2;
																		IL_0a38_2:
																		if (12 < b)
																		{
																			break;
																		}
																		num = 203;
																		goto IL_0a4f_2;
																		IL_0b5a_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_0b83_2;
																		IL_0a4f_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0a5d_2;
																		IL_0a5d_2:
																		array8 = array3;
																		num7 = num6;
																		if (array == null)
																		{
																			goto IL_0a6c_2;
																		}
																		goto IL_0a7a;
																		IL_0b35_2:
																		if (14 < b)
																		{
																			break;
																		}
																		num = 149;
																		goto IL_0b4c_2;
																		IL_0b83_2:
																		array2[num6 - 1] = 5;
																		goto IL_1154_2;
																	}
																	break;
																}
																goto IL_06f9_2;
																IL_07af_2:
																num6++;
																goto IL_1154_2;
																IL_06f9_2:
																array2[num6] = array2[num6 - 1];
																goto IL_0711_2;
																IL_0711_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_0773_2;
																IL_0773_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0797_2;
																IL_0797_2:
																array3[num6] = array3[num6 - 1];
																goto IL_07af_2;
															}
															break;
														}
														goto IL_0b9c_2;
														IL_10ba_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_10f9_2;
														IL_0b9c_2:
														if (22 >= b)
														{
															goto IL_0baa_2;
														}
														goto IL_0e93_2;
														IL_0baa_2:
														if (22 <= b)
														{
															goto IL_0bb5_2;
														}
														goto IL_0c1a_2;
														IL_0bb5_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0c07_2;
														IL_0c07_2:
														num6--;
														goto IL_1154_2;
														IL_0c1a_2:
														if (18 < b)
														{
															goto IL_0c28_2;
														}
														num = 77;
														goto IL_0d53_2;
														IL_0c28_2:
														if (20 < b)
														{
															goto IL_0c36_2;
														}
														num = 42;
														goto IL_0cc3_2;
														IL_0c36_2:
														if (21 < b)
														{
															break;
														}
														goto IL_0c44_2;
														IL_0c44_2:
														if (21 > b)
														{
															break;
														}
														goto IL_0c52_2;
														IL_0c52_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_0c93_2;
														IL_0c93_2:
														array2[num6 - 2] = 0;
														goto IL_0ca7_2;
														IL_0ca7_2:
														num6--;
														goto IL_1154_2;
														IL_1109_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto IL_1154_2;
														IL_0cc3_2:
														if (20 <= b)
														{
															goto IL_0cce_2;
														}
														goto IL_0ce6_2;
														IL_0cce_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_1154_2;
														IL_0ce6_2:
														if (19 < b)
														{
															break;
														}
														goto IL_0cf4_2;
														IL_0cf4_2:
														if (19 > b)
														{
															break;
														}
														goto IL_0d02_2;
														IL_0d02_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_0d1b_2;
														IL_0d1b_2:
														array2[num6] = 1;
														goto IL_0d29_2;
														IL_0d29_2:
														num6++;
														goto IL_0d37_2;
														IL_0d37_2:
														ptr2 += 16;
														goto IL_1154_2;
														IL_10f9_2:
														ptr2 += 8;
														goto IL_1154_2;
														IL_0d53_2:
														if (18 <= b)
														{
															num = 49;
															goto IL_0d67_2;
														}
														goto IL_0dc6_2;
														IL_1122_2:
														if (29 < b)
														{
															break;
														}
														goto IL_112d_2;
														IL_0d67_2:
														array2[num6 - 1] = 5;
														goto IL_0d7b_2;
														IL_0d7b_2:
														array3[num6 - 1] = ((delegate*<string[], string>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_0db3_2;
														IL_0db3_2:
														ptr2 += 8;
														goto IL_1154_2;
														IL_0dc6_2:
														if (16 >= b)
														{
															goto IL_0dd1_2;
														}
														goto IL_0e26_2;
														IL_0dd1_2:
														if (16 > b)
														{
															break;
														}
														goto IL_0ddf_2;
														IL_0ddf_2:
														array2[num6] = 5;
														goto IL_0ded_2;
														IL_0ded_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_0e05_2;
														IL_0e05_2:
														num6++;
														goto IL_0e13_2;
														IL_0e13_2:
														ptr2 += 8;
														goto IL_1154_2;
														IL_0e26_2:
														if (17 < b)
														{
															break;
														}
														goto IL_0e34_2;
														IL_0e34_2:
														if (17 > b)
														{
															break;
														}
														goto IL_0e42_2;
														IL_0e42_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_0e80_2;
														IL_0e80_2:
														num6 -= 3;
														goto IL_1154_2;
														IL_0e93_2:
														if (26 >= b)
														{
															goto IL_0ea1_2;
														}
														goto IL_1071_2;
														IL_0ea1_2:
														if (26 > b)
														{
															goto IL_0eaf_2;
														}
														goto IL_100a_2;
														IL_0eaf_2:
														if (24 < b)
														{
															goto IL_0ebd_2;
														}
														goto IL_0f3f_2;
														IL_0ebd_2:
														if (25 < b)
														{
															break;
														}
														goto IL_0ecb_2;
														IL_0ecb_2:
														if (25 > b)
														{
															break;
														}
														goto IL_0ed9_2;
														IL_0ed9_2:
														array2[num6 - 1] = 3;
														goto IL_0eed_2;
														IL_0eed_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_0f2c_2;
														IL_0f2c_2:
														ptr2 += 8;
														goto IL_1154_2;
														IL_0f3f_2:
														if (24 <= b)
														{
															goto IL_0f4a_2;
														}
														goto IL_0f9b_2;
														IL_0f4a_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_0f63_2;
														IL_0f63_2:
														array2[num6] = 3;
														goto IL_0f71_2;
														IL_0f71_2:
														num6++;
														goto IL_0f7f_2;
														IL_0f7f_2:
														ptr2 += 16;
														num = 243;
														goto IL_1154_2;
														IL_0f9b_2:
														if (23 < b)
														{
															break;
														}
														num = 214;
														goto IL_0fb2_2;
														IL_112d_2:
														if (29 <= b)
														{
															num = 144;
														}
														break;
														IL_0fb2_2:
														if (23 > b)
														{
															break;
														}
														goto IL_0fc0_2;
														IL_0fc0_2:
														((delegate*<string, void>)FormIdnaCreateSubKey[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_0fe9_2;
														IL_0fe9_2:
														num6--;
														goto IL_0ff7_2;
														IL_0ff7_2:
														ptr2 += 8;
														goto IL_1154_2;
														IL_100a_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_104a_2;
														IL_104a_2:
														array2[num6 - 2] = 3;
														goto IL_105e_2;
														IL_105e_2:
														num6--;
														goto IL_1154_2;
														IL_1071_2:
														if (28 >= b)
														{
															goto IL_107f_2;
														}
														goto IL_1122_2;
														IL_107f_2:
														if (28 > b)
														{
															goto IL_108a_2;
														}
														goto IL_1109_2;
														IL_108a_2:
														if (27 < b)
														{
															break;
														}
														goto IL_1098_2;
														IL_1098_2:
														if (27 > b)
														{
															break;
														}
														goto IL_10a6_2;
														IL_10a6_2:
														array2[num6 - 1] = 0;
														goto IL_10ba_2;
													}
													break;
													IL_04f1_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_1154_2;
											continue;
											end_IL_0501_2:
											break;
										}
										continue;
										end_IL_0511:
										break;
									}
									continue;
									end_IL_0521:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0b14:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_0)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 32;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CheckNameHEBREW.TimeZoneInfoActivityControl);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02a8:
															num = 22;
															while (true)
															{
																IL_029d:
																byte b = *ptr2;
																while (true)
																{
																	IL_028d:
																	ptr2++;
																	while (true)
																	{
																		IL_027d:
																		if (b >= 1)
																		{
																			while (b <= 10)
																			{
																				while (true)
																				{
																					IL_025d:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0250:
																							if (5 <= b)
																							{
																								while (true)
																								{
																									IL_0240:
																									array[num5] = 0;
																									while (true)
																									{
																										IL_021b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										while (true)
																										{
																											IL_020f:
																											array2[num5] = null;
																											while (true)
																											{
																												IL_01ff:
																												num5++;
																												while (true)
																												{
																													IL_01e6:
																													ptr2 += 8;
																													num = 113;
																													while (num != 113 && num == 1094)
																													{
																														switch (num)
																														{
																														case 43:
																															goto IL_01e6;
																														case 96:
																															goto IL_01ff;
																														case 31:
																															goto IL_020f;
																														case 98:
																															goto IL_021b;
																														case 48:
																														case 67:
																															goto IL_0240;
																														case 61:
																															goto IL_0250;
																														case 75:
																															goto IL_025d;
																														case 49:
																															goto IL_026d;
																														case 80:
																															goto IL_027d;
																														case 97:
																															goto IL_028d;
																														case 22:
																															goto IL_029d;
																														case 63:
																															goto IL_02a8;
																														case 72:
																														case 78:
																															goto IL_02b3;
																														case 34:
																															goto IL_02be;
																														case 0:
																															goto IL_02d1;
																														case 27:
																															goto IL_02df;
																														case 17:
																														case 82:
																															goto IL_02ed;
																														case 18:
																														case 85:
																															goto IL_0305;
																														case 46:
																														case 81:
																															goto IL_0310;
																														case 12:
																														case 41:
																															goto IL_031e;
																														case 66:
																															goto IL_032c;
																														case 86:
																															goto IL_033f;
																														case 13:
																														case 23:
																															goto IL_034d;
																														case 90:
																															goto IL_03b1;
																														case 11:
																														case 45:
																															goto IL_03bf;
																														case 91:
																															goto IL_03db;
																														case 39:
																															goto IL_03e9;
																														case 95:
																															goto IL_03fc;
																														case 102:
																															goto IL_040f;
																														case 44:
																															goto IL_041a;
																														case 19:
																														case 24:
																															goto IL_0428;
																														case 36:
																															goto IL_0468;
																														case 40:
																															goto IL_047c;
																														case 88:
																															goto IL_048f;
																														case 69:
																															goto IL_049d;
																														case 21:
																														case 70:
																															goto IL_04ab;
																														case 87:
																															goto IL_04ce;
																														case 50:
																															goto IL_04dc;
																														case 37:
																															goto IL_04ea;
																														case 8:
																														case 103:
																															goto IL_04fd;
																														case 74:
																															goto IL_0526;
																														case 64:
																															goto IL_0534;
																														case 106:
																															goto IL_0547;
																														case 7:
																															goto IL_0552;
																														case 54:
																														case 71:
																															goto IL_055d;
																														case 89:
																															goto IL_0576;
																														case 76:
																															goto IL_0584;
																														case 92:
																															goto IL_059b;
																														case 1:
																														case 2:
																														case 10:
																														case 15:
																														case 16:
																														case 26:
																														case 29:
																														case 33:
																														case 35:
																														case 47:
																														case 55:
																														case 57:
																														case 58:
																														case 60:
																														case 65:
																														case 83:
																														case 84:
																														case 93:
																														case 94:
																														case 99:
																														case 100:
																														case 101:
																															goto end_IL_026d;
																														case 3:
																														case 9:
																														case 14:
																														case 20:
																														case 25:
																														case 38:
																														case 42:
																														case 51:
																														case 53:
																														case 59:
																														case 62:
																														case 105:
																															goto end_IL_01d3;
																														case 52:
																															goto end_IL_05c7;
																														case 68:
																															goto end_IL_05da;
																														case 79:
																															goto end_IL_05e4;
																														case 73:
																															goto end_IL_05ef;
																														case 32:
																															goto end_IL_0604;
																														case 56:
																															goto end_IL_0614;
																														case 4:
																															goto end_IL_0624;
																														case 30:
																														case 104:
																															goto end_IL_062f;
																														case 5:
																															goto end_IL_063f;
																														case 6:
																															goto end_IL_064f;
																														case 28:
																														case 77:
																															goto IL_0673;
																														}
																														continue;
																														end_IL_01d3:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_02b3;
																							IL_03db:
																							if (4 < b)
																							{
																								goto end_IL_026d;
																							}
																							goto IL_03e9;
																							IL_02b3:
																							if (2 >= b)
																							{
																								goto IL_02be;
																							}
																							goto IL_02d1;
																							IL_02be:
																							if (2 <= b)
																							{
																								goto IL_04fd;
																							}
																							goto IL_0547;
																							IL_04fd:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0526;
																							IL_0526:
																							ptr2 += 8;
																							goto IL_0534;
																							IL_0534:
																							num5--;
																							break;
																							IL_0547:
																							if (1 < b)
																							{
																								num = 101;
																								goto end_IL_026d;
																							}
																							goto IL_0552;
																							IL_0552:
																							if (1 > b)
																							{
																								goto end_IL_026d;
																							}
																							goto IL_055d;
																							IL_055d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0576;
																							IL_0576:
																							array[num5] = 0;
																							goto IL_0584;
																							IL_0584:
																							num5++;
																							num = 92;
																							goto IL_059b;
																							IL_059b:
																							ptr2 += 8;
																							break;
																							IL_03e9:
																							if (4 <= b)
																							{
																								break;
																							}
																							goto end_IL_026d;
																							IL_02d1:
																							if (3 >= b)
																							{
																								goto IL_02df;
																							}
																							goto IL_03db;
																							IL_02df:
																							if (3 > b)
																							{
																								goto end_IL_026d;
																							}
																							goto IL_02ed;
																							IL_02ed:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																						}
																						break;
																					}
																					goto IL_0305;
																					IL_04ea:
																					ptr2 += 8;
																					break;
																					IL_0305:
																					if (8 < b)
																					{
																						goto IL_0310;
																					}
																					goto IL_033f;
																					IL_0310:
																					if (9 < b)
																					{
																						goto IL_031e;
																					}
																					goto IL_03b1;
																					IL_031e:
																					if (10 < b)
																					{
																						goto end_IL_026d;
																					}
																					goto IL_032c;
																					IL_032c:
																					if (10 <= b)
																					{
																					}
																					goto end_IL_026d;
																					IL_03b1:
																					if (9 > b)
																					{
																						goto end_IL_026d;
																					}
																					goto IL_03bf;
																					IL_03bf:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_033f:
																					if (8 <= b)
																					{
																						goto IL_034d;
																					}
																					goto IL_040f;
																					IL_034d:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03fc;
																					IL_03fc:
																					num5 -= 2;
																					break;
																					IL_040f:
																					if (6 >= b)
																					{
																						goto IL_041a;
																					}
																					goto IL_048f;
																					IL_041a:
																					if (6 > b)
																					{
																						goto end_IL_026d;
																					}
																					goto IL_0428;
																					IL_0428:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0468;
																					IL_0468:
																					array[num5 - 2] = 0;
																					goto IL_047c;
																					IL_047c:
																					num5--;
																					break;
																					IL_048f:
																					if (7 < b)
																					{
																						goto end_IL_026d;
																					}
																					goto IL_049d;
																					IL_049d:
																					if (7 > b)
																					{
																						goto end_IL_026d;
																					}
																					goto IL_04ab;
																					IL_04ab:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_04ce;
																					IL_04ce:
																					array[num5] = 0;
																					goto IL_04dc;
																					IL_04dc:
																					num5++;
																					goto IL_04ea;
																				}
																				goto end_IL_027d;
																				continue;
																				end_IL_026d:
																				break;
																				IL_026d:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_027d:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 28;
													goto IL_0673;
													IL_0673:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05c7:
													break;
												}
												continue;
												end_IL_05da:
												break;
											}
											continue;
											end_IL_05e4:
											break;
										}
										continue;
										end_IL_05ef:
										break;
									}
									continue;
									end_IL_0604:
									break;
								}
								continue;
								end_IL_0614:
								break;
							}
							continue;
							end_IL_0624:
							break;
						}
						continue;
						end_IL_062f:
						break;
					}
					continue;
					end_IL_063f:
					break;
				}
				continue;
				end_IL_064f:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 13;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 79;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRightssetTask.setCompoundAceTypeOemPlus);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 95;
												while (true)
												{
													if (num == 95)
													{
														goto IL_024a;
													}
													if (num != 1076)
													{
														goto IL_04d2;
													}
													switch (num)
													{
													case 25:
														goto end_IL_018b;
													case 61:
														goto end_IL_019e;
													case 20:
														goto end_IL_01b1;
													case 26:
														goto end_IL_01bc;
													case 59:
														goto end_IL_01d1;
													case 67:
													case 78:
														goto end_IL_01e6;
													case 79:
														goto end_IL_01f6;
													case 29:
													case 63:
														goto end_IL_0206;
													case 12:
														goto end_IL_0216;
													case 13:
														goto end_IL_022f;
													case 14:
													case 15:
													case 36:
													case 37:
													case 38:
													case 46:
													case 50:
													case 65:
													case 68:
													case 83:
														goto IL_024a;
													case 75:
													case 87:
														goto IL_025a;
													case 17:
														goto IL_0263;
													case 10:
														goto IL_0271;
													case 86:
														goto IL_027f;
													case 45:
														goto IL_028d;
													case 0:
													case 1:
														goto IL_029b;
													case 34:
														goto IL_02a6;
													case 72:
														goto IL_02b1;
													case 40:
														goto IL_02bf;
													case 9:
													case 28:
														goto IL_02cd;
													case 71:
														goto IL_02e5;
													case 21:
														goto IL_02f0;
													case 69:
														goto IL_02fe;
													case 16:
													case 48:
														goto IL_030c;
													case 11:
														goto IL_0328;
													case 42:
													case 56:
														goto IL_0336;
													case 81:
														goto IL_0344;
													case 8:
														goto IL_0367;
													case 39:
														goto IL_037a;
													case 57:
														goto IL_0388;
													case 73:
														goto IL_03a4;
													case 19:
													case 35:
														goto IL_03b2;
													case 22:
													case 51:
														goto IL_03c0;
													case 31:
														goto IL_03ce;
													case 47:
													case 54:
														goto IL_03dc;
													case 82:
														goto IL_041c;
													case 49:
														goto IL_0430;
													case 62:
														goto IL_0443;
													case 2:
													case 18:
														goto IL_0451;
													case 23:
														goto IL_04bf;
													case 30:
													case 64:
														goto IL_04d2;
													case 7:
														goto IL_04e0;
													case 74:
													case 84:
														goto IL_04f3;
													case 80:
														goto IL_051c;
													case 66:
														goto IL_052a;
													case 55:
														goto IL_053d;
													case 41:
														goto IL_054b;
													case 85:
														goto IL_0559;
													case 3:
													case 4:
													case 5:
													case 6:
													case 24:
													case 27:
													case 32:
													case 33:
													case 44:
													case 52:
													case 53:
													case 58:
													case 60:
													case 76:
													case 77:
													case 88:
														goto IL_0575;
													case 43:
													case 70:
														goto IL_059a;
													}
													continue;
													IL_054b:
													num4++;
													goto IL_0559;
													IL_0559:
													ptr2 += 8;
													num = 14;
													goto IL_024a;
													IL_024a:
													if (num5 != 1)
													{
														goto IL_025a;
													}
													goto IL_059a;
													IL_059a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_025a:
													b = *ptr2;
													goto IL_0263;
													IL_0263:
													ptr2++;
													goto IL_0271;
													IL_0271:
													if (b >= 1)
													{
														goto IL_027f;
													}
													goto IL_0575;
													IL_027f:
													if (b <= 8)
													{
														goto IL_028d;
													}
													goto IL_0575;
													IL_028d:
													if (4 < b)
													{
														goto IL_029b;
													}
													goto IL_03a4;
													IL_029b:
													if (6 >= b)
													{
														goto IL_02a6;
													}
													goto IL_02e5;
													IL_02a6:
													if (6 <= b)
													{
														goto IL_024a;
													}
													goto IL_02b1;
													IL_02b1:
													if (5 >= b)
													{
														goto IL_02bf;
													}
													goto IL_0575;
													IL_02bf:
													if (5 <= b)
													{
														goto IL_02cd;
													}
													goto IL_0575;
													IL_02cd:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_024a;
													IL_02e5:
													if (7 < b)
													{
														goto IL_02f0;
													}
													goto IL_0328;
													IL_02f0:
													if (8 >= b)
													{
														goto IL_02fe;
													}
													goto IL_0575;
													IL_02fe:
													if (8 <= b)
													{
														goto IL_030c;
													}
													goto IL_0575;
													IL_030c:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_024a;
													IL_0328:
													if (7 <= b)
													{
														goto IL_0336;
													}
													goto IL_0575;
													IL_0336:
													array[num4] = 0;
													goto IL_0344;
													IL_0344:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0367;
													IL_0367:
													array2[num4] = null;
													num = 39;
													goto IL_037a;
													IL_037a:
													num4++;
													goto IL_0388;
													IL_0388:
													ptr2 += 8;
													num = 38;
													goto IL_024a;
													IL_03a4:
													if (4 > b)
													{
														goto IL_03b2;
													}
													goto IL_04f3;
													IL_03b2:
													if (2 < b)
													{
														goto IL_03c0;
													}
													goto IL_0443;
													IL_03c0:
													if (3 >= b)
													{
														goto IL_03ce;
													}
													goto IL_0575;
													IL_03ce:
													if (3 <= b)
													{
														goto IL_03dc;
													}
													goto IL_0575;
													IL_03dc:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_041c;
													IL_041c:
													array[num4 - 2] = 0;
													goto IL_0430;
													IL_0430:
													num4--;
													goto IL_024a;
													IL_0443:
													if (2 <= b)
													{
														goto IL_0451;
													}
													goto IL_04d2;
													IL_0451:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_04bf;
													IL_04bf:
													num4 -= 2;
													goto IL_024a;
													IL_04d2:
													if (1 >= b)
													{
														goto IL_04e0;
													}
													goto IL_0575;
													IL_04e0:
													if (1 > b)
													{
													}
													goto IL_0575;
													IL_04f3:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_051c;
													IL_051c:
													ptr2 += 8;
													goto IL_052a;
													IL_052a:
													num4--;
													goto IL_024a;
													IL_0575:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_053d;
													IL_053d:
													array[num4] = 0;
													goto IL_054b;
													continue;
													end_IL_018b:
													break;
												}
												continue;
												end_IL_019e:
												break;
											}
											continue;
											end_IL_01b1:
											break;
										}
										continue;
										end_IL_01bc:
										break;
									}
									continue;
									end_IL_01d1:
									break;
								}
								continue;
								end_IL_01e6:
								break;
							}
							continue;
							end_IL_01f6:
							break;
						}
						continue;
						end_IL_0206:
						break;
					}
					continue;
					end_IL_0216:
					break;
				}
				continue;
				end_IL_022f:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0, int int_1)
	{
		int num = 50;
		byte* ptr2 = default(byte*);
		byte b = default(byte);
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										num = 54;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StandardDangerousAddRef.LetterNumbergetXmlElementName);
											num = 110;
											while (true)
											{
												if (num != 110)
												{
													if (num != 1091)
													{
														goto IL_06c0;
													}
													switch (num)
													{
													case 54:
														goto end_IL_01c7;
													case 83:
														goto end_IL_01da;
													case 76:
														goto end_IL_01ee;
													case 86:
														goto end_IL_020c;
													case 17:
													case 93:
														goto end_IL_0221;
													case 32:
														goto end_IL_0231;
													case 7:
													case 75:
														goto end_IL_0241;
													case 49:
														goto end_IL_0251;
													case 50:
														goto end_IL_0261;
													case 3:
													case 9:
													case 15:
													case 20:
													case 27:
													case 39:
													case 48:
													case 66:
													case 71:
													case 73:
													case 91:
														goto IL_0284;
													case 29:
													case 68:
														goto IL_0294;
													case 80:
														goto IL_029d;
													case 23:
														goto IL_02ab;
													case 13:
														goto IL_02c2;
													case 101:
														goto IL_02d0;
													case 99:
														goto IL_02de;
													case 61:
														goto IL_02ec;
													case 47:
													case 72:
														goto IL_02fa;
													case 56:
														goto IL_0305;
													case 53:
													case 95:
														goto IL_0313;
													case 12:
														goto IL_033c;
													case 42:
														goto IL_034a;
													case 35:
														goto IL_035d;
													case 63:
														goto IL_036b;
													case 5:
													case 74:
														goto IL_0382;
													case 8:
														goto IL_03c2;
													case 4:
														goto IL_03d6;
													case 78:
														goto IL_03e9;
													case 44:
													case 55:
														goto IL_03f4;
													case 22:
														goto IL_0402;
													case 6:
													case 77:
														goto IL_0415;
													case 14:
														goto IL_0455;
													case 102:
														goto IL_0469;
													case 43:
													case 92:
														goto IL_047c;
													case 37:
														goto IL_048a;
													case 18:
														goto IL_04b6;
													case 21:
														goto IL_04c0;
													case 40:
														goto IL_04ce;
													case 96:
														goto IL_04e1;
													case 79:
														goto IL_04ef;
													case 0:
													case 26:
														goto IL_04fa;
													case 97:
														goto IL_0513;
													case 62:
														goto IL_052a;
													case 60:
														goto IL_0538;
													case 28:
													case 67:
														goto IL_0554;
													case 88:
														goto IL_0562;
													case 31:
													case 87:
														goto IL_0570;
													case 98:
														goto IL_05b0;
													case 85:
														goto IL_05c4;
													case 10:
														goto IL_05d7;
													case 45:
														goto IL_05e2;
													case 51:
													case 70:
														goto IL_05ed;
													case 103:
														goto IL_062d;
													case 34:
														goto IL_0641;
													case 94:
														goto IL_065f;
													case 25:
														goto IL_066a;
													case 52:
													case 65:
														goto IL_0675;
													case 46:
														goto IL_0691;
													case 89:
														goto IL_069f;
													case 24:
														goto IL_06ad;
													case 2:
													case 11:
													case 16:
													case 19:
													case 30:
													case 33:
													case 36:
													case 38:
													case 41:
													case 57:
													case 58:
													case 59:
													case 64:
													case 69:
													case 81:
													case 82:
													case 84:
													case 90:
														goto IL_06c0;
													case 1:
													case 100:
														goto IL_06e5;
													}
													continue;
												}
												ptr2 = ptr;
												goto IL_0284;
												IL_065f:
												if (9 >= b)
												{
													goto IL_066a;
												}
												goto IL_06c0;
												IL_0675:
												byte* num4 = ptr2;
												num5 = 1;
												ptr2 = num4 + -200;
												goto IL_0284;
												IL_066a:
												if (9 <= b)
												{
													goto IL_0675;
												}
												goto IL_06c0;
												IL_0284:
												if (num5 != 1)
												{
													goto IL_0294;
												}
												goto IL_06e5;
												IL_06e5:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												IL_0294:
												b = *ptr2;
												goto IL_029d;
												IL_029d:
												ptr2++;
												goto IL_02ab;
												IL_02ab:
												if (b >= 1)
												{
													num = 13;
													goto IL_02c2;
												}
												goto IL_06c0;
												IL_06c0:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0691;
												IL_02c2:
												if (b <= 9)
												{
													goto IL_02d0;
												}
												goto IL_06c0;
												IL_02d0:
												if (5 >= b)
												{
													goto IL_02de;
												}
												goto IL_04e1;
												IL_02de:
												if (5 > b)
												{
													goto IL_02ec;
												}
												goto IL_047c;
												IL_02ec:
												if (2 < b)
												{
													goto IL_02fa;
												}
												goto IL_03e9;
												IL_02fa:
												if (3 >= b)
												{
													goto IL_0305;
												}
												goto IL_035d;
												IL_0305:
												if (3 <= b)
												{
													goto IL_0313;
												}
												goto IL_06c0;
												IL_0313:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												goto IL_033c;
												IL_033c:
												ptr2 += 8;
												goto IL_034a;
												IL_034a:
												num6--;
												goto IL_0284;
												IL_035d:
												if (4 >= b)
												{
													goto IL_036b;
												}
												goto IL_06c0;
												IL_036b:
												if (4 <= b)
												{
													num = 5;
													goto IL_0382;
												}
												goto IL_06c0;
												IL_0691:
												array[num6] = 0;
												goto IL_069f;
												IL_0382:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												goto IL_03c2;
												IL_03c2:
												array[num6 - 2] = 0;
												goto IL_03d6;
												IL_03d6:
												num6--;
												goto IL_0284;
												IL_03e9:
												if (2 > b)
												{
													goto IL_03f4;
												}
												goto IL_0415;
												IL_03f4:
												if (1 >= b)
												{
													goto IL_0402;
												}
												goto IL_06c0;
												IL_0402:
												if (1 > b)
												{
												}
												goto IL_06c0;
												IL_0415:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												goto IL_0455;
												IL_0455:
												array[num6 - 2] = 0;
												goto IL_0469;
												IL_0469:
												num6--;
												goto IL_0284;
												IL_047c:
												array[num6] = 0;
												goto IL_048a;
												IL_048a:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
												num = 18;
												goto IL_04b6;
												IL_04b6:
												array2[num6] = null;
												goto IL_04c0;
												IL_04c0:
												num6++;
												goto IL_04ce;
												IL_04ce:
												ptr2 += 8;
												goto IL_0284;
												IL_04e1:
												if (7 >= b)
												{
													goto IL_04ef;
												}
												goto IL_05d7;
												IL_04ef:
												if (7 <= b)
												{
													goto IL_04fa;
												}
												num = 67;
												goto IL_0554;
												IL_04fa:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
												goto IL_0513;
												IL_0513:
												array[num6] = 0;
												num = 62;
												goto IL_052a;
												IL_052a:
												num6++;
												goto IL_0538;
												IL_0538:
												ptr2 += 8;
												goto IL_0284;
												IL_069f:
												num6++;
												goto IL_06ad;
												IL_0554:
												if (6 >= b)
												{
													goto IL_0562;
												}
												goto IL_06c0;
												IL_0562:
												if (6 <= b)
												{
													goto IL_0570;
												}
												goto IL_06c0;
												IL_0570:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												goto IL_05b0;
												IL_05b0:
												array[num6 - 2] = 0;
												goto IL_05c4;
												IL_05c4:
												num6--;
												goto IL_0284;
												IL_05d7:
												if (8 >= b)
												{
													goto IL_05e2;
												}
												goto IL_065f;
												IL_05e2:
												if (8 <= b)
												{
													goto IL_05ed;
												}
												num = 81;
												goto IL_06c0;
												IL_05ed:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												goto IL_062d;
												IL_062d:
												array[num6 - 2] = 0;
												goto IL_0641;
												IL_0641:
												num6--;
												goto IL_0284;
												IL_06ad:
												ptr2 += 8;
												goto IL_0284;
												continue;
												end_IL_01c7:
												break;
											}
											continue;
											end_IL_01da:
											break;
										}
										continue;
										end_IL_01ee:
										break;
									}
									continue;
									end_IL_020c:
									break;
								}
								continue;
								end_IL_0221:
								break;
							}
							continue;
							end_IL_0231:
							break;
						}
						continue;
						end_IL_0241:
						break;
					}
					continue;
					end_IL_0251:
					break;
				}
				continue;
				end_IL_0261:
				break;
			}
		}
	}

	public Class200()
	{
		object obj = this;
		List<Player> list = new List<Player>();
		((Class200)obj).list_0 = list;
		obj = this;
		Dictionary<int, GameObject> dictionary = new Dictionary<int, GameObject>();
		((Class200)obj).dictionary_0 = dictionary;
		obj = this;
		Dictionary<int, float> dictionary2 = new Dictionary<int, float>();
		((Class200)obj).dictionary_1 = dictionary2;
		obj = this;
		Dictionary<int, float> dictionary3 = new Dictionary<int, float>();
		((Class200)obj).dictionary_2 = dictionary3;
		obj = this;
		Dictionary<int, bool> dictionary4 = new Dictionary<int, bool>();
		((Class200)obj).dictionary_3 = dictionary4;
	}

	private static int DESCryptoServiceProviderClientReceive(int int_0)
	{
		return smethod_6(int_0);
	}

	private unsafe static int smethod_6(int int_0)
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HexStaticMethodOnly.GetComSlotForMethodInfoMuiResourceIdLookupMapCount);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02fe:
														byte b = *ptr2;
														while (true)
														{
															IL_02e5:
															ptr2++;
															num = 24;
															while (true)
															{
																IL_02d5:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_02b5:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02a8:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0298:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_028b:
																									if (5 >= b)
																									{
																										while (true)
																										{
																											IL_0278:
																											if (5 > b)
																											{
																												num = 146;
																												while (true)
																												{
																													if (num != 146)
																													{
																														if (num != 1127)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 55:
																															goto IL_0278;
																														case 53:
																														case 66:
																															goto IL_028b;
																														case 77:
																															goto IL_0298;
																														case 72:
																															goto IL_02a8;
																														case 99:
																															goto IL_02b5;
																														case 46:
																															goto IL_02c5;
																														case 24:
																															goto IL_02d5;
																														case 138:
																															goto IL_02e5;
																														case 54:
																														case 79:
																															goto IL_02fe;
																														case 47:
																															goto IL_0309;
																														case 18:
																														case 60:
																															goto IL_031c;
																														case 32:
																															goto IL_035c;
																														case 42:
																														case 81:
																															goto IL_037b;
																														case 44:
																														case 89:
																															goto IL_0389;
																														case 68:
																															goto IL_0397;
																														case 94:
																															goto IL_03a4;
																														case 69:
																														case 96:
																															goto IL_03b7;
																														case 75:
																															goto IL_03c5;
																														case 25:
																														case 36:
																															goto IL_03d3;
																														case 23:
																														case 106:
																															goto IL_03e6;
																														case 116:
																															goto IL_040b;
																														case 126:
																															goto IL_041e;
																														case 63:
																														case 105:
																															goto IL_0429;
																														case 39:
																															goto IL_043d;
																														case 102:
																															goto IL_047c;
																														case 9:
																															goto IL_048f;
																														case 83:
																														case 101:
																															goto IL_049a;
																														case 0:
																															goto IL_04ad;
																														case 48:
																														case 67:
																															goto IL_04bb;
																														case 8:
																															goto IL_04c9;
																														case 20:
																														case 70:
																															goto IL_04d7;
																														case 62:
																															goto IL_04fa;
																														case 64:
																															goto IL_0511;
																														case 115:
																															goto IL_051f;
																														case 133:
																															goto IL_0532;
																														case 95:
																														case 104:
																															goto IL_0540;
																														case 65:
																															goto IL_0580;
																														case 119:
																															goto IL_0594;
																														case 56:
																														case 134:
																															goto IL_05a7;
																														case 122:
																															goto IL_05e7;
																														case 2:
																															goto IL_0604;
																														case 29:
																														case 136:
																															goto IL_0617;
																														case 16:
																															goto IL_0679;
																														case 17:
																														case 137:
																															goto IL_068c;
																														case 82:
																															goto IL_06a3;
																														case 37:
																															goto IL_06b6;
																														case 109:
																															goto IL_06c4;
																														case 41:
																														case 131:
																															goto IL_06d7;
																														case 100:
																															goto IL_06e5;
																														case 124:
																															goto IL_0708;
																														case 97:
																															goto IL_0712;
																														case 58:
																															goto IL_0729;
																														case 15:
																															goto IL_073c;
																														case 5:
																														case 120:
																															goto IL_074a;
																														case 127:
																															goto IL_0755;
																														case 50:
																														case 71:
																															goto IL_0763;
																														case 121:
																															goto IL_077c;
																														case 28:
																															goto IL_078a;
																														case 114:
																															goto IL_0798;
																														case 112:
																															goto IL_07b4;
																														case 10:
																															goto IL_07bf;
																														case 51:
																														case 128:
																															goto IL_07ca;
																														case 13:
																															goto IL_07f3;
																														case 111:
																															goto IL_0801;
																														case 49:
																														case 125:
																															goto IL_0811;
																														case 1:
																														case 11:
																														case 21:
																														case 26:
																														case 30:
																														case 31:
																														case 33:
																														case 34:
																														case 40:
																														case 43:
																														case 45:
																														case 59:
																														case 73:
																														case 78:
																														case 80:
																														case 84:
																														case 86:
																														case 90:
																														case 91:
																														case 93:
																														case 108:
																														case 129:
																														case 130:
																														case 135:
																															goto end_IL_02c5;
																														case 3:
																														case 4:
																														case 12:
																														case 19:
																														case 22:
																														case 27:
																														case 52:
																														case 57:
																														case 61:
																														case 74:
																														case 87:
																														case 88:
																														case 92:
																														case 107:
																														case 110:
																														case 118:
																														case 139:
																															goto end_IL_0265;
																														case 123:
																															goto end_IL_0839;
																														case 113:
																															goto end_IL_084c;
																														case 85:
																															goto end_IL_0856;
																														case 103:
																															goto end_IL_0861;
																														case 76:
																														case 98:
																															goto end_IL_0876;
																														case 38:
																															goto end_IL_0886;
																														case 14:
																														case 35:
																															goto end_IL_0896;
																														case 6:
																															goto end_IL_08a6;
																														case 7:
																															goto end_IL_08b6;
																														case 117:
																														case 132:
																															goto IL_08da;
																														}
																														continue;
																													}
																													goto IL_06b6;
																													IL_06b6:
																													if (4 < b)
																													{
																														goto end_IL_02c5;
																													}
																													goto IL_06c4;
																													IL_06c4:
																													if (4 > b)
																													{
																														goto end_IL_02c5;
																													}
																													break;
																													continue;
																													end_IL_0265:
																													break;
																												}
																												break;
																											}
																											goto IL_06d7;
																											IL_0712:
																											num5++;
																											num = 58;
																											goto IL_0729;
																											IL_0729:
																											ptr2 += 8;
																											break;
																											IL_06d7:
																											array[num5] = 0;
																											goto IL_06e5;
																											IL_06e5:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0708;
																											IL_0708:
																											array2[num5] = null;
																											goto IL_0712;
																										}
																										break;
																									}
																									goto IL_0309;
																									IL_0604:
																									num5--;
																									break;
																									IL_0309:
																									if (6 < b)
																									{
																										goto end_IL_02c5;
																									}
																									goto IL_040b;
																									IL_040b:
																									if (6 > b)
																									{
																										goto end_IL_02c5;
																									}
																									goto IL_05a7;
																									IL_05a7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05e7;
																									IL_05e7:
																									array[num5 - 2] = 0;
																									num = 2;
																									goto IL_0604;
																								}
																								break;
																							}
																							goto IL_073c;
																							IL_0811:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_073c:
																							if (3 > b)
																							{
																								goto IL_074a;
																							}
																							goto IL_0811;
																							IL_074a:
																							if (1 >= b)
																							{
																								goto IL_0755;
																							}
																							goto IL_07b4;
																							IL_0755:
																							if (1 > b)
																							{
																								goto end_IL_02c5;
																							}
																							goto IL_0763;
																							IL_0763:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_077c;
																							IL_077c:
																							array[num5] = 0;
																							goto IL_078a;
																							IL_078a:
																							num5++;
																							goto IL_0798;
																							IL_0798:
																							ptr2 += 8;
																							num = 107;
																							break;
																							IL_07b4:
																							if (2 < b)
																							{
																								goto end_IL_02c5;
																							}
																							goto IL_07bf;
																							IL_07bf:
																							if (2 > b)
																							{
																								goto end_IL_02c5;
																							}
																							goto IL_07ca;
																							IL_07ca:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07f3;
																							IL_07f3:
																							ptr2 += 8;
																							goto IL_0801;
																							IL_0801:
																							num5--;
																							break;
																						}
																						break;
																					}
																					goto IL_031c;
																					IL_03a4:
																					num5--;
																					break;
																					IL_031c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_035c;
																					IL_035c:
																					array[num5 - 2] = 0;
																					num = 94;
																					goto IL_03a4;
																				}
																				break;
																			}
																			goto IL_037b;
																			IL_0617:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0679;
																			IL_037b:
																			if (11 < b)
																			{
																				goto IL_0389;
																			}
																			goto IL_041e;
																			IL_0389:
																			if (13 >= b)
																			{
																				goto IL_0397;
																			}
																			goto IL_068c;
																			IL_0397:
																			if (13 > b)
																			{
																				goto IL_03b7;
																			}
																			goto IL_03e6;
																			IL_03b7:
																			if (12 < b)
																			{
																				goto end_IL_02c5;
																			}
																			goto IL_03c5;
																			IL_03c5:
																			if (12 > b)
																			{
																				goto end_IL_02c5;
																			}
																			goto IL_03d3;
																			IL_03d3:
																			num5--;
																			break;
																			IL_03e6:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 74;
																			break;
																			IL_068c:
																			if (14 < b)
																			{
																				goto end_IL_02c5;
																			}
																			num = 82;
																			goto IL_06a3;
																			IL_0679:
																			num5 -= 2;
																			break;
																			IL_06a3:
																			if (14 > b)
																			{
																			}
																			goto end_IL_02c5;
																			IL_041e:
																			if (11 <= b)
																			{
																				goto IL_0429;
																			}
																			goto IL_048f;
																			IL_0429:
																			array[num5 - 1] = 0;
																			goto IL_043d;
																			IL_043d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)FormKDDTDSubset[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_047c;
																			IL_047c:
																			ptr2 += 8;
																			break;
																			IL_048f:
																			if (9 < b)
																			{
																				goto IL_049a;
																			}
																			goto IL_04ad;
																			IL_049a:
																			if (10 < b)
																			{
																				goto end_IL_02c5;
																			}
																			goto IL_0532;
																			IL_0532:
																			if (10 > b)
																			{
																				goto end_IL_02c5;
																			}
																			goto IL_0540;
																			IL_0540:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0580;
																			IL_0580:
																			array[num5 - 2] = 0;
																			goto IL_0594;
																			IL_0594:
																			num5--;
																			break;
																			IL_04ad:
																			if (9 > b)
																			{
																				goto IL_04bb;
																			}
																			goto IL_0617;
																			IL_04bb:
																			if (8 < b)
																			{
																				goto end_IL_02c5;
																			}
																			goto IL_04c9;
																			IL_04c9:
																			if (8 > b)
																			{
																				goto end_IL_02c5;
																			}
																			goto IL_04d7;
																			IL_04d7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04fa;
																			IL_04fa:
																			array[num5] = 0;
																			num = 64;
																			goto IL_0511;
																			IL_0511:
																			num5++;
																			goto IL_051f;
																			IL_051f:
																			ptr2 += 8;
																			break;
																		}
																		goto end_IL_02d5;
																		continue;
																		end_IL_02c5:
																		break;
																		IL_02c5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d5:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 132;
												goto IL_08da;
												IL_08da:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0839:
												break;
											}
											continue;
											end_IL_084c:
											break;
										}
										continue;
										end_IL_0856:
										break;
									}
									continue;
									end_IL_0861:
									break;
								}
								continue;
								end_IL_0876:
								break;
							}
							continue;
							end_IL_0886:
							break;
						}
						continue;
						end_IL_0896:
						break;
					}
					continue;
					end_IL_08a6:
					break;
				}
				continue;
				end_IL_08b6:
				break;
			}
		}
	}

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001e, IL_09af, IL_09c2, IL_0a0d, IL_0a1d, IL_0a2d, IL_0a3d, IL_0a4d, IL_0a5d, IL_0a6d, IL_0a7d, IL_0a8a, IL_0a9a, IL_0aaa, IL_0aba, IL_0aca, IL_0ada, IL_0ae5, IL_0af0, IL_0afe, IL_0b0e, IL_0b27, IL_0b32, IL_0b72, IL_0b8b, IL_0b96, IL_0ba1, IL_0baf, IL_0bd7, IL_0be5, IL_0bf3, IL_0bfc, IL_0c0c, IL_0c1a, IL_0c23, IL_0c33, IL_0c46, IL_0c74, IL_0cb9, IL_0d01, IL_0d1d, IL_0d2b, IL_0d39, IL_0d82, IL_0d96, IL_0db2, IL_0dc0, IL_0dd3, IL_0df6, IL_0e04, IL_0e12, IL_0e25, IL_0e33, IL_0e41, IL_0e5e, IL_0ead, IL_0eb7, IL_0ee4, IL_0ef8, IL_0f0f, IL_0f22, IL_0f60, IL_0f7c, IL_0f87, IL_0fc7, IL_0fdb, IL_0fee, IL_0ffc, IL_100a, IL_102c, IL_103a, IL_1048, IL_105b, IL_1069, IL_1077, IL_1085, IL_109d, IL_10bb, IL_10df, IL_10f7, IL_110a, IL_1118, IL_1141, IL_115a, IL_1168, IL_1176, IL_118a, IL_11de, IL_11ec, IL_11ff, IL_120d, IL_1220, IL_122e, IL_123c, IL_124a, IL_1258, IL_1266, IL_1284, IL_129b, IL_12ae, IL_12c2, IL_12d5, IL_12e3, IL_12f1, IL_12ff, IL_1317, IL_1325, IL_1338, IL_134b, IL_1355, IL_1363, IL_137f, IL_138d, IL_13a0, IL_13b0, IL_1412, IL_1425, IL_1433, IL_1473, IL_1487, IL_149a, IL_14ae, IL_14c1, IL_14cc, IL_14da, IL_14e3, IL_14f1, IL_151a, IL_1528, IL_153b, IL_1549, IL_1561, IL_156f, IL_157d, IL_1590, IL_15a4, IL_15e3, IL_15f6, IL_1604, IL_1612, IL_1620, IL_162e, IL_1666, IL_167a, IL_1696, IL_169f, IL_16b3, IL_16f1, IL_1704, IL_1712, IL_1720, IL_178e, IL_17a1, IL_17af, IL_17bd, IL_17f5, IL_1812, IL_1825, IL_182e, IL_183c, IL_184a, IL_1858, IL_1866, IL_1871, IL_188a, IL_1898, IL_18a6, IL_18b9, IL_18c7, IL_18d0, IL_18de, IL_18f2, IL_192a, IL_193d, IL_194b, IL_1959, IL_1971, IL_197a, IL_19bb, IL_19cf, IL_19e2, IL_19f0, IL_19fb, IL_1a17, IL_1a25, IL_1a33, IL_1a85, IL_1a98, IL_1aa3, IL_1ab1, IL_1ada, IL_1ae8, IL_1afb, IL_1b09, IL_1b17, IL_1b30, IL_1b3e, IL_1b4c, IL_1b5f, IL_1b73, IL_1bb2, IL_1bc5, IL_1bd3, IL_1bde, IL_1bfb, IL_1c3a, IL_1c4d, IL_1c5b, IL_1c69, IL_1c77, IL_1c85, IL_1c93, IL_1c9e, IL_1cac, IL_1cba, IL_1cf2, IL_1d06, IL_1d19, IL_1d2d, IL_1d88, IL_1d96, IL_1da9, IL_1db7, IL_1dc5, IL_1dd9, IL_1e18, IL_1e2b, IL_1e3f, IL_1e91, IL_1ea8, IL_1ebb, IL_1ec9, IL_1ed7, IL_1ee5, IL_1ef3, IL_1f33, IL_1f47, IL_1f5a, IL_1f98, IL_1fac, IL_1fbf, IL_1fcd, IL_1fdb, IL_1fe9, IL_1ff2, IL_202a, IL_2047, IL_205a, IL_2063, IL_2071, IL_2085, IL_20c4, IL_20d7, IL_20e0, IL_20f4, IL_2132, IL_2145, IL_2153, IL_215e, IL_2177, IL_218a, IL_2198, IL_21a3, IL_21ce, IL_21e7, IL_21f5, IL_2203, IL_220c, IL_225f, IL_226d, IL_2280, IL_228e, IL_229c, IL_22aa, IL_22c7, IL_2358, IL_2366, IL_2379, IL_2387, IL_2390, IL_23aa, IL_23b8, IL_23c6, IL_23d9, IL_23e7, IL_23f5, IL_2403, IL_2411, IL_242e, IL_246d, IL_2480, IL_24c0, IL_24d4, IL_24e7, IL_24f2, IL_2500, IL_2509, IL_2520, IL_2544, IL_2552, IL_2565, IL_2573, IL_2581, IL_25e8, IL_2604, IL_2612, IL_261d, IL_2646, IL_2654, IL_2667, IL_2675, IL_2683, IL_268e, IL_26b7, IL_26c5, IL_26d8, IL_26e6, IL_26f4, IL_271e, IL_272c, IL_273f, IL_274a, IL_2758, IL_2775, IL_27b4, IL_27c7, IL_27d5, IL_27e3, IL_282b, IL_283e, IL_2847, IL_2852, IL_2866, IL_28a5, IL_28b8, IL_28c6, IL_28d1, IL_28df, IL_2903, IL_2911, IL_2924, IL_2932, IL_2940, IL_297d, IL_298b, IL_299e, IL_29ac, IL_29ba, IL_29e8, IL_29fb, IL_2a09, IL_2a17, IL_2a25, IL_2a30, IL_2a3e, IL_2a62, IL_2a70, IL_2a83, IL_2a91, IL_2a9f, IL_2adf, IL_2af3, IL_2b06, IL_2b14, IL_2b22, IL_2b30, IL_2b9e, IL_2bb1, IL_2bba, IL_2bc8, IL_2c06, IL_2c1a, IL_2c2d, IL_2c4a, IL_2c88, IL_2c9b, IL_2ca9, IL_2cb4, IL_2cc2, IL_2cd0, IL_2d0e, IL_2d1c, IL_2d2f, IL_2d43, IL_2d82, IL_2d95, IL_2da0, IL_2dab, IL_2de9, IL_2dfd, IL_2e0d, IL_2e18, IL_2e23, IL_2e36, IL_2e49, IL_2e53, IL_2e5e, IL_2e6e, IL_2e7e, IL_2e8e, IL_2e9e, IL_2eae, IL_2ebe, IL_2ece, IL_2ede, IL_2eee are reachable both inside and outside the pinned region starting at IL_2f03. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 169;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef96 = default(int);
			ref int reference = ref __rxRef96;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2eee:
					num2 = 1;
					while (true)
					{
						IL_2ede:
						num3 = num2 * 4;
						while (true)
						{
							IL_2ece:
							num4 = num2 * 8;
							while (true)
							{
								IL_2ebe:
								array2 = new byte[5];
								while (true)
								{
									IL_2eae:
									array3 = new object[5];
									while (true)
									{
										IL_2e9e:
										array4 = new int[5];
										while (true)
										{
											IL_2e8e:
											array5 = new int[7];
											while (true)
											{
												IL_2e7e:
												array6 = new long[5];
												while (true)
												{
													IL_2e6e:
													array7 = new object[15];
													while (true)
													{
														IL_2e5e:
														array7[0] = this;
														while (true)
														{
															IL_2e53:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsNetFxLegacySecurityPolicyvalue.InteropBgeUn);
															while (true)
															{
																IL_2e49:
																ptr2 = ptr;
																while (true)
																{
																	IL_2e36:
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0ada:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0aca:
																			ptr2++;
																			while (true)
																			{
																				IL_0aba:
																				if (b >= 1)
																				{
																					while (b <= 74)
																					{
																						while (true)
																						{
																							IL_0a9a:
																							if (37 >= b)
																							{
																								while (true)
																								{
																									IL_0a8a:
																									if (37 > b)
																									{
																										while (true)
																										{
																											IL_0a7d:
																											if (18 < b)
																											{
																												while (true)
																												{
																													IL_0a6d:
																													if (27 < b)
																													{
																														while (true)
																														{
																															IL_0a5d:
																															if (32 >= b)
																															{
																																while (true)
																																{
																																	IL_0a4d:
																																	if (32 > b)
																																	{
																																		while (true)
																																		{
																																			IL_0a3d:
																																			if (29 >= b)
																																			{
																																				while (true)
																																				{
																																					IL_0a2d:
																																					if (29 > b)
																																					{
																																						while (28 >= b)
																																						{
																																							while (28 <= b)
																																							{
																																								while (true)
																																								{
																																									IL_09c2:
																																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																									num = 616;
																																									while (true)
																																									{
																																										if (num != 616)
																																										{
																																											if (num != 1597)
																																											{
																																												break;
																																											}
																																											switch (num)
																																											{
																																											case 169:
																																												break;
																																											default:
																																												continue;
																																											case 122:
																																											case 171:
																																												goto IL_09c2;
																																											case 220:
																																												goto IL_0a0d;
																																											case 566:
																																												goto IL_0a1d;
																																											case 330:
																																												goto IL_0a2d;
																																											case 383:
																																												goto IL_0a3d;
																																											case 417:
																																												goto IL_0a4d;
																																											case 374:
																																												goto IL_0a5d;
																																											case 458:
																																												goto IL_0a6d;
																																											case 485:
																																												goto IL_0a7d;
																																											case 269:
																																												goto IL_0a8a;
																																											case 475:
																																												goto IL_0a9a;
																																											case 52:
																																												goto IL_0aaa;
																																											case 439:
																																												goto IL_0aba;
																																											case 498:
																																												goto IL_0aca;
																																											case 261:
																																											case 338:
																																												goto IL_0ada;
																																											case 193:
																																												goto IL_0af0;
																																											case 194:
																																												goto IL_0afe;
																																											case 14:
																																											case 257:
																																												goto IL_0b0e;
																																											case 348:
																																												goto IL_0b27;
																																											case 15:
																																											case 91:
																																												goto IL_0b32;
																																											case 43:
																																												goto IL_0b72;
																																											case 189:
																																												goto IL_0b8b;
																																											case 38:
																																												goto IL_0b96;
																																											case 113:
																																											case 262:
																																												goto IL_0ba1;
																																											case 32:
																																												goto IL_0baf;
																																											case 332:
																																												goto IL_0bd7;
																																											case 293:
																																												goto IL_0be5;
																																											case 154:
																																												goto IL_0bfc;
																																											case 266:
																																												goto IL_0c0c;
																																											case 22:
																																												goto IL_0c23;
																																											case 355:
																																												goto IL_0c33;
																																											case 79:
																																											case 367:
																																												goto IL_0c46;
																																											case 97:
																																											case 385:
																																												goto IL_0c74;
																																											case 388:
																																												goto IL_0cb9;
																																											case 149:
																																												goto IL_0d01;
																																											case 392:
																																												goto IL_0d1d;
																																											case 353:
																																												goto IL_0d2b;
																																											case 142:
																																											case 183:
																																												goto IL_0d39;
																																											case 273:
																																												goto IL_0d82;
																																											case 197:
																																												goto IL_0d96;
																																											case 64:
																																												goto IL_0db2;
																																											case 276:
																																												goto IL_0dc0;
																																											case 400:
																																											case 402:
																																												goto IL_0dd3;
																																											case 143:
																																												goto IL_0df6;
																																											case 356:
																																												goto IL_0e04;
																																											case 397:
																																												goto IL_0e12;
																																											case 427:
																																												goto IL_0e25;
																																											case 21:
																																												goto IL_0e33;
																																											case 201:
																																											case 232:
																																												goto IL_0e41;
																																											case 251:
																																												goto IL_0ef8;
																																											case 109:
																																												goto IL_0f0f;
																																											case 370:
																																											case 437:
																																												goto IL_0f22;
																																											case 45:
																																												goto IL_0f60;
																																											case 484:
																																												goto IL_0f7c;
																																											case 325:
																																											case 326:
																																												goto IL_0f87;
																																											case 473:
																																												goto IL_0fc7;
																																											case 471:
																																												goto IL_0fdb;
																																											case 199:
																																												goto IL_0fee;
																																											case 418:
																																												goto IL_0ffc;
																																											case 87:
																																											case 441:
																																												goto IL_100a;
																																											case 279:
																																												goto IL_102c;
																																											case 272:
																																												goto IL_103a;
																																											case 476:
																																												goto IL_1048;
																																											case 490:
																																												goto IL_105b;
																																											case 207:
																																												goto IL_1069;
																																											case 360:
																																												goto IL_1077;
																																											case 34:
																																											case 37:
																																												goto IL_1085;
																																											case 74:
																																												goto IL_109d;
																																											case 453:
																																												goto IL_10bb;
																																											case 8:
																																												goto IL_10df;
																																											case 131:
																																												goto IL_10f7;
																																											case 253:
																																												goto IL_110a;
																																											case 277:
																																											case 324:
																																												goto IL_1118;
																																											case 387:
																																												goto IL_1141;
																																											case 528:
																																												goto IL_115a;
																																											case 464:
																																												goto IL_1168;
																																											case 124:
																																											case 209:
																																												goto IL_1176;
																																											case 136:
																																												goto IL_118a;
																																											case 363:
																																												goto IL_11de;
																																											case 192:
																																												goto IL_11ec;
																																											case 448:
																																												goto IL_11ff;
																																											case 345:
																																												goto IL_120d;
																																											case 524:
																																												goto IL_1220;
																																											case 240:
																																												goto IL_122e;
																																											case 540:
																																												goto IL_124a;
																																											case 236:
																																												goto IL_1258;
																																											case 127:
																																											case 196:
																																												goto IL_1266;
																																											case 231:
																																												goto IL_1284;
																																											case 541:
																																												goto IL_129b;
																																											case 550:
																																												goto IL_12ae;
																																											case 129:
																																												goto IL_12c2;
																																											case 555:
																																												goto IL_12d5;
																																											case 57:
																																												goto end_IL_09af;
																																											case 235:
																																											case 264:
																																												goto IL_12f1;
																																											case 83:
																																												goto IL_12ff;
																																											case 256:
																																												goto IL_1317;
																																											case 442:
																																												goto IL_1325;
																																											case 382:
																																											case 561:
																																												goto IL_1338;
																																											case 569:
																																												goto IL_134b;
																																											case 450:
																																												goto IL_1355;
																																											case 89:
																																												goto IL_1363;
																																											case 579:
																																												goto IL_137f;
																																											case 153:
																																												goto IL_138d;
																																											case 589:
																																												goto IL_13a0;
																																											case 333:
																																											case 596:
																																												goto IL_13b0;
																																											case 588:
																																												goto IL_1412;
																																											case 600:
																																												goto IL_1425;
																																											case 368:
																																											case 463:
																																												goto IL_1433;
																																											case 123:
																																												goto IL_1473;
																																											case 88:
																																												goto IL_1487;
																																											case 582:
																																												goto IL_14ae;
																																											case 120:
																																												goto IL_14c1;
																																											case 488:
																																												goto IL_14cc;
																																											case 562:
																																												goto IL_14e3;
																																											case 373:
																																											case 482:
																																												goto IL_14f1;
																																											case 76:
																																												goto IL_151a;
																																											case 132:
																																												goto IL_1528;
																																											case 604:
																																												goto IL_153b;
																																											case 190:
																																											case 531:
																																												goto IL_1549;
																																											case 339:
																																												goto IL_1561;
																																											case 444:
																																												goto IL_156f;
																																											case 577:
																																												goto IL_157d;
																																											case 102:
																																											case 202:
																																												goto IL_1590;
																																											case 443:
																																												goto IL_15a4;
																																											case 228:
																																												goto IL_15e3;
																																											case 511:
																																												goto IL_15f6;
																																											case 499:
																																												goto IL_1604;
																																											case 204:
																																												goto IL_1612;
																																											case 156:
																																												goto IL_1620;
																																											case 7:
																																											case 558:
																																												goto IL_162e;
																																											case 461:
																																												goto IL_1666;
																																											case 26:
																																												goto IL_167a;
																																											case 295:
																																											case 308:
																																												goto IL_169f;
																																											case 602:
																																												goto IL_16b3;
																																											case 206:
																																												goto IL_16f1;
																																											case 187:
																																												goto IL_1704;
																																											case 92:
																																												goto IL_1712;
																																											case 105:
																																											case 179:
																																												goto IL_1720;
																																											case 24:
																																												goto IL_178e;
																																											case 350:
																																												goto IL_17a1;
																																											case 290:
																																												goto IL_17af;
																																											case 198:
																																											case 299:
																																												goto IL_17bd;
																																											case 224:
																																												goto IL_17f5;
																																											case 372:
																																												goto IL_1812;
																																											case 526:
																																												goto IL_182e;
																																											case 389:
																																												goto IL_183c;
																																											case 23:
																																												goto IL_184a;
																																											case 380:
																																												goto IL_1858;
																																											case 125:
																																												goto IL_1866;
																																											case 117:
																																											case 545:
																																												goto IL_1871;
																																											case 114:
																																												goto IL_188a;
																																											case 587:
																																												goto IL_1898;
																																											case 205:
																																												goto IL_18a6;
																																											case 291:
																																												goto IL_18b9;
																																											case 433:
																																												goto IL_18d0;
																																											case 176:
																																											case 597:
																																												goto IL_18de;
																																											case 215:
																																												goto IL_18f2;
																																											case 500:
																																												goto IL_192a;
																																											case 160:
																																												goto IL_193d;
																																											case 459:
																																												goto IL_194b;
																																											case 172:
																																											case 575:
																																												goto IL_1959;
																																											case 184:
																																											case 553:
																																												goto IL_197a;
																																											case 28:
																																												goto IL_19bb;
																																											case 49:
																																												goto IL_19cf;
																																											case 446:
																																												goto IL_19e2;
																																											case 419:
																																												goto IL_19f0;
																																											case 200:
																																											case 334:
																																												goto IL_19fb;
																																											case 216:
																																												goto IL_1a17;
																																											case 287:
																																												goto IL_1a25;
																																											case 346:
																																											case 559:
																																												goto IL_1a33;
																																											case 93:
																																												goto IL_1a85;
																																											case 512:
																																												goto IL_1a98;
																																											case 265:
																																												goto IL_1aa3;
																																											case 134:
																																											case 162:
																																												goto IL_1ab1;
																																											case 583:
																																												goto IL_1ada;
																																											case 0:
																																												goto IL_1ae8;
																																											case 303:
																																												goto IL_1afb;
																																											case 436:
																																												goto IL_1b09;
																																											case 468:
																																											case 572:
																																												goto IL_1b17;
																																											case 352:
																																												goto IL_1b30;
																																											case 29:
																																												goto IL_1b3e;
																																											case 203:
																																												goto IL_1b4c;
																																											case 4:
																																											case 532:
																																												goto IL_1b5f;
																																											case 173:
																																												goto IL_1b73;
																																											case 284:
																																												goto IL_1bb2;
																																											case 586:
																																												goto IL_1bc5;
																																											case 551:
																																												goto IL_1bd3;
																																											case 377:
																																											case 457:
																																												goto IL_1bde;
																																											case 599:
																																												goto IL_1bfb;
																																											case 517:
																																												goto IL_1c3a;
																																											case 369:
																																												goto IL_1c4d;
																																											case 548:
																																												goto IL_1c5b;
																																											case 297:
																																												goto IL_1c69;
																																											case 386:
																																												goto IL_1c77;
																																											case 73:
																																												goto IL_1c85;
																																											case 315:
																																												goto IL_1c93;
																																											case 101:
																																												goto IL_1c9e;
																																											case 126:
																																												goto IL_1cac;
																																											case 61:
																																											case 591:
																																												goto IL_1cba;
																																											case 520:
																																												goto IL_1cf2;
																																											case 307:
																																												goto IL_1d06;
																																											case 281:
																																											case 607:
																																												goto IL_1d19;
																																											case 408:
																																												goto IL_1d2d;
																																											case 107:
																																												goto IL_1d88;
																																											case 145:
																																												goto IL_1d96;
																																											case 226:
																																												goto IL_1da9;
																																											case 361:
																																												goto IL_1db7;
																																											case 321:
																																											case 534:
																																												goto IL_1dc5;
																																											case 469:
																																												goto IL_1dd9;
																																											case 3:
																																												goto IL_1e18;
																																											case 288:
																																											case 554:
																																												goto IL_1e2b;
																																											case 546:
																																												goto IL_1e3f;
																																											case 42:
																																												goto IL_1e91;
																																											case 56:
																																												goto IL_1ea8;
																																											case 316:
																																												goto IL_1ebb;
																																											case 422:
																																												goto IL_1ec9;
																																											case 258:
																																												goto IL_1ed7;
																																											case 249:
																																												goto IL_1ee5;
																																											case 305:
																																											case 328:
																																												goto IL_1ef3;
																																											case 191:
																																												goto IL_1f33;
																																											case 314:
																																												goto IL_1f47;
																																											case 252:
																																											case 557:
																																												goto IL_1f5a;
																																											case 270:
																																												goto IL_1f98;
																																											case 25:
																																												goto IL_1fac;
																																											case 255:
																																												goto IL_1fbf;
																																											case 247:
																																												goto IL_1fcd;
																																											case 379:
																																												goto IL_1fdb;
																																											case 404:
																																											case 535:
																																												goto IL_1ff2;
																																											case 301:
																																												goto IL_202a;
																																											case 16:
																																												goto IL_2047;
																																											case 44:
																																												goto IL_2063;
																																											case 1:
																																											case 507:
																																												goto IL_2071;
																																											case 378:
																																												goto IL_2085;
																																											case 456:
																																												goto IL_20c4;
																																											case 133:
																																											case 595:
																																												goto IL_20e0;
																																											case 115:
																																												goto IL_20f4;
																																											case 268:
																																												goto IL_2132;
																																											case 108:
																																												goto IL_2145;
																																											case 118:
																																												goto IL_2153;
																																											case 414:
																																											case 478:
																																												goto IL_215e;
																																											case 504:
																																												goto IL_2177;
																																											case 452:
																																												goto IL_218a;
																																											case 2:
																																												goto IL_2198;
																																											case 568:
																																											case 590:
																																												goto IL_21a3;
																																											case 331:
																																												goto IL_21ce;
																																											case 259:
																																												goto IL_21e7;
																																											case 296:
																																												goto IL_21f5;
																																											case 174:
																																											case 565:
																																												goto IL_220c;
																																											case 491:
																																												goto IL_225f;
																																											case 445:
																																												goto IL_226d;
																																											case 180:
																																												goto IL_2280;
																																											case 263:
																																												goto IL_228e;
																																											case 254:
																																												goto IL_229c;
																																											case 178:
																																											case 241:
																																												goto IL_22aa;
																																											case 601:
																																												goto IL_22c7;
																																											case 150:
																																												goto IL_2358;
																																											case 537:
																																												goto IL_2366;
																																											case 556:
																																												goto IL_2379;
																																											case 100:
																																											case 480:
																																												goto IL_2390;
																																											case 538:
																																												goto IL_23aa;
																																											case 519:
																																												goto IL_23b8;
																																											case 609:
																																												goto IL_23c6;
																																											case 55:
																																												goto IL_23d9;
																																											case 483:
																																												goto IL_23e7;
																																											case 376:
																																												goto IL_23f5;
																																											case 423:
																																												goto IL_2403;
																																											case 186:
																																											case 479:
																																												goto IL_2411;
																																											case 146:
																																												goto IL_242e;
																																											case 425:
																																												goto IL_246d;
																																											case 159:
																																											case 403:
																																												goto IL_2480;
																																											case 188:
																																												goto IL_24c0;
																																											case 282:
																																												goto IL_24d4;
																																											case 470:
																																												goto IL_24e7;
																																											case 163:
																																												goto IL_24f2;
																																											case 72:
																																											case 310:
																																												goto IL_2509;
																																											case 86:
																																												goto IL_2520;
																																											case 341:
																																												goto IL_2544;
																																											case 401:
																																												goto IL_2552;
																																											case 155:
																																												goto IL_2565;
																																											case 503:
																																												goto IL_2573;
																																											case 398:
																																											case 409:
																																												goto IL_2581;
																																											case 242:
																																												goto IL_25e8;
																																											case 396:
																																												goto IL_2604;
																																											case 466:
																																												goto IL_2612;
																																											case 309:
																																											case 486:
																																												goto IL_261d;
																																											case 426:
																																												goto IL_2646;
																																											case 542:
																																												goto IL_2654;
																																											case 451:
																																												goto IL_2667;
																																											case 219:
																																												goto IL_2675;
																																											case 227:
																																												goto IL_2683;
																																											case 20:
																																											case 496:
																																												goto IL_268e;
																																											case 103:
																																												goto IL_26b7;
																																											case 104:
																																												goto IL_26c5;
																																											case 233:
																																												goto IL_26d8;
																																											case 481:
																																												goto IL_26e6;
																																											case 424:
																																											case 573:
																																												goto IL_26f4;
																																											case 221:
																																												goto IL_271e;
																																											case 576:
																																												goto IL_272c;
																																											case 434:
																																												goto IL_273f;
																																											case 275:
																																												goto IL_274a;
																																											case 185:
																																											case 552:
																																												goto IL_2758;
																																											case 239:
																																												goto IL_2775;
																																											case 533:
																																												goto IL_27b4;
																																											case 605:
																																												goto IL_27c7;
																																											case 116:
																																												goto IL_27d5;
																																											case 366:
																																											case 435:
																																												goto IL_27e3;
																																											case 148:
																																												goto IL_282b;
																																											case 508:
																																												goto IL_2847;
																																											case 399:
																																											case 543:
																																												goto IL_2852;
																																											case 405:
																																												goto IL_2866;
																																											case 317:
																																												goto IL_28a5;
																																											case 606:
																																												goto IL_28b8;
																																											case 222:
																																												goto IL_28c6;
																																											case 35:
																																											case 337:
																																												goto IL_28d1;
																																											case 139:
																																												goto IL_28df;
																																											case 167:
																																												goto IL_2903;
																																											case 593:
																																												goto IL_2911;
																																											case 460:
																																												goto IL_2924;
																																											case 208:
																																												goto IL_2932;
																																											case 119:
																																											case 571:
																																												goto IL_2940;
																																											case 495:
																																												goto IL_297d;
																																											case 323:
																																												goto IL_298b;
																																											case 560:
																																												goto IL_299e;
																																											case 585:
																																												goto IL_29ac;
																																											case 60:
																																											case 570:
																																												goto IL_29ba;
																																											case 340:
																																												goto IL_29e8;
																																											case 343:
																																												goto IL_29fb;
																																											case 195:
																																												goto IL_2a09;
																																											case 289:
																																												goto IL_2a17;
																																											case 19:
																																												goto IL_2a25;
																																											case 166:
																																											case 245:
																																												goto IL_2a30;
																																											case 212:
																																												goto IL_2a3e;
																																											case 527:
																																												goto IL_2a62;
																																											case 71:
																																												goto IL_2a70;
																																											case 359:
																																												goto IL_2a83;
																																											case 438:
																																												goto IL_2a91;
																																											case 128:
																																											case 516:
																																												goto IL_2a9f;
																																											case 342:
																																												goto IL_2adf;
																																											case 110:
																																												goto IL_2af3;
																																											case 494:
																																												goto IL_2b06;
																																											case 421:
																																												goto IL_2b14;
																																											case 260:
																																												goto IL_2b22;
																																											case 244:
																																											case 502:
																																												goto IL_2b30;
																																											case 510:
																																												goto IL_2b9e;
																																											case 5:
																																												goto IL_2bba;
																																											case 410:
																																											case 514:
																																												goto IL_2bc8;
																																											case 420:
																																												goto IL_2c06;
																																											case 581:
																																												goto IL_2c1a;
																																											case 13:
																																											case 223:
																																												goto IL_2c2d;
																																											case 505:
																																												goto IL_2c4a;
																																											case 137:
																																												goto IL_2c88;
																																											case 594:
																																												goto IL_2c9b;
																																											case 440:
																																												goto IL_2ca9;
																																											case 432:
																																												goto IL_2cb4;
																																											case 449:
																																												goto IL_2cc2;
																																											case 147:
																																											case 218:
																																												goto IL_2cd0;
																																											case 411:
																																												goto IL_2d0e;
																																											case 306:
																																												goto IL_2d1c;
																																											case 31:
																																											case 603:
																																												goto IL_2d2f;
																																											case 322:
																																												goto IL_2d43;
																																											case 182:
																																												goto IL_2d82;
																																											case 413:
																																												goto IL_2d95;
																																											case 48:
																																												goto IL_2da0;
																																											case 300:
																																											case 429:
																																												goto IL_2dab;
																																											case 521:
																																												goto IL_2de9;
																																											case 375:
																																												goto IL_2dfd;
																																											case 547:
																																												goto IL_2e0d;
																																											case 135:
																																												goto IL_2e18;
																																											case 6:
																																											case 10:
																																											case 17:
																																											case 18:
																																											case 36:
																																											case 39:
																																											case 41:
																																											case 46:
																																											case 51:
																																											case 53:
																																											case 54:
																																											case 58:
																																											case 66:
																																											case 68:
																																											case 70:
																																											case 75:
																																											case 77:
																																											case 78:
																																											case 81:
																																											case 84:
																																											case 95:
																																											case 106:
																																											case 112:
																																											case 121:
																																											case 130:
																																											case 140:
																																											case 144:
																																											case 158:
																																											case 165:
																																											case 170:
																																											case 175:
																																											case 177:
																																											case 181:
																																											case 210:
																																											case 211:
																																											case 214:
																																											case 217:
																																											case 230:
																																											case 234:
																																											case 237:
																																											case 238:
																																											case 243:
																																											case 246:
																																											case 250:
																																											case 267:
																																											case 280:
																																											case 285:
																																											case 292:
																																											case 298:
																																											case 304:
																																											case 313:
																																											case 319:
																																											case 327:
																																											case 329:
																																											case 335:
																																											case 344:
																																											case 347:
																																											case 351:
																																											case 364:
																																											case 365:
																																											case 384:
																																											case 390:
																																											case 428:
																																											case 447:
																																											case 462:
																																											case 487:
																																											case 509:
																																											case 518:
																																											case 522:
																																											case 523:
																																											case 525:
																																											case 529:
																																											case 567:
																																											case 574:
																																											case 578:
																																											case 580:
																																											case 608:
																																												goto end_IL_0a0d;
																																											case 9:
																																											case 11:
																																											case 12:
																																											case 27:
																																											case 30:
																																											case 33:
																																											case 40:
																																											case 47:
																																											case 50:
																																											case 59:
																																											case 62:
																																											case 63:
																																											case 65:
																																											case 67:
																																											case 69:
																																											case 82:
																																											case 85:
																																											case 90:
																																											case 96:
																																											case 98:
																																											case 99:
																																											case 138:
																																											case 141:
																																											case 151:
																																											case 152:
																																											case 161:
																																											case 164:
																																											case 213:
																																											case 225:
																																											case 229:
																																											case 248:
																																											case 274:
																																											case 278:
																																											case 283:
																																											case 294:
																																											case 302:
																																											case 311:
																																											case 312:
																																											case 318:
																																											case 320:
																																											case 336:
																																											case 354:
																																											case 357:
																																											case 358:
																																											case 362:
																																											case 371:
																																											case 381:
																																											case 391:
																																											case 394:
																																											case 395:
																																											case 406:
																																											case 407:
																																											case 412:
																																											case 415:
																																											case 416:
																																											case 431:
																																											case 454:
																																											case 465:
																																											case 472:
																																											case 474:
																																											case 489:
																																											case 492:
																																											case 493:
																																											case 497:
																																											case 501:
																																											case 513:
																																											case 515:
																																											case 530:
																																											case 536:
																																											case 539:
																																											case 544:
																																											case 549:
																																											case 563:
																																											case 564:
																																											case 584:
																																											case 592:
																																											case 598:
																																												goto IL_2e36;
																																											case 286:
																																												goto IL_2e49;
																																											case 430:
																																												goto IL_2e53;
																																											case 506:
																																												goto IL_2e5e;
																																											case 477:
																																												goto IL_2e6e;
																																											case 157:
																																												goto IL_2e7e;
																																											case 393:
																																												goto IL_2e8e;
																																											case 94:
																																												goto IL_2e9e;
																																											case 111:
																																												goto IL_2eae;
																																											case 467:
																																												goto IL_2ebe;
																																											case 349:
																																												goto IL_2ece;
																																											case 271:
																																												goto IL_2ede;
																																											case 168:
																																												goto IL_2eee;
																																											case 80:
																																											case 455:
																																												return;
																																											}
																																											goto end_IL_0aba;
																																										}
																																										array2[num6 - 2] = 3;
																																										goto IL_14ae;
																																										IL_14ae:
																																										num6--;
																																										goto IL_2e36;
																																										continue;
																																										end_IL_09af:
																																										break;
																																									}
																																									break;
																																								}
																																								goto IL_12e3;
																																								continue;
																																								end_IL_0a0d:
																																								break;
																																								IL_0a0d:;
																																							}
																																							break;
																																							IL_0a1d:;
																																						}
																																						break;
																																					}
																																					num = 14;
																																					goto IL_0b0e;
																																					IL_0cb9:
																																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																					num = 149;
																																					goto IL_0d01;
																																					IL_0d01:
																																					ptr2 += 8;
																																					num = 161;
																																					goto IL_2e36;
																																					IL_0b0e:
																																					array2[num6 - 1] = 0;
																																					goto IL_0cb9;
																																				}
																																				break;
																																			}
																																			goto IL_14c1;
																																			IL_156f:
																																			num6++;
																																			goto IL_157d;
																																			IL_14c1:
																																			if (30 < b)
																																			{
																																				goto IL_14cc;
																																			}
																																			goto IL_153b;
																																			IL_14cc:
																																			if (31 < b)
																																			{
																																				break;
																																			}
																																			num = 562;
																																			goto IL_14e3;
																																			IL_157d:
																																			ptr2 += 8;
																																			goto IL_2e36;
																																			IL_14e3:
																																			if (31 > b)
																																			{
																																				break;
																																			}
																																			goto IL_14f1;
																																			IL_14f1:
																																			((delegate*<Class200, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																																			goto IL_151a;
																																			IL_151a:
																																			num6--;
																																			goto IL_1528;
																																			IL_1528:
																																			ptr2 += 8;
																																			goto IL_2e36;
																																			IL_153b:
																																			if (30 > b)
																																			{
																																				break;
																																			}
																																			goto IL_1549;
																																			IL_1549:
																																			array3[num6] = array7[*(int*)(ptr2 + num3)];
																																			goto IL_1561;
																																			IL_1561:
																																			array2[num6] = 5;
																																			goto IL_156f;
																																		}
																																		break;
																																	}
																																	goto IL_1590;
																																	IL_15e3:
																																	ptr2 += 8;
																																	goto IL_2e36;
																																	IL_1590:
																																	array2[num6 - 1] = 3;
																																	goto IL_15a4;
																																	IL_15a4:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																	goto IL_15e3;
																																}
																																break;
																															}
																															goto IL_15f6;
																															IL_17f5:
																															array2[num6 - 1] = 5;
																															num = 372;
																															goto IL_1812;
																															IL_15f6:
																															if (34 >= b)
																															{
																																goto IL_1604;
																															}
																															goto IL_1704;
																															IL_1604:
																															if (34 > b)
																															{
																																goto IL_1612;
																															}
																															num = 295;
																															goto IL_169f;
																															IL_1612:
																															if (33 < b)
																															{
																																break;
																															}
																															goto IL_1620;
																															IL_1620:
																															if (33 > b)
																															{
																																break;
																															}
																															goto IL_162e;
																															IL_162e:
																															array3[num6 - 1] = ((delegate*<Class200, Dictionary<int, GameObject>>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																															goto IL_1666;
																															IL_1666:
																															array2[num6 - 1] = 5;
																															goto IL_167a;
																															IL_167a:
																															ptr2 += 8;
																															num = 141;
																															goto IL_2e36;
																															IL_1812:
																															ptr2 += 8;
																															goto IL_2e36;
																															IL_169f:
																															array2[num6 - 1] = 0;
																															goto IL_16b3;
																															IL_16b3:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Dictionary<int, GameObject>, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Dictionary<int, GameObject>)array3[num6 - 1]);
																															goto IL_16f1;
																															IL_16f1:
																															ptr2 += 8;
																															goto IL_2e36;
																															IL_1704:
																															if (35 >= b)
																															{
																																goto IL_1712;
																															}
																															goto IL_17a1;
																															IL_1712:
																															if (35 > b)
																															{
																																break;
																															}
																															goto IL_1720;
																															IL_1720:
																															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															goto IL_178e;
																															IL_178e:
																															num6 -= 2;
																															goto IL_2e36;
																															IL_17a1:
																															if (36 < b)
																															{
																																break;
																															}
																															goto IL_17af;
																															IL_17af:
																															if (36 > b)
																															{
																																break;
																															}
																															goto IL_17bd;
																															IL_17bd:
																															array3[num6 - 1] = ((delegate*<Class200, List<Player>>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																															goto IL_17f5;
																														}
																														break;
																													}
																													num = 526;
																													goto IL_182e;
																													IL_1b4c:
																													ptr2 += 16;
																													goto IL_2e36;
																													IL_1b5f:
																													array2[num6 - 1] = 3;
																													goto IL_1b73;
																													IL_182e:
																													if (27 > b)
																													{
																														goto IL_183c;
																													}
																													goto IL_1b5f;
																													IL_183c:
																													if (22 >= b)
																													{
																														goto IL_184a;
																													}
																													goto IL_19e2;
																													IL_184a:
																													if (22 > b)
																													{
																														goto IL_1858;
																													}
																													num = 553;
																													goto IL_197a;
																													IL_1858:
																													if (20 >= b)
																													{
																														goto IL_1866;
																													}
																													goto IL_193d;
																													IL_1866:
																													if (20 <= b)
																													{
																														goto IL_1871;
																													}
																													goto IL_18b9;
																													IL_1871:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																													goto IL_188a;
																													IL_188a:
																													array2[num6] = 1;
																													goto IL_1898;
																													IL_1898:
																													num6++;
																													goto IL_18a6;
																													IL_18a6:
																													ptr2 += 16;
																													goto IL_2e36;
																													IL_18b9:
																													if (19 < b)
																													{
																														break;
																													}
																													num = 433;
																													goto IL_18d0;
																													IL_1bb2:
																													ptr2 += 8;
																													goto IL_2e36;
																													IL_18d0:
																													if (19 > b)
																													{
																														break;
																													}
																													goto IL_18de;
																													IL_18de:
																													array2[num6 - 1] = 5;
																													goto IL_18f2;
																													IL_18f2:
																													array3[num6 - 1] = ((delegate*<string[], string>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																													goto IL_192a;
																													IL_192a:
																													ptr2 += 8;
																													goto IL_2e36;
																													IL_193d:
																													if (21 < b)
																													{
																														break;
																													}
																													goto IL_194b;
																													IL_194b:
																													if (21 > b)
																													{
																														break;
																													}
																													goto IL_1959;
																													IL_1959:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													goto IL_2e36;
																													IL_1b73:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_1bb2;
																													IL_197a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																													goto IL_19bb;
																													IL_19bb:
																													array2[num6 - 2] = 0;
																													goto IL_19cf;
																													IL_19cf:
																													num6--;
																													goto IL_2e36;
																													IL_19e2:
																													if (24 >= b)
																													{
																														goto IL_19f0;
																													}
																													goto IL_1a98;
																													IL_19f0:
																													if (24 <= b)
																													{
																														goto IL_19fb;
																													}
																													goto IL_1a17;
																													IL_19fb:
																													num7 = ptr2;
																													num8 = -200;
																													num5 = 1;
																													ptr2 = num7 + num8;
																													goto IL_2e36;
																													IL_1a17:
																													if (23 < b)
																													{
																														break;
																													}
																													goto IL_1a25;
																													IL_1a25:
																													if (23 > b)
																													{
																														break;
																													}
																													goto IL_1a33;
																													IL_1a33:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_1a85;
																													IL_1a85:
																													num6--;
																													goto IL_2e36;
																													IL_1a98:
																													if (25 >= b)
																													{
																														goto IL_1aa3;
																													}
																													goto IL_1afb;
																													IL_1aa3:
																													if (25 > b)
																													{
																														break;
																													}
																													goto IL_1ab1;
																													IL_1ab1:
																													((delegate*<string, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																													goto IL_1ada;
																													IL_1ada:
																													num6--;
																													goto IL_1ae8;
																													IL_1ae8:
																													ptr2 += 8;
																													goto IL_2e36;
																													IL_1afb:
																													if (26 < b)
																													{
																														break;
																													}
																													goto IL_1b09;
																													IL_1b09:
																													if (26 > b)
																													{
																														break;
																													}
																													goto IL_1b17;
																													IL_1b17:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																													goto IL_1b30;
																													IL_1b30:
																													array2[num6] = 3;
																													goto IL_1b3e;
																													IL_1b3e:
																													num6++;
																													goto IL_1b4c;
																												}
																												break;
																											}
																											goto IL_0af0;
																											IL_124a:
																											if (14 < b)
																											{
																												break;
																											}
																											goto IL_1258;
																											IL_0af0:
																											if (18 > b)
																											{
																												goto IL_0afe;
																											}
																											goto IL_0f22;
																											IL_0afe:
																											if (9 >= b)
																											{
																												goto IL_0b27;
																											}
																											goto IL_0e25;
																											IL_0b27:
																											if (9 <= b)
																											{
																												goto IL_0b32;
																											}
																											goto IL_0b8b;
																											IL_0b32:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0b72;
																											IL_0b72:
																											array2[num6 - 2] = 0;
																											goto IL_0c33;
																											IL_0c33:
																											num6--;
																											goto IL_2e36;
																											IL_0b8b:
																											if (4 >= b)
																											{
																												goto IL_0b96;
																											}
																											goto IL_0c0c;
																											IL_0b96:
																											if (4 <= b)
																											{
																												goto IL_0ba1;
																											}
																											goto IL_0bd7;
																											IL_0ba1:
																											array2[num6] = 0;
																											goto IL_0baf;
																											IL_0baf:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_134b;
																											IL_134b:
																											array3[num6] = null;
																											goto IL_1355;
																											IL_1355:
																											num6++;
																											goto IL_1363;
																											IL_1363:
																											ptr2 += 8;
																											num = 501;
																											goto IL_2e36;
																											IL_0bd7:
																											if (2 < b)
																											{
																												goto IL_0be5;
																											}
																											goto IL_0f7c;
																											IL_0be5:
																											if (3 < b)
																											{
																												break;
																											}
																											num = 154;
																											goto IL_0bfc;
																											IL_1258:
																											if (14 > b)
																											{
																												break;
																											}
																											goto IL_1266;
																											IL_0bfc:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_0c46;
																											IL_0c46:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_137f;
																											IL_137f:
																											ptr2 += 8;
																											goto IL_138d;
																											IL_138d:
																											num6--;
																											goto IL_2e36;
																											IL_0f7c:
																											if (2 <= b)
																											{
																												goto IL_0f87;
																											}
																											goto IL_0fee;
																											IL_0f87:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0fc7;
																											IL_0fc7:
																											array2[num6 - 2] = 0;
																											goto IL_0fdb;
																											IL_0fdb:
																											num6--;
																											goto IL_2e36;
																											IL_0fee:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_0ffc;
																											IL_0ffc:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_100a;
																											IL_100a:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																											num = 279;
																											goto IL_102c;
																											IL_102c:
																											array2[num6] = 0;
																											goto IL_103a;
																											IL_103a:
																											num6++;
																											goto IL_1048;
																											IL_1048:
																											ptr2 += 8;
																											goto IL_2e36;
																											IL_0c0c:
																											if (6 >= b)
																											{
																												num = 22;
																												goto IL_0c23;
																											}
																											goto IL_0d1d;
																											IL_1266:
																											array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																											goto IL_1284;
																											IL_0c23:
																											if (6 <= b)
																											{
																												goto IL_0c74;
																											}
																											goto IL_13a0;
																											IL_0c74:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_12ae;
																											IL_12ae:
																											array2[num6 - 2] = 0;
																											goto IL_12c2;
																											IL_12c2:
																											num6--;
																											goto IL_2e36;
																											IL_13a0:
																											if (5 < b)
																											{
																												break;
																											}
																											goto IL_1425;
																											IL_1425:
																											if (5 > b)
																											{
																												break;
																											}
																											goto IL_1433;
																											IL_1433:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_1473;
																											IL_1473:
																											array2[num6 - 2] = 0;
																											goto IL_1487;
																											IL_1487:
																											num6--;
																											goto IL_2e36;
																											IL_0d1d:
																											if (7 >= b)
																											{
																												goto IL_0d2b;
																											}
																											goto IL_0db2;
																											IL_0d2b:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_0d39;
																											IL_0d39:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											num = 273;
																											goto IL_0d82;
																											IL_0d82:
																											array2[num6 - 2] = 0;
																											goto IL_0d96;
																											IL_0d96:
																											num6--;
																											num = 544;
																											goto IL_2e36;
																											IL_0db2:
																											if (8 < b)
																											{
																												break;
																											}
																											goto IL_0dc0;
																											IL_0dc0:
																											if (8 > b)
																											{
																												break;
																											}
																											goto IL_1338;
																											IL_1338:
																											num6--;
																											goto IL_2e36;
																											IL_0e25:
																											if (13 >= b)
																											{
																												goto IL_0e33;
																											}
																											goto IL_105b;
																											IL_0e33:
																											if (13 <= b)
																											{
																												goto IL_0e41;
																											}
																											goto IL_115a;
																											IL_0e41:
																											array8 = array3;
																											num9 = num6;
																											if (array == null)
																											{
																												goto IL_0e50;
																											}
																											num10 = ptr2;
																											byte b2 = *num10;
																											ptr2 = num10 + 4;
																											int num11 = *(int*)(ptr2 + num3);
																											ptr2 += 8;
																											byte* ptr3 = ptr2 + num11;
																											byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																											while (ptr2 != ptr3)
																											{
																												*ptr4 = (byte)(*ptr2 ^ b2);
																												ptr2++;
																												ptr4++;
																											}
																											array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																											goto IL_0ef8;
																											IL_1284:
																											ptr2 += 8;
																											num = 541;
																											goto IL_129b;
																											IL_129b:
																											num6--;
																											goto IL_2e36;
																											IL_0f22:
																											((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																											goto IL_0f60;
																											IL_0ef8:
																											array2[num6] = 5;
																											num = 109;
																											goto IL_0f0f;
																											IL_0f0f:
																											num6++;
																											goto IL_2e36;
																											IL_115a:
																											if (11 >= b)
																											{
																												goto IL_1168;
																											}
																											goto IL_1220;
																											IL_1168:
																											if (11 <= b)
																											{
																												goto IL_1176;
																											}
																											goto IL_11ff;
																											IL_1176:
																											array2[num6 - 2] = 0;
																											goto IL_118a;
																											IL_118a:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_11de;
																											IL_11de:
																											num6--;
																											goto IL_11ec;
																											IL_11ec:
																											ptr2 += 8;
																											goto IL_2e36;
																											IL_11ff:
																											if (10 < b)
																											{
																												break;
																											}
																											goto IL_120d;
																											IL_120d:
																											if (10 > b)
																											{
																												break;
																											}
																											goto IL_13b0;
																											IL_13b0:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_1412;
																											IL_1412:
																											num6 -= 2;
																											goto IL_2e36;
																											IL_1220:
																											if (12 < b)
																											{
																												break;
																											}
																											goto IL_122e;
																											IL_122e:
																											if (12 > b)
																											{
																												break;
																											}
																											num = 213;
																											goto IL_2e36;
																											IL_0f60:
																											num6 -= 3;
																											num = 151;
																											goto IL_2e36;
																											IL_105b:
																											if (15 < b)
																											{
																												goto IL_1069;
																											}
																											goto IL_110a;
																											IL_1069:
																											if (16 >= b)
																											{
																												goto IL_1077;
																											}
																											goto IL_12d5;
																											IL_1077:
																											if (16 > b)
																											{
																												break;
																											}
																											goto IL_1085;
																											IL_1085:
																											array2[num6] = array2[num6 - 1];
																											goto IL_109d;
																											IL_109d:
																											array4[num6 - 0] = array4[num6 - 1];
																											goto IL_10bb;
																											IL_10bb:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_10df;
																											IL_10df:
																											array3[num6] = array3[num6 - 1];
																											goto IL_10f7;
																											IL_10f7:
																											num6++;
																											goto IL_2e36;
																											IL_12d5:
																											if (17 < b)
																											{
																												break;
																											}
																											goto IL_12e3;
																											IL_12e3:
																											if (17 > b)
																											{
																												break;
																											}
																											goto IL_12f1;
																											IL_12f1:
																											array2[num6] = 5;
																											goto IL_12ff;
																											IL_12ff:
																											array3[num6] = array7[*(int*)(ptr2 + num3)];
																											goto IL_1317;
																											IL_1317:
																											num6++;
																											goto IL_1325;
																											IL_1325:
																											ptr2 += 8;
																											goto IL_2e36;
																											IL_110a:
																											if (15 <= b)
																											{
																												goto IL_1118;
																											}
																											goto IL_124a;
																											IL_1118:
																											array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																											goto IL_1141;
																											IL_1141:
																											array2[num6 - 1] = 5;
																											goto IL_2e36;
																										}
																										break;
																									}
																									goto IL_0dd3;
																									IL_0e12:
																									ptr2 += 8;
																									goto IL_2e36;
																									IL_0dd3:
																									array3[num6] = ((delegate*<Class8.GunResult>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])();
																									goto IL_0df6;
																									IL_0df6:
																									array2[num6] = 4;
																									goto IL_0e04;
																									IL_0e04:
																									num6++;
																									goto IL_0e12;
																								}
																								break;
																							}
																							goto IL_1bc5;
																							IL_2d43:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_2d82;
																							IL_1bc5:
																							if (56 >= b)
																							{
																								goto IL_1bd3;
																							}
																							goto IL_2604;
																							IL_1bd3:
																							if (56 <= b)
																							{
																								goto IL_1bde;
																							}
																							goto IL_1c4d;
																							IL_1bde:
																							array2[num6 - 1] = 3;
																							num = 599;
																							goto IL_1bfb;
																							IL_1bfb:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1c3a;
																							IL_1c3a:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_1c4d:
																							if (46 >= b)
																							{
																								goto IL_1c5b;
																							}
																							goto IL_2145;
																							IL_1c5b:
																							if (46 > b)
																							{
																								goto IL_1c69;
																							}
																							num = 595;
																							goto IL_20e0;
																							IL_1c69:
																							if (41 >= b)
																							{
																								goto IL_1c77;
																							}
																							goto IL_1ebb;
																							IL_1c77:
																							if (41 > b)
																							{
																								goto IL_1c85;
																							}
																							goto IL_1e2b;
																							IL_1c85:
																							if (39 >= b)
																							{
																								goto IL_1c93;
																							}
																							goto IL_1da9;
																							IL_1c93:
																							if (39 > b)
																							{
																								goto IL_1c9e;
																							}
																							goto IL_1d19;
																							IL_1c9e:
																							if (38 < b)
																							{
																								break;
																							}
																							goto IL_1cac;
																							IL_1cac:
																							if (38 > b)
																							{
																								break;
																							}
																							goto IL_1cba;
																							IL_1cba:
																							array3[num6 - 1] = ((delegate*<Class8.GunResult, Player>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]);
																							goto IL_1cf2;
																							IL_1cf2:
																							array2[num6 - 1] = 5;
																							goto IL_1d06;
																							IL_1d06:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_1d19:
																							array2[num6 - 2] = 0;
																							goto IL_1d2d;
																							IL_1d2d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<List<Player>, Player, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((List<Player>)array3[num6 - 2], (Player)array3[num6 - 1]) ? 1 : 0);
																							num = 107;
																							goto IL_1d88;
																							IL_1d88:
																							num6--;
																							goto IL_1d96;
																							IL_1d96:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_1da9:
																							if (40 < b)
																							{
																								break;
																							}
																							goto IL_1db7;
																							IL_1db7:
																							if (40 > b)
																							{
																								break;
																							}
																							goto IL_1dc5;
																							IL_1dc5:
																							array2[num6 - 1] = 3;
																							goto IL_1dd9;
																							IL_1dd9:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1e18;
																							IL_1e18:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_1e2b:
																							array2[num6 - 2] = 0;
																							goto IL_1e3f;
																							IL_1e3f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<List<Player>, Player, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((List<Player>)array3[num6 - 2], (Player)array3[num6 - 1]) ? 1 : 0);
																							goto IL_1e91;
																							IL_1e91:
																							num6--;
																							num = 56;
																							goto IL_1ea8;
																							IL_1ea8:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_1ebb:
																							if (43 >= b)
																							{
																								goto IL_1ec9;
																							}
																							goto IL_1fbf;
																							IL_1ec9:
																							if (43 > b)
																							{
																								goto IL_1ed7;
																							}
																							goto IL_1f5a;
																							IL_1ed7:
																							if (42 < b)
																							{
																								break;
																							}
																							goto IL_1ee5;
																							IL_1ee5:
																							if (42 > b)
																							{
																								break;
																							}
																							goto IL_1ef3;
																							IL_1ef3:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1f33;
																							IL_1f33:
																							array2[num6 - 2] = 3;
																							goto IL_1f47;
																							IL_1f47:
																							num6--;
																							goto IL_2e36;
																							IL_1f5a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																							goto IL_1f98;
																							IL_1f98:
																							array2[num6 - 1] = 0;
																							goto IL_1fac;
																							IL_1fac:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_1fbf:
																							if (44 < b)
																							{
																								goto IL_1fcd;
																							}
																							num = 44;
																							goto IL_2063;
																							IL_1fcd:
																							if (45 < b)
																							{
																								break;
																							}
																							goto IL_1fdb;
																							IL_1fdb:
																							if (45 > b)
																							{
																								break;
																							}
																							num = 404;
																							goto IL_1ff2;
																							IL_2da0:
																							if (73 > b)
																							{
																								break;
																							}
																							goto IL_2dab;
																							IL_1ff2:
																							array3[num6 - 1] = ((delegate*<Class200, Dictionary<int, bool>>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																							goto IL_202a;
																							IL_202a:
																							array2[num6 - 1] = 5;
																							num = 16;
																							goto IL_2047;
																							IL_2047:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2d95:
																							if (73 >= b)
																							{
																								goto IL_2da0;
																							}
																							goto IL_2e0d;
																							IL_2063:
																							if (44 > b)
																							{
																								break;
																							}
																							goto IL_2071;
																							IL_2071:
																							array2[num6 - 1] = 3;
																							goto IL_2085;
																							IL_2085:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_20c4;
																							IL_20c4:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2d82:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_20e0:
																							array2[num6 - 1] = 0;
																							goto IL_20f4;
																							IL_20f4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Player, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
																							goto IL_2132;
																							IL_2132:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2145:
																							if (51 >= b)
																							{
																								goto IL_2153;
																							}
																							goto IL_23d9;
																							IL_2153:
																							if (51 <= b)
																							{
																								goto IL_215e;
																							}
																							goto IL_218a;
																							IL_215e:
																							global::_003CModule_003E.gunResult_9 = (Class8.GunResult)array3[num6 - 1];
																							goto IL_2177;
																							IL_2177:
																							num6--;
																							goto IL_2e36;
																							IL_218a:
																							if (48 >= b)
																							{
																								goto IL_2198;
																							}
																							goto IL_2280;
																							IL_2198:
																							if (48 <= b)
																							{
																								goto IL_21a3;
																							}
																							goto IL_21e7;
																							IL_21a3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_21ce;
																							IL_21ce:
																							array2[num6 - 1] = 0;
																							goto IL_2e36;
																							IL_21e7:
																							if (47 < b)
																							{
																								break;
																							}
																							goto IL_21f5;
																							IL_21f5:
																							if (47 > b)
																							{
																								break;
																							}
																							num = 565;
																							goto IL_220c;
																							IL_2dab:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																							goto IL_2de9;
																							IL_220c:
																							((delegate*<Dictionary<int, bool>, int, bool, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Dictionary<int, bool>)array3[num6 - 3], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																							goto IL_225f;
																							IL_225f:
																							num6 -= 3;
																							goto IL_226d;
																							IL_226d:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2280:
																							if (49 < b)
																							{
																								goto IL_228e;
																							}
																							goto IL_2379;
																							IL_228e:
																							if (50 < b)
																							{
																								break;
																							}
																							goto IL_229c;
																							IL_229c:
																							if (50 > b)
																							{
																								break;
																							}
																							goto IL_22aa;
																							IL_22aa:
																							array2[num6 - 5] = 4;
																							num = 601;
																							goto IL_22c7;
																							IL_22c7:
																							array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																							goto IL_2358;
																							IL_2358:
																							num6 -= 4;
																							goto IL_2366;
																							IL_2366:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2379:
																							if (49 > b)
																							{
																								break;
																							}
																							num = 100;
																							goto IL_2390;
																							IL_2de9:
																							array2[num6 - 1] = 0;
																							goto IL_2dfd;
																							IL_2390:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																							goto IL_23aa;
																							IL_23aa:
																							array2[num6] = 3;
																							goto IL_23b8;
																							IL_23b8:
																							num6++;
																							goto IL_23c6;
																							IL_23c6:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_23d9:
																							if (53 >= b)
																							{
																								goto IL_23e7;
																							}
																							goto IL_24e7;
																							IL_23e7:
																							if (53 > b)
																							{
																								goto IL_23f5;
																							}
																							goto IL_2480;
																							IL_23f5:
																							if (52 < b)
																							{
																								break;
																							}
																							goto IL_2403;
																							IL_2403:
																							if (52 > b)
																							{
																								break;
																							}
																							goto IL_2411;
																							IL_2411:
																							array2[num6 - 1] = 3;
																							num = 146;
																							goto IL_242e;
																							IL_242e:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_246d;
																							IL_246d:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2480:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_24c0;
																							IL_24c0:
																							array2[num6 - 2] = 3;
																							goto IL_24d4;
																							IL_24d4:
																							num6--;
																							goto IL_2e36;
																							IL_24e7:
																							if (54 >= b)
																							{
																								goto IL_24f2;
																							}
																							goto IL_2565;
																							IL_24f2:
																							if (54 > b)
																							{
																								break;
																							}
																							num = 310;
																							goto IL_2509;
																							IL_2dfd:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2509:
																							array2[num6] = 0;
																							num = 86;
																							goto IL_2520;
																							IL_2520:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_2544;
																							IL_2544:
																							num6++;
																							goto IL_2552;
																							IL_2552:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2565:
																							if (55 < b)
																							{
																								break;
																							}
																							goto IL_2573;
																							IL_2573:
																							if (55 > b)
																							{
																								break;
																							}
																							goto IL_2581;
																							IL_2581:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 242;
																							goto IL_25e8;
																							IL_25e8:
																							num6--;
																							num = 394;
																							goto IL_2e36;
																							IL_2604:
																							if (65 >= b)
																							{
																								goto IL_2612;
																							}
																							goto IL_29fb;
																							IL_2612:
																							if (65 <= b)
																							{
																								goto IL_261d;
																							}
																							goto IL_2667;
																							IL_261d:
																							((delegate*<Class200, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																							goto IL_2646;
																							IL_2646:
																							num6--;
																							goto IL_2654;
																							IL_2654:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2667:
																							if (60 < b)
																							{
																								goto IL_2675;
																							}
																							num = 508;
																							goto IL_2847;
																							IL_2675:
																							if (62 >= b)
																							{
																								goto IL_2683;
																							}
																							goto IL_273f;
																							IL_2683:
																							if (62 <= b)
																							{
																								goto IL_268e;
																							}
																							goto IL_26d8;
																							IL_268e:
																							((delegate*<string, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																							goto IL_26b7;
																							IL_26b7:
																							num6--;
																							goto IL_26c5;
																							IL_26c5:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_26d8:
																							if (61 < b)
																							{
																								break;
																							}
																							goto IL_26e6;
																							IL_26e6:
																							if (61 > b)
																							{
																								break;
																							}
																							goto IL_26f4;
																							IL_26f4:
																							((delegate*<float, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																							goto IL_271e;
																							IL_271e:
																							num6--;
																							goto IL_272c;
																							IL_272c:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_273f:
																							if (63 >= b)
																							{
																								goto IL_274a;
																							}
																							goto IL_27c7;
																							IL_274a:
																							if (63 > b)
																							{
																								break;
																							}
																							goto IL_2758;
																							IL_2758:
																							array2[num6 - 1] = 3;
																							num = 239;
																							goto IL_2775;
																							IL_2775:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_27b4;
																							IL_27b4:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_27c7:
																							if (64 < b)
																							{
																								break;
																							}
																							goto IL_27d5;
																							IL_27d5:
																							if (64 > b)
																							{
																								break;
																							}
																							goto IL_27e3;
																							IL_27e3:
																							ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_282b;
																							IL_282b:
																							num6--;
																							goto IL_2e36;
																							IL_2e0d:
																							if (74 < b)
																							{
																								break;
																							}
																							goto IL_2e18;
																							IL_2847:
																							if (60 <= b)
																							{
																								goto IL_2852;
																							}
																							goto IL_28b8;
																							IL_2852:
																							array2[num6 - 1] = 3;
																							goto IL_2866;
																							IL_2866:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_28a5;
																							IL_28a5:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_28b8:
																							if (58 >= b)
																							{
																								goto IL_28c6;
																							}
																							goto IL_299e;
																							IL_28c6:
																							if (58 <= b)
																							{
																								goto IL_28d1;
																							}
																							goto IL_2924;
																							IL_28d1:
																							array2[num6] = 3;
																							goto IL_28df;
																							IL_28df:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])();
																							goto IL_2903;
																							IL_2903:
																							num6++;
																							goto IL_2911;
																							IL_2911:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2924:
																							if (57 < b)
																							{
																								break;
																							}
																							goto IL_2932;
																							IL_2932:
																							if (57 > b)
																							{
																								break;
																							}
																							goto IL_2940;
																							IL_2940:
																							((delegate*<List<Player>, Player, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((List<Player>)array3[num6 - 2], (Player)array3[num6 - 1]);
																							goto IL_297d;
																							IL_297d:
																							num6 -= 2;
																							goto IL_298b;
																							IL_298b:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_299e:
																							if (59 < b)
																							{
																								break;
																							}
																							goto IL_29ac;
																							IL_29ac:
																							if (59 > b)
																							{
																								break;
																							}
																							goto IL_29ba;
																							IL_29ba:
																							((Class200)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_29e8;
																							IL_29e8:
																							num6 -= 2;
																							goto IL_2e36;
																							IL_29fb:
																							if (70 >= b)
																							{
																								goto IL_2a09;
																							}
																							goto IL_2c9b;
																							IL_2a09:
																							if (70 > b)
																							{
																								goto IL_2a17;
																							}
																							goto IL_2c2d;
																							IL_2a17:
																							if (67 >= b)
																							{
																								goto IL_2a25;
																							}
																							goto IL_2b06;
																							IL_2a25:
																							if (67 <= b)
																							{
																								goto IL_2a30;
																							}
																							goto IL_2a83;
																							IL_2a30:
																							array2[num6] = 3;
																							goto IL_2a3e;
																							IL_2a3e:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])();
																							goto IL_2a62;
																							IL_2a62:
																							num6++;
																							goto IL_2a70;
																							IL_2a70:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2a83:
																							if (66 < b)
																							{
																								break;
																							}
																							goto IL_2a91;
																							IL_2a91:
																							if (66 > b)
																							{
																								break;
																							}
																							goto IL_2a9f;
																							IL_2a9f:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_2adf;
																							IL_2adf:
																							array2[num6 - 2] = 3;
																							goto IL_2af3;
																							IL_2af3:
																							num6--;
																							goto IL_2e36;
																							IL_2b06:
																							if (68 < b)
																							{
																								goto IL_2b14;
																							}
																							num = 5;
																							goto IL_2bba;
																							IL_2b14:
																							if (69 < b)
																							{
																								break;
																							}
																							goto IL_2b22;
																							IL_2b22:
																							if (69 > b)
																							{
																								break;
																							}
																							goto IL_2b30;
																							IL_2b30:
																							ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_2b9e;
																							IL_2b9e:
																							num6 -= 2;
																							goto IL_2e36;
																							IL_2e18:
																							if (74 <= b)
																							{
																							}
																							break;
																							IL_2bba:
																							if (68 > b)
																							{
																								break;
																							}
																							goto IL_2bc8;
																							IL_2bc8:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class200, float>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																							goto IL_2c06;
																							IL_2c06:
																							array2[num6 - 1] = 3;
																							goto IL_2c1a;
																							IL_2c1a:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2c2d:
																							array2[num6 - 1] = 0;
																							num = 505;
																							goto IL_2c4a;
																							IL_2c4a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Player, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
																							goto IL_2c88;
																							IL_2c88:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2c9b:
																							if (72 >= b)
																							{
																								goto IL_2ca9;
																							}
																							goto IL_2d95;
																							IL_2ca9:
																							if (72 > b)
																							{
																								goto IL_2cb4;
																							}
																							goto IL_2d2f;
																							IL_2cb4:
																							if (71 < b)
																							{
																								break;
																							}
																							goto IL_2cc2;
																							IL_2cc2:
																							if (71 > b)
																							{
																								break;
																							}
																							goto IL_2cd0;
																							IL_2cd0:
																							((delegate*<Class200, int, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_2d0e;
																							IL_2d0e:
																							num6 -= 2;
																							goto IL_2d1c;
																							IL_2d1c:
																							ptr2 += 8;
																							goto IL_2e36;
																							IL_2d2f:
																							array2[num6 - 1] = 3;
																							goto IL_2d43;
																						}
																						break;
																						IL_0aaa:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_2e36;
																				continue;
																				end_IL_0aba:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0e50:
			while (true)
			{
				IL_0e50_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0ef8_2:
						array2[num6] = 5;
						num = 109;
						while (true)
						{
							IL_0f0f_2:
							num6++;
							while (true)
							{
								IL_2e36_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0aba_2:
											if (b >= 1)
											{
												while (b <= 74)
												{
													while (true)
													{
														IL_0a9a_2:
														if (37 >= b)
														{
															while (true)
															{
																IL_0a8a_2:
																if (37 > b)
																{
																	while (true)
																	{
																		IL_0a7d_2:
																		if (18 < b)
																		{
																			while (true)
																			{
																				IL_0a6d_2:
																				if (27 < b)
																				{
																					while (true)
																					{
																						IL_0a5d_2:
																						if (32 >= b)
																						{
																							while (true)
																							{
																								IL_0a4d_2:
																								if (32 > b)
																								{
																									while (true)
																									{
																										IL_0a3d_2:
																										if (29 >= b)
																										{
																											while (true)
																											{
																												IL_0a2d_2:
																												if (29 > b)
																												{
																													while (28 >= b)
																													{
																														while (28 <= b)
																														{
																															while (true)
																															{
																																IL_09c2_2:
																																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																num = 616;
																																while (true)
																																{
																																	if (num != 616)
																																	{
																																		if (num != 1597)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 122:
																																		case 171:
																																			goto IL_09c2_2;
																																		case 220:
																																			goto IL_0a0d_2;
																																		case 566:
																																			goto IL_0a1d_2;
																																		case 330:
																																			goto IL_0a2d_2;
																																		case 383:
																																			goto IL_0a3d_2;
																																		case 417:
																																			goto IL_0a4d_2;
																																		case 374:
																																			goto IL_0a5d_2;
																																		case 458:
																																			goto IL_0a6d_2;
																																		case 485:
																																			goto IL_0a7d_2;
																																		case 269:
																																			goto IL_0a8a_2;
																																		case 475:
																																			goto IL_0a9a_2;
																																		case 52:
																																			goto IL_0aaa_2;
																																		case 439:
																																			goto IL_0aba_2;
																																		case 498:
																																			goto end_IL_0aba_2;
																																		case 261:
																																		case 338:
																																			goto end_IL_0aca;
																																		case 193:
																																			goto IL_0af0_2;
																																		case 194:
																																			goto IL_0afe_2;
																																		case 14:
																																		case 257:
																																			goto IL_0b0e_2;
																																		case 348:
																																			goto IL_0b27_2;
																																		case 15:
																																		case 91:
																																			goto IL_0b32_2;
																																		case 43:
																																			goto IL_0b72_2;
																																		case 189:
																																			goto IL_0b8b_2;
																																		case 38:
																																			goto IL_0b96_2;
																																		case 113:
																																		case 262:
																																			goto IL_0ba1_2;
																																		case 32:
																																			goto IL_0baf_2;
																																		case 332:
																																			goto IL_0bd7_2;
																																		case 293:
																																			goto IL_0be5_2;
																																		case 154:
																																			goto IL_0bfc_2;
																																		case 266:
																																			goto IL_0c0c_2;
																																		case 22:
																																			goto IL_0c23_2;
																																		case 355:
																																			goto IL_0c33_2;
																																		case 79:
																																		case 367:
																																			goto IL_0c46_2;
																																		case 97:
																																		case 385:
																																			goto IL_0c74_2;
																																		case 388:
																																			goto IL_0cb9_2;
																																		case 149:
																																			goto IL_0d01_2;
																																		case 392:
																																			goto IL_0d1d_2;
																																		case 353:
																																			goto IL_0d2b_2;
																																		case 142:
																																		case 183:
																																			goto IL_0d39_2;
																																		case 273:
																																			goto IL_0d82_2;
																																		case 197:
																																			goto IL_0d96_2;
																																		case 64:
																																			goto IL_0db2_2;
																																		case 276:
																																			goto IL_0dc0_2;
																																		case 400:
																																		case 402:
																																			goto IL_0dd3_2;
																																		case 143:
																																			goto IL_0df6_2;
																																		case 356:
																																			goto IL_0e04_2;
																																		case 397:
																																			goto IL_0e12_2;
																																		case 427:
																																			goto IL_0e25_2;
																																		case 21:
																																			goto IL_0e33_2;
																																		case 201:
																																		case 232:
																																			goto end_IL_0ada;
																																		case 251:
																																			goto IL_0ef8_2;
																																		case 109:
																																			goto IL_0f0f_2;
																																		case 370:
																																		case 437:
																																			goto IL_0f22_2;
																																		case 45:
																																			goto IL_0f60_2;
																																		case 484:
																																			goto IL_0f7c_2;
																																		case 325:
																																		case 326:
																																			goto IL_0f87_2;
																																		case 473:
																																			goto IL_0fc7_2;
																																		case 471:
																																			goto IL_0fdb_2;
																																		case 199:
																																			goto IL_0fee_2;
																																		case 418:
																																			goto IL_0ffc_2;
																																		case 87:
																																		case 441:
																																			goto IL_100a_2;
																																		case 279:
																																			goto IL_102c_2;
																																		case 272:
																																			goto IL_103a_2;
																																		case 476:
																																			goto IL_1048_2;
																																		case 490:
																																			goto IL_105b_2;
																																		case 207:
																																			goto IL_1069_2;
																																		case 360:
																																			goto IL_1077_2;
																																		case 34:
																																		case 37:
																																			goto IL_1085_2;
																																		case 74:
																																			goto IL_109d_2;
																																		case 453:
																																			goto IL_10bb_2;
																																		case 8:
																																			goto IL_10df_2;
																																		case 131:
																																			goto IL_10f7_2;
																																		case 253:
																																			goto IL_110a_2;
																																		case 277:
																																		case 324:
																																			goto IL_1118_2;
																																		case 387:
																																			goto IL_1141_2;
																																		case 528:
																																			goto IL_115a_2;
																																		case 464:
																																			goto IL_1168_2;
																																		case 124:
																																		case 209:
																																			goto IL_1176_2;
																																		case 136:
																																			goto IL_118a_2;
																																		case 363:
																																			goto IL_11de_2;
																																		case 192:
																																			goto IL_11ec_2;
																																		case 448:
																																			goto IL_11ff_2;
																																		case 345:
																																			goto IL_120d_2;
																																		case 524:
																																			goto IL_1220_2;
																																		case 240:
																																			goto IL_122e_2;
																																		case 540:
																																			goto IL_124a_2;
																																		case 236:
																																			goto IL_1258_2;
																																		case 127:
																																		case 196:
																																			goto IL_1266_2;
																																		case 231:
																																			goto IL_1284_2;
																																		case 541:
																																			goto IL_129b_2;
																																		case 550:
																																			goto IL_12ae_2;
																																		case 129:
																																			goto IL_12c2_2;
																																		case 555:
																																			goto IL_12d5_2;
																																		case 57:
																																			goto end_IL_09af_2;
																																		case 235:
																																		case 264:
																																			goto IL_12f1_2;
																																		case 83:
																																			goto IL_12ff_2;
																																		case 256:
																																			goto IL_1317_2;
																																		case 442:
																																			goto IL_1325_2;
																																		case 382:
																																		case 561:
																																			goto IL_1338_2;
																																		case 569:
																																			goto IL_134b_2;
																																		case 450:
																																			goto IL_1355_2;
																																		case 89:
																																			goto IL_1363_2;
																																		case 579:
																																			goto IL_137f_2;
																																		case 153:
																																			goto IL_138d_2;
																																		case 589:
																																			goto IL_13a0_2;
																																		case 333:
																																		case 596:
																																			goto IL_13b0_2;
																																		case 588:
																																			goto IL_1412_2;
																																		case 600:
																																			goto IL_1425_2;
																																		case 368:
																																		case 463:
																																			goto IL_1433_2;
																																		case 123:
																																			goto IL_1473_2;
																																		case 88:
																																			goto IL_1487_2;
																																		case 582:
																																			goto IL_14ae_2;
																																		case 120:
																																			goto IL_14c1_2;
																																		case 488:
																																			goto IL_14cc_2;
																																		case 562:
																																			goto IL_14e3_2;
																																		case 373:
																																		case 482:
																																			goto IL_14f1_2;
																																		case 76:
																																			goto IL_151a_2;
																																		case 132:
																																			goto IL_1528_2;
																																		case 604:
																																			goto IL_153b_2;
																																		case 190:
																																		case 531:
																																			goto IL_1549_2;
																																		case 339:
																																			goto IL_1561_2;
																																		case 444:
																																			goto IL_156f_2;
																																		case 577:
																																			goto IL_157d_2;
																																		case 102:
																																		case 202:
																																			goto IL_1590_2;
																																		case 443:
																																			goto IL_15a4_2;
																																		case 228:
																																			goto IL_15e3_2;
																																		case 511:
																																			goto IL_15f6_2;
																																		case 499:
																																			goto IL_1604_2;
																																		case 204:
																																			goto IL_1612_2;
																																		case 156:
																																			goto IL_1620_2;
																																		case 7:
																																		case 558:
																																			goto IL_162e_2;
																																		case 461:
																																			goto IL_1666_2;
																																		case 26:
																																			goto IL_167a_2;
																																		case 295:
																																		case 308:
																																			goto IL_169f_2;
																																		case 602:
																																			goto IL_16b3_2;
																																		case 206:
																																			goto IL_16f1_2;
																																		case 187:
																																			goto IL_1704_2;
																																		case 92:
																																			goto IL_1712_2;
																																		case 105:
																																		case 179:
																																			goto IL_1720_2;
																																		case 24:
																																			goto IL_178e_2;
																																		case 350:
																																			goto IL_17a1_2;
																																		case 290:
																																			goto IL_17af_2;
																																		case 198:
																																		case 299:
																																			goto IL_17bd_2;
																																		case 224:
																																			goto IL_17f5_2;
																																		case 372:
																																			goto IL_1812_2;
																																		case 526:
																																			goto IL_182e_2;
																																		case 389:
																																			goto IL_183c_2;
																																		case 23:
																																			goto IL_184a_2;
																																		case 380:
																																			goto IL_1858_2;
																																		case 125:
																																			goto IL_1866_2;
																																		case 117:
																																		case 545:
																																			goto IL_1871_2;
																																		case 114:
																																			goto IL_188a_2;
																																		case 587:
																																			goto IL_1898_2;
																																		case 205:
																																			goto IL_18a6_2;
																																		case 291:
																																			goto IL_18b9_2;
																																		case 433:
																																			goto IL_18d0_2;
																																		case 176:
																																		case 597:
																																			goto IL_18de_2;
																																		case 215:
																																			goto IL_18f2_2;
																																		case 500:
																																			goto IL_192a_2;
																																		case 160:
																																			goto IL_193d_2;
																																		case 459:
																																			goto IL_194b_2;
																																		case 172:
																																		case 575:
																																			goto IL_1959_2;
																																		case 184:
																																		case 553:
																																			goto IL_197a_2;
																																		case 28:
																																			goto IL_19bb_2;
																																		case 49:
																																			goto IL_19cf_2;
																																		case 446:
																																			goto IL_19e2_2;
																																		case 419:
																																			goto IL_19f0_2;
																																		case 200:
																																		case 334:
																																			goto IL_19fb_2;
																																		case 216:
																																			goto IL_1a17_2;
																																		case 287:
																																			goto IL_1a25_2;
																																		case 346:
																																		case 559:
																																			goto IL_1a33_2;
																																		case 93:
																																			goto IL_1a85_2;
																																		case 512:
																																			goto IL_1a98_2;
																																		case 265:
																																			goto IL_1aa3_2;
																																		case 134:
																																		case 162:
																																			goto IL_1ab1_2;
																																		case 583:
																																			goto IL_1ada_2;
																																		case 0:
																																			goto IL_1ae8_2;
																																		case 303:
																																			goto IL_1afb_2;
																																		case 436:
																																			goto IL_1b09_2;
																																		case 468:
																																		case 572:
																																			goto IL_1b17_2;
																																		case 352:
																																			goto IL_1b30_2;
																																		case 29:
																																			goto IL_1b3e_2;
																																		case 203:
																																			goto IL_1b4c_2;
																																		case 4:
																																		case 532:
																																			goto IL_1b5f_2;
																																		case 173:
																																			goto IL_1b73_2;
																																		case 284:
																																			goto IL_1bb2_2;
																																		case 586:
																																			goto IL_1bc5_2;
																																		case 551:
																																			goto IL_1bd3_2;
																																		case 377:
																																		case 457:
																																			goto IL_1bde_2;
																																		case 599:
																																			goto IL_1bfb_2;
																																		case 517:
																																			goto IL_1c3a_2;
																																		case 369:
																																			goto IL_1c4d_2;
																																		case 548:
																																			goto IL_1c5b_2;
																																		case 297:
																																			goto IL_1c69_2;
																																		case 386:
																																			goto IL_1c77_2;
																																		case 73:
																																			goto IL_1c85_2;
																																		case 315:
																																			goto IL_1c93_2;
																																		case 101:
																																			goto IL_1c9e_2;
																																		case 126:
																																			goto IL_1cac_2;
																																		case 61:
																																		case 591:
																																			goto IL_1cba_2;
																																		case 520:
																																			goto IL_1cf2_2;
																																		case 307:
																																			goto IL_1d06_2;
																																		case 281:
																																		case 607:
																																			goto IL_1d19_2;
																																		case 408:
																																			goto IL_1d2d_2;
																																		case 107:
																																			goto IL_1d88_2;
																																		case 145:
																																			goto IL_1d96_2;
																																		case 226:
																																			goto IL_1da9_2;
																																		case 361:
																																			goto IL_1db7_2;
																																		case 321:
																																		case 534:
																																			goto IL_1dc5_2;
																																		case 469:
																																			goto IL_1dd9_2;
																																		case 3:
																																			goto IL_1e18_2;
																																		case 288:
																																		case 554:
																																			goto IL_1e2b_2;
																																		case 546:
																																			goto IL_1e3f_2;
																																		case 42:
																																			goto IL_1e91_2;
																																		case 56:
																																			goto IL_1ea8_2;
																																		case 316:
																																			goto IL_1ebb_2;
																																		case 422:
																																			goto IL_1ec9_2;
																																		case 258:
																																			goto IL_1ed7_2;
																																		case 249:
																																			goto IL_1ee5_2;
																																		case 305:
																																		case 328:
																																			goto IL_1ef3_2;
																																		case 191:
																																			goto IL_1f33_2;
																																		case 314:
																																			goto IL_1f47_2;
																																		case 252:
																																		case 557:
																																			goto IL_1f5a_2;
																																		case 270:
																																			goto IL_1f98_2;
																																		case 25:
																																			goto IL_1fac_2;
																																		case 255:
																																			goto IL_1fbf_2;
																																		case 247:
																																			goto IL_1fcd_2;
																																		case 379:
																																			goto IL_1fdb_2;
																																		case 404:
																																		case 535:
																																			goto IL_1ff2_2;
																																		case 301:
																																			goto IL_202a_2;
																																		case 16:
																																			goto IL_2047_2;
																																		case 44:
																																			goto IL_2063_2;
																																		case 1:
																																		case 507:
																																			goto IL_2071_2;
																																		case 378:
																																			goto IL_2085_2;
																																		case 456:
																																			goto IL_20c4_2;
																																		case 133:
																																		case 595:
																																			goto IL_20e0_2;
																																		case 115:
																																			goto IL_20f4_2;
																																		case 268:
																																			goto IL_2132_2;
																																		case 108:
																																			goto IL_2145_2;
																																		case 118:
																																			goto IL_2153_2;
																																		case 414:
																																		case 478:
																																			goto IL_215e_2;
																																		case 504:
																																			goto IL_2177_2;
																																		case 452:
																																			goto IL_218a_2;
																																		case 2:
																																			goto IL_2198_2;
																																		case 568:
																																		case 590:
																																			goto IL_21a3_2;
																																		case 331:
																																			goto IL_21ce_2;
																																		case 259:
																																			goto IL_21e7_2;
																																		case 296:
																																			goto IL_21f5_2;
																																		case 174:
																																		case 565:
																																			goto IL_220c_2;
																																		case 491:
																																			goto IL_225f_2;
																																		case 445:
																																			goto IL_226d_2;
																																		case 180:
																																			goto IL_2280_2;
																																		case 263:
																																			goto IL_228e_2;
																																		case 254:
																																			goto IL_229c_2;
																																		case 178:
																																		case 241:
																																			goto IL_22aa_2;
																																		case 601:
																																			goto IL_22c7_2;
																																		case 150:
																																			goto IL_2358_2;
																																		case 537:
																																			goto IL_2366_2;
																																		case 556:
																																			goto IL_2379_2;
																																		case 100:
																																		case 480:
																																			goto IL_2390_2;
																																		case 538:
																																			goto IL_23aa_2;
																																		case 519:
																																			goto IL_23b8_2;
																																		case 609:
																																			goto IL_23c6_2;
																																		case 55:
																																			goto IL_23d9_2;
																																		case 483:
																																			goto IL_23e7_2;
																																		case 376:
																																			goto IL_23f5_2;
																																		case 423:
																																			goto IL_2403_2;
																																		case 186:
																																		case 479:
																																			goto IL_2411_2;
																																		case 146:
																																			goto IL_242e_2;
																																		case 425:
																																			goto IL_246d_2;
																																		case 159:
																																		case 403:
																																			goto IL_2480_2;
																																		case 188:
																																			goto IL_24c0_2;
																																		case 282:
																																			goto IL_24d4_2;
																																		case 470:
																																			goto IL_24e7_2;
																																		case 163:
																																			goto IL_24f2_2;
																																		case 72:
																																		case 310:
																																			goto IL_2509_2;
																																		case 86:
																																			goto IL_2520_2;
																																		case 341:
																																			goto IL_2544_2;
																																		case 401:
																																			goto IL_2552_2;
																																		case 155:
																																			goto IL_2565_2;
																																		case 503:
																																			goto IL_2573_2;
																																		case 398:
																																		case 409:
																																			goto IL_2581_2;
																																		case 242:
																																			goto IL_25e8_2;
																																		case 396:
																																			goto IL_2604_2;
																																		case 466:
																																			goto IL_2612_2;
																																		case 309:
																																		case 486:
																																			goto IL_261d_2;
																																		case 426:
																																			goto IL_2646_2;
																																		case 542:
																																			goto IL_2654_2;
																																		case 451:
																																			goto IL_2667_2;
																																		case 219:
																																			goto IL_2675_2;
																																		case 227:
																																			goto IL_2683_2;
																																		case 20:
																																		case 496:
																																			goto IL_268e_2;
																																		case 103:
																																			goto IL_26b7_2;
																																		case 104:
																																			goto IL_26c5_2;
																																		case 233:
																																			goto IL_26d8_2;
																																		case 481:
																																			goto IL_26e6_2;
																																		case 424:
																																		case 573:
																																			goto IL_26f4_2;
																																		case 221:
																																			goto IL_271e_2;
																																		case 576:
																																			goto IL_272c_2;
																																		case 434:
																																			goto IL_273f_2;
																																		case 275:
																																			goto IL_274a_2;
																																		case 185:
																																		case 552:
																																			goto IL_2758_2;
																																		case 239:
																																			goto IL_2775_2;
																																		case 533:
																																			goto IL_27b4_2;
																																		case 605:
																																			goto IL_27c7_2;
																																		case 116:
																																			goto IL_27d5_2;
																																		case 366:
																																		case 435:
																																			goto IL_27e3_2;
																																		case 148:
																																			goto IL_282b_2;
																																		case 508:
																																			goto IL_2847_2;
																																		case 399:
																																		case 543:
																																			goto IL_2852_2;
																																		case 405:
																																			goto IL_2866_2;
																																		case 317:
																																			goto IL_28a5_2;
																																		case 606:
																																			goto IL_28b8_2;
																																		case 222:
																																			goto IL_28c6_2;
																																		case 35:
																																		case 337:
																																			goto IL_28d1_2;
																																		case 139:
																																			goto IL_28df_2;
																																		case 167:
																																			goto IL_2903_2;
																																		case 593:
																																			goto IL_2911_2;
																																		case 460:
																																			goto IL_2924_2;
																																		case 208:
																																			goto IL_2932_2;
																																		case 119:
																																		case 571:
																																			goto IL_2940_2;
																																		case 495:
																																			goto IL_297d_2;
																																		case 323:
																																			goto IL_298b_2;
																																		case 560:
																																			goto IL_299e_2;
																																		case 585:
																																			goto IL_29ac_2;
																																		case 60:
																																		case 570:
																																			goto IL_29ba_2;
																																		case 340:
																																			goto IL_29e8_2;
																																		case 343:
																																			goto IL_29fb_2;
																																		case 195:
																																			goto IL_2a09_2;
																																		case 289:
																																			goto IL_2a17_2;
																																		case 19:
																																			goto IL_2a25_2;
																																		case 166:
																																		case 245:
																																			goto IL_2a30_2;
																																		case 212:
																																			goto IL_2a3e_2;
																																		case 527:
																																			goto IL_2a62_2;
																																		case 71:
																																			goto IL_2a70_2;
																																		case 359:
																																			goto IL_2a83_2;
																																		case 438:
																																			goto IL_2a91_2;
																																		case 128:
																																		case 516:
																																			goto IL_2a9f_2;
																																		case 342:
																																			goto IL_2adf_2;
																																		case 110:
																																			goto IL_2af3_2;
																																		case 494:
																																			goto IL_2b06_2;
																																		case 421:
																																			goto IL_2b14_2;
																																		case 260:
																																			goto IL_2b22_2;
																																		case 244:
																																		case 502:
																																			goto IL_2b30_2;
																																		case 510:
																																			goto IL_2b9e_2;
																																		case 5:
																																			goto IL_2bba_2;
																																		case 410:
																																		case 514:
																																			goto IL_2bc8_2;
																																		case 420:
																																			goto IL_2c06_2;
																																		case 581:
																																			goto IL_2c1a_2;
																																		case 13:
																																		case 223:
																																			goto IL_2c2d_2;
																																		case 505:
																																			goto IL_2c4a_2;
																																		case 137:
																																			goto IL_2c88_2;
																																		case 594:
																																			goto IL_2c9b_2;
																																		case 440:
																																			goto IL_2ca9_2;
																																		case 432:
																																			goto IL_2cb4_2;
																																		case 449:
																																			goto IL_2cc2_2;
																																		case 147:
																																		case 218:
																																			goto IL_2cd0_2;
																																		case 411:
																																			goto IL_2d0e_2;
																																		case 306:
																																			goto IL_2d1c_2;
																																		case 31:
																																		case 603:
																																			goto IL_2d2f_2;
																																		case 322:
																																			goto IL_2d43_2;
																																		case 182:
																																			goto IL_2d82_2;
																																		case 413:
																																			goto IL_2d95_2;
																																		case 48:
																																			goto IL_2da0_2;
																																		case 300:
																																		case 429:
																																			goto IL_2dab_2;
																																		case 521:
																																			goto IL_2de9_2;
																																		case 375:
																																			goto IL_2dfd_2;
																																		case 547:
																																			goto IL_2e0d_2;
																																		case 135:
																																			goto IL_2e18_2;
																																		case 6:
																																		case 10:
																																		case 17:
																																		case 18:
																																		case 36:
																																		case 39:
																																		case 41:
																																		case 46:
																																		case 51:
																																		case 53:
																																		case 54:
																																		case 58:
																																		case 66:
																																		case 68:
																																		case 70:
																																		case 75:
																																		case 77:
																																		case 78:
																																		case 81:
																																		case 84:
																																		case 95:
																																		case 106:
																																		case 112:
																																		case 121:
																																		case 130:
																																		case 140:
																																		case 144:
																																		case 158:
																																		case 165:
																																		case 170:
																																		case 175:
																																		case 177:
																																		case 181:
																																		case 210:
																																		case 211:
																																		case 214:
																																		case 217:
																																		case 230:
																																		case 234:
																																		case 237:
																																		case 238:
																																		case 243:
																																		case 246:
																																		case 250:
																																		case 267:
																																		case 280:
																																		case 285:
																																		case 292:
																																		case 298:
																																		case 304:
																																		case 313:
																																		case 319:
																																		case 327:
																																		case 329:
																																		case 335:
																																		case 344:
																																		case 347:
																																		case 351:
																																		case 364:
																																		case 365:
																																		case 384:
																																		case 390:
																																		case 428:
																																		case 447:
																																		case 462:
																																		case 487:
																																		case 509:
																																		case 518:
																																		case 522:
																																		case 523:
																																		case 525:
																																		case 529:
																																		case 567:
																																		case 574:
																																		case 578:
																																		case 580:
																																		case 608:
																																			goto end_IL_0a0d_2;
																																		case 9:
																																		case 11:
																																		case 12:
																																		case 27:
																																		case 30:
																																		case 33:
																																		case 40:
																																		case 47:
																																		case 50:
																																		case 59:
																																		case 62:
																																		case 63:
																																		case 65:
																																		case 67:
																																		case 69:
																																		case 82:
																																		case 85:
																																		case 90:
																																		case 96:
																																		case 98:
																																		case 99:
																																		case 138:
																																		case 141:
																																		case 151:
																																		case 152:
																																		case 161:
																																		case 164:
																																		case 213:
																																		case 225:
																																		case 229:
																																		case 248:
																																		case 274:
																																		case 278:
																																		case 283:
																																		case 294:
																																		case 302:
																																		case 311:
																																		case 312:
																																		case 318:
																																		case 320:
																																		case 336:
																																		case 354:
																																		case 357:
																																		case 358:
																																		case 362:
																																		case 371:
																																		case 381:
																																		case 391:
																																		case 394:
																																		case 395:
																																		case 406:
																																		case 407:
																																		case 412:
																																		case 415:
																																		case 416:
																																		case 431:
																																		case 454:
																																		case 465:
																																		case 472:
																																		case 474:
																																		case 489:
																																		case 492:
																																		case 493:
																																		case 497:
																																		case 501:
																																		case 513:
																																		case 515:
																																		case 530:
																																		case 536:
																																		case 539:
																																		case 544:
																																		case 549:
																																		case 563:
																																		case 564:
																																		case 584:
																																		case 592:
																																		case 598:
																																			goto IL_2e36_2;
																																		case 286:
																																			ptr2 = ptr;
																																			goto IL_2e36_2;
																																		case 430:
																																			ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsNetFxLegacySecurityPolicyvalue.InteropBgeUn);
																																			goto case 286;
																																		case 506:
																																			array7[0] = this;
																																			goto case 430;
																																		case 477:
																																			array7 = new object[15];
																																			goto case 506;
																																		case 157:
																																			array6 = new long[5];
																																			goto case 477;
																																		case 393:
																																			array5 = new int[7];
																																			goto case 157;
																																		case 94:
																																			array4 = new int[5];
																																			goto case 393;
																																		case 111:
																																			array3 = new object[5];
																																			goto case 94;
																																		case 467:
																																			array2 = new byte[5];
																																			goto case 111;
																																		case 349:
																																			num4 = num2 * 8;
																																			goto case 467;
																																		case 271:
																																			num3 = num2 * 4;
																																			goto case 349;
																																		case 168:
																																			num2 = 1;
																																			goto case 271;
																																		case 169:
																																			goto end_IL_0e5e;
																																		case 80:
																																		case 455:
																																			return;
																																		}
																																		continue;
																																	}
																																	array2[num6 - 2] = 3;
																																	goto IL_14ae_2;
																																	IL_14ae_2:
																																	num6--;
																																	goto IL_2e36_2;
																																	continue;
																																	end_IL_09af_2:
																																	break;
																																}
																																break;
																															}
																															goto IL_12e3_2;
																															continue;
																															end_IL_0a0d_2:
																															break;
																															IL_0a0d_2:;
																														}
																														break;
																														IL_0a1d_2:;
																													}
																													break;
																												}
																												num = 14;
																												goto IL_0b0e_2;
																												IL_0cb9_2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												num = 149;
																												goto IL_0d01_2;
																												IL_0d01_2:
																												ptr2 += 8;
																												num = 161;
																												goto IL_2e36_2;
																												IL_0b0e_2:
																												array2[num6 - 1] = 0;
																												goto IL_0cb9_2;
																											}
																											break;
																										}
																										goto IL_14c1_2;
																										IL_156f_2:
																										num6++;
																										goto IL_157d_2;
																										IL_14c1_2:
																										if (30 < b)
																										{
																											goto IL_14cc_2;
																										}
																										goto IL_153b_2;
																										IL_14cc_2:
																										if (31 < b)
																										{
																											break;
																										}
																										num = 562;
																										goto IL_14e3_2;
																										IL_157d_2:
																										ptr2 += 8;
																										goto IL_2e36_2;
																										IL_14e3_2:
																										if (31 > b)
																										{
																											break;
																										}
																										goto IL_14f1_2;
																										IL_14f1_2:
																										((delegate*<Class200, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																										goto IL_151a_2;
																										IL_151a_2:
																										num6--;
																										goto IL_1528_2;
																										IL_1528_2:
																										ptr2 += 8;
																										goto IL_2e36_2;
																										IL_153b_2:
																										if (30 > b)
																										{
																											break;
																										}
																										goto IL_1549_2;
																										IL_1549_2:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_1561_2;
																										IL_1561_2:
																										array2[num6] = 5;
																										goto IL_156f_2;
																									}
																									break;
																								}
																								goto IL_1590_2;
																								IL_15e3_2:
																								ptr2 += 8;
																								goto IL_2e36_2;
																								IL_1590_2:
																								array2[num6 - 1] = 3;
																								goto IL_15a4_2;
																								IL_15a4_2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_15e3_2;
																							}
																							break;
																						}
																						goto IL_15f6_2;
																						IL_17f5_2:
																						array2[num6 - 1] = 5;
																						num = 372;
																						goto IL_1812_2;
																						IL_15f6_2:
																						if (34 >= b)
																						{
																							goto IL_1604_2;
																						}
																						goto IL_1704_2;
																						IL_1604_2:
																						if (34 > b)
																						{
																							goto IL_1612_2;
																						}
																						num = 295;
																						goto IL_169f_2;
																						IL_1612_2:
																						if (33 < b)
																						{
																							break;
																						}
																						goto IL_1620_2;
																						IL_1620_2:
																						if (33 > b)
																						{
																							break;
																						}
																						goto IL_162e_2;
																						IL_162e_2:
																						array3[num6 - 1] = ((delegate*<Class200, Dictionary<int, GameObject>>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																						goto IL_1666_2;
																						IL_1666_2:
																						array2[num6 - 1] = 5;
																						goto IL_167a_2;
																						IL_167a_2:
																						ptr2 += 8;
																						num = 141;
																						goto IL_2e36_2;
																						IL_1812_2:
																						ptr2 += 8;
																						goto IL_2e36_2;
																						IL_169f_2:
																						array2[num6 - 1] = 0;
																						goto IL_16b3_2;
																						IL_16b3_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Dictionary<int, GameObject>, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Dictionary<int, GameObject>)array3[num6 - 1]);
																						goto IL_16f1_2;
																						IL_16f1_2:
																						ptr2 += 8;
																						goto IL_2e36_2;
																						IL_1704_2:
																						if (35 >= b)
																						{
																							goto IL_1712_2;
																						}
																						goto IL_17a1_2;
																						IL_1712_2:
																						if (35 > b)
																						{
																							break;
																						}
																						goto IL_1720_2;
																						IL_1720_2:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_178e_2;
																						IL_178e_2:
																						num6 -= 2;
																						goto IL_2e36_2;
																						IL_17a1_2:
																						if (36 < b)
																						{
																							break;
																						}
																						goto IL_17af_2;
																						IL_17af_2:
																						if (36 > b)
																						{
																							break;
																						}
																						goto IL_17bd_2;
																						IL_17bd_2:
																						array3[num6 - 1] = ((delegate*<Class200, List<Player>>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
																						goto IL_17f5_2;
																					}
																					break;
																				}
																				num = 526;
																				goto IL_182e_2;
																				IL_1b4c_2:
																				ptr2 += 16;
																				goto IL_2e36_2;
																				IL_1b5f_2:
																				array2[num6 - 1] = 3;
																				goto IL_1b73_2;
																				IL_182e_2:
																				if (27 > b)
																				{
																					goto IL_183c_2;
																				}
																				goto IL_1b5f_2;
																				IL_183c_2:
																				if (22 >= b)
																				{
																					goto IL_184a_2;
																				}
																				goto IL_19e2_2;
																				IL_184a_2:
																				if (22 > b)
																				{
																					goto IL_1858_2;
																				}
																				num = 553;
																				goto IL_197a_2;
																				IL_1858_2:
																				if (20 >= b)
																				{
																					goto IL_1866_2;
																				}
																				goto IL_193d_2;
																				IL_1866_2:
																				if (20 <= b)
																				{
																					goto IL_1871_2;
																				}
																				goto IL_18b9_2;
																				IL_1871_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																				goto IL_188a_2;
																				IL_188a_2:
																				array2[num6] = 1;
																				goto IL_1898_2;
																				IL_1898_2:
																				num6++;
																				goto IL_18a6_2;
																				IL_18a6_2:
																				ptr2 += 16;
																				goto IL_2e36_2;
																				IL_18b9_2:
																				if (19 < b)
																				{
																					break;
																				}
																				num = 433;
																				goto IL_18d0_2;
																				IL_1bb2_2:
																				ptr2 += 8;
																				goto IL_2e36_2;
																				IL_18d0_2:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_18de_2;
																				IL_18de_2:
																				array2[num6 - 1] = 5;
																				goto IL_18f2_2;
																				IL_18f2_2:
																				array3[num6 - 1] = ((delegate*<string[], string>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																				goto IL_192a_2;
																				IL_192a_2:
																				ptr2 += 8;
																				goto IL_2e36_2;
																				IL_193d_2:
																				if (21 < b)
																				{
																					break;
																				}
																				goto IL_194b_2;
																				IL_194b_2:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_1959_2;
																				IL_1959_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_2e36_2;
																				IL_1b73_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_1bb2_2;
																				IL_197a_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																				goto IL_19bb_2;
																				IL_19bb_2:
																				array2[num6 - 2] = 0;
																				goto IL_19cf_2;
																				IL_19cf_2:
																				num6--;
																				goto IL_2e36_2;
																				IL_19e2_2:
																				if (24 >= b)
																				{
																					goto IL_19f0_2;
																				}
																				goto IL_1a98_2;
																				IL_19f0_2:
																				if (24 <= b)
																				{
																					goto IL_19fb_2;
																				}
																				goto IL_1a17_2;
																				IL_19fb_2:
																				num7 = ptr2;
																				num8 = -200;
																				num5 = 1;
																				ptr2 = num7 + num8;
																				goto IL_2e36_2;
																				IL_1a17_2:
																				if (23 < b)
																				{
																					break;
																				}
																				goto IL_1a25_2;
																				IL_1a25_2:
																				if (23 > b)
																				{
																					break;
																				}
																				goto IL_1a33_2;
																				IL_1a33_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_1a85_2;
																				IL_1a85_2:
																				num6--;
																				goto IL_2e36_2;
																				IL_1a98_2:
																				if (25 >= b)
																				{
																					goto IL_1aa3_2;
																				}
																				goto IL_1afb_2;
																				IL_1aa3_2:
																				if (25 > b)
																				{
																					break;
																				}
																				goto IL_1ab1_2;
																				IL_1ab1_2:
																				((delegate*<string, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																				goto IL_1ada_2;
																				IL_1ada_2:
																				num6--;
																				goto IL_1ae8_2;
																				IL_1ae8_2:
																				ptr2 += 8;
																				goto IL_2e36_2;
																				IL_1afb_2:
																				if (26 < b)
																				{
																					break;
																				}
																				goto IL_1b09_2;
																				IL_1b09_2:
																				if (26 > b)
																				{
																					break;
																				}
																				goto IL_1b17_2;
																				IL_1b17_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																				goto IL_1b30_2;
																				IL_1b30_2:
																				array2[num6] = 3;
																				goto IL_1b3e_2;
																				IL_1b3e_2:
																				num6++;
																				goto IL_1b4c_2;
																			}
																			break;
																		}
																		goto IL_0af0_2;
																		IL_1284_2:
																		ptr2 += 8;
																		num = 541;
																		goto IL_129b_2;
																		IL_0af0_2:
																		if (18 > b)
																		{
																			goto IL_0afe_2;
																		}
																		goto IL_0f22_2;
																		IL_0afe_2:
																		if (9 >= b)
																		{
																			goto IL_0b27_2;
																		}
																		goto IL_0e25_2;
																		IL_0b27_2:
																		if (9 <= b)
																		{
																			goto IL_0b32_2;
																		}
																		goto IL_0b8b_2;
																		IL_0b32_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0b72_2;
																		IL_0b72_2:
																		array2[num6 - 2] = 0;
																		goto IL_0c33_2;
																		IL_0c33_2:
																		num6--;
																		goto IL_2e36_2;
																		IL_0b8b_2:
																		if (4 >= b)
																		{
																			goto IL_0b96_2;
																		}
																		goto IL_0c0c_2;
																		IL_0b96_2:
																		if (4 <= b)
																		{
																			goto IL_0ba1_2;
																		}
																		goto IL_0bd7_2;
																		IL_0ba1_2:
																		array2[num6] = 0;
																		goto IL_0baf_2;
																		IL_0baf_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_134b_2;
																		IL_134b_2:
																		array3[num6] = null;
																		goto IL_1355_2;
																		IL_1355_2:
																		num6++;
																		goto IL_1363_2;
																		IL_1363_2:
																		ptr2 += 8;
																		num = 501;
																		goto IL_2e36_2;
																		IL_0bd7_2:
																		if (2 < b)
																		{
																			goto IL_0be5_2;
																		}
																		goto IL_0f7c_2;
																		IL_0be5_2:
																		if (3 < b)
																		{
																			break;
																		}
																		num = 154;
																		goto IL_0bfc_2;
																		IL_129b_2:
																		num6--;
																		goto IL_2e36_2;
																		IL_0bfc_2:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0c46_2;
																		IL_0c46_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_137f_2;
																		IL_137f_2:
																		ptr2 += 8;
																		goto IL_138d_2;
																		IL_138d_2:
																		num6--;
																		goto IL_2e36_2;
																		IL_0f7c_2:
																		if (2 <= b)
																		{
																			goto IL_0f87_2;
																		}
																		goto IL_0fee_2;
																		IL_0f87_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0fc7_2;
																		IL_0fc7_2:
																		array2[num6 - 2] = 0;
																		goto IL_0fdb_2;
																		IL_0fdb_2:
																		num6--;
																		goto IL_2e36_2;
																		IL_0fee_2:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_0ffc_2;
																		IL_0ffc_2:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_100a_2;
																		IL_100a_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																		num = 279;
																		goto IL_102c_2;
																		IL_102c_2:
																		array2[num6] = 0;
																		goto IL_103a_2;
																		IL_103a_2:
																		num6++;
																		goto IL_1048_2;
																		IL_1048_2:
																		ptr2 += 8;
																		goto IL_2e36_2;
																		IL_0c0c_2:
																		if (6 >= b)
																		{
																			num = 22;
																			goto IL_0c23_2;
																		}
																		goto IL_0d1d_2;
																		IL_0f22_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_0f60_2;
																		IL_0c23_2:
																		if (6 <= b)
																		{
																			goto IL_0c74_2;
																		}
																		goto IL_13a0_2;
																		IL_0c74_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_12ae_2;
																		IL_12ae_2:
																		array2[num6 - 2] = 0;
																		goto IL_12c2_2;
																		IL_12c2_2:
																		num6--;
																		goto IL_2e36_2;
																		IL_13a0_2:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_1425_2;
																		IL_1425_2:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_1433_2;
																		IL_1433_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_1473_2;
																		IL_1473_2:
																		array2[num6 - 2] = 0;
																		goto IL_1487_2;
																		IL_1487_2:
																		num6--;
																		goto IL_2e36_2;
																		IL_0d1d_2:
																		if (7 >= b)
																		{
																			goto IL_0d2b_2;
																		}
																		goto IL_0db2_2;
																		IL_0d2b_2:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_0d39_2;
																		IL_0d39_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 273;
																		goto IL_0d82_2;
																		IL_0d82_2:
																		array2[num6 - 2] = 0;
																		goto IL_0d96_2;
																		IL_0d96_2:
																		num6--;
																		num = 544;
																		goto IL_2e36_2;
																		IL_0db2_2:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_0dc0_2;
																		IL_0dc0_2:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_1338_2;
																		IL_1338_2:
																		num6--;
																		goto IL_2e36_2;
																		IL_0e25_2:
																		if (13 >= b)
																		{
																			goto IL_0e33_2;
																		}
																		goto IL_105b_2;
																		IL_0e33_2:
																		if (13 <= b)
																		{
																			goto end_IL_0ada;
																		}
																		goto IL_115a_2;
																		IL_115a_2:
																		if (11 >= b)
																		{
																			goto IL_1168_2;
																		}
																		goto IL_1220_2;
																		IL_1168_2:
																		if (11 <= b)
																		{
																			goto IL_1176_2;
																		}
																		goto IL_11ff_2;
																		IL_1176_2:
																		array2[num6 - 2] = 0;
																		goto IL_118a_2;
																		IL_118a_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_11de_2;
																		IL_11de_2:
																		num6--;
																		goto IL_11ec_2;
																		IL_11ec_2:
																		ptr2 += 8;
																		goto IL_2e36_2;
																		IL_11ff_2:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_120d_2;
																		IL_120d_2:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_13b0_2;
																		IL_13b0_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_1412_2;
																		IL_1412_2:
																		num6 -= 2;
																		goto IL_2e36_2;
																		IL_1220_2:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_122e_2;
																		IL_122e_2:
																		if (12 > b)
																		{
																			break;
																		}
																		num = 213;
																		goto IL_2e36_2;
																		IL_0f60_2:
																		num6 -= 3;
																		num = 151;
																		goto IL_2e36_2;
																		IL_105b_2:
																		if (15 < b)
																		{
																			goto IL_1069_2;
																		}
																		goto IL_110a_2;
																		IL_1069_2:
																		if (16 >= b)
																		{
																			goto IL_1077_2;
																		}
																		goto IL_12d5_2;
																		IL_1077_2:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_1085_2;
																		IL_1085_2:
																		array2[num6] = array2[num6 - 1];
																		goto IL_109d_2;
																		IL_109d_2:
																		array4[num6 - 0] = array4[num6 - 1];
																		goto IL_10bb_2;
																		IL_10bb_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_10df_2;
																		IL_10df_2:
																		array3[num6] = array3[num6 - 1];
																		goto IL_10f7_2;
																		IL_10f7_2:
																		num6++;
																		goto IL_2e36_2;
																		IL_12d5_2:
																		if (17 < b)
																		{
																			break;
																		}
																		goto IL_12e3_2;
																		IL_12e3_2:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_12f1_2;
																		IL_12f1_2:
																		array2[num6] = 5;
																		goto IL_12ff_2;
																		IL_12ff_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_1317_2;
																		IL_1317_2:
																		num6++;
																		goto IL_1325_2;
																		IL_1325_2:
																		ptr2 += 8;
																		goto IL_2e36_2;
																		IL_110a_2:
																		if (15 <= b)
																		{
																			goto IL_1118_2;
																		}
																		goto IL_124a_2;
																		IL_1118_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_1141_2;
																		IL_1141_2:
																		array2[num6 - 1] = 5;
																		goto IL_2e36_2;
																		IL_124a_2:
																		if (14 < b)
																		{
																			break;
																		}
																		goto IL_1258_2;
																		IL_1258_2:
																		if (14 > b)
																		{
																			break;
																		}
																		goto IL_1266_2;
																		IL_1266_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_1284_2;
																	}
																	break;
																}
																goto IL_0dd3_2;
																IL_0e12_2:
																ptr2 += 8;
																goto IL_2e36_2;
																IL_0dd3_2:
																array3[num6] = ((delegate*<Class8.GunResult>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])();
																goto IL_0df6_2;
																IL_0df6_2:
																array2[num6] = 4;
																goto IL_0e04_2;
																IL_0e04_2:
																num6++;
																goto IL_0e12_2;
															}
															break;
														}
														goto IL_1bc5_2;
														IL_2d43_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_2d82_2;
														IL_1bc5_2:
														if (56 >= b)
														{
															goto IL_1bd3_2;
														}
														goto IL_2604_2;
														IL_1bd3_2:
														if (56 <= b)
														{
															goto IL_1bde_2;
														}
														goto IL_1c4d_2;
														IL_1bde_2:
														array2[num6 - 1] = 3;
														num = 599;
														goto IL_1bfb_2;
														IL_1bfb_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1c3a_2;
														IL_1c3a_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_1c4d_2:
														if (46 >= b)
														{
															goto IL_1c5b_2;
														}
														goto IL_2145_2;
														IL_1c5b_2:
														if (46 > b)
														{
															goto IL_1c69_2;
														}
														num = 595;
														goto IL_20e0_2;
														IL_1c69_2:
														if (41 >= b)
														{
															goto IL_1c77_2;
														}
														goto IL_1ebb_2;
														IL_1c77_2:
														if (41 > b)
														{
															goto IL_1c85_2;
														}
														goto IL_1e2b_2;
														IL_1c85_2:
														if (39 >= b)
														{
															goto IL_1c93_2;
														}
														goto IL_1da9_2;
														IL_1c93_2:
														if (39 > b)
														{
															goto IL_1c9e_2;
														}
														goto IL_1d19_2;
														IL_1c9e_2:
														if (38 < b)
														{
															break;
														}
														goto IL_1cac_2;
														IL_1cac_2:
														if (38 > b)
														{
															break;
														}
														goto IL_1cba_2;
														IL_1cba_2:
														array3[num6 - 1] = ((delegate*<Class8.GunResult, Player>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]);
														goto IL_1cf2_2;
														IL_1cf2_2:
														array2[num6 - 1] = 5;
														goto IL_1d06_2;
														IL_1d06_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_1d19_2:
														array2[num6 - 2] = 0;
														goto IL_1d2d_2;
														IL_1d2d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<List<Player>, Player, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((List<Player>)array3[num6 - 2], (Player)array3[num6 - 1]) ? 1 : 0);
														num = 107;
														goto IL_1d88_2;
														IL_1d88_2:
														num6--;
														goto IL_1d96_2;
														IL_1d96_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_1da9_2:
														if (40 < b)
														{
															break;
														}
														goto IL_1db7_2;
														IL_1db7_2:
														if (40 > b)
														{
															break;
														}
														goto IL_1dc5_2;
														IL_1dc5_2:
														array2[num6 - 1] = 3;
														goto IL_1dd9_2;
														IL_1dd9_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1e18_2;
														IL_1e18_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_1e2b_2:
														array2[num6 - 2] = 0;
														goto IL_1e3f_2;
														IL_1e3f_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<List<Player>, Player, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((List<Player>)array3[num6 - 2], (Player)array3[num6 - 1]) ? 1 : 0);
														goto IL_1e91_2;
														IL_1e91_2:
														num6--;
														num = 56;
														goto IL_1ea8_2;
														IL_1ea8_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_1ebb_2:
														if (43 >= b)
														{
															goto IL_1ec9_2;
														}
														goto IL_1fbf_2;
														IL_1ec9_2:
														if (43 > b)
														{
															goto IL_1ed7_2;
														}
														goto IL_1f5a_2;
														IL_1ed7_2:
														if (42 < b)
														{
															break;
														}
														goto IL_1ee5_2;
														IL_1ee5_2:
														if (42 > b)
														{
															break;
														}
														goto IL_1ef3_2;
														IL_1ef3_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1f33_2;
														IL_1f33_2:
														array2[num6 - 2] = 3;
														goto IL_1f47_2;
														IL_1f47_2:
														num6--;
														goto IL_2e36_2;
														IL_1f5a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
														goto IL_1f98_2;
														IL_1f98_2:
														array2[num6 - 1] = 0;
														goto IL_1fac_2;
														IL_1fac_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_1fbf_2:
														if (44 < b)
														{
															goto IL_1fcd_2;
														}
														num = 44;
														goto IL_2063_2;
														IL_1fcd_2:
														if (45 < b)
														{
															break;
														}
														goto IL_1fdb_2;
														IL_1fdb_2:
														if (45 > b)
														{
															break;
														}
														num = 404;
														goto IL_1ff2_2;
														IL_2da0_2:
														if (73 > b)
														{
															break;
														}
														goto IL_2dab_2;
														IL_1ff2_2:
														array3[num6 - 1] = ((delegate*<Class200, Dictionary<int, bool>>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
														goto IL_202a_2;
														IL_202a_2:
														array2[num6 - 1] = 5;
														num = 16;
														goto IL_2047_2;
														IL_2047_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2d95_2:
														if (73 >= b)
														{
															goto IL_2da0_2;
														}
														goto IL_2e0d_2;
														IL_2063_2:
														if (44 > b)
														{
															break;
														}
														goto IL_2071_2;
														IL_2071_2:
														array2[num6 - 1] = 3;
														goto IL_2085_2;
														IL_2085_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_20c4_2;
														IL_20c4_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2d82_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_20e0_2:
														array2[num6 - 1] = 0;
														goto IL_20f4_2;
														IL_20f4_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Player, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
														goto IL_2132_2;
														IL_2132_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2145_2:
														if (51 >= b)
														{
															goto IL_2153_2;
														}
														goto IL_23d9_2;
														IL_2153_2:
														if (51 <= b)
														{
															goto IL_215e_2;
														}
														goto IL_218a_2;
														IL_215e_2:
														global::_003CModule_003E.gunResult_9 = (Class8.GunResult)array3[num6 - 1];
														goto IL_2177_2;
														IL_2177_2:
														num6--;
														goto IL_2e36_2;
														IL_218a_2:
														if (48 >= b)
														{
															goto IL_2198_2;
														}
														goto IL_2280_2;
														IL_2198_2:
														if (48 <= b)
														{
															goto IL_21a3_2;
														}
														goto IL_21e7_2;
														IL_21a3_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_21ce_2;
														IL_21ce_2:
														array2[num6 - 1] = 0;
														goto IL_2e36_2;
														IL_21e7_2:
														if (47 < b)
														{
															break;
														}
														goto IL_21f5_2;
														IL_21f5_2:
														if (47 > b)
														{
															break;
														}
														num = 565;
														goto IL_220c_2;
														IL_2dab_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
														goto IL_2de9_2;
														IL_220c_2:
														((delegate*<Dictionary<int, bool>, int, bool, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Dictionary<int, bool>)array3[num6 - 3], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
														goto IL_225f_2;
														IL_225f_2:
														num6 -= 3;
														goto IL_226d_2;
														IL_226d_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2280_2:
														if (49 < b)
														{
															goto IL_228e_2;
														}
														goto IL_2379_2;
														IL_228e_2:
														if (50 < b)
														{
															break;
														}
														goto IL_229c_2;
														IL_229c_2:
														if (50 > b)
														{
															break;
														}
														goto IL_22aa_2;
														IL_22aa_2:
														array2[num6 - 5] = 4;
														num = 601;
														goto IL_22c7_2;
														IL_22c7_2:
														array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
														goto IL_2358_2;
														IL_2358_2:
														num6 -= 4;
														goto IL_2366_2;
														IL_2366_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2379_2:
														if (49 > b)
														{
															break;
														}
														num = 100;
														goto IL_2390_2;
														IL_2de9_2:
														array2[num6 - 1] = 0;
														goto IL_2dfd_2;
														IL_2390_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
														goto IL_23aa_2;
														IL_23aa_2:
														array2[num6] = 3;
														goto IL_23b8_2;
														IL_23b8_2:
														num6++;
														goto IL_23c6_2;
														IL_23c6_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_23d9_2:
														if (53 >= b)
														{
															goto IL_23e7_2;
														}
														goto IL_24e7_2;
														IL_23e7_2:
														if (53 > b)
														{
															goto IL_23f5_2;
														}
														goto IL_2480_2;
														IL_23f5_2:
														if (52 < b)
														{
															break;
														}
														goto IL_2403_2;
														IL_2403_2:
														if (52 > b)
														{
															break;
														}
														goto IL_2411_2;
														IL_2411_2:
														array2[num6 - 1] = 3;
														num = 146;
														goto IL_242e_2;
														IL_242e_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_246d_2;
														IL_246d_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2480_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_24c0_2;
														IL_24c0_2:
														array2[num6 - 2] = 3;
														goto IL_24d4_2;
														IL_24d4_2:
														num6--;
														goto IL_2e36_2;
														IL_24e7_2:
														if (54 >= b)
														{
															goto IL_24f2_2;
														}
														goto IL_2565_2;
														IL_24f2_2:
														if (54 > b)
														{
															break;
														}
														num = 310;
														goto IL_2509_2;
														IL_2dfd_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2509_2:
														array2[num6] = 0;
														num = 86;
														goto IL_2520_2;
														IL_2520_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_2544_2;
														IL_2544_2:
														num6++;
														goto IL_2552_2;
														IL_2552_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2565_2:
														if (55 < b)
														{
															break;
														}
														goto IL_2573_2;
														IL_2573_2:
														if (55 > b)
														{
															break;
														}
														goto IL_2581_2;
														IL_2581_2:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														num = 242;
														goto IL_25e8_2;
														IL_25e8_2:
														num6--;
														num = 394;
														goto IL_2e36_2;
														IL_2604_2:
														if (65 >= b)
														{
															goto IL_2612_2;
														}
														goto IL_29fb_2;
														IL_2612_2:
														if (65 <= b)
														{
															goto IL_261d_2;
														}
														goto IL_2667_2;
														IL_261d_2:
														((delegate*<Class200, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
														goto IL_2646_2;
														IL_2646_2:
														num6--;
														goto IL_2654_2;
														IL_2654_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2667_2:
														if (60 < b)
														{
															goto IL_2675_2;
														}
														num = 508;
														goto IL_2847_2;
														IL_2675_2:
														if (62 >= b)
														{
															goto IL_2683_2;
														}
														goto IL_273f_2;
														IL_2683_2:
														if (62 <= b)
														{
															goto IL_268e_2;
														}
														goto IL_26d8_2;
														IL_268e_2:
														((delegate*<string, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_26b7_2;
														IL_26b7_2:
														num6--;
														goto IL_26c5_2;
														IL_26c5_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_26d8_2:
														if (61 < b)
														{
															break;
														}
														goto IL_26e6_2;
														IL_26e6_2:
														if (61 > b)
														{
															break;
														}
														goto IL_26f4_2;
														IL_26f4_2:
														((delegate*<float, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
														goto IL_271e_2;
														IL_271e_2:
														num6--;
														goto IL_272c_2;
														IL_272c_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_273f_2:
														if (63 >= b)
														{
															goto IL_274a_2;
														}
														goto IL_27c7_2;
														IL_274a_2:
														if (63 > b)
														{
															break;
														}
														goto IL_2758_2;
														IL_2758_2:
														array2[num6 - 1] = 3;
														num = 239;
														goto IL_2775_2;
														IL_2775_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_27b4_2;
														IL_27b4_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_27c7_2:
														if (64 < b)
														{
															break;
														}
														goto IL_27d5_2;
														IL_27d5_2:
														if (64 > b)
														{
															break;
														}
														goto IL_27e3_2;
														IL_27e3_2:
														ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_282b_2;
														IL_282b_2:
														num6--;
														goto IL_2e36_2;
														IL_2e0d_2:
														if (74 < b)
														{
															break;
														}
														goto IL_2e18_2;
														IL_2847_2:
														if (60 <= b)
														{
															goto IL_2852_2;
														}
														goto IL_28b8_2;
														IL_2852_2:
														array2[num6 - 1] = 3;
														goto IL_2866_2;
														IL_2866_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_28a5_2;
														IL_28a5_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_28b8_2:
														if (58 >= b)
														{
															goto IL_28c6_2;
														}
														goto IL_299e_2;
														IL_28c6_2:
														if (58 <= b)
														{
															goto IL_28d1_2;
														}
														goto IL_2924_2;
														IL_28d1_2:
														array2[num6] = 3;
														goto IL_28df_2;
														IL_28df_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])();
														goto IL_2903_2;
														IL_2903_2:
														num6++;
														goto IL_2911_2;
														IL_2911_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2924_2:
														if (57 < b)
														{
															break;
														}
														goto IL_2932_2;
														IL_2932_2:
														if (57 > b)
														{
															break;
														}
														goto IL_2940_2;
														IL_2940_2:
														((delegate*<List<Player>, Player, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((List<Player>)array3[num6 - 2], (Player)array3[num6 - 1]);
														goto IL_297d_2;
														IL_297d_2:
														num6 -= 2;
														goto IL_298b_2;
														IL_298b_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_299e_2:
														if (59 < b)
														{
															break;
														}
														goto IL_29ac_2;
														IL_29ac_2:
														if (59 > b)
														{
															break;
														}
														goto IL_29ba_2;
														IL_29ba_2:
														((Class200)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_29e8_2;
														IL_29e8_2:
														num6 -= 2;
														goto IL_2e36_2;
														IL_29fb_2:
														if (70 >= b)
														{
															goto IL_2a09_2;
														}
														goto IL_2c9b_2;
														IL_2a09_2:
														if (70 > b)
														{
															goto IL_2a17_2;
														}
														goto IL_2c2d_2;
														IL_2a17_2:
														if (67 >= b)
														{
															goto IL_2a25_2;
														}
														goto IL_2b06_2;
														IL_2a25_2:
														if (67 <= b)
														{
															goto IL_2a30_2;
														}
														goto IL_2a83_2;
														IL_2a30_2:
														array2[num6] = 3;
														goto IL_2a3e_2;
														IL_2a3e_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])();
														goto IL_2a62_2;
														IL_2a62_2:
														num6++;
														goto IL_2a70_2;
														IL_2a70_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2a83_2:
														if (66 < b)
														{
															break;
														}
														goto IL_2a91_2;
														IL_2a91_2:
														if (66 > b)
														{
															break;
														}
														goto IL_2a9f_2;
														IL_2a9f_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2adf_2;
														IL_2adf_2:
														array2[num6 - 2] = 3;
														goto IL_2af3_2;
														IL_2af3_2:
														num6--;
														goto IL_2e36_2;
														IL_2b06_2:
														if (68 < b)
														{
															goto IL_2b14_2;
														}
														num = 5;
														goto IL_2bba_2;
														IL_2b14_2:
														if (69 < b)
														{
															break;
														}
														goto IL_2b22_2;
														IL_2b22_2:
														if (69 > b)
														{
															break;
														}
														goto IL_2b30_2;
														IL_2b30_2:
														ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_2b9e_2;
														IL_2b9e_2:
														num6 -= 2;
														goto IL_2e36_2;
														IL_2e18_2:
														if (74 <= b)
														{
														}
														break;
														IL_2bba_2:
														if (68 > b)
														{
															break;
														}
														goto IL_2bc8_2;
														IL_2bc8_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class200, float>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 1]);
														goto IL_2c06_2;
														IL_2c06_2:
														array2[num6 - 1] = 3;
														goto IL_2c1a_2;
														IL_2c1a_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2c2d_2:
														array2[num6 - 1] = 0;
														num = 505;
														goto IL_2c4a_2;
														IL_2c4a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Player, int>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
														goto IL_2c88_2;
														IL_2c88_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2c9b_2:
														if (72 >= b)
														{
															goto IL_2ca9_2;
														}
														goto IL_2d95_2;
														IL_2ca9_2:
														if (72 > b)
														{
															goto IL_2cb4_2;
														}
														goto IL_2d2f_2;
														IL_2cb4_2:
														if (71 < b)
														{
															break;
														}
														goto IL_2cc2_2;
														IL_2cc2_2:
														if (71 > b)
														{
															break;
														}
														goto IL_2cd0_2;
														IL_2cd0_2:
														((delegate*<Class200, int, void>)SoapTimeAssemblyBuilderLock[*(int*)(ptr2 + num3)])((Class200)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_2d0e_2;
														IL_2d0e_2:
														num6 -= 2;
														goto IL_2d1c_2;
														IL_2d1c_2:
														ptr2 += 8;
														goto IL_2e36_2;
														IL_2d2f_2:
														array2[num6 - 1] = 3;
														goto IL_2d43_2;
													}
													break;
													IL_0aaa_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_2e36_2;
											continue;
											end_IL_0aba_2:
											break;
										}
										continue;
										end_IL_0aca:
										break;
									}
									continue;
									end_IL_0ada:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_0e50_2;
					}
					continue;
					end_IL_0e5e:
					break;
				}
				break;
			}
		}
	}

	static Class200()
	{
		int num = 10;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					string_0 = "SchizophreniaGun";
					num = 20;
					while (true)
					{
						if (num != 20)
						{
							if (num != 1001)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 2:
							case 3:
							case 4:
							case 5:
							case 6:
							case 7:
							case 8:
							case 11:
							case 12:
							case 13:
								goto end_IL_005f;
							case 9:
								goto end_IL_006f;
							case 10:
								goto end_IL_00f0;
							}
							continue;
						}
						return;
						continue;
						end_IL_005f:
						break;
					}
					continue;
					end_IL_006f:
					break;
				}
				continue;
				end_IL_00f0:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0)
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								num = 92;
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EphemeralKeySetNormal.IsSameTokenImpersonation);
										num = 39;
										while (true)
										{
											IL_0788:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0775:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d1:
														byte b = *ptr2;
														while (true)
														{
															IL_02c1:
															ptr2++;
															while (true)
															{
																IL_02b1:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0291:
																			if (7 >= b)
																			{
																				num = 43;
																				while (true)
																				{
																					IL_0281:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0271:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_025e:
																									if (3 > b)
																									{
																										num = 136;
																										while (true)
																										{
																											if (num != 136)
																											{
																												if (num != 1117)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 122:
																													goto IL_025e;
																												case 46:
																												case 114:
																													goto IL_0271;
																												case 43:
																													goto IL_0281;
																												case 77:
																													goto IL_0291;
																												case 7:
																													goto IL_02a1;
																												case 42:
																													goto IL_02b1;
																												case 28:
																													goto IL_02c1;
																												case 90:
																												case 117:
																													goto IL_02d1;
																												case 26:
																													goto IL_02dc;
																												case 62:
																													goto IL_02ea;
																												case 29:
																												case 88:
																													goto IL_02f8;
																												case 31:
																												case 52:
																													goto IL_0303;
																												case 12:
																													goto IL_0313;
																												case 91:
																													goto IL_0326;
																												case 33:
																												case 78:
																													goto IL_0334;
																												case 63:
																													goto IL_0374;
																												case 60:
																													goto IL_0391;
																												case 1:
																												case 94:
																													goto IL_03ad;
																												case 64:
																													goto IL_040f;
																												case 102:
																													goto IL_0422;
																												case 56:
																												case 80:
																													goto IL_0439;
																												case 98:
																													goto IL_0447;
																												case 25:
																												case 119:
																													goto IL_045a;
																												case 22:
																												case 97:
																													goto IL_0468;
																												case 95:
																													goto IL_0476;
																												case 59:
																												case 89:
																													goto IL_0484;
																												case 87:
																													goto IL_04c4;
																												case 24:
																													goto IL_04e1;
																												case 103:
																													goto IL_04f4;
																												case 21:
																												case 44:
																													goto IL_04ff;
																												case 35:
																													goto IL_050d;
																												case 71:
																													goto IL_0530;
																												case 110:
																													goto IL_053a;
																												case 3:
																													goto IL_054a;
																												case 23:
																													goto IL_0558;
																												case 125:
																													goto IL_056b;
																												case 128:
																													goto IL_057e;
																												case 120:
																													goto IL_0589;
																												case 66:
																													goto IL_0597;
																												case 84:
																												case 96:
																													goto IL_05a5;
																												case 14:
																												case 18:
																													goto IL_05b8;
																												case 11:
																												case 129:
																													goto IL_05d4;
																												case 127:
																													goto IL_05e8;
																												case 76:
																													goto IL_0627;
																												case 104:
																													goto IL_063a;
																												case 113:
																													goto IL_0645;
																												case 53:
																												case 73:
																													goto IL_0653;
																												case 118:
																													goto IL_066c;
																												case 101:
																													goto IL_067a;
																												case 65:
																													goto IL_0688;
																												case 10:
																													goto IL_069b;
																												case 85:
																													goto IL_06a9;
																												case 2:
																												case 9:
																													goto IL_06b7;
																												case 106:
																													goto IL_06e0;
																												case 41:
																													goto IL_06ee;
																												case 55:
																												case 70:
																													goto IL_06fe;
																												case 16:
																												case 74:
																													goto IL_0713;
																												case 30:
																													goto IL_0736;
																												case 15:
																													goto IL_0744;
																												case 17:
																													goto IL_0752;
																												case 4:
																												case 5:
																												case 8:
																												case 13:
																												case 27:
																												case 32:
																												case 34:
																												case 37:
																												case 40:
																												case 47:
																												case 48:
																												case 51:
																												case 57:
																												case 72:
																												case 75:
																												case 81:
																												case 99:
																												case 100:
																												case 108:
																												case 112:
																												case 115:
																												case 121:
																												case 124:
																													goto end_IL_02a1;
																												case 0:
																												case 36:
																												case 45:
																												case 49:
																												case 50:
																												case 58:
																												case 68:
																												case 69:
																												case 79:
																												case 83:
																												case 86:
																												case 105:
																												case 109:
																												case 111:
																												case 116:
																												case 123:
																													goto IL_0775;
																												case 39:
																													goto IL_0788;
																												case 67:
																													goto end_IL_024b;
																												case 92:
																													goto end_IL_0792;
																												case 6:
																													goto end_IL_07a6;
																												case 107:
																												case 126:
																													goto end_IL_07bb;
																												case 93:
																													goto end_IL_07d4;
																												case 54:
																												case 61:
																													goto end_IL_07e4;
																												case 19:
																													goto end_IL_07f4;
																												case 20:
																													goto end_IL_0804;
																												case 38:
																												case 82:
																													goto IL_081f;
																												}
																												continue;
																											}
																											goto IL_063a;
																											IL_06e0:
																											ptr2 += 8;
																											goto IL_06ee;
																											IL_06ee:
																											num5--;
																											goto IL_0775;
																											IL_063a:
																											if (1 >= b)
																											{
																												goto IL_0645;
																											}
																											goto IL_069b;
																											IL_0645:
																											if (1 > b)
																											{
																												goto end_IL_02a1;
																											}
																											goto IL_0653;
																											IL_0653:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_066c;
																											IL_066c:
																											array[num5] = 0;
																											goto IL_067a;
																											IL_067a:
																											num5++;
																											goto IL_0688;
																											IL_0688:
																											ptr2 += 8;
																											goto IL_0775;
																											IL_069b:
																											if (2 < b)
																											{
																												goto end_IL_02a1;
																											}
																											goto IL_06a9;
																											IL_06a9:
																											if (2 > b)
																											{
																												goto end_IL_02a1;
																											}
																											goto IL_06b7;
																											IL_06b7:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_06e0;
																											continue;
																											end_IL_024b:
																											break;
																										}
																										break;
																									}
																									goto IL_06fe;
																									IL_06fe:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_0775;
																								}
																								break;
																							}
																							goto IL_045a;
																							IL_0558:
																							if (4 > b)
																							{
																								goto end_IL_02a1;
																							}
																							goto IL_0775;
																							IL_045a:
																							if (5 < b)
																							{
																								goto IL_0468;
																							}
																							goto IL_04f4;
																							IL_0468:
																							if (6 < b)
																							{
																								goto end_IL_02a1;
																							}
																							goto IL_0476;
																							IL_0476:
																							if (6 > b)
																							{
																								goto end_IL_02a1;
																							}
																							goto IL_0484;
																							IL_0484:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04c4;
																							IL_04c4:
																							array[num5 - 2] = 0;
																							num = 24;
																							goto IL_04e1;
																							IL_04e1:
																							num5--;
																							goto IL_0775;
																							IL_04f4:
																							if (5 <= b)
																							{
																								goto IL_04ff;
																							}
																							goto IL_054a;
																							IL_04ff:
																							array[num5] = 0;
																							goto IL_050d;
																							IL_050d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0530;
																							IL_0530:
																							array2[num5] = null;
																							goto IL_053a;
																							IL_053a:
																							num5++;
																							goto IL_056b;
																							IL_056b:
																							ptr2 += 8;
																							goto IL_0775;
																							IL_054a:
																							if (4 < b)
																							{
																								goto end_IL_02a1;
																							}
																							goto IL_0558;
																						}
																						break;
																					}
																					goto IL_0713;
																					IL_0752:
																					ptr2 += 8;
																					goto IL_0775;
																					IL_0713:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0736;
																					IL_0736:
																					array[num5] = 0;
																					goto IL_0744;
																					IL_0744:
																					num5++;
																					goto IL_0752;
																				}
																				break;
																			}
																			goto IL_02dc;
																			IL_0597:
																			if (11 > b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_05a5;
																			IL_05a5:
																			num5--;
																			goto IL_0775;
																			IL_02dc:
																			if (10 >= b)
																			{
																				goto IL_02ea;
																			}
																			goto IL_0422;
																			IL_02ea:
																			if (10 > b)
																			{
																				goto IL_02f8;
																			}
																			goto IL_05d4;
																			IL_02f8:
																			if (8 < b)
																			{
																				goto IL_0303;
																			}
																			goto IL_0313;
																			IL_0303:
																			if (9 < b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_0326;
																			IL_0326:
																			if (9 > b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_0334;
																			IL_0334:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0374;
																			IL_0374:
																			array[num5 - 2] = 0;
																			num = 60;
																			goto IL_0391;
																			IL_0391:
																			num5--;
																			num = 83;
																			goto IL_0775;
																			IL_0313:
																			if (8 > b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_03ad;
																			IL_03ad:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_040f;
																			IL_040f:
																			num5 -= 2;
																			goto IL_0775;
																			IL_05d4:
																			array[num5 - 1] = 0;
																			goto IL_05e8;
																			IL_05e8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ContextBoundObjectNewKeyset[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0627;
																			IL_0627:
																			ptr2 += 8;
																			goto IL_0775;
																			IL_0422:
																			if (12 < b)
																			{
																				num = 80;
																				goto IL_0439;
																			}
																			goto IL_057e;
																			IL_05b8:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_0775;
																			IL_0439:
																			if (13 < b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_0447;
																			IL_0447:
																			if (13 > b)
																			{
																			}
																			goto end_IL_02a1;
																			IL_057e:
																			if (12 > b)
																			{
																				goto IL_0589;
																			}
																			goto IL_05b8;
																			IL_0589:
																			if (11 < b)
																			{
																				goto end_IL_02a1;
																			}
																			goto IL_0597;
																		}
																		goto end_IL_02b1;
																		continue;
																		end_IL_02a1:
																		break;
																		IL_02a1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0775;
																continue;
																end_IL_02b1:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_081f;
												IL_081f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										continue;
										end_IL_0792:
										break;
									}
									continue;
									end_IL_07a6:
									break;
								}
								continue;
								end_IL_07bb:
								break;
							}
							continue;
							end_IL_07d4:
							break;
						}
						continue;
						end_IL_07e4:
						break;
					}
					continue;
					end_IL_07f4:
					break;
				}
				continue;
				end_IL_0804:
				break;
			}
		}
	}

	private static void RawDefaultValueAssemblyHashAlgorithm(ref Dictionary<int, GameObject>.Enumerator enumerator_0)
	{
		((IDisposable)enumerator_0/*cast due to .constrained prefix*/).Dispose();
	}
}
