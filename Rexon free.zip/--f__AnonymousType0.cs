using System.Collections.Generic;

internal sealed class _003C_003Ef__AnonymousType0<_003CPlayFabId_003Ej__TPar>
{
	private _003CPlayFabId_003Ej__TPar _003CPlayFabId_003Ei__Field;

	internal static object object_0;

	public _003CPlayFabId_003Ej__TPar PlayFabId
	{
		get
		{
			int num = 5;
			int num2 = 5;
			num2 = 5;
			int[] array = new int[8] { 0, 0, 0, 0, 0, 1, 0, 2 };
			_003CPlayFabId_003Ej__TPar result = default(_003CPlayFabId_003Ej__TPar);
			while (true)
			{
				if (num2 != 0)
				{
					switch (array[num + 0])
					{
					default:
					{
						string text = "s";
						string text2 = "r";
						string text3 = "a";
						string text4 = "o";
						string text5 = "I";
						string text6 = "t";
						string text7 = "l";
						_ = text5 + text + text4 + text7 + text3 + text6 + text4 + text2;
						num = 7;
						continue;
					}
					case 2:
					{
						_003CPlayFabId_003Ej__TPar val = _003CPlayFabId_003Ei__Field;
						num2 = 0;
						result = val;
						continue;
					}
					case 0:
						break;
					}
				}
				else
				{
					num2 = 5;
				}
				break;
			}
			return result;
		}
	}

	public override int GetHashCode()
	{
		int num = 6;
		int result = default(int);
		while (true)
		{
			int num2 = 7;
			while (true)
			{
				int num3 = 7;
				while (true)
				{
					IL_00c4:
					num3 = 7;
					while (true)
					{
						IL_00b1:
						int[] array = new int[8];
						num = 3;
						while (true)
						{
							IL_00aa:
							array[7] = 1;
							while (true)
							{
								IL_00a0:
								if (num3 != 0)
								{
									while (true)
									{
										IL_000e:
										switch (array[num2 + 0])
										{
										case 0:
											break;
										default:
											goto IL_0084;
										}
										num = 17;
										while (num != 17)
										{
											if (num != 998)
											{
												goto end_IL_00a0;
											}
											switch (num)
											{
											case 1:
												break;
											default:
												continue;
											case 0:
												goto IL_0084;
											case 2:
											case 9:
												goto IL_00a0;
											case 3:
												goto IL_00aa;
											case 10:
												goto IL_00b1;
											case 7:
												goto IL_00c4;
											case 5:
												goto end_IL_00a0;
											case 6:
												goto end_IL_00c9;
											case 4:
												goto IL_00d3;
											case 8:
												goto end_IL_006c;
											}
											goto IL_000e;
											continue;
											end_IL_006c:
											break;
										}
										break;
										IL_0084:
										int num4 = -191492656 + EqualityComparer<_003CPlayFabId_003Ej__TPar>.Default.GetHashCode(_003CPlayFabId_003Ei__Field);
										num3 = 0;
										result = num4;
										goto IL_00a0;
									}
									goto IL_00d6;
								}
								goto IL_00d3;
								IL_00d6:
								return result;
								IL_00d3:
								num3 = 7;
								goto IL_00d6;
								continue;
								end_IL_00a0:
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_00c9:
				break;
			}
		}
	}

	public override string ToString()
	{
		int num = 24;
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string result = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		while (true)
		{
			int num2 = 4;
			while (true)
			{
				int num3 = 4;
				while (true)
				{
					num3 = 4;
					while (true)
					{
						int[] array = new int[8];
						while (true)
						{
							array[4] = 1;
							while (true)
							{
								IL_028e:
								if (num3 != 0)
								{
									while (true)
									{
										switch (array[num2 + 0])
										{
										case 0:
											goto end_IL_000e;
										}
										while (true)
										{
											IL_0147:
											string text = "y";
											while (true)
											{
												IL_0136:
												string text2 = "=";
												while (true)
												{
													IL_011e:
													string text3 = "}";
													while (true)
													{
														IL_0106:
														string text4 = "b";
														while (true)
														{
															IL_00ee:
															string text5 = "{";
															while (true)
															{
																string text6 = "P";
																while (true)
																{
																	IL_00bc:
																	string text7 = "d";
																	num = 31;
																	while (true)
																	{
																		if (num != 31)
																		{
																			if (num != 1012)
																			{
																				break;
																			}
																			switch (num)
																			{
																			case 12:
																				break;
																			default:
																				continue;
																			case 18:
																				goto IL_00bc;
																			case 20:
																				goto end_IL_00a9;
																			case 13:
																				goto IL_00ee;
																			case 1:
																				goto IL_0106;
																			case 5:
																				goto IL_011e;
																			case 22:
																				goto IL_0136;
																			case 11:
																				goto IL_0147;
																			case 17:
																				goto IL_016e;
																			case 7:
																				goto IL_0184;
																			case 4:
																				goto IL_019a;
																			case 3:
																				goto IL_01a9;
																			case 9:
																				goto IL_01b8;
																			case 15:
																				goto IL_01ce;
																			case 14:
																				goto IL_0251;
																			case 2:
																			case 16:
																				goto IL_028e;
																			case 10:
																				goto end_IL_028e;
																			case 21:
																				goto end_IL_0298;
																			case 0:
																				goto end_IL_029f;
																			case 23:
																				goto end_IL_02a9;
																			case 24:
																				goto end_IL_02ae;
																			case 6:
																				goto IL_02b8;
																			case 8:
																			case 19:
																				goto end_IL_000e;
																			}
																			goto end_IL_00dd;
																		}
																		text8 = "F";
																		goto IL_016e;
																		IL_01b8:
																		text9 = "I";
																		goto IL_01ce;
																		IL_0251:
																		string format = text10;
																		object[] array2 = new object[1];
																		_003CPlayFabId_003Ej__TPar val = _003CPlayFabId_003Ei__Field;
																		array2[0] = ((val == null) ? null : val.ToString());
																		string text11 = string.Format(null, format, array2);
																		num3 = 0;
																		result = text11;
																		goto IL_028e;
																		IL_01ce:
																		text10 = text5 + text5 + text12 + text6 + text13 + text14 + text + text8 + text14 + text4 + text9 + text7 + text12 + text2 + text12 + text5 + text15 + text3 + text12 + text3 + text3;
																		goto IL_0251;
																		IL_016e:
																		text14 = "a";
																		goto IL_0184;
																		IL_0184:
																		text13 = "l";
																		goto IL_019a;
																		IL_019a:
																		text12 = " ";
																		goto IL_01a9;
																		IL_01a9:
																		text15 = "0";
																		goto IL_01b8;
																		continue;
																		end_IL_00a9:
																		break;
																	}
																	break;
																}
																continue;
																end_IL_00dd:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										continue;
										end_IL_000e:
										break;
									}
									goto IL_02be;
								}
								goto IL_02b8;
								IL_02be:
								return result;
								IL_02b8:
								num3 = 4;
								goto IL_02be;
								continue;
								end_IL_028e:
								break;
							}
							continue;
							end_IL_0298:
							break;
						}
						continue;
						end_IL_029f:
						break;
					}
					continue;
					end_IL_02a9:
					break;
				}
				continue;
				end_IL_02ae:
				break;
			}
		}
	}

	public override bool Equals(object value)
	{
		int num = 24;
		bool result = default(bool);
		int num4 = default(int);
		_003C_003Ef__AnonymousType0<_003CPlayFabId_003Ej__TPar> _003C_003Ef__AnonymousType6 = default(_003C_003Ef__AnonymousType0<_003CPlayFabId_003Ej__TPar>);
		while (true)
		{
			int num2 = 7;
			while (true)
			{
				int num3 = 7;
				while (true)
				{
					num3 = 7;
					while (true)
					{
						int[] array = new int[12];
						while (true)
						{
							array[7] = 1;
							while (true)
							{
								array[9] = 2;
								while (true)
								{
									array[6] = 3;
									while (true)
									{
										array[11] = 4;
										while (true)
										{
											array[10] = 5;
											while (true)
											{
												IL_0139:
												if (num3 != 0)
												{
													while (true)
													{
														IL_000e:
														switch (array[num2 + 0])
														{
														case 4:
															break;
														case 3:
															goto IL_00e3;
														case 2:
															goto IL_0102;
														default:
															goto IL_0117;
														case 5:
															goto IL_0132;
														case 0:
															goto end_IL_000e;
														}
														while (true)
														{
															IL_00d1:
															num3 = 0;
															result = false;
															num = 33;
															while (num != 33)
															{
																if (num != 1014)
																{
																	goto IL_0132;
																}
																switch (num)
																{
																case 16:
																	break;
																default:
																	continue;
																case 0:
																	goto IL_00d1;
																case 4:
																	goto IL_00e3;
																case 6:
																	goto IL_0102;
																case 8:
																	goto IL_0109;
																case 10:
																	goto IL_0110;
																case 22:
																	goto IL_0117;
																case 15:
																	goto IL_011f;
																case 25:
																	goto IL_012b;
																case 18:
																	goto IL_0132;
																case 1:
																case 9:
																case 19:
																case 20:
																case 26:
																	goto end_IL_00c1;
																case 7:
																	goto end_IL_0139;
																case 5:
																	goto end_IL_0143;
																case 13:
																	goto end_IL_014b;
																case 21:
																	goto end_IL_0153;
																case 17:
																	goto end_IL_015a;
																case 11:
																	goto end_IL_0162;
																case 3:
																	goto end_IL_0169;
																case 23:
																	goto end_IL_0174;
																case 24:
																	goto end_IL_0179;
																case 2:
																	goto IL_0183;
																case 12:
																case 14:
																	goto end_IL_000e;
																}
																goto IL_000e;
																continue;
																end_IL_00c1:
																break;
															}
															break;
														}
														goto IL_0139;
														IL_0110:
														num2 = num4;
														goto IL_0139;
														IL_0132:
														num3 = 0;
														result = true;
														goto IL_0139;
														IL_0117:
														_003C_003Ef__AnonymousType6 = value as _003C_003Ef__AnonymousType0<_003CPlayFabId_003Ej__TPar>;
														goto IL_011f;
														IL_011f:
														num4 = ((this == _003C_003Ef__AnonymousType6) ? 1 : 0) * 1 + 9;
														goto IL_012b;
														IL_012b:
														num2 = num4;
														goto IL_0139;
														IL_0102:
														if (_003C_003Ef__AnonymousType6 != null)
														{
															goto IL_0109;
														}
														int num5 = 1;
														goto IL_010a;
														IL_00e3:
														bool num6 = EqualityComparer<_003CPlayFabId_003Ej__TPar>.Default.Equals(_003CPlayFabId_003Ei__Field, _003C_003Ef__AnonymousType6._003CPlayFabId_003Ei__Field);
														num3 = 0;
														result = num6;
														goto IL_0139;
														IL_0109:
														num5 = 0;
														goto IL_010a;
														IL_010a:
														num4 = num5 * 5 + 6;
														goto IL_0110;
														continue;
														end_IL_000e:
														break;
													}
													goto IL_0189;
												}
												goto IL_0183;
												IL_0189:
												return result;
												IL_0183:
												num3 = 7;
												goto IL_0189;
												continue;
												end_IL_0139:
												break;
											}
											continue;
											end_IL_0143:
											break;
										}
										continue;
										end_IL_014b:
										break;
									}
									continue;
									end_IL_0153:
									break;
								}
								continue;
								end_IL_015a:
								break;
							}
							continue;
							end_IL_0162:
							break;
						}
						continue;
						end_IL_0169:
						break;
					}
					continue;
					end_IL_0174:
					break;
				}
				continue;
				end_IL_0179:
				break;
			}
		}
	}

	public _003C_003Ef__AnonymousType0(_003CPlayFabId_003Ej__TPar PlayFabId)
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
		int num = 5;
		int num2 = 5;
		num2 = 5;
		int[] array = new int[7] { 0, 0, 0, 0, 0, 1, 0 };
		while (num2 != 0)
		{
			switch (array[num + 0])
			{
			case 0:
				return;
			}
			_003CPlayFabId_003Ei__Field = PlayFabId;
			num2 = 0;
		}
		num2 = 5;
	}

	internal static bool smethod_0()
	{
		return object_0 == null;
	}

	internal static object smethod_1()
	{
		return object_0;
	}
}
