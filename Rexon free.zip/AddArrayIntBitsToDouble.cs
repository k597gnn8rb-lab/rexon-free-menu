using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 11)]
internal struct AddArrayIntBitsToDouble
{
	internal static AddArrayIntBitsToDouble getSafeWaitHandlegetNameClaimType/* Not supported: data(01 00 00 00 00 00 00 00 00 02 03) */;
}
