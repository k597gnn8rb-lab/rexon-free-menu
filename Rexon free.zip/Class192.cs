using System;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Platform Wall Walk [RIGHT GRIP]", "Rig", "Spawn a platform to walk on walls.", false, 29, ModType.const_0, false)]
internal class Class192 : MonoBehaviour
{
	private Vector3 vector3_0;

	private Vector3 vector3_1;

	private GameObject gameObject_0;

	private static Vector3 vector3_2;

	private static float float_0;

	private static int int_0;

	private static float float_1;

	private static double double_0;

	private static bool bool_0;

	private static IntPtr[] NOTIFCONVERTWARNINGCodePageDataFileHeader;

	private static IntPtr[] HeaderNameRC;

	private static IntPtr[] VerifyContextRuntimeTypeHandle;

	private static IntPtr[] UnhandledExceptionTraceSynchronousWorkStart;

	private static IntPtr[] IKeyValuePairVTDISPATCH;

	private static CapsuleCollider StringComparisonsetLongDatePattern(GTPlayer gtplayer_0)
	{
		return gtplayer_0.bodyCollider;
	}

	private static GameObject TypeNameBuilderWaitAny(Class192 class192_1)
	{
		return class192_1.gameObject_0;
	}

	private static Vector3 SEPTimeEndProlog(Transform transform_0)
	{
		return transform_0.position;
	}

	private unsafe static int smethod_0()
	{
		int num = 117;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 116;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 19;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IMuiResourceIdLookupMapEntryReuseSlot.FreeNativeOverlappedSafeIsolatedStorageFileHandle);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0301:
															byte b = *ptr2;
															while (true)
															{
																IL_02f1:
																ptr2++;
																while (true)
																{
																	IL_02e1:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02c1:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02b4:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02a4:
																								if (4 >= b)
																								{
																									num = 157;
																									while (true)
																									{
																										if (num != 157)
																										{
																											if (num != 1138)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 147:
																												goto IL_02a4;
																											case 144:
																												goto IL_02b4;
																											case 145:
																												goto IL_02c1;
																											case 40:
																												goto IL_02d1;
																											case 50:
																												goto IL_02e1;
																											case 120:
																												goto IL_02f1;
																											case 17:
																											case 22:
																												goto IL_0301;
																											case 16:
																											case 57:
																												goto IL_030c;
																											case 75:
																												goto IL_0324;
																											case 2:
																												goto IL_032f;
																											case 33:
																												goto IL_033a;
																											case 1:
																											case 87:
																												goto IL_034d;
																											case 80:
																												goto IL_038c;
																											case 29:
																											case 132:
																												goto IL_039f;
																											case 44:
																												goto IL_03ad;
																											case 73:
																											case 135:
																												goto IL_03c6;
																											case 38:
																												goto IL_03ef;
																											case 139:
																												goto IL_03ff;
																											case 3:
																											case 78:
																												goto IL_040d;
																											case 105:
																												goto IL_041b;
																											case 72:
																												goto IL_0433;
																											case 21:
																												goto IL_0441;
																											case 141:
																												goto IL_0454;
																											case 24:
																											case 148:
																												goto IL_0467;
																											case 5:
																											case 113:
																												goto IL_0472;
																											case 119:
																												goto IL_047d;
																											case 94:
																											case 106:
																												goto IL_048b;
																											case 0:
																											case 46:
																												goto IL_04a7;
																											case 56:
																												goto IL_04b5;
																											case 93:
																												goto IL_04c8;
																											case 53:
																											case 118:
																												goto IL_04d6;
																											case 35:
																											case 138:
																												goto IL_04e4;
																											case 112:
																												goto IL_04f2;
																											case 41:
																											case 55:
																												goto IL_0500;
																											case 97:
																												goto IL_0544;
																											case 14:
																												goto IL_0558;
																											case 65:
																												goto IL_056b;
																											case 82:
																											case 121:
																												goto IL_0576;
																											case 64:
																												goto IL_0584;
																											case 108:
																											case 115:
																												goto IL_0597;
																											case 124:
																												goto IL_05a5;
																											case 36:
																												goto IL_05c8;
																											case 52:
																												goto IL_05d2;
																											case 88:
																												goto IL_05e0;
																											case 15:
																											case 90:
																												goto IL_05f3;
																											case 31:
																												goto IL_0633;
																											case 61:
																												goto IL_0647;
																											case 109:
																											case 149:
																												goto IL_065a;
																											case 27:
																												goto IL_0668;
																											case 13:
																											case 85:
																												goto IL_0676;
																											case 10:
																												goto IL_06e1;
																											case 8:
																											case 81:
																												goto IL_0702;
																											case 79:
																												goto IL_0710;
																											case 83:
																											case 133:
																												goto IL_071b;
																											case 66:
																												goto IL_075b;
																											case 11:
																												goto IL_076f;
																											case 67:
																												goto IL_0782;
																											case 130:
																												goto IL_0790;
																											case 134:
																											case 142:
																												goto IL_079e;
																											case 37:
																												goto IL_07b7;
																											case 39:
																												goto IL_07c5;
																											case 146:
																												goto IL_07d3;
																											case 102:
																												goto IL_07ef;
																											case 98:
																												goto IL_0806;
																											case 70:
																											case 104:
																												goto IL_0811;
																											case 136:
																												goto IL_083a;
																											case 26:
																											case 69:
																												goto IL_0850;
																											case 25:
																												goto IL_086e;
																											case 92:
																												goto IL_087c;
																											case 4:
																											case 6:
																											case 7:
																											case 12:
																											case 18:
																											case 20:
																											case 23:
																											case 28:
																											case 30:
																											case 32:
																											case 34:
																											case 49:
																											case 58:
																											case 59:
																											case 60:
																											case 74:
																											case 76:
																											case 89:
																											case 91:
																											case 95:
																											case 96:
																											case 100:
																											case 101:
																											case 122:
																											case 126:
																											case 140:
																											case 143:
																											case 150:
																												goto end_IL_02d1;
																											case 43:
																											case 45:
																											case 47:
																											case 48:
																											case 51:
																											case 62:
																											case 71:
																											case 77:
																											case 84:
																											case 86:
																											case 103:
																											case 107:
																											case 111:
																											case 114:
																											case 127:
																											case 129:
																											case 131:
																											case 137:
																												goto end_IL_0291;
																											case 68:
																												goto end_IL_089f;
																											case 125:
																												goto end_IL_08b2;
																											case 128:
																												goto end_IL_08bc;
																											case 99:
																												goto end_IL_08c7;
																											case 19:
																												goto end_IL_08d7;
																											case 110:
																												goto end_IL_08e7;
																											case 42:
																												goto end_IL_08f7;
																											case 9:
																											case 63:
																												goto end_IL_0902;
																											case 116:
																												goto end_IL_0912;
																											case 117:
																												goto end_IL_0922;
																											case 54:
																											case 123:
																												goto IL_0946;
																											}
																											continue;
																										}
																										if (4 > b)
																										{
																											goto IL_0702;
																										}
																										goto IL_0850;
																										IL_083a:
																										array[num5 - 1] = 5;
																										break;
																										IL_086e:
																										ptr2 += 8;
																										goto IL_087c;
																										IL_0850:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										goto IL_086e;
																										IL_0702:
																										if (2 >= b)
																										{
																											goto IL_0710;
																										}
																										goto IL_07ef;
																										IL_0710:
																										if (2 <= b)
																										{
																											goto IL_071b;
																										}
																										goto IL_0782;
																										IL_071b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_075b;
																										IL_075b:
																										array[num5 - 2] = 0;
																										goto IL_076f;
																										IL_076f:
																										num5--;
																										break;
																										IL_0782:
																										if (1 < b)
																										{
																											goto end_IL_02d1;
																										}
																										goto IL_0790;
																										IL_0790:
																										if (1 > b)
																										{
																											goto end_IL_02d1;
																										}
																										goto IL_079e;
																										IL_079e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_07b7;
																										IL_07b7:
																										array[num5] = 0;
																										goto IL_07c5;
																										IL_07c5:
																										num5++;
																										goto IL_07d3;
																										IL_07d3:
																										ptr2 += 8;
																										num = 107;
																										break;
																										IL_07ef:
																										if (3 < b)
																										{
																											goto end_IL_02d1;
																										}
																										num = 98;
																										goto IL_0806;
																										IL_087c:
																										num5--;
																										break;
																										IL_0806:
																										if (3 > b)
																										{
																											goto end_IL_02d1;
																										}
																										goto IL_0811;
																										IL_0811:
																										array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_083a;
																										continue;
																										end_IL_0291:
																										break;
																									}
																									break;
																								}
																								goto IL_0324;
																								IL_03c6:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03ef;
																								IL_03ef:
																								ptr2 += 8;
																								goto IL_0454;
																								IL_0324:
																								if (6 >= b)
																								{
																									goto IL_032f;
																								}
																								goto IL_039f;
																								IL_032f:
																								if (6 > b)
																								{
																									goto IL_033a;
																								}
																								goto IL_034d;
																								IL_033a:
																								if (5 < b)
																								{
																									goto end_IL_02d1;
																								}
																								goto IL_03ff;
																								IL_03ff:
																								if (5 > b)
																								{
																									goto end_IL_02d1;
																								}
																								goto IL_040d;
																								IL_040d:
																								array[num5] = 5;
																								goto IL_041b;
																								IL_041b:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_0433;
																								IL_0433:
																								num5++;
																								goto IL_0441;
																								IL_0441:
																								ptr2 += 8;
																								break;
																								IL_034d:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_038c;
																								IL_038c:
																								num5 -= 3;
																								break;
																								IL_039f:
																								if (7 < b)
																								{
																									goto end_IL_02d1;
																								}
																								goto IL_03ad;
																								IL_03ad:
																								if (7 > b)
																								{
																									num = 12;
																									goto end_IL_02d1;
																								}
																								goto IL_03c6;
																								IL_0454:
																								num5--;
																								break;
																							}
																							break;
																						}
																						goto IL_030c;
																						IL_030c:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																					}
																					break;
																				}
																				goto IL_0467;
																				IL_0647:
																				num5--;
																				break;
																				IL_0467:
																				if (12 < b)
																				{
																					goto IL_0472;
																				}
																				goto IL_04c8;
																				IL_0472:
																				if (14 >= b)
																				{
																					goto IL_047d;
																				}
																				goto IL_04a7;
																				IL_047d:
																				if (14 <= b)
																				{
																					goto IL_048b;
																				}
																				goto IL_065a;
																				IL_048b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_065a:
																				if (13 < b)
																				{
																					goto end_IL_02d1;
																				}
																				goto IL_0668;
																				IL_0668:
																				if (13 > b)
																				{
																					goto end_IL_02d1;
																				}
																				goto IL_0676;
																				IL_0676:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 10;
																				goto IL_06e1;
																				IL_06e1:
																				num5 -= 2;
																				break;
																				IL_04a7:
																				if (15 < b)
																				{
																					goto end_IL_02d1;
																				}
																				goto IL_04b5;
																				IL_04b5:
																				if (15 <= b)
																				{
																				}
																				goto end_IL_02d1;
																				IL_04c8:
																				if (12 > b)
																				{
																					goto IL_04d6;
																				}
																				goto IL_05f3;
																				IL_04d6:
																				if (10 < b)
																				{
																					goto IL_04e4;
																				}
																				goto IL_056b;
																				IL_04e4:
																				if (11 < b)
																				{
																					goto end_IL_02d1;
																				}
																				goto IL_04f2;
																				IL_04f2:
																				if (11 > b)
																				{
																					goto end_IL_02d1;
																				}
																				goto IL_0500;
																				IL_0500:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0544;
																				IL_0544:
																				array[num5 - 2] = 0;
																				goto IL_0558;
																				IL_0558:
																				num5--;
																				break;
																				IL_056b:
																				if (10 > b)
																				{
																					goto IL_0576;
																				}
																				goto IL_0597;
																				IL_0576:
																				if (9 < b)
																				{
																					goto end_IL_02d1;
																				}
																				goto IL_0584;
																				IL_0584:
																				if (9 > b)
																				{
																					goto end_IL_02d1;
																				}
																				break;
																				IL_0597:
																				array[num5] = 0;
																				goto IL_05a5;
																				IL_05a5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05c8;
																				IL_05c8:
																				array2[num5] = null;
																				goto IL_05d2;
																				IL_05d2:
																				num5++;
																				goto IL_05e0;
																				IL_05e0:
																				ptr2 += 8;
																				break;
																				IL_05f3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0633;
																				IL_0633:
																				array[num5 - 2] = 0;
																				goto IL_0647;
																			}
																			goto end_IL_02e1;
																			continue;
																			end_IL_02d1:
																			break;
																			IL_02d1:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02e1:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0946;
													IL_0946:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_089f:
													break;
												}
												continue;
												end_IL_08b2:
												break;
											}
											continue;
											end_IL_08bc:
											break;
										}
										continue;
										end_IL_08c7:
										break;
									}
									continue;
									end_IL_08d7:
									break;
								}
								continue;
								end_IL_08e7:
								break;
							}
							continue;
							end_IL_08f7:
							break;
						}
						continue;
						end_IL_0902:
						break;
					}
					continue;
					end_IL_0912:
					break;
				}
				continue;
				end_IL_0922:
				break;
			}
		}
	}

	public Class192()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static Vector3 smethod_1(Transform transform_0)
	{
		return transform_0.position;
	}

	private static Renderer SystemAclPresentSetAddOnMethod(GameObject gameObject_1)
	{
		return gameObject_1.GetComponent<Renderer>();
	}

	private static int SetGenericParameterAttributesHMACRIPEMD(int int_1)
	{
		return smethod_3(int_1);
	}

	private static bool ShadowCopyDirectoriesValueAddScalar(GTPlayer gtplayer_0, bool bool_1)
	{
		return gtplayer_0.IsHandTouching(bool_1);
	}

	private unsafe void method_0()
	{
		int num = 133;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											num = 35;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LdsfldaTypeRequiresRegistration.getRealErrorObjectConsoleApplication);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_0415:
															byte b = *ptr2;
															num = 113;
															while (true)
															{
																IL_0405:
																ptr2++;
																while (true)
																{
																	IL_03f5:
																	if (b >= 1)
																	{
																		while (b <= 22)
																		{
																			while (true)
																			{
																				IL_03d8:
																				if (11 < b)
																				{
																					while (true)
																					{
																						IL_03cb:
																						if (17 < b)
																						{
																							while (true)
																							{
																								IL_03bb:
																								if (20 >= b)
																								{
																									while (true)
																									{
																										IL_03ab:
																										if (20 <= b)
																										{
																											while (true)
																											{
																												IL_038c:
																												array[num6 - 1] = 0;
																												num = 10;
																												while (true)
																												{
																													IL_034b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)HeaderNameRC[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																													while (true)
																													{
																														IL_0332:
																														ptr2 += 8;
																														num = 196;
																														while (num != 196)
																														{
																															if (num != 1177)
																															{
																																goto IL_0551;
																															}
																															switch (num)
																															{
																															case 154:
																																goto IL_0332;
																															case 10:
																																goto IL_034b;
																															case 50:
																															case 150:
																																goto IL_038c;
																															case 63:
																																goto IL_03ab;
																															case 158:
																																goto IL_03bb;
																															case 116:
																																goto IL_03cb;
																															case 110:
																																goto IL_03d8;
																															case 74:
																																goto IL_03e5;
																															case 61:
																																goto IL_03f5;
																															case 113:
																																goto IL_0405;
																															case 20:
																															case 163:
																																goto IL_0415;
																															case 6:
																																goto IL_0429;
																															case 62:
																																goto IL_0439;
																															case 68:
																																goto IL_0449;
																															case 36:
																																goto IL_0454;
																															case 73:
																																goto IL_0461;
																															case 81:
																																goto IL_0471;
																															case 86:
																																goto IL_047e;
																															case 89:
																																goto IL_048b;
																															case 101:
																																goto IL_049e;
																															case 105:
																																goto IL_04b1;
																															case 37:
																															case 106:
																																goto IL_04c4;
																															case 112:
																																goto IL_04e0;
																															case 143:
																																goto IL_04f0;
																															case 87:
																																goto IL_04fe;
																															case 139:
																																goto IL_050c;
																															case 148:
																																goto IL_051f;
																															case 142:
																																goto IL_052a;
																															case 5:
																															case 39:
																																goto IL_0538;
																															case 80:
																																goto IL_0551;
																															case 129:
																																goto IL_0564;
																															case 7:
																																goto IL_0572;
																															case 84:
																															case 140:
																																goto IL_0580;
																															case 155:
																																goto IL_0598;
																															case 99:
																																goto IL_05a3;
																															case 96:
																																goto IL_05b6;
																															case 64:
																																goto IL_05c1;
																															case 100:
																																goto IL_05d1;
																															case 90:
																																goto IL_05df;
																															case 166:
																																goto IL_05ef;
																															case 70:
																																goto IL_0606;
																															case 47:
																															case 169:
																																goto IL_0619;
																															case 153:
																																goto IL_0642;
																															case 16:
																																goto IL_0650;
																															case 109:
																															case 171:
																																goto IL_0663;
																															case 55:
																																goto IL_0671;
																															case 134:
																																goto IL_0694;
																															case 21:
																																goto IL_069e;
																															case 24:
																																goto IL_06ac;
																															case 172:
																																goto IL_06c8;
																															case 118:
																																goto IL_06d6;
																															case 57:
																															case 71:
																																goto IL_06ed;
																															case 170:
																																goto IL_070f;
																															case 83:
																																goto IL_071d;
																															case 11:
																																goto IL_072b;
																															case 126:
																															case 173:
																																goto IL_073e;
																															case 67:
																															case 176:
																																goto IL_076c;
																															case 78:
																																goto IL_07ac;
																															case 29:
																																goto IL_07c0;
																															case 177:
																																goto IL_07d3;
																															case 117:
																															case 125:
																																goto IL_07e1;
																															case 160:
																																goto IL_0843;
																															case 27:
																															case 178:
																																goto IL_0856;
																															case 3:
																																goto IL_0896;
																															case 128:
																																goto IL_08aa;
																															case 180:
																																goto IL_08bd;
																															case 28:
																																goto IL_08cb;
																															case 123:
																																goto IL_08d9;
																															case 2:
																															case 144:
																																goto IL_08e7;
																															case 120:
																																goto IL_08ff;
																															case 66:
																																goto IL_090d;
																															case 91:
																																goto IL_091b;
																															case 12:
																															case 181:
																																goto IL_092e;
																															case 174:
																																goto IL_096f;
																															case 23:
																																goto IL_0983;
																															case 26:
																															case 182:
																																goto IL_0996;
																															case 175:
																																goto IL_09d6;
																															case 114:
																																goto IL_09ea;
																															case 183:
																																goto IL_09fd;
																															case 34:
																															case 97:
																																goto IL_0a0b;
																															case 14:
																																goto IL_0a5d;
																															case 185:
																																goto IL_0a70;
																															case 31:
																															case 149:
																																goto IL_0a7e;
																															case 17:
																																goto IL_0abe;
																															case 49:
																																goto IL_0ad2;
																															case 186:
																																goto IL_0ae5;
																															case 69:
																																goto IL_0afc;
																															case 32:
																															case 189:
																																goto IL_0b0f;
																															case 161:
																																goto IL_0b4f;
																															case 95:
																																goto IL_0b63;
																															case 76:
																																goto IL_0b76;
																															case 65:
																																goto IL_0b81;
																															case 72:
																															case 151:
																																goto IL_0b8f;
																															case 75:
																																goto IL_0ba8;
																															case 33:
																																goto IL_0bbf;
																															case 22:
																																goto IL_0bcd;
																															case 179:
																																goto IL_0be0;
																															case 107:
																																goto IL_0bee;
																															case 44:
																															case 79:
																																goto IL_0bfc;
																															case 82:
																																goto IL_0c3c;
																															case 48:
																																goto IL_0c50;
																															case 25:
																																goto IL_0c69;
																															case 45:
																																goto IL_0c74;
																															case 46:
																															case 60:
																																goto IL_0c7f;
																															case 167:
																																goto IL_0c98;
																															case 42:
																																goto IL_0ca3;
																															case 4:
																															case 8:
																															case 9:
																															case 13:
																															case 18:
																															case 30:
																															case 40:
																															case 41:
																															case 52:
																															case 54:
																															case 58:
																															case 77:
																															case 88:
																															case 92:
																															case 102:
																															case 103:
																															case 108:
																															case 111:
																															case 115:
																															case 122:
																															case 124:
																															case 131:
																															case 157:
																															case 168:
																															case 187:
																																goto end_IL_03e5;
																															case 0:
																															case 1:
																															case 38:
																															case 43:
																															case 51:
																															case 53:
																															case 56:
																															case 59:
																															case 93:
																															case 94:
																															case 98:
																															case 119:
																															case 127:
																															case 130:
																															case 135:
																															case 136:
																															case 137:
																															case 138:
																															case 141:
																															case 147:
																															case 152:
																															case 162:
																															case 184:
																															case 188:
																																goto end_IL_031f;
																															case 121:
																																goto end_IL_0cc1;
																															case 35:
																																goto end_IL_0cd4;
																															case 19:
																																goto end_IL_0cde;
																															case 159:
																																goto end_IL_0ce9;
																															case 104:
																																goto end_IL_0d02;
																															case 15:
																															case 156:
																																goto end_IL_0d12;
																															case 146:
																																goto end_IL_0d22;
																															case 164:
																																goto end_IL_0d32;
																															case 165:
																																goto end_IL_0d42;
																															case 132:
																																goto end_IL_0d52;
																															case 133:
																																goto end_IL_0d62;
																															case 85:
																															case 145:
																																return;
																															}
																															continue;
																															end_IL_031f:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_0b76;
																										IL_0c50:
																										num6--;
																										num = 56;
																										break;
																										IL_0b76:
																										if (18 >= b)
																										{
																											goto IL_0b81;
																										}
																										goto IL_0be0;
																										IL_0b81:
																										if (18 > b)
																										{
																											goto end_IL_03e5;
																										}
																										goto IL_0b8f;
																										IL_0b8f:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_0ba8;
																										IL_0ba8:
																										array[num6] = 3;
																										num = 33;
																										goto IL_0bbf;
																										IL_0bbf:
																										num6++;
																										goto IL_0bcd;
																										IL_0bcd:
																										ptr2 += 16;
																										break;
																										IL_0be0:
																										if (19 < b)
																										{
																											goto end_IL_03e5;
																										}
																										goto IL_0bee;
																										IL_0bee:
																										if (19 > b)
																										{
																											goto end_IL_03e5;
																										}
																										goto IL_0bfc;
																										IL_0bfc:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0c3c;
																										IL_0c3c:
																										array[num6 - 2] = 3;
																										goto IL_0c50;
																									}
																									break;
																								}
																								goto IL_0c69;
																								IL_0ca3:
																								if (22 <= b)
																								{
																								}
																								goto end_IL_03e5;
																								IL_0c69:
																								if (21 >= b)
																								{
																									goto IL_0c74;
																								}
																								goto IL_0c98;
																								IL_0c74:
																								if (21 > b)
																								{
																									goto end_IL_03e5;
																								}
																								goto IL_0c7f;
																								IL_0c7f:
																								byte* num7 = ptr2;
																								num5 = 1;
																								ptr2 = num7 + -200;
																								break;
																								IL_0c98:
																								if (22 < b)
																								{
																									goto end_IL_03e5;
																								}
																								goto IL_0ca3;
																							}
																							break;
																						}
																						goto IL_0439;
																						IL_0a5d:
																						num6--;
																						break;
																						IL_0439:
																						if (17 > b)
																						{
																							goto IL_0461;
																						}
																						goto IL_073e;
																						IL_073e:
																						((delegate*<Class192, void>)HeaderNameRC[*(int*)(ptr2 + num3)])((Class192)array2[num6 - 1]);
																						goto IL_0ae5;
																						IL_0ae5:
																						num6--;
																						num = 69;
																						goto IL_0afc;
																						IL_0afc:
																						ptr2 += 8;
																						break;
																						IL_0461:
																						if (14 >= b)
																						{
																							goto IL_04e0;
																						}
																						goto IL_08bd;
																						IL_04e0:
																						if (14 > b)
																						{
																							goto IL_051f;
																						}
																						goto IL_092e;
																						IL_092e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_096f;
																						IL_096f:
																						array[num6 - 2] = 0;
																						goto IL_0983;
																						IL_0983:
																						num6--;
																						break;
																						IL_051f:
																						if (12 >= b)
																						{
																							goto IL_052a;
																						}
																						goto IL_0564;
																						IL_052a:
																						if (12 > b)
																						{
																							goto end_IL_03e5;
																						}
																						goto IL_0538;
																						IL_0538:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0551;
																						IL_0551:
																						array[num6] = 1;
																						goto IL_05ef;
																						IL_05ef:
																						num6++;
																						num = 70;
																						goto IL_0606;
																						IL_0606:
																						ptr2 += 16;
																						break;
																						IL_0564:
																						if (13 < b)
																						{
																							goto end_IL_03e5;
																						}
																						goto IL_0572;
																						IL_0572:
																						if (13 > b)
																						{
																							goto end_IL_03e5;
																						}
																						goto IL_0580;
																						IL_0580:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_08bd:
																						if (15 < b)
																						{
																							goto IL_08cb;
																						}
																						goto IL_09fd;
																						IL_08cb:
																						if (16 < b)
																						{
																							goto end_IL_03e5;
																						}
																						goto IL_08d9;
																						IL_08d9:
																						if (16 > b)
																						{
																							goto end_IL_03e5;
																						}
																						goto IL_08e7;
																						IL_08e7:
																						array2[num6] = array5[*(int*)(ptr2 + num3)];
																						goto IL_08ff;
																						IL_08ff:
																						array[num6] = 5;
																						goto IL_090d;
																						IL_090d:
																						num6++;
																						goto IL_091b;
																						IL_091b:
																						ptr2 += 8;
																						break;
																						IL_09fd:
																						if (15 > b)
																						{
																							goto end_IL_03e5;
																						}
																						goto IL_0a0b;
																						IL_0a0b:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0a5d;
																					}
																					break;
																				}
																				goto IL_0429;
																				IL_069e:
																				num6++;
																				goto IL_06ac;
																				IL_0429:
																				if (11 <= b)
																				{
																					break;
																				}
																				goto IL_0449;
																				IL_0449:
																				if (5 < b)
																				{
																					goto IL_0454;
																				}
																				goto IL_048b;
																				IL_0454:
																				if (8 < b)
																				{
																					goto IL_0471;
																				}
																				goto IL_047e;
																				IL_047e:
																				if (8 <= b)
																				{
																					goto IL_04c4;
																				}
																				goto IL_04f0;
																				IL_04c4:
																				num6--;
																				num = 184;
																				break;
																				IL_04f0:
																				if (6 < b)
																				{
																					goto IL_04fe;
																				}
																				goto IL_0a70;
																				IL_04fe:
																				if (7 < b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_050c;
																				IL_050c:
																				if (7 > b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_0996;
																				IL_0996:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_09d6;
																				IL_09d6:
																				array[num6 - 2] = 0;
																				goto IL_09ea;
																				IL_09ea:
																				num6--;
																				break;
																				IL_0a70:
																				if (6 > b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_0a7e;
																				IL_0a7e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0abe;
																				IL_0abe:
																				array[num6 - 2] = 0;
																				goto IL_0ad2;
																				IL_0ad2:
																				num6--;
																				break;
																				IL_0471:
																				if (9 >= b)
																				{
																					goto IL_049e;
																				}
																				goto IL_04b1;
																				IL_049e:
																				if (9 > b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_076c;
																				IL_076c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_07ac;
																				IL_07ac:
																				array[num6 - 2] = 0;
																				goto IL_07c0;
																				IL_07c0:
																				num6--;
																				break;
																				IL_04b1:
																				if (10 < b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_07d3;
																				IL_07d3:
																				if (10 > b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_07e1;
																				IL_07e1:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0843;
																				IL_0843:
																				num6 -= 2;
																				break;
																				IL_048b:
																				if (5 > b)
																				{
																					goto IL_0598;
																				}
																				goto IL_0b0f;
																				IL_0b0f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0b4f;
																				IL_0b4f:
																				array[num6 - 2] = 0;
																				goto IL_0b63;
																				IL_0b63:
																				num6--;
																				break;
																				IL_0598:
																				if (2 >= b)
																				{
																					goto IL_05a3;
																				}
																				goto IL_05b6;
																				IL_05a3:
																				if (2 > b)
																				{
																					goto IL_06c8;
																				}
																				goto IL_0856;
																				IL_0856:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0896;
																				IL_0896:
																				array[num6 - 2] = 0;
																				goto IL_08aa;
																				IL_08aa:
																				num6--;
																				break;
																				IL_06c8:
																				if (1 < b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_06d6;
																				IL_06d6:
																				if (1 > b)
																				{
																					goto end_IL_03e5;
																				}
																				num = 57;
																				goto IL_06ed;
																				IL_06ac:
																				ptr2 += 8;
																				num = 130;
																				break;
																				IL_06ed:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				num = 170;
																				goto IL_070f;
																				IL_070f:
																				array[num6] = 0;
																				goto IL_071d;
																				IL_071d:
																				num6++;
																				goto IL_072b;
																				IL_072b:
																				ptr2 += 8;
																				break;
																				IL_05b6:
																				if (3 >= b)
																				{
																					goto IL_05c1;
																				}
																				goto IL_05d1;
																				IL_05c1:
																				if (3 > b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_0619;
																				IL_0619:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0642;
																				IL_0642:
																				ptr2 += 8;
																				goto IL_0650;
																				IL_0650:
																				num6--;
																				break;
																				IL_05d1:
																				if (4 < b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_05df;
																				IL_05df:
																				if (4 > b)
																				{
																					goto end_IL_03e5;
																				}
																				goto IL_0663;
																				IL_0663:
																				array[num6] = 0;
																				goto IL_0671;
																				IL_0671:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0694;
																				IL_0694:
																				array2[num6] = null;
																				goto IL_069e;
																			}
																			goto end_IL_03f5;
																			continue;
																			end_IL_03e5:
																			break;
																			IL_03e5:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_03f5:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0cc1:
														break;
													}
													continue;
													end_IL_0cd4:
													break;
												}
												continue;
												end_IL_0cde:
												break;
											}
											continue;
											end_IL_0ce9:
											break;
										}
										continue;
										end_IL_0d02:
										break;
									}
									continue;
									end_IL_0d12:
									break;
								}
								continue;
								end_IL_0d22:
								break;
							}
							continue;
							end_IL_0d32:
							break;
						}
						continue;
						end_IL_0d42:
						break;
					}
					continue;
					end_IL_0d52:
					break;
				}
				continue;
				end_IL_0d62:
				break;
			}
		}
	}

	private static Material BeginEndAwaitableAdapterReadonly(Renderer renderer_0)
	{
		return renderer_0.material;
	}

	private static double HeadersFirstFullWeek(double double_1)
	{
		return Math.Round(double_1);
	}

	private static double CommonPicturesgetInformationalVersion(double double_1)
	{
		return Math.Sin(double_1);
	}

	private static object MetadataSectionResourceTypeManifestResourcesDependencySkipSize(float float_2, float float_3, float float_4)
	{
		return new Color(float_2, float_3, float_4);
	}

	private static double MetadataExceptionGetInstance(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private unsafe void method_1()
	{
		int num = 27;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								num = 271;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											num = 50;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PermissionSetTripleIAssemblyName.ArrayTypeMismatchExceptionNewobj);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 165;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_061c:
																		if (b >= 1)
																		{
																			while (b <= 37)
																			{
																				num = 149;
																				while (true)
																				{
																					IL_05f9:
																					if (19 >= b)
																					{
																						while (true)
																						{
																							IL_05e9:
																							if (19 > b)
																							{
																								while (true)
																								{
																									IL_05d9:
																									if (9 >= b)
																									{
																										while (true)
																										{
																											IL_05c9:
																											if (9 > b)
																											{
																												while (true)
																												{
																													IL_05bc:
																													if (4 >= b)
																													{
																														while (true)
																														{
																															IL_05ac:
																															if (4 > b)
																															{
																																while (true)
																																{
																																	IL_059c:
																																	if (2 >= b)
																																	{
																																		while (true)
																																		{
																																			IL_058c:
																																			if (2 > b)
																																			{
																																				while (1 >= b)
																																				{
																																					while (1 <= b)
																																					{
																																						while (true)
																																						{
																																							IL_0551:
																																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																																							while (true)
																																							{
																																								IL_0541:
																																								array[num6] = 0;
																																								while (true)
																																								{
																																									IL_0528:
																																									num6++;
																																									num = 318;
																																									while (true)
																																									{
																																										if (num != 318)
																																										{
																																											if (num != 1299)
																																											{
																																												break;
																																											}
																																											switch (num)
																																											{
																																											case 235:
																																												goto IL_0528;
																																											case 300:
																																												goto IL_0541;
																																											case 83:
																																											case 241:
																																												goto IL_0551;
																																											case 260:
																																												goto IL_056c;
																																											case 283:
																																												goto IL_057c;
																																											case 39:
																																												goto IL_058c;
																																											case 116:
																																												goto IL_059c;
																																											case 119:
																																												goto IL_05ac;
																																											case 21:
																																												goto IL_05bc;
																																											case 23:
																																												goto IL_05c9;
																																											case 42:
																																												goto IL_05d9;
																																											case 218:
																																												goto IL_05e9;
																																											case 149:
																																												goto IL_05f9;
																																											case 18:
																																												goto IL_0609;
																																											case 210:
																																												goto IL_061c;
																																											case 134:
																																												goto end_IL_061c;
																																											case 280:
																																											case 295:
																																												goto end_IL_062c;
																																											case 31:
																																												goto IL_0647;
																																											case 77:
																																												goto IL_0655;
																																											case 94:
																																											case 145:
																																												goto IL_0668;
																																											case 12:
																																											case 164:
																																												goto IL_0678;
																																											case 37:
																																												goto IL_06b8;
																																											case 223:
																																												goto IL_06d1;
																																											case 52:
																																												goto IL_06f4;
																																											case 180:
																																												goto IL_06fe;
																																											case 220:
																																												goto end_IL_0515;
																																											case 269:
																																												goto IL_071f;
																																											case 212:
																																												goto IL_072a;
																																											case 70:
																																												goto IL_0738;
																																											case 63:
																																											case 249:
																																												goto IL_0746;
																																											case 176:
																																												goto IL_0762;
																																											case 272:
																																												goto IL_0775;
																																											case 299:
																																												goto IL_0788;
																																											case 214:
																																												goto IL_0796;
																																											case 259:
																																											case 270:
																																												goto IL_07a4;
																																											case 98:
																																												goto IL_07e4;
																																											case 157:
																																												goto IL_07f8;
																																											case 281:
																																											case 302:
																																												goto IL_080b;
																																											case 203:
																																												goto IL_084b;
																																											case 257:
																																												goto IL_085f;
																																											case 284:
																																											case 305:
																																												goto IL_087b;
																																											case 221:
																																												goto IL_08bb;
																																											case 268:
																																												goto IL_08cf;
																																											case 122:
																																												goto IL_08f5;
																																											case 130:
																																												goto IL_0903;
																																											case 71:
																																											case 228:
																																												goto IL_0911;
																																											case 136:
																																												goto IL_093a;
																																											case 127:
																																												goto IL_0948;
																																											case 79:
																																											case 113:
																																												goto IL_095b;
																																											case 146:
																																												goto IL_099b;
																																											case 233:
																																												goto IL_09b8;
																																											case 194:
																																												goto IL_09cb;
																																											case 293:
																																												goto IL_09d9;
																																											case 225:
																																											case 256:
																																												goto IL_09e4;
																																											case 253:
																																												goto IL_0a25;
																																											case 211:
																																												goto IL_0a39;
																																											case 306:
																																												goto IL_0a4c;
																																											case 137:
																																												goto IL_0a5a;
																																											case 111:
																																												goto IL_0a65;
																																											case 132:
																																											case 265:
																																												goto IL_0a73;
																																											case 261:
																																												goto IL_0a8c;
																																											case 296:
																																												goto IL_0aa3;
																																											case 48:
																																												goto IL_0ab1;
																																											case 143:
																																												goto IL_0ac4;
																																											case 178:
																																												goto IL_0adb;
																																											case 85:
																																											case 301:
																																												goto IL_0ae9;
																																											case 73:
																																												goto IL_0b0a;
																																											case 267:
																																												goto IL_0b18;
																																											case 286:
																																												goto IL_0b26;
																																											case 72:
																																											case 251:
																																												goto IL_0b3d;
																																											case 282:
																																												goto IL_0b9f;
																																											case 247:
																																												goto IL_0bb2;
																																											case 246:
																																												goto IL_0bc0;
																																											case 64:
																																											case 310:
																																												goto IL_0bcb;
																																											case 193:
																																												goto IL_0be3;
																																											case 29:
																																												goto IL_0bf1;
																																											case 188:
																																												goto IL_0bff;
																																											case 224:
																																												goto IL_0c12;
																																											case 196:
																																												goto IL_0c20;
																																											case 158:
																																											case 287:
																																												goto IL_0c37;
																																											case 19:
																																												goto IL_0c92;
																																											case 290:
																																												goto IL_0ca5;
																																											case 16:
																																												goto IL_0cb0;
																																											case 231:
																																											case 289:
																																												goto IL_0cbe;
																																											case 32:
																																												goto IL_0cf6;
																																											case 252:
																																												goto IL_0d0a;
																																											case 204:
																																												goto IL_0d1d;
																																											case 266:
																																												goto IL_0d2b;
																																											case 55:
																																											case 199:
																																												goto IL_0d39;
																																											case 10:
																																												goto IL_0d62;
																																											case 142:
																																												goto IL_0d70;
																																											case 25:
																																											case 222:
																																												goto IL_0d83;
																																											case 105:
																																												goto IL_0d9c;
																																											case 97:
																																												goto IL_0daa;
																																											case 166:
																																												goto IL_0dc1;
																																											case 155:
																																												goto IL_0dd4;
																																											case 95:
																																												goto IL_0de2;
																																											case 74:
																																												goto IL_0df0;
																																											case 17:
																																												goto IL_0dfe;
																																											case 135:
																																												goto IL_0e0c;
																																											case 75:
																																												goto IL_0e1a;
																																											case 53:
																																												goto IL_0e28;
																																											case 120:
																																												goto IL_0e36;
																																											case 34:
																																											case 226:
																																												goto IL_0e44;
																																											case 5:
																																												goto IL_0e58;
																																											case 67:
																																												goto IL_0e97;
																																											case 88:
																																											case 255:
																																												goto IL_0eaa;
																																											case 11:
																																												goto IL_0eea;
																																											case 311:
																																												goto IL_0efe;
																																											case 54:
																																												goto IL_0f1a;
																																											case 102:
																																												goto IL_0f28;
																																											case 232:
																																											case 245:
																																												goto IL_0f36;
																																											case 82:
																																												goto IL_0f4a;
																																											case 230:
																																												goto IL_0f89;
																																											case 22:
																																											case 202:
																																												goto IL_0fa5;
																																											case 248:
																																												goto IL_0faf;
																																											case 9:
																																												goto IL_0fbd;
																																											case 106:
																																												goto IL_0fd0;
																																											case 28:
																																												goto IL_0fde;
																																											case 66:
																																											case 169:
																																												goto IL_0fe9;
																																											case 49:
																																												goto IL_0ffd;
																																											case 309:
																																												goto IL_103c;
																																											case 103:
																																												goto IL_104f;
																																											case 191:
																																												goto IL_105d;
																																											case 163:
																																											case 168:
																																												goto IL_106b;
																																											case 110:
																																												goto IL_1088;
																																											case 298:
																																												goto IL_10d5;
																																											case 68:
																																												goto IL_10e3;
																																											case 152:
																																												goto IL_10f6;
																																											case 86:
																																												goto IL_1101;
																																											case 14:
																																											case 153:
																																												goto IL_110f;
																																											case 201:
																																												goto IL_114f;
																																											case 140:
																																												goto IL_116c;
																																											case 184:
																																												goto IL_117f;
																																											case 45:
																																												goto IL_118d;
																																											case 90:
																																											case 99:
																																												goto IL_119b;
																																											case 141:
																																												goto IL_11a9;
																																											case 192:
																																												goto IL_11c7;
																																											case 128:
																																												goto IL_11d5;
																																											case 101:
																																											case 215:
																																												goto IL_11e8;
																																											case 33:
																																												goto IL_11fc;
																																											case 258:
																																												goto IL_1249;
																																											case 139:
																																												goto IL_1257;
																																											case 207:
																																												goto IL_126a;
																																											case 65:
																																												goto IL_1278;
																																											case 76:
																																											case 209:
																																												goto IL_1283;
																																											case 1:
																																												goto IL_1297;
																																											case 264:
																																												goto IL_12d6;
																																											case 154:
																																												goto IL_12e9;
																																											case 107:
																																												goto IL_12f7;
																																											case 109:
																																											case 175:
																																												goto IL_1302;
																																											case 3:
																																												goto IL_1338;
																																											case 219:
																																												goto IL_1354;
																																											case 187:
																																												goto IL_1362;
																																											case 172:
																																											case 217:
																																												goto IL_1370;
																																											case 35:
																																												goto IL_137e;
																																											case 115:
																																												goto IL_13a1;
																																											case 181:
																																												goto IL_13af;
																																											case 44:
																																												goto IL_13c2;
																																											case 170:
																																												goto IL_13cd;
																																											case 91:
																																											case 190:
																																												goto IL_13db;
																																											case 198:
																																												goto IL_13ef;
																																											case 243:
																																												goto IL_142e;
																																											case 93:
																																												goto IL_1441;
																																											case 56:
																																												goto IL_144f;
																																											case 186:
																																											case 276:
																																												goto IL_145d;
																																											case 62:
																																												goto IL_1485;
																																											case 125:
																																												goto IL_14a1;
																																											case 61:
																																												goto IL_14af;
																																											case 47:
																																											case 114:
																																												goto IL_14ba;
																																											case 8:
																																												goto IL_14f8;
																																											case 133:
																																												goto IL_1506;
																																											case 46:
																																												goto IL_1519;
																																											case 92:
																																												goto IL_1527;
																																											case 41:
																																											case 182:
																																												goto IL_153e;
																																											case 307:
																																												goto IL_155b;
																																											case 69:
																																												goto IL_1593;
																																											case 43:
																																												goto IL_15a3;
																																											case 126:
																																												goto IL_15ae;
																																											case 206:
																																											case 292:
																																												goto IL_15b9;
																																											case 297:
																																												goto IL_15d2;
																																											case 123:
																																												goto IL_15e6;
																																											case 0:
																																											case 4:
																																											case 6:
																																											case 7:
																																											case 20:
																																											case 40:
																																											case 58:
																																											case 81:
																																											case 87:
																																											case 96:
																																											case 104:
																																											case 108:
																																											case 112:
																																											case 117:
																																											case 124:
																																											case 129:
																																											case 159:
																																											case 160:
																																											case 171:
																																											case 177:
																																											case 179:
																																											case 189:
																																											case 195:
																																											case 200:
																																											case 205:
																																											case 208:
																																											case 227:
																																											case 234:
																																											case 237:
																																											case 238:
																																											case 244:
																																											case 250:
																																											case 262:
																																											case 263:
																																											case 274:
																																											case 279:
																																											case 285:
																																											case 288:
																																											case 303:
																																											case 308:
																																												goto end_IL_056c;
																																											case 2:
																																											case 13:
																																											case 15:
																																											case 24:
																																											case 36:
																																											case 38:
																																											case 60:
																																											case 78:
																																											case 80:
																																											case 84:
																																											case 89:
																																											case 100:
																																											case 118:
																																											case 138:
																																											case 144:
																																											case 147:
																																											case 148:
																																											case 150:
																																											case 156:
																																											case 161:
																																											case 162:
																																											case 165:
																																											case 167:
																																											case 183:
																																											case 185:
																																											case 213:
																																											case 216:
																																											case 229:
																																											case 236:
																																											case 239:
																																											case 240:
																																											case 242:
																																											case 254:
																																											case 275:
																																											case 277:
																																											case 278:
																																											case 291:
																																											case 294:
																																											case 304:
																																												goto end_IL_063c;
																																											case 51:
																																												goto end_IL_160d;
																																											case 174:
																																												goto end_IL_1620;
																																											case 50:
																																												goto end_IL_162b;
																																											case 151:
																																												goto end_IL_1635;
																																											case 131:
																																												goto end_IL_1640;
																																											case 271:
																																												goto end_IL_1659;
																																											case 173:
																																											case 197:
																																												goto end_IL_1669;
																																											case 30:
																																												goto end_IL_1679;
																																											case 121:
																																												goto end_IL_1692;
																																											case 59:
																																												goto end_IL_16a2;
																																											case 26:
																																												goto end_IL_16b2;
																																											case 27:
																																												goto end_IL_16c2;
																																											case 57:
																																											case 273:
																																												return;
																																											}
																																											continue;
																																										}
																																										ptr2 += 8;
																																										goto end_IL_063c;
																																										continue;
																																										end_IL_0515:
																																										break;
																																									}
																																									break;
																																								}
																																								break;
																																							}
																																							break;
																																						}
																																						goto IL_070c;
																																						continue;
																																						end_IL_056c:
																																						break;
																																						IL_056c:;
																																					}
																																					break;
																																					IL_057c:;
																																				}
																																				break;
																																			}
																																			goto IL_0678;
																																			IL_0775:
																																			num6--;
																																			goto end_IL_063c;
																																			IL_0678:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																			goto IL_06b8;
																																			IL_06b8:
																																			array[num6 - 2] = 0;
																																			goto IL_0775;
																																		}
																																		break;
																																	}
																																	goto IL_08f5;
																																	IL_0948:
																																	num6--;
																																	goto end_IL_063c;
																																	IL_08f5:
																																	if (3 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0903;
																																	IL_0903:
																																	if (3 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0911;
																																	IL_0911:
																																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																	goto IL_093a;
																																	IL_093a:
																																	ptr2 += 8;
																																	goto IL_0948;
																																}
																																break;
																															}
																															goto IL_0668;
																															IL_070c:
																															ptr2 += 8;
																															goto end_IL_063c;
																															IL_0668:
																															array[num6] = 0;
																															goto IL_06d1;
																															IL_06d1:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																															goto IL_06f4;
																															IL_06f4:
																															array2[num6] = null;
																															goto IL_06fe;
																															IL_06fe:
																															num6++;
																															goto IL_070c;
																														}
																														break;
																													}
																													goto IL_0647;
																													IL_08cf:
																													num6--;
																													goto end_IL_063c;
																													IL_0647:
																													if (6 >= b)
																													{
																														goto IL_0655;
																													}
																													goto IL_071f;
																													IL_0655:
																													if (6 > b)
																													{
																														goto IL_0788;
																													}
																													goto IL_080b;
																													IL_080b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_084b;
																													IL_084b:
																													array[num6 - 2] = 0;
																													goto IL_085f;
																													IL_085f:
																													num6--;
																													num = 150;
																													goto end_IL_063c;
																													IL_0788:
																													if (5 < b)
																													{
																														break;
																													}
																													goto IL_0796;
																													IL_0796:
																													if (5 > b)
																													{
																														break;
																													}
																													goto IL_07a4;
																													IL_07a4:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_07e4;
																													IL_07e4:
																													array[num6 - 2] = 0;
																													goto IL_07f8;
																													IL_07f8:
																													num6--;
																													goto end_IL_063c;
																													IL_071f:
																													if (7 < b)
																													{
																														goto IL_072a;
																													}
																													goto IL_0762;
																													IL_072a:
																													if (8 < b)
																													{
																														break;
																													}
																													goto IL_0738;
																													IL_0738:
																													if (8 > b)
																													{
																														break;
																													}
																													goto IL_0746;
																													IL_0746:
																													num6--;
																													num = 84;
																													goto end_IL_063c;
																													IL_0762:
																													if (7 > b)
																													{
																														break;
																													}
																													goto IL_087b;
																													IL_087b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_08bb;
																													IL_08bb:
																													array[num6 - 2] = 0;
																													goto IL_08cf;
																												}
																												break;
																											}
																											goto IL_095b;
																											IL_09b8:
																											num6--;
																											goto end_IL_063c;
																											IL_095b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_099b;
																											IL_099b:
																											array[num6 - 2] = 0;
																											num = 233;
																											goto IL_09b8;
																										}
																										break;
																									}
																									goto IL_09cb;
																									IL_0d1d:
																									if (18 < b)
																									{
																										break;
																									}
																									goto IL_0d2b;
																									IL_09cb:
																									if (14 >= b)
																									{
																										goto IL_09d9;
																									}
																									goto IL_0bb2;
																									IL_09d9:
																									if (14 <= b)
																									{
																										goto IL_09e4;
																									}
																									goto IL_0a4c;
																									IL_09e4:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																									goto IL_0a25;
																									IL_0a25:
																									array[num6 - 2] = 0;
																									goto IL_0a39;
																									IL_0a39:
																									num6--;
																									goto end_IL_063c;
																									IL_0a4c:
																									if (11 < b)
																									{
																										goto IL_0a5a;
																									}
																									num = 73;
																									goto IL_0b0a;
																									IL_0a5a:
																									if (12 >= b)
																									{
																										goto IL_0a65;
																									}
																									goto IL_0ac4;
																									IL_0a65:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_0a73;
																									IL_0a73:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0a8c;
																									IL_0a8c:
																									array[num6] = 1;
																									num = 296;
																									goto IL_0aa3;
																									IL_0aa3:
																									num6++;
																									goto IL_0ab1;
																									IL_0ab1:
																									ptr2 += 16;
																									goto end_IL_063c;
																									IL_0ac4:
																									if (13 < b)
																									{
																										break;
																									}
																									num = 178;
																									goto IL_0adb;
																									IL_0d39:
																									((delegate*<UnityEngine.Object, void>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																									goto IL_0d62;
																									IL_0adb:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_0ae9;
																									IL_0ae9:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_063c;
																									IL_0d2b:
																									if (18 > b)
																									{
																										break;
																									}
																									goto IL_0d39;
																									IL_0b0a:
																									if (11 <= b)
																									{
																										goto end_IL_063c;
																									}
																									goto IL_0b18;
																									IL_0b18:
																									if (10 < b)
																									{
																										break;
																									}
																									goto IL_0b26;
																									IL_0b26:
																									if (10 > b)
																									{
																										break;
																									}
																									num = 72;
																									goto IL_0b3d;
																									IL_0d62:
																									num6--;
																									goto IL_0d70;
																									IL_0b3d:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0b9f;
																									IL_0b9f:
																									num6 -= 2;
																									goto end_IL_063c;
																									IL_0bb2:
																									if (16 >= b)
																									{
																										goto IL_0bc0;
																									}
																									goto IL_0ca5;
																									IL_0bc0:
																									if (16 <= b)
																									{
																										goto IL_0bcb;
																									}
																									goto IL_0c12;
																									IL_0bcb:
																									array2[num6] = array5[*(int*)(ptr2 + num3)];
																									goto IL_0be3;
																									IL_0be3:
																									array[num6] = 5;
																									goto IL_0bf1;
																									IL_0bf1:
																									num6++;
																									goto IL_0bff;
																									IL_0bff:
																									ptr2 += 8;
																									goto end_IL_063c;
																									IL_0c12:
																									if (15 < b)
																									{
																										break;
																									}
																									goto IL_0c20;
																									IL_0c20:
																									if (15 > b)
																									{
																										break;
																									}
																									num = 158;
																									goto IL_0c37;
																									IL_0d70:
																									ptr2 += 8;
																									goto end_IL_063c;
																									IL_0c37:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									num = 19;
																									goto IL_0c92;
																									IL_0c92:
																									num6--;
																									goto end_IL_063c;
																									IL_0ca5:
																									if (17 >= b)
																									{
																										goto IL_0cb0;
																									}
																									goto IL_0d1d;
																									IL_0cb0:
																									if (17 > b)
																									{
																										break;
																									}
																									goto IL_0cbe;
																									IL_0cbe:
																									array2[num6 - 1] = ((delegate*<Class192, GameObject>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])((Class192)array2[num6 - 1]);
																									goto IL_0cf6;
																									IL_0cf6:
																									array[num6 - 1] = 5;
																									goto IL_0d0a;
																									IL_0d0a:
																									ptr2 += 8;
																									goto end_IL_063c;
																								}
																								break;
																							}
																							goto IL_0d83;
																							IL_0dc1:
																							ptr2 += 16;
																							goto end_IL_063c;
																							IL_0d83:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																							goto IL_0d9c;
																							IL_0d9c:
																							array[num6] = 3;
																							goto IL_0daa;
																							IL_0daa:
																							num6++;
																							num = 166;
																							goto IL_0dc1;
																						}
																						break;
																					}
																					goto IL_0dd4;
																					IL_15d2:
																					if (37 < b)
																					{
																						break;
																					}
																					num = 123;
																					goto IL_15e6;
																					IL_0dd4:
																					if (28 >= b)
																					{
																						goto IL_0de2;
																					}
																					goto IL_126a;
																					IL_0de2:
																					if (28 > b)
																					{
																						goto IL_0df0;
																					}
																					goto IL_11e8;
																					IL_0df0:
																					if (23 >= b)
																					{
																						goto IL_0dfe;
																					}
																					goto IL_0fd0;
																					IL_0dfe:
																					if (23 > b)
																					{
																						goto IL_0e0c;
																					}
																					goto IL_0fa5;
																					IL_0e0c:
																					if (21 >= b)
																					{
																						goto IL_0e1a;
																					}
																					goto IL_0f1a;
																					IL_0e1a:
																					if (21 > b)
																					{
																						goto IL_0e28;
																					}
																					goto IL_0eaa;
																					IL_0e28:
																					if (20 < b)
																					{
																						break;
																					}
																					goto IL_0e36;
																					IL_0e36:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0e44;
																					IL_0e44:
																					array[num6 - 1] = 3;
																					goto IL_0e58;
																					IL_0e58:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0e97;
																					IL_0e97:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_0eaa:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0eea;
																					IL_0eea:
																					array[num6 - 2] = 3;
																					goto IL_0efe;
																					IL_0efe:
																					num6--;
																					num = 242;
																					goto end_IL_063c;
																					IL_0f1a:
																					if (22 < b)
																					{
																						break;
																					}
																					goto IL_0f28;
																					IL_0f28:
																					if (22 > b)
																					{
																						break;
																					}
																					goto IL_0f36;
																					IL_0f36:
																					array[num6 - 1] = 0;
																					goto IL_0f4a;
																					IL_0f4a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0f89;
																					IL_0f89:
																					ptr2 += 8;
																					num = 304;
																					goto end_IL_063c;
																					IL_0fa5:
																					array2[num6] = null;
																					goto IL_0faf;
																					IL_0faf:
																					array[num6] = 5;
																					goto IL_0fbd;
																					IL_0fbd:
																					num6++;
																					goto end_IL_063c;
																					IL_0fd0:
																					if (25 >= b)
																					{
																						goto IL_0fde;
																					}
																					goto IL_10f6;
																					IL_0fde:
																					if (25 <= b)
																					{
																						goto IL_0fe9;
																					}
																					goto IL_104f;
																					IL_0fe9:
																					array[num6 - 1] = 3;
																					goto IL_0ffd;
																					IL_0ffd:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_103c;
																					IL_103c:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_104f:
																					if (24 < b)
																					{
																						break;
																					}
																					goto IL_105d;
																					IL_105d:
																					if (24 > b)
																					{
																						break;
																					}
																					goto IL_106b;
																					IL_106b:
																					array[num6 - 2] = 0;
																					num = 110;
																					goto IL_1088;
																					IL_1088:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																					goto IL_10d5;
																					IL_10d5:
																					num6--;
																					goto IL_10e3;
																					IL_10e3:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_10f6:
																					if (26 >= b)
																					{
																						goto IL_1101;
																					}
																					goto IL_117f;
																					IL_1101:
																					if (26 > b)
																					{
																						break;
																					}
																					goto IL_110f;
																					IL_110f:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_114f;
																					IL_114f:
																					array[num6 - 2] = 3;
																					num = 140;
																					goto IL_116c;
																					IL_116c:
																					num6--;
																					goto end_IL_063c;
																					IL_117f:
																					if (27 < b)
																					{
																						break;
																					}
																					goto IL_118d;
																					IL_118d:
																					if (27 > b)
																					{
																						break;
																					}
																					goto IL_119b;
																					IL_119b:
																					array[num6] = 5;
																					goto IL_11a9;
																					IL_11a9:
																					array2[num6] = ((delegate*<GTPlayer>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])();
																					goto IL_11c7;
																					IL_11c7:
																					num6++;
																					goto IL_11d5;
																					IL_11d5:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_11e8:
																					array[num6 - 2] = 0;
																					goto IL_11fc;
																					IL_11fc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])((GTPlayer)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																					goto IL_1249;
																					IL_1249:
																					num6--;
																					goto IL_1257;
																					IL_1257:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_126a:
																					if (33 >= b)
																					{
																						goto IL_1278;
																					}
																					goto IL_14a1;
																					IL_1278:
																					if (33 <= b)
																					{
																						goto IL_1283;
																					}
																					goto IL_12e9;
																					IL_1283:
																					array[num6 - 1] = 3;
																					goto IL_1297;
																					IL_1297:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_12d6;
																					IL_12d6:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_12e9:
																					if (30 >= b)
																					{
																						goto IL_12f7;
																					}
																					goto IL_13c2;
																					IL_12f7:
																					if (30 <= b)
																					{
																						goto IL_1302;
																					}
																					goto IL_1354;
																					IL_1302:
																					((Class192)array2[num6 - 2]).vector3_0 = (Vector3)array2[num6 - 1];
																					num = 3;
																					goto IL_1338;
																					IL_1338:
																					num6 -= 2;
																					num = 183;
																					goto end_IL_063c;
																					IL_1354:
																					if (29 < b)
																					{
																						break;
																					}
																					goto IL_1362;
																					IL_1362:
																					if (29 > b)
																					{
																						break;
																					}
																					goto IL_1370;
																					IL_1370:
																					array[num6] = 4;
																					goto IL_137e;
																					IL_137e:
																					array2[num6] = ((delegate*<Vector3>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])();
																					goto IL_13a1;
																					IL_13a1:
																					num6++;
																					goto IL_13af;
																					IL_13af:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_13c2:
																					if (31 >= b)
																					{
																						goto IL_13cd;
																					}
																					goto IL_1441;
																					IL_13cd:
																					if (31 > b)
																					{
																						break;
																					}
																					goto IL_13db;
																					IL_13db:
																					array[num6 - 1] = 3;
																					goto IL_13ef;
																					IL_13ef:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_142e;
																					IL_142e:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_1441:
																					if (32 < b)
																					{
																						break;
																					}
																					goto IL_144f;
																					IL_144f:
																					if (32 > b)
																					{
																						break;
																					}
																					goto IL_145d;
																					IL_145d:
																					((Class192)array2[num6 - 2]).gameObject_0 = (GameObject)array2[num6 - 1];
																					goto IL_1485;
																					IL_1485:
																					num6 -= 2;
																					num = 254;
																					goto end_IL_063c;
																					IL_14a1:
																					if (35 >= b)
																					{
																						goto IL_14af;
																					}
																					goto IL_15a3;
																					IL_14af:
																					if (35 <= b)
																					{
																						goto IL_14ba;
																					}
																					goto IL_1519;
																					IL_14ba:
																					((delegate*<Rigidbody, bool, void>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																					goto IL_14f8;
																					IL_14f8:
																					num6 -= 2;
																					goto IL_1506;
																					IL_1506:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_1519:
																					if (34 < b)
																					{
																						break;
																					}
																					goto IL_1527;
																					IL_1527:
																					if (34 > b)
																					{
																						break;
																					}
																					num = 41;
																					goto IL_153e;
																					IL_15e6:
																					if (37 <= b)
																					{
																					}
																					break;
																					IL_153e:
																					array[num6 - 1] = 5;
																					num = 307;
																					goto IL_155b;
																					IL_155b:
																					array2[num6 - 1] = ((delegate*<Component, Rigidbody>)VerifyContextRuntimeTypeHandle[*(int*)(ptr2 + num3)])((GTPlayer)array2[num6 - 1]);
																					goto IL_1593;
																					IL_1593:
																					ptr2 += 8;
																					goto end_IL_063c;
																					IL_15a3:
																					if (36 >= b)
																					{
																						goto IL_15ae;
																					}
																					goto IL_15d2;
																					IL_15ae:
																					if (36 > b)
																					{
																						break;
																					}
																					goto IL_15b9;
																					IL_15b9:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_063c;
																				}
																				break;
																				IL_0609:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 13;
																		goto end_IL_063c;
																		continue;
																		end_IL_061c:
																		break;
																	}
																	continue;
																	end_IL_062c:
																	break;
																}
																continue;
																end_IL_063c:
																break;
															}
															continue;
															end_IL_160d:
															break;
														}
														continue;
														end_IL_1620:
														break;
													}
													continue;
													end_IL_162b:
													break;
												}
												continue;
												end_IL_1635:
												break;
											}
											continue;
											end_IL_1640:
											break;
										}
										continue;
										end_IL_1659:
										break;
									}
									continue;
									end_IL_1669:
									break;
								}
								continue;
								end_IL_1679:
								break;
							}
							continue;
							end_IL_1692:
							break;
						}
						continue;
						end_IL_16a2:
						break;
					}
					continue;
					end_IL_16b2:
					break;
				}
				continue;
				end_IL_16c2:
				break;
			}
		}
	}

	private static double RemotingCachedDataUserKeySet(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private static void TasksFlowActivityIdsCodeConnectAccess(Material material_0, Color color_0)
	{
		material_0.color = color_0;
	}

	private static Rigidbody STAAnsiClass(Component component_0)
	{
		return component_0.GetComponent<Rigidbody>();
	}

	private static void GetLoadedModulesStelem(Transform transform_0, Quaternion quaternion_0)
	{
		transform_0.rotation = quaternion_0;
	}

	private static void ThreadPoolBoundHandleOverlappedSizeOf(Transform transform_0, Vector3 vector3_3)
	{
		transform_0.position = vector3_3;
	}

	private static Transform ParamValuesSymCustomAttr(GameObject gameObject_1)
	{
		return gameObject_1.transform;
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 54;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 39;
				while (true)
				{
					byte[] array = new byte[4];
					num = 118;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypedReferenceUnpack.GetEventPropsResponseXmlNamespace);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02c1:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02a1:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_0294:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0284:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0277:
																									if (5 >= b)
																									{
																										while (true)
																										{
																											IL_0267:
																											if (5 > b)
																											{
																												while (4 >= b)
																												{
																													num = 137;
																													while (true)
																													{
																														if (num != 137)
																														{
																															if (num != 1118)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 0:
																															case 111:
																																goto IL_0254;
																															case 94:
																																goto IL_0267;
																															case 122:
																																goto IL_0277;
																															case 64:
																																goto IL_0284;
																															case 121:
																																goto IL_0294;
																															case 26:
																																goto IL_02a1;
																															case 115:
																																goto IL_02b1;
																															case 3:
																																goto IL_02c1;
																															case 58:
																																goto end_IL_02c1;
																															case 30:
																															case 51:
																																goto end_IL_02d1;
																															case 52:
																															case 60:
																																goto IL_02ec;
																															case 23:
																															case 69:
																																goto IL_02ff;
																															case 93:
																																goto IL_032d;
																															case 97:
																																goto IL_033d;
																															case 41:
																																goto IL_034b;
																															case 13:
																																goto IL_0359;
																															case 98:
																																goto IL_036c;
																															case 105:
																																goto IL_037c;
																															case 2:
																															case 25:
																																goto IL_038a;
																															case 92:
																															case 110:
																																goto IL_03cc;
																															case 95:
																																goto IL_03da;
																															case 119:
																															case 123:
																																goto IL_03ea;
																															case 126:
																																goto IL_0402;
																															case 101:
																																goto IL_041f;
																															case 85:
																															case 127:
																																goto IL_043b;
																															case 78:
																																goto IL_046d;
																															case 89:
																																goto IL_047b;
																															case 129:
																																goto IL_048e;
																															case 36:
																															case 67:
																																goto IL_049c;
																															case 50:
																																goto IL_04be;
																															case 83:
																																goto IL_04cc;
																															case 33:
																																goto IL_04da;
																															case 11:
																															case 29:
																																goto IL_0500;
																															case 61:
																																goto IL_0517;
																															case 81:
																																goto IL_053a;
																															case 34:
																																goto IL_0544;
																															case 82:
																																goto IL_0552;
																															case 19:
																															case 130:
																																goto IL_0565;
																															case 45:
																															case 99:
																																goto IL_0573;
																															case 90:
																																goto IL_057e;
																															case 65:
																																goto IL_058c;
																															case 87:
																																goto IL_05a8;
																															case 31:
																															case 46:
																																goto IL_05b3;
																															case 57:
																																goto IL_05cf;
																															case 102:
																																goto IL_05dd;
																															case 80:
																															case 106:
																																goto IL_05eb;
																															case 76:
																																goto IL_05fe;
																															case 43:
																															case 75:
																																goto IL_060c;
																															case 103:
																																goto IL_061a;
																															case 48:
																															case 108:
																																goto IL_0628;
																															case 6:
																																goto IL_068a;
																															case 24:
																															case 128:
																																goto IL_069d;
																															case 62:
																																goto IL_06ab;
																															case 21:
																															case 28:
																																goto IL_06b9;
																															case 8:
																																goto IL_0702;
																															case 77:
																																goto IL_0716;
																															case 9:
																															case 18:
																																goto IL_0729;
																															case 14:
																																goto IL_073d;
																															case 109:
																																goto IL_0791;
																															case 32:
																																goto IL_079f;
																															case 4:
																															case 5:
																															case 7:
																															case 17:
																															case 27:
																															case 35:
																															case 38:
																															case 40:
																															case 42:
																															case 47:
																															case 70:
																															case 71:
																															case 72:
																															case 73:
																															case 79:
																															case 86:
																															case 88:
																															case 100:
																															case 104:
																															case 107:
																															case 113:
																															case 116:
																															case 120:
																																goto end_IL_0241;
																															case 1:
																															case 10:
																															case 15:
																															case 16:
																															case 20:
																															case 49:
																															case 55:
																															case 56:
																															case 59:
																															case 63:
																															case 68:
																															case 91:
																															case 112:
																															case 114:
																															case 124:
																															case 125:
																																goto end_IL_02e1;
																															case 96:
																																goto end_IL_07c2;
																															case 12:
																																goto end_IL_07d5;
																															case 117:
																																goto end_IL_07df;
																															case 37:
																																goto end_IL_07ea;
																															case 74:
																															case 84:
																																goto end_IL_07ff;
																															case 118:
																																goto end_IL_080f;
																															case 39:
																															case 66:
																																goto end_IL_081f;
																															case 53:
																																goto end_IL_082f;
																															case 54:
																																goto end_IL_0848;
																															case 22:
																															case 44:
																																goto IL_086c;
																															}
																															continue;
																														}
																														if (4 <= b)
																														{
																															goto end_IL_02e1;
																														}
																														break;
																														continue;
																														end_IL_0241:
																														break;
																													}
																													break;
																													IL_0254:;
																												}
																												break;
																											}
																											goto IL_0500;
																											IL_0552:
																											ptr2 += 8;
																											goto end_IL_02e1;
																											IL_0500:
																											array[num5] = 0;
																											num = 61;
																											goto IL_0517;
																											IL_0517:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_053a;
																											IL_053a:
																											array2[num5] = null;
																											goto IL_0544;
																											IL_0544:
																											num5++;
																											goto IL_0552;
																										}
																										break;
																									}
																									goto IL_02ec;
																									IL_041f:
																									num5--;
																									num = 49;
																									goto end_IL_02e1;
																									IL_02ec:
																									if (6 < b)
																									{
																										break;
																									}
																									goto IL_037c;
																									IL_037c:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_038a;
																									IL_038a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0402;
																									IL_0402:
																									array[num5 - 2] = 0;
																									num = 101;
																									goto IL_041f;
																								}
																								break;
																							}
																							goto IL_032d;
																							IL_04da:
																							ptr2 += 8;
																							goto end_IL_02e1;
																							IL_032d:
																							if (3 > b)
																							{
																								goto IL_036c;
																							}
																							goto IL_03ea;
																							IL_03ea:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02e1;
																							IL_036c:
																							if (1 < b)
																							{
																								goto IL_03cc;
																							}
																							goto IL_048e;
																							IL_03cc:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_03da;
																							IL_03da:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_043b;
																							IL_043b:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 78;
																							goto IL_046d;
																							IL_046d:
																							ptr2 += 8;
																							goto IL_047b;
																							IL_047b:
																							num5--;
																							goto end_IL_02e1;
																							IL_048e:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_049c;
																							IL_049c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							num = 50;
																							goto IL_04be;
																							IL_04be:
																							array[num5] = 0;
																							goto IL_04cc;
																							IL_04cc:
																							num5++;
																							goto IL_04da;
																						}
																						break;
																					}
																					goto IL_02ff;
																					IL_0359:
																					ptr2 += 8;
																					goto end_IL_02e1;
																					IL_02ff:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					num = 97;
																					goto IL_033d;
																					IL_033d:
																					array[num5] = 0;
																					goto IL_034b;
																					IL_034b:
																					num5++;
																					goto IL_0359;
																				}
																				break;
																			}
																			goto IL_0565;
																			IL_0791:
																			num5--;
																			goto IL_079f;
																			IL_0565:
																			if (10 < b)
																			{
																				goto IL_0573;
																			}
																			goto IL_05fe;
																			IL_0573:
																			if (12 < b)
																			{
																				goto IL_057e;
																			}
																			num = 87;
																			goto IL_05a8;
																			IL_057e:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_058c;
																			IL_058c:
																			if (13 > b)
																			{
																			}
																			break;
																			IL_079f:
																			ptr2 += 8;
																			goto end_IL_02e1;
																			IL_05a8:
																			if (12 <= b)
																			{
																				goto IL_05b3;
																			}
																			goto IL_05cf;
																			IL_05b3:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02e1;
																			IL_05cf:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_05dd;
																			IL_05dd:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_05eb;
																			IL_05eb:
																			num5--;
																			goto end_IL_02e1;
																			IL_05fe:
																			if (10 > b)
																			{
																				goto IL_060c;
																			}
																			goto IL_0729;
																			IL_060c:
																			if (8 >= b)
																			{
																				goto IL_061a;
																			}
																			goto IL_069d;
																			IL_061a:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0628;
																			IL_0628:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_068a;
																			IL_068a:
																			num5 -= 2;
																			goto end_IL_02e1;
																			IL_069d:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06ab;
																			IL_06ab:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_06b9;
																			IL_06b9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 8;
																			goto IL_0702;
																			IL_0702:
																			array[num5 - 2] = 0;
																			goto IL_0716;
																			IL_0716:
																			num5--;
																			goto end_IL_02e1;
																			IL_0729:
																			array[num5 - 2] = 0;
																			goto IL_073d;
																			IL_073d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)IKeyValuePairVTDISPATCH[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0791;
																		}
																		break;
																		IL_02b1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02e1;
																continue;
																end_IL_02c1:
																break;
															}
															continue;
															end_IL_02d1:
															break;
														}
														continue;
														end_IL_02e1:
														break;
													}
													continue;
												}
												goto IL_086c;
												IL_086c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_07c2:
												break;
											}
											continue;
											end_IL_07d5:
											break;
										}
										continue;
										end_IL_07df:
										break;
									}
									continue;
									end_IL_07ea:
									break;
								}
								continue;
								end_IL_07ff:
								break;
							}
							continue;
							end_IL_080f:
							break;
						}
						continue;
						end_IL_081f:
						break;
					}
					continue;
					end_IL_082f:
					break;
				}
				continue;
				end_IL_0848:
				break;
			}
		}
	}

	private static Quaternion EventRegistrationTokenListComEventInterfaceAttribute(float float_2, float float_3, float float_4)
	{
		return Quaternion.Euler(float_2, float_3, float_4);
	}

	private static bool ContinuationTaskFromResultTaskFDispatchable(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static int smethod_4(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 15;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										num = 80;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StringInfogetIsServerGC.stringInfogetIsServerGC_0);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 94;
															while (true)
															{
																if (num != 94)
																{
																	if (num != 1075)
																	{
																		goto IL_0357;
																	}
																	switch (num)
																	{
																	case 29:
																	case 42:
																		goto end_IL_0187;
																	case 8:
																		goto IL_01c2;
																	case 46:
																		goto IL_01d0;
																	case 48:
																		goto IL_01de;
																	case 84:
																		goto IL_01ec;
																	case 6:
																	case 52:
																		goto IL_01f7;
																	case 56:
																		goto IL_0220;
																	case 75:
																		goto IL_022e;
																	case 2:
																		goto IL_0241;
																	case 13:
																	case 24:
																		goto IL_024f;
																	case 25:
																		goto IL_025d;
																	case 54:
																	case 82:
																		goto IL_026b;
																	case 20:
																		goto IL_02ab;
																	case 69:
																		goto IL_02bf;
																	case 11:
																		goto IL_02d2;
																	case 21:
																	case 57:
																		goto IL_02e0;
																	case 17:
																		goto IL_0357;
																	case 85:
																		goto IL_036a;
																	case 45:
																		goto IL_0378;
																	case 73:
																		goto IL_038b;
																	case 16:
																		goto IL_0396;
																	case 44:
																		goto IL_03a4;
																	case 1:
																		goto IL_03b2;
																	case 30:
																	case 58:
																		goto IL_03c0;
																	case 76:
																		goto IL_03e1;
																	case 36:
																	case 59:
																		goto IL_03ec;
																	case 51:
																		goto IL_03fa;
																	case 7:
																	case 63:
																		goto IL_0408;
																	case 33:
																		goto IL_0424;
																	case 5:
																	case 27:
																		goto IL_042f;
																	case 39:
																		goto IL_043d;
																	case 40:
																		goto IL_0460;
																	case 50:
																		goto IL_046a;
																	case 72:
																		goto IL_0478;
																	case 0:
																	case 10:
																	case 12:
																	case 26:
																	case 28:
																	case 32:
																	case 35:
																	case 37:
																	case 60:
																	case 61:
																	case 65:
																	case 66:
																	case 68:
																	case 71:
																	case 79:
																	case 83:
																	case 86:
																		goto IL_0488;
																	case 55:
																		goto IL_04ab;
																	case 22:
																		goto IL_04b9;
																	case 62:
																		goto IL_04c7;
																	case 9:
																	case 19:
																	case 23:
																	case 31:
																	case 34:
																	case 43:
																	case 47:
																	case 53:
																	case 67:
																	case 78:
																	case 87:
																		goto end_IL_0197;
																	case 41:
																		goto end_IL_04d5;
																	case 80:
																		goto end_IL_04e8;
																	case 70:
																		goto end_IL_04f2;
																	case 18:
																		goto end_IL_04fd;
																	case 77:
																		goto end_IL_051b;
																	case 4:
																	case 38:
																		goto end_IL_0530;
																	case 3:
																		goto end_IL_0540;
																	case 64:
																	case 81:
																		goto end_IL_0550;
																	case 14:
																		goto end_IL_0560;
																	case 15:
																		goto end_IL_0570;
																	case 49:
																	case 74:
																		goto IL_058b;
																	}
																	continue;
																}
																ptr2++;
																num = 8;
																goto IL_01c2;
																IL_04ab:
																array[num5] = 0;
																goto IL_04b9;
																IL_04c7:
																ptr2 += 8;
																goto end_IL_0197;
																IL_04b9:
																num5++;
																goto IL_04c7;
																IL_01c2:
																if (b >= 1)
																{
																	goto IL_01d0;
																}
																goto IL_0488;
																IL_01d0:
																if (b <= 8)
																{
																	goto IL_01de;
																}
																goto IL_0488;
																IL_01de:
																if (4 >= b)
																{
																	goto IL_01ec;
																}
																goto IL_038b;
																IL_01ec:
																if (4 <= b)
																{
																	goto IL_01f7;
																}
																goto IL_0241;
																IL_01f7:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0220;
																IL_0220:
																ptr2 += 8;
																goto IL_022e;
																IL_022e:
																num5--;
																goto end_IL_0197;
																IL_0241:
																if (2 < b)
																{
																	goto IL_024f;
																}
																goto IL_02d2;
																IL_024f:
																if (3 >= b)
																{
																	goto IL_025d;
																}
																goto IL_0488;
																IL_025d:
																if (3 <= b)
																{
																	goto IL_026b;
																}
																goto IL_0488;
																IL_026b:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_02ab;
																IL_02ab:
																array[num5 - 2] = 0;
																goto IL_02bf;
																IL_02bf:
																num5--;
																goto end_IL_0197;
																IL_02d2:
																if (2 <= b)
																{
																	goto IL_02e0;
																}
																goto IL_036a;
																IL_02e0:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																num = 17;
																goto IL_0357;
																IL_0357:
																num5 -= 2;
																goto end_IL_0197;
																IL_036a:
																if (1 >= b)
																{
																	goto IL_0378;
																}
																goto IL_0488;
																IL_0378:
																if (1 <= b)
																{
																}
																goto IL_0488;
																IL_038b:
																if (6 >= b)
																{
																	goto IL_0396;
																}
																goto IL_03e1;
																IL_0396:
																if (6 <= b)
																{
																	goto end_IL_0197;
																}
																goto IL_03a4;
																IL_03a4:
																if (5 >= b)
																{
																	goto IL_03b2;
																}
																goto IL_0488;
																IL_03b2:
																if (5 <= b)
																{
																	goto IL_03c0;
																}
																goto IL_0488;
																IL_03c0:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 31;
																goto end_IL_0197;
																IL_03e1:
																if (7 < b)
																{
																	goto IL_03ec;
																}
																goto IL_0424;
																IL_03ec:
																if (8 >= b)
																{
																	goto IL_03fa;
																}
																goto IL_0488;
																IL_03fa:
																if (8 <= b)
																{
																	goto IL_0408;
																}
																goto IL_0488;
																IL_0408:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_0197;
																IL_0424:
																if (7 <= b)
																{
																	goto IL_042f;
																}
																goto IL_0488;
																IL_042f:
																array[num5] = 0;
																goto IL_043d;
																IL_043d:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0460;
																IL_0460:
																array2[num5] = null;
																goto IL_046a;
																IL_046a:
																num5++;
																goto IL_0478;
																IL_0478:
																ptr2 += 8;
																goto end_IL_0197;
																IL_0488:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_04ab;
																continue;
																end_IL_0187:
																break;
															}
															continue;
															end_IL_0197:
															break;
														}
														continue;
													}
													goto IL_058b;
													IL_058b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04d5:
													break;
												}
												continue;
												end_IL_04e8:
												break;
											}
											continue;
											end_IL_04f2:
											break;
										}
										continue;
										end_IL_04fd:
										break;
									}
									continue;
									end_IL_051b:
									break;
								}
								continue;
								end_IL_0530:
								break;
							}
							continue;
							end_IL_0540:
							break;
						}
						continue;
						end_IL_0550:
						break;
					}
					continue;
					end_IL_0560:
					break;
				}
				continue;
				end_IL_0570:
				break;
			}
		}
	}

	private static double SecurityEnabledGetMachineStoreForAssembly(double double_1)
	{
		return Math.Floor(double_1);
	}

	private static int getIsCompatibilityBehaviorDefinedSunday(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private unsafe void Update()
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				num = 14;
				while (true)
				{
					if (num != 14)
					{
						if (num != 995)
						{
							return;
						}
						switch (num)
						{
						case 6:
							goto end_IL_0041;
						case 7:
							goto end_IL_004e;
						case 5:
							goto IL_0066;
						case 1:
						case 4:
							goto IL_0088;
						case 0:
							goto IL_008e;
						case 2:
						case 3:
							return;
						}
						continue;
					}
					num3 = 0;
					goto IL_0088;
					IL_0088:
					if (num3 != 73)
					{
						goto IL_0066;
					}
					goto IL_008e;
					IL_0066:
					((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, Class192, void>)NOTIFCONVERTWARNINGCodePageDataFileHeader[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11, this);
					goto IL_0088;
					IL_008e:
					num3 = 0;
					return;
					continue;
					end_IL_0041:
					break;
				}
				continue;
				end_IL_004e:
				break;
			}
		}
	}

	private static bool SafeLocalAllocHandleHostExecutionContext(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightGrab;
	}

	private static ControllerInputPoller getDefaultSerializationName()
	{
		return ControllerInputPoller.instance;
	}

	private static Vector3 getDeltaFreeNamedDataSlot(Vector3 vector3_3, float float_2)
	{
		return vector3_3 * float_2;
	}

	unsafe static Class192()
	{
		int num = 12;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 46;
					while (true)
					{
						int num2 = 1;
						while (true)
						{
							int num3 = num2 * 4;
							while (true)
							{
								byte[] array = new byte[3];
								while (true)
								{
									object[] array2 = new object[3];
									while (true)
									{
										long[] array3 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MetadataSectionEntryUnaligned.StoreTransactionKeyValuePairComparator);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 49;
															while (true)
															{
																IL_0211:
																if (b >= 1)
																{
																	while (b <= 8)
																	{
																		num = 63;
																		while (true)
																		{
																			IL_01ee:
																			if (4 >= b)
																			{
																				while (true)
																				{
																					IL_01de:
																					if (4 > b)
																					{
																						while (true)
																						{
																							IL_01ce:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_01c1:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (1 <= b)
																											{
																												num = 88;
																												while (num != 88)
																												{
																													if (num != 1069)
																													{
																														goto IL_042e;
																													}
																													switch (num)
																													{
																													case 16:
																														goto IL_019e;
																													case 34:
																														goto IL_01b1;
																													case 60:
																														goto IL_01c1;
																													case 43:
																														goto IL_01ce;
																													case 13:
																														goto IL_01de;
																													case 63:
																														goto IL_01ee;
																													case 55:
																														goto IL_01fe;
																													case 49:
																														goto IL_0211;
																													case 54:
																														goto end_IL_0211;
																													case 37:
																													case 65:
																														goto end_IL_0221;
																													case 0:
																													case 77:
																														goto IL_0245;
																													case 14:
																														goto IL_025a;
																													case 79:
																														goto IL_026d;
																													case 17:
																														goto IL_027b;
																													case 21:
																													case 30:
																														goto IL_0292;
																													case 6:
																														goto IL_02a7;
																													case 47:
																													case 59:
																														goto IL_02c3;
																													case 50:
																														goto IL_02d8;
																													case 18:
																														goto IL_02eb;
																													case 81:
																														goto IL_02f9;
																													case 25:
																													case 58:
																														goto IL_0307;
																													case 42:
																														goto IL_031b;
																													case 61:
																														goto IL_037e;
																													case 35:
																														goto IL_038c;
																													case 5:
																														goto IL_039f;
																													case 70:
																														goto IL_03ad;
																													case 24:
																													case 80:
																														goto IL_03bb;
																													case 19:
																														goto IL_03de;
																													case 64:
																														goto IL_03ec;
																													case 41:
																														goto IL_03fa;
																													case 48:
																														goto IL_040d;
																													case 8:
																														goto IL_0418;
																													case 67:
																														goto IL_0423;
																													case 26:
																													case 32:
																														goto IL_042e;
																													case 68:
																														goto IL_0447;
																													case 66:
																													case 76:
																														goto IL_0452;
																													case 57:
																														goto IL_046b;
																													case 1:
																													case 15:
																													case 22:
																													case 29:
																													case 31:
																													case 33:
																													case 36:
																													case 62:
																													case 72:
																													case 74:
																														goto end_IL_018b;
																													case 38:
																														goto IL_0490;
																													case 7:
																													case 10:
																													case 20:
																													case 23:
																													case 28:
																													case 45:
																													case 69:
																													case 73:
																													case 75:
																													case 78:
																														goto end_IL_023a;
																													case 56:
																														goto end_IL_049e;
																													case 2:
																														goto end_IL_04b1;
																													case 27:
																													case 40:
																														goto end_IL_04bb;
																													case 51:
																														goto end_IL_04c6;
																													case 4:
																													case 52:
																														goto end_IL_04d6;
																													case 39:
																														goto end_IL_04e6;
																													case 46:
																														goto end_IL_04f6;
																													case 3:
																													case 53:
																													case 71:
																														goto end_IL_0506;
																													case 11:
																														goto end_IL_0511;
																													case 12:
																														goto end_IL_0523;
																													case 9:
																													case 44:
																														return;
																													}
																													continue;
																													end_IL_018b:
																													break;
																												}
																												break;
																												IL_019e:;
																											}
																											break;
																											IL_01b1:;
																										}
																										break;
																									}
																									goto IL_0245;
																									IL_025a:
																									ptr2 += 8;
																									goto end_IL_023a;
																									IL_0245:
																									((delegate*<void>)UnhandledExceptionTraceSynchronousWorkStart[*(int*)(ptr2 + num3)])();
																									goto IL_025a;
																								}
																								break;
																							}
																							goto IL_026d;
																							IL_0292:
																							((delegate*<void>)UnhandledExceptionTraceSynchronousWorkStart[*(int*)(ptr2 + num3)])();
																							goto IL_02a7;
																							IL_026d:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_027b;
																							IL_027b:
																							if (3 > b)
																							{
																								break;
																							}
																							num = 21;
																							goto IL_0292;
																							IL_02a7:
																							ptr2 += 8;
																							goto end_IL_023a;
																						}
																						break;
																					}
																					num = 47;
																					goto IL_02c3;
																					IL_02c3:
																					((delegate*<void>)UnhandledExceptionTraceSynchronousWorkStart[*(int*)(ptr2 + num3)])();
																					goto IL_02d8;
																					IL_02d8:
																					ptr2 += 8;
																					goto end_IL_023a;
																				}
																				break;
																			}
																			goto IL_02eb;
																			IL_046b:
																			num5--;
																			goto end_IL_023a;
																			IL_02eb:
																			if (6 >= b)
																			{
																				goto IL_02f9;
																			}
																			goto IL_040d;
																			IL_02f9:
																			if (6 <= b)
																			{
																				goto IL_0307;
																			}
																			goto IL_039f;
																			IL_0307:
																			array[num5 - 3] = 5;
																			goto IL_031b;
																			IL_031b:
																			array2[num5 - 3] = ((delegate*<float, float, float, object>)UnhandledExceptionTraceSynchronousWorkStart[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1])));
																			goto IL_037e;
																			IL_037e:
																			num5 -= 2;
																			goto IL_038c;
																			IL_038c:
																			ptr2 += 8;
																			goto end_IL_023a;
																			IL_039f:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_03ad;
																			IL_03ad:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_03bb;
																			IL_03bb:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(float*)(ptr2 + num3);
																			num = 19;
																			goto IL_03de;
																			IL_03de:
																			array[num5] = 3;
																			goto IL_03ec;
																			IL_03ec:
																			num5++;
																			goto IL_03fa;
																			IL_03fa:
																			ptr2 += 8;
																			goto end_IL_023a;
																			IL_040d:
																			if (7 < b)
																			{
																				goto IL_0418;
																			}
																			goto IL_0447;
																			IL_0418:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0423;
																			IL_0423:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_042e;
																			IL_042e:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_023a;
																			IL_0447:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0452;
																			IL_0452:
																			vector3_2 = (Vector3)array2[num5 - 1];
																			goto IL_046b;
																		}
																		break;
																		IL_01fe:;
																	}
																}
																((delegate*<void>)UnhandledExceptionTraceSynchronousWorkStart[*(int*)(ptr2 + num3)])();
																goto IL_0490;
																IL_0490:
																ptr2 += 8;
																goto end_IL_023a;
																continue;
																end_IL_0211:
																break;
															}
															continue;
															end_IL_0221:
															break;
														}
														continue;
														end_IL_023a:
														break;
													}
													continue;
													end_IL_049e:
													break;
												}
												continue;
												end_IL_04b1:
												break;
											}
											continue;
											end_IL_04bb:
											break;
										}
										continue;
										end_IL_04c6:
										break;
									}
									continue;
									end_IL_04d6:
									break;
								}
								continue;
								end_IL_04e6:
								break;
							}
							continue;
							end_IL_04f6:
							break;
						}
						continue;
						end_IL_0506:
						break;
					}
					continue;
					end_IL_0511:
					break;
				}
				continue;
				end_IL_0523:
				break;
			}
		}
	}

	private static double SorterGenericArrayFUNCNONVIRTUAL(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private static GorillaTagger GetCachedSoapAttributeRawSecurityDescriptor()
	{
		return GorillaTagger.Instance;
	}

	private static bool DateTimeRawInfoMethodReturnMessageWrapper(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private static GTPlayer GroupSelfRelative()
	{
		return GTPlayer.Instance;
	}

	private static void IDynamicPropertyGetDllEntry(UnityEngine.Object object_0)
	{
		UnityEngine.Object.Destroy(object_0);
	}

	private static void ProfileSingleProcessSub(Transform transform_0, Vector3 vector3_3)
	{
		transform_0.localScale = vector3_3;
	}

	private unsafe static int smethod_6()
	{
		int num = 9;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetNextArgTypeDaylightName.PointArrayUseGenitiveMonth);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_033c:
														byte b = *ptr2;
														while (true)
														{
															IL_032c:
															ptr2++;
															while (true)
															{
																IL_031c:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02ff:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02ef:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02df:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02cf:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_02af:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											while (true)
																											{
																												IL_029f:
																												ptr2 += 8;
																												while (true)
																												{
																													IL_0286:
																													num5--;
																													num = 153;
																													while (num != 153)
																													{
																														if (num != 1134)
																														{
																															goto IL_03b6;
																														}
																														switch (num)
																														{
																														case 29:
																															goto IL_0286;
																														case 124:
																															goto IL_029f;
																														case 5:
																														case 140:
																															goto IL_02af;
																														case 73:
																															goto IL_02cf;
																														case 99:
																															goto IL_02df;
																														case 35:
																															goto IL_02ef;
																														case 107:
																															goto IL_02ff;
																														case 7:
																															goto IL_030c;
																														case 125:
																															goto IL_031c;
																														case 22:
																															goto IL_032c;
																														case 43:
																														case 95:
																															goto IL_033c;
																														case 78:
																														case 97:
																															goto IL_0347;
																														case 85:
																															goto IL_0352;
																														case 53:
																														case 93:
																															goto IL_0360;
																														case 6:
																															goto IL_03a0;
																														case 70:
																															goto IL_03b6;
																														case 1:
																														case 67:
																															goto IL_03c1;
																														case 102:
																															goto IL_03d4;
																														case 4:
																														case 111:
																															goto IL_03e7;
																														case 118:
																															goto IL_03ff;
																														case 62:
																														case 112:
																															goto IL_040d;
																														case 10:
																															goto IL_041b;
																														case 69:
																														case 88:
																															goto IL_0429;
																														case 63:
																															goto IL_048b;
																														case 12:
																														case 123:
																															goto IL_049e;
																														case 114:
																															goto IL_04ac;
																														case 0:
																														case 83:
																															goto IL_04b7;
																														case 33:
																															goto IL_04c5;
																														case 89:
																														case 94:
																															goto IL_04d3;
																														case 2:
																														case 72:
																															goto IL_04e6;
																														case 66:
																															goto IL_0525;
																														case 31:
																															goto IL_0538;
																														case 56:
																														case 136:
																															goto IL_054b;
																														case 74:
																														case 137:
																															goto IL_0567;
																														case 59:
																															goto IL_0575;
																														case 3:
																															goto IL_0580;
																														case 24:
																															goto IL_058e;
																														case 11:
																														case 81:
																															goto IL_05aa;
																														case 110:
																															goto IL_05b8;
																														case 106:
																															goto IL_05db;
																														case 44:
																															goto IL_05e5;
																														case 54:
																															goto IL_05f3;
																														case 138:
																															goto IL_0614;
																														case 103:
																															goto IL_062c;
																														case 139:
																															goto IL_063c;
																														case 141:
																															goto IL_064f;
																														case 19:
																														case 116:
																															goto IL_065d;
																														case 23:
																															goto IL_0686;
																														case 45:
																															goto IL_0694;
																														case 144:
																															goto IL_06a7;
																														case 27:
																														case 146:
																															goto IL_06ba;
																														case 21:
																															goto IL_06c8;
																														case 28:
																														case 51:
																															goto IL_06d6;
																														case 104:
																															goto IL_071a;
																														case 82:
																															goto IL_0737;
																														case 134:
																															goto IL_074a;
																														case 41:
																														case 75:
																															goto IL_0755;
																														case 14:
																															goto IL_0763;
																														case 48:
																														case 77:
																															goto IL_0771;
																														case 64:
																															goto IL_079a;
																														case 17:
																															goto IL_07b3;
																														case 115:
																															goto IL_07be;
																														case 120:
																															goto IL_07cc;
																														case 92:
																														case 145:
																															goto IL_07da;
																														case 79:
																															goto IL_07f3;
																														case 30:
																															goto IL_0801;
																														case 117:
																															goto IL_0818;
																														case 18:
																														case 91:
																															goto IL_082b;
																														case 127:
																															goto IL_0874;
																														case 133:
																															goto IL_0888;
																														case 13:
																														case 15:
																														case 25:
																														case 38:
																														case 46:
																														case 50:
																														case 52:
																														case 55:
																														case 58:
																														case 60:
																														case 68:
																														case 80:
																														case 84:
																														case 96:
																														case 98:
																														case 101:
																														case 108:
																														case 119:
																														case 121:
																														case 122:
																														case 126:
																														case 128:
																														case 129:
																														case 130:
																														case 131:
																															goto end_IL_030c;
																														case 16:
																														case 20:
																														case 26:
																														case 37:
																														case 39:
																														case 42:
																														case 47:
																														case 49:
																														case 57:
																														case 71:
																														case 76:
																														case 87:
																														case 90:
																														case 100:
																														case 109:
																														case 135:
																														case 143:
																															goto end_IL_0273;
																														case 36:
																															goto end_IL_08bd;
																														case 61:
																															goto end_IL_08d0;
																														case 113:
																															goto end_IL_08da;
																														case 65:
																															goto end_IL_08e5;
																														case 105:
																														case 142:
																															goto end_IL_08f5;
																														case 40:
																															goto end_IL_0905;
																														case 32:
																														case 34:
																															goto end_IL_0915;
																														case 8:
																															goto end_IL_0925;
																														case 9:
																															goto end_IL_0935;
																														case 86:
																														case 132:
																															goto IL_0950;
																														}
																														continue;
																														end_IL_0273:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_074a;
																									IL_0888:
																									num5--;
																									num = 42;
																									break;
																									IL_074a:
																									if (2 < b)
																									{
																										goto IL_0755;
																									}
																									goto IL_07b3;
																									IL_0755:
																									if (3 < b)
																									{
																										goto end_IL_030c;
																									}
																									goto IL_0763;
																									IL_0763:
																									if (3 > b)
																									{
																										goto end_IL_030c;
																									}
																									goto IL_0771;
																									IL_0771:
																									array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_079a;
																									IL_079a:
																									array[num5 - 1] = 5;
																									break;
																									IL_07b3:
																									if (2 > b)
																									{
																										goto IL_07be;
																									}
																									goto IL_082b;
																									IL_07be:
																									if (1 < b)
																									{
																										goto end_IL_030c;
																									}
																									goto IL_07cc;
																									IL_07cc:
																									if (1 > b)
																									{
																										goto end_IL_030c;
																									}
																									goto IL_07da;
																									IL_07da:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_07f3;
																									IL_07f3:
																									array[num5] = 0;
																									goto IL_0801;
																									IL_0801:
																									num5++;
																									num = 117;
																									goto IL_0818;
																									IL_0818:
																									ptr2 += 8;
																									break;
																									IL_082b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 127;
																									goto IL_0874;
																									IL_0874:
																									array[num5 - 2] = 0;
																									goto IL_0888;
																								}
																								break;
																							}
																							goto IL_049e;
																							IL_0694:
																							num5--;
																							break;
																							IL_049e:
																							if (6 >= b)
																							{
																								goto IL_04ac;
																							}
																							goto IL_0538;
																							IL_04ac:
																							if (6 > b)
																							{
																								goto IL_04b7;
																							}
																							goto IL_04e6;
																							IL_04b7:
																							if (5 < b)
																							{
																								goto end_IL_030c;
																							}
																							goto IL_04c5;
																							IL_04c5:
																							if (5 > b)
																							{
																								goto end_IL_030c;
																							}
																							goto IL_04d3;
																							IL_04d3:
																							array[num5] = 5;
																							goto IL_0614;
																							IL_0614:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_062c;
																							IL_062c:
																							num5++;
																							goto IL_06a7;
																							IL_06a7:
																							ptr2 += 8;
																							break;
																							IL_04e6:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0525;
																							IL_0525:
																							num5 -= 3;
																							break;
																							IL_0538:
																							if (7 < b)
																							{
																								goto end_IL_030c;
																							}
																							goto IL_064f;
																							IL_064f:
																							if (7 > b)
																							{
																								goto end_IL_030c;
																							}
																							goto IL_065d;
																							IL_065d:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0686;
																							IL_0686:
																							ptr2 += 8;
																							goto IL_0694;
																						}
																						break;
																					}
																					goto IL_03e7;
																					IL_03e7:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																				}
																				break;
																			}
																			goto IL_0347;
																			IL_0429:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_048b;
																			IL_0347:
																			if (12 >= b)
																			{
																				goto IL_0352;
																			}
																			goto IL_03b6;
																			IL_0352:
																			if (12 <= b)
																			{
																				goto IL_0360;
																			}
																			goto IL_0567;
																			IL_0360:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03a0;
																			IL_03a0:
																			array[num5 - 2] = 0;
																			goto IL_03d4;
																			IL_03d4:
																			num5--;
																			break;
																			IL_0567:
																			if (10 >= b)
																			{
																				goto IL_0575;
																			}
																			num = 146;
																			goto IL_06ba;
																			IL_0575:
																			if (10 > b)
																			{
																				goto IL_0580;
																			}
																			num = 81;
																			goto IL_05aa;
																			IL_0580:
																			if (9 < b)
																			{
																				goto end_IL_030c;
																			}
																			goto IL_058e;
																			IL_058e:
																			if (9 <= b)
																			{
																				break;
																			}
																			goto end_IL_030c;
																			IL_054b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_05aa:
																			array[num5] = 0;
																			goto IL_05b8;
																			IL_05b8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05db;
																			IL_05db:
																			array2[num5] = null;
																			goto IL_05e5;
																			IL_05e5:
																			num5++;
																			goto IL_05f3;
																			IL_05f3:
																			ptr2 += 8;
																			break;
																			IL_048b:
																			num5 -= 2;
																			break;
																			IL_06ba:
																			if (11 < b)
																			{
																				goto end_IL_030c;
																			}
																			goto IL_06c8;
																			IL_06c8:
																			if (11 > b)
																			{
																				goto end_IL_030c;
																			}
																			goto IL_06d6;
																			IL_06d6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_071a;
																			IL_071a:
																			array[num5 - 2] = 0;
																			num = 82;
																			goto IL_0737;
																			IL_0737:
																			num5--;
																			break;
																			IL_03b6:
																			if (14 < b)
																			{
																				goto IL_03c1;
																			}
																			goto IL_03ff;
																			IL_03c1:
																			if (15 < b)
																			{
																				goto end_IL_030c;
																			}
																			goto IL_063c;
																			IL_063c:
																			if (15 <= b)
																			{
																			}
																			goto end_IL_030c;
																			IL_03ff:
																			if (14 > b)
																			{
																				goto IL_040d;
																			}
																			goto IL_054b;
																			IL_040d:
																			if (13 < b)
																			{
																				goto end_IL_030c;
																			}
																			goto IL_041b;
																			IL_041b:
																			if (13 > b)
																			{
																				goto end_IL_030c;
																			}
																			goto IL_0429;
																		}
																		goto end_IL_031c;
																		continue;
																		end_IL_030c:
																		break;
																		IL_030c:;
																	}
																}
																else
																{
																	num = 101;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_031c:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0950;
												IL_0950:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08bd:
												break;
											}
											continue;
											end_IL_08d0:
											break;
										}
										continue;
										end_IL_08da:
										break;
									}
									continue;
									end_IL_08e5:
									break;
								}
								continue;
								end_IL_08f5:
								break;
							}
							continue;
							end_IL_0905:
							break;
						}
						continue;
						end_IL_0915:
						break;
					}
					continue;
					end_IL_0925:
					break;
				}
				continue;
				end_IL_0935:
				break;
			}
		}
	}

	private static Vector3 FileSystemInfoSignData()
	{
		return Vector3.zero;
	}

	private static int OverflowActivityId(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static object SecurityUnmngdCodeAccessStrongNameKeyDelete(float float_2, float float_3, float float_4)
	{
		return new Vector3(float_2, float_3, float_4);
	}

	private static double GetDateTimeFormatsgetCharUnknown(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static Vector3 getOriginalExceptionJitImmediate(Class192 class192_1)
	{
		return class192_1.vector3_0;
	}

	private static Vector3 ProcessorArchitectureAMDVTCY()
	{
		return vector3_2;
	}

	private static bool getCapsLockgetMaxCapacity(Vector3 vector3_3, Vector3 vector3_4)
	{
		return vector3_3 != vector3_4;
	}

	private static Rigidbody IsMetricCustomErrorsEntry(Collider collider_0)
	{
		return collider_0.attachedRigidbody;
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							num = 106;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										IL_0683:
										array3[1] = int_2;
										while (true)
										{
											IL_0678:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddIdentityZeroFreeGlobalAllocUnicode.AsBstrIsFinal);
											while (true)
											{
												IL_066e:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_065b:
													if (num4 != 1)
													{
														while (true)
														{
															IL_02ce:
															byte b = *ptr2;
															while (true)
															{
																IL_02be:
																ptr2++;
																while (true)
																{
																	IL_02ae:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_028e:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_027e:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_0271:
																								if (7 > b)
																								{
																									while (6 >= b)
																									{
																										while (true)
																										{
																											IL_0254:
																											if (6 <= b)
																											{
																												while (true)
																												{
																													IL_0209:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 2;
																													while (true)
																													{
																														IL_01ea:
																														array[num5 - 2] = 0;
																														num = 114;
																														while (true)
																														{
																															if (num != 114)
																															{
																																if (num != 1095)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 2:
																																	goto IL_01ea;
																																case 36:
																																case 42:
																																	goto IL_0209;
																																case 13:
																																	goto IL_0254;
																																case 40:
																																case 98:
																																	goto IL_0261;
																																case 7:
																																	goto IL_0271;
																																case 90:
																																case 96:
																																	goto IL_027e;
																																case 10:
																																	goto IL_028e;
																																case 25:
																																	goto IL_029e;
																																case 18:
																																	goto IL_02ae;
																																case 34:
																																	goto IL_02be;
																																case 37:
																																case 53:
																																	goto IL_02ce;
																																case 31:
																																case 102:
																																	goto IL_02fa;
																																case 62:
																																	goto IL_0313;
																																case 83:
																																	goto IL_0321;
																																case 63:
																																	goto IL_0338;
																																case 65:
																																case 73:
																																	goto IL_034b;
																																case 85:
																																case 95:
																																	goto IL_0356;
																																case 57:
																																	goto IL_0364;
																																case 28:
																																case 39:
																																	goto IL_0372;
																																case 6:
																																	goto IL_038e;
																																case 55:
																																case 99:
																																	goto IL_0399;
																																case 91:
																																	goto IL_03d9;
																																case 70:
																																	goto IL_03ed;
																																case 15:
																																	goto IL_040e;
																																case 72:
																																case 107:
																																	goto IL_0419;
																																case 104:
																																	goto IL_0427;
																																case 22:
																																	goto IL_044a;
																																case 66:
																																	goto IL_045d;
																																case 20:
																																	goto IL_046b;
																																case 71:
																																	goto IL_047e;
																																case 24:
																																case 86:
																																	goto IL_048c;
																																case 74:
																																case 82:
																																	goto IL_049a;
																																case 80:
																																	goto IL_04a5;
																																case 3:
																																case 68:
																																	goto IL_04b3;
																																case 89:
																																	goto IL_04f3;
																																case 38:
																																	goto IL_0507;
																																case 17:
																																	goto IL_0528;
																																case 1:
																																case 92:
																																	goto IL_0536;
																																case 32:
																																	goto IL_055f;
																																case 45:
																																	goto IL_056d;
																																case 43:
																																	goto IL_0589;
																																case 4:
																																case 51:
																																	goto IL_0594;
																																case 103:
																																	goto IL_05d4;
																																case 88:
																																	goto IL_05e8;
																																case 47:
																																	goto IL_05f8;
																																case 94:
																																	goto IL_0603;
																																case 8:
																																case 14:
																																case 16:
																																case 21:
																																case 23:
																																case 41:
																																case 44:
																																case 46:
																																case 49:
																																case 50:
																																case 56:
																																case 58:
																																case 69:
																																case 75:
																																case 77:
																																case 93:
																																case 97:
																																case 100:
																																case 105:
																																	goto end_IL_0254;
																																case 54:
																																	goto IL_0631;
																																case 87:
																																	goto IL_063f;
																																case 60:
																																	goto IL_064d;
																																case 9:
																																case 12:
																																case 27:
																																case 29:
																																case 30:
																																case 35:
																																case 48:
																																case 61:
																																case 64:
																																case 84:
																																case 101:
																																	goto IL_065b;
																																case 76:
																																	goto IL_066e;
																																case 81:
																																	goto IL_0678;
																																case 26:
																																	goto IL_0683;
																																case 19:
																																	goto end_IL_01d7;
																																case 106:
																																	goto end_IL_0698;
																																case 33:
																																case 67:
																																	goto end_IL_06ad;
																																case 0:
																																	goto end_IL_06bd;
																																case 52:
																																case 59:
																																	goto end_IL_06d6;
																																case 78:
																																	goto end_IL_06e6;
																																case 79:
																																	goto end_IL_06f6;
																																case 5:
																																case 11:
																																	goto IL_0711;
																																}
																																continue;
																															}
																															num5--;
																															goto IL_065b;
																															continue;
																															end_IL_01d7:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02ae;
																											}
																											num = 16;
																											break;
																											continue;
																											end_IL_0254:
																											break;
																										}
																										break;
																										IL_0261:;
																									}
																									break;
																								}
																								goto IL_02fa;
																								IL_0338:
																								ptr2 += 8;
																								goto IL_065b;
																								IL_02fa:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0313;
																								IL_0313:
																								array[num5] = 0;
																								goto IL_0321;
																								IL_0321:
																								num5++;
																								num = 63;
																								goto IL_0338;
																							}
																							break;
																						}
																						goto IL_034b;
																						IL_03ed:
																						num5--;
																						goto IL_065b;
																						IL_034b:
																						if (8 < b)
																						{
																							goto IL_0356;
																						}
																						goto IL_038e;
																						IL_0356:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0364;
																						IL_0364:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0372;
																						IL_0372:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto IL_065b;
																						IL_038e:
																						if (8 > b)
																						{
																							num = 8;
																							break;
																						}
																						goto IL_0399;
																						IL_0399:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03d9;
																						IL_03d9:
																						array[num5 - 2] = 0;
																						goto IL_03ed;
																					}
																					break;
																				}
																				goto IL_040e;
																				IL_05f8:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0603;
																				IL_040e:
																				if (5 <= b)
																				{
																					goto IL_0419;
																				}
																				goto IL_047e;
																				IL_0419:
																				array[num5] = 0;
																				goto IL_0427;
																				IL_0427:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_044a;
																				IL_044a:
																				array2[num5] = null;
																				num = 66;
																				goto IL_045d;
																				IL_045d:
																				num5++;
																				goto IL_046b;
																				IL_046b:
																				ptr2 += 8;
																				goto IL_065b;
																				IL_047e:
																				if (2 < b)
																				{
																					goto IL_048c;
																				}
																				goto IL_0589;
																				IL_048c:
																				if (3 < b)
																				{
																					goto IL_049a;
																				}
																				goto IL_0528;
																				IL_049a:
																				if (4 < b)
																				{
																					num = 56;
																					break;
																				}
																				goto IL_04a5;
																				IL_04a5:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_04b3;
																				IL_04b3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f3;
																				IL_04f3:
																				array[num5 - 2] = 0;
																				goto IL_0507;
																				IL_0507:
																				num5--;
																				goto IL_065b;
																				IL_0603:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0528:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0536;
																				IL_0536:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_055f;
																				IL_055f:
																				ptr2 += 8;
																				goto IL_056d;
																				IL_056d:
																				num5--;
																				num = 64;
																				goto IL_065b;
																				IL_0589:
																				if (2 <= b)
																				{
																					goto IL_0594;
																				}
																				goto IL_05f8;
																				IL_0594:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05d4;
																				IL_05d4:
																				array[num5 - 2] = 0;
																				goto IL_05e8;
																				IL_05e8:
																				num5--;
																				goto IL_065b;
																			}
																			break;
																			IL_029e:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0631;
																	IL_064d:
																	ptr2 += 8;
																	goto IL_065b;
																	IL_063f:
																	num5++;
																	goto IL_064d;
																	IL_0631:
																	array[num5] = 0;
																	goto IL_063f;
																	continue;
																	end_IL_02ae:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_0711;
													IL_0711:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									continue;
									end_IL_0698:
									break;
								}
								continue;
								end_IL_06ad:
								break;
							}
							continue;
							end_IL_06bd:
							break;
						}
						continue;
						end_IL_06d6:
						break;
					}
					continue;
					end_IL_06e6:
					break;
				}
				continue;
				end_IL_06f6:
				break;
			}
		}
	}

	private static Transform smethod_8(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rightHandTransform;
	}

	private static double CreateFlagsThrowException(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static RaycastHit SYSWINDoNotIgnoreWhiteSpaces(GTPlayer gtplayer_0)
	{
		return gtplayer_0.lastHitInfoHand;
	}

	private static float StartingFunctorComparer(Vector3 vector3_3, Vector3 vector3_4)
	{
		return Vector3.Distance(vector3_3, vector3_4);
	}

	private unsafe static int smethod_9(int int_1)
	{
		int num = 71;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MoreDataEraseEndOfFile.InstallExecutionEngineException);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0291:
														byte b = *ptr2;
														while (true)
														{
															IL_0278:
															ptr2++;
															num = 2;
															while (true)
															{
																IL_0268:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0248:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0238:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_022b:
																							if (10 >= b)
																							{
																								while (true)
																								{
																									IL_0218:
																									if (10 > b)
																									{
																										num = 122;
																										while (num != 122)
																										{
																											if (num != 1103)
																											{
																												goto end_IL_0268;
																											}
																											switch (num)
																											{
																											case 97:
																												goto IL_0218;
																											case 37:
																											case 86:
																												goto IL_022b;
																											case 42:
																											case 106:
																												goto IL_0238;
																											case 7:
																												goto IL_0248;
																											case 27:
																												goto IL_0258;
																											case 2:
																												goto IL_0268;
																											case 4:
																												goto IL_0278;
																											case 50:
																											case 61:
																												goto IL_0291;
																											case 6:
																											case 35:
																												goto IL_029c;
																											case 19:
																												goto IL_02a7;
																											case 11:
																											case 45:
																												goto IL_02c8;
																											case 57:
																												goto IL_02e4;
																											case 59:
																												goto IL_02f2;
																											case 18:
																											case 73:
																												goto IL_0300;
																											case 84:
																												goto IL_030e;
																											case 72:
																											case 79:
																												goto IL_031c;
																											case 107:
																												goto IL_0348;
																											case 104:
																												goto IL_0356;
																											case 48:
																												goto IL_036d;
																											case 5:
																												goto IL_0389;
																											case 28:
																											case 87:
																												goto IL_0397;
																											case 0:
																												goto IL_03d7;
																											case 15:
																												goto IL_03eb;
																											case 89:
																											case 115:
																												goto IL_0407;
																											case 31:
																												goto IL_0469;
																											case 85:
																												goto IL_047c;
																											case 82:
																												goto IL_048a;
																											case 68:
																												goto IL_0498;
																											case 41:
																												goto IL_04a6;
																											case 113:
																												goto IL_04b4;
																											case 54:
																											case 101:
																												goto IL_04c2;
																											case 33:
																												goto IL_04d0;
																											case 99:
																												goto IL_04f3;
																											case 21:
																												goto IL_04fd;
																											case 49:
																												goto IL_050b;
																											case 96:
																												goto IL_0527;
																											case 60:
																												goto IL_053a;
																											case 1:
																											case 39:
																												goto IL_0545;
																											case 25:
																												goto IL_055d;
																											case 108:
																											case 110:
																												goto IL_0568;
																											case 13:
																												goto IL_0576;
																											case 78:
																											case 112:
																												goto IL_0584;
																											case 16:
																												goto IL_05ad;
																											case 55:
																												goto IL_05bb;
																											case 9:
																												goto IL_05ce;
																											case 22:
																											case 63:
																												goto IL_05dc;
																											case 52:
																												goto IL_05f5;
																											case 17:
																												goto IL_0603;
																											case 91:
																												goto IL_0611;
																											case 67:
																											case 81:
																												goto IL_062d;
																											case 14:
																												goto IL_066d;
																											case 36:
																												goto IL_0681;
																											case 8:
																											case 10:
																											case 23:
																											case 26:
																											case 34:
																											case 44:
																											case 47:
																											case 51:
																											case 58:
																											case 62:
																											case 66:
																											case 75:
																											case 90:
																											case 92:
																											case 93:
																											case 95:
																											case 100:
																											case 102:
																											case 103:
																											case 105:
																											case 109:
																											case 114:
																												goto end_IL_0205;
																											case 3:
																											case 29:
																											case 30:
																											case 40:
																											case 46:
																											case 53:
																											case 56:
																											case 64:
																											case 65:
																											case 74:
																											case 76:
																											case 94:
																											case 98:
																											case 111:
																												goto end_IL_0268;
																											case 12:
																												goto end_IL_06a4;
																											case 43:
																												goto end_IL_06b7;
																											case 80:
																												goto end_IL_06c1;
																											case 32:
																												goto end_IL_06cc;
																											case 20:
																											case 69:
																												goto end_IL_06e1;
																											case 38:
																												goto end_IL_06f1;
																											case 24:
																											case 77:
																												goto end_IL_0701;
																											case 70:
																												goto end_IL_0711;
																											case 71:
																												goto end_IL_0721;
																											case 83:
																											case 88:
																												goto IL_073c;
																											}
																											continue;
																											end_IL_0205:
																											break;
																										}
																										break;
																									}
																									goto IL_02c8;
																									IL_02c8:
																									byte* num5 = ptr2;
																									num4 = 1;
																									ptr2 = num5 + -200;
																									goto end_IL_0268;
																								}
																								break;
																							}
																							goto IL_029c;
																							IL_02a7:
																							if (11 <= b)
																							{
																							}
																							break;
																							IL_029c:
																							if (11 < b)
																							{
																								num = 114;
																								break;
																							}
																							goto IL_02a7;
																						}
																						break;
																					}
																					goto IL_02e4;
																					IL_0469:
																					num6 -= 2;
																					goto end_IL_0268;
																					IL_02e4:
																					if (9 > b)
																					{
																						goto IL_02f2;
																					}
																					goto IL_0407;
																					IL_02f2:
																					if (7 < b)
																					{
																						goto IL_0300;
																					}
																					goto IL_0389;
																					IL_0300:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_030e;
																					IL_030e:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_031c;
																					IL_031c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					num = 107;
																					goto IL_0348;
																					IL_0348:
																					array[num6] = 0;
																					goto IL_0356;
																					IL_0356:
																					num6++;
																					num = 48;
																					goto IL_036d;
																					IL_036d:
																					ptr2 += 8;
																					num = 94;
																					goto end_IL_0268;
																					IL_0389:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0397;
																					IL_0397:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_03d7;
																					IL_03d7:
																					array[num6 - 2] = 0;
																					goto IL_03eb;
																					IL_03eb:
																					num6--;
																					num = 46;
																					goto end_IL_0268;
																					IL_0407:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0469;
																				}
																				break;
																			}
																			goto IL_047c;
																			IL_066d:
																			array[num6 - 2] = 0;
																			goto IL_0681;
																			IL_047c:
																			if (6 > b)
																			{
																				goto IL_048a;
																			}
																			num = 67;
																			goto IL_062d;
																			IL_048a:
																			if (3 < b)
																			{
																				goto IL_0498;
																			}
																			goto IL_053a;
																			IL_0498:
																			if (4 < b)
																			{
																				goto IL_04a6;
																			}
																			goto IL_0527;
																			IL_04a6:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_04b4;
																			IL_04b4:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_04c2;
																			IL_04c2:
																			array[num6] = 0;
																			goto IL_04d0;
																			IL_04d0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04f3;
																			IL_04f3:
																			array2[num6] = null;
																			goto IL_04fd;
																			IL_04fd:
																			num6++;
																			goto IL_050b;
																			IL_050b:
																			ptr2 += 8;
																			num = 40;
																			goto end_IL_0268;
																			IL_0527:
																			if (4 <= b)
																			{
																				goto end_IL_0268;
																			}
																			break;
																			IL_053a:
																			if (3 <= b)
																			{
																				goto IL_0545;
																			}
																			goto IL_055d;
																			IL_0545:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0268;
																			IL_055d:
																			if (1 < b)
																			{
																				goto IL_0568;
																			}
																			goto IL_05ce;
																			IL_0568:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0576;
																			IL_0576:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0584;
																			IL_0584:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_05ad;
																			IL_05ad:
																			ptr2 += 8;
																			goto IL_05bb;
																			IL_05bb:
																			num6--;
																			goto end_IL_0268;
																			IL_05ce:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_05dc;
																			IL_05dc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_05f5;
																			IL_05f5:
																			array[num6] = 0;
																			goto IL_0603;
																			IL_0603:
																			num6++;
																			goto IL_0611;
																			IL_0611:
																			ptr2 += 8;
																			goto end_IL_0268;
																			IL_0681:
																			num6--;
																			goto end_IL_0268;
																			IL_062d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_066d;
																		}
																		break;
																		IL_0258:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0268:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_073c;
												IL_073c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_06a4:
												break;
											}
											continue;
											end_IL_06b7:
											break;
										}
										continue;
										end_IL_06c1:
										break;
									}
									continue;
									end_IL_06cc:
									break;
								}
								continue;
								end_IL_06e1:
								break;
							}
							continue;
							end_IL_06f1:
							break;
						}
						continue;
						end_IL_0701:
						break;
					}
					continue;
					end_IL_0711:
					break;
				}
				continue;
				end_IL_0721:
				break;
			}
		}
	}

	private static double NativeExceptionMethodReturnMessageWrapper(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static Vector3 getMachineKeyStoreValuesAndNames()
	{
		return Vector3.zero;
	}

	private static void getOriginalStringCreateObjRef(Rigidbody rigidbody_0, bool bool_1)
	{
		rigidbody_0.useGravity = bool_1;
	}

	private static GorillaTagger LocalBuilderMonthSpace()
	{
		return GorillaTagger.Instance;
	}

	private static int getCurrentSizeoffset(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static Vector3 smethod_10(ref RaycastHit raycastHit_0)
	{
		return raycastHit_0.normal;
	}

	private void OnDisable()
	{
		getFaultCodeGetDayOfWeek(this);
	}

	private static double smethod_11(double double_1)
	{
		return Math.Log(double_1);
	}

	private static void UnmanagedBitSetAudit(Rigidbody rigidbody_0, Vector3 vector3_3, ForceMode forceMode_0)
	{
		rigidbody_0.AddForce(vector3_3, forceMode_0);
	}

	private static Vector3 SetPermissionsetNoPrompt(ref RaycastHit raycastHit_0)
	{
		return raycastHit_0.point;
	}

	private static double PrintScreenGetDirectoryRoot(double double_1)
	{
		return Math.Cos(double_1);
	}

	private static Vector3 RegisterWithHostAssemblyBuilder(Class192 class192_1)
	{
		return class192_1.vector3_1;
	}

	private static GameObject getOriginalStringProvidedSecurityInfo(PrimitiveType primitiveType_0)
	{
		return GameObject.CreatePrimitive(primitiveType_0);
	}

	private static Vector3 getIsCancellationRequestedLongList(Vector3 vector3_3, Vector3 vector3_4)
	{
		return vector3_3 + vector3_4;
	}

	private unsafe static int smethod_13(int int_1)
	{
		int num = 58;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 105;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DefinitionToTextBuffergetIsLiteral.IsBackgroundaddTracingStatusChanged);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 22;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_027e:
														byte b = *ptr2;
														while (true)
														{
															IL_026e:
															ptr2++;
															while (true)
															{
																IL_025e:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0241:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0234:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0224:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0214:
																									if (3 <= b)
																									{
																										while (true)
																										{
																											IL_01f6:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											num = 117;
																											while (num != 117)
																											{
																												if (num != 1098)
																												{
																													goto IL_04bf;
																												}
																												switch (num)
																												{
																												case 17:
																												case 65:
																													goto IL_01f6;
																												case 101:
																													goto IL_0214;
																												case 60:
																													goto IL_0224;
																												case 41:
																													goto IL_0234;
																												case 43:
																													goto IL_0241;
																												case 78:
																													goto IL_024e;
																												case 97:
																													goto IL_025e;
																												case 40:
																													goto IL_026e;
																												case 26:
																												case 47:
																													goto IL_027e;
																												case 2:
																												case 32:
																													goto IL_0289;
																												case 24:
																												case 62:
																													goto IL_0299;
																												case 85:
																													goto IL_02de;
																												case 35:
																												case 66:
																													goto IL_02e9;
																												case 53:
																													goto IL_034d;
																												case 8:
																												case 48:
																													goto IL_0358;
																												case 16:
																													goto IL_0366;
																												case 54:
																												case 55:
																													goto IL_0374;
																												case 31:
																													goto IL_0397;
																												case 5:
																													goto IL_03aa;
																												case 86:
																													goto IL_03ba;
																												case 87:
																													goto IL_03cd;
																												case 70:
																													goto IL_03d8;
																												case 64:
																												case 80:
																													goto IL_03e6;
																												case 88:
																													goto IL_0402;
																												case 69:
																													goto IL_0410;
																												case 3:
																												case 96:
																													goto IL_0423;
																												case 50:
																													goto IL_0463;
																												case 42:
																													goto IL_0477;
																												case 99:
																													goto IL_048a;
																												case 23:
																													goto IL_049e;
																												case 108:
																													goto IL_04b1;
																												case 36:
																													goto IL_04bf;
																												case 102:
																													goto IL_04d2;
																												case 0:
																												case 76:
																													goto IL_04dd;
																												case 37:
																													goto IL_04eb;
																												case 71:
																												case 110:
																													goto IL_04f9;
																												case 52:
																													goto IL_052b;
																												case 20:
																													goto IL_0539;
																												case 10:
																													goto IL_054c;
																												case 9:
																												case 30:
																													goto IL_055a;
																												case 109:
																													goto IL_0573;
																												case 49:
																													goto IL_0581;
																												case 13:
																													goto IL_058f;
																												case 29:
																													goto IL_05a2;
																												case 25:
																													goto IL_05ad;
																												case 103:
																													goto IL_05b8;
																												case 34:
																												case 79:
																													goto IL_05c3;
																												case 61:
																													goto IL_05d1;
																												case 6:
																													goto IL_05f4;
																												case 28:
																													goto IL_05fe;
																												case 44:
																													goto IL_060c;
																												case 74:
																													goto IL_061c;
																												case 7:
																												case 11:
																												case 14:
																												case 15:
																												case 19:
																												case 38:
																												case 45:
																												case 46:
																												case 51:
																												case 59:
																												case 63:
																												case 68:
																												case 82:
																												case 83:
																												case 89:
																												case 91:
																												case 93:
																												case 94:
																												case 98:
																												case 106:
																													goto end_IL_024e;
																												case 4:
																												case 18:
																												case 21:
																												case 22:
																												case 27:
																												case 56:
																												case 75:
																												case 81:
																												case 90:
																												case 92:
																												case 95:
																												case 104:
																												case 107:
																													goto end_IL_01e3;
																												case 67:
																													goto end_IL_0643;
																												case 12:
																													goto end_IL_0656;
																												case 105:
																													goto end_IL_0669;
																												case 77:
																													goto end_IL_0674;
																												case 33:
																												case 39:
																													goto end_IL_0689;
																												case 100:
																													goto end_IL_06a2;
																												case 1:
																												case 73:
																													goto end_IL_06b2;
																												case 57:
																													goto end_IL_06c2;
																												case 58:
																													goto end_IL_06d2;
																												case 72:
																												case 84:
																													goto IL_06ed;
																												}
																												continue;
																												end_IL_01e3:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_04d2;
																									IL_058f:
																									ptr2 += 8;
																									break;
																									IL_04d2:
																									if (1 < b)
																									{
																										goto IL_04dd;
																									}
																									goto IL_054c;
																									IL_04dd:
																									if (2 < b)
																									{
																										goto end_IL_024e;
																									}
																									goto IL_04eb;
																									IL_04eb:
																									if (2 > b)
																									{
																										goto end_IL_024e;
																									}
																									goto IL_04f9;
																									IL_04f9:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 52;
																									goto IL_052b;
																									IL_052b:
																									ptr2 += 8;
																									goto IL_0539;
																									IL_0539:
																									num5--;
																									break;
																									IL_054c:
																									if (1 > b)
																									{
																										goto end_IL_024e;
																									}
																									goto IL_055a;
																									IL_055a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0573;
																									IL_0573:
																									array[num5] = 0;
																									goto IL_0581;
																									IL_0581:
																									num5++;
																									goto IL_058f;
																								}
																								break;
																							}
																							goto IL_05a2;
																							IL_061c:
																							if (4 <= b)
																							{
																								break;
																							}
																							goto end_IL_024e;
																							IL_05a2:
																							if (4 < b)
																							{
																								goto IL_05ad;
																							}
																							goto IL_061c;
																							IL_05ad:
																							if (5 < b)
																							{
																								goto end_IL_024e;
																							}
																							goto IL_05b8;
																							IL_05b8:
																							if (5 > b)
																							{
																								goto end_IL_024e;
																							}
																							goto IL_05c3;
																							IL_05c3:
																							array[num5] = 0;
																							goto IL_05d1;
																							IL_05d1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05f4;
																							IL_05f4:
																							array2[num5] = null;
																							goto IL_05fe;
																							IL_05fe:
																							num5++;
																							goto IL_060c;
																							IL_060c:
																							ptr2 += 8;
																							break;
																						}
																						break;
																					}
																					goto IL_0299;
																					IL_049e:
																					num5--;
																					break;
																					IL_0299:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_048a;
																					IL_048a:
																					array[num5 - 2] = 0;
																					goto IL_049e;
																				}
																				break;
																			}
																			goto IL_0289;
																			IL_0410:
																			if (11 > b)
																			{
																			}
																			goto end_IL_024e;
																			IL_0289:
																			if (9 >= b)
																			{
																				goto IL_02de;
																			}
																			goto IL_03cd;
																			IL_02de:
																			if (9 <= b)
																			{
																				goto IL_02e9;
																			}
																			goto IL_034d;
																			IL_02e9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03ba;
																			IL_03ba:
																			num5 -= 2;
																			break;
																			IL_034d:
																			if (7 < b)
																			{
																				goto IL_0358;
																			}
																			goto IL_03aa;
																			IL_0358:
																			if (8 < b)
																			{
																				goto end_IL_024e;
																			}
																			goto IL_0366;
																			IL_0366:
																			if (8 > b)
																			{
																				goto end_IL_024e;
																			}
																			goto IL_0374;
																			IL_0374:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0397;
																			IL_0397:
																			array[num5] = 0;
																			goto IL_04b1;
																			IL_04b1:
																			num5++;
																			goto IL_04bf;
																			IL_04bf:
																			ptr2 += 8;
																			break;
																			IL_03aa:
																			if (7 > b)
																			{
																				goto end_IL_024e;
																			}
																			goto IL_0423;
																			IL_0423:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0463;
																			IL_0463:
																			array[num5 - 2] = 0;
																			goto IL_0477;
																			IL_0477:
																			num5--;
																			break;
																			IL_03cd:
																			if (10 >= b)
																			{
																				goto IL_03d8;
																			}
																			goto IL_0402;
																			IL_03d8:
																			if (10 > b)
																			{
																				goto end_IL_024e;
																			}
																			goto IL_03e6;
																			IL_03e6:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0402:
																			if (11 < b)
																			{
																				goto end_IL_024e;
																			}
																			goto IL_0410;
																		}
																		goto end_IL_025e;
																		continue;
																		end_IL_024e:
																		break;
																		IL_024e:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 95;
																break;
																continue;
																end_IL_025e:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06ed;
												IL_06ed:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0643:
												break;
											}
											continue;
											end_IL_0656:
											break;
										}
										continue;
										end_IL_0669:
										break;
									}
									continue;
									end_IL_0674:
									break;
								}
								continue;
								end_IL_0689:
								break;
							}
							continue;
							end_IL_06a2:
							break;
						}
						continue;
						end_IL_06b2:
						break;
					}
					continue;
					end_IL_06c2:
					break;
				}
				continue;
				end_IL_06d2:
				break;
			}
		}
	}

	private static void getFaultCodeGetDayOfWeek(Class192 class192_1)
	{
		class192_1.method_1();
	}
}
