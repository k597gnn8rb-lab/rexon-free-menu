using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Anti Report Visualizer", "Safety", "Shows report button range.", false, 4, ModType.const_0, false)]
internal class Class150 : MonoBehaviour
{
	private static float float_0;

	private static double double_0;

	private static float float_1;

	private static float float_2;

	private static float float_3;

	private static int int_0;

	private static IntPtr[] CFDefaultCollelem;

	private static IntPtr[] ForkJoinOperationTypeMetadataSectionUsagePatterns;

	private static IntPtr[] GetCountSafeDescriptionMetadataPublisher;

	private static IntPtr[] MixedMemberInfo;

	private unsafe void OnEnable()
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 48;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[6];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HasClaimsgetLoaderOptimization.getParamNamesDeleteTimer);
										num = 23;
										while (true)
										{
											byte* ptr2 = ptr;
											num = 127;
											while (true)
											{
												if (num4 == 1)
												{
													return;
												}
												while (true)
												{
													IL_0341:
													byte b = *ptr2;
													while (true)
													{
														IL_0331:
														ptr2++;
														while (true)
														{
															IL_0321:
															if (b >= 1)
															{
																while (b <= 13)
																{
																	while (true)
																	{
																		IL_0301:
																		if (7 < b)
																		{
																			while (true)
																			{
																				IL_02f1:
																				if (10 >= b)
																				{
																					while (true)
																					{
																						IL_02e4:
																						if (10 > b)
																						{
																							while (true)
																							{
																								IL_02d7:
																								if (8 < b)
																								{
																									while (9 >= b)
																									{
																										while (9 <= b)
																										{
																											while (true)
																											{
																												IL_0275:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_025f:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_0246:
																														num5--;
																														num = 137;
																														while (num != 137)
																														{
																															if (num != 1118)
																															{
																																goto end_IL_02b7;
																															}
																															switch (num)
																															{
																															case 55:
																																goto IL_0246;
																															case 96:
																																goto IL_025f;
																															case 29:
																															case 128:
																																goto IL_0275;
																															case 53:
																																goto IL_02b7;
																															case 59:
																																goto IL_02c7;
																															case 62:
																																goto IL_02d7;
																															case 75:
																																goto IL_02e4;
																															case 4:
																																goto IL_02f1;
																															case 19:
																																goto IL_0301;
																															case 39:
																																goto IL_0311;
																															case 37:
																																goto IL_0321;
																															case 126:
																																goto IL_0331;
																															case 45:
																															case 106:
																																goto IL_0341;
																															case 125:
																																goto IL_034c;
																															case 43:
																															case 122:
																																goto IL_035a;
																															case 63:
																															case 113:
																																goto IL_036d;
																															case 56:
																																goto IL_03cf;
																															case 105:
																																goto IL_03e2;
																															case 15:
																																goto IL_03ed;
																															case 118:
																																goto IL_03f8;
																															case 120:
																																goto IL_0406;
																															case 2:
																															case 60:
																																goto IL_0419;
																															case 91:
																																goto IL_0433;
																															case 85:
																																goto IL_044f;
																															case 71:
																																goto IL_045d;
																															case 25:
																															case 40:
																																goto IL_046b;
																															case 27:
																																goto IL_0487;
																															case 38:
																															case 130:
																																goto IL_0495;
																															case 51:
																															case 104:
																																goto IL_04a3;
																															case 54:
																																goto IL_04b1;
																															case 47:
																															case 117:
																																goto IL_04bc;
																															case 65:
																																goto IL_04ca;
																															case 100:
																															case 109:
																																goto IL_04d8;
																															case 76:
																																goto IL_04e6;
																															case 32:
																																goto IL_0509;
																															case 102:
																																goto IL_0513;
																															case 66:
																																goto IL_0521;
																															case 79:
																															case 116:
																																goto IL_0534;
																															case 30:
																																goto IL_057d;
																															case 129:
																																goto IL_0591;
																															case 112:
																																goto IL_05a4;
																															case 6:
																																goto IL_05b2;
																															case 88:
																															case 110:
																																goto IL_05c9;
																															case 42:
																																goto IL_0609;
																															case 57:
																																goto IL_061d;
																															case 33:
																																goto IL_0630;
																															case 90:
																															case 98:
																																goto IL_063e;
																															case 10:
																																goto IL_064c;
																															case 61:
																																goto IL_065a;
																															case 73:
																															case 115:
																																goto IL_0668;
																															case 70:
																																goto IL_06a8;
																															case 50:
																																goto IL_06bc;
																															case 46:
																																goto IL_06d8;
																															case 14:
																															case 123:
																																goto IL_06eb;
																															case 21:
																																goto IL_0714;
																															case 1:
																																goto IL_0722;
																															case 58:
																															case 84:
																																goto IL_0735;
																															case 82:
																																goto IL_077e;
																															case 35:
																																goto IL_0792;
																															case 3:
																															case 5:
																															case 8:
																															case 12:
																															case 13:
																															case 20:
																															case 24:
																															case 41:
																															case 44:
																															case 49:
																															case 72:
																															case 77:
																															case 81:
																															case 83:
																															case 86:
																															case 87:
																															case 89:
																															case 92:
																															case 93:
																															case 95:
																															case 99:
																															case 101:
																															case 107:
																															case 108:
																															case 114:
																															case 121:
																																goto end_IL_02b7;
																															case 52:
																																goto IL_07c4;
																															case 0:
																																goto IL_07d2;
																															case 28:
																																goto IL_07e0;
																															case 7:
																															case 9:
																															case 11:
																															case 31:
																															case 34:
																															case 36:
																															case 74:
																															case 78:
																															case 80:
																															case 97:
																															case 103:
																															case 111:
																															case 119:
																															case 124:
																															case 127:
																																goto end_IL_0233;
																															case 23:
																																goto end_IL_07ee;
																															case 26:
																																goto end_IL_0801;
																															case 67:
																																goto end_IL_0814;
																															case 22:
																															case 69:
																																goto end_IL_0828;
																															case 16:
																																goto end_IL_0838;
																															case 48:
																																goto end_IL_0848;
																															case 68:
																																goto end_IL_0858;
																															case 17:
																																goto end_IL_0868;
																															case 18:
																																goto end_IL_0873;
																															case 64:
																															case 94:
																																return;
																															}
																															continue;
																															end_IL_0233:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_0321;
																											continue;
																											end_IL_02b7:
																											break;
																											IL_02b7:;
																										}
																										break;
																										IL_02c7:;
																									}
																									break;
																								}
																								goto IL_034c;
																								IL_035a:
																								num5--;
																								goto end_IL_0321;
																								IL_034c:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_035a;
																							}
																							break;
																						}
																						goto IL_036d;
																						IL_03cf:
																						num5 -= 2;
																						goto end_IL_0321;
																						IL_036d:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_03cf;
																					}
																					break;
																				}
																				goto IL_03e2;
																				IL_046b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0321;
																				IL_03e2:
																				if (12 >= b)
																				{
																					goto IL_03ed;
																				}
																				goto IL_044f;
																				IL_03ed:
																				if (12 > b)
																				{
																					goto IL_03f8;
																				}
																				goto IL_0419;
																				IL_03f8:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0406;
																				IL_0406:
																				if (11 <= b)
																				{
																					goto end_IL_0321;
																				}
																				break;
																				IL_0419:
																				Class147.bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																				goto IL_0433;
																				IL_0433:
																				num5--;
																				num = 80;
																				goto end_IL_0321;
																				IL_044f:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_045d;
																				IL_045d:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_046b;
																			}
																			break;
																		}
																		goto IL_0487;
																		IL_0735:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		num = 82;
																		goto IL_077e;
																		IL_0487:
																		if (7 > b)
																		{
																			goto IL_0495;
																		}
																		goto IL_0735;
																		IL_0495:
																		if (3 < b)
																		{
																			goto IL_04a3;
																		}
																		goto IL_0630;
																		IL_04a3:
																		if (5 >= b)
																		{
																			goto IL_04b1;
																		}
																		goto IL_05a4;
																		IL_04b1:
																		if (5 > b)
																		{
																			goto IL_04bc;
																		}
																		goto IL_0534;
																		IL_04bc:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_04ca;
																		IL_04ca:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_04d8;
																		IL_04d8:
																		array[num5] = 0;
																		goto IL_04e6;
																		IL_04e6:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0509;
																		IL_0509:
																		array2[num5] = null;
																		goto IL_0513;
																		IL_0513:
																		num5++;
																		goto IL_0521;
																		IL_0521:
																		ptr2 += 8;
																		goto end_IL_0321;
																		IL_0534:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		num = 30;
																		goto IL_057d;
																		IL_057d:
																		array[num5 - 2] = 0;
																		goto IL_0591;
																		IL_0591:
																		num5--;
																		goto end_IL_0321;
																		IL_05a4:
																		if (6 < b)
																		{
																			break;
																		}
																		goto IL_05b2;
																		IL_05b2:
																		if (6 > b)
																		{
																			break;
																		}
																		num = 88;
																		goto IL_05c9;
																		IL_077e:
																		array[num5 - 2] = 0;
																		goto IL_0792;
																		IL_05c9:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0609;
																		IL_0609:
																		array[num5 - 2] = 0;
																		goto IL_061d;
																		IL_061d:
																		num5--;
																		goto end_IL_0321;
																		IL_0630:
																		if (3 > b)
																		{
																			goto IL_063e;
																		}
																		goto IL_06eb;
																		IL_063e:
																		if (1 < b)
																		{
																			goto IL_064c;
																		}
																		num = 46;
																		goto IL_06d8;
																		IL_064c:
																		if (2 < b)
																		{
																			break;
																		}
																		goto IL_065a;
																		IL_065a:
																		if (2 > b)
																		{
																			break;
																		}
																		goto IL_0668;
																		IL_0668:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_06a8;
																		IL_06a8:
																		array[num5 - 2] = 0;
																		goto IL_06bc;
																		IL_06bc:
																		num5--;
																		goto end_IL_0321;
																		IL_0792:
																		num5--;
																		num = 9;
																		goto end_IL_0321;
																		IL_06d8:
																		if (1 <= b)
																		{
																		}
																		break;
																		IL_06eb:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0714;
																		IL_0714:
																		ptr2 += 8;
																		goto IL_0722;
																		IL_0722:
																		num5--;
																		goto end_IL_0321;
																	}
																	break;
																	IL_0311:;
																}
															}
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_07c4;
															IL_07e0:
															ptr2 += 8;
															break;
															IL_07d2:
															num5++;
															goto IL_07e0;
															IL_07c4:
															array[num5] = 0;
															goto IL_07d2;
															continue;
															end_IL_0321:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_07ee:
												break;
											}
											continue;
											end_IL_0801:
											break;
										}
										continue;
										end_IL_0814:
										break;
									}
									continue;
									end_IL_0828:
									break;
								}
								continue;
								end_IL_0838:
								break;
							}
							continue;
							end_IL_0848:
							break;
						}
						continue;
						end_IL_0858:
						break;
					}
					continue;
					end_IL_0868:
					break;
				}
				continue;
				end_IL_0873:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 3;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetSymAttributegetArray.EnumUIntTypeInfoPrefixCode);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											num = 84;
											while (true)
											{
												if (num4 == 1)
												{
													return;
												}
												while (true)
												{
													IL_0319:
													byte b = *ptr2;
													while (true)
													{
														IL_0309:
														ptr2++;
														while (true)
														{
															IL_02f9:
															if (b >= 1)
															{
																while (b <= 14)
																{
																	while (true)
																	{
																		IL_02d9:
																		if (7 < b)
																		{
																			while (true)
																			{
																				IL_02cc:
																				if (11 < b)
																				{
																					while (true)
																					{
																						IL_02bc:
																						if (13 < b)
																						{
																							while (14 >= b)
																							{
																								while (14 <= b)
																								{
																									while (true)
																									{
																										IL_027a:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										num = 150;
																										while (num != 150)
																										{
																											if (num != 1131)
																											{
																												goto IL_0810;
																											}
																											switch (num)
																											{
																											case 51:
																											case 89:
																												goto IL_027a;
																											case 27:
																												goto IL_029c;
																											case 54:
																											case 88:
																												goto IL_02ac;
																											case 64:
																												goto IL_02bc;
																											case 4:
																											case 46:
																												goto IL_02cc;
																											case 61:
																												goto IL_02d9;
																											case 129:
																												goto IL_02e9;
																											case 28:
																												goto IL_02f9;
																											case 134:
																												goto IL_0309;
																											case 1:
																											case 138:
																												goto IL_0319;
																											case 95:
																												goto IL_0324;
																											case 56:
																											case 83:
																												goto IL_032f;
																											case 76:
																												goto IL_0343;
																											case 10:
																											case 72:
																												goto IL_03a5;
																											case 82:
																												goto IL_03b3;
																											case 38:
																											case 43:
																												goto IL_03c7;
																											case 87:
																											case 124:
																												goto IL_03da;
																											case 26:
																												goto IL_041a;
																											case 15:
																												goto IL_042e;
																											case 130:
																												goto IL_0441;
																											case 78:
																												goto IL_044f;
																											case 135:
																												goto IL_0462;
																											case 70:
																											case 128:
																												goto IL_0470;
																											case 141:
																												goto IL_048c;
																											case 31:
																												goto IL_049a;
																											case 12:
																											case 114:
																												goto IL_04a8;
																											case 6:
																												goto IL_050a;
																											case 5:
																												goto IL_051d;
																											case 67:
																											case 111:
																												goto IL_0528;
																											case 106:
																												goto IL_0536;
																											case 32:
																											case 133:
																												goto IL_0552;
																											case 35:
																												goto IL_056c;
																											case 37:
																												goto IL_057f;
																											case 101:
																											case 104:
																												goto IL_058a;
																											case 65:
																												goto IL_05ca;
																											case 18:
																												goto IL_05de;
																											case 93:
																												goto IL_05f1;
																											case 52:
																												goto IL_05ff;
																											case 42:
																											case 71:
																												goto IL_060a;
																											case 11:
																												goto IL_0633;
																											case 107:
																												goto IL_0641;
																											case 25:
																												goto IL_0654;
																											case 44:
																												goto IL_0662;
																											case 91:
																												goto IL_066d;
																											case 53:
																											case 69:
																												goto IL_067b;
																											case 125:
																												goto IL_06bb;
																											case 0:
																												goto IL_06cf;
																											case 103:
																												goto IL_06f0;
																											case 39:
																												goto IL_0703;
																											case 79:
																												goto IL_0711;
																											case 16:
																												goto IL_071f;
																											case 50:
																												goto IL_072d;
																											case 41:
																											case 100:
																												goto IL_073b;
																											case 58:
																												goto IL_0749;
																											case 48:
																												goto IL_0775;
																											case 117:
																												goto IL_077f;
																											case 132:
																												goto IL_078d;
																											case 30:
																											case 122:
																												goto IL_07a0;
																											case 140:
																												goto IL_07e0;
																											case 47:
																												goto IL_07f4;
																											case 34:
																											case 63:
																												goto IL_0810;
																											case 108:
																												goto IL_081b;
																											case 20:
																											case 127:
																												goto IL_0826;
																											case 139:
																												goto IL_0866;
																											case 116:
																												goto IL_087a;
																											case 7:
																											case 8:
																											case 17:
																											case 19:
																											case 22:
																											case 33:
																											case 36:
																											case 45:
																											case 57:
																											case 66:
																											case 68:
																											case 75:
																											case 77:
																											case 80:
																											case 86:
																											case 90:
																											case 92:
																											case 94:
																											case 97:
																											case 102:
																											case 112:
																											case 115:
																											case 118:
																											case 119:
																											case 120:
																											case 131:
																											case 136:
																											case 137:
																											case 143:
																												goto end_IL_029c;
																											case 60:
																												goto IL_08a3;
																											case 74:
																												goto IL_08b1;
																											case 121:
																												goto IL_08bf;
																											case 14:
																											case 21:
																											case 23:
																											case 24:
																											case 29:
																											case 49:
																											case 62:
																											case 73:
																											case 84:
																											case 96:
																											case 98:
																											case 109:
																											case 110:
																											case 123:
																											case 142:
																												goto end_IL_0267;
																											case 40:
																												goto end_IL_08d6;
																											case 59:
																												goto end_IL_08e6;
																											case 13:
																												goto end_IL_08f1;
																											case 99:
																												goto end_IL_08fb;
																											case 9:
																											case 126:
																												goto end_IL_0906;
																											case 113:
																												goto end_IL_0916;
																											case 81:
																											case 85:
																												goto end_IL_0926;
																											case 2:
																												goto end_IL_0936;
																											case 3:
																												goto end_IL_0946;
																											case 55:
																											case 105:
																												return;
																											}
																											continue;
																											end_IL_0267:
																											break;
																										}
																										break;
																									}
																									goto end_IL_02f9;
																									continue;
																									end_IL_029c:
																									break;
																									IL_029c:;
																								}
																								break;
																								IL_02ac:;
																							}
																							break;
																						}
																						goto IL_051d;
																						IL_0552:
																						Class147.bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																						goto IL_056c;
																						IL_051d:
																						if (13 > b)
																						{
																							goto IL_0528;
																						}
																						goto IL_0552;
																						IL_0528:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0536;
																						IL_0536:
																						if (12 <= b)
																						{
																							goto end_IL_02f9;
																						}
																						num = 86;
																						break;
																						IL_056c:
																						num6--;
																						goto end_IL_02f9;
																					}
																					break;
																				}
																				goto IL_0324;
																				IL_049a:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_04a8;
																				IL_0324:
																				if (11 <= b)
																				{
																					goto IL_032f;
																				}
																				num = 10;
																				goto IL_03a5;
																				IL_032f:
																				array[num6 - 2] = 0;
																				goto IL_0343;
																				IL_0343:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)CFDefaultCollelem[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0441;
																				IL_0441:
																				num6--;
																				goto IL_044f;
																				IL_044f:
																				ptr2 += 8;
																				goto end_IL_02f9;
																				IL_04a8:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_050a;
																				IL_03a5:
																				if (9 >= b)
																				{
																					goto IL_03b3;
																				}
																				goto IL_048c;
																				IL_03b3:
																				if (9 > b)
																				{
																					num = 43;
																					goto IL_03c7;
																				}
																				goto IL_03da;
																				IL_050a:
																				num6 -= 2;
																				goto end_IL_02f9;
																				IL_03c7:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0462;
																				IL_0462:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0470;
																				IL_0470:
																				num6--;
																				num = 14;
																				goto end_IL_02f9;
																				IL_03da:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_041a;
																				IL_041a:
																				array[num6 - 2] = 0;
																				goto IL_042e;
																				IL_042e:
																				num6--;
																				goto end_IL_02f9;
																				IL_048c:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_049a;
																			}
																			break;
																		}
																		goto IL_057f;
																		IL_0826:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0866;
																		IL_057f:
																		if (7 <= b)
																		{
																			goto IL_058a;
																		}
																		goto IL_05f1;
																		IL_058a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_05ca;
																		IL_05ca:
																		array[num6 - 2] = 0;
																		goto IL_05de;
																		IL_05de:
																		num6--;
																		goto end_IL_02f9;
																		IL_05f1:
																		if (3 >= b)
																		{
																			goto IL_05ff;
																		}
																		goto IL_0703;
																		IL_05ff:
																		if (3 <= b)
																		{
																			goto IL_060a;
																		}
																		goto IL_0654;
																		IL_060a:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0633;
																		IL_0633:
																		ptr2 += 8;
																		goto IL_0641;
																		IL_0641:
																		num6--;
																		goto end_IL_02f9;
																		IL_0654:
																		if (1 < b)
																		{
																			goto IL_0662;
																		}
																		goto IL_06f0;
																		IL_0662:
																		if (2 < b)
																		{
																			num = 7;
																			break;
																		}
																		goto IL_066d;
																		IL_066d:
																		if (2 > b)
																		{
																			break;
																		}
																		goto IL_067b;
																		IL_067b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_06bb;
																		IL_06bb:
																		array[num6 - 2] = 0;
																		goto IL_06cf;
																		IL_06cf:
																		num6--;
																		goto end_IL_02f9;
																		IL_0866:
																		array[num6 - 2] = 0;
																		goto IL_087a;
																		IL_06f0:
																		if (1 > b)
																		{
																		}
																		break;
																		IL_0703:
																		if (5 >= b)
																		{
																			goto IL_0711;
																		}
																		num = 63;
																		goto IL_0810;
																		IL_0711:
																		if (5 > b)
																		{
																			goto IL_071f;
																		}
																		goto IL_07a0;
																		IL_071f:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_072d;
																		IL_072d:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_073b;
																		IL_073b:
																		array[num6] = 0;
																		goto IL_0749;
																		IL_0749:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		num = 48;
																		goto IL_0775;
																		IL_0775:
																		array2[num6] = null;
																		goto IL_077f;
																		IL_077f:
																		num6++;
																		goto IL_078d;
																		IL_078d:
																		ptr2 += 8;
																		goto end_IL_02f9;
																		IL_07a0:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_07e0;
																		IL_07e0:
																		array[num6 - 2] = 0;
																		goto IL_07f4;
																		IL_07f4:
																		num6--;
																		goto end_IL_02f9;
																		IL_087a:
																		num6--;
																		goto end_IL_02f9;
																		IL_0810:
																		if (6 < b)
																		{
																			break;
																		}
																		goto IL_081b;
																		IL_081b:
																		if (6 > b)
																		{
																			break;
																		}
																		goto IL_0826;
																	}
																	break;
																	IL_02e9:;
																}
															}
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
															goto IL_08a3;
															IL_08bf:
															ptr2 += 8;
															num = 24;
															break;
															IL_08b1:
															num6++;
															goto IL_08bf;
															IL_08a3:
															array[num6] = 0;
															goto IL_08b1;
															continue;
															end_IL_02f9:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_08d6:
												break;
											}
											continue;
											end_IL_08e6:
											break;
										}
										continue;
										end_IL_08f1:
										break;
									}
									continue;
									end_IL_08fb:
									break;
								}
								continue;
								end_IL_0906:
								break;
							}
							continue;
							end_IL_0916:
							break;
						}
						continue;
						end_IL_0926:
						break;
					}
					continue;
					end_IL_0936:
					break;
				}
				continue;
				end_IL_0946:
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		int num = 114;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PopDirectionIsolateWindowsBuiltInRole.AssemblyVersionAttributeTypeCode);
										num = 136;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													IL_0410:
													byte b = *ptr2;
													while (true)
													{
														IL_0400:
														ptr2++;
														while (true)
														{
															IL_03f0:
															if (b >= 1)
															{
																while (b <= 22)
																{
																	while (true)
																	{
																		IL_03d0:
																		if (11 >= b)
																		{
																			while (11 > b)
																			{
																				while (true)
																				{
																					IL_03b0:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_03a0:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_0390:
																									if (2 < b)
																									{
																										while (true)
																										{
																											IL_0380:
																											if (3 < b)
																											{
																												while (4 >= b)
																												{
																													while (4 <= b)
																													{
																														while (true)
																														{
																															IL_0350:
																															array[num6] = 0;
																															while (true)
																															{
																																IL_0322:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																																num = 192;
																																while (true)
																																{
																																	if (num != 192)
																																	{
																																		if (num != 1173)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 53:
																																			goto IL_0322;
																																		case 57:
																																		case 176:
																																			goto IL_0350;
																																		case 171:
																																			goto IL_0360;
																																		case 118:
																																			goto IL_0370;
																																		case 83:
																																			goto IL_0380;
																																		case 140:
																																			goto IL_0390;
																																		case 134:
																																			goto IL_03a0;
																																		case 142:
																																			goto IL_03b0;
																																		case 86:
																																			goto IL_03c0;
																																		case 96:
																																			goto IL_03d0;
																																		case 131:
																																			goto IL_03e0;
																																		case 11:
																																			goto IL_03f0;
																																		case 170:
																																			goto IL_0400;
																																		case 1:
																																		case 163:
																																			goto IL_0410;
																																		case 20:
																																			goto IL_041b;
																																		case 12:
																																		case 55:
																																			goto IL_0429;
																																		case 120:
																																			goto IL_0452;
																																		case 119:
																																			goto IL_0460;
																																		case 154:
																																			goto IL_0473;
																																		case 22:
																																		case 37:
																																			goto IL_047e;
																																		case 10:
																																			goto IL_04be;
																																		case 34:
																																			goto IL_04d2;
																																		case 62:
																																			goto IL_04e5;
																																		case 102:
																																			goto IL_04f3;
																																		case 49:
																																		case 66:
																																			goto IL_0501;
																																		case 157:
																																			goto IL_051a;
																																		case 28:
																																			goto IL_0528;
																																		case 9:
																																			goto IL_0536;
																																		case 110:
																																		case 158:
																																			goto IL_0549;
																																		case 61:
																																			goto IL_0589;
																																		case 18:
																																			goto IL_059d;
																																		case 172:
																																			goto IL_05b0;
																																		case 111:
																																			goto IL_05be;
																																		case 40:
																																		case 43:
																																			goto IL_05c9;
																																		case 25:
																																			goto IL_05dc;
																																		case 93:
																																			goto IL_05ea;
																																		case 5:
																																		case 92:
																																			goto IL_05f8;
																																		case 129:
																																			goto IL_0638;
																																		case 29:
																																			goto IL_064c;
																																		case 155:
																																			goto IL_065f;
																																		case 44:
																																			goto IL_066d;
																																		case 56:
																																			goto IL_067b;
																																		case 42:
																																		case 145:
																																			goto IL_0689;
																																		case 175:
																																			goto IL_06ed;
																																		case 30:
																																		case 181:
																																			goto IL_06fb;
																																		case 123:
																																			goto IL_073b;
																																		case 23:
																																			goto IL_074f;
																																		case 182:
																																			goto IL_0762;
																																		case 185:
																																			goto IL_0775;
																																		case 90:
																																			goto IL_0783;
																																		case 32:
																																		case 106:
																																			goto IL_0791;
																																		case 65:
																																			goto IL_07d1;
																																		case 76:
																																			goto IL_07e5;
																																		case 82:
																																			goto IL_0802;
																																		case 95:
																																			goto IL_0810;
																																		case 13:
																																			goto IL_0823;
																																		case 105:
																																			goto IL_0831;
																																		case 164:
																																		case 167:
																																			goto IL_083c;
																																		case 60:
																																			goto IL_0855;
																																		case 146:
																																			goto IL_0863;
																																		case 27:
																																			goto IL_0871;
																																		case 133:
																																			goto IL_0884;
																																		case 162:
																																			goto IL_0892;
																																		case 70:
																																		case 80:
																																			goto IL_089d;
																																		case 36:
																																			goto IL_08de;
																																		case 78:
																																			goto IL_08f2;
																																		case 63:
																																			goto IL_090e;
																																		case 3:
																																			goto IL_0919;
																																		case 14:
																																		case 69:
																																			goto IL_0927;
																																		case 137:
																																			goto IL_0940;
																																		case 54:
																																			goto IL_094e;
																																		case 59:
																																			goto IL_095c;
																																		case 159:
																																			goto IL_096f;
																																		case 7:
																																			goto IL_097d;
																																		case 2:
																																		case 107:
																																			goto IL_098b;
																																		case 130:
																																			goto IL_09a3;
																																		case 138:
																																			goto IL_09b7;
																																		case 41:
																																		case 89:
																																			goto IL_09c5;
																																		case 85:
																																			goto IL_0a17;
																																		case 160:
																																			goto IL_0a2a;
																																		case 179:
																																			goto IL_0a38;
																																		case 26:
																																		case 51:
																																			goto IL_0a46;
																																		case 45:
																																			goto IL_0a60;
																																		case 127:
																																			goto IL_0a73;
																																		case 46:
																																			goto IL_0a81;
																																		case 72:
																																		case 128:
																																			goto IL_0a8c;
																																		case 67:
																																			goto IL_0aa0;
																																		case 104:
																																			goto IL_0adf;
																																		case 100:
																																			goto IL_0af2;
																																		case 4:
																																			goto IL_0afd;
																																		case 6:
																																		case 98:
																																			goto IL_0b0b;
																																		case 178:
																																			goto IL_0b1f;
																																		case 91:
																																			goto IL_0b5e;
																																		case 112:
																																			goto IL_0b71;
																																		case 73:
																																			goto IL_0b7f;
																																		case 24:
																																		case 149:
																																			goto IL_0b8d;
																																		case 144:
																																			goto IL_0bcd;
																																		case 165:
																																			goto IL_0be1;
																																		case 8:
																																			goto IL_0bf1;
																																		case 177:
																																			goto IL_0bfc;
																																		case 156:
																																		case 169:
																																			goto IL_0c07;
																																		case 38:
																																			goto IL_0c20;
																																		case 58:
																																			goto IL_0c2b;
																																		case 0:
																																		case 31:
																																		case 35:
																																		case 47:
																																		case 48:
																																		case 64:
																																		case 71:
																																		case 79:
																																		case 94:
																																		case 101:
																																		case 108:
																																		case 116:
																																		case 117:
																																		case 122:
																																		case 124:
																																		case 125:
																																		case 135:
																																		case 143:
																																		case 150:
																																		case 151:
																																		case 152:
																																		case 153:
																																		case 161:
																																		case 173:
																																		case 184:
																																			goto end_IL_030f;
																																		case 15:
																																		case 16:
																																		case 19:
																																		case 21:
																																		case 33:
																																		case 50:
																																		case 68:
																																		case 74:
																																		case 75:
																																		case 77:
																																		case 81:
																																		case 84:
																																		case 87:
																																		case 88:
																																		case 97:
																																		case 99:
																																		case 103:
																																		case 109:
																																		case 115:
																																		case 121:
																																		case 132:
																																		case 139:
																																		case 147:
																																		case 174:
																																		case 180:
																																			goto end_IL_03c0;
																																		case 136:
																																			goto end_IL_0c49;
																																		case 17:
																																			goto end_IL_0c5c;
																																		case 52:
																																			goto end_IL_0c66;
																																		case 148:
																																		case 166:
																																			goto end_IL_0c7a;
																																		case 126:
																																			goto end_IL_0c8a;
																																		case 39:
																																			goto end_IL_0c9a;
																																		case 168:
																																			goto end_IL_0caa;
																																		case 113:
																																			goto end_IL_0cba;
																																		case 114:
																																			goto end_IL_0cca;
																																		case 141:
																																		case 183:
																																			return;
																																		}
																																		continue;
																																	}
																																	array2[num6] = null;
																																	goto IL_0802;
																																	IL_0802:
																																	num6++;
																																	goto IL_0810;
																																	IL_0810:
																																	ptr2 += 8;
																																	goto end_IL_03c0;
																																	continue;
																																	end_IL_030f:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																														IL_0360:;
																													}
																													break;
																													IL_0370:;
																												}
																												break;
																											}
																											goto IL_041b;
																											IL_0460:
																											num6--;
																											goto end_IL_03c0;
																											IL_041b:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_0429;
																											IL_0429:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_0452;
																											IL_0452:
																											ptr2 += 8;
																											goto IL_0460;
																										}
																										break;
																									}
																									goto IL_0473;
																									IL_0536:
																									ptr2 += 8;
																									goto end_IL_03c0;
																									IL_0473:
																									if (2 <= b)
																									{
																										goto IL_047e;
																									}
																									goto IL_04e5;
																									IL_047e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_04be;
																									IL_04be:
																									array[num6 - 2] = 0;
																									goto IL_04d2;
																									IL_04d2:
																									num6--;
																									goto end_IL_03c0;
																									IL_04e5:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_04f3;
																									IL_04f3:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_0501;
																									IL_0501:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																									goto IL_051a;
																									IL_051a:
																									array[num6] = 0;
																									goto IL_0528;
																									IL_0528:
																									num6++;
																									goto IL_0536;
																								}
																								break;
																							}
																							goto IL_0549;
																							IL_059d:
																							num6--;
																							goto end_IL_03c0;
																							IL_0549:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0589;
																							IL_0589:
																							array[num6 - 2] = 0;
																							goto IL_059d;
																						}
																						break;
																					}
																					goto IL_05b0;
																					IL_074f:
																					num6--;
																					goto end_IL_03c0;
																					IL_05b0:
																					if (8 >= b)
																					{
																						goto IL_05be;
																					}
																					goto IL_065f;
																					IL_05be:
																					if (8 <= b)
																					{
																						goto IL_05c9;
																					}
																					goto IL_05dc;
																					IL_05c9:
																					num6--;
																					goto end_IL_03c0;
																					IL_05dc:
																					if (6 >= b)
																					{
																						goto IL_05ea;
																					}
																					goto IL_0775;
																					IL_05ea:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_05f8;
																					IL_05f8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0638;
																					IL_0638:
																					array[num6 - 2] = 0;
																					goto IL_064c;
																					IL_064c:
																					num6--;
																					goto end_IL_03c0;
																					IL_0775:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_0783;
																					IL_0783:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0791;
																					IL_0791:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_07d1;
																					IL_07d1:
																					array[num6 - 2] = 0;
																					goto IL_07e5;
																					IL_07e5:
																					num6--;
																					goto end_IL_03c0;
																					IL_065f:
																					if (9 < b)
																					{
																						goto IL_066d;
																					}
																					goto IL_06ed;
																					IL_066d:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_067b;
																					IL_067b:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0689;
																					IL_0689:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0762;
																					IL_0762:
																					num6 -= 2;
																					goto end_IL_03c0;
																					IL_06ed:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_06fb;
																					IL_06fb:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_073b;
																					IL_073b:
																					array[num6 - 2] = 0;
																					goto IL_074f;
																				}
																				goto end_IL_03e0;
																				continue;
																				end_IL_03c0:
																				break;
																				IL_03c0:;
																			}
																			break;
																		}
																		goto IL_0823;
																		IL_0c20:
																		if (22 < b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0c2b;
																		IL_0823:
																		if (17 >= b)
																		{
																			goto IL_0831;
																		}
																		goto IL_0a73;
																		IL_0831:
																		if (17 <= b)
																		{
																			goto IL_083c;
																		}
																		goto IL_0884;
																		IL_083c:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		goto IL_0855;
																		IL_0855:
																		array[num6] = 3;
																		goto IL_0863;
																		IL_0863:
																		num6++;
																		goto IL_0871;
																		IL_0871:
																		ptr2 += 16;
																		break;
																		IL_0884:
																		if (14 >= b)
																		{
																			goto IL_0892;
																		}
																		goto IL_09a3;
																		IL_0892:
																		if (14 <= b)
																		{
																			goto IL_089d;
																		}
																		goto IL_090e;
																		IL_089d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																		goto IL_08de;
																		IL_08de:
																		array[num6 - 2] = 0;
																		goto IL_08f2;
																		IL_08f2:
																		num6--;
																		num = 16;
																		break;
																		IL_090e:
																		if (12 >= b)
																		{
																			goto IL_0919;
																		}
																		goto IL_096f;
																		IL_0919:
																		if (12 > b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0927;
																		IL_0927:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0940;
																		IL_0940:
																		array[num6] = 1;
																		goto IL_094e;
																		IL_094e:
																		num6++;
																		goto IL_095c;
																		IL_095c:
																		ptr2 += 16;
																		break;
																		IL_096f:
																		if (13 < b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_097d;
																		IL_097d:
																		if (13 > b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_098b;
																		IL_098b:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		IL_09a3:
																		if (15 >= b)
																		{
																			num = 138;
																			goto IL_09b7;
																		}
																		goto IL_0a2a;
																		IL_0c2b:
																		if (22 <= b)
																		{
																		}
																		goto end_IL_03e0;
																		IL_09b7:
																		if (15 > b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_09c5;
																		IL_09c5:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0a17;
																		IL_0a17:
																		num6--;
																		break;
																		IL_0a2a:
																		if (16 < b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0a38;
																		IL_0a38:
																		if (16 > b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0a46;
																		IL_0a46:
																		Class147.bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																		goto IL_0a60;
																		IL_0a60:
																		num6--;
																		break;
																		IL_0a73:
																		if (20 >= b)
																		{
																			goto IL_0a81;
																		}
																		goto IL_0bf1;
																		IL_0a81:
																		if (20 <= b)
																		{
																			goto IL_0a8c;
																		}
																		goto IL_0af2;
																		IL_0a8c:
																		array[num6 - 1] = 0;
																		goto IL_0aa0;
																		IL_0aa0:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)ForkJoinOperationTypeMetadataSectionUsagePatterns[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0adf;
																		IL_0adf:
																		ptr2 += 8;
																		break;
																		IL_0af2:
																		if (18 >= b)
																		{
																			goto IL_0afd;
																		}
																		goto IL_0b71;
																		IL_0afd:
																		if (18 > b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0b0b;
																		IL_0b0b:
																		array[num6 - 1] = 3;
																		goto IL_0b1f;
																		IL_0b1f:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ForkJoinOperationTypeMetadataSectionUsagePatterns[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0b5e;
																		IL_0b5e:
																		ptr2 += 8;
																		break;
																		IL_0b71:
																		if (19 < b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0b7f;
																		IL_0b7f:
																		if (19 > b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0b8d;
																		IL_0b8d:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0bcd;
																		IL_0bcd:
																		array[num6 - 2] = 3;
																		goto IL_0be1;
																		IL_0be1:
																		num6--;
																		break;
																		IL_0bf1:
																		if (21 >= b)
																		{
																			goto IL_0bfc;
																		}
																		goto IL_0c20;
																		IL_0bfc:
																		if (21 > b)
																		{
																			goto end_IL_03e0;
																		}
																		goto IL_0c07;
																		IL_0c07:
																		byte* num7 = ptr2;
																		num5 = 1;
																		ptr2 = num7 + -200;
																		break;
																	}
																	goto end_IL_03f0;
																	continue;
																	end_IL_03e0:
																	break;
																	IL_03e0:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															continue;
															end_IL_03f0:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_0c49:
												break;
											}
											continue;
											end_IL_0c5c:
											break;
										}
										continue;
										end_IL_0c66:
										break;
									}
									continue;
									end_IL_0c7a:
									break;
								}
								continue;
								end_IL_0c8a:
								break;
							}
							continue;
							end_IL_0c9a:
							break;
						}
						continue;
						end_IL_0caa:
						break;
					}
					continue;
					end_IL_0cba:
					break;
				}
				continue;
				end_IL_0cca:
				break;
			}
		}
	}

	public Class150()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 116;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 115;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getUserQuotaNetworkSid.SafeLocalAllocHandleUnlockRegion);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02c7:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02aa:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_029a:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_028a:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_027a:
																										if (7 < b)
																										{
																											while (8 >= b)
																											{
																												while (8 <= b)
																												{
																													while (true)
																													{
																														IL_023f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_0226:
																															array[num5] = 0;
																															num = 129;
																															while (true)
																															{
																																if (num != 129)
																																{
																																	if (num != 1110)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 74:
																																		goto IL_0226;
																																	case 80:
																																	case 88:
																																		goto IL_023f;
																																	case 52:
																																		goto IL_025a;
																																	case 4:
																																	case 93:
																																		goto IL_026a;
																																	case 31:
																																	case 47:
																																		goto IL_027a;
																																	case 23:
																																		goto IL_028a;
																																	case 117:
																																		goto IL_029a;
																																	case 54:
																																		goto IL_02aa;
																																	case 38:
																																		goto IL_02b7;
																																	case 113:
																																		goto IL_02c7;
																																	case 20:
																																		goto end_IL_02c7;
																																	case 63:
																																	case 103:
																																		goto end_IL_02d7;
																																	case 106:
																																		goto IL_02f2;
																																	case 43:
																																		goto IL_0300;
																																	case 73:
																																		goto IL_030e;
																																	case 40:
																																	case 64:
																																		goto IL_0319;
																																	case 67:
																																		goto IL_0359;
																																	case 100:
																																		goto IL_036d;
																																	case 32:
																																		goto IL_0380;
																																	case 83:
																																		goto IL_038e;
																																	case 53:
																																		goto IL_039c;
																																	case 33:
																																	case 77:
																																		goto IL_03aa;
																																	case 70:
																																		goto IL_0418;
																																	case 25:
																																		goto IL_042b;
																																	case 11:
																																		goto IL_0436;
																																	case 58:
																																		goto IL_0444;
																																	case 112:
																																		goto IL_0454;
																																	case 114:
																																		goto IL_0467;
																																	case 7:
																																	case 62:
																																		goto end_IL_0213;
																																	case 17:
																																		goto IL_049e;
																																	case 72:
																																		goto IL_04ac;
																																	case 39:
																																	case 118:
																																		goto IL_04bf;
																																	case 16:
																																		goto IL_04e5;
																																	case 34:
																																		goto IL_04f8;
																																	case 35:
																																	case 101:
																																		goto IL_0506;
																																	case 46:
																																		goto IL_0514;
																																	case 109:
																																		goto IL_0537;
																																	case 24:
																																		goto IL_0541;
																																	case 12:
																																		goto IL_054f;
																																	case 91:
																																	case 121:
																																		goto IL_0562;
																																	case 94:
																																		goto IL_05a2;
																																	case 76:
																																		goto IL_05b6;
																																	case 107:
																																	case 120:
																																		goto IL_05c9;
																																	case 56:
																																		goto IL_05d7;
																																	case 30:
																																	case 79:
																																		goto IL_05e2;
																																	case 8:
																																		goto IL_05f5;
																																	case 28:
																																		goto IL_0603;
																																	case 19:
																																	case 41:
																																		goto IL_0611;
																																	case 92:
																																		goto IL_0625;
																																	case 5:
																																		goto IL_0664;
																																	case 21:
																																		goto IL_0677;
																																	case 66:
																																		goto IL_0682;
																																	case 50:
																																	case 51:
																																		goto IL_068d;
																																	case 0:
																																	case 1:
																																	case 13:
																																	case 15:
																																	case 18:
																																	case 22:
																																	case 29:
																																	case 36:
																																	case 37:
																																	case 42:
																																	case 44:
																																	case 45:
																																	case 55:
																																	case 60:
																																	case 61:
																																	case 68:
																																	case 71:
																																	case 75:
																																	case 78:
																																	case 89:
																																	case 90:
																																	case 96:
																																	case 104:
																																	case 108:
																																		goto end_IL_025a;
																																	case 65:
																																		goto IL_06c9;
																																	case 81:
																																		goto IL_06e0;
																																	case 3:
																																		goto IL_06ee;
																																	case 2:
																																	case 6:
																																	case 9:
																																	case 14:
																																	case 48:
																																	case 57:
																																	case 69:
																																	case 85:
																																	case 87:
																																	case 98:
																																	case 99:
																																	case 105:
																																	case 111:
																																	case 119:
																																	case 122:
																																		goto end_IL_02e7;
																																	case 84:
																																		goto end_IL_06fc;
																																	case 10:
																																		goto end_IL_070f;
																																	case 82:
																																		goto end_IL_0719;
																																	case 49:
																																		goto end_IL_0724;
																																	case 86:
																																		goto end_IL_0739;
																																	case 59:
																																	case 95:
																																		goto end_IL_074e;
																																	case 26:
																																		goto end_IL_075e;
																																	case 97:
																																	case 102:
																																		goto end_IL_076e;
																																	case 115:
																																		goto end_IL_077e;
																																	case 116:
																																		goto end_IL_078e;
																																	case 27:
																																	case 110:
																																		goto IL_07b2;
																																	}
																																	continue;
																																}
																																num5++;
																																goto IL_04e5;
																																IL_04e5:
																																ptr2 += 8;
																																goto end_IL_02e7;
																																continue;
																																end_IL_0213:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0475;
																													continue;
																													end_IL_025a:
																													break;
																													IL_025a:;
																												}
																												break;
																												IL_026a:;
																											}
																											break;
																										}
																										goto IL_04f8;
																										IL_054f:
																										ptr2 += 8;
																										goto end_IL_02e7;
																										IL_04f8:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0506;
																										IL_0506:
																										array[num5] = 0;
																										goto IL_0514;
																										IL_0514:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0537;
																										IL_0537:
																										array2[num5] = null;
																										goto IL_0541;
																										IL_0541:
																										num5++;
																										goto IL_054f;
																									}
																									break;
																								}
																								goto IL_0562;
																								IL_05b6:
																								num5--;
																								goto end_IL_02e7;
																								IL_0562:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05a2;
																								IL_05a2:
																								array[num5 - 2] = 0;
																								goto IL_05b6;
																							}
																							break;
																						}
																						goto IL_05c9;
																						IL_068d:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02e7;
																						IL_05c9:
																						if (11 >= b)
																						{
																							goto IL_05d7;
																						}
																						goto IL_0677;
																						IL_05d7:
																						if (11 <= b)
																						{
																							goto IL_05e2;
																						}
																						goto IL_05f5;
																						IL_05e2:
																						num5--;
																						goto end_IL_02e7;
																						IL_05f5:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0603;
																						IL_0603:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0611;
																						IL_0611:
																						array[num5 - 1] = 0;
																						goto IL_0625;
																						IL_0625:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)GetCountSafeDescriptionMetadataPublisher[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_0664;
																						IL_0664:
																						ptr2 += 8;
																						goto end_IL_02e7;
																						IL_0677:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0682;
																						IL_0682:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_068d;
																					}
																					break;
																				}
																				goto IL_02f2;
																				IL_04ac:
																				num5--;
																				goto end_IL_02e7;
																				IL_02f2:
																				if (6 <= b)
																				{
																					goto end_IL_02e7;
																				}
																				goto IL_0300;
																				IL_0300:
																				if (3 >= b)
																				{
																					goto IL_030e;
																				}
																				goto IL_042b;
																				IL_030e:
																				if (3 <= b)
																				{
																					goto IL_0319;
																				}
																				goto IL_0380;
																				IL_0319:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0359;
																				IL_0359:
																				array[num5 - 2] = 0;
																				goto IL_036d;
																				IL_036d:
																				num5--;
																				goto end_IL_02e7;
																				IL_0380:
																				if (1 < b)
																				{
																					goto IL_038e;
																				}
																				goto IL_0454;
																				IL_038e:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_039c;
																				IL_039c:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_03aa;
																				IL_03aa:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0418;
																				IL_0418:
																				num5 -= 2;
																				goto end_IL_02e7;
																				IL_0454:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_042b:
																				if (4 < b)
																				{
																					goto IL_0436;
																				}
																				goto IL_0467;
																				IL_0436:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0444;
																				IL_0444:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_04bf;
																				IL_04bf:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02e7;
																				IL_0467:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0475;
																				IL_0475:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_049e;
																				IL_049e:
																				ptr2 += 8;
																				goto IL_04ac;
																			}
																			break;
																			IL_02b7:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06c9;
																	IL_06ee:
																	ptr2 += 8;
																	goto end_IL_02e7;
																	IL_06e0:
																	num5++;
																	goto IL_06ee;
																	IL_06c9:
																	array[num5] = 0;
																	num = 81;
																	goto IL_06e0;
																	continue;
																	end_IL_02c7:
																	break;
																}
																continue;
																end_IL_02d7:
																break;
															}
															continue;
															end_IL_02e7:
															break;
														}
														continue;
													}
													goto IL_07b2;
													IL_07b2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_06fc:
													break;
												}
												continue;
												end_IL_070f:
												break;
											}
											continue;
											end_IL_0719:
											break;
										}
										continue;
										end_IL_0724:
										break;
									}
									continue;
									end_IL_0739:
									break;
								}
								continue;
								end_IL_074e:
								break;
							}
							continue;
							end_IL_075e:
							break;
						}
						continue;
						end_IL_076e:
						break;
					}
					continue;
					end_IL_077e:
					break;
				}
				continue;
				end_IL_078e:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 99;
		int num5 = default(int);
		int num6 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RequireSecObjectVolumeLabel.ServiceSidgetIdentities);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 123;
												while (true)
												{
													if (num == 123)
													{
														goto IL_029e;
													}
													if (num != 1104)
													{
														goto IL_06ee;
													}
													switch (num)
													{
													case 115:
														goto end_IL_01fb;
													case 92:
														goto end_IL_020e;
													case 101:
														goto end_IL_0219;
													case 50:
														goto end_IL_0223;
													case 15:
														goto end_IL_022e;
													case 12:
													case 43:
														goto end_IL_0243;
													case 53:
														goto end_IL_0253;
													case 4:
													case 44:
														goto end_IL_0263;
													case 98:
														goto end_IL_0273;
													case 99:
														goto end_IL_0283;
													case 9:
													case 21:
													case 26:
													case 42:
													case 51:
													case 58:
													case 67:
													case 69:
													case 74:
													case 83:
													case 91:
													case 108:
														goto IL_029e;
													case 38:
													case 82:
														goto IL_02ae;
													case 84:
														goto IL_02b7;
													case 14:
														goto IL_02c5;
													case 25:
														goto IL_02d3;
													case 89:
														goto IL_02e1;
													case 86:
														goto IL_02ef;
													case 18:
													case 61:
														goto IL_02fd;
													case 66:
														goto IL_030b;
													case 39:
													case 49:
														goto IL_0316;
													case 76:
													case 112:
														goto IL_0337;
													case 107:
														goto IL_0342;
													case 54:
													case 81:
														goto IL_0350;
													case 28:
														goto IL_0369;
													case 113:
														goto IL_0377;
													case 116:
														goto IL_0385;
													case 45:
													case 80:
														goto IL_0398;
													case 5:
														goto IL_03a6;
													case 97:
													case 102:
														goto IL_03b4;
													case 88:
														goto IL_03dd;
													case 100:
														goto IL_03eb;
													case 33:
														goto IL_03fe;
													case 16:
													case 17:
														goto IL_040c;
													case 46:
														goto IL_041a;
													case 78:
													case 105:
														goto IL_0428;
													case 62:
														goto IL_0436;
													case 19:
														goto IL_0462;
													case 110:
														goto IL_0475;
													case 22:
														goto IL_0483;
													case 106:
														goto IL_0496;
													case 3:
													case 40:
														goto IL_04a9;
													case 36:
														goto IL_04e9;
													case 6:
														goto IL_04fd;
													case 68:
														goto IL_0510;
													case 60:
														goto IL_051e;
													case 8:
													case 59:
														goto IL_052c;
													case 65:
														goto IL_053a;
													case 0:
													case 87:
														goto IL_0545;
													case 29:
														goto IL_0585;
													case 30:
														goto IL_0599;
													case 77:
														goto IL_05ba;
													case 47:
														goto IL_05c8;
													case 32:
													case 75:
														goto IL_05d6;
													case 11:
														goto IL_05f9;
													case 71:
														goto IL_0607;
													case 1:
														goto IL_0615;
													case 27:
													case 41:
														goto IL_0628;
													case 90:
														goto IL_068a;
													case 96:
														goto IL_069d;
													case 37:
														goto IL_06a8;
													case 34:
													case 52:
														goto IL_06b3;
													case 63:
													case 111:
														goto IL_06d8;
													case 23:
														goto IL_06e3;
													case 2:
													case 7:
													case 10:
													case 13:
													case 20:
													case 24:
													case 31:
													case 35:
													case 48:
													case 55:
													case 56:
													case 57:
													case 64:
													case 70:
													case 72:
													case 73:
													case 79:
													case 85:
													case 93:
													case 94:
													case 104:
													case 109:
													case 114:
														goto IL_06ee;
													case 95:
													case 103:
														goto IL_0706;
													}
													continue;
													IL_06b3:
													byte* num4 = ptr2;
													num5 = 1;
													ptr2 = num4 + -200;
													goto IL_029e;
													IL_06ee:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_029e;
													IL_029e:
													if (num5 != 1)
													{
														goto IL_02ae;
													}
													goto IL_0706;
													IL_0706:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													IL_02ae:
													b = *ptr2;
													goto IL_02b7;
													IL_02b7:
													ptr2++;
													goto IL_02c5;
													IL_02c5:
													if (b >= 1)
													{
														goto IL_02d3;
													}
													goto IL_06ee;
													IL_02d3:
													if (b <= 11)
													{
														goto IL_02e1;
													}
													goto IL_06ee;
													IL_02e1:
													if (6 >= b)
													{
														goto IL_02ef;
													}
													goto IL_0510;
													IL_02ef:
													if (6 > b)
													{
														goto IL_02fd;
													}
													goto IL_04a9;
													IL_02fd:
													if (3 >= b)
													{
														goto IL_030b;
													}
													goto IL_03fe;
													IL_030b:
													if (3 <= b)
													{
														goto IL_0316;
													}
													num = 112;
													goto IL_0337;
													IL_0316:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_029e;
													IL_06d8:
													if (11 >= b)
													{
														goto IL_06e3;
													}
													goto IL_06ee;
													IL_0337:
													if (1 >= b)
													{
														goto IL_0342;
													}
													goto IL_0398;
													IL_0342:
													if (1 <= b)
													{
														goto IL_0350;
													}
													goto IL_06ee;
													IL_0350:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
													goto IL_0369;
													IL_0369:
													array[num6] = 0;
													goto IL_0377;
													IL_0377:
													num6++;
													goto IL_0385;
													IL_0385:
													ptr2 += 8;
													goto IL_029e;
													IL_0398:
													if (2 >= b)
													{
														goto IL_03a6;
													}
													goto IL_06ee;
													IL_03a6:
													if (2 <= b)
													{
														goto IL_03b4;
													}
													goto IL_06ee;
													IL_03b4:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													goto IL_03dd;
													IL_03dd:
													ptr2 += 8;
													goto IL_03eb;
													IL_03eb:
													num6--;
													goto IL_029e;
													IL_03fe:
													if (4 < b)
													{
														goto IL_040c;
													}
													goto IL_0496;
													IL_040c:
													if (5 >= b)
													{
														goto IL_041a;
													}
													goto IL_06ee;
													IL_041a:
													if (5 <= b)
													{
														goto IL_0428;
													}
													goto IL_06ee;
													IL_0428:
													array[num6] = 0;
													goto IL_0436;
													IL_0436:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
													num = 19;
													goto IL_0462;
													IL_0462:
													array2[num6] = null;
													num = 110;
													goto IL_0475;
													IL_0475:
													num6++;
													goto IL_0483;
													IL_0483:
													ptr2 += 8;
													goto IL_029e;
													IL_0496:
													if (4 <= b)
													{
														goto IL_029e;
													}
													goto IL_06ee;
													IL_04a9:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													goto IL_04e9;
													IL_04e9:
													array[num6 - 2] = 0;
													goto IL_04fd;
													IL_04fd:
													num6--;
													goto IL_029e;
													IL_0510:
													if (9 >= b)
													{
														goto IL_051e;
													}
													goto IL_069d;
													IL_051e:
													if (9 > b)
													{
														goto IL_052c;
													}
													goto IL_0628;
													IL_052c:
													if (7 >= b)
													{
														goto IL_053a;
													}
													goto IL_05ba;
													IL_053a:
													if (7 <= b)
													{
														goto IL_0545;
													}
													num = 13;
													goto IL_06ee;
													IL_0545:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													goto IL_0585;
													IL_0585:
													array[num6 - 2] = 0;
													goto IL_0599;
													IL_0599:
													num6--;
													goto IL_029e;
													IL_06e3:
													if (11 > b)
													{
													}
													goto IL_06ee;
													IL_05ba:
													if (8 >= b)
													{
														goto IL_05c8;
													}
													goto IL_06ee;
													IL_05c8:
													if (8 <= b)
													{
														goto IL_05d6;
													}
													goto IL_06ee;
													IL_05d6:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
													goto IL_05f9;
													IL_05f9:
													array[num6] = 0;
													goto IL_0607;
													IL_0607:
													num6++;
													goto IL_0615;
													IL_0615:
													ptr2 += 8;
													goto IL_029e;
													IL_0628:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_068a;
													IL_068a:
													num6 -= 2;
													goto IL_029e;
													IL_069d:
													if (10 >= b)
													{
														goto IL_06a8;
													}
													num = 63;
													goto IL_06d8;
													IL_06a8:
													if (10 <= b)
													{
														goto IL_06b3;
													}
													goto IL_06ee;
													continue;
													end_IL_01fb:
													break;
												}
												continue;
												end_IL_020e:
												break;
											}
											continue;
											end_IL_0219:
											break;
										}
										continue;
										end_IL_0223:
										break;
									}
									continue;
									end_IL_022e:
									break;
								}
								continue;
								end_IL_0243:
								break;
							}
							continue;
							end_IL_0253:
							break;
						}
						continue;
						end_IL_0263:
						break;
					}
					continue;
					end_IL_0273:
					break;
				}
				continue;
				end_IL_0283:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 45;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DebuggerTypeProxyAttributeEnumAssemblyInstallReferenceFlags.AdjustSessionIdGetTypeInfoInstance);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 == 1)
												{
													num = 112;
													while (true)
													{
														if (num != 112)
														{
															if (num != 1093)
															{
																break;
															}
															switch (num)
															{
															case 12:
															case 96:
																break;
															case 57:
																goto IL_0017;
															case 8:
																goto IL_002e;
															case 58:
																goto IL_003c;
															case 23:
																goto IL_004a;
															case 31:
																goto IL_0058;
															case 15:
															case 43:
																goto IL_0066;
															case 46:
															case 52:
																goto IL_0071;
															case 41:
																goto IL_007c;
															case 35:
																goto IL_008a;
															case 9:
																goto IL_00a6;
															case 2:
															case 103:
																goto IL_00b4;
															case 67:
																goto IL_00d5;
															case 75:
															case 104:
																goto IL_00e0;
															case 77:
																goto IL_00ee;
															case 61:
															case 91:
																goto IL_00fc;
															case 62:
																goto IL_0115;
															case 88:
																goto IL_0123;
															case 0:
																goto IL_0131;
															case 76:
															case 92:
																goto IL_0144;
															case 94:
																goto IL_016d;
															case 55:
																goto IL_017b;
															case 27:
															case 102:
																goto IL_0197;
															case 60:
																goto IL_01a5;
															case 83:
																goto IL_01c8;
															case 50:
																goto IL_01d2;
															case 68:
																goto IL_01e9;
															case 73:
															case 78:
																goto IL_01fc;
															case 22:
																goto IL_020a;
															case 24:
															case 82:
																goto IL_0218;
															case 100:
																goto IL_0226;
															case 3:
															case 69:
																goto IL_0234;
															case 66:
																goto IL_0274;
															case 74:
																goto IL_0291;
															case 99:
																goto IL_02ad;
															case 13:
																goto IL_02bb;
															case 64:
															case 79:
																goto IL_02c9;
															case 20:
																goto IL_02f5;
															case 19:
																goto IL_0303;
															case 44:
																goto IL_031a;
															case 87:
															case 98:
																goto IL_032d;
															case 72:
																goto IL_038f;
															case 70:
																goto IL_03a2;
															case 38:
																goto IL_03ad;
															case 33:
																goto IL_03b8;
															case 80:
																goto IL_03ce;
															case 84:
															case 85:
																goto IL_03e4;
															case 1:
															case 4:
															case 7:
															case 10:
															case 14:
															case 16:
															case 18:
															case 25:
															case 26:
															case 34:
															case 37:
															case 42:
															case 47:
															case 48:
															case 49:
															case 56:
															case 63:
															case 89:
															case 95:
															case 101:
																goto IL_0400;
															default:
																continue;
															case 11:
															case 17:
															case 21:
															case 28:
															case 29:
															case 32:
															case 36:
															case 39:
															case 71:
															case 81:
															case 93:
															case 97:
															case 105:
																goto end_IL_05e7;
															case 40:
																goto end_IL_05fa;
															case 54:
																goto end_IL_060d;
															case 30:
																goto end_IL_0617;
															case 90:
																goto end_IL_0622;
															case 59:
															case 65:
																goto end_IL_0637;
															case 86:
																goto end_IL_0647;
															case 45:
															case 51:
																goto end_IL_0657;
															case 5:
																goto end_IL_0667;
															case 6:
																goto end_IL_0677;
															case 53:
																goto IL_069b;
															}
															goto IL_000e;
														}
														goto IL_069b;
														IL_069b:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_05e7:
														break;
													}
													continue;
												}
												goto IL_000e;
												IL_03e4:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_03ce:
												if (9 <= b)
												{
													goto IL_03e4;
												}
												num = 16;
												goto IL_0400;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												num = 8;
												goto IL_002e;
												IL_002e:
												if (b >= 1)
												{
													goto IL_003c;
												}
												goto IL_0400;
												IL_003c:
												if (b <= 10)
												{
													goto IL_004a;
												}
												goto IL_0400;
												IL_004a:
												if (5 >= b)
												{
													goto IL_0058;
												}
												goto IL_01fc;
												IL_0058:
												if (5 > b)
												{
													goto IL_0066;
												}
												goto IL_0197;
												IL_0066:
												if (2 < b)
												{
													goto IL_0071;
												}
												goto IL_00d5;
												IL_0071:
												if (3 < b)
												{
													goto IL_007c;
												}
												num = 9;
												goto IL_00a6;
												IL_007c:
												if (4 >= b)
												{
													goto IL_008a;
												}
												goto IL_0400;
												IL_008a:
												if (4 <= b)
												{
													continue;
												}
												goto IL_0400;
												IL_0400:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_00a6:
												if (3 <= b)
												{
													goto IL_00b4;
												}
												goto IL_0400;
												IL_00b4:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 81;
												continue;
												IL_00d5:
												if (2 > b)
												{
													goto IL_00e0;
												}
												goto IL_0144;
												IL_00e0:
												if (1 >= b)
												{
													goto IL_00ee;
												}
												goto IL_0400;
												IL_00ee:
												if (1 <= b)
												{
													goto IL_00fc;
												}
												goto IL_0400;
												IL_00fc:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_0115;
												IL_0115:
												array[num5] = 0;
												goto IL_0123;
												IL_0123:
												num5++;
												goto IL_0131;
												IL_0131:
												ptr2 += 8;
												continue;
												IL_0144:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_016d;
												IL_016d:
												ptr2 += 8;
												goto IL_017b;
												IL_017b:
												num5--;
												num = 11;
												continue;
												IL_0197:
												array[num5] = 0;
												goto IL_01a5;
												IL_01a5:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_01c8;
												IL_01c8:
												array2[num5] = null;
												goto IL_01d2;
												IL_01d2:
												num5++;
												num = 68;
												goto IL_01e9;
												IL_01e9:
												ptr2 += 8;
												continue;
												IL_01fc:
												if (8 >= b)
												{
													goto IL_020a;
												}
												goto IL_03a2;
												IL_020a:
												if (8 > b)
												{
													goto IL_0218;
												}
												goto IL_032d;
												IL_0218:
												if (6 >= b)
												{
													goto IL_0226;
												}
												goto IL_02ad;
												IL_0226:
												if (6 <= b)
												{
													goto IL_0234;
												}
												goto IL_0400;
												IL_0234:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0274;
												IL_0274:
												array[num5 - 2] = 0;
												num = 74;
												goto IL_0291;
												IL_0291:
												num5--;
												num = 71;
												continue;
												IL_02ad:
												if (7 >= b)
												{
													goto IL_02bb;
												}
												goto IL_0400;
												IL_02bb:
												if (7 <= b)
												{
													goto IL_02c9;
												}
												goto IL_0400;
												IL_02c9:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												num = 20;
												goto IL_02f5;
												IL_02f5:
												array[num5] = 0;
												goto IL_0303;
												IL_0303:
												num5++;
												num = 44;
												goto IL_031a;
												IL_031a:
												ptr2 += 8;
												continue;
												IL_032d:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_038f;
												IL_038f:
												num5 -= 2;
												continue;
												IL_03a2:
												if (9 < b)
												{
													goto IL_03ad;
												}
												goto IL_03ce;
												IL_03ad:
												if (10 >= b)
												{
													goto IL_03b8;
												}
												goto IL_0400;
												IL_03b8:
												if (10 <= b)
												{
													num = 25;
												}
												goto IL_0400;
												continue;
												end_IL_05fa:
												break;
											}
											continue;
											end_IL_060d:
											break;
										}
										continue;
										end_IL_0617:
										break;
									}
									continue;
									end_IL_0622:
									break;
								}
								continue;
								end_IL_0637:
								break;
							}
							continue;
							end_IL_0647:
							break;
						}
						continue;
						end_IL_0657:
						break;
					}
					continue;
					end_IL_0667:
					break;
				}
				continue;
				end_IL_0677:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 60;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 33;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LookForMyCallerDynamicResolver.setCancellationTokengetDefaultAlias);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 36;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 53;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_026c:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_024c:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_023c:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_022f:
																								if (10 < b)
																								{
																									while (11 >= b)
																									{
																										num = 123;
																										while (true)
																										{
																											if (num != 123)
																											{
																												if (num != 1104)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 100:
																													goto IL_021c;
																												case 72:
																												case 105:
																													goto IL_022f;
																												case 1:
																													goto IL_023c;
																												case 43:
																													goto IL_024c;
																												case 42:
																													goto IL_025c;
																												case 9:
																													goto IL_026c;
																												case 53:
																													goto end_IL_026c;
																												case 11:
																												case 114:
																													goto end_IL_027c;
																												case 90:
																													goto IL_02a0;
																												case 89:
																												case 113:
																													goto IL_02ae;
																												case 78:
																													goto IL_02dd;
																												case 84:
																												case 110:
																													goto IL_02e8;
																												case 6:
																													goto IL_034a;
																												case 82:
																													goto IL_035d;
																												case 34:
																												case 39:
																													goto IL_0368;
																												case 35:
																													goto IL_037f;
																												case 70:
																												case 95:
																													goto IL_038d;
																												case 22:
																													goto IL_03b0;
																												case 76:
																													goto IL_03be;
																												case 47:
																													goto IL_03cc;
																												case 29:
																													goto IL_03df;
																												case 21:
																												case 102:
																													goto IL_03ed;
																												case 28:
																													goto IL_042d;
																												case 54:
																													goto IL_0441;
																												case 30:
																													goto IL_045d;
																												case 86:
																												case 92:
																													goto IL_0468;
																												case 81:
																													goto IL_04a8;
																												case 2:
																													goto IL_04c5;
																												case 68:
																													goto end_IL_0209;
																												case 55:
																												case 64:
																													goto IL_04e6;
																												case 45:
																												case 101:
																													goto IL_04f4;
																												case 80:
																													goto IL_0502;
																												case 7:
																												case 112:
																													goto IL_0510;
																												case 91:
																													goto IL_051e;
																												case 99:
																													goto IL_054a;
																												case 18:
																													goto IL_0554;
																												case 15:
																													goto IL_056b;
																												case 108:
																													goto IL_057e;
																												case 37:
																													goto IL_0591;
																												case 50:
																												case 65:
																													goto IL_059f;
																												case 4:
																												case 25:
																													goto IL_05aa;
																												case 106:
																													goto IL_05b8;
																												case 69:
																												case 74:
																													goto IL_05c6;
																												case 96:
																													goto IL_05ef;
																												case 46:
																													goto IL_05fd;
																												case 85:
																													goto IL_0610;
																												case 67:
																												case 115:
																													goto IL_061b;
																												case 20:
																													goto IL_0634;
																												case 116:
																													goto IL_0642;
																												case 77:
																													goto IL_0650;
																												case 62:
																												case 87:
																													goto IL_0660;
																												case 0:
																												case 8:
																												case 10:
																												case 12:
																												case 14:
																												case 26:
																												case 31:
																												case 40:
																												case 41:
																												case 44:
																												case 51:
																												case 57:
																												case 61:
																												case 63:
																												case 71:
																												case 75:
																												case 79:
																												case 83:
																												case 93:
																												case 94:
																												case 98:
																												case 103:
																												case 107:
																													goto end_IL_021c;
																												case 5:
																												case 13:
																												case 16:
																												case 19:
																												case 23:
																												case 27:
																												case 36:
																												case 38:
																												case 56:
																												case 58:
																												case 66:
																												case 73:
																												case 104:
																												case 111:
																													goto end_IL_028c;
																												case 52:
																													goto end_IL_0691;
																												case 17:
																													goto end_IL_06a4;
																												case 32:
																													goto end_IL_06b7;
																												case 48:
																													goto end_IL_06c2;
																												case 33:
																													goto end_IL_06d7;
																												case 3:
																													goto end_IL_06e7;
																												case 88:
																													goto end_IL_06f7;
																												case 24:
																												case 97:
																													goto end_IL_0702;
																												case 59:
																													goto end_IL_0712;
																												case 60:
																													goto end_IL_0722;
																												case 49:
																												case 109:
																													goto IL_073d;
																												}
																												continue;
																											}
																											if (11 > b)
																											{
																											}
																											goto end_IL_021c;
																											continue;
																											end_IL_0209:
																											break;
																										}
																										goto IL_04d8;
																										continue;
																										end_IL_021c:
																										break;
																										IL_021c:;
																									}
																									break;
																								}
																								goto IL_02a0;
																								IL_02ae:
																								byte* num5 = ptr2;
																								num4 = 1;
																								ptr2 = num5 + -200;
																								goto end_IL_028c;
																								IL_02a0:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_02ae;
																							}
																							break;
																						}
																						goto IL_02dd;
																						IL_042d:
																						array[num6 - 2] = 0;
																						goto IL_0441;
																						IL_02dd:
																						if (9 <= b)
																						{
																							goto IL_02e8;
																						}
																						goto IL_035d;
																						IL_02e8:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_034a;
																						IL_034a:
																						num6 -= 2;
																						goto end_IL_028c;
																						IL_035d:
																						if (7 < b)
																						{
																							goto IL_0368;
																						}
																						goto IL_03df;
																						IL_0368:
																						if (8 < b)
																						{
																							break;
																						}
																						num = 35;
																						goto IL_037f;
																						IL_0441:
																						num6--;
																						goto end_IL_028c;
																						IL_037f:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_038d;
																						IL_038d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03b0;
																						IL_03b0:
																						array[num6] = 0;
																						goto IL_03be;
																						IL_03be:
																						num6++;
																						goto IL_03cc;
																						IL_03cc:
																						ptr2 += 8;
																						goto end_IL_028c;
																						IL_03df:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_03ed;
																						IL_03ed:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_042d;
																					}
																					break;
																				}
																				num = 30;
																				goto IL_045d;
																				IL_0650:
																				ptr2 += 8;
																				goto end_IL_028c;
																				IL_0660:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 19;
																				goto end_IL_028c;
																				IL_045d:
																				if (6 <= b)
																				{
																					goto IL_0468;
																				}
																				goto IL_04d8;
																				IL_0468:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04a8;
																				IL_04a8:
																				array[num6 - 2] = 0;
																				num = 2;
																				goto IL_04c5;
																				IL_04c5:
																				num6--;
																				goto end_IL_028c;
																				IL_04d8:
																				if (3 < b)
																				{
																					goto IL_04e6;
																				}
																				goto IL_0591;
																				IL_04e6:
																				if (4 < b)
																				{
																					goto IL_04f4;
																				}
																				goto IL_057e;
																				IL_04f4:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0502;
																				IL_0502:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0510;
																				IL_0510:
																				array[num6] = 0;
																				goto IL_051e;
																				IL_051e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				num = 99;
																				goto IL_054a;
																				IL_054a:
																				array2[num6] = null;
																				goto IL_0554;
																				IL_0554:
																				num6++;
																				num = 15;
																				goto IL_056b;
																				IL_056b:
																				ptr2 += 8;
																				goto end_IL_028c;
																				IL_057e:
																				if (4 <= b)
																				{
																					goto end_IL_028c;
																				}
																				break;
																				IL_0591:
																				if (3 > b)
																				{
																					goto IL_059f;
																				}
																				goto IL_0660;
																				IL_059f:
																				if (1 < b)
																				{
																					goto IL_05aa;
																				}
																				goto IL_0610;
																				IL_05aa:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_05b8;
																				IL_05b8:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_05c6;
																				IL_05c6:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_05ef;
																				IL_05ef:
																				ptr2 += 8;
																				goto IL_05fd;
																				IL_05fd:
																				num6--;
																				goto end_IL_028c;
																				IL_0610:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_061b;
																				IL_061b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0634;
																				IL_0634:
																				array[num6] = 0;
																				goto IL_0642;
																				IL_0642:
																				num6++;
																				goto IL_0650;
																			}
																			break;
																			IL_025c:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_028c;
																	continue;
																	end_IL_026c:
																	break;
																}
																continue;
																end_IL_027c:
																break;
															}
															continue;
															end_IL_028c:
															break;
														}
														continue;
													}
													goto IL_073d;
													IL_073d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0691:
													break;
												}
												continue;
												end_IL_06a4:
												break;
											}
											continue;
											end_IL_06b7:
											break;
										}
										continue;
										end_IL_06c2:
										break;
									}
									continue;
									end_IL_06d7:
									break;
								}
								continue;
								end_IL_06e7:
								break;
							}
							continue;
							end_IL_06f7:
							break;
						}
						continue;
						end_IL_0702:
						break;
					}
					continue;
					end_IL_0712:
					break;
				}
				continue;
				end_IL_0722:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 67;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[4];
								num = 138;
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_1;
										num = 92;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref pValuesetContentType.HourgetCanReuseTransform);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 132;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02f3:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_02e3:
																			if (b <= 14)
																			{
																				while (true)
																				{
																					IL_02d3:
																					if (7 >= b)
																					{
																						while (true)
																						{
																							IL_02c3:
																							if (7 > b)
																							{
																								while (true)
																								{
																									IL_02b3:
																									if (3 < b)
																									{
																										while (true)
																										{
																											IL_02a3:
																											if (5 < b)
																											{
																												while (6 >= b)
																												{
																													while (true)
																													{
																														IL_0280:
																														if (6 > b)
																														{
																															num = 148;
																															while (num != 148)
																															{
																																if (num != 1129)
																																{
																																	goto IL_02c3;
																																}
																																switch (num)
																																{
																																case 38:
																																	goto IL_0280;
																																case 82:
																																	goto IL_0293;
																																case 23:
																																	goto IL_02a3;
																																case 9:
																																case 48:
																																	goto IL_02b3;
																																case 24:
																																	goto IL_02c3;
																																case 66:
																																	goto IL_02d3;
																																case 98:
																																	goto IL_02e3;
																																case 22:
																																	goto IL_02f3;
																																case 132:
																																	goto end_IL_02f3;
																																case 53:
																																case 85:
																																	goto end_IL_0303;
																																case 6:
																																case 30:
																																	goto IL_0327;
																																case 84:
																																	goto IL_0367;
																																case 87:
																																	goto IL_037b;
																																case 106:
																																	goto IL_038e;
																																case 1:
																																case 75:
																																	goto IL_03a2;
																																case 21:
																																	goto IL_03b0;
																																case 3:
																																case 57:
																																	goto IL_03c3;
																																case 105:
																																	goto IL_03d1;
																																case 52:
																																	goto IL_03fd;
																																case 54:
																																	goto IL_0407;
																																case 97:
																																	goto IL_0415;
																																case 95:
																																	goto IL_0431;
																																case 86:
																																case 140:
																																	goto IL_043f;
																																case 101:
																																case 107:
																																	goto IL_044a;
																																case 28:
																																	goto IL_0458;
																																case 5:
																																case 50:
																																	goto IL_0466;
																																case 94:
																																	goto IL_048f;
																																case 42:
																																	goto IL_049d;
																																case 8:
																																	goto IL_04b0;
																																case 58:
																																case 125:
																																	goto IL_04be;
																																case 124:
																																	goto IL_04d7;
																																case 136:
																																	goto IL_04e5;
																																case 64:
																																	goto IL_04f3;
																																case 51:
																																case 100:
																																	goto IL_050f;
																																case 15:
																																case 93:
																																	goto IL_0527;
																																case 18:
																																	goto IL_0567;
																																case 65:
																																	goto IL_057b;
																																case 47:
																																	goto IL_058e;
																																case 35:
																																	goto IL_059c;
																																case 114:
																																case 139:
																																	goto IL_05b3;
																																case 43:
																																case 123:
																																	goto IL_05c1;
																																case 41:
																																	goto IL_05d8;
																																case 19:
																																case 102:
																																	goto IL_05e6;
																																case 4:
																																	goto IL_0626;
																																case 131:
																																	goto IL_063a;
																																case 110:
																																	goto IL_064d;
																																case 26:
																																case 68:
																																	goto IL_0658;
																																case 111:
																																	goto IL_06ba;
																																case 129:
																																	goto IL_06cd;
																																case 120:
																																	goto IL_06e4;
																																case 118:
																																case 127:
																																	goto IL_06f2;
																																case 62:
																																	goto IL_0715;
																																case 112:
																																	goto IL_0723;
																																case 89:
																																	goto IL_0731;
																																case 90:
																																case 137:
																																	goto IL_0744;
																																case 113:
																																	goto IL_0758;
																																case 103:
																																	goto IL_07ac;
																																case 40:
																																	goto IL_07ba;
																																case 135:
																																	goto IL_07cd;
																																case 46:
																																	goto IL_07d8;
																																case 10:
																																case 115:
																																	goto IL_07e3;
																																case 130:
																																	goto IL_07ee;
																																case 74:
																																case 108:
																																	goto IL_07f9;
																																case 36:
																																case 76:
																																	goto IL_0809;
																																case 16:
																																	goto IL_0822;
																																case 34:
																																	goto IL_082d;
																																case 0:
																																case 7:
																																case 13:
																																case 17:
																																case 20:
																																case 27:
																																case 29:
																																case 31:
																																case 37:
																																case 44:
																																case 55:
																																case 61:
																																case 69:
																																case 73:
																																case 77:
																																case 80:
																																case 83:
																																case 96:
																																case 109:
																																case 117:
																																case 121:
																																case 126:
																																case 128:
																																case 133:
																																case 134:
																																case 141:
																																	goto end_IL_026d;
																																case 2:
																																case 11:
																																case 14:
																																case 25:
																																case 32:
																																case 33:
																																case 45:
																																case 49:
																																case 63:
																																case 78:
																																case 81:
																																case 88:
																																case 91:
																																case 99:
																																case 104:
																																case 116:
																																case 122:
																																	goto end_IL_0313;
																																case 56:
																																	goto end_IL_0856;
																																case 92:
																																	goto end_IL_0869;
																																case 119:
																																	goto end_IL_0873;
																																case 138:
																																	goto end_IL_087e;
																																case 12:
																																case 60:
																																	goto end_IL_089c;
																																case 70:
																																	goto end_IL_08ac;
																																case 67:
																																	goto end_IL_08c5;
																																case 59:
																																	goto end_IL_08d5;
																																case 71:
																																	goto end_IL_08e5;
																																case 72:
																																	goto end_IL_08f0;
																																case 39:
																																case 79:
																																	goto IL_0914;
																																}
																																continue;
																																end_IL_026d:
																																break;
																															}
																															break;
																														}
																														goto IL_0327;
																														IL_0367:
																														array[num5 - 2] = 0;
																														goto IL_037b;
																														IL_037b:
																														num5--;
																														goto end_IL_0313;
																														IL_0327:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_0367;
																													}
																													break;
																													IL_0293:;
																												}
																												break;
																											}
																											goto IL_038e;
																											IL_0407:
																											num5++;
																											goto IL_0415;
																											IL_038e:
																											if (5 > b)
																											{
																												num = 75;
																												goto IL_03a2;
																											}
																											goto IL_03c3;
																											IL_0415:
																											ptr2 += 8;
																											num = 11;
																											goto end_IL_0313;
																											IL_03a2:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_03b0;
																											IL_03b0:
																											if (4 > b)
																											{
																												break;
																											}
																											goto end_IL_0313;
																											IL_03c3:
																											array[num5] = 0;
																											goto IL_03d1;
																											IL_03d1:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											num = 52;
																											goto IL_03fd;
																											IL_03fd:
																											array2[num5] = null;
																											goto IL_0407;
																										}
																										break;
																									}
																									goto IL_0431;
																									IL_050f:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0313;
																									IL_0431:
																									if (3 > b)
																									{
																										goto IL_043f;
																									}
																									goto IL_050f;
																									IL_043f:
																									if (1 < b)
																									{
																										goto IL_044a;
																									}
																									goto IL_04b0;
																									IL_044a:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_0458;
																									IL_0458:
																									if (2 > b)
																									{
																										break;
																									}
																									goto IL_0466;
																									IL_0466:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_048f;
																									IL_048f:
																									ptr2 += 8;
																									goto IL_049d;
																									IL_049d:
																									num5--;
																									goto end_IL_0313;
																									IL_04b0:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_04be;
																									IL_04be:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_04d7;
																									IL_04d7:
																									array[num5] = 0;
																									goto IL_04e5;
																									IL_04e5:
																									num5++;
																									goto IL_04f3;
																									IL_04f3:
																									ptr2 += 8;
																									num = 116;
																									goto end_IL_0313;
																								}
																								break;
																							}
																							goto IL_0527;
																							IL_057b:
																							num5--;
																							goto end_IL_0313;
																							IL_0527:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0567;
																							IL_0567:
																							array[num5 - 2] = 0;
																							goto IL_057b;
																						}
																						break;
																					}
																					goto IL_058e;
																					IL_07f9:
																					num5--;
																					goto end_IL_0313;
																					IL_058e:
																					if (11 >= b)
																					{
																						goto IL_059c;
																					}
																					goto IL_07cd;
																					IL_059c:
																					if (11 > b)
																					{
																						num = 114;
																						goto IL_05b3;
																					}
																					goto IL_0744;
																					IL_0809:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0313;
																					IL_05b3:
																					if (9 < b)
																					{
																						goto IL_05c1;
																					}
																					goto IL_064d;
																					IL_05c1:
																					if (10 < b)
																					{
																						break;
																					}
																					num = 41;
																					goto IL_05d8;
																					IL_0822:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_082d;
																					IL_05d8:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_05e6;
																					IL_05e6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0626;
																					IL_0626:
																					array[num5 - 2] = 0;
																					goto IL_063a;
																					IL_063a:
																					num5--;
																					goto end_IL_0313;
																					IL_064d:
																					if (9 <= b)
																					{
																						goto IL_0658;
																					}
																					goto IL_06cd;
																					IL_0658:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_06ba;
																					IL_06ba:
																					num5 -= 2;
																					goto end_IL_0313;
																					IL_06cd:
																					if (8 < b)
																					{
																						break;
																					}
																					num = 120;
																					goto IL_06e4;
																					IL_082d:
																					if (14 <= b)
																					{
																					}
																					break;
																					IL_06e4:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_06f2;
																					IL_06f2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0715;
																					IL_0715:
																					array[num5] = 0;
																					goto IL_0723;
																					IL_0723:
																					num5++;
																					goto IL_0731;
																					IL_0731:
																					ptr2 += 8;
																					goto end_IL_0313;
																					IL_0744:
																					array[num5 - 2] = 0;
																					goto IL_0758;
																					IL_0758:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)MixedMemberInfo[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_07ac;
																					IL_07ac:
																					num5--;
																					goto IL_07ba;
																					IL_07ba:
																					ptr2 += 8;
																					goto end_IL_0313;
																					IL_07cd:
																					if (13 >= b)
																					{
																						goto IL_07d8;
																					}
																					goto IL_0822;
																					IL_07d8:
																					if (13 > b)
																					{
																						goto IL_07e3;
																					}
																					goto IL_0809;
																					IL_07e3:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_07ee;
																					IL_07ee:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_07f9;
																				}
																			}
																			else
																			{
																				num = 44;
																			}
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0313;
																	continue;
																	end_IL_02f3:
																	break;
																}
																continue;
																end_IL_0303:
																break;
															}
															continue;
															end_IL_0313:
															break;
														}
														continue;
													}
													num = 79;
													goto IL_0914;
													IL_0914:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0856:
													break;
												}
												continue;
												end_IL_0869:
												break;
											}
											continue;
											end_IL_0873:
											break;
										}
										continue;
										end_IL_087e:
										break;
									}
									continue;
									end_IL_089c:
									break;
								}
								continue;
								end_IL_08ac:
								break;
							}
							continue;
							end_IL_08c5:
							break;
						}
						continue;
						end_IL_08d5:
						break;
					}
					continue;
					end_IL_08e5:
					break;
				}
				continue;
				end_IL_08f0:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 44;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getFileAssociationSectionSetObjectUriForMarshal.GetMaxCharCountClosedDelegateOnly);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 85;
																while (true)
																{
																	IL_026a:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_024a:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_023a:
																						if (5 <= b)
																						{
																							num = 77;
																							while (true)
																							{
																								IL_022a:
																								array[num5] = 0;
																								while (true)
																								{
																									IL_0205:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									while (true)
																									{
																										IL_01f9:
																										array2[num5] = null;
																										while (true)
																										{
																											IL_01e0:
																											num5++;
																											num = 108;
																											while (true)
																											{
																												if (num != 108)
																												{
																													if (num != 1089)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 56:
																														goto IL_01e0;
																													case 39:
																														goto IL_01f9;
																													case 55:
																														goto IL_0205;
																													case 77:
																													case 101:
																														goto IL_022a;
																													case 1:
																														goto IL_023a;
																													case 41:
																														goto IL_024a;
																													case 27:
																														goto end_IL_024a;
																													case 85:
																														goto IL_026a;
																													case 70:
																														goto end_IL_026a;
																													case 48:
																													case 52:
																														goto end_IL_027a;
																													case 14:
																														goto IL_029e;
																													case 23:
																														goto IL_02a9;
																													case 32:
																														goto IL_02b9;
																													case 38:
																														goto IL_02c4;
																													case 42:
																														goto IL_02d4;
																													case 65:
																														goto IL_02e4;
																													case 17:
																													case 79:
																														goto IL_02f7;
																													case 31:
																													case 81:
																														goto IL_0322;
																													case 92:
																														goto IL_0332;
																													case 15:
																														goto IL_0340;
																													case 94:
																														goto IL_0353;
																													case 5:
																													case 98:
																														goto IL_036f;
																													case 58:
																														goto IL_03af;
																													case 13:
																														goto IL_03c3;
																													case 40:
																													case 99:
																														goto IL_03d6;
																													case 73:
																														goto IL_03e4;
																													case 62:
																													case 80:
																														goto IL_03ef;
																													case 26:
																														goto IL_0408;
																													case 83:
																														goto IL_0416;
																													case 4:
																														goto IL_0424;
																													case 82:
																														goto IL_0440;
																													case 47:
																														goto IL_0457;
																													case 37:
																													case 69:
																														goto IL_0465;
																													case 91:
																														goto IL_04a5;
																													case 29:
																														goto end_IL_01cd;
																													case 6:
																														goto IL_04cc;
																													case 12:
																														goto IL_04d7;
																													case 78:
																													case 87:
																														goto IL_04ee;
																													case 7:
																														goto IL_052e;
																													case 51:
																														goto IL_0542;
																													case 34:
																														goto IL_0555;
																													case 61:
																														goto IL_0563;
																													case 67:
																													case 89:
																														goto IL_0571;
																													case 59:
																													case 100:
																														goto IL_058d;
																													case 30:
																														goto IL_05cd;
																													case 2:
																														goto IL_05e1;
																													case 3:
																													case 9:
																													case 11:
																													case 21:
																													case 24:
																													case 45:
																													case 46:
																													case 50:
																													case 57:
																													case 60:
																													case 63:
																													case 74:
																													case 75:
																													case 86:
																													case 88:
																													case 93:
																													case 95:
																														goto end_IL_025a;
																													case 66:
																														goto IL_062d;
																													case 96:
																														goto IL_063b;
																													case 35:
																														goto IL_0649;
																													case 0:
																													case 8:
																													case 16:
																													case 18:
																													case 22:
																													case 28:
																													case 36:
																													case 53:
																													case 54:
																													case 90:
																													case 97:
																														goto end_IL_0293;
																													case 72:
																														goto end_IL_0657;
																													case 76:
																														goto end_IL_066a;
																													case 19:
																														goto end_IL_0674;
																													case 71:
																														goto end_IL_067f;
																													case 84:
																														goto end_IL_0694;
																													case 10:
																													case 68:
																														goto end_IL_06a9;
																													case 49:
																														goto end_IL_06b9;
																													case 33:
																													case 64:
																														goto end_IL_06c9;
																													case 43:
																														goto end_IL_06d9;
																													case 44:
																														goto end_IL_06e9;
																													case 20:
																													case 25:
																														goto IL_0704;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												num = 18;
																												goto end_IL_0293;
																												continue;
																												end_IL_01cd:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_029e;
																						IL_02f7:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0332;
																						IL_0332:
																						ptr2 += 8;
																						goto IL_0340;
																						IL_029e:
																						if (2 >= b)
																						{
																							goto IL_02a9;
																						}
																						goto IL_02b9;
																						IL_02a9:
																						if (2 > b)
																						{
																							goto IL_0322;
																						}
																						goto IL_036f;
																						IL_0322:
																						if (1 < b)
																						{
																							goto end_IL_025a;
																						}
																						goto IL_0353;
																						IL_0353:
																						if (1 <= b)
																						{
																							num = 86;
																						}
																						goto end_IL_025a;
																						IL_0340:
																						num5--;
																						goto end_IL_0293;
																						IL_036f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03af;
																						IL_03af:
																						array[num5 - 2] = 0;
																						goto IL_03c3;
																						IL_03c3:
																						num5--;
																						goto end_IL_0293;
																						IL_02b9:
																						if (3 < b)
																						{
																							goto IL_02c4;
																						}
																						goto IL_02d4;
																						IL_02c4:
																						if (4 < b)
																						{
																							goto end_IL_025a;
																						}
																						goto IL_02e4;
																						IL_02e4:
																						if (4 > b)
																						{
																							goto end_IL_025a;
																						}
																						goto IL_058d;
																						IL_058d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05cd;
																						IL_05cd:
																						array[num5 - 2] = 0;
																						goto IL_05e1;
																						IL_05e1:
																						num5--;
																						goto end_IL_0293;
																						IL_02d4:
																						if (3 > b)
																						{
																							goto end_IL_025a;
																						}
																						goto IL_02f7;
																					}
																					goto IL_04b9;
																				}
																				goto IL_03d6;
																				IL_0555:
																				if (9 < b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_0563;
																				IL_03d6:
																				if (7 >= b)
																				{
																					goto IL_03e4;
																				}
																				goto IL_04cc;
																				IL_03e4:
																				if (7 <= b)
																				{
																					goto IL_03ef;
																				}
																				goto IL_0440;
																				IL_03ef:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0408;
																				IL_0408:
																				array[num5] = 0;
																				goto IL_0416;
																				IL_0416:
																				num5++;
																				goto IL_0424;
																				IL_0424:
																				ptr2 += 8;
																				num = 22;
																				goto end_IL_0293;
																				IL_0440:
																				if (6 < b)
																				{
																					goto end_IL_025a;
																				}
																				num = 47;
																				goto IL_0457;
																				IL_0563:
																				if (9 > b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_0571;
																				IL_0457:
																				if (6 > b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_0465;
																				IL_0465:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04a5;
																				IL_04a5:
																				array[num5 - 2] = 0;
																				goto IL_04b9;
																				IL_04b9:
																				num5--;
																				goto end_IL_0293;
																				IL_04cc:
																				if (8 >= b)
																				{
																					goto IL_04d7;
																				}
																				goto IL_0555;
																				IL_04d7:
																				if (8 > b)
																				{
																					goto end_IL_025a;
																				}
																				num = 87;
																				goto IL_04ee;
																				IL_0571:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0293;
																				IL_04ee:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_052e;
																				IL_052e:
																				array[num5 - 2] = 0;
																				goto IL_0542;
																				IL_0542:
																				num5--;
																				goto end_IL_0293;
																				continue;
																				end_IL_024a:
																				break;
																			}
																			continue;
																			end_IL_025a:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_062d;
																	IL_0649:
																	ptr2 += 8;
																	goto end_IL_0293;
																	IL_063b:
																	num5++;
																	goto IL_0649;
																	IL_062d:
																	array[num5] = 0;
																	goto IL_063b;
																	continue;
																	end_IL_026a:
																	break;
																}
																continue;
																end_IL_027a:
																break;
															}
															continue;
															end_IL_0293:
															break;
														}
														continue;
													}
													goto IL_0704;
													IL_0704:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0657:
													break;
												}
												continue;
												end_IL_066a:
												break;
											}
											continue;
											end_IL_0674:
											break;
										}
										continue;
										end_IL_067f:
										break;
									}
									continue;
									end_IL_0694:
									break;
								}
								continue;
								end_IL_06a9:
								break;
							}
							continue;
							end_IL_06b9:
							break;
						}
						continue;
						end_IL_06c9:
						break;
					}
					continue;
					end_IL_06d9:
					break;
				}
				continue;
				end_IL_06e9:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 19;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_06b0:
					byte[] array = new byte[3];
					while (true)
					{
						IL_06a0:
						object[] array2 = new object[3];
						while (true)
						{
							IL_0687:
							int[] array3 = new int[5];
							num = 98;
							while (true)
							{
								IL_0677:
								long[] array4 = new long[3];
								while (true)
								{
									IL_0662:
									array3[0] = int_1;
									while (true)
									{
										IL_064d:
										array3[1] = int_2;
										while (true)
										{
											IL_0642:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref XsdTypeOaepSHA.GenitiveArgumentInvalidArgumentForComparison);
											while (true)
											{
												IL_0638:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0625:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0214:
															byte b = *ptr2;
															num = 13;
															while (true)
															{
																IL_0204:
																ptr2++;
																while (true)
																{
																	IL_01f4:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_01e4:
																			if (b > 9)
																			{
																				num = 109;
																				while (num != 109)
																				{
																					if (num != 1090)
																					{
																						goto end_IL_01f4;
																					}
																					switch (num)
																					{
																					case 16:
																						goto IL_01e4;
																					case 42:
																						goto IL_01f4;
																					case 13:
																						goto IL_0204;
																					case 48:
																					case 49:
																						goto IL_0214;
																					case 102:
																						goto IL_0228;
																					case 62:
																						goto IL_0236;
																					case 75:
																					case 95:
																						goto IL_0244;
																					case 65:
																					case 87:
																						goto IL_0252;
																					case 76:
																						goto IL_025d;
																					case 1:
																					case 2:
																						goto IL_026b;
																					case 41:
																						goto IL_0294;
																					case 73:
																						goto IL_02a2;
																					case 85:
																						goto IL_02b5;
																					case 99:
																						goto IL_02c3;
																					case 18:
																					case 58:
																						goto IL_02d1;
																					case 57:
																						goto IL_0311;
																					case 84:
																						goto IL_0325;
																					case 94:
																						goto IL_0338;
																					case 29:
																					case 31:
																						goto IL_0343;
																					case 91:
																						goto IL_0383;
																					case 0:
																						goto IL_0397;
																					case 5:
																					case 36:
																						goto IL_03aa;
																					case 26:
																						goto IL_03b8;
																					case 96:
																					case 97:
																						goto IL_03d4;
																					case 79:
																						goto IL_03e2;
																					case 55:
																						goto IL_0405;
																					case 54:
																						goto IL_040f;
																					case 69:
																						goto IL_041d;
																					case 10:
																						goto IL_0430;
																					case 38:
																						goto IL_043e;
																					case 22:
																					case 56:
																						goto IL_044c;
																					case 92:
																						goto IL_045a;
																					case 24:
																					case 81:
																						goto IL_0468;
																					case 61:
																						goto IL_04a8;
																					case 37:
																						goto IL_04bc;
																					case 3:
																					case 68:
																						goto IL_04d8;
																					case 6:
																						goto IL_04f1;
																					case 17:
																						goto IL_04ff;
																					case 23:
																						goto IL_050d;
																					case 80:
																						goto IL_0520;
																					case 35:
																						goto IL_052b;
																					case 8:
																					case 12:
																						goto IL_0539;
																					case 71:
																						goto IL_0579;
																					case 25:
																						goto IL_058d;
																					case 100:
																						goto IL_05a0;
																					case 9:
																						goto IL_05ab;
																					case 43:
																					case 74:
																						goto IL_05b6;
																					case 11:
																					case 14:
																					case 21:
																					case 28:
																					case 32:
																					case 33:
																					case 34:
																					case 46:
																					case 50:
																					case 52:
																					case 66:
																					case 70:
																					case 86:
																					case 89:
																					case 90:
																						goto end_IL_01d1;
																					case 27:
																						goto IL_05f2;
																					case 39:
																						goto IL_0600;
																					case 78:
																						goto IL_060e;
																					case 4:
																					case 15:
																					case 40:
																					case 47:
																					case 63:
																					case 64:
																					case 72:
																					case 77:
																					case 82:
																					case 93:
																					case 101:
																						goto IL_0625;
																					case 60:
																						goto IL_0638;
																					case 51:
																						goto IL_0642;
																					case 7:
																						goto IL_064d;
																					case 53:
																						goto IL_0662;
																					case 98:
																						goto IL_0677;
																					case 67:
																					case 88:
																						goto IL_0687;
																					case 83:
																						goto IL_06a0;
																					case 30:
																					case 59:
																						goto IL_06b0;
																					case 19:
																						goto end_IL_01f4;
																					case 20:
																						goto end_IL_06c0;
																					case 44:
																					case 45:
																						goto IL_06e4;
																					}
																					continue;
																					end_IL_01d1:
																					break;
																				}
																				break;
																			}
																			goto IL_0228;
																			IL_05a0:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_05ab;
																			IL_05ab:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_05b6;
																			IL_0228:
																			if (5 >= b)
																			{
																				goto IL_0236;
																			}
																			goto IL_0430;
																			IL_0236:
																			if (5 > b)
																			{
																				goto IL_0244;
																			}
																			goto IL_03d4;
																			IL_0244:
																			if (2 < b)
																			{
																				goto IL_0252;
																			}
																			goto IL_0338;
																			IL_0252:
																			if (3 >= b)
																			{
																				goto IL_025d;
																			}
																			goto IL_02b5;
																			IL_025d:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_026b;
																			IL_026b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0294;
																			IL_0294:
																			ptr2 += 8;
																			goto IL_02a2;
																			IL_02a2:
																			num5--;
																			goto IL_0625;
																			IL_02b5:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_02c3;
																			IL_02c3:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_02d1;
																			IL_02d1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0311;
																			IL_0311:
																			array[num5 - 2] = 0;
																			goto IL_0325;
																			IL_0325:
																			num5--;
																			goto IL_0625;
																			IL_0338:
																			if (2 <= b)
																			{
																				goto IL_0343;
																			}
																			goto IL_03aa;
																			IL_0343:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0383;
																			IL_0383:
																			array[num5 - 2] = 0;
																			goto IL_0397;
																			IL_0397:
																			num5--;
																			goto IL_0625;
																			IL_03aa:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_03b8;
																			IL_03b8:
																			if (1 <= b)
																			{
																				num = 86;
																			}
																			break;
																			IL_05b6:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_0625;
																			IL_03d4:
																			array[num5] = 0;
																			goto IL_03e2;
																			IL_03e2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0405;
																			IL_0405:
																			array2[num5] = null;
																			goto IL_040f;
																			IL_040f:
																			num5++;
																			goto IL_041d;
																			IL_041d:
																			ptr2 += 8;
																			goto IL_0625;
																			IL_0430:
																			if (7 >= b)
																			{
																				goto IL_043e;
																			}
																			goto IL_0520;
																			IL_043e:
																			if (7 > b)
																			{
																				goto IL_044c;
																			}
																			goto IL_04d8;
																			IL_044c:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_045a;
																			IL_045a:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0468;
																			IL_0468:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04a8;
																			IL_04a8:
																			array[num5 - 2] = 0;
																			goto IL_04bc;
																			IL_04bc:
																			num5--;
																			num = 101;
																			goto IL_0625;
																			IL_04d8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04f1;
																			IL_04f1:
																			array[num5] = 0;
																			goto IL_04ff;
																			IL_04ff:
																			num5++;
																			goto IL_050d;
																			IL_050d:
																			ptr2 += 8;
																			goto IL_0625;
																			IL_0520:
																			if (8 >= b)
																			{
																				goto IL_052b;
																			}
																			goto IL_05a0;
																			IL_052b:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0539;
																			IL_0539:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0579;
																			IL_0579:
																			array[num5 - 2] = 0;
																			goto IL_058d;
																			IL_058d:
																			num5--;
																			goto IL_0625;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05f2;
																	IL_060e:
																	ptr2 += 8;
																	num = 15;
																	goto IL_0625;
																	IL_0600:
																	num5++;
																	goto IL_060e;
																	IL_05f2:
																	array[num5] = 0;
																	goto IL_0600;
																	continue;
																	end_IL_01f4:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_06e4;
													IL_06e4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_06c0:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 31;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 87;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DateOfBirthBinaryCompatibility.GetRootObjectgetTargetTypeName);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 42;
															while (true)
															{
																IL_01f8:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_01e8:
																		if (b > 10)
																		{
																			num = 110;
																			while (num != 110)
																			{
																				if (num != 1091)
																				{
																					goto end_IL_01f8;
																				}
																				switch (num)
																				{
																				case 67:
																					goto IL_01e8;
																				case 42:
																					goto IL_01f8;
																				case 13:
																					goto end_IL_01f8;
																				case 72:
																				case 95:
																					goto end_IL_0208;
																				case 83:
																					goto IL_022c;
																				case 89:
																					goto IL_023a;
																				case 27:
																				case 45:
																					goto IL_0248;
																				case 25:
																					goto IL_0256;
																				case 86:
																					goto IL_0261;
																				case 75:
																					goto IL_026f;
																				case 52:
																				case 78:
																					goto IL_027d;
																				case 94:
																					goto IL_0296;
																				case 53:
																					goto IL_02a4;
																				case 54:
																					goto IL_02b2;
																				case 34:
																				case 43:
																					goto IL_02c5;
																				case 88:
																					goto IL_02ee;
																				case 70:
																					goto IL_02fc;
																				case 41:
																					goto IL_0318;
																				case 59:
																					goto IL_0323;
																				case 32:
																				case 74:
																					goto IL_0331;
																				case 99:
																					goto IL_0349;
																				case 50:
																					goto IL_0357;
																				case 81:
																				case 96:
																					goto IL_036a;
																				case 66:
																					goto IL_0378;
																				case 0:
																					goto IL_039b;
																				case 35:
																					goto IL_03a5;
																				case 90:
																					goto IL_03b3;
																				case 4:
																				case 17:
																					goto IL_03cf;
																				case 33:
																					goto IL_03dd;
																				case 73:
																					goto IL_03eb;
																				case 39:
																					goto IL_03f6;
																				case 9:
																				case 48:
																					goto IL_0404;
																				case 14:
																					goto IL_044d;
																				case 85:
																					goto IL_0461;
																				case 16:
																					goto IL_0474;
																				case 80:
																					goto IL_047f;
																				case 2:
																				case 97:
																					goto IL_048d;
																				case 103:
																					goto IL_04b0;
																				case 37:
																					goto IL_04be;
																				case 65:
																					goto IL_04cc;
																				case 20:
																				case 98:
																					goto IL_04ed;
																				case 57:
																					goto IL_0558;
																				case 55:
																				case 93:
																					goto IL_0568;
																				case 47:
																					goto IL_057c;
																				case 18:
																				case 69:
																					goto IL_0587;
																				case 56:
																					goto IL_05a0;
																				case 102:
																					goto IL_05ab;
																				case 1:
																				case 7:
																				case 8:
																				case 19:
																				case 22:
																				case 24:
																				case 36:
																				case 40:
																				case 44:
																				case 46:
																				case 49:
																				case 51:
																				case 60:
																				case 64:
																				case 76:
																				case 77:
																				case 79:
																				case 100:
																				case 101:
																					goto end_IL_01d5;
																				case 3:
																				case 5:
																				case 6:
																				case 12:
																				case 26:
																				case 28:
																				case 29:
																				case 58:
																				case 62:
																				case 68:
																				case 82:
																				case 91:
																				case 92:
																					goto end_IL_0221;
																				case 71:
																					goto end_IL_05d2;
																				case 38:
																					goto end_IL_05e5;
																				case 11:
																					goto end_IL_05ef;
																				case 61:
																					goto end_IL_05fa;
																				case 15:
																				case 84:
																					goto end_IL_060f;
																				case 10:
																					goto end_IL_061f;
																				case 23:
																				case 87:
																					goto end_IL_062f;
																				case 30:
																					goto end_IL_063f;
																				case 31:
																					goto end_IL_064f;
																				case 21:
																				case 63:
																					goto IL_0673;
																				}
																				continue;
																				end_IL_01d5:
																				break;
																			}
																			break;
																		}
																		goto IL_022c;
																		IL_057c:
																		if (9 > b)
																		{
																			break;
																		}
																		goto IL_0587;
																		IL_0587:
																		byte* num5 = ptr2;
																		num4 = 1;
																		ptr2 = num5 + -200;
																		goto end_IL_0221;
																		IL_022c:
																		if (5 >= b)
																		{
																			goto IL_023a;
																		}
																		goto IL_03cf;
																		IL_023a:
																		if (5 > b)
																		{
																			goto IL_0248;
																		}
																		goto IL_036a;
																		IL_0248:
																		if (2 >= b)
																		{
																			goto IL_0256;
																		}
																		goto IL_0318;
																		IL_0256:
																		if (2 > b)
																		{
																			goto IL_0261;
																		}
																		goto IL_02c5;
																		IL_0261:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_026f;
																		IL_026f:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_027d;
																		IL_027d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0296;
																		IL_0296:
																		array[num6] = 0;
																		goto IL_02a4;
																		IL_02a4:
																		num6++;
																		goto IL_02b2;
																		IL_02b2:
																		ptr2 += 8;
																		goto end_IL_0221;
																		IL_02c5:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_02ee;
																		IL_02ee:
																		ptr2 += 8;
																		goto IL_02fc;
																		IL_02fc:
																		num6--;
																		num = 92;
																		goto end_IL_0221;
																		IL_0318:
																		if (3 >= b)
																		{
																			goto IL_0323;
																		}
																		goto IL_0349;
																		IL_0323:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0331;
																		IL_0331:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_0221;
																		IL_0349:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_0357;
																		IL_0357:
																		if (4 > b)
																		{
																			break;
																		}
																		goto end_IL_0221;
																		IL_036a:
																		array[num6] = 0;
																		goto IL_0378;
																		IL_0378:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_039b;
																		IL_039b:
																		array2[num6] = null;
																		goto IL_03a5;
																		IL_03a5:
																		num6++;
																		goto IL_03b3;
																		IL_03b3:
																		ptr2 += 8;
																		num = 29;
																		goto end_IL_0221;
																		IL_03cf:
																		if (8 >= b)
																		{
																			goto IL_03dd;
																		}
																		goto IL_0568;
																		IL_03dd:
																		if (8 > b)
																		{
																			goto IL_03eb;
																		}
																		goto IL_04ed;
																		IL_03eb:
																		if (6 >= b)
																		{
																			goto IL_03f6;
																		}
																		goto IL_0474;
																		IL_03f6:
																		if (6 > b)
																		{
																			break;
																		}
																		goto IL_0404;
																		IL_0404:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		num = 14;
																		goto IL_044d;
																		IL_044d:
																		array[num6 - 2] = 0;
																		goto IL_0461;
																		IL_0461:
																		num6--;
																		goto end_IL_0221;
																		IL_0474:
																		if (7 < b)
																		{
																			num = 79;
																			break;
																		}
																		goto IL_047f;
																		IL_047f:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_048d;
																		IL_048d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04b0;
																		IL_04b0:
																		array[num6] = 0;
																		goto IL_04be;
																		IL_04be:
																		num6++;
																		goto IL_04cc;
																		IL_04cc:
																		ptr2 += 8;
																		goto end_IL_0221;
																		IL_05a0:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_05ab;
																		IL_04ed:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		num = 57;
																		goto IL_0558;
																		IL_0558:
																		num6 -= 2;
																		goto end_IL_0221;
																		IL_0568:
																		if (9 >= b)
																		{
																			num = 47;
																			goto IL_057c;
																		}
																		goto IL_05a0;
																		IL_05ab:
																		if (10 <= b)
																		{
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 91;
																goto end_IL_0221;
																continue;
																end_IL_01f8:
																break;
															}
															continue;
															end_IL_0208:
															break;
														}
														continue;
														end_IL_0221:
														break;
													}
													continue;
												}
												goto IL_0673;
												IL_0673:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05d2:
												break;
											}
											continue;
											end_IL_05e5:
											break;
										}
										continue;
										end_IL_05ef:
										break;
									}
									continue;
									end_IL_05fa:
									break;
								}
								continue;
								end_IL_060f:
								break;
							}
							continue;
							end_IL_061f:
							break;
						}
						continue;
						end_IL_062f:
						break;
					}
					continue;
					end_IL_063f:
					break;
				}
				continue;
				end_IL_064f:
				break;
			}
		}
	}

	static Class150()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 2:
							case 3:
							case 6:
								goto end_IL_003d;
							case 4:
								goto end_IL_004a;
							case 5:
								goto end_IL_0062;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					continue;
					end_IL_004a:
					break;
				}
				continue;
				end_IL_0062:
				break;
			}
		}
	}
}
