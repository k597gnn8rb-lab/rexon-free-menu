using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Projectile Color: Black", "Settings", "Change projectile color.", true, 6, ModType.const_1, false)]
internal class Class136 : MonoBehaviour
{
	internal sealed class _003CDelayedDestroy_003Ed__1 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int int_0;

		private WaitForSeconds waitForSeconds_0;

		public Class136 class136_0;

		private static IntPtr[] ISymbolReaderQueueUserWorkItemCallback;

		object IEnumerator<object>.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		public _003CDelayedDestroy_003Ed__1(int _003C_003E1__state)
		{
			object obj = this;
			((_003CDelayedDestroy_003Ed__1)obj).int_0 = _003C_003E1__state;
		}

		unsafe void IDisposable.Dispose()
		{
			int num = 19;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						IL_03c3:
						byte[] array = new byte[3];
						num = 15;
						while (true)
						{
							IL_03b3:
							object[] array2 = new object[3];
							while (true)
							{
								IL_03a3:
								long[] array3 = new long[3];
								while (true)
								{
									IL_0393:
									object[] array4 = new object[1];
									while (true)
									{
										IL_0383:
										array4[0] = this;
										while (true)
										{
											IL_0378:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResetTimeSpanArray.MaskGenerationMethodgetTypeFormat);
											while (true)
											{
												IL_036e:
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_024d:
														byte b = *ptr2;
														while (true)
														{
															IL_023d:
															ptr2++;
															while (true)
															{
																IL_022d:
																if (b >= 1)
																{
																	goto IL_0177;
																}
																goto IL_0210;
																IL_0210:
																while (true)
																{
																	IL_0210_2:
																	array2[num5] = array4[*(int*)(ptr2 + num3)];
																	while (true)
																	{
																		IL_0167:
																		array[num5] = 5;
																		while (true)
																		{
																			IL_0157:
																			num5++;
																			while (true)
																			{
																				IL_013e:
																				ptr2 += 8;
																				num = 71;
																				while (num != 71)
																				{
																					if (num != 1052)
																					{
																						goto end_IL_035b;
																					}
																					switch (num)
																					{
																					case 33:
																						goto IL_013e;
																					case 28:
																						goto IL_0157;
																					case 63:
																						goto IL_0167;
																					case 16:
																						goto IL_0177;
																					case 45:
																						goto IL_0185;
																					case 32:
																					case 51:
																						goto IL_0199;
																					case 13:
																						goto IL_01a4;
																					case 10:
																						goto IL_01b4;
																					case 57:
																						goto IL_01c1;
																					case 22:
																					case 50:
																						goto IL_01cf;
																					case 44:
																						goto IL_01da;
																					case 5:
																					case 31:
																						goto IL_01e7;
																					case 23:
																						goto IL_01f2;
																					case 60:
																						goto IL_0202;
																					case 9:
																					case 14:
																					case 21:
																					case 30:
																					case 34:
																					case 40:
																					case 43:
																					case 48:
																					case 53:
																					case 61:
																					case 62:
																						goto IL_0210_2;
																					case 35:
																						goto IL_022d;
																					case 11:
																						goto IL_023d;
																					case 0:
																					case 25:
																						goto IL_024d;
																					case 42:
																					case 56:
																						goto IL_0258;
																					case 20:
																						goto IL_0286;
																					case 3:
																					case 29:
																						goto IL_0299;
																					case 27:
																						goto IL_02b2;
																					case 24:
																					case 54:
																						goto IL_02c2;
																					case 58:
																						goto IL_0302;
																					case 8:
																						goto IL_0316;
																					case 1:
																					case 39:
																						goto IL_0326;
																					case 64:
																						goto IL_033f;
																					case 49:
																						goto IL_034d;
																					case 6:
																					case 26:
																					case 36:
																					case 46:
																					case 55:
																					case 59:
																						goto end_IL_012b;
																					case 2:
																						goto IL_036e;
																					case 7:
																						goto IL_0378;
																					case 12:
																						goto IL_0383;
																					case 52:
																						goto IL_0393;
																					case 37:
																					case 47:
																						goto IL_03a3;
																					case 15:
																						goto IL_03b3;
																					case 4:
																					case 17:
																						goto IL_03c3;
																					case 18:
																						goto end_IL_035b;
																					case 19:
																						goto end_IL_03dc;
																					case 38:
																					case 41:
																						return;
																					}
																					continue;
																					end_IL_012b:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
																IL_0177:
																if (b <= 5)
																{
																	goto IL_0185;
																}
																goto IL_0210;
																IL_0185:
																if (3 < b)
																{
																	num = 32;
																	goto IL_0199;
																}
																goto IL_01c1;
																IL_0316:
																num5--;
																break;
																IL_0199:
																if (4 >= b)
																{
																	goto IL_01a4;
																}
																goto IL_01b4;
																IL_01a4:
																if (4 > b)
																{
																	goto IL_0210;
																}
																goto IL_0258;
																IL_0258:
																((_003CDelayedDestroy_003Ed__1)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																goto IL_0286;
																IL_0286:
																num5 -= 2;
																break;
																IL_01b4:
																if (5 >= b)
																{
																	goto IL_0202;
																}
																goto IL_0210;
																IL_0202:
																if (5 > b)
																{
																	goto IL_0210;
																}
																goto IL_0326;
																IL_0326:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																break;
																IL_01c1:
																if (3 > b)
																{
																	goto IL_01cf;
																}
																goto IL_02c2;
																IL_01cf:
																if (1 >= b)
																{
																	goto IL_01da;
																}
																goto IL_01e7;
																IL_01da:
																if (1 > b)
																{
																}
																goto IL_0210;
																IL_01e7:
																if (2 >= b)
																{
																	goto IL_01f2;
																}
																goto IL_0210;
																IL_01f2:
																if (2 > b)
																{
																	goto IL_0210;
																}
																goto IL_0299;
																IL_0299:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(int*)(ptr2 + num3);
																goto IL_02b2;
																IL_02b2:
																array[num5] = 0;
																goto IL_033f;
																IL_033f:
																num5++;
																goto IL_034d;
																IL_034d:
																ptr2 += 8;
																break;
																IL_02c2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																goto IL_0302;
																IL_0302:
																array[num5 - 2] = 0;
																goto IL_0316;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_035b:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_03dc:
					break;
				}
			}
		}

		private unsafe bool MoveNext()
		{
			int num = 32;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[1];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										object[] array5 = new object[2];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UMALQURACMSASSEMBLYREFERENCEFLAGISPLATFORM.ISurrogateSelectorCanResume);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02bc:
																		if (b >= 1)
																		{
																			while (b <= 16)
																			{
																				while (true)
																				{
																					IL_029c:
																					if (8 >= b)
																					{
																						num = 155;
																						while (true)
																						{
																							if (num != 155)
																							{
																								if (num != 1136)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 131:
																									goto IL_029c;
																								case 100:
																									goto end_IL_029c;
																								case 96:
																									goto IL_02bc;
																								case 108:
																									goto end_IL_02bc;
																								case 19:
																								case 59:
																									goto end_IL_02cc;
																								case 79:
																									goto IL_02e7;
																								case 92:
																									goto IL_02f5;
																								case 51:
																									goto IL_0300;
																								case 15:
																									goto IL_030b;
																								case 37:
																									goto IL_032c;
																								case 62:
																									goto IL_0337;
																								case 54:
																									goto IL_0347;
																								case 56:
																									goto IL_0355;
																								case 1:
																								case 107:
																									goto IL_0368;
																								case 120:
																									goto IL_037b;
																								case 21:
																								case 67:
																									goto IL_038f;
																								case 22:
																									goto IL_03a9;
																								case 46:
																									goto end_IL_0289;
																								case 73:
																									goto IL_03ca;
																								case 35:
																								case 117:
																									goto IL_03d5;
																								case 102:
																									goto IL_03f1;
																								case 13:
																									goto IL_03ff;
																								case 89:
																								case 119:
																									goto IL_0416;
																								case 94:
																									goto IL_047d;
																								case 16:
																									goto IL_0494;
																								case 47:
																								case 125:
																									goto IL_04a7;
																								case 36:
																									goto IL_04d0;
																								case 26:
																									goto IL_04de;
																								case 128:
																									goto IL_04f1;
																								case 130:
																									goto IL_050e;
																								case 5:
																								case 33:
																									goto IL_051c;
																								case 105:
																									goto IL_0530;
																								case 64:
																									goto IL_0569;
																								case 136:
																									goto IL_057c;
																								case 69:
																								case 138:
																									goto IL_058f;
																								case 93:
																									goto IL_05bd;
																								case 12:
																								case 140:
																									goto IL_05d0;
																								case 97:
																									goto IL_05fd;
																								case 143:
																									goto IL_0610;
																								case 81:
																									goto IL_0627;
																								case 145:
																									goto IL_063a;
																								case 8:
																									goto IL_0648;
																								case 110:
																								case 123:
																									goto IL_0666;
																								case 52:
																									goto IL_067f;
																								case 27:
																									goto IL_068d;
																								case 2:
																									goto IL_069b;
																								case 85:
																									goto IL_06ae;
																								case 146:
																									goto IL_06bc;
																								case 0:
																								case 39:
																									goto IL_06c7;
																								case 3:
																									goto IL_06ff;
																								case 44:
																									goto IL_0713;
																								case 29:
																									goto IL_0726;
																								case 118:
																									goto IL_0731;
																								case 99:
																									goto IL_073f;
																								case 4:
																								case 25:
																									goto IL_0756;
																								case 10:
																									goto IL_077f;
																								case 60:
																									goto IL_078d;
																								case 133:
																									goto IL_07a9;
																								case 65:
																								case 147:
																									goto IL_07b4;
																								case 121:
																									goto IL_07f2;
																								case 139:
																									goto IL_0806;
																								case 83:
																									goto IL_0819;
																								case 14:
																									goto IL_0827;
																								case 40:
																									goto IL_083a;
																								case 24:
																									goto IL_0848;
																								case 87:
																								case 113:
																									goto IL_0853;
																								case 11:
																									goto IL_0861;
																								case 104:
																									goto IL_0884;
																								case 144:
																									goto IL_088e;
																								case 135:
																									goto IL_089c;
																								case 23:
																									goto IL_08af;
																								case 55:
																									goto IL_08bd;
																								case 17:
																								case 126:
																									goto IL_08cb;
																								case 38:
																									goto IL_08e9;
																								case 84:
																									goto IL_08f7;
																								case 18:
																									goto IL_090a;
																								case 141:
																									goto IL_0915;
																								case 76:
																								case 114:
																									goto IL_0920;
																								case 88:
																									goto IL_0972;
																								case 6:
																								case 7:
																								case 34:
																								case 41:
																								case 43:
																								case 48:
																								case 66:
																								case 71:
																								case 74:
																								case 77:
																								case 80:
																								case 90:
																								case 98:
																								case 111:
																								case 112:
																								case 127:
																								case 129:
																								case 132:
																								case 137:
																									goto end_IL_02ac;
																								case 57:
																									goto IL_09a3;
																								case 91:
																									goto IL_09b1;
																								case 101:
																									goto IL_09bf;
																								case 9:
																								case 28:
																								case 30:
																								case 42:
																								case 53:
																								case 58:
																								case 68:
																								case 72:
																								case 75:
																								case 78:
																								case 82:
																								case 95:
																								case 103:
																								case 115:
																								case 116:
																								case 122:
																								case 134:
																								case 142:
																									goto end_IL_02dc;
																								case 86:
																									goto end_IL_09cd;
																								case 61:
																									goto end_IL_09e0;
																								case 45:
																									goto end_IL_09ea;
																								case 70:
																									goto end_IL_09f5;
																								case 20:
																									goto end_IL_0a05;
																								case 50:
																								case 63:
																									goto end_IL_0a15;
																								case 109:
																									goto end_IL_0a25;
																								case 49:
																								case 106:
																									goto end_IL_0a35;
																								case 31:
																									goto end_IL_0a45;
																								case 32:
																									goto end_IL_0a55;
																								case 124:
																								case 148:
																									goto IL_0a70;
																								}
																								continue;
																							}
																							if (8 <= b)
																							{
																								goto IL_0666;
																							}
																							goto IL_06ae;
																							IL_090a:
																							if (7 < b)
																							{
																								goto end_IL_02ac;
																							}
																							goto IL_0915;
																							IL_0920:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0972;
																							IL_0915:
																							if (7 > b)
																							{
																								goto end_IL_02ac;
																							}
																							goto IL_0920;
																							IL_0666:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_067f;
																							IL_067f:
																							array[num5] = 0;
																							goto IL_068d;
																							IL_068d:
																							num5++;
																							goto IL_069b;
																							IL_069b:
																							ptr2 += 8;
																							goto end_IL_02dc;
																							IL_06ae:
																							if (4 >= b)
																							{
																								goto IL_06bc;
																							}
																							goto IL_083a;
																							IL_06bc:
																							if (4 <= b)
																							{
																								goto IL_06c7;
																							}
																							goto IL_0726;
																							IL_06c7:
																							array2[num5 - 1] = ((delegate*<_003CDelayedDestroy_003Ed__1, Class136>)ISymbolReaderQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((_003CDelayedDestroy_003Ed__1)array2[num5 - 1]);
																							goto IL_06ff;
																							IL_06ff:
																							array[num5 - 1] = 5;
																							goto IL_0713;
																							IL_0713:
																							ptr2 += 8;
																							goto end_IL_02dc;
																							IL_0726:
																							if (2 < b)
																							{
																								goto IL_0731;
																							}
																							goto IL_07a9;
																							IL_0731:
																							if (3 < b)
																							{
																								goto end_IL_02ac;
																							}
																							goto IL_073f;
																							IL_073f:
																							if (3 > b)
																							{
																								goto end_IL_02ac;
																							}
																							num = 25;
																							goto IL_0756;
																							IL_0972:
																							num5--;
																							num = 142;
																							goto end_IL_02dc;
																							IL_0756:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_077f;
																							IL_077f:
																							ptr2 += 8;
																							goto IL_078d;
																							IL_078d:
																							num5--;
																							num = 28;
																							goto end_IL_02dc;
																							IL_07a9:
																							if (2 <= b)
																							{
																								goto IL_07b4;
																							}
																							goto IL_0819;
																							IL_07b4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CDelayedDestroy_003Ed__1, int>)ISymbolReaderQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((_003CDelayedDestroy_003Ed__1)array2[num5 - 1]);
																							goto IL_07f2;
																							IL_07f2:
																							array[num5 - 1] = 0;
																							goto IL_0806;
																							IL_0806:
																							ptr2 += 8;
																							goto end_IL_02dc;
																							IL_0819:
																							if (1 < b)
																							{
																								goto end_IL_02ac;
																							}
																							goto IL_0827;
																							IL_0827:
																							if (1 > b)
																							{
																							}
																							goto end_IL_02ac;
																							IL_083a:
																							if (6 >= b)
																							{
																								goto IL_0848;
																							}
																							goto IL_090a;
																							IL_0848:
																							if (6 <= b)
																							{
																								goto IL_0853;
																							}
																							goto IL_08af;
																							IL_0853:
																							array[num5] = 0;
																							goto IL_0861;
																							IL_0861:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0884;
																							IL_0884:
																							array2[num5] = null;
																							goto IL_088e;
																							IL_088e:
																							num5++;
																							goto IL_089c;
																							IL_089c:
																							ptr2 += 8;
																							goto end_IL_02dc;
																							IL_08af:
																							if (5 < b)
																							{
																								goto end_IL_02ac;
																							}
																							goto IL_08bd;
																							IL_08bd:
																							if (5 > b)
																							{
																								goto end_IL_02ac;
																							}
																							goto IL_08cb;
																							IL_08cb:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_08e9;
																							IL_08e9:
																							ptr2 += 8;
																							goto IL_08f7;
																							IL_08f7:
																							num5--;
																							goto end_IL_02dc;
																							continue;
																							end_IL_0289:
																							break;
																						}
																						goto IL_03bc;
																					}
																					goto IL_02e7;
																					IL_057c:
																					num5 -= 2;
																					goto end_IL_02dc;
																					IL_047d:
																					if (11 < b)
																					{
																						goto end_IL_02ac;
																					}
																					num = 16;
																					goto IL_0494;
																					IL_02e7:
																					if (12 < b)
																					{
																						goto IL_02f5;
																					}
																					goto IL_037b;
																					IL_02f5:
																					if (14 >= b)
																					{
																						goto IL_0300;
																					}
																					goto IL_032c;
																					IL_0300:
																					if (14 > b)
																					{
																						goto IL_030b;
																					}
																					num = 12;
																					goto IL_05d0;
																					IL_030b:
																					if (13 < b)
																					{
																						goto end_IL_02ac;
																					}
																					goto IL_050e;
																					IL_050e:
																					if (13 > b)
																					{
																						goto end_IL_02ac;
																					}
																					goto IL_051c;
																					IL_051c:
																					array[num5 - 1] = 5;
																					goto IL_0530;
																					IL_0530:
																					array2[num5 - 1] = ((delegate*<float, WaitForSeconds>)ISymbolReaderQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])));
																					goto IL_0569;
																					IL_0569:
																					ptr2 += 8;
																					goto end_IL_02dc;
																					IL_05bd:
																					num5 -= 2;
																					goto end_IL_02dc;
																					IL_05d0:
																					((_003CDelayedDestroy_003Ed__1)array2[num5 - 2]).waitForSeconds_0 = (WaitForSeconds)array2[num5 - 1];
																					goto IL_05fd;
																					IL_05fd:
																					num5 -= 2;
																					goto end_IL_02dc;
																					IL_032c:
																					if (15 >= b)
																					{
																						goto IL_0337;
																					}
																					goto IL_0347;
																					IL_0337:
																					if (15 > b)
																					{
																						goto end_IL_02ac;
																					}
																					goto IL_0368;
																					IL_0368:
																					array[num5] = 5;
																					goto IL_04f1;
																					IL_04f1:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_063a;
																					IL_063a:
																					num5++;
																					goto IL_0648;
																					IL_0648:
																					ptr2 += 8;
																					goto end_IL_02dc;
																					IL_0347:
																					if (16 < b)
																					{
																						goto end_IL_02ac;
																					}
																					goto IL_0355;
																					IL_0355:
																					if (16 > b)
																					{
																						goto end_IL_02ac;
																					}
																					goto IL_04a7;
																					IL_04a7:
																					((delegate*<UnityEngine.Object, void>)ISymbolReaderQueueUserWorkItemCallback[*(int*)(ptr2 + num3)])((Class136)array2[num5 - 1]);
																					goto IL_04d0;
																					IL_04d0:
																					num5--;
																					goto IL_04de;
																					IL_04de:
																					ptr2 += 8;
																					goto end_IL_02dc;
																					IL_037b:
																					if (12 <= b)
																					{
																						num = 67;
																						goto IL_038f;
																					}
																					goto IL_03bc;
																					IL_0494:
																					if (11 > b)
																					{
																						goto end_IL_02ac;
																					}
																					goto IL_058f;
																					IL_038f:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																					goto IL_03a9;
																					IL_03a9:
																					array[num5] = 3;
																					goto IL_0610;
																					IL_0610:
																					num5++;
																					num = 81;
																					goto IL_0627;
																					IL_0627:
																					ptr2 += 8;
																					goto end_IL_02dc;
																					IL_03bc:
																					if (10 >= b)
																					{
																						goto IL_03ca;
																					}
																					goto IL_047d;
																					IL_03ca:
																					if (10 <= b)
																					{
																						goto IL_03d5;
																					}
																					goto IL_03f1;
																					IL_03d5:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02dc;
																					IL_03f1:
																					if (9 < b)
																					{
																						goto end_IL_02ac;
																					}
																					goto IL_03ff;
																					IL_03ff:
																					if (9 > b)
																					{
																						goto end_IL_02ac;
																					}
																					num = 119;
																					goto IL_0416;
																					IL_058f:
																					((_003CDelayedDestroy_003Ed__1)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05bd;
																					IL_0416:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_057c;
																					continue;
																					end_IL_029c:
																					break;
																				}
																				continue;
																				end_IL_02ac:
																				break;
																			}
																		}
																		array2[num5] = array5[*(int*)(ptr2 + num3)];
																		goto IL_09a3;
																		IL_09bf:
																		ptr2 += 8;
																		goto end_IL_02dc;
																		IL_09b1:
																		num5++;
																		goto IL_09bf;
																		IL_09a3:
																		array[num5] = 5;
																		goto IL_09b1;
																		continue;
																		end_IL_02bc:
																		break;
																	}
																	continue;
																	end_IL_02cc:
																	break;
																}
																continue;
																end_IL_02dc:
																break;
															}
															continue;
														}
														goto IL_0a70;
														IL_0a70:
														return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
														continue;
														end_IL_09cd:
														break;
													}
													continue;
													end_IL_09e0:
													break;
												}
												continue;
												end_IL_09ea:
												break;
											}
											continue;
											end_IL_09f5:
											break;
										}
										continue;
										end_IL_0a05:
										break;
									}
									continue;
									end_IL_0a15:
									break;
								}
								continue;
								end_IL_0a25:
								break;
							}
							continue;
							end_IL_0a35:
							break;
						}
						continue;
						end_IL_0a45:
						break;
					}
					continue;
					end_IL_0a55:
					break;
				}
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		void IEnumerator.Reset()
		{
			NotSupportedException ex = new NotSupportedException();
			object obj = ex;
			throw (Exception)obj;
		}

		static _003CDelayedDestroy_003Ed__1()
		{
			int num = 3;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					while (true)
					{
						num = 13;
						while (true)
						{
							if (num == 13 || num != 994)
							{
								return;
							}
							switch (num)
							{
							case 1:
							case 4:
							case 6:
								goto end_IL_003d;
							case 2:
								goto end_IL_004a;
							case 3:
								goto end_IL_005c;
							case 0:
								return;
							case 5:
								return;
							}
							continue;
							end_IL_003d:
							break;
						}
						continue;
						end_IL_004a:
						break;
					}
					continue;
					end_IL_005c:
					break;
				}
			}
		}
	}

	private static int int_0;

	private static int int_1;

	private static float float_0;

	private static int int_2;

	private static bool bool_0;

	private static double double_0;

	private static IntPtr[] CursorTopSetTraits;

	private static IntPtr[] getIsNotPublicEras;

	private static IntPtr[] OutputEncodingRSA;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001e, IL_04eb, IL_04fe, IL_050c, IL_051a, IL_0528, IL_0536, IL_0544, IL_054f, IL_055a, IL_056d, IL_057b, IL_058b, IL_0594, IL_05a2, IL_05ad, IL_05bb, IL_05c4, IL_05d7, IL_05e5, IL_05f3, IL_0601, IL_0614, IL_0622, IL_062d, IL_0638, IL_0643, IL_0656, IL_0669, IL_0677, IL_0685, IL_0698, IL_06a1, IL_06b4, IL_06c2, IL_06cd, IL_06db, IL_06e6, IL_06f4, IL_0702, IL_0715, IL_0728, IL_0733, IL_0741, IL_074f, IL_0762, IL_0770, IL_0783, IL_0791, IL_079f, IL_07b2, IL_07c5, IL_07d0, IL_07de, IL_07e9, IL_07f7, IL_0805, IL_0818, IL_0826, IL_0839, IL_0842, IL_084d, IL_085b, IL_0869, IL_087c, IL_0887, IL_0897, IL_08a7, IL_08b2, IL_08bd, IL_08cd, IL_08d6, IL_08e4, IL_08ef, IL_08fd, IL_0924, IL_0934, IL_0944, IL_094f, IL_095d, IL_0983, IL_09c3, IL_09d7, IL_09ea, IL_0a13, IL_0a2a, IL_0a3d, IL_0a54, IL_0a67, IL_0a75, IL_0a98, IL_0aa2, IL_0ab0, IL_0ac3, IL_0b03, IL_0b17, IL_0b2a, IL_0b3e, IL_0b93, IL_0ba1, IL_0bb4, IL_0bd1, IL_0be5, IL_0c1d, IL_0c30, IL_0c45, IL_0c61, IL_0c7e, IL_0cb6, IL_0cc9, IL_0ce3, IL_0cf6, IL_0d21, IL_0d3a, IL_0d64, IL_0d86, IL_0dc6, IL_0dda, IL_0ded, IL_0e04, IL_0e12, IL_0e25, IL_0e41, IL_0e68, IL_0e76, IL_0e84, IL_0e97, IL_0ed5, IL_0ee8, IL_0f28, IL_0f3c, IL_0f4f, IL_0f8f, IL_0fa8, IL_0fc5, IL_1014, IL_101e, IL_104b, IL_105f, IL_106d, IL_1080, IL_10e2, IL_10f5, IL_1135, IL_1149, IL_1165, IL_1173, IL_1191, IL_11a8, IL_11bb, IL_11e4, IL_11fd, IL_1215, IL_1233, IL_1257, IL_1278, IL_128b, IL_129e, IL_12b1, IL_12d5, IL_12e3, IL_12f1, IL_1304, IL_132d, IL_133b, IL_134e, IL_1387, IL_139b, IL_13ae, IL_13c2, IL_140e, IL_141c, IL_142c, IL_143a, IL_1448, IL_1456, IL_1469, IL_1473, IL_147e, IL_148e, IL_149e, IL_14ae, IL_14be, IL_14ce, IL_14de, IL_14ee, IL_14fe are reachable both inside and outside the pinned region starting at IL_1513. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 258;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef53 = default(int);
			ref int reference = ref __rxRef53;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_14fe:
					num2 = 1;
					while (true)
					{
						IL_14ee:
						num3 = num2 * 4;
						while (true)
						{
							IL_14de:
							array2 = new byte[4];
							while (true)
							{
								IL_14ce:
								array3 = new object[4];
								while (true)
								{
									IL_14be:
									array4 = new int[4];
									while (true)
									{
										IL_14ae:
										array5 = new int[6];
										while (true)
										{
											IL_149e:
											array6 = new long[4];
											while (true)
											{
												IL_148e:
												array7 = new object[14];
												while (true)
												{
													IL_147e:
													array7[0] = this;
													while (true)
													{
														IL_1473:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setCreationTimeUtcNoCurrentDateDefault.InternetSiteAuthorityDictionary);
														while (true)
														{
															IL_1469:
															ptr2 = ptr;
															while (true)
															{
																IL_1456:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0944:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0934:
																		ptr2++;
																		while (true)
																		{
																			IL_0924:
																			if (b >= 1)
																			{
																				goto IL_04fe;
																			}
																			goto IL_08fd;
																			IL_08fd:
																			while (true)
																			{
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																				num = 311;
																				while (true)
																				{
																					if (num != 311)
																					{
																						if (num != 1292)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 258:
																							break;
																						default:
																							continue;
																						case 35:
																							goto IL_04fe;
																						case 176:
																							goto IL_050c;
																						case 68:
																							goto IL_051a;
																						case 22:
																						case 64:
																							goto IL_0528;
																						case 228:
																							goto IL_0536;
																						case 4:
																							goto IL_0544;
																						case 173:
																							goto IL_054f;
																						case 95:
																						case 110:
																							goto IL_055a;
																						case 109:
																							goto IL_056d;
																						case 43:
																							goto IL_057b;
																						case 164:
																							goto IL_0594;
																						case 107:
																						case 175:
																							goto IL_05a2;
																						case 187:
																							goto IL_05ad;
																						case 115:
																						case 145:
																							goto IL_05c4;
																						case 165:
																							goto IL_05d7;
																						case 105:
																							goto IL_05e5;
																						case 245:
																							goto IL_0601;
																						case 224:
																						case 255:
																							goto IL_0614;
																						case 101:
																							goto IL_0622;
																						case 87:
																							goto IL_062d;
																						case 108:
																						case 227:
																							goto IL_0638;
																						case 67:
																						case 182:
																							goto IL_0643;
																						case 77:
																							goto IL_0656;
																						case 206:
																							goto IL_0669;
																						case 137:
																						case 247:
																							goto IL_0677;
																						case 75:
																							goto IL_0685;
																						case 48:
																							goto IL_06a1;
																						case 23:
																							goto IL_06b4;
																						case 36:
																						case 124:
																							goto IL_06c2;
																						case 59:
																							goto IL_06cd;
																						case 114:
																							goto IL_06db;
																						case 65:
																							goto IL_06e6;
																						case 186:
																							goto IL_06f4;
																						case 144:
																							goto IL_0702;
																						case 209:
																							goto IL_0715;
																						case 259:
																							goto IL_0728;
																						case 133:
																							goto IL_0733;
																						case 28:
																							goto IL_0741;
																						case 78:
																							goto IL_074f;
																						case 251:
																							goto IL_0762;
																						case 29:
																							goto IL_0770;
																						case 277:
																							goto IL_0783;
																						case 278:
																							goto IL_079f;
																						case 288:
																							goto IL_07b2;
																						case 201:
																						case 293:
																							goto IL_07c5;
																						case 289:
																							goto IL_07d0;
																						case 205:
																							goto IL_07de;
																						case 143:
																							goto IL_07e9;
																						case 237:
																							goto IL_07f7;
																						case 86:
																							goto IL_0805;
																						case 241:
																							goto IL_0818;
																						case 280:
																							goto IL_0826;
																						case 198:
																						case 290:
																							goto IL_0842;
																						case 188:
																							goto IL_084d;
																						case 221:
																						case 232:
																							goto IL_085b;
																						case 89:
																							goto IL_0869;
																						case 275:
																							goto IL_087c;
																						case 131:
																							goto IL_0887;
																						case 295:
																							goto IL_0897;
																						case 304:
																							goto IL_08a7;
																						case 44:
																							goto IL_08b2;
																						case 273:
																							goto IL_08bd;
																						case 52:
																							goto IL_08d6;
																						case 271:
																						case 285:
																							goto IL_08e4;
																						case 76:
																							goto IL_08ef;
																						case 8:
																						case 12:
																						case 16:
																						case 17:
																						case 19:
																						case 41:
																						case 45:
																						case 49:
																						case 72:
																						case 74:
																						case 84:
																						case 88:
																						case 92:
																						case 103:
																						case 119:
																						case 125:
																						case 129:
																						case 132:
																						case 150:
																						case 151:
																						case 152:
																						case 154:
																						case 158:
																						case 160:
																						case 162:
																						case 166:
																						case 167:
																						case 170:
																						case 172:
																						case 181:
																						case 183:
																						case 184:
																						case 189:
																						case 190:
																						case 191:
																						case 193:
																						case 195:
																						case 238:
																						case 240:
																						case 250:
																						case 252:
																						case 260:
																						case 261:
																						case 262:
																						case 276:
																						case 279:
																						case 283:
																						case 284:
																						case 291:
																						case 294:
																						case 297:
																						case 299:
																							goto end_IL_04eb;
																						case 15:
																							goto IL_0924;
																						case 178:
																							goto IL_0934;
																						case 0:
																						case 127:
																							goto IL_0944;
																						case 34:
																						case 39:
																							goto IL_094f;
																						case 42:
																							goto IL_095d;
																						case 91:
																						case 215:
																							goto IL_0983;
																						case 225:
																							goto IL_09c3;
																						case 79:
																							goto IL_09d7;
																						case 216:
																						case 217:
																							goto IL_09ea;
																						case 71:
																							goto IL_0a13;
																						case 66:
																							goto IL_0a2a;
																						case 231:
																							goto IL_0a3d;
																						case 24:
																							goto IL_0a54;
																						case 96:
																						case 253:
																							goto IL_0a67;
																						case 83:
																							goto IL_0a75;
																						case 177:
																							goto IL_0a98;
																						case 126:
																							goto IL_0aa2;
																						case 25:
																							goto IL_0ab0;
																						case 179:
																						case 254:
																							goto IL_0ac3;
																						case 204:
																							goto IL_0b03;
																						case 27:
																							goto IL_0b17;
																						case 134:
																						case 220:
																							goto IL_0b2a;
																						case 199:
																							goto IL_0b3e;
																						case 9:
																							goto IL_0b93;
																						case 1:
																							goto IL_0ba1;
																						case 14:
																						case 235:
																							goto IL_0bb4;
																						case 136:
																						case 197:
																							goto IL_0bd1;
																						case 111:
																							goto IL_0be5;
																						case 37:
																							goto IL_0c1d;
																						case 192:
																						case 219:
																							goto IL_0c30;
																						case 159:
																							goto IL_0c45;
																						case 99:
																						case 239:
																							goto IL_0c61;
																						case 85:
																							goto IL_0c7e;
																						case 56:
																							goto IL_0cb6;
																						case 163:
																						case 246:
																							goto IL_0cc9;
																						case 200:
																							goto IL_0ce3;
																						case 61:
																						case 249:
																							goto IL_0cf6;
																						case 117:
																							goto IL_0d21;
																						case 185:
																						case 223:
																							goto IL_0d3a;
																						case 118:
																							goto IL_0d64;
																						case 50:
																						case 218:
																							goto IL_0d86;
																						case 13:
																							goto IL_0dc6;
																						case 90:
																							goto IL_0dda;
																						case 272:
																							goto IL_0ded;
																						case 33:
																							goto IL_0e04;
																						case 130:
																							goto IL_0e12;
																						case 31:
																						case 38:
																							goto IL_0e25;
																						case 265:
																						case 281:
																							goto IL_0e41;
																						case 26:
																							goto IL_0e68;
																						case 263:
																							goto IL_0e76;
																						case 55:
																							goto IL_0e84;
																						case 269:
																						case 286:
																							goto IL_0e97;
																						case 242:
																							goto IL_0ed5;
																						case 214:
																						case 287:
																							goto IL_0ee8;
																						case 128:
																							goto IL_0f28;
																						case 180:
																							goto IL_0f3c;
																						case 139:
																						case 148:
																							goto IL_0f4f;
																						case 123:
																							goto IL_0f8f;
																						case 54:
																						case 147:
																							goto IL_0fa8;
																						case 58:
																							goto IL_105f;
																						case 233:
																							goto IL_106d;
																						case 73:
																						case 102:
																							goto IL_1080;
																						case 230:
																							goto IL_10e2;
																						case 11:
																						case 203:
																							goto IL_10f5;
																						case 2:
																							goto IL_1135;
																						case 122:
																							goto IL_1149;
																						case 116:
																						case 268:
																							goto IL_1173;
																						case 113:
																							goto IL_1191;
																						case 63:
																							goto IL_11a8;
																						case 149:
																						case 212:
																							goto IL_11bb;
																						case 208:
																							goto IL_11e4;
																						case 46:
																						case 168:
																							goto IL_11fd;
																						case 226:
																							goto IL_1215;
																						case 40:
																							goto IL_1233;
																						case 140:
																							goto IL_1257;
																						case 256:
																							goto IL_1278;
																						case 298:
																							goto IL_128b;
																						case 267:
																						case 302:
																							goto IL_129e;
																						case 156:
																						case 303:
																							goto IL_12b1;
																						case 30:
																							goto IL_12d5;
																						case 57:
																							goto IL_12e3;
																						case 171:
																							goto IL_12f1;
																						case 51:
																						case 236:
																							goto IL_1304;
																						case 5:
																							goto IL_132d;
																						case 82:
																							goto IL_133b;
																						case 20:
																						case 94:
																							goto IL_134e;
																						case 135:
																							goto IL_1387;
																						case 100:
																							goto IL_139b;
																						case 157:
																						case 202:
																							goto IL_13ae;
																						case 292:
																							goto IL_13c2;
																						case 301:
																							goto IL_140e;
																						case 53:
																							goto IL_141c;
																						case 264:
																							goto IL_143a;
																						case 18:
																							goto IL_1448;
																						case 3:
																						case 6:
																						case 7:
																						case 47:
																						case 60:
																						case 62:
																						case 70:
																						case 80:
																						case 93:
																						case 97:
																						case 98:
																						case 104:
																						case 106:
																						case 112:
																						case 120:
																						case 121:
																						case 141:
																						case 146:
																						case 153:
																						case 161:
																						case 174:
																						case 194:
																						case 196:
																						case 207:
																						case 210:
																						case 211:
																						case 213:
																						case 229:
																						case 243:
																						case 248:
																						case 266:
																						case 274:
																						case 282:
																						case 296:
																						case 300:
																							goto IL_1456;
																						case 69:
																							goto IL_1469;
																						case 270:
																							goto IL_1473;
																						case 155:
																							goto IL_147e;
																						case 234:
																							goto IL_148e;
																						case 244:
																							goto IL_149e;
																						case 81:
																							goto IL_14ae;
																						case 142:
																							goto IL_14be;
																						case 169:
																							goto IL_14ce;
																						case 21:
																						case 222:
																							goto IL_14de;
																						case 32:
																							goto IL_14ee;
																						case 257:
																							goto IL_14fe;
																						case 10:
																						case 138:
																							return;
																						}
																						goto end_IL_08fd;
																					}
																					array2[num5] = 0;
																					goto IL_143a;
																					IL_143a:
																					num5++;
																					goto IL_1448;
																					IL_1448:
																					ptr2 += 8;
																					goto IL_1456;
																					continue;
																					end_IL_04eb:
																					break;
																				}
																				continue;
																				end_IL_08fd:
																				break;
																			}
																			break;
																			IL_04fe:
																			if (b <= 32)
																			{
																				goto IL_050c;
																			}
																			goto IL_08fd;
																			IL_050c:
																			if (16 >= b)
																			{
																				goto IL_051a;
																			}
																			goto IL_0614;
																			IL_051a:
																			if (16 > b)
																			{
																				goto IL_0528;
																			}
																			goto IL_094f;
																			IL_0528:
																			if (8 >= b)
																			{
																				goto IL_0536;
																			}
																			goto IL_07c5;
																			IL_0536:
																			if (8 > b)
																			{
																				goto IL_0544;
																			}
																			goto IL_129e;
																			IL_0544:
																			if (4 < b)
																			{
																				goto IL_054f;
																			}
																			num = 164;
																			goto IL_0594;
																			IL_054f:
																			if (6 < b)
																			{
																				goto IL_055a;
																			}
																			goto IL_056d;
																			IL_055a:
																			if (7 >= b)
																			{
																				goto IL_07b2;
																			}
																			goto IL_08fd;
																			IL_07b2:
																			if (7 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0f4f;
																			IL_0f4f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0f8f;
																			IL_0f8f:
																			array2[num5 - 2] = 0;
																			goto IL_128b;
																			IL_128b:
																			num5--;
																			goto IL_1456;
																			IL_056d:
																			if (6 > b)
																			{
																				goto IL_057b;
																			}
																			goto IL_0983;
																			IL_057b:
																			if (5 >= b)
																			{
																				goto IL_0601;
																			}
																			goto IL_08fd;
																			IL_0601:
																			if (5 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0ee8;
																			IL_0ee8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0f28;
																			IL_0f28:
																			array2[num5 - 2] = 0;
																			goto IL_0f3c;
																			IL_0f3c:
																			num5--;
																			goto IL_1456;
																			IL_0983:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_09c3;
																			IL_09c3:
																			array2[num5 - 2] = 0;
																			goto IL_09d7;
																			IL_09d7:
																			num5--;
																			goto IL_1456;
																			IL_0d3a:
																			*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
																			goto IL_0d64;
																			IL_0594:
																			if (4 > b)
																			{
																				goto IL_05a2;
																			}
																			goto IL_0a67;
																			IL_05a2:
																			if (2 >= b)
																			{
																				goto IL_05ad;
																			}
																			goto IL_05d7;
																			IL_05ad:
																			if (2 > b)
																			{
																				num = 115;
																				goto IL_05c4;
																			}
																			goto IL_0ac3;
																			IL_0d64:
																			array2[num5 - 1] = 2;
																			num = 141;
																			goto IL_1456;
																			IL_05c4:
																			if (1 >= b)
																			{
																				goto IL_0783;
																			}
																			goto IL_08fd;
																			IL_0783:
																			if (1 <= b)
																			{
																				num = 167;
																			}
																			goto IL_08fd;
																			IL_0cf6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																			goto IL_0d21;
																			IL_0ac3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0b03;
																			IL_0b03:
																			array2[num5 - 2] = 0;
																			goto IL_0b17;
																			IL_0b17:
																			num5--;
																			goto IL_1456;
																			IL_05d7:
																			if (3 >= b)
																			{
																				goto IL_05e5;
																			}
																			goto IL_08fd;
																			IL_05e5:
																			if (3 > b)
																			{
																				num = 84;
																				goto IL_08fd;
																			}
																			goto IL_09ea;
																			IL_0d21:
																			array2[num5 - 1] = 0;
																			goto IL_1456;
																			IL_09ea:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0a13;
																			IL_0a13:
																			ptr2 += 8;
																			num = 66;
																			goto IL_0a2a;
																			IL_0a2a:
																			num5--;
																			goto IL_1456;
																			IL_0a67:
																			array2[num5] = 0;
																			goto IL_0a75;
																			IL_0a75:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_0a98;
																			IL_0a98:
																			array3[num5] = null;
																			goto IL_0aa2;
																			IL_0aa2:
																			num5++;
																			goto IL_0ab0;
																			IL_0ab0:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_129e:
																			num5--;
																			goto IL_1456;
																			IL_07c5:
																			if (12 >= b)
																			{
																				goto IL_07d0;
																			}
																			num = 290;
																			goto IL_0842;
																			IL_07d0:
																			if (12 > b)
																			{
																				goto IL_07de;
																			}
																			goto IL_0fa8;
																			IL_07de:
																			if (10 >= b)
																			{
																				goto IL_07e9;
																			}
																			goto IL_0818;
																			IL_07e9:
																			if (10 > b)
																			{
																				goto IL_07f7;
																			}
																			goto IL_1080;
																			IL_07f7:
																			if (9 >= b)
																			{
																				goto IL_0805;
																			}
																			goto IL_08fd;
																			IL_0805:
																			if (9 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_10f5;
																			IL_10f5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_1135;
																			IL_1135:
																			array2[num5 - 2] = 0;
																			goto IL_1149;
																			IL_1149:
																			num5--;
																			num = 93;
																			goto IL_1456;
																			IL_1080:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_10e2;
																			IL_10e2:
																			num5 -= 2;
																			goto IL_1456;
																			IL_0818:
																			if (11 >= b)
																			{
																				goto IL_0826;
																			}
																			goto IL_08fd;
																			IL_0826:
																			if (11 <= b)
																			{
																				num = 153;
																				goto IL_1456;
																			}
																			goto IL_08fd;
																			IL_0770:
																			if (23 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0d86;
																			IL_0fa8:
																			array8 = array3;
																			num6 = num5;
																			if (array == null)
																			{
																				goto IL_0fb7;
																			}
																			num7 = ptr2;
																			byte b2 = *num7;
																			ptr2 = num7 + 4;
																			int num8 = *(int*)(ptr2 + num3);
																			ptr2 += 8;
																			byte* ptr3 = ptr2 + num8;
																			byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																			while (ptr2 != ptr3)
																			{
																				*ptr4 = (byte)(*ptr2 ^ b2);
																				ptr2++;
																				ptr4++;
																			}
																			array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																			goto IL_105f;
																			IL_0d86:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0dc6;
																			IL_0dc6:
																			array2[num5 - 2] = 0;
																			goto IL_0dda;
																			IL_0dda:
																			num5--;
																			goto IL_1456;
																			IL_105f:
																			array2[num5] = 5;
																			goto IL_106d;
																			IL_106d:
																			num5++;
																			goto IL_1456;
																			IL_0762:
																			if (23 >= b)
																			{
																				goto IL_0770;
																			}
																			goto IL_08fd;
																			IL_0842:
																			if (14 >= b)
																			{
																				goto IL_084d;
																			}
																			goto IL_087c;
																			IL_084d:
																			if (14 > b)
																			{
																				goto IL_085b;
																			}
																			goto IL_11bb;
																			IL_085b:
																			if (13 >= b)
																			{
																				goto IL_0869;
																			}
																			goto IL_08fd;
																			IL_0869:
																			if (13 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_1173;
																			IL_1173:
																			array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																			goto IL_1191;
																			IL_1191:
																			ptr2 += 8;
																			num = 63;
																			goto IL_11a8;
																			IL_11a8:
																			num5--;
																			goto IL_1456;
																			IL_11bb:
																			array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																			goto IL_11e4;
																			IL_11e4:
																			array2[num5 - 1] = 5;
																			goto IL_1456;
																			IL_087c:
																			if (15 >= b)
																			{
																				goto IL_0887;
																			}
																			goto IL_08fd;
																			IL_0887:
																			if (15 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_11fd;
																			IL_11fd:
																			array2[num5] = array2[num5 - 1];
																			goto IL_1215;
																			IL_1215:
																			array4[num5 - 0] = array4[num5 - 1];
																			goto IL_1233;
																			IL_1233:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_1257;
																			IL_1257:
																			array3[num5] = array3[num5 - 1];
																			num = 256;
																			goto IL_1278;
																			IL_1278:
																			num5++;
																			goto IL_1456;
																			IL_094f:
																			array2[num5] = 5;
																			goto IL_095d;
																			IL_095d:
																			array3[num5] = array7[*(int*)(ptr2 + num3)];
																			num = 231;
																			goto IL_0a3d;
																			IL_0a3d:
																			num5++;
																			num = 24;
																			goto IL_0a54;
																			IL_0a54:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0614:
																			if (24 < b)
																			{
																				goto IL_0622;
																			}
																			goto IL_06b4;
																			IL_0622:
																			if (28 < b)
																			{
																				goto IL_062d;
																			}
																			num = 48;
																			goto IL_06a1;
																			IL_062d:
																			if (30 < b)
																			{
																				goto IL_0638;
																			}
																			goto IL_0669;
																			IL_0638:
																			if (31 < b)
																			{
																				goto IL_0643;
																			}
																			goto IL_0656;
																			IL_0643:
																			if (32 >= b)
																			{
																				goto IL_079f;
																			}
																			goto IL_08fd;
																			IL_079f:
																			if (32 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0e25;
																			IL_0e25:
																			num9 = ptr2;
																			num10 = -200;
																			num4 = 1;
																			ptr2 = num9 + num10;
																			goto IL_1456;
																			IL_0656:
																			if (31 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0b2a;
																			IL_0b2a:
																			array2[num5 - 2] = 5;
																			goto IL_0b3e;
																			IL_0b3e:
																			array3[num5 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((Class136)array3[num5 - 2], (IEnumerator)array3[num5 - 1]);
																			num = 9;
																			goto IL_0b93;
																			IL_0b93:
																			num5--;
																			goto IL_0ba1;
																			IL_0ba1:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0669:
																			if (30 > b)
																			{
																				goto IL_0677;
																			}
																			goto IL_0bd1;
																			IL_0677:
																			if (29 >= b)
																			{
																				goto IL_0685;
																			}
																			goto IL_08fd;
																			IL_0685:
																			if (29 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0bb4;
																			IL_0bb4:
																			array3[num5] = array7[*(int*)(ptr2 + num3)];
																			goto IL_0ded;
																			IL_0ded:
																			array2[num5] = 5;
																			num = 33;
																			goto IL_0e04;
																			IL_0e04:
																			num5++;
																			goto IL_0e12;
																			IL_0e12:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0bd1:
																			array2[num5 - 1] = 5;
																			goto IL_0be5;
																			IL_0be5:
																			array3[num5 - 1] = ((delegate*<Class136, IEnumerator>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((Class136)array3[num5 - 1]);
																			goto IL_0c1d;
																			IL_0c1d:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0cc9:
																			Class9.int_1 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0ce3;
																			IL_06a1:
																			if (28 > b)
																			{
																				goto IL_08a7;
																			}
																			goto IL_0c30;
																			IL_0c30:
																			((delegate*<void>)CursorTopSetTraits[*(int*)(ptr2 + num3)])();
																			goto IL_0c45;
																			IL_0c45:
																			ptr2 += 8;
																			num = 213;
																			goto IL_1456;
																			IL_08a7:
																			if (26 < b)
																			{
																				goto IL_08b2;
																			}
																			num = 52;
																			goto IL_08d6;
																			IL_08b2:
																			if (27 >= b)
																			{
																				goto IL_08bd;
																			}
																			goto IL_08fd;
																			IL_08bd:
																			if (27 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_1304;
																			IL_1304:
																			((delegate*<string, void>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																			goto IL_132d;
																			IL_132d:
																			num5--;
																			goto IL_133b;
																			IL_133b:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0ce3:
																			num5--;
																			goto IL_1456;
																			IL_08d6:
																			if (26 > b)
																			{
																				goto IL_08e4;
																			}
																			goto IL_13ae;
																			IL_08e4:
																			if (25 >= b)
																			{
																				goto IL_08ef;
																			}
																			goto IL_08fd;
																			IL_08ef:
																			if (25 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_134e;
																			IL_134e:
																			array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																			goto IL_1387;
																			IL_1387:
																			array2[num5 - 2] = 5;
																			goto IL_139b;
																			IL_139b:
																			num5--;
																			goto IL_1456;
																			IL_13ae:
																			array2[num5 - 2] = 5;
																			goto IL_13c2;
																			IL_13c2:
																			array3[num5 - 2] = ((delegate*<string, string, string>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																			goto IL_140e;
																			IL_140e:
																			num5--;
																			goto IL_141c;
																			IL_141c:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_06b4:
																			if (24 > b)
																			{
																				goto IL_06c2;
																			}
																			goto IL_0cc9;
																			IL_06c2:
																			if (20 >= b)
																			{
																				goto IL_06cd;
																			}
																			goto IL_0728;
																			IL_06cd:
																			if (20 > b)
																			{
																				goto IL_06db;
																			}
																			goto IL_0e41;
																			IL_06db:
																			if (18 >= b)
																			{
																				goto IL_06e6;
																			}
																			goto IL_0715;
																			IL_06e6:
																			if (18 > b)
																			{
																				goto IL_06f4;
																			}
																			goto IL_0c61;
																			IL_06f4:
																			if (17 >= b)
																			{
																				goto IL_0702;
																			}
																			goto IL_08fd;
																			IL_0702:
																			if (17 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0e97;
																			IL_0e97:
																			((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																			goto IL_0ed5;
																			IL_0ed5:
																			num5 -= 3;
																			goto IL_1456;
																			IL_0c61:
																			array2[num5 - 1] = 5;
																			num = 85;
																			goto IL_0c7e;
																			IL_0c7e:
																			array3[num5 - 1] = ((delegate*<string[], string>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																			goto IL_0cb6;
																			IL_0cb6:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0715:
																			if (19 >= b)
																			{
																				goto IL_0897;
																			}
																			goto IL_08fd;
																			IL_0897:
																			if (19 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_12b1;
																			IL_12b1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)CursorTopSetTraits[*(int*)(ptr2 + num3)])();
																			goto IL_12d5;
																			IL_12d5:
																			array2[num5] = 0;
																			goto IL_12e3;
																			IL_12e3:
																			num5++;
																			goto IL_12f1;
																			IL_12f1:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0e41:
																			array3[num5] = ((delegate*<string[]>)CursorTopSetTraits[*(int*)(ptr2 + num3)])();
																			num = 26;
																			goto IL_0e68;
																			IL_0e68:
																			array2[num5] = 5;
																			goto IL_0e76;
																			IL_0e76:
																			num5++;
																			goto IL_0e84;
																			IL_0e84:
																			ptr2 += 8;
																			goto IL_1456;
																			IL_0728:
																			if (22 >= b)
																			{
																				goto IL_0733;
																			}
																			goto IL_0762;
																			IL_0733:
																			if (22 > b)
																			{
																				goto IL_0741;
																			}
																			goto IL_0cf6;
																			IL_0741:
																			if (21 >= b)
																			{
																				goto IL_074f;
																			}
																			goto IL_08fd;
																			IL_074f:
																			if (21 > b)
																			{
																				goto IL_08fd;
																			}
																			goto IL_0d3a;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0fb7:
			while (true)
			{
				IL_0fb7_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_105f_2:
						array2[num5] = 5;
						while (true)
						{
							IL_106d_2:
							num5++;
							while (true)
							{
								IL_1456_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0924_2:
											if (b >= 1)
											{
												goto IL_04fe_2;
											}
											goto IL_08fd_3;
											IL_08fd_3:
											while (true)
											{
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
												num = 311;
												while (true)
												{
													if (num != 311)
													{
														if (num != 1292)
														{
															break;
														}
														switch (num)
														{
														case 35:
															goto end_IL_08fd_2;
														case 176:
															goto IL_050c_2;
														case 68:
															goto IL_051a_2;
														case 22:
														case 64:
															goto IL_0528_2;
														case 228:
															goto IL_0536_2;
														case 4:
															goto IL_0544_2;
														case 173:
															goto IL_054f_2;
														case 95:
														case 110:
															goto IL_055a_2;
														case 109:
															goto IL_056d_2;
														case 43:
															goto IL_057b_2;
														case 164:
															goto IL_0594_2;
														case 107:
														case 175:
															goto IL_05a2_2;
														case 187:
															goto IL_05ad_2;
														case 115:
														case 145:
															goto IL_05c4_2;
														case 165:
															goto IL_05d7_2;
														case 105:
															goto IL_05e5_2;
														case 245:
															goto IL_0601_2;
														case 224:
														case 255:
															goto IL_0614_2;
														case 101:
															goto IL_0622_2;
														case 87:
															goto IL_062d_2;
														case 108:
														case 227:
															goto IL_0638_2;
														case 67:
														case 182:
															goto IL_0643_2;
														case 77:
															goto IL_0656_2;
														case 206:
															goto IL_0669_2;
														case 137:
														case 247:
															goto IL_0677_2;
														case 75:
															goto IL_0685_2;
														case 48:
															goto IL_06a1_2;
														case 23:
															goto IL_06b4_2;
														case 36:
														case 124:
															goto IL_06c2_2;
														case 59:
															goto IL_06cd_2;
														case 114:
															goto IL_06db_2;
														case 65:
															goto IL_06e6_2;
														case 186:
															goto IL_06f4_2;
														case 144:
															goto IL_0702_2;
														case 209:
															goto IL_0715_2;
														case 259:
															goto IL_0728_2;
														case 133:
															goto IL_0733_2;
														case 28:
															goto IL_0741_2;
														case 78:
															goto IL_074f_2;
														case 251:
															goto IL_0762_2;
														case 29:
															goto IL_0770_2;
														case 277:
															goto IL_0783_2;
														case 278:
															goto IL_079f_2;
														case 288:
															goto IL_07b2_2;
														case 201:
														case 293:
															goto IL_07c5_2;
														case 289:
															goto IL_07d0_2;
														case 205:
															goto IL_07de_2;
														case 143:
															goto IL_07e9_2;
														case 237:
															goto IL_07f7_2;
														case 86:
															goto IL_0805_2;
														case 241:
															goto IL_0818_2;
														case 280:
															goto IL_0826_2;
														case 198:
														case 290:
															goto IL_0842_2;
														case 188:
															goto IL_084d_2;
														case 221:
														case 232:
															goto IL_085b_2;
														case 89:
															goto IL_0869_2;
														case 275:
															goto IL_087c_2;
														case 131:
															goto IL_0887_2;
														case 295:
															goto IL_0897_2;
														case 304:
															goto IL_08a7_2;
														case 44:
															goto IL_08b2_2;
														case 273:
															goto IL_08bd_2;
														case 52:
															goto IL_08d6_2;
														case 271:
														case 285:
															goto IL_08e4_2;
														case 76:
															goto IL_08ef_2;
														case 8:
														case 12:
														case 16:
														case 17:
														case 19:
														case 41:
														case 45:
														case 49:
														case 72:
														case 74:
														case 84:
														case 88:
														case 92:
														case 103:
														case 119:
														case 125:
														case 129:
														case 132:
														case 150:
														case 151:
														case 152:
														case 154:
														case 158:
														case 160:
														case 162:
														case 166:
														case 167:
														case 170:
														case 172:
														case 181:
														case 183:
														case 184:
														case 189:
														case 190:
														case 191:
														case 193:
														case 195:
														case 238:
														case 240:
														case 250:
														case 252:
														case 260:
														case 261:
														case 262:
														case 276:
														case 279:
														case 283:
														case 284:
														case 291:
														case 294:
														case 297:
														case 299:
															goto end_IL_04eb_2;
														case 15:
															goto IL_0924_2;
														case 178:
															goto end_IL_0924;
														case 0:
														case 127:
															goto end_IL_0934;
														case 34:
														case 39:
															goto IL_094f_2;
														case 42:
															goto IL_095d_2;
														case 91:
														case 215:
															goto IL_0983_2;
														case 225:
															goto IL_09c3_2;
														case 79:
															goto IL_09d7_2;
														case 216:
														case 217:
															goto IL_09ea_2;
														case 71:
															goto IL_0a13_2;
														case 66:
															goto IL_0a2a_2;
														case 231:
															goto IL_0a3d_2;
														case 24:
															goto IL_0a54_2;
														case 96:
														case 253:
															goto IL_0a67_2;
														case 83:
															goto IL_0a75_2;
														case 177:
															goto IL_0a98_2;
														case 126:
															goto IL_0aa2_2;
														case 25:
															goto IL_0ab0_2;
														case 179:
														case 254:
															goto IL_0ac3_2;
														case 204:
															goto IL_0b03_2;
														case 27:
															goto IL_0b17_2;
														case 134:
														case 220:
															goto IL_0b2a_2;
														case 199:
															goto IL_0b3e_2;
														case 9:
															goto IL_0b93_2;
														case 1:
															goto IL_0ba1_2;
														case 14:
														case 235:
															goto IL_0bb4_2;
														case 136:
														case 197:
															goto IL_0bd1_2;
														case 111:
															goto IL_0be5_2;
														case 37:
															goto IL_0c1d_2;
														case 192:
														case 219:
															goto IL_0c30_2;
														case 159:
															goto IL_0c45_2;
														case 99:
														case 239:
															goto IL_0c61_2;
														case 85:
															goto IL_0c7e_2;
														case 56:
															goto IL_0cb6_2;
														case 163:
														case 246:
															goto IL_0cc9_2;
														case 200:
															goto IL_0ce3_2;
														case 61:
														case 249:
															goto IL_0cf6_2;
														case 117:
															goto IL_0d21_2;
														case 185:
														case 223:
															goto IL_0d3a_2;
														case 118:
															goto IL_0d64_2;
														case 50:
														case 218:
															goto IL_0d86_2;
														case 13:
															goto IL_0dc6_2;
														case 90:
															goto IL_0dda_2;
														case 272:
															goto IL_0ded_2;
														case 33:
															goto IL_0e04_2;
														case 130:
															goto IL_0e12_2;
														case 31:
														case 38:
															goto IL_0e25_2;
														case 265:
														case 281:
															goto IL_0e41_2;
														case 26:
															goto IL_0e68_2;
														case 263:
															goto IL_0e76_2;
														case 55:
															goto IL_0e84_2;
														case 269:
														case 286:
															goto IL_0e97_2;
														case 242:
															goto IL_0ed5_2;
														case 214:
														case 287:
															goto IL_0ee8_2;
														case 128:
															goto IL_0f28_2;
														case 180:
															goto IL_0f3c_2;
														case 139:
														case 148:
															goto IL_0f4f_2;
														case 123:
															goto IL_0f8f_2;
														case 54:
														case 147:
															goto end_IL_0944;
														case 58:
															goto IL_105f_2;
														case 233:
															goto IL_106d_2;
														case 73:
														case 102:
															goto IL_1080_2;
														case 230:
															goto IL_10e2_2;
														case 11:
														case 203:
															goto IL_10f5_2;
														case 2:
															goto IL_1135_2;
														case 122:
															goto IL_1149_2;
														case 116:
														case 268:
															goto IL_1173_2;
														case 113:
															goto IL_1191_2;
														case 63:
															goto IL_11a8_2;
														case 149:
														case 212:
															goto IL_11bb_2;
														case 208:
															goto IL_11e4_2;
														case 46:
														case 168:
															goto IL_11fd_2;
														case 226:
															goto IL_1215_2;
														case 40:
															goto IL_1233_2;
														case 140:
															goto IL_1257_2;
														case 256:
															goto IL_1278_2;
														case 298:
															goto IL_128b_2;
														case 267:
														case 302:
															goto IL_129e_2;
														case 156:
														case 303:
															goto IL_12b1_2;
														case 30:
															goto IL_12d5_2;
														case 57:
															goto IL_12e3_2;
														case 171:
															goto IL_12f1_2;
														case 51:
														case 236:
															goto IL_1304_2;
														case 5:
															goto IL_132d_2;
														case 82:
															goto IL_133b_2;
														case 20:
														case 94:
															goto IL_134e_2;
														case 135:
															goto IL_1387_2;
														case 100:
															goto IL_139b_2;
														case 157:
														case 202:
															goto IL_13ae_2;
														case 292:
															goto IL_13c2_2;
														case 301:
															goto IL_140e_2;
														case 53:
															goto IL_141c_2;
														case 264:
															goto IL_143a_2;
														case 18:
															goto IL_1448_2;
														case 3:
														case 6:
														case 7:
														case 47:
														case 60:
														case 62:
														case 70:
														case 80:
														case 93:
														case 97:
														case 98:
														case 104:
														case 106:
														case 112:
														case 120:
														case 121:
														case 141:
														case 146:
														case 153:
														case 161:
														case 174:
														case 194:
														case 196:
														case 207:
														case 210:
														case 211:
														case 213:
														case 229:
														case 243:
														case 248:
														case 266:
														case 274:
														case 282:
														case 296:
														case 300:
															goto IL_1456_2;
														case 69:
															ptr2 = ptr;
															goto IL_1456_2;
														case 270:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setCreationTimeUtcNoCurrentDateDefault.InternetSiteAuthorityDictionary);
															goto case 69;
														case 155:
															array7[0] = this;
															goto case 270;
														case 234:
															array7 = new object[14];
															goto case 155;
														case 244:
															array6 = new long[4];
															goto case 234;
														case 81:
															array5 = new int[6];
															goto case 244;
														case 142:
															array4 = new int[4];
															goto case 81;
														case 169:
															array3 = new object[4];
															goto case 142;
														case 21:
														case 222:
															array2 = new byte[4];
															goto case 169;
														case 32:
															num3 = num2 * 4;
															goto case 21;
														case 257:
															num2 = 1;
															goto case 32;
														case 258:
															goto end_IL_0fc5;
														case 10:
														case 138:
															return;
														}
														continue;
													}
													array2[num5] = 0;
													goto IL_143a_2;
													IL_143a_2:
													num5++;
													goto IL_1448_2;
													IL_1448_2:
													ptr2 += 8;
													goto IL_1456_2;
													continue;
													end_IL_04eb_2:
													break;
												}
												continue;
												end_IL_08fd_2:
												break;
											}
											goto IL_04fe_2;
											IL_04fe_2:
											if (b <= 32)
											{
												goto IL_050c_2;
											}
											goto IL_08fd_3;
											IL_050c_2:
											if (16 >= b)
											{
												goto IL_051a_2;
											}
											goto IL_0614_2;
											IL_051a_2:
											if (16 > b)
											{
												goto IL_0528_2;
											}
											goto IL_094f_2;
											IL_0528_2:
											if (8 >= b)
											{
												goto IL_0536_2;
											}
											goto IL_07c5_2;
											IL_0536_2:
											if (8 > b)
											{
												goto IL_0544_2;
											}
											goto IL_129e_2;
											IL_0544_2:
											if (4 < b)
											{
												goto IL_054f_2;
											}
											num = 164;
											goto IL_0594_2;
											IL_054f_2:
											if (6 < b)
											{
												goto IL_055a_2;
											}
											goto IL_056d_2;
											IL_055a_2:
											if (7 >= b)
											{
												goto IL_07b2_2;
											}
											goto IL_08fd_3;
											IL_07b2_2:
											if (7 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0f4f_2;
											IL_0f4f_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_0f8f_2;
											IL_0f8f_2:
											array2[num5 - 2] = 0;
											goto IL_128b_2;
											IL_128b_2:
											num5--;
											goto IL_1456_2;
											IL_056d_2:
											if (6 > b)
											{
												goto IL_057b_2;
											}
											goto IL_0983_2;
											IL_057b_2:
											if (5 >= b)
											{
												goto IL_0601_2;
											}
											goto IL_08fd_3;
											IL_0601_2:
											if (5 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0ee8_2;
											IL_0ee8_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_0f28_2;
											IL_0f28_2:
											array2[num5 - 2] = 0;
											goto IL_0f3c_2;
											IL_0f3c_2:
											num5--;
											goto IL_1456_2;
											IL_0983_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_09c3_2;
											IL_09c3_2:
											array2[num5 - 2] = 0;
											goto IL_09d7_2;
											IL_09d7_2:
											num5--;
											goto IL_1456_2;
											IL_0d21_2:
											array2[num5 - 1] = 0;
											goto IL_1456_2;
											IL_0594_2:
											if (4 > b)
											{
												goto IL_05a2_2;
											}
											goto IL_0a67_2;
											IL_05a2_2:
											if (2 >= b)
											{
												goto IL_05ad_2;
											}
											goto IL_05d7_2;
											IL_05ad_2:
											if (2 > b)
											{
												num = 115;
												goto IL_05c4_2;
											}
											goto IL_0ac3_2;
											IL_0762_2:
											if (23 >= b)
											{
												goto IL_0770_2;
											}
											goto IL_08fd_3;
											IL_05c4_2:
											if (1 >= b)
											{
												goto IL_0783_2;
											}
											goto IL_08fd_3;
											IL_0783_2:
											if (1 <= b)
											{
												num = 167;
											}
											goto IL_08fd_3;
											IL_0770_2:
											if (23 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0d86_2;
											IL_0ac3_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_0b03_2;
											IL_0b03_2:
											array2[num5 - 2] = 0;
											goto IL_0b17_2;
											IL_0b17_2:
											num5--;
											goto IL_1456_2;
											IL_05d7_2:
											if (3 >= b)
											{
												goto IL_05e5_2;
											}
											goto IL_08fd_3;
											IL_05e5_2:
											if (3 > b)
											{
												num = 84;
												goto IL_08fd_3;
											}
											goto IL_09ea_2;
											IL_0d86_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_0dc6_2;
											IL_09ea_2:
											reference = ref array5[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_0a13_2;
											IL_0a13_2:
											ptr2 += 8;
											num = 66;
											goto IL_0a2a_2;
											IL_0a2a_2:
											num5--;
											goto IL_1456_2;
											IL_0a67_2:
											array2[num5] = 0;
											goto IL_0a75_2;
											IL_0a75_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
											goto IL_0a98_2;
											IL_0a98_2:
											array3[num5] = null;
											goto IL_0aa2_2;
											IL_0aa2_2:
											num5++;
											goto IL_0ab0_2;
											IL_0ab0_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_129e_2:
											num5--;
											goto IL_1456_2;
											IL_07c5_2:
											if (12 >= b)
											{
												goto IL_07d0_2;
											}
											num = 290;
											goto IL_0842_2;
											IL_07d0_2:
											if (12 <= b)
											{
												goto end_IL_0944;
											}
											goto IL_07de_2;
											IL_07de_2:
											if (10 >= b)
											{
												goto IL_07e9_2;
											}
											goto IL_0818_2;
											IL_07e9_2:
											if (10 > b)
											{
												goto IL_07f7_2;
											}
											goto IL_1080_2;
											IL_07f7_2:
											if (9 >= b)
											{
												goto IL_0805_2;
											}
											goto IL_08fd_3;
											IL_0805_2:
											if (9 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_10f5_2;
											IL_10f5_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_1135_2;
											IL_1135_2:
											array2[num5 - 2] = 0;
											goto IL_1149_2;
											IL_1149_2:
											num5--;
											num = 93;
											goto IL_1456_2;
											IL_1080_2:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_10e2_2;
											IL_10e2_2:
											num5 -= 2;
											goto IL_1456_2;
											IL_0818_2:
											if (11 >= b)
											{
												goto IL_0826_2;
											}
											goto IL_08fd_3;
											IL_0826_2:
											if (11 <= b)
											{
												num = 153;
												goto IL_1456_2;
											}
											goto IL_08fd_3;
											IL_0dda_2:
											num5--;
											goto IL_1456_2;
											IL_0dc6_2:
											array2[num5 - 2] = 0;
											goto IL_0dda_2;
											IL_0842_2:
											if (14 >= b)
											{
												goto IL_084d_2;
											}
											goto IL_087c_2;
											IL_084d_2:
											if (14 > b)
											{
												goto IL_085b_2;
											}
											goto IL_11bb_2;
											IL_085b_2:
											if (13 >= b)
											{
												goto IL_0869_2;
											}
											goto IL_08fd_3;
											IL_0869_2:
											if (13 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_1173_2;
											IL_1173_2:
											array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
											goto IL_1191_2;
											IL_1191_2:
											ptr2 += 8;
											num = 63;
											goto IL_11a8_2;
											IL_11a8_2:
											num5--;
											goto IL_1456_2;
											IL_11bb_2:
											array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
											goto IL_11e4_2;
											IL_11e4_2:
											array2[num5 - 1] = 5;
											goto IL_1456_2;
											IL_087c_2:
											if (15 >= b)
											{
												goto IL_0887_2;
											}
											goto IL_08fd_3;
											IL_0887_2:
											if (15 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_11fd_2;
											IL_11fd_2:
											array2[num5] = array2[num5 - 1];
											goto IL_1215_2;
											IL_1215_2:
											array4[num5 - 0] = array4[num5 - 1];
											goto IL_1233_2;
											IL_1233_2:
											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_1257_2;
											IL_1257_2:
											array3[num5] = array3[num5 - 1];
											num = 256;
											goto IL_1278_2;
											IL_1278_2:
											num5++;
											goto IL_1456_2;
											IL_094f_2:
											array2[num5] = 5;
											goto IL_095d_2;
											IL_095d_2:
											array3[num5] = array7[*(int*)(ptr2 + num3)];
											num = 231;
											goto IL_0a3d_2;
											IL_0a3d_2:
											num5++;
											num = 24;
											goto IL_0a54_2;
											IL_0a54_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0614_2:
											if (24 < b)
											{
												goto IL_0622_2;
											}
											goto IL_06b4_2;
											IL_0622_2:
											if (28 < b)
											{
												goto IL_062d_2;
											}
											num = 48;
											goto IL_06a1_2;
											IL_062d_2:
											if (30 < b)
											{
												goto IL_0638_2;
											}
											goto IL_0669_2;
											IL_0638_2:
											if (31 < b)
											{
												goto IL_0643_2;
											}
											goto IL_0656_2;
											IL_0643_2:
											if (32 >= b)
											{
												goto IL_079f_2;
											}
											goto IL_08fd_3;
											IL_079f_2:
											if (32 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0e25_2;
											IL_0e25_2:
											num9 = ptr2;
											num10 = -200;
											num4 = 1;
											ptr2 = num9 + num10;
											goto IL_1456_2;
											IL_0656_2:
											if (31 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0b2a_2;
											IL_0b2a_2:
											array2[num5 - 2] = 5;
											goto IL_0b3e_2;
											IL_0b3e_2:
											array3[num5 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((Class136)array3[num5 - 2], (IEnumerator)array3[num5 - 1]);
											num = 9;
											goto IL_0b93_2;
											IL_0b93_2:
											num5--;
											goto IL_0ba1_2;
											IL_0ba1_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0669_2:
											if (30 > b)
											{
												goto IL_0677_2;
											}
											goto IL_0bd1_2;
											IL_0677_2:
											if (29 >= b)
											{
												goto IL_0685_2;
											}
											goto IL_08fd_3;
											IL_0685_2:
											if (29 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0bb4_2;
											IL_0bb4_2:
											array3[num5] = array7[*(int*)(ptr2 + num3)];
											goto IL_0ded_2;
											IL_0ded_2:
											array2[num5] = 5;
											num = 33;
											goto IL_0e04_2;
											IL_0e04_2:
											num5++;
											goto IL_0e12_2;
											IL_0e12_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0bd1_2:
											array2[num5 - 1] = 5;
											goto IL_0be5_2;
											IL_0be5_2:
											array3[num5 - 1] = ((delegate*<Class136, IEnumerator>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((Class136)array3[num5 - 1]);
											goto IL_0c1d_2;
											IL_0c1d_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0cc9_2:
											Class9.int_1 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
											goto IL_0ce3_2;
											IL_06a1_2:
											if (28 > b)
											{
												goto IL_08a7_2;
											}
											goto IL_0c30_2;
											IL_0c30_2:
											((delegate*<void>)CursorTopSetTraits[*(int*)(ptr2 + num3)])();
											goto IL_0c45_2;
											IL_0c45_2:
											ptr2 += 8;
											num = 213;
											goto IL_1456_2;
											IL_08a7_2:
											if (26 < b)
											{
												goto IL_08b2_2;
											}
											num = 52;
											goto IL_08d6_2;
											IL_08b2_2:
											if (27 >= b)
											{
												goto IL_08bd_2;
											}
											goto IL_08fd_3;
											IL_08bd_2:
											if (27 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_1304_2;
											IL_1304_2:
											((delegate*<string, void>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
											goto IL_132d_2;
											IL_132d_2:
											num5--;
											goto IL_133b_2;
											IL_133b_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0ce3_2:
											num5--;
											goto IL_1456_2;
											IL_08d6_2:
											if (26 > b)
											{
												goto IL_08e4_2;
											}
											goto IL_13ae_2;
											IL_08e4_2:
											if (25 >= b)
											{
												goto IL_08ef_2;
											}
											goto IL_08fd_3;
											IL_08ef_2:
											if (25 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_134e_2;
											IL_134e_2:
											array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
											goto IL_1387_2;
											IL_1387_2:
											array2[num5 - 2] = 5;
											goto IL_139b_2;
											IL_139b_2:
											num5--;
											goto IL_1456_2;
											IL_13ae_2:
											array2[num5 - 2] = 5;
											goto IL_13c2_2;
											IL_13c2_2:
											array3[num5 - 2] = ((delegate*<string, string, string>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
											goto IL_140e_2;
											IL_140e_2:
											num5--;
											goto IL_141c_2;
											IL_141c_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_06b4_2:
											if (24 > b)
											{
												goto IL_06c2_2;
											}
											goto IL_0cc9_2;
											IL_06c2_2:
											if (20 >= b)
											{
												goto IL_06cd_2;
											}
											goto IL_0728_2;
											IL_06cd_2:
											if (20 > b)
											{
												goto IL_06db_2;
											}
											goto IL_0e41_2;
											IL_06db_2:
											if (18 >= b)
											{
												goto IL_06e6_2;
											}
											goto IL_0715_2;
											IL_06e6_2:
											if (18 > b)
											{
												goto IL_06f4_2;
											}
											goto IL_0c61_2;
											IL_06f4_2:
											if (17 >= b)
											{
												goto IL_0702_2;
											}
											goto IL_08fd_3;
											IL_0702_2:
											if (17 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0e97_2;
											IL_0e97_2:
											((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
											goto IL_0ed5_2;
											IL_0ed5_2:
											num5 -= 3;
											goto IL_1456_2;
											IL_0c61_2:
											array2[num5 - 1] = 5;
											num = 85;
											goto IL_0c7e_2;
											IL_0c7e_2:
											array3[num5 - 1] = ((delegate*<string[], string>)CursorTopSetTraits[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
											goto IL_0cb6_2;
											IL_0cb6_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0715_2:
											if (19 >= b)
											{
												goto IL_0897_2;
											}
											goto IL_08fd_3;
											IL_0897_2:
											if (19 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_12b1_2;
											IL_12b1_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)CursorTopSetTraits[*(int*)(ptr2 + num3)])();
											goto IL_12d5_2;
											IL_12d5_2:
											array2[num5] = 0;
											goto IL_12e3_2;
											IL_12e3_2:
											num5++;
											goto IL_12f1_2;
											IL_12f1_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0e41_2:
											array3[num5] = ((delegate*<string[]>)CursorTopSetTraits[*(int*)(ptr2 + num3)])();
											num = 26;
											goto IL_0e68_2;
											IL_0e68_2:
											array2[num5] = 5;
											goto IL_0e76_2;
											IL_0e76_2:
											num5++;
											goto IL_0e84_2;
											IL_0e84_2:
											ptr2 += 8;
											goto IL_1456_2;
											IL_0728_2:
											if (22 >= b)
											{
												goto IL_0733_2;
											}
											goto IL_0762_2;
											IL_0733_2:
											if (22 > b)
											{
												goto IL_0741_2;
											}
											goto IL_0cf6_2;
											IL_0741_2:
											if (21 >= b)
											{
												goto IL_074f_2;
											}
											goto IL_08fd_3;
											IL_074f_2:
											if (21 > b)
											{
												goto IL_08fd_3;
											}
											goto IL_0d3a_2;
											IL_0d3a_2:
											*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
											goto IL_0d64_2;
											IL_0d64_2:
											array2[num5 - 1] = 2;
											num = 141;
											goto IL_1456_2;
											IL_0cf6_2:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
											goto IL_0d21_2;
											continue;
											end_IL_0924:
											break;
										}
										continue;
										end_IL_0934:
										break;
									}
									continue;
									end_IL_0944:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_0fb7_2;
					}
					continue;
					end_IL_0fc5:
					break;
				}
				break;
			}
		}
	}

	private unsafe IEnumerator method_0()
	{
		int num = 59;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 38;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											object[] array6 = new object[1];
											while (true)
											{
												array6[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref KoreanLunisolarCalendarDSASignatureFormatter.promisebodyWithStateAndLocal);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 != 1)
															{
																while (true)
																{
																	IL_0475:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0465:
																		ptr2++;
																		while (true)
																		{
																			IL_0455:
																			if (b >= 1)
																			{
																				while (b <= 21)
																				{
																					while (true)
																					{
																						IL_0435:
																						if (11 >= b)
																						{
																							while (11 > b)
																							{
																								num = 56;
																								while (true)
																								{
																									IL_0412:
																									if (5 < b)
																									{
																										while (true)
																										{
																											IL_0402:
																											if (8 < b)
																											{
																												while (true)
																												{
																													IL_03f5:
																													if (9 >= b)
																													{
																														while (9 <= b)
																														{
																															while (true)
																															{
																																IL_03a3:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																while (true)
																																{
																																	IL_0384:
																																	array[num6 - 2] = 0;
																																	num = 213;
																																	while (true)
																																	{
																																		if (num != 213)
																																		{
																																			if (num != 1194)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 109:
																																				goto IL_0384;
																																			case 21:
																																			case 70:
																																				goto IL_03a3;
																																			case 191:
																																				goto IL_03e5;
																																			case 2:
																																			case 62:
																																				goto IL_03f5;
																																			case 90:
																																				goto IL_0402;
																																			case 1:
																																			case 56:
																																				goto IL_0412;
																																			case 101:
																																				goto IL_0422;
																																			case 26:
																																				goto IL_0435;
																																			case 171:
																																				goto IL_0445;
																																			case 24:
																																				goto IL_0455;
																																			case 66:
																																				goto IL_0465;
																																			case 135:
																																			case 186:
																																				goto IL_0475;
																																			case 31:
																																			case 93:
																																				goto IL_0480;
																																			case 127:
																																				goto IL_048e;
																																			case 5:
																																			case 112:
																																				goto IL_049c;
																																			case 12:
																																				goto IL_04fe;
																																			case 96:
																																			case 182:
																																				goto IL_0511;
																																			case 60:
																																				goto IL_051f;
																																			case 50:
																																				goto IL_052d;
																																			case 146:
																																			case 159:
																																				goto IL_053b;
																																			case 35:
																																			case 37:
																																				goto IL_0546;
																																			case 130:
																																				goto IL_0554;
																																			case 34:
																																			case 51:
																																				goto IL_0562;
																																			case 54:
																																				goto IL_05b9;
																																			case 36:
																																			case 84:
																																				goto IL_05c7;
																																			case 67:
																																				goto IL_0608;
																																			case 164:
																																				goto IL_061c;
																																			case 102:
																																				goto IL_062f;
																																			case 153:
																																				goto IL_063d;
																																			case 47:
																																				goto IL_064b;
																																			case 30:
																																			case 141:
																																				goto IL_065e;
																																			case 103:
																																				goto IL_066c;
																																			case 149:
																																				goto IL_067a;
																																			case 57:
																																			case 122:
																																				goto IL_0685;
																																			case 69:
																																				goto IL_0693;
																																			case 20:
																																				goto IL_06a6;
																																			case 80:
																																			case 143:
																																				goto IL_06b4;
																																			case 85:
																																				goto IL_06cc;
																																			case 10:
																																				goto IL_06ea;
																																			case 49:
																																				goto IL_070e;
																																			case 118:
																																				goto IL_072f;
																																			case 115:
																																			case 181:
																																				goto IL_0742;
																																			case 45:
																																				goto IL_0778;
																																			case 107:
																																				goto IL_078b;
																																			case 11:
																																				goto IL_0799;
																																			case 29:
																																			case 166:
																																				goto IL_07a7;
																																			case 9:
																																			case 183:
																																				goto IL_07c3;
																																			case 185:
																																				goto IL_07db;
																																			case 97:
																																			case 193:
																																				goto IL_07ee;
																																			case 27:
																																				goto IL_0802;
																																			case 99:
																																			case 194:
																																				goto IL_083d;
																																			case 73:
																																				goto IL_0856;
																																			case 190:
																																				goto IL_0864;
																																			case 126:
																																				goto IL_0872;
																																			case 196:
																																				goto IL_0885;
																																			case 110:
																																			case 200:
																																				goto IL_0898;
																																			case 173:
																																				goto IL_08b0;
																																			case 7:
																																				goto IL_08c7;
																																			case 175:
																																				goto IL_08d5;
																																			case 61:
																																			case 203:
																																				goto IL_08f1;
																																			case 43:
																																				goto IL_08ff;
																																			case 16:
																																				goto IL_0925;
																																			case 156:
																																			case 188:
																																				goto IL_0930;
																																			case 177:
																																				goto IL_0943;
																																			case 169:
																																			case 189:
																																				goto IL_0951;
																																			case 180:
																																				goto IL_095f;
																																			case 152:
																																			case 178:
																																				goto IL_0978;
																																			case 151:
																																				goto IL_09b8;
																																			case 55:
																																				goto IL_09d5;
																																			case 71:
																																				goto IL_09e8;
																																			case 13:
																																			case 94:
																																				goto IL_09f6;
																																			case 86:
																																				goto IL_0a3f;
																																			case 64:
																																				goto IL_0a53;
																																			case 137:
																																				goto IL_0a66;
																																			case 79:
																																			case 111:
																																				goto end_IL_0371;
																																			case 0:
																																			case 106:
																																				goto IL_0a82;
																																			case 128:
																																			case 134:
																																				goto IL_0a90;
																																			case 154:
																																				goto IL_0aa9;
																																			case 72:
																																			case 206:
																																				goto IL_0ab7;
																																			case 52:
																																				goto IL_0ac5;
																																			case 201:
																																				goto IL_0ae8;
																																			case 138:
																																				goto IL_0af2;
																																			case 83:
																																				goto IL_0b00;
																																			case 113:
																																				goto IL_0b13;
																																			case 129:
																																			case 192:
																																				goto IL_0b21;
																																			case 40:
																																				goto IL_0b4a;
																																			case 121:
																																				goto IL_0b58;
																																			case 23:
																																				goto IL_0b6b;
																																			case 25:
																																			case 46:
																																				goto IL_0b76;
																																			case 98:
																																				goto IL_0bb6;
																																			case 172:
																																				goto IL_0bca;
																																			case 167:
																																				goto IL_0bdd;
																																			case 117:
																																				goto IL_0beb;
																																			case 33:
																																			case 144:
																																				goto IL_0bf9;
																																			case 100:
																																				goto IL_0c1b;
																																			case 39:
																																				goto IL_0c29;
																																			case 136:
																																				goto IL_0c37;
																																			case 88:
																																			case 187:
																																				goto IL_0c4a;
																																			case 198:
																																				goto IL_0c93;
																																			case 124:
																																				goto IL_0ca7;
																																			case 3:
																																			case 15:
																																			case 17:
																																			case 18:
																																			case 19:
																																			case 28:
																																			case 42:
																																			case 44:
																																			case 48:
																																			case 53:
																																			case 63:
																																			case 65:
																																			case 68:
																																			case 75:
																																			case 76:
																																			case 89:
																																			case 91:
																																			case 92:
																																			case 116:
																																			case 119:
																																			case 125:
																																			case 131:
																																			case 132:
																																			case 139:
																																			case 147:
																																			case 148:
																																			case 158:
																																			case 161:
																																			case 163:
																																			case 165:
																																			case 168:
																																			case 176:
																																			case 179:
																																			case 199:
																																			case 202:
																																			case 204:
																																				goto end_IL_03e5;
																																			case 4:
																																			case 6:
																																			case 8:
																																			case 14:
																																			case 32:
																																			case 41:
																																			case 77:
																																			case 78:
																																			case 81:
																																			case 87:
																																			case 104:
																																			case 105:
																																			case 108:
																																			case 120:
																																			case 140:
																																			case 142:
																																			case 145:
																																			case 155:
																																			case 157:
																																			case 160:
																																			case 162:
																																			case 170:
																																			case 184:
																																			case 197:
																																				goto end_IL_0422;
																																			case 205:
																																				goto end_IL_0cca;
																																			case 174:
																																				goto end_IL_0cdd;
																																			case 82:
																																				goto end_IL_0ce7;
																																			case 123:
																																				goto end_IL_0cf2;
																																			case 22:
																																				goto end_IL_0d02;
																																			case 150:
																																				goto end_IL_0d12;
																																			case 195:
																																				goto end_IL_0d22;
																																			case 95:
																																				goto end_IL_0d32;
																																			case 133:
																																				goto end_IL_0d42;
																																			case 38:
																																				goto end_IL_0d52;
																																			case 58:
																																				goto end_IL_0d62;
																																			case 59:
																																				goto end_IL_0d72;
																																			case 74:
																																			case 114:
																																				goto IL_0d96;
																																			}
																																			continue;
																																		}
																																		num6--;
																																		goto end_IL_0422;
																																		continue;
																																		end_IL_0371:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_0a74;
																															continue;
																															end_IL_03e5:
																															break;
																															IL_03e5:;
																														}
																														break;
																													}
																													goto IL_0480;
																													IL_04fe:
																													num6 -= 2;
																													goto end_IL_0422;
																													IL_0480:
																													if (10 < b)
																													{
																														break;
																													}
																													goto IL_048e;
																													IL_048e:
																													if (10 > b)
																													{
																														break;
																													}
																													goto IL_049c;
																													IL_049c:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_04fe;
																												}
																												break;
																											}
																											goto IL_0925;
																											IL_0a3f:
																											array[num6 - 2] = 0;
																											goto IL_0a53;
																											IL_0925:
																											if (8 <= b)
																											{
																												goto IL_0930;
																											}
																											goto IL_0943;
																											IL_0930:
																											num6--;
																											goto end_IL_0422;
																											IL_0943:
																											if (6 < b)
																											{
																												goto IL_0951;
																											}
																											goto IL_09e8;
																											IL_0951:
																											if (7 < b)
																											{
																												break;
																											}
																											goto IL_095f;
																											IL_095f:
																											if (7 > b)
																											{
																												num = 68;
																												break;
																											}
																											goto IL_0978;
																											IL_0a53:
																											num6--;
																											goto end_IL_0422;
																											IL_0978:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_09b8;
																											IL_09b8:
																											array[num6 - 2] = 0;
																											num = 55;
																											goto IL_09d5;
																											IL_09d5:
																											num6--;
																											goto end_IL_0422;
																											IL_09e8:
																											if (6 > b)
																											{
																												break;
																											}
																											goto IL_09f6;
																											IL_09f6:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											num = 86;
																											goto IL_0a3f;
																										}
																										break;
																									}
																									goto IL_0a66;
																									IL_0c93:
																									array[num6 - 2] = 0;
																									goto IL_0ca7;
																									IL_0a66:
																									if (5 > b)
																									{
																										goto IL_0a74;
																									}
																									goto IL_0c4a;
																									IL_0a74:
																									if (2 < b)
																									{
																										goto IL_0a82;
																									}
																									goto IL_0b6b;
																									IL_0a82:
																									if (3 < b)
																									{
																										goto IL_0a90;
																									}
																									goto IL_0b13;
																									IL_0a90:
																									if (4 < b)
																									{
																										num = 42;
																										break;
																									}
																									goto IL_0aa9;
																									IL_0ca7:
																									num6--;
																									goto end_IL_0422;
																									IL_0aa9:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_0ab7;
																									IL_0ab7:
																									array[num6] = 0;
																									goto IL_0ac5;
																									IL_0ac5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																									goto IL_0ae8;
																									IL_0ae8:
																									array2[num6] = null;
																									goto IL_0af2;
																									IL_0af2:
																									num6++;
																									goto IL_0b00;
																									IL_0b00:
																									ptr2 += 8;
																									goto end_IL_0422;
																									IL_0b13:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0b21;
																									IL_0b21:
																									ref int reference = ref array4[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_0b4a;
																									IL_0b4a:
																									ptr2 += 8;
																									goto IL_0b58;
																									IL_0b58:
																									num6--;
																									goto end_IL_0422;
																									IL_0b6b:
																									if (2 <= b)
																									{
																										goto IL_0b76;
																									}
																									goto IL_0bdd;
																									IL_0b76:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_0bb6;
																									IL_0bb6:
																									array[num6 - 2] = 0;
																									goto IL_0bca;
																									IL_0bca:
																									num6--;
																									goto end_IL_0422;
																									IL_0bdd:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_0beb;
																									IL_0beb:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_0bf9;
																									IL_0bf9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																									num = 100;
																									goto IL_0c1b;
																									IL_0c1b:
																									array[num6] = 0;
																									goto IL_0c29;
																									IL_0c29:
																									num6++;
																									goto IL_0c37;
																									IL_0c37:
																									ptr2 += 8;
																									goto end_IL_0422;
																									IL_0c4a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									num = 198;
																									goto IL_0c93;
																								}
																								goto end_IL_0445;
																								continue;
																								end_IL_0422:
																								break;
																								IL_0422:;
																							}
																							break;
																						}
																						goto IL_0511;
																						IL_08ff:
																						if (21 <= b)
																						{
																						}
																						goto end_IL_0445;
																						IL_0511:
																						if (16 >= b)
																						{
																							goto IL_051f;
																						}
																						goto IL_065e;
																						IL_051f:
																						if (16 > b)
																						{
																							goto IL_052d;
																						}
																						goto IL_07ee;
																						IL_052d:
																						if (13 < b)
																						{
																							goto IL_053b;
																						}
																						goto IL_062f;
																						IL_053b:
																						if (14 < b)
																						{
																							goto IL_0546;
																						}
																						goto IL_05b9;
																						IL_0546:
																						if (15 < b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_0554;
																						IL_0554:
																						if (15 > b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_0562;
																						IL_0562:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_07db;
																						IL_07db:
																						num6--;
																						break;
																						IL_05b9:
																						if (14 > b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_05c7;
																						IL_05c7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																						goto IL_0608;
																						IL_0608:
																						array[num6 - 2] = 0;
																						goto IL_061c;
																						IL_061c:
																						num6--;
																						break;
																						IL_062f:
																						if (13 > b)
																						{
																							goto IL_063d;
																						}
																						goto IL_07c3;
																						IL_063d:
																						if (12 < b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_064b;
																						IL_064b:
																						if (12 > b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_083d;
																						IL_083d:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0856;
																						IL_0856:
																						array[num6] = 1;
																						goto IL_0864;
																						IL_0864:
																						num6++;
																						goto IL_0872;
																						IL_0872:
																						ptr2 += 16;
																						break;
																						IL_07c3:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_07ee:
																						array[num6 - 1] = 5;
																						goto IL_0802;
																						IL_0802:
																						array2[num6 - 1] = ((delegate*<int, _003CDelayedDestroy_003Ed__1>)getIsNotPublicEras[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_0885;
																						IL_0885:
																						ptr2 += 8;
																						break;
																						IL_065e:
																						if (19 >= b)
																						{
																							goto IL_066c;
																						}
																						goto IL_078b;
																						IL_066c:
																						if (19 > b)
																						{
																							goto IL_067a;
																						}
																						goto IL_0742;
																						IL_067a:
																						if (17 < b)
																						{
																							goto IL_0685;
																						}
																						goto IL_06a6;
																						IL_0685:
																						if (18 < b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_0693;
																						IL_0693:
																						if (18 > b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_0898;
																						IL_0898:
																						array2[num6] = array6[*(int*)(ptr2 + num3)];
																						goto IL_08b0;
																						IL_08b0:
																						array[num6] = 5;
																						num = 7;
																						goto IL_08c7;
																						IL_08c7:
																						num6++;
																						goto IL_08d5;
																						IL_08d5:
																						ptr2 += 8;
																						num = 8;
																						break;
																						IL_06a6:
																						if (17 > b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_06b4;
																						IL_06b4:
																						array[num6] = array[num6 - 1];
																						goto IL_06cc;
																						IL_06cc:
																						array3[num6 - 0] = array3[num6 - 1];
																						goto IL_06ea;
																						IL_06ea:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_070e;
																						IL_070e:
																						array2[num6] = array2[num6 - 1];
																						num = 118;
																						goto IL_072f;
																						IL_072f:
																						num6++;
																						break;
																						IL_0742:
																						((_003CDelayedDestroy_003Ed__1)array2[num6 - 2]).class136_0 = (Class136)array2[num6 - 1];
																						num = 45;
																						goto IL_0778;
																						IL_0778:
																						num6 -= 2;
																						break;
																						IL_078b:
																						if (20 >= b)
																						{
																							goto IL_0799;
																						}
																						goto IL_08f1;
																						IL_0799:
																						if (20 > b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_07a7;
																						IL_07a7:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						break;
																						IL_08f1:
																						if (21 < b)
																						{
																							goto end_IL_0445;
																						}
																						goto IL_08ff;
																					}
																					goto end_IL_0455;
																					continue;
																					end_IL_0445:
																					break;
																					IL_0445:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_0455:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
															}
															goto IL_0d96;
															IL_0d96:
															return (IEnumerator)array2[num6 - 1];
															continue;
															end_IL_0cca:
															break;
														}
														continue;
														end_IL_0cdd:
														break;
													}
													continue;
													end_IL_0ce7:
													break;
												}
												continue;
												end_IL_0cf2:
												break;
											}
											continue;
											end_IL_0d02:
											break;
										}
										continue;
										end_IL_0d12:
										break;
									}
									continue;
									end_IL_0d22:
									break;
								}
								continue;
								end_IL_0d32:
								break;
							}
							continue;
							end_IL_0d42:
							break;
						}
						continue;
						end_IL_0d52:
						break;
					}
					continue;
					end_IL_0d62:
					break;
				}
				continue;
				end_IL_0d72:
				break;
			}
		}
	}

	public Class136()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3)
	{
		int num = 71;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 45;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VTARRAYRequestedExecutionLevel.SafeRegistryHandleGetResponse);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 118;
												while (true)
												{
													if (num == 118)
													{
														goto IL_0293;
													}
													if (num != 1099)
													{
														goto IL_05e1;
													}
													switch (num)
													{
													case 100:
														goto end_IL_01e7;
													case 53:
														goto end_IL_01fa;
													case 87:
														goto end_IL_020d;
													case 109:
														goto end_IL_0218;
													case 45:
														goto end_IL_022d;
													case 96:
														goto end_IL_023d;
													case 40:
														goto end_IL_024d;
													case 62:
													case 104:
														goto end_IL_0258;
													case 70:
														goto end_IL_0268;
													case 71:
														goto end_IL_0278;
													case 21:
													case 22:
													case 41:
													case 47:
													case 50:
													case 60:
													case 64:
													case 69:
													case 72:
													case 73:
													case 78:
													case 89:
													case 108:
														goto IL_0293;
													case 16:
													case 83:
														goto IL_02a3;
													case 20:
														goto IL_02ac;
													case 25:
														goto IL_02ba;
													case 0:
														goto IL_02c8;
													case 98:
														goto IL_02d6;
													case 79:
														goto IL_02e4;
													case 54:
														goto IL_02f2;
													case 19:
													case 35:
														goto IL_0300;
													case 10:
													case 29:
														goto IL_030b;
													case 13:
														goto IL_0319;
													case 36:
													case 85:
														goto IL_0327;
													case 90:
														goto IL_034a;
													case 82:
														goto IL_0358;
													case 63:
														goto IL_0366;
													case 37:
														goto IL_0379;
													case 105:
													case 110:
														goto IL_0387;
													case 28:
														goto IL_03c7;
													case 39:
														goto IL_03db;
													case 81:
													case 95:
														goto IL_03f7;
													case 26:
														goto IL_0459;
													case 65:
														goto IL_046c;
													case 34:
														goto IL_0477;
													case 84:
													case 91:
														goto IL_0482;
													case 30:
														goto IL_04ac;
													case 31:
														goto IL_04ba;
													case 61:
														goto IL_04cd;
													case 11:
													case 24:
														goto IL_04d8;
													case 38:
														goto IL_0518;
													case 27:
														goto IL_052c;
													case 56:
														goto IL_053f;
													case 32:
														goto IL_054d;
													case 1:
													case 9:
														goto IL_0558;
													case 15:
														goto IL_0570;
													case 3:
													case 23:
														goto IL_057b;
													case 44:
														goto IL_0589;
													case 14:
													case 94:
														goto IL_0597;
													case 51:
														goto IL_05c0;
													case 7:
														goto IL_05ce;
													case 48:
														goto IL_05e1;
													case 88:
													case 102:
														goto IL_05ef;
													case 107:
														goto IL_0608;
													case 2:
														goto IL_0616;
													case 75:
														goto IL_0624;
													case 18:
														goto IL_0637;
													case 46:
														goto IL_0642;
													case 4:
														goto IL_0652;
													case 97:
														goto IL_065d;
													case 57:
													case 111:
														goto IL_0668;
													case 58:
														goto IL_0676;
													case 80:
														goto IL_0699;
													case 49:
														goto IL_06a3;
													case 103:
														goto IL_06b1;
													case 5:
													case 6:
													case 12:
													case 33:
													case 42:
													case 43:
													case 52:
													case 55:
													case 59:
													case 66:
													case 67:
													case 68:
													case 74:
													case 76:
													case 77:
													case 86:
													case 92:
													case 93:
													case 99:
													case 101:
													case 106:
														goto IL_06c4;
													case 8:
													case 17:
														goto IL_06dc;
													}
													continue;
													IL_06a3:
													num4++;
													goto IL_06b1;
													IL_06b1:
													ptr2 += 8;
													goto IL_0293;
													IL_0293:
													if (num5 != 1)
													{
														goto IL_02a3;
													}
													goto IL_06dc;
													IL_06dc:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_02a3:
													b = *ptr2;
													goto IL_02ac;
													IL_02ac:
													ptr2++;
													goto IL_02ba;
													IL_02ba:
													if (b >= 1)
													{
														goto IL_02c8;
													}
													goto IL_06c4;
													IL_02c8:
													if (b <= 11)
													{
														goto IL_02d6;
													}
													goto IL_06c4;
													IL_02d6:
													if (6 < b)
													{
														goto IL_02e4;
													}
													goto IL_04cd;
													IL_02e4:
													if (9 >= b)
													{
														goto IL_02f2;
													}
													goto IL_046c;
													IL_02f2:
													if (9 > b)
													{
														goto IL_0300;
													}
													goto IL_03f7;
													IL_0300:
													if (7 < b)
													{
														goto IL_030b;
													}
													goto IL_0379;
													IL_030b:
													if (8 >= b)
													{
														goto IL_0319;
													}
													goto IL_06c4;
													IL_0319:
													if (8 <= b)
													{
														goto IL_0327;
													}
													goto IL_06c4;
													IL_0327:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_034a;
													IL_034a:
													array[num4] = 0;
													goto IL_0358;
													IL_0358:
													num4++;
													goto IL_0366;
													IL_0366:
													ptr2 += 8;
													goto IL_0293;
													IL_0379:
													if (7 <= b)
													{
														goto IL_0387;
													}
													goto IL_06c4;
													IL_0387:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_03c7;
													IL_03c7:
													array[num4 - 2] = 0;
													goto IL_03db;
													IL_03db:
													num4--;
													num = 108;
													goto IL_0293;
													IL_03f7:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_0459;
													IL_0459:
													num4 -= 2;
													goto IL_0293;
													IL_046c:
													if (10 >= b)
													{
														goto IL_0477;
													}
													goto IL_04ac;
													IL_0477:
													if (10 <= b)
													{
														goto IL_0482;
													}
													num = 68;
													goto IL_06c4;
													IL_0482:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_0293;
													IL_06c4:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0293;
													IL_04ac:
													if (11 >= b)
													{
														goto IL_04ba;
													}
													goto IL_06c4;
													IL_04ba:
													if (11 > b)
													{
													}
													goto IL_06c4;
													IL_04cd:
													if (6 <= b)
													{
														goto IL_04d8;
													}
													goto IL_053f;
													IL_04d8:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0518;
													IL_0518:
													array[num4 - 2] = 0;
													goto IL_052c;
													IL_052c:
													num4--;
													goto IL_0293;
													IL_053f:
													if (3 >= b)
													{
														goto IL_054d;
													}
													goto IL_0637;
													IL_054d:
													if (3 <= b)
													{
														goto IL_0558;
													}
													goto IL_0570;
													IL_0558:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0293;
													IL_0570:
													if (1 < b)
													{
														goto IL_057b;
													}
													goto IL_05e1;
													IL_057b:
													if (2 >= b)
													{
														goto IL_0589;
													}
													goto IL_06c4;
													IL_0589:
													if (2 <= b)
													{
														goto IL_0597;
													}
													goto IL_06c4;
													IL_0597:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_05c0;
													IL_05c0:
													ptr2 += 8;
													goto IL_05ce;
													IL_05ce:
													num4--;
													goto IL_0293;
													IL_05e1:
													if (1 <= b)
													{
														goto IL_05ef;
													}
													goto IL_06c4;
													IL_05ef:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
													goto IL_0608;
													IL_0608:
													array[num4] = 0;
													goto IL_0616;
													IL_0616:
													num4++;
													goto IL_0624;
													IL_0624:
													ptr2 += 8;
													goto IL_0293;
													IL_0637:
													if (4 >= b)
													{
														goto IL_0642;
													}
													goto IL_0652;
													IL_0642:
													if (4 <= b)
													{
														goto IL_0293;
													}
													goto IL_06c4;
													IL_0652:
													if (5 >= b)
													{
														goto IL_065d;
													}
													goto IL_06c4;
													IL_065d:
													if (5 <= b)
													{
														goto IL_0668;
													}
													goto IL_06c4;
													IL_0668:
													array[num4] = 0;
													goto IL_0676;
													IL_0676:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0699;
													IL_0699:
													array2[num4] = null;
													goto IL_06a3;
													continue;
													end_IL_01e7:
													break;
												}
												continue;
												end_IL_01fa:
												break;
											}
											continue;
											end_IL_020d:
											break;
										}
										continue;
										end_IL_0218:
										break;
									}
									continue;
									end_IL_022d:
									break;
								}
								continue;
								end_IL_023d:
								break;
							}
							continue;
							end_IL_024d:
							break;
						}
						continue;
						end_IL_0258:
						break;
					}
					continue;
					end_IL_0268:
					break;
				}
				continue;
				end_IL_0278:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_3, int int_4)
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 43;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 54;
								while (true)
								{
									int[] array3 = new int[5];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											array3[0] = int_3;
											while (true)
											{
												array3[1] = int_4;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref addResourceResolveHStringMarshaler.globalQueueTailKeySizes);
													while (true)
													{
														byte* ptr2 = ptr;
														num = 26;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_022c:
																			if (b >= 1)
																			{
																				while (b <= 9)
																				{
																					while (true)
																					{
																						IL_020c:
																						if (5 >= b)
																						{
																							goto IL_03ee;
																						}
																						while (true)
																						{
																							IL_01fc:
																							if (7 >= b)
																							{
																								num = 115;
																								while (true)
																								{
																									if (num != 115)
																									{
																										if (num != 1096)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 29:
																										case 90:
																											goto IL_01fc;
																										case 0:
																											goto IL_020c;
																										case 71:
																											goto end_IL_020c;
																										case 40:
																											goto IL_022c;
																										case 67:
																											goto end_IL_022c;
																										case 62:
																										case 72:
																											goto end_IL_023c;
																										case 61:
																											goto IL_0257;
																										case 24:
																											goto IL_0262;
																										case 10:
																										case 86:
																											goto IL_0270;
																										case 39:
																											goto IL_02b0;
																										case 23:
																											goto IL_02c4;
																										case 56:
																										case 99:
																											goto IL_02d7;
																										case 96:
																											goto IL_02e5;
																										case 31:
																										case 65:
																											goto IL_02f3;
																										case 75:
																										case 98:
																											goto IL_031a;
																										case 78:
																											goto IL_0333;
																										case 55:
																											goto IL_034a;
																										case 46:
																											goto IL_0358;
																										case 92:
																											goto IL_036b;
																										case 73:
																											goto IL_0379;
																										case 18:
																										case 57:
																											goto IL_0387;
																										case 12:
																											goto IL_03c7;
																										case 82:
																											goto IL_03db;
																										case 85:
																											goto IL_03ee;
																										case 32:
																										case 89:
																											goto IL_03fc;
																										case 102:
																										case 104:
																											goto IL_040a;
																										case 51:
																											goto IL_0415;
																										case 6:
																										case 105:
																											goto IL_0423;
																										case 106:
																											goto IL_044c;
																										case 84:
																											goto IL_045a;
																										case 2:
																										case 9:
																											goto IL_046d;
																										case 5:
																											goto IL_047b;
																										case 34:
																										case 66:
																											goto IL_0489;
																										case 94:
																											goto IL_04c9;
																										case 107:
																											goto IL_04dd;
																										case 45:
																											goto IL_04f0;
																										case 38:
																										case 83:
																											goto IL_04fb;
																										case 17:
																											goto IL_0512;
																										case 15:
																										case 52:
																											goto IL_0525;
																										case 97:
																											goto IL_0565;
																										case 63:
																											goto IL_0579;
																										case 37:
																										case 101:
																											goto IL_058c;
																										case 103:
																											goto end_IL_01e9;
																										case 14:
																											goto IL_05bd;
																										case 30:
																											goto IL_05c7;
																										case 60:
																											goto IL_05de;
																										case 7:
																										case 8:
																										case 11:
																										case 13:
																										case 22:
																										case 25:
																										case 28:
																										case 33:
																										case 35:
																										case 42:
																										case 44:
																										case 47:
																										case 48:
																										case 53:
																										case 58:
																										case 68:
																										case 69:
																										case 70:
																										case 91:
																										case 108:
																											goto end_IL_021c;
																										case 93:
																											goto IL_0611;
																										case 64:
																											goto IL_061f;
																										case 80:
																											goto IL_062d;
																										case 1:
																										case 16:
																										case 20:
																										case 26:
																										case 27:
																										case 41:
																										case 49:
																										case 74:
																										case 88:
																										case 95:
																										case 100:
																											goto end_IL_024c;
																										case 4:
																											goto end_IL_063b;
																										case 87:
																											goto end_IL_064e;
																										case 21:
																											goto end_IL_0661;
																										case 79:
																											goto end_IL_066c;
																										case 19:
																											goto end_IL_0681;
																										case 54:
																											goto end_IL_0696;
																										case 59:
																											goto end_IL_06a6;
																										case 3:
																											goto end_IL_06b6;
																										case 43:
																											goto end_IL_06c1;
																										case 81:
																											goto end_IL_06d1;
																										case 76:
																											goto end_IL_06e1;
																										case 77:
																											goto end_IL_06ec;
																										case 36:
																										case 50:
																											goto IL_0707;
																										}
																										continue;
																									}
																									if (7 <= b)
																									{
																										goto IL_031a;
																									}
																									goto IL_036b;
																									IL_0387:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03c7;
																									IL_03db:
																									num5--;
																									goto end_IL_024c;
																									IL_03c7:
																									array[num5 - 2] = 0;
																									goto IL_03db;
																									IL_031a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0333;
																									IL_0333:
																									array[num5] = 0;
																									num = 55;
																									goto IL_034a;
																									IL_034a:
																									num5++;
																									goto IL_0358;
																									IL_0358:
																									ptr2 += 8;
																									goto end_IL_024c;
																									IL_036b:
																									if (6 < b)
																									{
																										goto end_IL_021c;
																									}
																									goto IL_0379;
																									IL_0379:
																									if (6 > b)
																									{
																										goto end_IL_021c;
																									}
																									goto IL_0387;
																									continue;
																									end_IL_01e9:
																									break;
																								}
																								break;
																							}
																							goto IL_0257;
																							IL_02e5:
																							if (9 > b)
																							{
																								goto end_IL_021c;
																							}
																							goto IL_02f3;
																							IL_02f3:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_024c;
																							IL_0257:
																							if (8 >= b)
																							{
																								goto IL_0262;
																							}
																							goto IL_02d7;
																							IL_0262:
																							if (8 > b)
																							{
																								goto end_IL_021c;
																							}
																							goto IL_0270;
																							IL_0270:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_02b0;
																							IL_02b0:
																							array[num5 - 2] = 0;
																							goto IL_02c4;
																							IL_02c4:
																							num5--;
																							goto end_IL_024c;
																							IL_02d7:
																							if (9 < b)
																							{
																								goto end_IL_021c;
																							}
																							goto IL_02e5;
																						}
																						goto IL_059a;
																						IL_05c7:
																						num5++;
																						num = 60;
																						goto IL_05de;
																						IL_03ee:
																						if (5 > b)
																						{
																							goto IL_03fc;
																						}
																						goto IL_058c;
																						IL_03fc:
																						if (2 < b)
																						{
																							goto IL_040a;
																						}
																						goto IL_04f0;
																						IL_040a:
																						if (3 >= b)
																						{
																							goto IL_0415;
																						}
																						goto IL_046d;
																						IL_0415:
																						if (3 > b)
																						{
																							goto end_IL_021c;
																						}
																						goto IL_0423;
																						IL_0423:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_044c;
																						IL_044c:
																						ptr2 += 8;
																						goto IL_045a;
																						IL_045a:
																						num5--;
																						goto end_IL_024c;
																						IL_046d:
																						if (4 < b)
																						{
																							goto end_IL_021c;
																						}
																						goto IL_047b;
																						IL_047b:
																						if (4 > b)
																						{
																							goto end_IL_021c;
																						}
																						goto IL_0489;
																						IL_0489:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04c9;
																						IL_04c9:
																						array[num5 - 2] = 0;
																						goto IL_04dd;
																						IL_04dd:
																						num5--;
																						goto end_IL_024c;
																						IL_04f0:
																						if (2 > b)
																						{
																							goto IL_04fb;
																						}
																						goto IL_0525;
																						IL_04fb:
																						if (1 < b)
																						{
																							goto end_IL_021c;
																						}
																						num = 17;
																						goto IL_0512;
																						IL_05de:
																						ptr2 += 8;
																						goto end_IL_024c;
																						IL_0512:
																						if (1 > b)
																						{
																						}
																						goto end_IL_021c;
																						IL_0525:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0565;
																						IL_0565:
																						array[num5 - 2] = 0;
																						goto IL_0579;
																						IL_0579:
																						num5--;
																						goto end_IL_024c;
																						IL_058c:
																						array[num5] = 0;
																						goto IL_059a;
																						IL_059a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05bd;
																						IL_05bd:
																						array2[num5] = null;
																						goto IL_05c7;
																						continue;
																						end_IL_020c:
																						break;
																					}
																					continue;
																					end_IL_021c:
																					break;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0611;
																			IL_062d:
																			ptr2 += 8;
																			goto end_IL_024c;
																			IL_061f:
																			num5++;
																			goto IL_062d;
																			IL_0611:
																			array[num5] = 0;
																			goto IL_061f;
																			continue;
																			end_IL_022c:
																			break;
																		}
																		continue;
																		end_IL_023c:
																		break;
																	}
																	continue;
																	end_IL_024c:
																	break;
																}
																continue;
															}
															goto IL_0707;
															IL_0707:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															continue;
															end_IL_063b:
															break;
														}
														continue;
														end_IL_064e:
														break;
													}
													continue;
													end_IL_0661:
													break;
												}
												continue;
												end_IL_066c:
												break;
											}
											continue;
											end_IL_0681:
											break;
										}
										continue;
										end_IL_0696:
										break;
									}
									continue;
									end_IL_06a6:
									break;
								}
								continue;
								end_IL_06b6:
								break;
							}
							continue;
							end_IL_06c1:
							break;
						}
						continue;
						end_IL_06d1:
						break;
					}
					continue;
					end_IL_06e1:
					break;
				}
				continue;
				end_IL_06ec:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3, int int_4)
	{
		int num = 73;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct83.RoundSafeCspHandle);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 49;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0268:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_0248:
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_0238:
																							if (7 >= b)
																							{
																								while (true)
																								{
																									IL_022b:
																									if (7 <= b)
																									{
																										while (true)
																										{
																											IL_0207:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											num = 97;
																											while (true)
																											{
																												IL_01f7:
																												array[num5] = 0;
																												while (true)
																												{
																													IL_01de:
																													num5++;
																													num = 111;
																													while (true)
																													{
																														if (num != 111)
																														{
																															if (num != 1092)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 56:
																																goto IL_01de;
																															case 97:
																																goto IL_01f7;
																															case 17:
																															case 44:
																																goto IL_0207;
																															case 39:
																																goto IL_022b;
																															case 4:
																																goto IL_0238;
																															case 102:
																																goto IL_0248;
																															case 22:
																																goto end_IL_0248;
																															case 26:
																																goto IL_0268;
																															case 29:
																																goto end_IL_0268;
																															case 49:
																																goto end_IL_0278;
																															case 51:
																																goto end_IL_0288;
																															case 21:
																															case 31:
																																goto IL_029e;
																															case 71:
																																goto IL_02ac;
																															case 9:
																															case 47:
																																goto IL_02c5;
																															case 20:
																																goto IL_0305;
																															case 3:
																																goto IL_0319;
																															case 88:
																																goto IL_032c;
																															case 38:
																															case 61:
																																goto IL_033a;
																															case 92:
																																goto IL_0348;
																															case 65:
																																goto IL_036b;
																															case 7:
																																goto end_IL_01cb;
																															case 79:
																																goto IL_038c;
																															case 86:
																															case 98:
																																goto IL_039f;
																															case 10:
																																goto IL_03aa;
																															case 60:
																																goto IL_03b8;
																															case 6:
																															case 35:
																																goto IL_03c6;
																															case 74:
																																goto IL_03e2;
																															case 82:
																															case 93:
																																goto IL_03f0;
																															case 55:
																																goto IL_0430;
																															case 67:
																																goto IL_0444;
																															case 14:
																															case 100:
																																goto IL_0457;
																															case 5:
																																goto IL_0465;
																															case 64:
																															case 69:
																																goto IL_0470;
																															case 33:
																																goto IL_047e;
																															case 25:
																															case 83:
																																goto IL_0491;
																															case 32:
																																goto IL_04d1;
																															case 101:
																																goto IL_04f2;
																															case 48:
																															case 103:
																																goto IL_0505;
																															case 70:
																																goto IL_0510;
																															case 15:
																															case 50:
																																goto IL_051e;
																															case 37:
																																goto IL_0547;
																															case 68:
																																goto IL_0555;
																															case 46:
																																goto IL_0568;
																															case 53:
																																goto IL_0573;
																															case 19:
																															case 81:
																																goto IL_057e;
																															case 23:
																																goto IL_05be;
																															case 24:
																																goto IL_05d2;
																															case 8:
																															case 18:
																															case 28:
																															case 30:
																															case 42:
																															case 43:
																															case 45:
																															case 52:
																															case 59:
																															case 66:
																															case 84:
																															case 87:
																															case 89:
																															case 94:
																															case 95:
																															case 99:
																															case 104:
																																goto end_IL_0258;
																															case 13:
																																goto IL_061e;
																															case 57:
																																goto IL_0635;
																															case 41:
																																goto IL_0643;
																															case 0:
																															case 27:
																															case 34:
																															case 54:
																															case 58:
																															case 62:
																															case 63:
																															case 76:
																															case 80:
																															case 90:
																															case 91:
																																goto end_IL_0293;
																															case 40:
																																goto end_IL_0651;
																															case 85:
																																goto end_IL_0664;
																															case 11:
																																goto end_IL_066e;
																															case 96:
																																goto end_IL_0679;
																															case 77:
																																goto end_IL_068e;
																															case 2:
																															case 78:
																																goto end_IL_06a3;
																															case 1:
																																goto end_IL_06b3;
																															case 16:
																															case 75:
																																goto end_IL_06c3;
																															case 72:
																																goto end_IL_06d3;
																															case 73:
																																goto end_IL_06e3;
																															case 12:
																															case 36:
																																goto IL_06fe;
																															}
																															continue;
																														}
																														ptr2 += 8;
																														goto end_IL_0293;
																														continue;
																														end_IL_01cb:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_029e;
																									IL_0305:
																									array[num5 - 2] = 0;
																									goto IL_0319;
																									IL_029e:
																									if (6 < b)
																									{
																										goto end_IL_0258;
																									}
																									goto IL_02ac;
																									IL_02ac:
																									if (6 > b)
																									{
																										num = 42;
																										goto end_IL_0258;
																									}
																									goto IL_02c5;
																									IL_0319:
																									num5--;
																									goto end_IL_0293;
																									IL_02c5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0305;
																								}
																								break;
																							}
																							goto IL_039f;
																							IL_0444:
																							num5--;
																							goto end_IL_0293;
																							IL_039f:
																							if (8 < b)
																							{
																								goto IL_03aa;
																							}
																							goto IL_03e2;
																							IL_03aa:
																							if (9 < b)
																							{
																								goto end_IL_0258;
																							}
																							goto IL_03b8;
																							IL_03b8:
																							if (9 > b)
																							{
																								goto end_IL_0258;
																							}
																							goto IL_03c6;
																							IL_03c6:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0293;
																							IL_03e2:
																							if (8 > b)
																							{
																								goto end_IL_0258;
																							}
																							goto IL_03f0;
																							IL_03f0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0430;
																							IL_0430:
																							array[num5 - 2] = 0;
																							goto IL_0444;
																						}
																						goto IL_0375;
																					}
																					goto IL_032c;
																					IL_05be:
																					array[num5 - 2] = 0;
																					goto IL_05d2;
																					IL_032c:
																					if (5 <= b)
																					{
																						goto IL_033a;
																					}
																					goto IL_0457;
																					IL_033a:
																					array[num5] = 0;
																					goto IL_0348;
																					IL_0348:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_036b;
																					IL_036b:
																					array2[num5] = null;
																					goto IL_0375;
																					IL_0375:
																					num5++;
																					num = 79;
																					goto IL_038c;
																					IL_038c:
																					ptr2 += 8;
																					goto end_IL_0293;
																					IL_0457:
																					if (2 >= b)
																					{
																						goto IL_0465;
																					}
																					num = 103;
																					goto IL_0505;
																					IL_0465:
																					if (2 > b)
																					{
																						goto IL_0470;
																					}
																					goto IL_0491;
																					IL_0470:
																					if (1 < b)
																					{
																						goto end_IL_0258;
																					}
																					goto IL_047e;
																					IL_047e:
																					if (1 > b)
																					{
																					}
																					goto end_IL_0258;
																					IL_0491:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04d1;
																					IL_04d1:
																					array[num5 - 2] = 0;
																					goto IL_04f2;
																					IL_04f2:
																					num5--;
																					goto end_IL_0293;
																					IL_05d2:
																					num5--;
																					goto end_IL_0293;
																					IL_0505:
																					if (3 >= b)
																					{
																						goto IL_0510;
																					}
																					goto IL_0568;
																					IL_0510:
																					if (3 > b)
																					{
																						goto end_IL_0258;
																					}
																					goto IL_051e;
																					IL_051e:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0547;
																					IL_0547:
																					ptr2 += 8;
																					goto IL_0555;
																					IL_0555:
																					num5--;
																					goto end_IL_0293;
																					IL_0568:
																					if (4 < b)
																					{
																						goto end_IL_0258;
																					}
																					goto IL_0573;
																					IL_0573:
																					if (4 > b)
																					{
																						goto end_IL_0258;
																					}
																					goto IL_057e;
																					IL_057e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05be;
																					continue;
																					end_IL_0248:
																					break;
																				}
																				continue;
																				end_IL_0258:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 13;
																		goto IL_061e;
																		IL_0643:
																		ptr2 += 8;
																		goto end_IL_0293;
																		IL_0635:
																		num5++;
																		goto IL_0643;
																		IL_061e:
																		array[num5] = 0;
																		num = 57;
																		goto IL_0635;
																		continue;
																		end_IL_0268:
																		break;
																	}
																	continue;
																	end_IL_0278:
																	break;
																}
																continue;
																end_IL_0288:
																break;
															}
															continue;
															end_IL_0293:
															break;
														}
														continue;
													}
													goto IL_06fe;
													IL_06fe:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0651:
													break;
												}
												continue;
												end_IL_0664:
												break;
											}
											continue;
											end_IL_066e:
											break;
										}
										continue;
										end_IL_0679:
										break;
									}
									continue;
									end_IL_068e:
									break;
								}
								continue;
								end_IL_06a3:
								break;
							}
							continue;
							end_IL_06b3:
							break;
						}
						continue;
						end_IL_06c3:
						break;
					}
					continue;
					end_IL_06d3:
					break;
				}
				continue;
				end_IL_06e3:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3, int int_4)
	{
		int num = 54;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct84.TextToDefinitionAccessRightType);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 59;
																while (true)
																{
																	IL_0204:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e4:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01d7:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01c7:
																								if (7 < b)
																								{
																									while (8 >= b)
																									{
																										while (8 <= b)
																										{
																											num = 93;
																											while (true)
																											{
																												if (num != 93)
																												{
																													if (num != 1074)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 71:
																														goto IL_01a4;
																													case 9:
																														goto IL_01b7;
																													case 45:
																														goto end_IL_0191;
																													case 58:
																													case 62:
																														goto IL_01d7;
																													case 83:
																														goto IL_01e4;
																													case 30:
																														goto IL_01f4;
																													case 59:
																														goto IL_0204;
																													case 48:
																														goto end_IL_0204;
																													case 44:
																													case 50:
																														goto end_IL_0214;
																													case 0:
																														goto IL_0238;
																													case 23:
																													case 81:
																														goto IL_0246;
																													case 41:
																														goto IL_0254;
																													case 17:
																													case 73:
																														goto IL_0262;
																													case 7:
																														goto IL_027a;
																													case 3:
																														goto IL_0296;
																													case 61:
																													case 72:
																														goto IL_02a4;
																													case 1:
																														goto IL_02b2;
																													case 34:
																														goto IL_02d5;
																													case 76:
																														goto IL_02df;
																													case 84:
																														goto IL_02ed;
																													case 36:
																														goto IL_0300;
																													case 63:
																													case 80:
																														goto IL_030e;
																													case 4:
																														goto IL_031c;
																													case 25:
																													case 29:
																														goto IL_032a;
																													case 27:
																														goto IL_0398;
																													case 2:
																														goto IL_03ab;
																													case 10:
																														goto IL_03c2;
																													case 78:
																													case 85:
																														goto IL_03d5;
																													case 55:
																														goto IL_03e3;
																													case 13:
																													case 77:
																														goto IL_03f1;
																													case 20:
																														goto IL_043a;
																													case 52:
																														goto IL_044e;
																													case 11:
																													case 70:
																														goto IL_0461;
																													case 49:
																														goto IL_048a;
																													case 86:
																														goto IL_04a1;
																													case 8:
																													case 14:
																													case 19:
																													case 21:
																													case 22:
																													case 26:
																													case 32:
																													case 37:
																													case 42:
																													case 46:
																													case 51:
																													case 57:
																													case 67:
																													case 74:
																														goto end_IL_01a4;
																													case 38:
																														goto IL_04d4;
																													case 18:
																														goto IL_04e2;
																													case 65:
																														goto IL_04f0;
																													case 12:
																													case 15:
																													case 24:
																													case 31:
																													case 33:
																													case 43:
																													case 47:
																													case 64:
																													case 69:
																													case 75:
																													case 82:
																														goto end_IL_022d;
																													case 68:
																														goto end_IL_04fe;
																													case 66:
																														goto end_IL_0511;
																													case 6:
																														goto end_IL_051b;
																													case 79:
																														goto end_IL_0526;
																													case 40:
																														goto end_IL_053b;
																													case 39:
																													case 60:
																														goto end_IL_0550;
																													case 16:
																														goto end_IL_0560;
																													case 5:
																													case 35:
																														goto end_IL_0570;
																													case 53:
																														goto end_IL_0580;
																													case 54:
																														goto end_IL_0590;
																													case 28:
																													case 56:
																														goto IL_05b4;
																													}
																													continue;
																												}
																												goto IL_027a;
																												IL_027a:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												goto end_IL_022d;
																												continue;
																												end_IL_0191:
																												break;
																											}
																											goto IL_01c7;
																											continue;
																											end_IL_01a4:
																											break;
																											IL_01a4:;
																										}
																										break;
																										IL_01b7:;
																									}
																									break;
																								}
																								goto IL_0296;
																								IL_02ed:
																								ptr2 += 8;
																								goto end_IL_022d;
																								IL_0296:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_02a4;
																								IL_02a4:
																								array[num6] = 0;
																								goto IL_02b2;
																								IL_02b2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_02d5;
																								IL_02d5:
																								array2[num6] = null;
																								goto IL_02df;
																								IL_02df:
																								num6++;
																								goto IL_02ed;
																							}
																							break;
																						}
																						goto IL_0238;
																						IL_0262:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_022d;
																						IL_0238:
																						if (6 <= b)
																						{
																							goto end_IL_022d;
																						}
																						goto IL_0246;
																						IL_0246:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_0254;
																						IL_0254:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0262;
																					}
																					break;
																				}
																				goto IL_0300;
																				IL_048a:
																				ptr2 += 8;
																				num = 86;
																				goto IL_04a1;
																				IL_0300:
																				if (4 > b)
																				{
																					goto IL_030e;
																				}
																				goto IL_0461;
																				IL_030e:
																				if (2 >= b)
																				{
																					goto IL_031c;
																				}
																				goto IL_03d5;
																				IL_031c:
																				if (2 <= b)
																				{
																					goto IL_032a;
																				}
																				goto IL_03ab;
																				IL_032a:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0398;
																				IL_0398:
																				num6 -= 2;
																				goto end_IL_022d;
																				IL_03ab:
																				if (1 < b)
																				{
																					break;
																				}
																				num = 10;
																				goto IL_03c2;
																				IL_04a1:
																				num6--;
																				goto end_IL_022d;
																				IL_03c2:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_03d5:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_03e3;
																				IL_03e3:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_03f1;
																				IL_03f1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 20;
																				goto IL_043a;
																				IL_043a:
																				array[num6 - 2] = 0;
																				goto IL_044e;
																				IL_044e:
																				num6--;
																				goto end_IL_022d;
																				IL_0461:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_048a;
																			}
																			break;
																			IL_01f4:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d4;
																	IL_04f0:
																	ptr2 += 8;
																	goto end_IL_022d;
																	IL_04e2:
																	num6++;
																	goto IL_04f0;
																	IL_04d4:
																	array[num6] = 0;
																	goto IL_04e2;
																	continue;
																	end_IL_0204:
																	break;
																}
																continue;
																end_IL_0214:
																break;
															}
															continue;
															end_IL_022d:
															break;
														}
														continue;
													}
													num = 56;
													goto IL_05b4;
													IL_05b4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04fe:
													break;
												}
												continue;
												end_IL_0511:
												break;
											}
											continue;
											end_IL_051b:
											break;
										}
										continue;
										end_IL_0526:
										break;
									}
									continue;
									end_IL_053b:
									break;
								}
								continue;
								end_IL_0550:
								break;
							}
							continue;
							end_IL_0560:
							break;
						}
						continue;
						end_IL_0570:
						break;
					}
					continue;
					end_IL_0580:
					break;
				}
				continue;
				end_IL_0590:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3, int int_4)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									num = 22;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReservedMaskgetEncodedType.ReferenceAssemblyAttributeEmail);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 86;
																while (true)
																{
																	IL_02a0:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_0290:
																			if (b <= 9)
																			{
																				while (true)
																				{
																					IL_0280:
																					if (5 >= b)
																					{
																						num = 13;
																						while (true)
																						{
																							IL_0270:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_0260:
																									if (2 < b)
																									{
																										while (true)
																										{
																											IL_0250:
																											if (3 >= b)
																											{
																												while (3 <= b)
																												{
																													while (true)
																													{
																														IL_0215:
																														ref int reference = ref array3[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														while (true)
																														{
																															IL_01fc:
																															ptr2 += 8;
																															num = 115;
																															while (true)
																															{
																																if (num != 115)
																																{
																																	if (num != 1096)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 16:
																																		goto IL_01fc;
																																	case 54:
																																	case 72:
																																		goto IL_0215;
																																	case 26:
																																		goto IL_0240;
																																	case 77:
																																	case 100:
																																		goto IL_0250;
																																	case 45:
																																		goto IL_0260;
																																	case 13:
																																		goto IL_0270;
																																	case 63:
																																		goto IL_0280;
																																	case 17:
																																		goto IL_0290;
																																	case 86:
																																		goto IL_02a0;
																																	case 37:
																																		goto end_IL_02a0;
																																	case 41:
																																	case 48:
																																		goto end_IL_02b0;
																																	case 32:
																																		goto IL_02d4;
																																	case 21:
																																		goto IL_02e2;
																																	case 12:
																																	case 61:
																																		goto IL_02f0;
																																	case 30:
																																	case 71:
																																		goto IL_030b;
																																	case 23:
																																	case 79:
																																		goto IL_031e;
																																	case 40:
																																		goto IL_032c;
																																	case 56:
																																		goto IL_034f;
																																	case 75:
																																		goto IL_0359;
																																	case 70:
																																		goto IL_0367;
																																	case 80:
																																		goto IL_037a;
																																	case 50:
																																	case 84:
																																		goto IL_038d;
																																	case 64:
																																		goto IL_039b;
																																	case 14:
																																	case 28:
																																		goto IL_03a9;
																																	case 73:
																																		goto IL_03e9;
																																	case 20:
																																		goto IL_03fd;
																																	case 90:
																																		goto IL_0419;
																																	case 93:
																																		goto IL_042c;
																																	case 34:
																																	case 78:
																																		goto IL_043a;
																																	case 60:
																																		goto IL_047a;
																																	case 42:
																																		goto IL_048e;
																																	case 98:
																																		goto IL_04aa;
																																	case 36:
																																		goto IL_04b8;
																																	case 102:
																																		goto IL_04c8;
																																	case 94:
																																	case 105:
																																		goto IL_04db;
																																	case 7:
																																		goto IL_051b;
																																	case 8:
																																		goto IL_052f;
																																	case 1:
																																	case 108:
																																		goto IL_0542;
																																	case 51:
																																		goto IL_0550;
																																	case 39:
																																	case 68:
																																		goto IL_055e;
																																	case 3:
																																		goto IL_058d;
																																	case 38:
																																	case 65:
																																		goto IL_0598;
																																	case 106:
																																		goto IL_05d8;
																																	case 57:
																																		goto IL_05ec;
																																	case 55:
																																	case 74:
																																		goto IL_05fc;
																																	case 35:
																																		goto IL_0607;
																																	case 0:
																																	case 2:
																																	case 5:
																																	case 6:
																																	case 15:
																																	case 18:
																																	case 24:
																																	case 29:
																																	case 47:
																																	case 52:
																																	case 62:
																																	case 66:
																																	case 81:
																																	case 83:
																																	case 87:
																																	case 91:
																																	case 92:
																																	case 99:
																																	case 103:
																																	case 104:
																																	case 107:
																																		goto end_IL_01e9;
																																	case 11:
																																		goto IL_0640;
																																	case 25:
																																		goto IL_064e;
																																	case 10:
																																		goto IL_065c;
																																	case 19:
																																	case 33:
																																	case 43:
																																	case 44:
																																	case 53:
																																	case 58:
																																	case 59:
																																	case 76:
																																	case 82:
																																	case 85:
																																	case 97:
																																		goto end_IL_02c9;
																																	case 46:
																																		goto end_IL_066a;
																																	case 101:
																																		goto end_IL_067d;
																																	case 22:
																																		goto end_IL_0687;
																																	case 31:
																																		goto end_IL_0692;
																																	case 88:
																																		goto end_IL_06a7;
																																	case 27:
																																	case 49:
																																		goto end_IL_06c5;
																																	case 4:
																																		goto end_IL_06d5;
																																	case 69:
																																	case 89:
																																		goto end_IL_06e5;
																																	case 95:
																																		goto end_IL_06f5;
																																	case 96:
																																		goto end_IL_0705;
																																	case 9:
																																	case 67:
																																		goto IL_0720;
																																	}
																																	continue;
																																}
																																num5--;
																																goto end_IL_02c9;
																																continue;
																																end_IL_01e9:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																													IL_0240:;
																												}
																												break;
																											}
																											goto IL_030b;
																											IL_048e:
																											num5--;
																											num = 53;
																											goto end_IL_02c9;
																											IL_030b:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_042c;
																											IL_042c:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_043a;
																											IL_043a:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_047a;
																											IL_047a:
																											array[num5 - 2] = 0;
																											goto IL_048e;
																										}
																										break;
																									}
																									goto IL_058d;
																									IL_0607:
																									if (1 <= b)
																									{
																									}
																									break;
																									IL_058d:
																									if (2 <= b)
																									{
																										goto IL_0598;
																									}
																									goto IL_05fc;
																									IL_0598:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05d8;
																									IL_05d8:
																									array[num5 - 2] = 0;
																									goto IL_05ec;
																									IL_05ec:
																									num5--;
																									goto end_IL_02c9;
																									IL_05fc:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_0607;
																								}
																								break;
																							}
																							goto IL_031e;
																							IL_0367:
																							ptr2 += 8;
																							goto end_IL_02c9;
																							IL_031e:
																							array[num5] = 0;
																							goto IL_032c;
																							IL_032c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_034f;
																							IL_034f:
																							array2[num5] = null;
																							goto IL_0359;
																							IL_0359:
																							num5++;
																							goto IL_0367;
																						}
																						break;
																					}
																					goto IL_02d4;
																					IL_0550:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_055e;
																					IL_055e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02c9;
																					IL_02d4:
																					if (7 >= b)
																					{
																						goto IL_02e2;
																					}
																					goto IL_038d;
																					IL_02e2:
																					if (7 <= b)
																					{
																						goto IL_02f0;
																					}
																					goto IL_04aa;
																					IL_02f0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_037a;
																					IL_037a:
																					array[num5] = 0;
																					goto IL_0419;
																					IL_0419:
																					num5++;
																					goto IL_04c8;
																					IL_04c8:
																					ptr2 += 8;
																					goto end_IL_02c9;
																					IL_04aa:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_04b8;
																					IL_04b8:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_04db;
																					IL_04db:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_051b;
																					IL_051b:
																					array[num5 - 2] = 0;
																					goto IL_052f;
																					IL_052f:
																					num5--;
																					goto end_IL_02c9;
																					IL_038d:
																					if (8 >= b)
																					{
																						goto IL_039b;
																					}
																					goto IL_0542;
																					IL_039b:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_03a9;
																					IL_03a9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03e9;
																					IL_03e9:
																					array[num5 - 2] = 0;
																					goto IL_03fd;
																					IL_03fd:
																					num5--;
																					num = 76;
																					goto end_IL_02c9;
																					IL_0542:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0550;
																				}
																			}
																			else
																			{
																				num = 87;
																			}
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0640;
																	IL_065c:
																	ptr2 += 8;
																	goto end_IL_02c9;
																	IL_064e:
																	num5++;
																	goto IL_065c;
																	IL_0640:
																	array[num5] = 0;
																	goto IL_064e;
																	continue;
																	end_IL_02a0:
																	break;
																}
																continue;
																end_IL_02b0:
																break;
															}
															continue;
															end_IL_02c9:
															break;
														}
														continue;
													}
													goto IL_0720;
													IL_0720:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_066a:
													break;
												}
												continue;
												end_IL_067d:
												break;
											}
											continue;
											end_IL_0687:
											break;
										}
										continue;
										end_IL_0692:
										break;
									}
									continue;
									end_IL_06a7:
									break;
								}
								continue;
								end_IL_06c5:
								break;
							}
							continue;
							end_IL_06d5:
							break;
						}
						continue;
						end_IL_06e5:
						break;
					}
					continue;
					end_IL_06f5:
					break;
				}
				continue;
				end_IL_0705:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_0914:
					byte[] array = new byte[4];
					while (true)
					{
						IL_0904:
						object[] array2 = new object[4];
						while (true)
						{
							IL_08f4:
							int[] array3 = new int[2];
							while (true)
							{
								IL_08e4:
								long[] array4 = new long[4];
								while (true)
								{
									IL_08d4:
									object[] array5 = new object[1];
									while (true)
									{
										IL_08c9:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InsufficientExecutionStackExceptionTypeRequiresRegistration.GetMinPrimeJulianCenturies);
										while (true)
										{
											IL_08bf:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_08b4:
												num = 142;
												while (true)
												{
													IL_08a1:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0369:
															byte b = *ptr2;
															while (true)
															{
																IL_0350:
																ptr2++;
																num = 43;
																while (true)
																{
																	IL_0340:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_031d:
																				if (8 >= b)
																				{
																					num = 32;
																					while (true)
																					{
																						IL_0310:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_0300:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02f0:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_02a5:
																														ref int reference = ref array3[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														while (true)
																														{
																															IL_028c:
																															ptr2 += 8;
																															num = 151;
																															while (true)
																															{
																																if (num != 151)
																																{
																																	if (num != 1132)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 132:
																																		goto IL_028c;
																																	case 1:
																																	case 134:
																																		goto IL_02a5;
																																	case 125:
																																		goto IL_02d0;
																																	case 6:
																																	case 94:
																																		goto IL_02e0;
																																	case 85:
																																		goto IL_02f0;
																																	case 140:
																																		goto IL_0300;
																																	case 32:
																																		goto IL_0310;
																																	case 22:
																																		goto IL_031d;
																																	case 40:
																																		goto IL_0330;
																																	case 43:
																																		goto IL_0340;
																																	case 65:
																																		goto IL_0350;
																																	case 28:
																																	case 138:
																																		goto IL_0369;
																																	case 38:
																																	case 50:
																																		goto IL_0374;
																																	case 131:
																																		goto IL_039f;
																																	case 13:
																																	case 90:
																																		goto IL_03aa;
																																	case 72:
																																		goto IL_03e9;
																																	case 55:
																																		goto IL_03fc;
																																	case 78:
																																		goto IL_040a;
																																	case 100:
																																	case 113:
																																		goto IL_0418;
																																	case 15:
																																		goto IL_0426;
																																	case 127:
																																		goto IL_043e;
																																	case 136:
																																		goto IL_044c;
																																	case 5:
																																		goto IL_0468;
																																	case 77:
																																	case 105:
																																		goto IL_0473;
																																	case 119:
																																		goto IL_049a;
																																	case 56:
																																		goto IL_04a8;
																																	case 70:
																																		goto IL_04bb;
																																	case 27:
																																	case 126:
																																		goto IL_04c6;
																																	case 89:
																																		goto IL_04d4;
																																	case 79:
																																	case 114:
																																		goto IL_04e2;
																																	case 76:
																																		goto IL_0514;
																																	case 45:
																																		goto IL_052d;
																																	case 33:
																																	case 46:
																																		goto IL_0538;
																																	case 111:
																																		goto IL_0578;
																																	case 121:
																																		goto IL_058c;
																																	case 41:
																																		goto IL_059f;
																																	case 8:
																																		goto IL_05ad;
																																	case 35:
																																	case 91:
																																		goto IL_05bb;
																																	case 52:
																																		goto IL_05d4;
																																	case 0:
																																		goto IL_05e2;
																																	case 99:
																																		goto IL_05f0;
																																	case 123:
																																		goto IL_0603;
																																	case 108:
																																		goto IL_0611;
																																	case 3:
																																	case 63:
																																		goto IL_061f;
																																	case 24:
																																		goto IL_062d;
																																	case 61:
																																	case 137:
																																		goto IL_0641;
																																	case 112:
																																		goto IL_064f;
																																	case 53:
																																		goto IL_0672;
																																	case 4:
																																		goto IL_067c;
																																	case 73:
																																		goto IL_068a;
																																	case 141:
																																		goto IL_069d;
																																	case 16:
																																		goto IL_06ab;
																																	case 143:
																																		goto IL_06be;
																																	case 83:
																																		goto IL_06cc;
																																	case 2:
																																	case 118:
																																		goto IL_06e3;
																																	case 66:
																																		goto IL_0727;
																																	case 109:
																																		goto IL_073b;
																																	case 62:
																																	case 144:
																																		goto IL_074e;
																																	case 58:
																																		goto IL_078e;
																																	case 60:
																																		goto IL_07a2;
																																	case 102:
																																	case 129:
																																		goto IL_07b5;
																																	case 81:
																																		goto IL_07c3;
																																	case 14:
																																	case 104:
																																		goto IL_07d1;
																																	case 117:
																																		goto IL_07df;
																																	case 30:
																																	case 36:
																																		goto IL_07ed;
																																	case 115:
																																		goto IL_084f;
																																	case 101:
																																	case 139:
																																		goto IL_085f;
																																	case 128:
																																		goto IL_0878;
																																	case 31:
																																		goto IL_0883;
																																	case 10:
																																	case 11:
																																	case 17:
																																	case 29:
																																	case 34:
																																	case 37:
																																	case 42:
																																	case 47:
																																	case 48:
																																	case 54:
																																	case 57:
																																	case 67:
																																	case 80:
																																	case 82:
																																	case 84:
																																	case 87:
																																	case 88:
																																	case 93:
																																	case 95:
																																	case 96:
																																	case 103:
																																	case 106:
																																	case 116:
																																	case 122:
																																	case 124:
																																	case 133:
																																		goto end_IL_02d0;
																																	case 9:
																																	case 18:
																																	case 21:
																																	case 23:
																																	case 25:
																																	case 26:
																																	case 39:
																																	case 64:
																																	case 68:
																																	case 71:
																																	case 75:
																																	case 86:
																																	case 92:
																																	case 98:
																																	case 120:
																																	case 130:
																																	case 142:
																																		goto IL_08a1;
																																	case 59:
																																		goto IL_08b4;
																																	case 110:
																																		goto IL_08bf;
																																	case 69:
																																		goto IL_08c9;
																																	case 44:
																																		goto IL_08d4;
																																	case 51:
																																		goto IL_08e4;
																																	case 7:
																																	case 135:
																																		goto IL_08f4;
																																	case 107:
																																		goto IL_0904;
																																	case 49:
																																	case 97:
																																		goto IL_0914;
																																	case 19:
																																		goto end_IL_0279;
																																	case 20:
																																		goto end_IL_0924;
																																	case 12:
																																	case 74:
																																		goto IL_093f;
																																	}
																																	continue;
																																}
																																num5--;
																																goto IL_08a1;
																																continue;
																																end_IL_0279:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_0340;
																													continue;
																													end_IL_02d0:
																													break;
																													IL_02d0:;
																												}
																												break;
																												IL_02e0:;
																											}
																											break;
																										}
																										goto IL_039f;
																										IL_044c:
																										ptr2 += 8;
																										goto IL_08a1;
																										IL_039f:
																										if (6 <= b)
																										{
																											goto IL_03aa;
																										}
																										goto IL_03fc;
																										IL_03aa:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03e9;
																										IL_03e9:
																										num5 -= 3;
																										goto IL_08a1;
																										IL_03fc:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_040a;
																										IL_040a:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_0418;
																										IL_0418:
																										array[num5] = 5;
																										goto IL_0426;
																										IL_0426:
																										array2[num5] = array5[*(int*)(ptr2 + num3)];
																										goto IL_043e;
																										IL_043e:
																										num5++;
																										goto IL_044c;
																									}
																									break;
																								}
																								num = 5;
																								goto IL_0468;
																								IL_05e2:
																								num5++;
																								goto IL_05f0;
																								IL_05f0:
																								ptr2 += 8;
																								goto IL_08a1;
																								IL_0468:
																								if (4 <= b)
																								{
																									goto IL_0473;
																								}
																								goto IL_04bb;
																								IL_0473:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								num = 119;
																								goto IL_049a;
																								IL_049a:
																								ptr2 += 8;
																								goto IL_04a8;
																								IL_04a8:
																								num5--;
																								goto IL_08a1;
																								IL_04bb:
																								if (2 < b)
																								{
																									goto IL_04c6;
																								}
																								goto IL_052d;
																								IL_04c6:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_04d4;
																								IL_04d4:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_04e2;
																								IL_04e2:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								num = 76;
																								goto IL_0514;
																								IL_0514:
																								array[num5 - 1] = 5;
																								goto IL_08a1;
																								IL_052d:
																								if (2 <= b)
																								{
																									goto IL_0538;
																								}
																								goto IL_059f;
																								IL_0538:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0578;
																								IL_0578:
																								array[num5 - 2] = 0;
																								goto IL_058c;
																								IL_058c:
																								num5--;
																								goto IL_08a1;
																								IL_059f:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_05ad;
																								IL_05ad:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_05bb;
																								IL_05bb:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_05d4;
																								IL_05d4:
																								array[num5] = 0;
																								goto IL_05e2;
																							}
																							break;
																						}
																						goto IL_0374;
																						IL_0374:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_08a1;
																					}
																					break;
																				}
																				goto IL_0603;
																				IL_084f:
																				num5 -= 2;
																				goto IL_08a1;
																				IL_085f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_08a1;
																				IL_0603:
																				if (12 >= b)
																				{
																					goto IL_0611;
																				}
																				goto IL_07b5;
																				IL_0611:
																				if (12 > b)
																				{
																					goto IL_061f;
																				}
																				goto IL_074e;
																				IL_061f:
																				if (10 >= b)
																				{
																					goto IL_062d;
																				}
																				goto IL_06be;
																				IL_062d:
																				if (10 <= b)
																				{
																					num = 137;
																					goto IL_0641;
																				}
																				goto IL_069d;
																				IL_0878:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_0883;
																				IL_0641:
																				array[num5] = 0;
																				goto IL_064f;
																				IL_064f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0672;
																				IL_0672:
																				array2[num5] = null;
																				goto IL_067c;
																				IL_067c:
																				num5++;
																				goto IL_068a;
																				IL_068a:
																				ptr2 += 8;
																				goto IL_08a1;
																				IL_069d:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_06ab;
																				IL_06ab:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_08a1;
																				IL_06be:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_06cc;
																				IL_06cc:
																				if (11 > b)
																				{
																					break;
																				}
																				num = 2;
																				goto IL_06e3;
																				IL_0883:
																				if (15 > b)
																				{
																				}
																				break;
																				IL_06e3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0727;
																				IL_0727:
																				array[num5 - 2] = 0;
																				goto IL_073b;
																				IL_073b:
																				num5--;
																				goto IL_08a1;
																				IL_074e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_078e;
																				IL_078e:
																				array[num5 - 2] = 0;
																				goto IL_07a2;
																				IL_07a2:
																				num5--;
																				goto IL_08a1;
																				IL_07b5:
																				if (14 >= b)
																				{
																					goto IL_07c3;
																				}
																				goto IL_0878;
																				IL_07c3:
																				if (14 > b)
																				{
																					goto IL_07d1;
																				}
																				goto IL_085f;
																				IL_07d1:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_07df;
																				IL_07df:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_07ed;
																				IL_07ed:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_084f;
																			}
																			break;
																			IL_0330:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_08a1;
																	continue;
																	end_IL_0340:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_093f;
													IL_093f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_0924:
				break;
			}
		}
	}

	private static int smethod_6(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_3;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_7(int int_3)
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 119;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref XmlNamespaceEncoderTrackResurrection.getSourcePathDefinitionIdentity);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 135;
											while (true)
											{
												if (num == 135)
												{
													goto IL_02d5;
												}
												if (num != 1116)
												{
													goto IL_0342;
												}
												switch (num)
												{
												case 2:
													goto end_IL_022b;
												case 88:
													goto end_IL_023e;
												case 105:
													goto end_IL_0251;
												case 62:
													goto end_IL_025c;
												case 41:
												case 104:
													goto end_IL_0271;
												case 106:
													goto end_IL_0281;
												case 53:
												case 119:
													goto end_IL_0291;
												case 75:
													goto end_IL_02a1;
												case 76:
													goto end_IL_02b1;
												case 21:
												case 23:
												case 27:
												case 32:
												case 52:
												case 54:
												case 60:
												case 61:
												case 66:
												case 67:
												case 79:
												case 108:
												case 112:
												case 113:
												case 120:
													goto IL_02d5;
												case 4:
												case 26:
													goto IL_02e5;
												case 58:
													goto IL_02ee;
												case 102:
													goto IL_02fc;
												case 63:
													goto IL_030a;
												case 95:
													goto IL_0318;
												case 24:
												case 25:
													goto IL_0326;
												case 48:
													goto IL_0334;
												case 49:
												case 73:
													goto IL_0342;
												case 89:
													goto IL_0356;
												case 19:
													goto IL_03aa;
												case 10:
													goto IL_03b8;
												case 92:
													goto IL_03cb;
												case 12:
													goto IL_03d9;
												case 18:
												case 44:
													goto IL_03e7;
												case 8:
													goto IL_0449;
												case 17:
													goto IL_045c;
												case 85:
													goto IL_046a;
												case 7:
												case 98:
													goto IL_0478;
												case 84:
													goto IL_04b8;
												case 6:
													goto IL_04cc;
												case 124:
													goto IL_04df;
												case 16:
												case 91:
													goto IL_04ea;
												case 114:
													goto IL_04f8;
												case 71:
													goto IL_050b;
												case 35:
												case 111:
													goto IL_0516;
												case 101:
													goto IL_053b;
												case 103:
													goto IL_0549;
												case 56:
												case 59:
													goto IL_0557;
												case 72:
													goto IL_056a;
												case 45:
												case 96:
													goto IL_0578;
												case 117:
													goto IL_0586;
												case 86:
												case 115:
													goto IL_0594;
												case 87:
													goto IL_059f;
												case 9:
												case 107:
													goto IL_05ad;
												case 90:
													goto IL_05c6;
												case 97:
													goto IL_05d4;
												case 38:
													goto IL_05e2;
												case 0:
													goto IL_05fe;
												case 100:
													goto IL_060c;
												case 30:
												case 43:
													goto IL_061a;
												case 22:
													goto IL_0643;
												case 122:
													goto IL_0651;
												case 64:
												case 99:
													goto IL_0664;
												case 69:
												case 126:
													goto IL_0685;
												case 50:
													goto IL_0693;
												case 125:
													goto IL_069e;
												case 40:
													goto IL_06ac;
												case 36:
												case 42:
													goto IL_06c8;
												case 116:
													goto IL_06d6;
												case 80:
													goto IL_06f9;
												case 31:
													goto IL_070c;
												case 5:
													goto IL_071a;
												case 68:
													goto IL_072d;
												case 37:
													goto IL_073b;
												case 1:
												case 28:
													goto IL_0749;
												case 121:
													goto IL_0789;
												case 55:
													goto IL_079d;
												case 15:
												case 47:
													goto IL_07b0;
												case 33:
													goto IL_07dc;
												case 70:
													goto IL_07ea;
												case 82:
													goto IL_07f8;
												case 3:
												case 11:
												case 13:
												case 14:
												case 20:
												case 29:
												case 34:
												case 46:
												case 51:
												case 57:
												case 65:
												case 74:
												case 77:
												case 81:
												case 83:
												case 93:
												case 94:
												case 109:
												case 110:
												case 118:
												case 123:
												case 127:
												case 128:
													goto IL_080b;
												case 39:
												case 78:
													goto IL_082c;
												}
												continue;
												IL_07dc:
												array[num4] = 0;
												goto IL_07ea;
												IL_07ea:
												num4++;
												goto IL_07f8;
												IL_02d5:
												if (num5 != 1)
												{
													goto IL_02e5;
												}
												goto IL_082c;
												IL_082c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_02e5:
												b = *ptr2;
												goto IL_02ee;
												IL_02ee:
												ptr2++;
												goto IL_02fc;
												IL_02fc:
												if (b >= 1)
												{
													goto IL_030a;
												}
												goto IL_080b;
												IL_030a:
												if (b <= 13)
												{
													goto IL_0318;
												}
												goto IL_080b;
												IL_0318:
												if (7 < b)
												{
													goto IL_0326;
												}
												goto IL_056a;
												IL_0326:
												if (10 >= b)
												{
													goto IL_0334;
												}
												goto IL_04df;
												IL_0334:
												if (10 <= b)
												{
													goto IL_0342;
												}
												goto IL_03cb;
												IL_0342:
												array[num4 - 2] = 0;
												goto IL_0356;
												IL_0356:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((delegate*<int, int, int>)OutputEncodingRSA[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
												goto IL_03aa;
												IL_03aa:
												num4--;
												goto IL_03b8;
												IL_03b8:
												ptr2 += 8;
												goto IL_02d5;
												IL_03cb:
												if (8 >= b)
												{
													goto IL_03d9;
												}
												goto IL_045c;
												IL_03d9:
												if (8 <= b)
												{
													goto IL_03e7;
												}
												goto IL_080b;
												IL_03e7:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0449;
												IL_0449:
												num4 -= 2;
												goto IL_02d5;
												IL_045c:
												if (9 >= b)
												{
													goto IL_046a;
												}
												goto IL_080b;
												IL_046a:
												if (9 <= b)
												{
													goto IL_0478;
												}
												goto IL_080b;
												IL_0478:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_04b8;
												IL_04b8:
												array[num4 - 2] = 0;
												goto IL_04cc;
												IL_04cc:
												num4--;
												goto IL_02d5;
												IL_04df:
												if (12 < b)
												{
													goto IL_04ea;
												}
												goto IL_050b;
												IL_04ea:
												if (13 >= b)
												{
													goto IL_04f8;
												}
												goto IL_080b;
												IL_04f8:
												if (13 <= b)
												{
												}
												goto IL_080b;
												IL_050b:
												if (12 <= b)
												{
													goto IL_0516;
												}
												goto IL_053b;
												IL_0516:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												num = 52;
												goto IL_02d5;
												IL_053b:
												if (11 >= b)
												{
													goto IL_0549;
												}
												goto IL_080b;
												IL_0549:
												if (11 <= b)
												{
													goto IL_0557;
												}
												goto IL_080b;
												IL_0557:
												num4--;
												goto IL_02d5;
												IL_056a:
												if (7 > b)
												{
													goto IL_0578;
												}
												goto IL_07b0;
												IL_0578:
												if (3 >= b)
												{
													goto IL_0586;
												}
												num = 126;
												goto IL_0685;
												IL_0586:
												if (3 > b)
												{
													goto IL_0594;
												}
												goto IL_0664;
												IL_0594:
												if (1 >= b)
												{
													goto IL_059f;
												}
												goto IL_05fe;
												IL_059f:
												if (1 <= b)
												{
													goto IL_05ad;
												}
												goto IL_080b;
												IL_05ad:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												goto IL_05c6;
												IL_05c6:
												array[num4] = 0;
												goto IL_05d4;
												IL_05d4:
												num4++;
												goto IL_05e2;
												IL_05e2:
												ptr2 += 8;
												num = 120;
												goto IL_02d5;
												IL_05fe:
												if (2 >= b)
												{
													goto IL_060c;
												}
												goto IL_080b;
												IL_060c:
												if (2 <= b)
												{
													goto IL_061a;
												}
												goto IL_080b;
												IL_061a:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0643;
												IL_0643:
												ptr2 += 8;
												goto IL_0651;
												IL_0651:
												num4--;
												goto IL_02d5;
												IL_0664:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_02d5;
												IL_07f8:
												ptr2 += 8;
												goto IL_02d5;
												IL_0685:
												if (5 >= b)
												{
													goto IL_0693;
												}
												goto IL_072d;
												IL_0693:
												if (5 > b)
												{
													goto IL_069e;
												}
												num = 42;
												goto IL_06c8;
												IL_069e:
												if (4 >= b)
												{
													goto IL_06ac;
												}
												goto IL_080b;
												IL_06ac:
												if (4 <= b)
												{
													goto IL_02d5;
												}
												goto IL_080b;
												IL_080b:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 54;
												goto IL_02d5;
												IL_06c8:
												array[num4] = 0;
												goto IL_06d6;
												IL_06d6:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_06f9;
												IL_06f9:
												array2[num4] = null;
												num = 31;
												goto IL_070c;
												IL_070c:
												num4++;
												goto IL_071a;
												IL_071a:
												ptr2 += 8;
												goto IL_02d5;
												IL_072d:
												if (6 >= b)
												{
													goto IL_073b;
												}
												goto IL_080b;
												IL_073b:
												if (6 <= b)
												{
													goto IL_0749;
												}
												goto IL_080b;
												IL_0749:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0789;
												IL_0789:
												array[num4 - 2] = 0;
												goto IL_079d;
												IL_079d:
												num4--;
												goto IL_02d5;
												IL_07b0:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												num = 33;
												goto IL_07dc;
												continue;
												end_IL_022b:
												break;
											}
											continue;
											end_IL_023e:
											break;
										}
										continue;
										end_IL_0251:
										break;
									}
									continue;
									end_IL_025c:
									break;
								}
								continue;
								end_IL_0271:
								break;
							}
							continue;
							end_IL_0281:
							break;
						}
						continue;
						end_IL_0291:
						break;
					}
					continue;
					end_IL_02a1:
					break;
				}
				continue;
				end_IL_02b1:
				break;
			}
		}
	}

	static Class136()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0046:
				Class300.smethod_0();
				num = 12;
				while (true)
				{
					if (num != 12)
					{
						if (num != 993)
						{
							break;
						}
						switch (num)
						{
						case 3:
							goto IL_0046;
						case 4:
							goto end_IL_0039;
						case 0:
						case 1:
						case 2:
							goto IL_0060;
						case 5:
							return;
						}
						continue;
					}
					goto IL_0060;
					IL_0060:
					num = 5;
					return;
					continue;
					end_IL_0039:
					break;
				}
				break;
			}
		}
	}
}
