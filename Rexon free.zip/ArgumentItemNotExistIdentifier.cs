using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 162)]
internal struct ArgumentItemNotExistIdentifier
{
	internal static ArgumentItemNotExistIdentifier IListWrapperSourceFilePath/* Not supported: data(01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 02 03 00 00 00 02 02 00 00 00 01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 04 03 00 00 00 03 03 00 00 00 05 00 00 00 02 02 00 00 00 05 00 00 00 03 03 00 00 00 06 03 00 00 00 04 04 00 00 00 05 00 00 00 04 04 00 00 00 07 00 00 00 5A 5A 00 00 00 07 00 00 00 02 02 00 00 00 08 02 07 00 00 02 10 10 02 00 00 07 00 00 00 0B 0B 00 00 00 08 07 00 00 00 C4 C4 00 00 00 07 00 00 00 04 04 00 00 00 08 09 00 00 00 00 00 00 00 00 0A 0B) */;
}
