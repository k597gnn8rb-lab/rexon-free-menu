using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1)]
internal struct AllowInnerWhiteClt
{
	internal static AllowInnerWhiteClt CreateFromSignedFileCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGOPTIONAL/* Not supported: data(01) */;
}
