using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gadget Sphere Large", "Super Infection/Casual [MASTERCLIENT]", "Spawns large gadget sphere.", true, 22, ModType.const_1, false)]
internal class Class118 : MonoBehaviour
{
	private static double double_0;

	private static double double_1;

	private static double double_2;

	private static int int_0;

	private static bool bool_0;

	private static Vector3 XKeyStorageFlagsFreeHString;

	private static Quaternion InheritedRSAPKCSKeyExchangeFormatter;

	private static GameEntityCreateData SourcePathGetTypeFromAssembly;

	private static IntPtr[] ThrowOnEventWriteErrorsDateTimeOffset;

	private static IntPtr[] SafeLsaMemoryHandleAddCustom;

	private static IntPtr[] RemotingFieldCachedDataGenerateEvidence;

	private static IntPtr[] EndOfStreamVolumeDown;

	private unsafe void OnEnable()
	{
		int num = 85;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 318;
				while (true)
				{
					byte[] array = new byte[3];
					num = 381;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							num = 131;
							while (true)
							{
								int[] array4 = new int[9];
								while (true)
								{
									long[] array5 = new long[3];
									while (true)
									{
										object[] array6 = new object[9];
										num = 157;
										while (true)
										{
											array6[0] = this;
											while (true)
											{
												array6[1] = XKeyStorageFlagsFreeHString;
												while (true)
												{
													array6[5] = XKeyStorageFlagsFreeHString;
													while (true)
													{
														array6[6] = InheritedRSAPKCSKeyExchangeFormatter;
														while (true)
														{
															array6[7] = XKeyStorageFlagsFreeHString;
															num = 257;
															while (true)
															{
																array6[8] = SourcePathGetTypeFromAssembly;
																while (true)
																{
																	byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IdentityHoldersetApplicationName.FormatAssemblyBlockSizeValue);
																	while (true)
																	{
																		byte* ptr2 = ptr;
																		while (true)
																		{
																			if (num4 != 1)
																			{
																				while (true)
																				{
																					byte b = *ptr2;
																					num = 208;
																					while (true)
																					{
																						ptr2++;
																						while (true)
																						{
																							IL_09cc:
																							if (b >= 1)
																							{
																								while (b <= 66)
																								{
																									while (true)
																									{
																										IL_09ac:
																										if (33 >= b)
																										{
																											while (true)
																											{
																												IL_099c:
																												if (33 > b)
																												{
																													while (true)
																													{
																														IL_098c:
																														if (16 < b)
																														{
																															while (true)
																															{
																																IL_0979:
																																if (24 >= b)
																																{
																																	num = 103;
																																	while (true)
																																	{
																																		IL_0969:
																																		if (24 > b)
																																		{
																																			while (true)
																																			{
																																				IL_0959:
																																				if (20 >= b)
																																				{
																																					while (true)
																																					{
																																						IL_0949:
																																						if (20 > b)
																																						{
																																							while (true)
																																							{
																																								IL_0939:
																																								if (18 < b)
																																								{
																																									while (19 >= b)
																																									{
																																										while (19 <= b)
																																										{
																																											num = 566;
																																											while (true)
																																											{
																																												if (num != 566)
																																												{
																																													if (num != 1547)
																																													{
																																														break;
																																													}
																																													switch (num)
																																													{
																																													case 384:
																																														goto IL_0916;
																																													case 130:
																																														goto IL_0929;
																																													case 452:
																																														goto IL_0939;
																																													case 49:
																																														goto IL_0949;
																																													case 279:
																																														goto IL_0959;
																																													case 103:
																																														goto IL_0969;
																																													case 287:
																																														goto IL_0979;
																																													case 236:
																																														goto IL_098c;
																																													case 134:
																																														goto IL_099c;
																																													case 466:
																																														goto IL_09ac;
																																													case 36:
																																														goto IL_09bc;
																																													case 164:
																																														goto IL_09cc;
																																													case 208:
																																														goto end_IL_09cc;
																																													case 144:
																																													case 278:
																																														goto end_IL_09dc;
																																													case 60:
																																													case 248:
																																														goto IL_0a00;
																																													case 106:
																																														goto IL_0a15;
																																													case 51:
																																													case 302:
																																														goto IL_0a28;
																																													case 295:
																																														goto IL_0a3c;
																																													case 234:
																																														goto IL_0a82;
																																													case 317:
																																														goto IL_0a95;
																																													case 268:
																																														goto IL_0aa3;
																																													case 316:
																																														goto IL_0ab1;
																																													case 356:
																																														goto IL_0ac4;
																																													case 226:
																																														goto IL_0ad2;
																																													case 324:
																																														goto IL_0ae0;
																																													case 277:
																																														goto IL_0aeb;
																																													case 16:
																																														goto IL_0af6;
																																													case 243:
																																														goto IL_0b20;
																																													case 215:
																																														goto IL_0b2e;
																																													case 125:
																																														goto IL_0b3c;
																																													case 169:
																																													case 216:
																																														goto IL_0b4a;
																																													case 24:
																																														goto IL_0bac;
																																													case 231:
																																														goto IL_0bbf;
																																													case 100:
																																														goto IL_0bd6;
																																													case 382:
																																														goto IL_0c00;
																																													case 393:
																																														goto IL_0c13;
																																													case 104:
																																														goto IL_0c1e;
																																													case 313:
																																														goto IL_0c2c;
																																													case 392:
																																														goto IL_0c3a;
																																													case 92:
																																														goto IL_0c4d;
																																													case 188:
																																														goto IL_0c5b;
																																													case 251:
																																														goto IL_0c6f;
																																													case 12:
																																													case 259:
																																														goto IL_0c7d;
																																													case 364:
																																														goto IL_0caa;
																																													case 238:
																																														goto IL_0cc1;
																																													case 32:
																																													case 412:
																																														goto IL_0cd4;
																																													case 3:
																																														goto IL_0cee;
																																													case 147:
																																														goto IL_0cfc;
																																													case 81:
																																														goto IL_0d0a;
																																													case 415:
																																														goto IL_0d1d;
																																													case 28:
																																													case 128:
																																														goto IL_0d28;
																																													case 185:
																																														goto IL_0d41;
																																													case 124:
																																														goto IL_0d4f;
																																													case 426:
																																														goto IL_0d62;
																																													case 23:
																																													case 173:
																																														goto IL_0d70;
																																													case 433:
																																														goto IL_0d89;
																																													case 165:
																																														goto IL_0d97;
																																													case 25:
																																														goto IL_0da5;
																																													case 22:
																																														goto IL_0db3;
																																													case 42:
																																														goto IL_0dc1;
																																													case 72:
																																													case 367:
																																														goto IL_0dcc;
																																													case 46:
																																														goto IL_0e11;
																																													case 310:
																																														goto IL_0e1f;
																																													case 242:
																																														goto IL_0e32;
																																													case 424:
																																														goto IL_0e40;
																																													case 129:
																																													case 249:
																																														goto IL_0e4b;
																																													case 99:
																																														goto IL_0e8b;
																																													case 76:
																																														goto IL_0ea4;
																																													case 294:
																																														goto IL_0eb2;
																																													case 39:
																																													case 371:
																																														goto IL_0ec9;
																																													case 332:
																																														goto IL_0f09;
																																													case 327:
																																														goto IL_0f22;
																																													case 375:
																																														goto IL_0f30;
																																													case 240:
																																													case 406:
																																														goto IL_0f47;
																																													case 86:
																																														goto IL_0f87;
																																													case 53:
																																													case 398:
																																														goto IL_0fa0;
																																													case 40:
																																													case 435:
																																														goto IL_0fb3;
																																													case 437:
																																														goto IL_0fc3;
																																													case 266:
																																													case 446:
																																														goto IL_0fd6;
																																													case 150:
																																														goto IL_0fee;
																																													case 447:
																																														goto IL_1001;
																																													case 449:
																																														goto IL_1014;
																																													case 217:
																																														goto IL_1038;
																																													case 455:
																																														goto IL_104b;
																																													case 379:
																																														goto IL_1083;
																																													case 456:
																																														goto IL_1096;
																																													case 140:
																																														goto IL_10a4;
																																													case 69:
																																													case 122:
																																														goto IL_10b2;
																																													case 441:
																																														goto IL_10db;
																																													case 233:
																																														goto IL_10e9;
																																													case 460:
																																														goto IL_10fc;
																																													case 343:
																																														goto IL_114d;
																																													case 93:
																																														goto IL_115b;
																																													case 465:
																																														goto IL_116e;
																																													case 118:
																																														goto IL_117c;
																																													case 18:
																																													case 467:
																																														goto IL_118f;
																																													case 154:
																																														goto IL_119d;
																																													case 79:
																																														goto IL_11c1;
																																													case 114:
																																														goto IL_11cf;
																																													case 479:
																																														goto IL_11e2;
																																													case 425:
																																														goto IL_11f0;
																																													case 480:
																																														goto IL_1203;
																																													case 481:
																																														goto IL_1216;
																																													case 330:
																																													case 484:
																																														goto IL_1229;
																																													case 20:
																																														goto IL_1287;
																																													case 366:
																																													case 493:
																																														goto IL_129a;
																																													case 289:
																																														goto IL_12a8;
																																													case 98:
																																														goto IL_12c6;
																																													case 443:
																																														goto IL_12d4;
																																													case 260:
																																													case 497:
																																														goto IL_12e7;
																																													case 476:
																																														goto IL_1310;
																																													case 359:
																																														goto IL_131e;
																																													case 168:
																																													case 500:
																																														goto IL_1331;
																																													case 502:
																																														goto IL_134a;
																																													case 509:
																																														goto IL_135d;
																																													case 213:
																																														goto IL_136b;
																																													case 421:
																																														goto IL_1382;
																																													case 97:
																																													case 459:
																																														goto IL_1390;
																																													case 189:
																																														goto IL_13e2;
																																													case 75:
																																													case 510:
																																														goto IL_13f5;
																																													case 230:
																																														goto IL_140c;
																																													case 187:
																																														goto IL_1430;
																																													case 348:
																																														goto IL_143e;
																																													case 223:
																																													case 519:
																																														goto IL_1451;
																																													case 521:
																																														goto IL_1464;
																																													case 21:
																																													case 522:
																																														goto IL_1477;
																																													case 221:
																																														goto IL_14b7;
																																													case 203:
																																														goto IL_14d4;
																																													case 534:
																																														goto IL_14e7;
																																													case 349:
																																														goto IL_150a;
																																													case 47:
																																														goto IL_1514;
																																													case 74:
																																														goto IL_1522;
																																													case 383:
																																													case 541:
																																														goto IL_1535;
																																													case 389:
																																														goto IL_1543;
																																													case 61:
																																														goto IL_1561;
																																													case 82:
																																														goto IL_156f;
																																													case 489:
																																													case 542:
																																														goto IL_1582;
																																													case 146:
																																														goto IL_159b;
																																													case 338:
																																														goto IL_15a9;
																																													case 70:
																																														goto IL_15b7;
																																													case 546:
																																														goto IL_15ca;
																																													case 350:
																																													case 548:
																																														goto IL_15dd;
																																													case 117:
																																														goto IL_15f1;
																																													case 549:
																																														goto IL_1645;
																																													case 328:
																																														goto IL_1653;
																																													case 551:
																																														goto IL_1666;
																																													case 132:
																																														goto IL_167a;
																																													case 554:
																																														goto IL_168d;
																																													case 195:
																																														goto IL_16a4;
																																													case 556:
																																														goto IL_16b7;
																																													case 498:
																																														goto IL_16f4;
																																													case 253:
																																														goto IL_1707;
																																													case 358:
																																														goto IL_1723;
																																													case 423:
																																														goto IL_1731;
																																													case 274:
																																													case 482:
																																														goto IL_173c;
																																													case 105:
																																														goto IL_1774;
																																													case 540:
																																														goto IL_1788;
																																													case 520:
																																														goto IL_179b;
																																													case 427:
																																														goto IL_17a9;
																																													case 409:
																																													case 431:
																																														goto IL_17b7;
																																													case 528:
																																														goto IL_17c5;
																																													case 434:
																																														goto IL_17e3;
																																													case 227:
																																														goto IL_17f1;
																																													case 451:
																																														goto IL_1804;
																																													case 504:
																																														goto IL_1812;
																																													case 77:
																																													case 182:
																																														goto IL_1820;
																																													case 355:
																																														goto IL_1834;
																																													case 19:
																																														goto IL_186c;
																																													case 27:
																																													case 336:
																																														goto IL_187f;
																																													case 159:
																																														goto IL_189d;
																																													case 151:
																																														goto IL_18b4;
																																													case 496:
																																														goto IL_18c7;
																																													case 385:
																																														goto IL_18d5;
																																													case 186:
																																														goto IL_18e3;
																																													case 239:
																																														goto IL_18f1;
																																													case 258:
																																													case 290:
																																														goto IL_18fc;
																																													case 339:
																																														goto IL_190a;
																																													case 83:
																																														goto IL_1922;
																																													case 370:
																																														goto IL_1930;
																																													case 475:
																																														goto IL_1943;
																																													case 176:
																																														goto IL_1951;
																																													case 15:
																																													case 402:
																																														goto IL_195c;
																																													case 275:
																																														goto IL_1973;
																																													case 149:
																																														goto IL_198b;
																																													case 430:
																																														goto IL_1999;
																																													case 457:
																																														goto IL_19ac;
																																													case 180:
																																														goto IL_19ba;
																																													case 414:
																																													case 559:
																																														goto IL_19c5;
																																													case 68:
																																														goto IL_19e3;
																																													case 407:
																																														goto IL_19f1;
																																													case 352:
																																														goto IL_1a04;
																																													case 341:
																																														goto IL_1a12;
																																													case 43:
																																													case 190:
																																														goto IL_1a20;
																																													case 322:
																																														goto IL_1a47;
																																													case 192:
																																														goto IL_1a55;
																																													case 229:
																																														goto IL_1a6c;
																																													case 58:
																																														goto IL_1a7f;
																																													case 64:
																																														goto IL_1a8d;
																																													case 323:
																																													case 337:
																																														goto IL_1a9b;
																																													case 91:
																																														goto IL_1ab3;
																																													case 283:
																																														goto IL_1ac1;
																																													case 8:
																																													case 558:
																																														goto IL_1acc;
																																													case 184:
																																														goto IL_1aea;
																																													case 94:
																																														goto IL_1af8;
																																													case 254:
																																														goto IL_1b0b;
																																													case 445:
																																														goto IL_1b19;
																																													case 33:
																																													case 121:
																																														goto IL_1b27;
																																													case 376:
																																														goto IL_1b60;
																																													case 288:
																																														goto IL_1b74;
																																													case 73:
																																														goto IL_1b87;
																																													case 50:
																																														goto IL_1b95;
																																													case 7:
																																													case 38:
																																														goto IL_1ba3;
																																													case 368:
																																														goto IL_1bc1;
																																													case 492:
																																														goto IL_1bcf;
																																													case 199:
																																														goto IL_1bdd;
																																													case 87:
																																														goto IL_1bf0;
																																													case 485:
																																														goto IL_1bfe;
																																													case 478:
																																														goto IL_1c0c;
																																													case 95:
																																														goto IL_1c1a;
																																													case 10:
																																													case 491:
																																														goto IL_1c28;
																																													case 301:
																																														goto IL_1c3c;
																																													case 325:
																																														goto IL_1c8e;
																																													case 372:
																																														goto IL_1ca5;
																																													case 250:
																																														goto IL_1cb8;
																																													case 436:
																																														goto IL_1cc6;
																																													case 127:
																																													case 354:
																																														goto IL_1cd4;
																																													case 67:
																																														goto IL_1ce8;
																																													case 110:
																																														goto IL_1d3a;
																																													case 309:
																																														goto IL_1d48;
																																													case 194:
																																														goto IL_1d5b;
																																													case 300:
																																														goto IL_1d69;
																																													case 143:
																																													case 308:
																																														goto IL_1d77;
																																													case 211:
																																														goto IL_1d85;
																																													case 386:
																																														goto IL_1da7;
																																													case 335:
																																														goto IL_1db5;
																																													case 334:
																																													case 487:
																																														goto IL_1dc8;
																																													case 177:
																																														goto IL_1dd6;
																																													case 312:
																																														goto IL_1df9;
																																													case 286:
																																														goto IL_1e07;
																																													case 469:
																																														goto IL_1e23;
																																													case 210:
																																														goto IL_1e31;
																																													case 78:
																																													case 531:
																																														goto IL_1e3c;
																																													case 167:
																																														goto IL_1e53;
																																													case 347:
																																														goto IL_1e6c;
																																													case 112:
																																														goto IL_1e8b;
																																													case 133:
																																														goto IL_1e99;
																																													case 136:
																																														goto IL_1eac;
																																													case 518:
																																														goto IL_1eba;
																																													case 35:
																																													case 145:
																																														goto IL_1ec8;
																																													case 113:
																																														goto IL_1edc;
																																													case 206:
																																														goto IL_1f2d;
																																													case 505:
																																														goto IL_1f3b;
																																													case 474:
																																														goto IL_1f4e;
																																													case 222:
																																														goto IL_1f5c;
																																													case 111:
																																													case 420:
																																														goto IL_1f6a;
																																													case 506:
																																														goto IL_1f7e;
																																													case 410:
																																														goto IL_1fed;
																																													case 537:
																																														goto IL_2000;
																																													case 361:
																																														goto IL_200e;
																																													case 264:
																																													case 311:
																																														goto IL_201c;
																																													case 535:
																																														goto IL_2030;
																																													case 523:
																																														goto IL_206d;
																																													case 270:
																																													case 511:
																																														goto IL_2080;
																																													case 55:
																																														goto IL_20a8;
																																													case 285:
																																														goto IL_20b6;
																																													case 357:
																																														goto IL_20c9;
																																													case 403:
																																														goto IL_20d7;
																																													case 166:
																																														goto IL_20e5;
																																													case 438:
																																														goto IL_20f3;
																																													case 162:
																																														goto IL_2101;
																																													case 88:
																																													case 508:
																																														goto IL_210c;
																																													case 48:
																																														goto IL_211a;
																																													case 178:
																																														goto IL_213c;
																																													case 45:
																																														goto IL_214a;
																																													case 314:
																																														goto IL_215d;
																																													case 299:
																																														goto IL_216b;
																																													case 63:
																																													case 284:
																																														goto IL_2179;
																																													case 247:
																																														goto IL_21e1;
																																													case 526:
																																														goto end_IL_0903;
																																													case 14:
																																														goto IL_220b;
																																													case 417:
																																													case 513:
																																														goto IL_2219;
																																													case 321:
																																														goto IL_2278;
																																													case 530:
																																														goto IL_228b;
																																													case 205:
																																													case 378:
																																														goto IL_2296;
																																													case 142:
																																														goto IL_22ff;
																																													case 198:
																																														goto IL_2312;
																																													case 483:
																																														goto IL_2320;
																																													case 232:
																																													case 269:
																																														goto IL_232b;
																																													case 252:
																																														goto IL_2339;
																																													case 553:
																																														goto IL_2352;
																																													case 52:
																																														goto IL_2371;
																																													case 171:
																																														goto IL_237f;
																																													case 218:
																																														goto IL_2392;
																																													case 543:
																																														goto IL_23a0;
																																													case 204:
																																													case 209:
																																														goto IL_23ae;
																																													case 17:
																																														goto IL_23bc;
																																													case 470:
																																														goto IL_23d4;
																																													case 66:
																																														goto IL_23e2;
																																													case 342:
																																														goto IL_23f5;
																																													case 59:
																																														goto IL_2403;
																																													case 174:
																																													case 397:
																																														goto IL_2411;
																																													case 533:
																																														goto IL_2466;
																																													case 175:
																																													case 315:
																																														goto IL_2482;
																																													case 101:
																																														goto IL_24ad;
																																													case 119:
																																														goto IL_24c6;
																																													case 388:
																																														goto IL_24d4;
																																													case 377:
																																														goto IL_24e2;
																																													case 517:
																																														goto IL_24f0;
																																													case 41:
																																													case 373:
																																														goto IL_24fb;
																																													case 422:
																																														goto IL_2509;
																																													case 514:
																																														goto IL_2534;
																																													case 503:
																																														goto IL_2542;
																																													case 346:
																																														goto IL_2555;
																																													case 120:
																																														goto IL_2563;
																																													case 440:
																																													case 557:
																																														goto IL_2571;
																																													case 37:
																																														goto IL_25da;
																																													case 538:
																																														goto IL_25ed;
																																													case 181:
																																														goto IL_2604;
																																													case 442:
																																													case 499:
																																														goto IL_2612;
																																													case 340:
																																														goto IL_264f;
																																													case 139:
																																														goto IL_265d;
																																													case 2:
																																													case 527:
																																														goto IL_2682;
																																													case 34:
																																														goto IL_26b5;
																																													case 102:
																																														goto IL_26ce;
																																													case 9:
																																														goto IL_26dc;
																																													case 524:
																																														goto IL_26e7;
																																													case 56:
																																													case 109:
																																														goto IL_26f5;
																																													case 453:
																																														goto IL_2742;
																																													case 153:
																																														goto IL_2750;
																																													case 345:
																																														goto IL_2763;
																																													case 416:
																																														goto IL_2771;
																																													case 160:
																																														goto IL_278d;
																																													case 155:
																																													case 280:
																																														goto IL_2798;
																																													case 448:
																																														goto IL_27ab;
																																													case 428:
																																														goto IL_27b9;
																																													case 401:
																																														goto IL_27c9;
																																													case 31:
																																														goto IL_27d4;
																																													case 191:
																																													case 507:
																																														goto IL_27df;
																																													case 390:
																																														goto IL_280a;
																																													case 4:
																																													case 5:
																																													case 11:
																																													case 30:
																																													case 54:
																																													case 57:
																																													case 65:
																																													case 71:
																																													case 89:
																																													case 115:
																																													case 123:
																																													case 135:
																																													case 137:
																																													case 141:
																																													case 148:
																																													case 152:
																																													case 158:
																																													case 179:
																																													case 193:
																																													case 196:
																																													case 197:
																																													case 201:
																																													case 212:
																																													case 214:
																																													case 219:
																																													case 224:
																																													case 228:
																																													case 241:
																																													case 246:
																																													case 255:
																																													case 261:
																																													case 265:
																																													case 276:
																																													case 282:
																																													case 291:
																																													case 292:
																																													case 293:
																																													case 305:
																																													case 306:
																																													case 307:
																																													case 319:
																																													case 333:
																																													case 353:
																																													case 362:
																																													case 365:
																																													case 374:
																																													case 387:
																																													case 391:
																																													case 404:
																																													case 411:
																																													case 419:
																																													case 432:
																																													case 439:
																																													case 444:
																																													case 450:
																																													case 463:
																																													case 472:
																																													case 488:
																																													case 495:
																																													case 501:
																																													case 512:
																																													case 515:
																																													case 516:
																																													case 525:
																																													case 539:
																																													case 545:
																																													case 547:
																																													case 552:
																																													case 555:
																																														goto end_IL_0916;
																																													case 0:
																																													case 1:
																																													case 6:
																																													case 26:
																																													case 29:
																																													case 44:
																																													case 62:
																																													case 80:
																																													case 90:
																																													case 96:
																																													case 108:
																																													case 126:
																																													case 138:
																																													case 156:
																																													case 161:
																																													case 163:
																																													case 170:
																																													case 172:
																																													case 183:
																																													case 200:
																																													case 202:
																																													case 207:
																																													case 220:
																																													case 225:
																																													case 235:
																																													case 237:
																																													case 244:
																																													case 245:
																																													case 256:
																																													case 263:
																																													case 267:
																																													case 271:
																																													case 272:
																																													case 273:
																																													case 281:
																																													case 297:
																																													case 298:
																																													case 303:
																																													case 304:
																																													case 326:
																																													case 331:
																																													case 344:
																																													case 351:
																																													case 360:
																																													case 363:
																																													case 369:
																																													case 380:
																																													case 394:
																																													case 399:
																																													case 400:
																																													case 408:
																																													case 413:
																																													case 418:
																																													case 429:
																																													case 454:
																																													case 458:
																																													case 461:
																																													case 462:
																																													case 464:
																																													case 468:
																																													case 471:
																																													case 477:
																																													case 486:
																																													case 490:
																																													case 494:
																																													case 529:
																																													case 532:
																																													case 536:
																																													case 544:
																																														goto end_IL_09ec;
																																													case 550:
																																														goto end_IL_2833;
																																													case 329:
																																														goto end_IL_2846;
																																													case 257:
																																														goto end_IL_2850;
																																													case 395:
																																														goto end_IL_285b;
																																													case 320:
																																														goto end_IL_2871;
																																													case 473:
																																														goto end_IL_2890;
																																													case 396:
																																														goto end_IL_28a6;
																																													case 157:
																																														goto end_IL_28bc;
																																													case 13:
																																														goto end_IL_28d2;
																																													case 296:
																																														goto end_IL_28e2;
																																													case 131:
																																														goto end_IL_28fb;
																																													case 262:
																																														goto end_IL_290b;
																																													case 381:
																																														goto end_IL_291b;
																																													case 116:
																																													case 318:
																																														goto end_IL_2934;
																																													case 84:
																																														goto end_IL_2944;
																																													case 85:
																																														goto end_IL_295d;
																																													case 107:
																																													case 405:
																																														return;
																																													}
																																													continue;
																																												}
																																												goto IL_1707;
																																												IL_1707:
																																												byte* num5 = ptr2;
																																												num4 = 1;
																																												ptr2 = num5 + -200;
																																												goto end_IL_09ec;
																																												continue;
																																												end_IL_0903:
																																												break;
																																											}
																																											goto IL_21fd;
																																											continue;
																																											end_IL_0916:
																																											break;
																																											IL_0916:;
																																										}
																																										break;
																																										IL_0929:;
																																									}
																																									break;
																																								}
																																								goto IL_0a95;
																																								IL_131e:
																																								ptr2 += 8;
																																								goto end_IL_09ec;
																																								IL_0a95:
																																								if (18 > b)
																																								{
																																									goto IL_0aa3;
																																								}
																																								goto IL_12e7;
																																								IL_0aa3:
																																								if (17 < b)
																																								{
																																									break;
																																								}
																																								goto IL_0ab1;
																																								IL_0ab1:
																																								if (17 > b)
																																								{
																																									break;
																																								}
																																								goto IL_0fd6;
																																								IL_0fd6:
																																								array2[num6] = array6[*(int*)(ptr2 + num3)];
																																								goto IL_0fee;
																																								IL_0fee:
																																								array[num6] = 5;
																																								goto IL_11e2;
																																								IL_11e2:
																																								num6++;
																																								goto IL_11f0;
																																								IL_11f0:
																																								ptr2 += 8;
																																								goto end_IL_09ec;
																																								IL_12e7:
																																								((delegate*<UnityEngine.Object, void>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Class118)array2[num6 - 1]);
																																								goto IL_1310;
																																								IL_1310:
																																								num6--;
																																								goto IL_131e;
																																							}
																																							break;
																																						}
																																						goto IL_0a00;
																																						IL_0a15:
																																						ptr2 += 8;
																																						goto end_IL_09ec;
																																						IL_0a00:
																																						((delegate*<void>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])();
																																						goto IL_0a15;
																																					}
																																					break;
																																				}
																																				goto IL_1723;
																																				IL_186c:
																																				ptr2 += 8;
																																				goto end_IL_09ec;
																																				IL_1723:
																																				if (22 >= b)
																																				{
																																					goto IL_1731;
																																				}
																																				goto IL_1804;
																																				IL_1731:
																																				if (22 <= b)
																																				{
																																					goto IL_173c;
																																				}
																																				goto IL_179b;
																																				IL_173c:
																																				array2[num6 - 1] = ((delegate*<GTPlayer, SphereCollider>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((GTPlayer)array2[num6 - 1]);
																																				goto IL_1774;
																																				IL_1774:
																																				array[num6 - 1] = 5;
																																				goto IL_1788;
																																				IL_1788:
																																				ptr2 += 8;
																																				goto end_IL_09ec;
																																				IL_179b:
																																				if (21 < b)
																																				{
																																					break;
																																				}
																																				goto IL_17a9;
																																				IL_17a9:
																																				if (21 > b)
																																				{
																																					break;
																																				}
																																				goto IL_17b7;
																																				IL_17b7:
																																				array[num6] = 5;
																																				goto IL_17c5;
																																				IL_17c5:
																																				array2[num6] = ((delegate*<GTPlayer>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])();
																																				goto IL_17e3;
																																				IL_17e3:
																																				num6++;
																																				goto IL_17f1;
																																				IL_17f1:
																																				ptr2 += 8;
																																				goto end_IL_09ec;
																																				IL_1804:
																																				if (23 < b)
																																				{
																																					break;
																																				}
																																				goto IL_1812;
																																				IL_1812:
																																				if (23 > b)
																																				{
																																					break;
																																				}
																																				goto IL_1820;
																																				IL_1820:
																																				array[num6 - 1] = 5;
																																				goto IL_1834;
																																				IL_1834:
																																				array2[num6 - 1] = ((delegate*<Component, Transform>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((SphereCollider)array2[num6 - 1]);
																																				goto IL_186c;
																																			}
																																			break;
																																		}
																																		goto IL_0a28;
																																		IL_0a82:
																																		ptr2 += 8;
																																		goto end_IL_09ec;
																																		IL_0a28:
																																		array[num6 - 1] = 4;
																																		goto IL_0a3c;
																																		IL_0a3c:
																																		array2[num6 - 1] = ((delegate*<Transform, Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																																		num = 234;
																																		goto IL_0a82;
																																	}
																																	break;
																																}
																																goto IL_0c13;
																																IL_15dd:
																																array[num6 - 2] = 4;
																																goto IL_15f1;
																																IL_15f1:
																																array2[num6 - 2] = ((delegate*<Vector3, float, Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																																goto IL_168d;
																																IL_0c13:
																																if (28 >= b)
																																{
																																	goto IL_0c1e;
																																}
																																goto IL_0c4d;
																																IL_0c1e:
																																if (28 > b)
																																{
																																	goto IL_0c2c;
																																}
																																goto IL_0cd4;
																																IL_0c2c:
																																if (26 < b)
																																{
																																	goto IL_0c3a;
																																}
																																goto IL_0d62;
																																IL_0c3a:
																																if (27 < b)
																																{
																																	break;
																																}
																																goto IL_0fc3;
																																IL_0fc3:
																																if (27 > b)
																																{
																																	break;
																																}
																																goto IL_1331;
																																IL_1331:
																																array[num6 - 1] = 4;
																																goto IL_16b7;
																																IL_16b7:
																																array2[num6 - 1] = ((delegate*<Transform, Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																																goto IL_16f4;
																																IL_16f4:
																																ptr2 += 8;
																																goto end_IL_09ec;
																																IL_0d62:
																																if (26 <= b)
																																{
																																	goto IL_0d70;
																																}
																																goto IL_1001;
																																IL_0d70:
																																array[num6 - 1] = 5;
																																goto IL_104b;
																																IL_104b:
																																array2[num6 - 1] = ((delegate*<Component, Transform>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((SphereCollider)array2[num6 - 1]);
																																goto IL_1083;
																																IL_1083:
																																ptr2 += 8;
																																goto end_IL_09ec;
																																IL_1001:
																																if (25 < b)
																																{
																																	break;
																																}
																																goto IL_1203;
																																IL_1203:
																																if (25 > b)
																																{
																																	break;
																																}
																																goto IL_1535;
																																IL_1535:
																																array[num6] = 5;
																																goto IL_1543;
																																IL_1543:
																																array2[num6] = ((delegate*<GTPlayer>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])();
																																goto IL_1561;
																																IL_1561:
																																num6++;
																																goto IL_156f;
																																IL_156f:
																																ptr2 += 8;
																																goto end_IL_09ec;
																																IL_0cd4:
																																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																																goto IL_0cee;
																																IL_0cee:
																																array[num6] = 3;
																																goto IL_0cfc;
																																IL_0cfc:
																																num6++;
																																goto IL_0d0a;
																																IL_0d0a:
																																ptr2 += 8;
																																goto end_IL_09ec;
																																IL_0c4d:
																																if (30 < b)
																																{
																																	goto IL_0c5b;
																																}
																																goto IL_0d1d;
																																IL_0c5b:
																																if (31 >= b)
																																{
																																	num = 251;
																																	goto IL_0c6f;
																																}
																																goto IL_0caa;
																																IL_168d:
																																num6--;
																																num = 195;
																																goto IL_16a4;
																																IL_0c6f:
																																if (31 > b)
																																{
																																	break;
																																}
																																goto IL_0c7d;
																																IL_0c7d:
																																array6[*(int*)(ptr2 + num3)] = (Vector3)array2[num6 - 1];
																																goto IL_1645;
																																IL_1645:
																																ptr2 += 8;
																																goto IL_1653;
																																IL_1653:
																																num6--;
																																goto end_IL_09ec;
																																IL_0caa:
																																if (32 < b)
																																{
																																	break;
																																}
																																num = 238;
																																goto IL_0cc1;
																																IL_16a4:
																																ptr2 += 8;
																																goto end_IL_09ec;
																																IL_0cc1:
																																if (32 > b)
																																{
																																	break;
																																}
																																goto IL_129a;
																																IL_129a:
																																array[num6] = 5;
																																goto IL_12a8;
																																IL_12a8:
																																array2[num6] = ((delegate*<List<GameEntityCreateData>>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])();
																																goto IL_12c6;
																																IL_12c6:
																																num6++;
																																goto IL_12d4;
																																IL_12d4:
																																ptr2 += 8;
																																goto end_IL_09ec;
																																IL_0d1d:
																																if (30 <= b)
																																{
																																	goto IL_0d28;
																																}
																																goto IL_0d41;
																																IL_0d28:
																																array[num6 - 2] = 4;
																																goto IL_10fc;
																																IL_10fc:
																																array2[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																																goto IL_114d;
																																IL_114d:
																																num6--;
																																goto IL_115b;
																																IL_115b:
																																ptr2 += 8;
																																goto end_IL_09ec;
																																IL_0d41:
																																if (29 < b)
																																{
																																	break;
																																}
																																goto IL_0d4f;
																																IL_0d4f:
																																if (29 > b)
																																{
																																	break;
																																}
																																goto IL_15dd;
																															}
																															break;
																														}
																														goto IL_0ac4;
																														IL_0f30:
																														if (7 > b)
																														{
																															break;
																														}
																														num = 406;
																														goto IL_0f47;
																														IL_0ac4:
																														if (16 > b)
																														{
																															goto IL_0ad2;
																														}
																														num = 330;
																														goto IL_1229;
																														IL_0ad2:
																														if (8 < b)
																														{
																															goto IL_0ae0;
																														}
																														goto IL_0d89;
																														IL_0ae0:
																														if (12 < b)
																														{
																															goto IL_0aeb;
																														}
																														num = 243;
																														goto IL_0b20;
																														IL_0aeb:
																														if (14 < b)
																														{
																															goto IL_0af6;
																														}
																														num = 509;
																														goto IL_135d;
																														IL_0af6:
																														if (15 < b)
																														{
																															break;
																														}
																														goto IL_0c00;
																														IL_0c00:
																														if (15 > b)
																														{
																															break;
																														}
																														goto IL_0fb3;
																														IL_0fb3:
																														array[num6] = 0;
																														goto IL_1014;
																														IL_1014:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = (((delegate*<bool>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])() ? 1 : 0);
																														goto IL_1038;
																														IL_1038:
																														num6++;
																														goto IL_1464;
																														IL_1464:
																														ptr2 += 8;
																														goto end_IL_09ec;
																														IL_0f87:
																														array[num6 - 2] = 0;
																														goto IL_1216;
																														IL_135d:
																														if (14 > b)
																														{
																															goto IL_136b;
																														}
																														goto IL_13f5;
																														IL_136b:
																														if (13 < b)
																														{
																															break;
																														}
																														num = 421;
																														goto IL_1382;
																														IL_1216:
																														num6--;
																														goto end_IL_09ec;
																														IL_1382:
																														if (13 > b)
																														{
																															break;
																														}
																														goto IL_1390;
																														IL_1390:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_13e2;
																														IL_13e2:
																														num6--;
																														goto end_IL_09ec;
																														IL_13f5:
																														array[num6] = 0;
																														num = 230;
																														goto IL_140c;
																														IL_140c:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = (((delegate*<bool>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])() ? 1 : 0);
																														goto IL_1430;
																														IL_1430:
																														num6++;
																														goto IL_143e;
																														IL_143e:
																														ptr2 += 8;
																														goto end_IL_09ec;
																														IL_0f47:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0f87;
																														IL_0b20:
																														if (12 > b)
																														{
																															goto IL_0b2e;
																														}
																														goto IL_118f;
																														IL_0b2e:
																														if (10 >= b)
																														{
																															goto IL_0b3c;
																														}
																														goto IL_0bbf;
																														IL_0b3c:
																														if (10 <= b)
																														{
																															goto IL_0b4a;
																														}
																														goto IL_116e;
																														IL_0b4a:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_0bac;
																														IL_0bac:
																														num6 -= 2;
																														goto end_IL_09ec;
																														IL_116e:
																														if (9 < b)
																														{
																															break;
																														}
																														goto IL_117c;
																														IL_117c:
																														if (9 > b)
																														{
																															break;
																														}
																														goto IL_1477;
																														IL_1477:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_14b7;
																														IL_14b7:
																														array[num6 - 2] = 0;
																														num = 203;
																														goto IL_14d4;
																														IL_14d4:
																														num6--;
																														goto end_IL_09ec;
																														IL_0bbf:
																														if (11 < b)
																														{
																															break;
																														}
																														num = 100;
																														goto IL_0bd6;
																														IL_0fa0:
																														num6--;
																														goto end_IL_09ec;
																														IL_0bd6:
																														if (11 > b)
																														{
																															break;
																														}
																														num = 331;
																														goto end_IL_09ec;
																														IL_1287:
																														num6--;
																														goto end_IL_09ec;
																														IL_118f:
																														array[num6] = 0;
																														goto IL_119d;
																														IL_119d:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = (((delegate*<bool>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])() ? 1 : 0);
																														goto IL_11c1;
																														IL_11c1:
																														num6++;
																														goto IL_11cf;
																														IL_11cf:
																														ptr2 += 8;
																														goto end_IL_09ec;
																														IL_0d89:
																														if (8 > b)
																														{
																															goto IL_0d97;
																														}
																														goto IL_0fa0;
																														IL_0d97:
																														if (4 >= b)
																														{
																															goto IL_0da5;
																														}
																														goto IL_0e32;
																														IL_0da5:
																														if (4 > b)
																														{
																															goto IL_0db3;
																														}
																														goto IL_1451;
																														IL_0db3:
																														if (2 >= b)
																														{
																															goto IL_0dc1;
																														}
																														goto IL_1096;
																														IL_0dc1:
																														if (2 <= b)
																														{
																															goto IL_0dcc;
																														}
																														goto IL_0e11;
																														IL_0dcc:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_1666;
																														IL_1666:
																														array[num6 - 2] = 0;
																														goto IL_167a;
																														IL_167a:
																														num6--;
																														goto end_IL_09ec;
																														IL_0e11:
																														if (1 < b)
																														{
																															break;
																														}
																														goto IL_0e1f;
																														IL_0e1f:
																														if (1 > b)
																														{
																															break;
																														}
																														goto IL_1582;
																														IL_1582:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																														goto IL_159b;
																														IL_159b:
																														array[num6] = 0;
																														goto IL_15a9;
																														IL_15a9:
																														num6++;
																														goto IL_15b7;
																														IL_15b7:
																														ptr2 += 8;
																														goto end_IL_09ec;
																														IL_1096:
																														if (3 < b)
																														{
																															break;
																														}
																														goto IL_10a4;
																														IL_10a4:
																														if (3 > b)
																														{
																															break;
																														}
																														goto IL_10b2;
																														IL_10b2:
																														ref int reference = ref array4[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_10db;
																														IL_10db:
																														ptr2 += 8;
																														goto IL_10e9;
																														IL_10e9:
																														num6--;
																														goto end_IL_09ec;
																														IL_1451:
																														array[num6] = 0;
																														goto IL_14e7;
																														IL_14e7:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																														goto IL_150a;
																														IL_150a:
																														array2[num6] = null;
																														goto IL_1514;
																														IL_1514:
																														num6++;
																														goto IL_1522;
																														IL_1522:
																														ptr2 += 8;
																														goto end_IL_09ec;
																														IL_0e32:
																														if (6 >= b)
																														{
																															goto IL_0e40;
																														}
																														goto IL_0f22;
																														IL_0e40:
																														if (6 <= b)
																														{
																															goto IL_0e4b;
																														}
																														goto IL_0ea4;
																														IL_0e4b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0e8b;
																														IL_0e8b:
																														array[num6 - 2] = 0;
																														goto IL_134a;
																														IL_134a:
																														num6--;
																														goto end_IL_09ec;
																														IL_0ea4:
																														if (5 < b)
																														{
																															break;
																														}
																														goto IL_0eb2;
																														IL_0eb2:
																														if (5 > b)
																														{
																															break;
																														}
																														num = 371;
																														goto IL_0ec9;
																														IL_1229:
																														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_1287;
																														IL_0ec9:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0f09;
																														IL_0f09:
																														array[num6 - 2] = 0;
																														goto IL_15ca;
																														IL_15ca:
																														num6--;
																														goto end_IL_09ec;
																														IL_0f22:
																														if (7 < b)
																														{
																															break;
																														}
																														goto IL_0f30;
																													}
																													break;
																												}
																												goto IL_187f;
																												IL_18b4:
																												num6--;
																												goto end_IL_09ec;
																												IL_187f:
																												array6[*(int*)(ptr2 + num3)] = array2[num6 - 1];
																												goto IL_189d;
																												IL_189d:
																												ptr2 += 8;
																												num = 151;
																												goto IL_18b4;
																											}
																											break;
																										}
																										goto IL_18c7;
																										IL_27b9:
																										num6++;
																										goto end_IL_09ec;
																										IL_18c7:
																										if (50 >= b)
																										{
																											goto IL_18d5;
																										}
																										goto IL_20c9;
																										IL_18d5:
																										if (50 > b)
																										{
																											goto IL_18e3;
																										}
																										goto IL_2080;
																										IL_18e3:
																										if (41 >= b)
																										{
																											goto IL_18f1;
																										}
																										goto IL_1bf0;
																										IL_18f1:
																										if (41 <= b)
																										{
																											goto IL_18fc;
																										}
																										goto IL_1943;
																										IL_18fc:
																										array[num6] = 5;
																										goto IL_190a;
																										IL_190a:
																										array2[num6] = array6[*(int*)(ptr2 + num3)];
																										goto IL_1922;
																										IL_1922:
																										num6++;
																										goto IL_1930;
																										IL_1930:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_1943:
																										if (37 >= b)
																										{
																											goto IL_1951;
																										}
																										goto IL_1ab3;
																										IL_1951:
																										if (37 <= b)
																										{
																											goto IL_195c;
																										}
																										goto IL_19ac;
																										IL_195c:
																										array[num6] = 5;
																										num = 275;
																										goto IL_1973;
																										IL_1973:
																										array2[num6] = array6[*(int*)(ptr2 + num3)];
																										goto IL_198b;
																										IL_198b:
																										num6++;
																										goto IL_1999;
																										IL_1999:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_19ac:
																										if (35 >= b)
																										{
																											goto IL_19ba;
																										}
																										goto IL_1a7f;
																										IL_19ba:
																										if (35 <= b)
																										{
																											goto IL_19c5;
																										}
																										goto IL_1a04;
																										IL_19c5:
																										array6[*(int*)(ptr2 + num3)] = array2[num6 - 1];
																										goto IL_19e3;
																										IL_19e3:
																										ptr2 += 8;
																										goto IL_19f1;
																										IL_19f1:
																										num6--;
																										goto end_IL_09ec;
																										IL_1a04:
																										if (34 < b)
																										{
																											break;
																										}
																										goto IL_1a12;
																										IL_1a12:
																										if (34 > b)
																										{
																											break;
																										}
																										goto IL_1a20;
																										IL_1a20:
																										array2[num6] = ((delegate*<string[]>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])();
																										num = 322;
																										goto IL_1a47;
																										IL_1a47:
																										array[num6] = 5;
																										goto IL_1a55;
																										IL_1a55:
																										num6++;
																										num = 229;
																										goto IL_1a6c;
																										IL_1a6c:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_1a7f:
																										if (36 < b)
																										{
																											break;
																										}
																										goto IL_1a8d;
																										IL_1a8d:
																										if (36 > b)
																										{
																											break;
																										}
																										goto IL_1a9b;
																										IL_1a9b:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_09ec;
																										IL_1ab3:
																										if (39 >= b)
																										{
																											goto IL_1ac1;
																										}
																										goto IL_1b87;
																										IL_1ac1:
																										if (39 <= b)
																										{
																											goto IL_1acc;
																										}
																										goto IL_1b0b;
																										IL_1acc:
																										array6[*(int*)(ptr2 + num3)] = array2[num6 - 1];
																										goto IL_1aea;
																										IL_1aea:
																										ptr2 += 8;
																										goto IL_1af8;
																										IL_1af8:
																										num6--;
																										goto end_IL_09ec;
																										IL_1b0b:
																										if (38 < b)
																										{
																											break;
																										}
																										goto IL_1b19;
																										IL_1b19:
																										if (38 > b)
																										{
																											break;
																										}
																										goto IL_1b27;
																										IL_1b27:
																										array2[num6 - 2] = ((string[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])];
																										goto IL_1b60;
																										IL_1b60:
																										array[num6 - 2] = 5;
																										goto IL_1b74;
																										IL_1b74:
																										num6--;
																										goto end_IL_09ec;
																										IL_1b87:
																										if (40 < b)
																										{
																											break;
																										}
																										goto IL_1b95;
																										IL_1b95:
																										if (40 > b)
																										{
																											break;
																										}
																										goto IL_1ba3;
																										IL_1ba3:
																										array2[num6] = ((delegate*<Dictionary<string, int>>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])();
																										goto IL_1bc1;
																										IL_1bc1:
																										array[num6] = 5;
																										goto IL_1bcf;
																										IL_1bcf:
																										num6++;
																										goto IL_1bdd;
																										IL_1bdd:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_1bf0:
																										if (45 >= b)
																										{
																											goto IL_1bfe;
																										}
																										goto IL_1e23;
																										IL_1bfe:
																										if (45 > b)
																										{
																											goto IL_1c0c;
																										}
																										goto IL_1dc8;
																										IL_1c0c:
																										if (43 >= b)
																										{
																											goto IL_1c1a;
																										}
																										goto IL_1d5b;
																										IL_1c1a:
																										if (43 <= b)
																										{
																											goto IL_1c28;
																										}
																										goto IL_1cb8;
																										IL_1c28:
																										array[num6 - 2] = 0;
																										goto IL_1c3c;
																										IL_1c3c:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num6 - 2], (string)array2[num6 - 1]);
																										goto IL_1c8e;
																										IL_1c8e:
																										num6--;
																										num = 372;
																										goto IL_1ca5;
																										IL_1ca5:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_1cb8:
																										if (42 < b)
																										{
																											break;
																										}
																										goto IL_1cc6;
																										IL_1cc6:
																										if (42 > b)
																										{
																											break;
																										}
																										goto IL_1cd4;
																										IL_1cd4:
																										array[num6 - 2] = 0;
																										goto IL_1ce8;
																										IL_1ce8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num6 - 2], (string)array2[num6 - 1]) ? 1 : 0);
																										goto IL_1d3a;
																										IL_1d3a:
																										num6--;
																										goto IL_1d48;
																										IL_1d48:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_1d5b:
																										if (44 < b)
																										{
																											break;
																										}
																										goto IL_1d69;
																										IL_1d69:
																										if (44 > b)
																										{
																											break;
																										}
																										goto IL_1d77;
																										IL_1d77:
																										array[num6] = 4;
																										goto IL_1d85;
																										IL_1d85:
																										array2[num6] = (Vector3)array6[*(int*)(ptr2 + num3)];
																										goto IL_1da7;
																										IL_1da7:
																										num6++;
																										goto IL_1db5;
																										IL_1db5:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_1dc8:
																										array[num6] = 4;
																										goto IL_1dd6;
																										IL_1dd6:
																										array2[num6] = ((delegate*<Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])();
																										goto IL_1df9;
																										IL_1df9:
																										num6++;
																										goto IL_1e07;
																										IL_1e07:
																										ptr2 += 8;
																										num = 303;
																										goto end_IL_09ec;
																										IL_1e23:
																										if (47 >= b)
																										{
																											goto IL_1e31;
																										}
																										goto IL_1f4e;
																										IL_1e31:
																										if (47 <= b)
																										{
																											goto IL_1e3c;
																										}
																										goto IL_1eac;
																										IL_1e3c:
																										array[num6] = 13;
																										num = 167;
																										goto IL_1e53;
																										IL_1e53:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																										goto IL_1e6c;
																										IL_1e6c:
																										array3[num6 - 0] = *(int*)(ptr2 + 8 + num3);
																										goto IL_1e8b;
																										IL_1e8b:
																										num6++;
																										goto IL_1e99;
																										IL_1e99:
																										ptr2 += 16;
																										goto end_IL_09ec;
																										IL_1eac:
																										if (46 < b)
																										{
																											break;
																										}
																										goto IL_1eba;
																										IL_1eba:
																										if (46 > b)
																										{
																											break;
																										}
																										goto IL_1ec8;
																										IL_1ec8:
																										array[num6 - 2] = 4;
																										goto IL_1edc;
																										IL_1edc:
																										array2[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																										goto IL_1f2d;
																										IL_1f2d:
																										num6--;
																										goto IL_1f3b;
																										IL_1f3b:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_1f4e:
																										if (48 >= b)
																										{
																											goto IL_1f5c;
																										}
																										goto IL_2000;
																										IL_1f5c:
																										if (48 > b)
																										{
																											break;
																										}
																										goto IL_1f6a;
																										IL_1f6a:
																										array[num6 - 1] = 4;
																										goto IL_1f7e;
																										IL_1f7e:
																										array2[num6 - 1] = ((delegate*<ref Vector3, Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)ThrowOnEventWriteErrorsDateTimeOffset[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																										goto IL_1fed;
																										IL_1fed:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_2000:
																										if (49 < b)
																										{
																											break;
																										}
																										goto IL_200e;
																										IL_200e:
																										if (49 > b)
																										{
																											break;
																										}
																										goto IL_201c;
																										IL_201c:
																										array[num6 - 1] = 4;
																										goto IL_2030;
																										IL_2030:
																										array2[num6 - 1] = ((delegate*<Vector3, Quaternion>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 1]);
																										goto IL_206d;
																										IL_206d:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_2080:
																										array6[*(int*)(ptr2 + num3)] = (Quaternion)array2[num6 - 1];
																										goto IL_20a8;
																										IL_20a8:
																										ptr2 += 8;
																										goto IL_20b6;
																										IL_20b6:
																										num6--;
																										goto end_IL_09ec;
																										IL_20c9:
																										if (58 >= b)
																										{
																											goto IL_20d7;
																										}
																										goto IL_24c6;
																										IL_20d7:
																										if (58 > b)
																										{
																											goto IL_20e5;
																										}
																										num = 315;
																										goto IL_2482;
																										IL_20e5:
																										if (54 < b)
																										{
																											goto IL_20f3;
																										}
																										goto IL_228b;
																										IL_20f3:
																										if (56 >= b)
																										{
																											goto IL_2101;
																										}
																										goto IL_21fd;
																										IL_2101:
																										if (56 <= b)
																										{
																											goto IL_210c;
																										}
																										goto IL_215d;
																										IL_210c:
																										array[num6] = 4;
																										goto IL_211a;
																										IL_211a:
																										array2[num6] = (Quaternion)array6[*(int*)(ptr2 + num3)];
																										goto IL_213c;
																										IL_213c:
																										num6++;
																										goto IL_214a;
																										IL_214a:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_215d:
																										if (55 < b)
																										{
																											break;
																										}
																										goto IL_216b;
																										IL_216b:
																										if (55 > b)
																										{
																											break;
																										}
																										goto IL_2179;
																										IL_2179:
																										((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ThrowOnEventWriteErrorsDateTimeOffset[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).position = (Vector3)array2[num6 - 1];
																										num = 247;
																										goto IL_21e1;
																										IL_21e1:
																										num6 -= 2;
																										num = 6;
																										goto end_IL_09ec;
																										IL_21fd:
																										if (57 < b)
																										{
																											break;
																										}
																										goto IL_220b;
																										IL_220b:
																										if (57 > b)
																										{
																											break;
																										}
																										goto IL_2219;
																										IL_2219:
																										((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ThrowOnEventWriteErrorsDateTimeOffset[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).rotation = (Quaternion)array2[num6 - 1];
																										goto IL_2278;
																										IL_2278:
																										num6 -= 2;
																										goto end_IL_09ec;
																										IL_228b:
																										if (54 <= b)
																										{
																											goto IL_2296;
																										}
																										goto IL_2312;
																										IL_2296:
																										((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ThrowOnEventWriteErrorsDateTimeOffset[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).entityTypeId = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										num = 142;
																										goto IL_22ff;
																										IL_22ff:
																										num6 -= 2;
																										goto end_IL_09ec;
																										IL_2312:
																										if (52 >= b)
																										{
																											goto IL_2320;
																										}
																										goto IL_23f5;
																										IL_2320:
																										if (52 <= b)
																										{
																											goto IL_232b;
																										}
																										goto IL_2392;
																										IL_232b:
																										array[num6] = 13;
																										goto IL_2339;
																										IL_2339:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																										goto IL_2352;
																										IL_2352:
																										array3[num6 - 0] = *(int*)(ptr2 + 8 + num3);
																										goto IL_2371;
																										IL_2371:
																										num6++;
																										goto IL_237f;
																										IL_237f:
																										ptr2 += 16;
																										goto end_IL_09ec;
																										IL_2392:
																										if (51 < b)
																										{
																											break;
																										}
																										goto IL_23a0;
																										IL_23a0:
																										if (51 > b)
																										{
																											break;
																										}
																										goto IL_23ae;
																										IL_23ae:
																										array[num6] = 5;
																										goto IL_23bc;
																										IL_23bc:
																										array2[num6] = array6[*(int*)(ptr2 + num3)];
																										goto IL_23d4;
																										IL_23d4:
																										num6++;
																										goto IL_23e2;
																										IL_23e2:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_23f5:
																										if (53 < b)
																										{
																											break;
																										}
																										goto IL_2403;
																										IL_2403:
																										if (53 > b)
																										{
																											break;
																										}
																										goto IL_2411;
																										IL_2411:
																										((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ThrowOnEventWriteErrorsDateTimeOffset[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4) = default(GameEntityCreateData);
																										num = 533;
																										goto IL_2466;
																										IL_2466:
																										num6--;
																										goto end_IL_09ec;
																										IL_27c9:
																										if (63 < b)
																										{
																											break;
																										}
																										goto IL_27d4;
																										IL_2482:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_24ad;
																										IL_24ad:
																										array[num6 - 1] = 1;
																										goto end_IL_09ec;
																										IL_24c6:
																										if (62 >= b)
																										{
																											goto IL_24d4;
																										}
																										goto IL_26ce;
																										IL_24d4:
																										if (62 > b)
																										{
																											goto IL_24e2;
																										}
																										num = 527;
																										goto IL_2682;
																										IL_24e2:
																										if (60 >= b)
																										{
																											goto IL_24f0;
																										}
																										goto IL_25ed;
																										IL_24f0:
																										if (60 <= b)
																										{
																											goto IL_24fb;
																										}
																										goto IL_2555;
																										IL_24fb:
																										array[num6] = 4;
																										goto IL_2509;
																										IL_2509:
																										array2[num6] = (GameEntityCreateData)array6[*(int*)(ptr2 + num3)];
																										num = 514;
																										goto IL_2534;
																										IL_2534:
																										num6++;
																										goto IL_2542;
																										IL_2542:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_2555:
																										if (59 < b)
																										{
																											break;
																										}
																										goto IL_2563;
																										IL_2563:
																										if (59 > b)
																										{
																											break;
																										}
																										goto IL_2571;
																										IL_2571:
																										((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ThrowOnEventWriteErrorsDateTimeOffset[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).createData = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										num = 37;
																										goto IL_25da;
																										IL_25da:
																										num6 -= 2;
																										goto end_IL_09ec;
																										IL_25ed:
																										if (61 < b)
																										{
																											break;
																										}
																										num = 181;
																										goto IL_2604;
																										IL_27df:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_280a;
																										IL_2604:
																										if (61 > b)
																										{
																											break;
																										}
																										goto IL_2612;
																										IL_2612:
																										((delegate*<List<GameEntityCreateData>, GameEntityCreateData, void>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num6 - 2], (GameEntityCreateData)array2[num6 - 1]);
																										goto IL_264f;
																										IL_264f:
																										num6 -= 2;
																										goto IL_265d;
																										IL_265d:
																										ptr2 += 8;
																										num = 408;
																										goto end_IL_09ec;
																										IL_27d4:
																										if (63 > b)
																										{
																											break;
																										}
																										goto IL_27df;
																										IL_2682:
																										*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (nint)((string[])array2[num6 - 1]).LongLength;
																										num = 34;
																										goto IL_26b5;
																										IL_26b5:
																										array[num6 - 1] = 2;
																										goto end_IL_09ec;
																										IL_26ce:
																										if (64 < b)
																										{
																											goto IL_26dc;
																										}
																										num = 160;
																										goto IL_278d;
																										IL_26dc:
																										if (65 >= b)
																										{
																											goto IL_26e7;
																										}
																										goto IL_2763;
																										IL_26e7:
																										if (65 > b)
																										{
																											break;
																										}
																										goto IL_26f5;
																										IL_26f5:
																										((delegate*<List<GameEntityCreateData>, Player, bool, void>)ThrowOnEventWriteErrorsDateTimeOffset[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num6 - 3], (Player)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0);
																										goto IL_2742;
																										IL_2742:
																										num6 -= 3;
																										goto IL_2750;
																										IL_2750:
																										ptr2 += 8;
																										goto end_IL_09ec;
																										IL_2763:
																										if (66 < b)
																										{
																											break;
																										}
																										goto IL_2771;
																										IL_2771:
																										if (66 > b)
																										{
																										}
																										break;
																										IL_280a:
																										array[num6 - 1] = 0;
																										goto end_IL_09ec;
																										IL_278d:
																										if (64 <= b)
																										{
																											goto IL_2798;
																										}
																										goto IL_27c9;
																										IL_2798:
																										array2[num6] = null;
																										num = 448;
																										goto IL_27ab;
																										IL_27ab:
																										array[num6] = 5;
																										goto IL_27b9;
																									}
																									break;
																									IL_09bc:;
																								}
																							}
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_09ec;
																							continue;
																							end_IL_09cc:
																							break;
																						}
																						continue;
																						end_IL_09dc:
																						break;
																					}
																					continue;
																					end_IL_09ec:
																					break;
																				}
																				continue;
																			}
																			num = 107;
																			return;
																			continue;
																			end_IL_2833:
																			break;
																		}
																		continue;
																		end_IL_2846:
																		break;
																	}
																	continue;
																	end_IL_2850:
																	break;
																}
																continue;
																end_IL_285b:
																break;
															}
															continue;
															end_IL_2871:
															break;
														}
														continue;
														end_IL_2890:
														break;
													}
													continue;
													end_IL_28a6:
													break;
												}
												continue;
												end_IL_28bc:
												break;
											}
											continue;
											end_IL_28d2:
											break;
										}
										continue;
										end_IL_28e2:
										break;
									}
									continue;
									end_IL_28fb:
									break;
								}
								continue;
								end_IL_290b:
								break;
							}
							continue;
							end_IL_291b:
							break;
						}
						continue;
						end_IL_2934:
						break;
					}
					continue;
					end_IL_2944:
					break;
				}
				continue;
				end_IL_295d:
				break;
			}
		}
	}

	public Class118()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 59;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRuleSetelemdescVar.GetLibAttrEvidenceTypeGenerated);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																IL_021b:
																ptr2++;
																num = 127;
																while (true)
																{
																	if (num != 127)
																	{
																		if (num != 1108)
																		{
																			break;
																		}
																		switch (num)
																		{
																		case 101:
																			goto IL_021b;
																		case 0:
																		case 31:
																			goto end_IL_020b;
																		case 103:
																			goto IL_024d;
																		case 2:
																			goto IL_025b;
																		case 53:
																		case 71:
																			goto IL_0269;
																		case 83:
																			goto IL_0277;
																		case 39:
																			goto IL_0285;
																		case 6:
																		case 24:
																			goto IL_0293;
																		case 86:
																			goto IL_02a1;
																		case 16:
																		case 109:
																			goto IL_02af;
																		case 15:
																			goto IL_02ef;
																		case 37:
																			goto IL_0303;
																		case 76:
																			goto IL_0316;
																		case 10:
																		case 27:
																			goto IL_032d;
																		case 36:
																			goto IL_0346;
																		case 40:
																			goto IL_0354;
																		case 89:
																			goto IL_0362;
																		case 75:
																		case 94:
																			goto IL_0375;
																		case 45:
																			goto IL_0392;
																		case 97:
																			goto IL_03d1;
																		case 30:
																			goto IL_03e4;
																		case 29:
																		case 64:
																			goto IL_03ef;
																		case 46:
																			goto IL_03fd;
																		case 8:
																		case 70:
																			goto IL_040b;
																		case 35:
																			goto IL_0427;
																		case 51:
																		case 54:
																			goto IL_0435;
																		case 25:
																			goto IL_0448;
																		case 43:
																		case 99:
																			goto IL_0453;
																		case 115:
																			goto IL_0493;
																		case 44:
																			goto IL_04a7;
																		case 20:
																			goto IL_04ba;
																		case 108:
																			goto IL_04c8;
																		case 21:
																		case 23:
																			goto IL_04d3;
																		case 55:
																			goto IL_04fc;
																		case 95:
																			goto IL_050a;
																		case 41:
																			goto IL_051d;
																		case 96:
																			goto IL_052b;
																		case 50:
																			goto IL_0539;
																		case 68:
																		case 110:
																			goto IL_0547;
																		case 3:
																			goto IL_0587;
																		case 80:
																			goto IL_059b;
																		case 78:
																			goto IL_05ae;
																		case 111:
																			goto IL_05c1;
																		case 119:
																			goto IL_05cc;
																		case 67:
																		case 113:
																			goto IL_05da;
																		case 11:
																			goto IL_061a;
																		case 107:
																			goto IL_062e;
																		case 63:
																			goto IL_0641;
																		case 14:
																			goto IL_064c;
																		case 28:
																		case 38:
																			goto IL_0657;
																		case 19:
																			goto IL_0665;
																		case 87:
																			goto IL_0688;
																		case 81:
																			goto IL_0692;
																		case 82:
																			goto IL_06a0;
																		case 7:
																		case 12:
																		case 13:
																		case 17:
																		case 18:
																		case 26:
																		case 47:
																		case 49:
																		case 57:
																		case 62:
																		case 65:
																		case 69:
																		case 72:
																		case 73:
																		case 74:
																		case 84:
																		case 85:
																		case 91:
																		case 98:
																		case 100:
																		case 102:
																		case 112:
																		case 120:
																			goto IL_06b0;
																		case 79:
																			goto IL_06dc;
																		case 118:
																			goto IL_06ea;
																		case 22:
																			goto IL_0701;
																		case 5:
																		case 9:
																		case 34:
																		case 42:
																		case 48:
																		case 52:
																		case 58:
																		case 77:
																		case 92:
																		case 93:
																		case 105:
																		case 106:
																		case 114:
																			goto end_IL_0234;
																		case 33:
																			goto end_IL_070f;
																		case 66:
																			goto end_IL_0722;
																		case 32:
																			goto end_IL_072c;
																		case 117:
																			goto end_IL_0737;
																		case 1:
																			goto end_IL_074c;
																		case 4:
																		case 90:
																			goto end_IL_0761;
																		case 59:
																			goto end_IL_0771;
																		case 104:
																		case 116:
																			goto end_IL_0781;
																		case 60:
																			goto end_IL_0791;
																		case 61:
																			goto end_IL_07aa;
																		case 56:
																		case 88:
																			goto IL_07c5;
																		}
																		continue;
																	}
																	if (b >= 1)
																	{
																		goto IL_024d;
																	}
																	goto IL_06b0;
																	IL_06b0:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 79;
																	goto IL_06dc;
																	IL_06ea:
																	num5++;
																	num = 22;
																	goto IL_0701;
																	IL_06dc:
																	array[num5] = 0;
																	goto IL_06ea;
																	IL_024d:
																	if (b <= 11)
																	{
																		goto IL_025b;
																	}
																	goto IL_06b0;
																	IL_025b:
																	if (6 < b)
																	{
																		goto IL_0269;
																	}
																	goto IL_0448;
																	IL_0269:
																	if (9 >= b)
																	{
																		goto IL_0277;
																	}
																	goto IL_03e4;
																	IL_0277:
																	if (9 > b)
																	{
																		goto IL_0285;
																	}
																	goto IL_0375;
																	IL_0285:
																	if (7 < b)
																	{
																		goto IL_0293;
																	}
																	goto IL_0316;
																	IL_0293:
																	if (8 >= b)
																	{
																		goto IL_02a1;
																	}
																	goto IL_06b0;
																	IL_02a1:
																	if (8 <= b)
																	{
																		goto IL_02af;
																	}
																	goto IL_06b0;
																	IL_02af:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_02ef;
																	IL_02ef:
																	array[num5 - 2] = 0;
																	goto IL_0303;
																	IL_0303:
																	num5--;
																	goto end_IL_0234;
																	IL_0316:
																	if (7 <= b)
																	{
																		num = 27;
																		goto IL_032d;
																	}
																	goto IL_06b0;
																	IL_0701:
																	ptr2 += 8;
																	goto end_IL_0234;
																	IL_032d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0346;
																	IL_0346:
																	array[num5] = 0;
																	goto IL_0354;
																	IL_0354:
																	num5++;
																	goto IL_0362;
																	IL_0362:
																	ptr2 += 8;
																	goto end_IL_0234;
																	IL_0375:
																	array[num5 - 1] = 0;
																	num = 45;
																	goto IL_0392;
																	IL_0392:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SafeLsaMemoryHandleAddCustom[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																	goto IL_03d1;
																	IL_03d1:
																	ptr2 += 8;
																	goto end_IL_0234;
																	IL_03e4:
																	if (10 < b)
																	{
																		goto IL_03ef;
																	}
																	goto IL_0427;
																	IL_03ef:
																	if (11 >= b)
																	{
																		goto IL_03fd;
																	}
																	goto IL_06b0;
																	IL_03fd:
																	if (11 <= b)
																	{
																		goto IL_040b;
																	}
																	goto IL_06b0;
																	IL_040b:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_0234;
																	IL_0427:
																	if (10 <= b)
																	{
																		goto IL_0435;
																	}
																	goto IL_06b0;
																	IL_0435:
																	num5--;
																	goto end_IL_0234;
																	IL_0448:
																	if (6 <= b)
																	{
																		goto IL_0453;
																	}
																	goto IL_04ba;
																	IL_0453:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0493;
																	IL_0493:
																	array[num5 - 2] = 0;
																	goto IL_04a7;
																	IL_04a7:
																	num5--;
																	goto end_IL_0234;
																	IL_04ba:
																	if (3 >= b)
																	{
																		goto IL_04c8;
																	}
																	goto IL_05c1;
																	IL_04c8:
																	if (3 <= b)
																	{
																		goto IL_04d3;
																	}
																	goto IL_051d;
																	IL_04d3:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04fc;
																	IL_04fc:
																	ptr2 += 8;
																	goto IL_050a;
																	IL_050a:
																	num5--;
																	goto end_IL_0234;
																	IL_051d:
																	if (1 < b)
																	{
																		goto IL_052b;
																	}
																	goto IL_05ae;
																	IL_052b:
																	if (2 >= b)
																	{
																		goto IL_0539;
																	}
																	goto IL_06b0;
																	IL_0539:
																	if (2 <= b)
																	{
																		goto IL_0547;
																	}
																	goto IL_06b0;
																	IL_0547:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0587;
																	IL_0587:
																	array[num5 - 2] = 0;
																	goto IL_059b;
																	IL_059b:
																	num5--;
																	goto end_IL_0234;
																	IL_05ae:
																	if (1 <= b)
																	{
																	}
																	goto IL_06b0;
																	IL_05c1:
																	if (4 >= b)
																	{
																		goto IL_05cc;
																	}
																	goto IL_0641;
																	IL_05cc:
																	if (4 <= b)
																	{
																		goto IL_05da;
																	}
																	goto IL_06b0;
																	IL_05da:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_061a;
																	IL_061a:
																	array[num5 - 2] = 0;
																	goto IL_062e;
																	IL_062e:
																	num5--;
																	goto end_IL_0234;
																	IL_0641:
																	if (5 >= b)
																	{
																		goto IL_064c;
																	}
																	goto IL_06b0;
																	IL_064c:
																	if (5 <= b)
																	{
																		goto IL_0657;
																	}
																	goto IL_06b0;
																	IL_0657:
																	array[num5] = 0;
																	goto IL_0665;
																	IL_0665:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0688;
																	IL_0688:
																	array2[num5] = null;
																	goto IL_0692;
																	IL_0692:
																	num5++;
																	goto IL_06a0;
																	IL_06a0:
																	ptr2 += 8;
																	goto end_IL_0234;
																	continue;
																	end_IL_020b:
																	break;
																}
																break;
															}
															continue;
															end_IL_0234:
															break;
														}
														continue;
													}
													goto IL_07c5;
													IL_07c5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_070f:
													break;
												}
												continue;
												end_IL_0722:
												break;
											}
											continue;
											end_IL_072c:
											break;
										}
										continue;
										end_IL_0737:
										break;
									}
									continue;
									end_IL_074c:
									break;
								}
								continue;
								end_IL_0761:
								break;
							}
							continue;
							end_IL_0771:
							break;
						}
						continue;
						end_IL_0781:
						break;
					}
					continue;
					end_IL_0791:
					break;
				}
				continue;
				end_IL_07aa:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 106;
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AreReferencesEqualKeyContainerName.ObjectAuditRuleILease);
										num = 123;
										while (true)
										{
											if (num != 123)
											{
												if (num != 1104)
												{
													goto IL_06db;
												}
												switch (num)
												{
												case 96:
													goto end_IL_01fb;
												case 91:
													goto end_IL_020e;
												case 55:
													goto end_IL_0222;
												case 26:
												case 49:
													goto end_IL_0237;
												case 88:
													goto end_IL_0247;
												case 24:
												case 29:
													goto end_IL_0257;
												case 105:
													goto end_IL_0267;
												case 106:
													goto end_IL_0277;
												case 0:
												case 17:
												case 22:
												case 30:
												case 35:
												case 37:
												case 54:
												case 61:
												case 70:
												case 77:
												case 86:
												case 92:
												case 97:
												case 116:
													goto IL_029a;
												case 43:
												case 101:
													goto IL_02aa;
												case 90:
													goto IL_02bc;
												case 69:
													goto IL_02ca;
												case 6:
													goto IL_02d8;
												case 94:
													goto IL_02e6;
												case 58:
													goto IL_02f4;
												case 5:
												case 15:
													goto IL_02ff;
												case 51:
													goto IL_033f;
												case 57:
													goto IL_0353;
												case 20:
												case 52:
													goto IL_0366;
												case 48:
												case 115:
													goto IL_0374;
												case 27:
													goto IL_037f;
												case 42:
												case 82:
													goto IL_0392;
												case 38:
													goto IL_03a9;
												case 93:
												case 99:
													goto IL_03b7;
												case 62:
													goto IL_03c5;
												case 73:
													goto IL_03e8;
												case 2:
													goto IL_03f2;
												case 11:
													goto IL_0400;
												case 85:
													goto IL_0413;
												case 1:
												case 95:
													goto IL_0421;
												case 28:
												case 41:
													goto IL_042c;
												case 47:
													goto IL_043a;
												case 3:
												case 19:
													goto IL_0448;
												case 112:
													goto IL_0471;
												case 67:
													goto IL_047f;
												case 16:
													goto IL_0492;
												case 23:
												case 44:
													goto IL_04a0;
												case 45:
													goto IL_04b9;
												case 87:
													goto IL_04c7;
												case 33:
													goto IL_04d5;
												case 71:
												case 107:
													goto IL_04f1;
												case 13:
												case 98:
													goto IL_0509;
												case 14:
												case 60:
													goto IL_0514;
												case 109:
													goto IL_051f;
												case 31:
												case 66:
													goto IL_052d;
												case 113:
													goto IL_0549;
												case 72:
													goto IL_0557;
												case 103:
													goto IL_056a;
												case 102:
													goto IL_0578;
												case 64:
												case 104:
													goto IL_0583;
												case 46:
													goto IL_0591;
												case 10:
												case 108:
													goto IL_059f;
												case 50:
													goto IL_05c2;
												case 18:
													goto IL_05d0;
												case 56:
													goto IL_05de;
												case 7:
													goto IL_05f1;
												case 100:
												case 110:
													goto IL_05ff;
												case 114:
													goto IL_063f;
												case 65:
													goto IL_0653;
												case 32:
												case 76:
													goto IL_0666;
												case 83:
													goto IL_06c8;
												case 4:
												case 8:
												case 9:
												case 12:
												case 21:
												case 25:
												case 34:
												case 36:
												case 39:
												case 40:
												case 53:
												case 59:
												case 63:
												case 68:
												case 74:
												case 75:
												case 78:
												case 79:
												case 81:
												case 84:
												case 111:
													goto IL_06db;
												case 80:
												case 89:
													goto IL_06f3;
												}
												continue;
											}
											ptr2 = ptr;
											goto IL_029a;
											IL_0653:
											num4--;
											goto IL_029a;
											IL_06c8:
											num4 -= 2;
											goto IL_029a;
											IL_0666:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_06c8;
											IL_029a:
											if (num5 != 1)
											{
												goto IL_02aa;
											}
											goto IL_06f3;
											IL_06f3:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											IL_02aa:
											b = *ptr2;
											num = 90;
											goto IL_02bc;
											IL_02bc:
											ptr2++;
											goto IL_02ca;
											IL_02ca:
											if (b >= 1)
											{
												goto IL_02d8;
											}
											goto IL_06db;
											IL_02d8:
											if (b <= 11)
											{
												goto IL_02e6;
											}
											goto IL_06db;
											IL_02e6:
											if (6 >= b)
											{
												goto IL_02f4;
											}
											goto IL_0509;
											IL_02f4:
											if (6 <= b)
											{
												goto IL_02ff;
											}
											goto IL_0366;
											IL_02ff:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_033f;
											IL_033f:
											array[num4 - 2] = 0;
											goto IL_0353;
											IL_0353:
											num4--;
											goto IL_029a;
											IL_0366:
											if (3 < b)
											{
												goto IL_0374;
											}
											goto IL_0413;
											IL_0374:
											if (4 >= b)
											{
												goto IL_037f;
											}
											goto IL_0392;
											IL_037f:
											if (4 <= b)
											{
												goto IL_029a;
											}
											goto IL_06db;
											IL_0392:
											if (5 >= b)
											{
												num = 38;
												goto IL_03a9;
											}
											goto IL_06db;
											IL_06db:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_029a;
											IL_03a9:
											if (5 <= b)
											{
												goto IL_03b7;
											}
											goto IL_06db;
											IL_03b7:
											array[num4] = 0;
											goto IL_03c5;
											IL_03c5:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
											goto IL_03e8;
											IL_03e8:
											array2[num4] = null;
											goto IL_03f2;
											IL_03f2:
											num4++;
											goto IL_0400;
											IL_0400:
											ptr2 += 8;
											goto IL_029a;
											IL_0413:
											if (3 > b)
											{
												goto IL_0421;
											}
											goto IL_04f1;
											IL_0421:
											if (1 < b)
											{
												goto IL_042c;
											}
											goto IL_0492;
											IL_042c:
											if (2 >= b)
											{
												goto IL_043a;
											}
											goto IL_06db;
											IL_043a:
											if (2 <= b)
											{
												goto IL_0448;
											}
											goto IL_06db;
											IL_0448:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_0471;
											IL_0471:
											ptr2 += 8;
											goto IL_047f;
											IL_047f:
											num4--;
											goto IL_029a;
											IL_0492:
											if (1 <= b)
											{
												goto IL_04a0;
											}
											goto IL_06db;
											IL_04a0:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
											goto IL_04b9;
											IL_04b9:
											array[num4] = 0;
											goto IL_04c7;
											IL_04c7:
											num4++;
											goto IL_04d5;
											IL_04d5:
											ptr2 += 8;
											num = 17;
											goto IL_029a;
											IL_04f1:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_029a;
											IL_0509:
											if (9 < b)
											{
												goto IL_0514;
											}
											goto IL_056a;
											IL_0514:
											if (10 >= b)
											{
												goto IL_051f;
											}
											goto IL_0549;
											IL_051f:
											if (10 <= b)
											{
												goto IL_052d;
											}
											goto IL_06db;
											IL_052d:
											byte* num6 = ptr2;
											num5 = 1;
											ptr2 = num6 + -200;
											goto IL_029a;
											IL_0549:
											if (11 >= b)
											{
												goto IL_0557;
											}
											goto IL_06db;
											IL_0557:
											if (11 <= b)
											{
											}
											goto IL_06db;
											IL_056a:
											if (9 > b)
											{
												goto IL_0578;
											}
											goto IL_0666;
											IL_0578:
											if (7 < b)
											{
												goto IL_0583;
											}
											goto IL_05f1;
											IL_0583:
											if (8 >= b)
											{
												goto IL_0591;
											}
											goto IL_06db;
											IL_0591:
											if (8 <= b)
											{
												goto IL_059f;
											}
											goto IL_06db;
											IL_059f:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
											goto IL_05c2;
											IL_05c2:
											array[num4] = 0;
											goto IL_05d0;
											IL_05d0:
											num4++;
											goto IL_05de;
											IL_05de:
											ptr2 += 8;
											goto IL_029a;
											IL_05f1:
											if (7 <= b)
											{
												goto IL_05ff;
											}
											goto IL_06db;
											IL_05ff:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_063f;
											IL_063f:
											array[num4 - 2] = 0;
											goto IL_0653;
											continue;
											end_IL_01fb:
											break;
										}
										continue;
										end_IL_020e:
										break;
									}
									continue;
									end_IL_0222:
									break;
								}
								continue;
								end_IL_0237:
								break;
							}
							continue;
							end_IL_0247:
							break;
						}
						continue;
						end_IL_0257:
						break;
					}
					continue;
					end_IL_0267:
					break;
				}
				continue;
				end_IL_0277:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 98;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 48;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OnStopKeyProperty.COMServerEntrygetIsHideBySig);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 59;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 83;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0234:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0217:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0207:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_01f7:
																								if (7 > b)
																								{
																									while (6 >= b)
																									{
																										num = 109;
																										while (true)
																										{
																											if (num != 109)
																											{
																												if (num != 1090)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 0:
																												case 55:
																													goto IL_01e4;
																												case 24:
																													goto IL_01f7;
																												case 69:
																													goto IL_0207;
																												case 89:
																													goto IL_0217;
																												case 58:
																													goto IL_0224;
																												case 71:
																													goto IL_0234;
																												case 83:
																													goto end_IL_0234;
																												case 19:
																												case 88:
																													goto end_IL_0244;
																												case 13:
																													goto IL_0268;
																												case 46:
																												case 54:
																													goto IL_0273;
																												case 37:
																													goto IL_0281;
																												case 90:
																													goto IL_02a9;
																												case 38:
																													goto IL_02b7;
																												case 25:
																												case 34:
																													goto IL_02c2;
																												case 65:
																													goto IL_02d0;
																												case 2:
																												case 35:
																													goto IL_02e3;
																												case 87:
																													goto IL_0323;
																												case 3:
																													goto IL_033c;
																												case 56:
																													goto IL_034a;
																												case 26:
																													goto IL_0358;
																												case 41:
																												case 60:
																													goto end_IL_01d1;
																												case 44:
																													goto IL_03a6;
																												case 4:
																													goto IL_03ba;
																												case 95:
																													goto IL_03cd;
																												case 99:
																													goto IL_03e9;
																												case 39:
																												case 42:
																													goto IL_03f7;
																												case 79:
																													goto IL_0420;
																												case 8:
																													goto IL_042e;
																												case 100:
																													goto IL_0441;
																												case 36:
																													goto IL_0454;
																												case 63:
																													goto IL_0462;
																												case 9:
																												case 78:
																													goto IL_0483;
																												case 21:
																													goto IL_04c3;
																												case 40:
																													goto IL_04d7;
																												case 51:
																												case 101:
																													goto IL_04ea;
																												case 20:
																													goto IL_050c;
																												case 86:
																													goto IL_051a;
																												case 61:
																													goto IL_0528;
																												case 47:
																													goto IL_053b;
																												case 62:
																													goto IL_0546;
																												case 5:
																												case 92:
																													goto IL_0554;
																												case 7:
																													goto IL_0594;
																												case 18:
																													goto IL_05a8;
																												case 52:
																												case 93:
																													goto IL_05c4;
																												case 1:
																													goto IL_05cf;
																												case 32:
																												case 49:
																													goto IL_05da;
																												case 10:
																												case 12:
																												case 15:
																												case 16:
																												case 22:
																												case 23:
																												case 30:
																												case 31:
																												case 64:
																												case 66:
																												case 68:
																												case 73:
																												case 81:
																												case 82:
																												case 84:
																												case 94:
																												case 96:
																													goto end_IL_01e4;
																												case 43:
																													goto IL_0616;
																												case 17:
																													goto IL_0624;
																												case 70:
																													goto IL_0632;
																												case 14:
																												case 27:
																												case 28:
																												case 29:
																												case 33:
																												case 45:
																												case 53:
																												case 59:
																												case 72:
																												case 75:
																												case 80:
																													goto end_IL_0254;
																												case 57:
																													goto end_IL_0640;
																												case 67:
																													goto end_IL_0653;
																												case 74:
																													goto end_IL_0666;
																												case 85:
																													goto end_IL_0671;
																												case 77:
																													goto end_IL_0686;
																												case 50:
																												case 91:
																													goto end_IL_069b;
																												case 76:
																													goto end_IL_06ab;
																												case 6:
																												case 48:
																													goto end_IL_06bb;
																												case 97:
																													goto end_IL_06cb;
																												case 98:
																													goto end_IL_06db;
																												case 11:
																												case 102:
																													goto IL_06ff;
																												}
																												continue;
																											}
																											if (6 > b)
																											{
																												goto end_IL_01e4;
																											}
																											goto IL_0483;
																											IL_0483:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_04c3;
																											IL_04d7:
																											num5--;
																											goto end_IL_0254;
																											IL_04c3:
																											array[num5 - 2] = 0;
																											goto IL_04d7;
																											continue;
																											end_IL_01d1:
																											break;
																										}
																										goto IL_0366;
																										continue;
																										end_IL_01e4:
																										break;
																										IL_01e4:;
																									}
																									break;
																								}
																								goto IL_04ea;
																								IL_0528:
																								ptr2 += 8;
																								goto end_IL_0254;
																								IL_04ea:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								num = 20;
																								goto IL_050c;
																								IL_050c:
																								array[num5] = 0;
																								goto IL_051a;
																								IL_051a:
																								num5++;
																								goto IL_0528;
																							}
																							break;
																						}
																						goto IL_053b;
																						IL_05cf:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_05da;
																						IL_053b:
																						if (8 >= b)
																						{
																							goto IL_0546;
																						}
																						num = 93;
																						goto IL_05c4;
																						IL_0546:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0554;
																						IL_0554:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0594;
																						IL_0594:
																						array[num5 - 2] = 0;
																						goto IL_05a8;
																						IL_05a8:
																						num5--;
																						goto end_IL_0254;
																						IL_05da:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0254;
																						IL_05c4:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_05cf;
																					}
																					break;
																				}
																				goto IL_0268;
																				IL_042e:
																				num5--;
																				goto end_IL_0254;
																				IL_0268:
																				if (5 <= b)
																				{
																					goto IL_0273;
																				}
																				goto IL_02a9;
																				IL_0273:
																				array[num5] = 0;
																				goto IL_0281;
																				IL_0281:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0441;
																				IL_0441:
																				array2[num5] = null;
																				num = 36;
																				goto IL_0454;
																				IL_0454:
																				num5++;
																				goto IL_0462;
																				IL_0462:
																				ptr2 += 8;
																				goto end_IL_0254;
																				IL_02a9:
																				if (2 >= b)
																				{
																					goto IL_02b7;
																				}
																				goto IL_033c;
																				IL_02b7:
																				if (2 > b)
																				{
																					goto IL_02c2;
																				}
																				goto IL_02e3;
																				IL_02c2:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_02d0;
																				IL_02d0:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_02e3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0323;
																				IL_0323:
																				array[num5 - 2] = 0;
																				goto IL_03cd;
																				IL_03cd:
																				num5--;
																				num = 53;
																				goto end_IL_0254;
																				IL_033c:
																				if (3 < b)
																				{
																					goto IL_034a;
																				}
																				goto IL_03e9;
																				IL_034a:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0358;
																				IL_0358:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0366;
																				IL_0366:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03a6;
																				IL_03a6:
																				array[num5 - 2] = 0;
																				goto IL_03ba;
																				IL_03ba:
																				num5--;
																				goto end_IL_0254;
																				IL_03e9:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_03f7;
																				IL_03f7:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0420;
																				IL_0420:
																				ptr2 += 8;
																				goto IL_042e;
																			}
																			break;
																			IL_0224:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0616;
																	IL_0632:
																	ptr2 += 8;
																	goto end_IL_0254;
																	IL_0624:
																	num5++;
																	goto IL_0632;
																	IL_0616:
																	array[num5] = 0;
																	goto IL_0624;
																	continue;
																	end_IL_0234:
																	break;
																}
																continue;
																end_IL_0244:
																break;
															}
															continue;
															end_IL_0254:
															break;
														}
														continue;
													}
													goto IL_06ff;
													IL_06ff:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0640:
													break;
												}
												continue;
												end_IL_0653:
												break;
											}
											continue;
											end_IL_0666:
											break;
										}
										continue;
										end_IL_0671:
										break;
									}
									continue;
									end_IL_0686:
									break;
								}
								continue;
								end_IL_069b:
								break;
							}
							continue;
							end_IL_06ab:
							break;
						}
						continue;
						end_IL_06bb:
						break;
					}
					continue;
					end_IL_06cb:
					break;
				}
				continue;
				end_IL_06db:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 61;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetLastAccessTimegetWindowTop.ToXmlStringSubject);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03f0:
														byte b = *ptr2;
														while (true)
														{
															IL_03e0:
															ptr2++;
															while (true)
															{
																IL_03d0:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_03b0:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_03a3:
																					if (13 < b)
																					{
																						while (true)
																						{
																							IL_0393:
																							if (15 >= b)
																							{
																								while (true)
																								{
																									IL_0383:
																									if (15 > b)
																									{
																										while (14 >= b)
																										{
																											while (14 <= b)
																											{
																												while (true)
																												{
																													IL_034d:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_02f7:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)RemotingFieldCachedDataGenerateEvidence[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																														while (true)
																														{
																															IL_02e7:
																															num5--;
																															while (true)
																															{
																																IL_02ce:
																																ptr2 += 8;
																																num = 171;
																																while (num != 171)
																																{
																																	if (num != 1152)
																																	{
																																		goto IL_03f0;
																																	}
																																	switch (num)
																																	{
																																	case 99:
																																		goto IL_02ce;
																																	case 22:
																																		goto IL_02e7;
																																	case 91:
																																		goto IL_02f7;
																																	case 26:
																																	case 50:
																																		goto IL_034d;
																																	case 21:
																																		goto IL_0363;
																																	case 59:
																																	case 65:
																																		goto IL_0373;
																																	case 159:
																																		goto IL_0383;
																																	case 105:
																																	case 161:
																																		goto IL_0393;
																																	case 5:
																																	case 13:
																																		goto IL_03a3;
																																	case 71:
																																		goto IL_03b0;
																																	case 132:
																																		goto IL_03c0;
																																	case 36:
																																		goto IL_03d0;
																																	case 41:
																																		goto IL_03e0;
																																	case 135:
																																	case 140:
																																		goto IL_03f0;
																																	case 109:
																																		goto IL_03fb;
																																	case 60:
																																	case 136:
																																		goto IL_0406;
																																	case 69:
																																		goto IL_0468;
																																	case 143:
																																		goto IL_047b;
																																	case 113:
																																		goto IL_0489;
																																	case 67:
																																	case 125:
																																		goto IL_0494;
																																	case 121:
																																		goto IL_04a2;
																																	case 54:
																																	case 62:
																																		goto IL_04b0;
																																	case 111:
																																	case 130:
																																		goto IL_04c0;
																																	case 34:
																																		goto IL_0504;
																																	case 131:
																																		goto IL_0518;
																																	case 14:
																																		goto IL_052b;
																																	case 148:
																																		goto IL_053b;
																																	case 154:
																																		goto IL_055e;
																																	case 9:
																																		goto IL_0568;
																																	case 89:
																																		goto IL_0576;
																																	case 158:
																																		goto IL_0589;
																																	case 4:
																																	case 28:
																																		goto IL_0597;
																																	case 149:
																																		goto IL_05d7;
																																	case 39:
																																		goto IL_05eb;
																																	case 94:
																																	case 120:
																																		goto IL_05fe;
																																	case 100:
																																	case 163:
																																		goto IL_0611;
																																	case 11:
																																		goto IL_061c;
																																	case 64:
																																	case 156:
																																		goto IL_062a;
																																	case 44:
																																		goto IL_0646;
																																	case 115:
																																		goto IL_0654;
																																	case 153:
																																		goto IL_0667;
																																	case 93:
																																	case 127:
																																		goto IL_0675;
																																	case 138:
																																		goto IL_0683;
																																	case 85:
																																		goto IL_0691;
																																	case 134:
																																		goto IL_069f;
																																	case 51:
																																	case 73:
																																		goto IL_06aa;
																																	case 81:
																																		goto IL_06ea;
																																	case 84:
																																		goto IL_06fe;
																																	case 77:
																																		goto IL_0711;
																																	case 66:
																																		goto IL_071f;
																																	case 45:
																																	case 63:
																																		goto IL_072d;
																																	case 110:
																																		goto IL_0746;
																																	case 116:
																																		goto IL_0754;
																																	case 155:
																																		goto IL_0762;
																																	case 30:
																																		goto IL_0775;
																																	case 118:
																																		goto IL_0783;
																																	case 15:
																																	case 162:
																																		goto IL_0791;
																																	case 8:
																																		goto IL_07ba;
																																	case 31:
																																	case 46:
																																		goto IL_07d3;
																																	case 103:
																																		goto IL_07f1;
																																	case 123:
																																		goto IL_07ff;
																																	case 35:
																																		goto IL_0812;
																																	case 32:
																																		goto IL_0820;
																																	case 16:
																																	case 151:
																																		goto IL_082b;
																																	case 58:
																																		goto IL_086a;
																																	case 145:
																																		goto IL_087d;
																																	case 3:
																																		goto IL_088b;
																																	case 124:
																																	case 128:
																																		goto IL_0899;
																																	case 106:
																																		goto IL_08a7;
																																	case 90:
																																		goto IL_08bf;
																																	case 97:
																																		goto IL_08cd;
																																	case 37:
																																		goto IL_08e0;
																																	case 48:
																																	case 117:
																																		goto IL_08eb;
																																	case 107:
																																		goto IL_08f6;
																																	case 23:
																																	case 74:
																																		goto IL_0901;
																																	case 47:
																																		goto IL_0916;
																																	case 96:
																																	case 133:
																																		goto IL_0921;
																																	case 24:
																																		goto IL_094a;
																																	case 55:
																																		goto IL_0958;
																																	case 2:
																																	case 12:
																																	case 18:
																																	case 19:
																																	case 20:
																																	case 25:
																																	case 29:
																																	case 33:
																																	case 43:
																																	case 68:
																																	case 70:
																																	case 83:
																																	case 87:
																																	case 88:
																																	case 92:
																																	case 98:
																																	case 101:
																																	case 104:
																																	case 108:
																																	case 112:
																																	case 114:
																																	case 122:
																																	case 126:
																																	case 137:
																																	case 141:
																																	case 142:
																																	case 144:
																																	case 146:
																																	case 147:
																																	case 150:
																																	case 152:
																																		goto end_IL_0363;
																																	case 6:
																																	case 10:
																																	case 27:
																																	case 40:
																																	case 42:
																																	case 52:
																																	case 53:
																																	case 56:
																																	case 57:
																																	case 75:
																																	case 76:
																																	case 79:
																																	case 80:
																																	case 82:
																																	case 95:
																																	case 119:
																																	case 157:
																																	case 160:
																																	case 164:
																																		goto end_IL_02bb;
																																	case 102:
																																		goto end_IL_0984;
																																	case 139:
																																		goto end_IL_0997;
																																	case 7:
																																		goto end_IL_09a1;
																																	case 17:
																																		goto end_IL_09ac;
																																	case 61:
																																	case 86:
																																		goto end_IL_09bc;
																																	case 38:
																																		goto end_IL_09cc;
																																	case 72:
																																	case 78:
																																		goto end_IL_09dc;
																																	case 0:
																																		goto end_IL_09f5;
																																	case 1:
																																		goto end_IL_0a05;
																																	case 49:
																																	case 129:
																																		goto IL_0a20;
																																	}
																																	continue;
																																	end_IL_02bb:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_03d0;
																												continue;
																												end_IL_0363:
																												break;
																												IL_0363:;
																											}
																											break;
																											IL_0373:;
																										}
																										break;
																									}
																									goto IL_05fe;
																									IL_05fe:
																									num5--;
																									goto end_IL_03d0;
																								}
																								break;
																							}
																							goto IL_0611;
																							IL_0654:
																							if (17 <= b)
																							{
																							}
																							break;
																							IL_0611:
																							if (16 >= b)
																							{
																								goto IL_061c;
																							}
																							goto IL_0646;
																							IL_061c:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_062a;
																							IL_062a:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_03d0;
																							IL_0646:
																							if (17 < b)
																							{
																								break;
																							}
																							goto IL_0654;
																						}
																						break;
																					}
																					goto IL_03fb;
																					IL_05eb:
																					num5--;
																					goto end_IL_03d0;
																					IL_03fb:
																					if (13 <= b)
																					{
																						goto IL_0406;
																					}
																					goto IL_047b;
																					IL_0406:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0468;
																					IL_0468:
																					num5 -= 2;
																					goto end_IL_03d0;
																					IL_047b:
																					if (11 >= b)
																					{
																						goto IL_0489;
																					}
																					goto IL_052b;
																					IL_0489:
																					if (11 > b)
																					{
																						goto IL_0494;
																					}
																					goto IL_04c0;
																					IL_0494:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_04a2;
																					IL_04a2:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_04b0;
																					IL_04b0:
																					array[num5] = 0;
																					goto IL_053b;
																					IL_053b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_055e;
																					IL_055e:
																					array2[num5] = null;
																					goto IL_0568;
																					IL_0568:
																					num5++;
																					goto IL_0576;
																					IL_0576:
																					ptr2 += 8;
																					goto end_IL_03d0;
																					IL_04c0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_0504;
																					IL_0504:
																					array[num5 - 2] = 0;
																					goto IL_0518;
																					IL_0518:
																					num5--;
																					goto end_IL_03d0;
																					IL_052b:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_0589;
																					IL_0589:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_0597;
																					IL_0597:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05d7;
																					IL_05d7:
																					array[num5 - 2] = 0;
																					goto IL_05eb;
																				}
																				break;
																			}
																			goto IL_0667;
																			IL_0958:
																			num5--;
																			goto end_IL_03d0;
																			IL_0667:
																			if (9 <= b)
																			{
																				goto end_IL_03d0;
																			}
																			goto IL_0675;
																			IL_0675:
																			if (4 >= b)
																			{
																				goto IL_0683;
																			}
																			goto IL_0812;
																			IL_0683:
																			if (4 > b)
																			{
																				goto IL_0691;
																			}
																			goto IL_07d3;
																			IL_0691:
																			if (2 >= b)
																			{
																				goto IL_069f;
																			}
																			goto IL_0775;
																			IL_069f:
																			if (2 <= b)
																			{
																				goto IL_06aa;
																			}
																			goto IL_0711;
																			IL_06aa:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06ea;
																			IL_06ea:
																			array[num5 - 2] = 0;
																			goto IL_06fe;
																			IL_06fe:
																			num5--;
																			goto end_IL_03d0;
																			IL_0711:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_071f;
																			IL_071f:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_072d;
																			IL_072d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0746;
																			IL_0746:
																			array[num5] = 0;
																			goto IL_0754;
																			IL_0754:
																			num5++;
																			goto IL_0762;
																			IL_0762:
																			ptr2 += 8;
																			goto end_IL_03d0;
																			IL_0775:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0783;
																			IL_0783:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0791;
																			IL_0791:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_07ba;
																			IL_07ba:
																			array[num5 - 1] = 5;
																			goto end_IL_03d0;
																			IL_07d3:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_07f1;
																			IL_07f1:
																			ptr2 += 8;
																			goto IL_07ff;
																			IL_07ff:
																			num5--;
																			goto end_IL_03d0;
																			IL_0812:
																			if (6 >= b)
																			{
																				goto IL_0820;
																			}
																			goto IL_08e0;
																			IL_0820:
																			if (6 <= b)
																			{
																				goto IL_082b;
																			}
																			goto IL_087d;
																			IL_082b:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_086a;
																			IL_086a:
																			num5 -= 3;
																			goto end_IL_03d0;
																			IL_087d:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_088b;
																			IL_088b:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0899;
																			IL_0899:
																			array[num5] = 5;
																			goto IL_08a7;
																			IL_08a7:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_08bf;
																			IL_08bf:
																			num5++;
																			goto IL_08cd;
																			IL_08cd:
																			ptr2 += 8;
																			goto end_IL_03d0;
																			IL_08e0:
																			if (7 < b)
																			{
																				goto IL_08eb;
																			}
																			goto IL_0916;
																			IL_08eb:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_08f6;
																			IL_08f6:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0901;
																			IL_0901:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_03d0;
																			IL_0916:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0921;
																			IL_0921:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_094a;
																			IL_094a:
																			ptr2 += 8;
																			goto IL_0958;
																		}
																		break;
																		IL_03c0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 75;
																break;
																continue;
																end_IL_03d0:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a20;
												IL_0a20:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0984:
												break;
											}
											continue;
											end_IL_0997:
											break;
										}
										continue;
										end_IL_09a1:
										break;
									}
									continue;
									end_IL_09ac:
									break;
								}
								continue;
								end_IL_09bc:
								break;
							}
							continue;
							end_IL_09cc:
							break;
						}
						continue;
						end_IL_09dc:
						break;
					}
					continue;
					end_IL_09f5:
					break;
				}
				continue;
				end_IL_0a05:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 104;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 76;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 100;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsUpperFormatLiterals.getApplicationEvidenceNormal);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 == 1)
												{
													num = 117;
													while (true)
													{
														if (num != 117)
														{
															if (num != 1098)
															{
																break;
															}
															switch (num)
															{
															case 10:
															case 35:
																break;
															case 34:
																goto IL_0017;
															case 40:
																goto IL_0025;
															case 50:
																goto IL_0033;
															case 97:
																goto IL_0041;
															case 26:
																goto IL_004f;
															case 61:
															case 92:
																goto IL_005a;
															case 54:
																goto IL_009a;
															case 107:
																goto IL_00ae;
															case 39:
																goto IL_00c1;
															case 25:
																goto IL_00cf;
															case 9:
																goto IL_00dd;
															case 32:
															case 53:
																goto IL_00e8;
															case 24:
																goto IL_00f6;
															case 14:
															case 70:
																goto IL_0104;
															case 101:
																goto IL_012d;
															case 28:
																goto IL_013b;
															case 27:
																goto IL_014e;
															case 18:
															case 63:
																goto IL_015c;
															case 46:
																goto IL_0175;
															case 82:
																goto IL_0183;
															case 57:
																goto IL_019a;
															case 33:
															case 41:
																goto IL_01ad;
															case 71:
																goto IL_01ce;
															case 79:
																goto IL_01d9;
															case 85:
																goto IL_01e7;
															case 22:
															case 86:
																goto IL_01f5;
															case 16:
																goto IL_0203;
															case 105:
																goto IL_0226;
															case 52:
																goto IL_0230;
															case 75:
																goto IL_023e;
															case 49:
																goto IL_025a;
															case 43:
															case 110:
																goto IL_026d;
															case 102:
																goto IL_027b;
															case 56:
															case 67:
																goto IL_0286;
															case 88:
																goto IL_02e8;
															case 89:
																goto IL_02fb;
															case 68:
															case 98:
																goto IL_0309;
															case 74:
																goto IL_0317;
															case 2:
															case 84:
																goto IL_032e;
															case 47:
																goto IL_035a;
															case 93:
																goto IL_0368;
															case 21:
																goto IL_0376;
															case 7:
																goto IL_0389;
															case 3:
															case 99:
																goto IL_0397;
															case 108:
																goto IL_03d7;
															case 4:
																goto IL_03eb;
															case 30:
																goto IL_03fe;
															case 48:
															case 59:
																goto IL_0409;
															case 0:
																goto IL_0414;
															case 45:
																goto IL_0421;
															case 42:
															case 95:
																goto IL_042c;
															case 5:
															case 6:
															case 12:
															case 13:
															case 15:
															case 19:
															case 23:
															case 29:
															case 36:
															case 37:
															case 38:
															case 58:
															case 65:
															case 69:
															case 73:
															case 78:
															case 81:
															case 87:
															case 109:
																goto IL_0448;
															default:
																continue;
															case 1:
															case 8:
															case 17:
															case 20:
															case 55:
															case 62:
															case 64:
															case 66:
															case 77:
															case 83:
															case 91:
															case 94:
															case 96:
															case 106:
																goto end_IL_0643;
															case 11:
																goto end_IL_0656;
															case 90:
																goto end_IL_0669;
															case 100:
																goto end_IL_0673;
															case 60:
																goto end_IL_067e;
															case 31:
															case 44:
																goto end_IL_0693;
															case 76:
																goto end_IL_06ac;
															case 51:
															case 72:
																goto end_IL_06bc;
															case 103:
																goto end_IL_06cc;
															case 104:
																goto end_IL_06e5;
															case 80:
																goto IL_0700;
															}
															goto IL_000e;
														}
														goto IL_0700;
														IL_0700:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0643:
														break;
													}
													continue;
												}
												goto IL_000e;
												IL_0414:
												if (11 > b)
												{
												}
												goto IL_0448;
												IL_0421:
												if (10 <= b)
												{
													goto IL_042c;
												}
												goto IL_0448;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												goto IL_0448;
												IL_0033:
												if (b <= 11)
												{
													goto IL_0041;
												}
												goto IL_0448;
												IL_0041:
												if (6 >= b)
												{
													goto IL_004f;
												}
												goto IL_026d;
												IL_004f:
												if (6 <= b)
												{
													goto IL_005a;
												}
												goto IL_00c1;
												IL_005a:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_009a;
												IL_009a:
												array[num5 - 2] = 0;
												goto IL_00ae;
												IL_00ae:
												num5--;
												continue;
												IL_00c1:
												if (3 >= b)
												{
													goto IL_00cf;
												}
												goto IL_01ce;
												IL_00cf:
												if (3 > b)
												{
													goto IL_00dd;
												}
												goto IL_01ad;
												IL_00dd:
												if (1 < b)
												{
													goto IL_00e8;
												}
												goto IL_014e;
												IL_00e8:
												if (2 >= b)
												{
													goto IL_00f6;
												}
												goto IL_0448;
												IL_00f6:
												if (2 <= b)
												{
													goto IL_0104;
												}
												goto IL_0448;
												IL_0104:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_012d;
												IL_012d:
												ptr2 += 8;
												goto IL_013b;
												IL_013b:
												num5--;
												continue;
												IL_014e:
												if (1 <= b)
												{
													goto IL_015c;
												}
												goto IL_0448;
												IL_015c:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_0175;
												IL_0175:
												array[num5] = 0;
												goto IL_0183;
												IL_0183:
												num5++;
												num = 57;
												goto IL_019a;
												IL_019a:
												ptr2 += 8;
												continue;
												IL_01ad:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 96;
												continue;
												IL_01ce:
												if (4 < b)
												{
													goto IL_01d9;
												}
												num = 49;
												goto IL_025a;
												IL_01d9:
												if (5 >= b)
												{
													goto IL_01e7;
												}
												goto IL_0448;
												IL_01e7:
												if (5 <= b)
												{
													goto IL_01f5;
												}
												goto IL_0448;
												IL_01f5:
												array[num5] = 0;
												goto IL_0203;
												IL_0203:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0226;
												IL_0226:
												array2[num5] = null;
												goto IL_0230;
												IL_0230:
												num5++;
												goto IL_023e;
												IL_023e:
												ptr2 += 8;
												continue;
												IL_042c:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_025a:
												if (4 <= b)
												{
													continue;
												}
												goto IL_0448;
												IL_026d:
												if (9 >= b)
												{
													goto IL_027b;
												}
												goto IL_03fe;
												IL_027b:
												if (9 <= b)
												{
													goto IL_0286;
												}
												goto IL_02fb;
												IL_0286:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_02e8;
												IL_02e8:
												num5 -= 2;
												continue;
												IL_02fb:
												if (7 < b)
												{
													goto IL_0309;
												}
												goto IL_0389;
												IL_0309:
												if (8 >= b)
												{
													goto IL_0317;
												}
												goto IL_0448;
												IL_0317:
												if (8 <= b)
												{
													num = 2;
													goto IL_032e;
												}
												goto IL_0448;
												IL_0448:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_032e:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												num = 47;
												goto IL_035a;
												IL_035a:
												array[num5] = 0;
												goto IL_0368;
												IL_0368:
												num5++;
												goto IL_0376;
												IL_0376:
												ptr2 += 8;
												continue;
												IL_0389:
												if (7 <= b)
												{
													goto IL_0397;
												}
												goto IL_0448;
												IL_0397:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_03d7;
												IL_03d7:
												array[num5 - 2] = 0;
												goto IL_03eb;
												IL_03eb:
												num5--;
												continue;
												IL_03fe:
												if (10 < b)
												{
													goto IL_0409;
												}
												goto IL_0421;
												IL_0409:
												if (11 >= b)
												{
													goto IL_0414;
												}
												goto IL_0448;
												continue;
												end_IL_0656:
												break;
											}
											continue;
											end_IL_0669:
											break;
										}
										continue;
										end_IL_0673:
										break;
									}
									continue;
									end_IL_067e:
									break;
								}
								continue;
								end_IL_0693:
								break;
							}
							continue;
							end_IL_06ac:
							break;
						}
						continue;
						end_IL_06bc:
						break;
					}
					continue;
					end_IL_06cc:
					break;
				}
				continue;
				end_IL_06e5:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 128;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 112;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadWritegetContextID.DefineManifestResourceDateSeparator);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02e5:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02c8:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02bb:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_02a8:
																							if (14 < b)
																							{
																								num = 158;
																								while (true)
																								{
																									if (num != 158)
																									{
																										if (num != 1139)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 45:
																										case 99:
																											goto IL_02a8;
																										case 66:
																											goto IL_02bb;
																										case 130:
																											goto IL_02c8;
																										case 62:
																											goto end_IL_02c8;
																										case 53:
																											goto IL_02e5;
																										case 109:
																											goto end_IL_02e5;
																										case 135:
																										case 139:
																											goto end_IL_02f5;
																										case 33:
																											goto IL_0310;
																										case 11:
																										case 47:
																											goto IL_031e;
																										case 88:
																											goto IL_0336;
																										case 16:
																										case 52:
																											goto IL_0341;
																										case 9:
																											goto IL_034f;
																										case 19:
																										case 67:
																											goto IL_035f;
																										case 46:
																											goto IL_039f;
																										case 86:
																											goto IL_03b3;
																										case 95:
																											goto IL_03c6;
																										case 41:
																											goto IL_03d4;
																										case 30:
																										case 97:
																											goto IL_03e7;
																										case 13:
																											goto IL_03f5;
																										case 111:
																											goto IL_041a;
																										case 96:
																										case 110:
																											goto IL_0425;
																										case 91:
																											goto IL_0441;
																										case 114:
																											goto IL_0454;
																										case 87:
																											goto IL_045e;
																										case 38:
																											goto IL_046c;
																										case 17:
																										case 115:
																											goto IL_047f;
																										case 82:
																											goto IL_048d;
																										case 44:
																										case 84:
																											goto IL_049b;
																										case 48:
																											goto IL_04e8;
																										case 3:
																											goto IL_04fc;
																										case 134:
																											goto IL_050f;
																										case 59:
																										case 126:
																											goto IL_051d;
																										case 94:
																											goto IL_057f;
																										case 42:
																										case 137:
																											goto IL_0592;
																										case 14:
																										case 85:
																											goto IL_05a0;
																										case 5:
																											goto IL_05ae;
																										case 27:
																										case 28:
																											goto IL_05b9;
																										case 29:
																											goto IL_05c7;
																										case 24:
																										case 69:
																											goto IL_05d5;
																										case 6:
																											goto IL_05e3;
																										case 116:
																											goto IL_0604;
																										case 83:
																											goto IL_061b;
																										case 106:
																										case 136:
																											goto end_IL_0295;
																										case 133:
																											goto IL_0672;
																										case 100:
																											goto IL_0680;
																										case 54:
																										case 74:
																											goto IL_068e;
																										case 10:
																											goto IL_06bc;
																										case 4:
																										case 107:
																											goto IL_06ca;
																										case 1:
																										case 25:
																											goto IL_06d5;
																										case 98:
																											goto IL_06e3;
																										case 8:
																										case 18:
																											goto IL_06f1;
																										case 65:
																											goto IL_071a;
																										case 117:
																											goto IL_0733;
																										case 138:
																											goto IL_0743;
																										case 140:
																											goto IL_0756;
																										case 72:
																											goto IL_0764;
																										case 124:
																										case 141:
																											goto IL_0777;
																										case 80:
																											goto IL_0785;
																										case 2:
																										case 77:
																											goto IL_0793;
																										case 15:
																											goto IL_07ac;
																										case 121:
																											goto IL_07ba;
																										case 125:
																											goto IL_07c8;
																										case 43:
																										case 146:
																											goto IL_07e4;
																										case 64:
																											goto IL_0802;
																										case 58:
																											goto IL_0810;
																										case 144:
																										case 151:
																											goto IL_0823;
																										case 49:
																											goto IL_086c;
																										case 142:
																											goto IL_0880;
																										case 73:
																											goto IL_0890;
																										case 78:
																											goto IL_089b;
																										case 0:
																										case 12:
																										case 20:
																										case 21:
																										case 26:
																										case 31:
																										case 34:
																										case 37:
																										case 39:
																										case 51:
																										case 57:
																										case 68:
																										case 70:
																										case 75:
																										case 79:
																										case 92:
																										case 101:
																										case 102:
																										case 104:
																										case 105:
																										case 120:
																										case 122:
																										case 123:
																										case 131:
																										case 147:
																										case 148:
																										case 149:
																										case 150:
																											goto end_IL_02d5;
																										case 7:
																										case 23:
																										case 35:
																										case 36:
																										case 40:
																										case 50:
																										case 55:
																										case 56:
																										case 60:
																										case 63:
																										case 71:
																										case 90:
																										case 93:
																										case 103:
																										case 113:
																										case 132:
																										case 143:
																										case 145:
																											goto end_IL_0305;
																										case 89:
																											goto end_IL_08c2;
																										case 61:
																											goto end_IL_08d5;
																										case 22:
																											goto end_IL_08df;
																										case 76:
																											goto end_IL_08ea;
																										case 112:
																										case 119:
																											goto end_IL_08fa;
																										case 32:
																											goto end_IL_090a;
																										case 81:
																										case 129:
																											goto end_IL_091a;
																										case 127:
																											goto end_IL_0933;
																										case 128:
																											goto end_IL_0943;
																										case 108:
																										case 118:
																											goto IL_095e;
																										}
																										continue;
																									}
																									goto IL_0890;
																									IL_0890:
																									if (15 < b)
																									{
																										goto end_IL_02d5;
																									}
																									goto IL_089b;
																									IL_089b:
																									if (15 > b)
																									{
																										num = 34;
																									}
																									goto end_IL_02d5;
																									continue;
																									end_IL_0295:
																									break;
																								}
																								break;
																							}
																							goto IL_041a;
																							IL_051d:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_057f;
																							IL_057f:
																							num5 -= 2;
																							goto end_IL_0305;
																							IL_041a:
																							if (14 <= b)
																							{
																								goto IL_0425;
																							}
																							goto IL_0441;
																							IL_0425:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0305;
																							IL_0441:
																							if (13 < b)
																							{
																								goto end_IL_02d5;
																							}
																							goto IL_050f;
																							IL_050f:
																							if (13 > b)
																							{
																								goto end_IL_02d5;
																							}
																							goto IL_051d;
																						}
																						break;
																					}
																					goto IL_0336;
																					IL_03b3:
																					num5--;
																					goto end_IL_0305;
																					IL_0336:
																					if (12 > b)
																					{
																						goto IL_0341;
																					}
																					goto IL_035f;
																					IL_0341:
																					if (10 >= b)
																					{
																						goto IL_034f;
																					}
																					goto IL_047f;
																					IL_034f:
																					if (10 > b)
																					{
																						goto IL_03c6;
																					}
																					goto IL_03e7;
																					IL_03e7:
																					array[num5] = 0;
																					goto IL_03f5;
																					IL_03f5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0454;
																					IL_0454:
																					array2[num5] = null;
																					goto IL_045e;
																					IL_045e:
																					num5++;
																					goto IL_046c;
																					IL_046c:
																					ptr2 += 8;
																					goto end_IL_0305;
																					IL_03c6:
																					if (9 < b)
																					{
																						goto end_IL_02d5;
																					}
																					goto IL_03d4;
																					IL_03d4:
																					if (9 <= b)
																					{
																						goto end_IL_0305;
																					}
																					goto end_IL_02d5;
																					IL_047f:
																					if (11 < b)
																					{
																						goto end_IL_02d5;
																					}
																					goto IL_048d;
																					IL_048d:
																					if (11 > b)
																					{
																						goto end_IL_02d5;
																					}
																					goto IL_049b;
																					IL_049b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					num = 48;
																					goto IL_04e8;
																					IL_04e8:
																					array[num5 - 2] = 0;
																					goto IL_04fc;
																					IL_04fc:
																					num5--;
																					goto end_IL_0305;
																					IL_035f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_039f;
																					IL_039f:
																					array[num5 - 2] = 0;
																					goto IL_03b3;
																				}
																				goto IL_062e;
																			}
																			goto IL_0310;
																			IL_0810:
																			num5--;
																			goto end_IL_0305;
																			IL_0310:
																			if (8 <= b)
																			{
																				goto IL_031e;
																			}
																			goto IL_0592;
																			IL_031e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0305;
																			IL_0592:
																			if (4 < b)
																			{
																				goto IL_05a0;
																			}
																			goto IL_06bc;
																			IL_05a0:
																			if (6 >= b)
																			{
																				goto IL_05ae;
																			}
																			goto IL_0672;
																			IL_05ae:
																			if (6 > b)
																			{
																				goto IL_05b9;
																			}
																			goto IL_062e;
																			IL_05b9:
																			if (5 < b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_05c7;
																			IL_05c7:
																			if (5 > b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_05d5;
																			IL_05d5:
																			array[num5] = 5;
																			goto IL_05e3;
																			IL_05e3:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			num = 116;
																			goto IL_0604;
																			IL_0604:
																			num5++;
																			num = 83;
																			goto IL_061b;
																			IL_061b:
																			ptr2 += 8;
																			goto end_IL_0305;
																			IL_062e:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0743;
																			IL_0743:
																			num5 -= 3;
																			goto end_IL_0305;
																			IL_0672:
																			if (7 < b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_0680;
																			IL_0680:
																			if (7 > b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_068e;
																			IL_068e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0756;
																			IL_0756:
																			ptr2 += 8;
																			goto IL_0764;
																			IL_0764:
																			num5--;
																			goto end_IL_0305;
																			IL_06bc:
																			if (4 > b)
																			{
																				goto IL_06ca;
																			}
																			goto IL_07e4;
																			IL_06ca:
																			if (2 < b)
																			{
																				goto IL_06d5;
																			}
																			goto IL_0733;
																			IL_06d5:
																			if (3 < b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_06e3;
																			IL_06e3:
																			if (3 > b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_06f1;
																			IL_06f1:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_071a;
																			IL_071a:
																			array[num5 - 1] = 5;
																			goto end_IL_0305;
																			IL_0733:
																			if (2 > b)
																			{
																				goto IL_0777;
																			}
																			goto IL_0823;
																			IL_0777:
																			if (1 < b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_0785;
																			IL_0785:
																			if (1 > b)
																			{
																				goto end_IL_02d5;
																			}
																			goto IL_0793;
																			IL_0793:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_07ac;
																			IL_07ac:
																			array[num5] = 0;
																			goto IL_07ba;
																			IL_07ba:
																			num5++;
																			goto IL_07c8;
																			IL_07c8:
																			ptr2 += 8;
																			num = 23;
																			goto end_IL_0305;
																			IL_0823:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 49;
																			goto IL_086c;
																			IL_086c:
																			array[num5 - 2] = 0;
																			goto IL_0880;
																			IL_0880:
																			num5--;
																			goto end_IL_0305;
																			IL_07e4:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0802;
																			IL_0802:
																			ptr2 += 8;
																			goto IL_0810;
																			continue;
																			end_IL_02c8:
																			break;
																		}
																		continue;
																		end_IL_02d5:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0305;
																continue;
																end_IL_02e5:
																break;
															}
															continue;
															end_IL_02f5:
															break;
														}
														continue;
														end_IL_0305:
														break;
													}
													continue;
												}
												goto IL_095e;
												IL_095e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c2:
												break;
											}
											continue;
											end_IL_08d5:
											break;
										}
										continue;
										end_IL_08df:
										break;
									}
									continue;
									end_IL_08ea:
									break;
								}
								continue;
								end_IL_08fa:
								break;
							}
							continue;
							end_IL_090a:
							break;
						}
						continue;
						end_IL_091a:
						break;
					}
					continue;
					end_IL_0933:
					break;
				}
				continue;
				end_IL_0943:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 68;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TYPEKINDParallelInvoke.TypeLibImporterFlagsgetResolvedAssemblies);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0259:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			if (6 < b)
																			{
																				while (true)
																				{
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_021c:
																							if (10 < b)
																							{
																								num = 123;
																								while (true)
																								{
																									if (num != 123)
																									{
																										if (num != 1104)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 44:
																										case 57:
																											goto IL_021c;
																										case 16:
																										case 42:
																											goto end_IL_021c;
																										case 6:
																											goto end_IL_022c;
																										case 10:
																											goto end_IL_0239;
																										case 54:
																											goto IL_0259;
																										case 95:
																											goto end_IL_0259;
																										case 31:
																										case 62:
																											goto end_IL_0269;
																										case 39:
																											goto IL_0284;
																										case 73:
																											goto IL_0297;
																										case 46:
																										case 66:
																											goto IL_02a5;
																										case 35:
																											goto IL_0310;
																										case 61:
																										case 74:
																											goto end_IL_0209;
																										case 72:
																										case 82:
																											goto IL_033f;
																										case 92:
																											goto IL_034a;
																										case 20:
																										case 103:
																											goto IL_035a;
																										case 99:
																										case 110:
																											goto IL_036a;
																										case 89:
																											goto IL_03aa;
																										case 7:
																											goto IL_03be;
																										case 114:
																											goto IL_03d1;
																										case 11:
																										case 59:
																											goto IL_03df;
																										case 104:
																											goto IL_040b;
																										case 60:
																											goto IL_0419;
																										case 48:
																											goto IL_0427;
																										case 43:
																											goto IL_043a;
																										case 86:
																											goto IL_0448;
																										case 109:
																											goto IL_045b;
																										case 38:
																										case 64:
																											goto IL_0469;
																										case 1:
																										case 69:
																											goto IL_0477;
																										case 36:
																											goto IL_0482;
																										case 100:
																										case 116:
																											goto IL_0495;
																										case 37:
																											goto IL_04a3;
																										case 47:
																										case 98:
																											goto IL_04b1;
																										case 87:
																											goto IL_04bf;
																										case 107:
																											goto IL_04e2;
																										case 19:
																											goto IL_04f5;
																										case 113:
																											goto IL_0503;
																										case 108:
																											goto IL_051f;
																										case 58:
																											goto IL_052d;
																										case 8:
																											goto IL_0538;
																										case 83:
																											goto IL_0546;
																										case 34:
																										case 55:
																											goto IL_0554;
																										case 12:
																											goto IL_057d;
																										case 53:
																											goto IL_058b;
																										case 80:
																											goto IL_05a7;
																										case 0:
																										case 70:
																											goto IL_05b2;
																										case 102:
																											goto IL_05cb;
																										case 76:
																											goto IL_05d9;
																										case 17:
																											goto IL_05e7;
																										case 23:
																										case 91:
																											goto IL_0608;
																										case 29:
																										case 75:
																											goto IL_0620;
																										case 105:
																											goto IL_0669;
																										case 106:
																											goto IL_0686;
																										case 2:
																										case 15:
																										case 21:
																										case 24:
																										case 26:
																										case 27:
																										case 28:
																										case 30:
																										case 40:
																										case 45:
																										case 50:
																										case 52:
																										case 56:
																										case 63:
																										case 78:
																										case 79:
																										case 90:
																										case 93:
																										case 96:
																										case 112:
																										case 115:
																											goto end_IL_0249;
																										case 5:
																										case 13:
																										case 18:
																										case 32:
																										case 33:
																										case 49:
																										case 65:
																										case 71:
																										case 77:
																										case 84:
																										case 85:
																										case 94:
																										case 97:
																										case 101:
																											goto end_IL_0279;
																										case 111:
																											goto end_IL_06b2;
																										case 25:
																											goto end_IL_06c5;
																										case 51:
																											goto end_IL_06cf;
																										case 22:
																											goto end_IL_06da;
																										case 14:
																										case 88:
																											goto end_IL_06ef;
																										case 4:
																											goto end_IL_06ff;
																										case 9:
																										case 41:
																											goto end_IL_070f;
																										case 67:
																											goto end_IL_071f;
																										case 68:
																											goto end_IL_072f;
																										case 3:
																										case 81:
																											goto IL_0753;
																										}
																										continue;
																									}
																									goto IL_043a;
																									IL_043a:
																									if (11 < b)
																									{
																										goto end_IL_0249;
																									}
																									goto IL_0448;
																									IL_0448:
																									if (11 <= b)
																									{
																									}
																									goto end_IL_0249;
																									continue;
																									end_IL_0209:
																									break;
																								}
																								goto IL_0323;
																							}
																							goto IL_0284;
																							IL_0284:
																							if (10 > b)
																							{
																								goto end_IL_0249;
																							}
																							goto IL_0323;
																							IL_0323:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_0279;
																							continue;
																							end_IL_021c:
																							break;
																						}
																						continue;
																					}
																					goto IL_0297;
																					IL_0427:
																					ptr2 += 8;
																					goto end_IL_0279;
																					IL_0297:
																					if (9 <= b)
																					{
																						goto IL_02a5;
																					}
																					goto IL_033f;
																					IL_02a5:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 35;
																					goto IL_0310;
																					IL_0310:
																					num6 -= 2;
																					goto end_IL_0279;
																					IL_033f:
																					if (7 >= b)
																					{
																						goto IL_034a;
																					}
																					goto IL_035a;
																					IL_034a:
																					if (7 > b)
																					{
																						goto end_IL_0249;
																					}
																					goto IL_036a;
																					IL_036a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_03aa;
																					IL_03aa:
																					array[num6 - 2] = 0;
																					goto IL_03be;
																					IL_03be:
																					num6--;
																					goto end_IL_0279;
																					IL_035a:
																					if (8 < b)
																					{
																						goto end_IL_0249;
																					}
																					goto IL_03d1;
																					IL_03d1:
																					if (8 > b)
																					{
																						goto end_IL_0249;
																					}
																					goto IL_03df;
																					IL_03df:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					num = 104;
																					goto IL_040b;
																					IL_040b:
																					array[num6] = 0;
																					goto IL_0419;
																					IL_0419:
																					num6++;
																					goto IL_0427;
																					continue;
																					end_IL_022c:
																					break;
																				}
																				continue;
																			}
																			goto IL_045b;
																			IL_0620:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			num = 105;
																			goto IL_0669;
																			IL_045b:
																			if (6 > b)
																			{
																				goto IL_0469;
																			}
																			goto IL_0620;
																			IL_0469:
																			if (3 < b)
																			{
																				goto IL_0477;
																			}
																			goto IL_051f;
																			IL_0477:
																			if (4 >= b)
																			{
																				goto IL_0482;
																			}
																			goto IL_0495;
																			IL_0482:
																			if (4 > b)
																			{
																				goto end_IL_0249;
																			}
																			goto end_IL_0279;
																			IL_0495:
																			if (5 < b)
																			{
																				goto end_IL_0249;
																			}
																			goto IL_04a3;
																			IL_04a3:
																			if (5 > b)
																			{
																				goto end_IL_0249;
																			}
																			goto IL_04b1;
																			IL_04b1:
																			array[num6] = 0;
																			goto IL_04bf;
																			IL_04bf:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04e2;
																			IL_04e2:
																			array2[num6] = null;
																			num = 19;
																			goto IL_04f5;
																			IL_04f5:
																			num6++;
																			goto IL_0503;
																			IL_0503:
																			ptr2 += 8;
																			num = 13;
																			goto end_IL_0279;
																			IL_051f:
																			if (3 > b)
																			{
																				goto IL_052d;
																			}
																			goto IL_0608;
																			IL_052d:
																			if (1 < b)
																			{
																				goto IL_0538;
																			}
																			num = 80;
																			goto IL_05a7;
																			IL_0538:
																			if (2 < b)
																			{
																				goto end_IL_0249;
																			}
																			goto IL_0546;
																			IL_0546:
																			if (2 > b)
																			{
																				goto end_IL_0249;
																			}
																			goto IL_0554;
																			IL_0554:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_057d;
																			IL_057d:
																			ptr2 += 8;
																			goto IL_058b;
																			IL_058b:
																			num6--;
																			goto end_IL_0279;
																			IL_0669:
																			array[num6 - 2] = 0;
																			num = 106;
																			goto IL_0686;
																			IL_05a7:
																			if (1 > b)
																			{
																				num = 52;
																				goto end_IL_0249;
																			}
																			goto IL_05b2;
																			IL_05b2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_05cb;
																			IL_05cb:
																			array[num6] = 0;
																			goto IL_05d9;
																			IL_05d9:
																			num6++;
																			goto IL_05e7;
																			IL_05e7:
																			ptr2 += 8;
																			goto end_IL_0279;
																			IL_0686:
																			num6--;
																			goto end_IL_0279;
																			IL_0608:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0279;
																			continue;
																			end_IL_0239:
																			break;
																		}
																		continue;
																		end_IL_0249:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 32;
																goto end_IL_0279;
																continue;
																end_IL_0259:
																break;
															}
															continue;
															end_IL_0269:
															break;
														}
														continue;
														end_IL_0279:
														break;
													}
													continue;
												}
												num = 81;
												goto IL_0753;
												IL_0753:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_06b2:
												break;
											}
											continue;
											end_IL_06c5:
											break;
										}
										continue;
										end_IL_06cf:
										break;
									}
									continue;
									end_IL_06da:
									break;
								}
								continue;
								end_IL_06ef:
								break;
							}
							continue;
							end_IL_06ff:
							break;
						}
						continue;
						end_IL_070f:
						break;
					}
					continue;
					end_IL_071f:
					break;
				}
				continue;
				end_IL_072f:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 45;
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									num = 17;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExecutionEngineExceptionPermitOnlySetInstance.OpenFileSafeKeyHandle);
											num = 134;
											while (true)
											{
												if (num != 134)
												{
													if (num == 1115)
													{
														switch (num)
														{
														case 94:
															goto end_IL_0227;
														case 17:
															goto end_IL_023a;
														case 6:
															goto end_IL_024e;
														case 42:
															goto end_IL_0263;
														case 25:
														case 28:
															goto end_IL_0281;
														case 32:
															goto end_IL_0291;
														case 51:
														case 82:
															goto end_IL_02a1;
														case 44:
															goto end_IL_02b1;
														case 45:
															goto end_IL_02c1;
														case 10:
														case 14:
														case 26:
														case 36:
														case 39:
														case 54:
														case 74:
														case 76:
														case 78:
														case 84:
														case 93:
														case 111:
														case 120:
														case 122:
														case 123:
															goto IL_02e4;
														case 2:
														case 75:
															goto IL_02f4;
														case 31:
															goto IL_02fd;
														case 19:
															goto IL_0314;
														case 47:
															goto IL_0322;
														case 16:
															goto IL_0330;
														case 0:
															goto IL_033e;
														case 29:
														case 53:
															goto IL_0349;
														case 1:
														case 64:
															goto IL_0357;
														case 91:
														case 121:
															goto IL_0362;
														case 100:
															goto IL_0370;
														case 11:
														case 113:
															goto IL_037e;
														case 114:
															goto IL_0396;
														case 15:
														case 127:
															goto IL_03a4;
														case 80:
															goto IL_03cd;
														case 40:
															goto IL_03db;
														case 102:
															goto IL_03ee;
														case 4:
														case 9:
															goto IL_03f9;
														case 125:
															goto IL_0439;
														case 37:
															goto IL_044d;
														case 33:
															goto IL_0460;
														case 48:
														case 98:
															goto IL_0477;
														case 12:
															goto IL_048e;
														case 109:
														case 110:
															goto IL_049c;
														case 66:
															goto IL_0513;
														case 112:
															goto IL_0526;
														case 20:
															goto IL_0539;
														case 38:
														case 97:
															goto IL_0547;
														case 57:
															goto IL_0555;
														case 41:
														case 65:
															goto IL_0563;
														case 60:
															goto IL_0571;
														case 24:
														case 69:
															goto IL_057f;
														case 46:
															goto IL_059c;
														case 34:
															goto IL_05db;
														case 83:
														case 119:
															goto IL_05ee;
														case 50:
														case 104:
															goto IL_0601;
														case 87:
															goto IL_060f;
														case 3:
														case 67:
															goto IL_061d;
														case 90:
															goto IL_0639;
														case 8:
														case 73:
															goto IL_0644;
														case 115:
															goto IL_0684;
														case 70:
															goto IL_06a1;
														case 56:
															goto IL_06b4;
														case 21:
														case 22:
															goto IL_06bf;
														case 118:
															goto IL_06cd;
														case 58:
														case 85:
															goto IL_06db;
														case 13:
															goto IL_06f4;
														case 81:
															goto IL_0702;
														case 101:
															goto IL_0710;
														case 89:
															goto IL_0723;
														case 55:
														case 92:
															goto IL_0731;
														case 61:
															goto IL_073f;
														case 62:
															goto IL_0762;
														case 107:
															goto IL_076c;
														case 68:
															goto IL_077a;
														case 88:
															goto IL_078d;
														case 7:
															goto IL_079b;
														case 124:
															goto IL_07a9;
														case 5:
														case 18:
														case 23:
														case 27:
														case 30:
														case 35:
														case 43:
														case 49:
														case 52:
														case 59:
														case 63:
														case 72:
														case 77:
														case 79:
														case 86:
														case 95:
														case 96:
														case 99:
														case 103:
														case 106:
														case 108:
														case 116:
														case 117:
														case 126:
															goto IL_07bc;
														case 71:
														case 105:
															goto IL_07e1;
														}
														continue;
													}
												}
												else
												{
													ptr2 = ptr;
												}
												goto IL_02e4;
												IL_077a:
												ptr2 += 8;
												goto IL_02e4;
												IL_078d:
												array[num4] = 0;
												goto IL_079b;
												IL_07bc:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_078d;
												IL_02e4:
												if (num5 != 1)
												{
													goto IL_02f4;
												}
												goto IL_07e1;
												IL_07e1:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_02f4:
												b = *ptr2;
												goto IL_02fd;
												IL_02fd:
												ptr2++;
												num = 19;
												goto IL_0314;
												IL_0314:
												if (b >= 1)
												{
													goto IL_0322;
												}
												goto IL_07bc;
												IL_0322:
												if (b <= 12)
												{
													goto IL_0330;
												}
												goto IL_07bc;
												IL_0330:
												if (6 >= b)
												{
													goto IL_033e;
												}
												goto IL_0539;
												IL_033e:
												if (6 <= b)
												{
													goto IL_02e4;
												}
												goto IL_0349;
												IL_0349:
												if (3 < b)
												{
													goto IL_0357;
												}
												goto IL_03ee;
												IL_0357:
												if (4 < b)
												{
													goto IL_0362;
												}
												goto IL_0396;
												IL_0362:
												if (5 >= b)
												{
													goto IL_0370;
												}
												goto IL_07bc;
												IL_0370:
												if (5 <= b)
												{
													goto IL_037e;
												}
												goto IL_07bc;
												IL_037e:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_02e4;
												IL_0396:
												if (4 <= b)
												{
													goto IL_03a4;
												}
												goto IL_07bc;
												IL_03a4:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_03cd;
												IL_03cd:
												ptr2 += 8;
												goto IL_03db;
												IL_03db:
												num4--;
												goto IL_02e4;
												IL_03ee:
												if (3 <= b)
												{
													goto IL_03f9;
												}
												goto IL_0460;
												IL_03f9:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0439;
												IL_0439:
												array[num4 - 2] = 0;
												goto IL_044d;
												IL_044d:
												num4--;
												goto IL_02e4;
												IL_0460:
												if (1 < b)
												{
													num = 98;
													goto IL_0477;
												}
												goto IL_0526;
												IL_079b:
												num4++;
												goto IL_07a9;
												IL_0477:
												if (2 >= b)
												{
													num = 12;
													goto IL_048e;
												}
												goto IL_07bc;
												IL_07a9:
												ptr2 += 8;
												goto IL_02e4;
												IL_048e:
												if (2 <= b)
												{
													goto IL_049c;
												}
												goto IL_07bc;
												IL_049c:
												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												num = 66;
												goto IL_0513;
												IL_0513:
												num4 -= 2;
												goto IL_02e4;
												IL_0526:
												if (1 > b)
												{
												}
												goto IL_07bc;
												IL_0539:
												if (9 < b)
												{
													goto IL_0547;
												}
												goto IL_0639;
												IL_0547:
												if (11 >= b)
												{
													goto IL_0555;
												}
												goto IL_0601;
												IL_0555:
												if (11 > b)
												{
													goto IL_0563;
												}
												goto IL_05ee;
												IL_0563:
												if (10 >= b)
												{
													goto IL_0571;
												}
												goto IL_07bc;
												IL_0571:
												if (10 <= b)
												{
													goto IL_057f;
												}
												goto IL_07bc;
												IL_057f:
												array[num4 - 1] = 0;
												num = 46;
												goto IL_059c;
												IL_059c:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]) = ((delegate*<int, int>)EndOfStreamVolumeDown[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
												goto IL_05db;
												IL_05db:
												ptr2 += 8;
												goto IL_02e4;
												IL_05ee:
												num4--;
												goto IL_02e4;
												IL_0601:
												if (12 >= b)
												{
													goto IL_060f;
												}
												goto IL_07bc;
												IL_060f:
												if (12 <= b)
												{
													goto IL_061d;
												}
												goto IL_07bc;
												IL_061d:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												goto IL_02e4;
												IL_0639:
												if (9 <= b)
												{
													goto IL_0644;
												}
												goto IL_06b4;
												IL_0644:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0684;
												IL_0684:
												array[num4 - 2] = 0;
												num = 70;
												goto IL_06a1;
												IL_06a1:
												num4--;
												goto IL_02e4;
												IL_06b4:
												if (7 < b)
												{
													goto IL_06bf;
												}
												goto IL_0723;
												IL_06bf:
												if (8 >= b)
												{
													goto IL_06cd;
												}
												goto IL_07bc;
												IL_06cd:
												if (8 <= b)
												{
													goto IL_06db;
												}
												goto IL_07bc;
												IL_06db:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												goto IL_06f4;
												IL_06f4:
												array[num4] = 0;
												goto IL_0702;
												IL_0702:
												num4++;
												goto IL_0710;
												IL_0710:
												ptr2 += 8;
												goto IL_02e4;
												IL_0723:
												if (7 <= b)
												{
													goto IL_0731;
												}
												goto IL_07bc;
												IL_0731:
												array[num4] = 0;
												goto IL_073f;
												IL_073f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0762;
												IL_0762:
												array2[num4] = null;
												goto IL_076c;
												IL_076c:
												num4++;
												goto IL_077a;
												continue;
												end_IL_0227:
												break;
											}
											continue;
											end_IL_023a:
											break;
										}
										continue;
										end_IL_024e:
										break;
									}
									continue;
									end_IL_0263:
									break;
								}
								continue;
								end_IL_0281:
								break;
							}
							continue;
							end_IL_0291:
							break;
						}
						continue;
						end_IL_02a1:
						break;
					}
					continue;
					end_IL_02b1:
					break;
				}
				continue;
				end_IL_02c1:
				break;
			}
		}
	}

	static Class118()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 13;
			while (true)
			{
				if (num != 13)
				{
					if (num == 994)
					{
						switch (num)
						{
						default:
							continue;
						case 2:
							break;
						case 0:
							return;
						case 1:
							return;
						case 3:
							return;
						case 4:
							return;
						case 5:
							return;
						case 6:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				return;
			}
		}
	}
}
