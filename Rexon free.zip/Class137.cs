using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Projectile Speed: Default", "Settings", "Change projectile speed.", true, 7, ModType.const_1, false)]
internal class Class137 : MonoBehaviour
{
	internal sealed class _003CDelayedDestroy_003Ed__1 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int int_0;

		private WaitForSeconds waitForSeconds_0;

		public Class137 class137_0;

		private static IntPtr[] CngSignatureIDUnmarshal;

		private static IntPtr[] SortVersionVTBLOB;

		object IEnumerator<object>.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		public _003CDelayedDestroy_003Ed__1(int _003C_003E1__state)
		{
			object obj = this;
			((_003CDelayedDestroy_003Ed__1)obj).int_0 = _003C_003E1__state;
		}

		unsafe void IDisposable.Dispose()
		{
			int num = 8;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								long[] array3 = new long[3];
								while (true)
								{
									object[] array4 = new object[1];
									num = 44;
									while (true)
									{
										array4[0] = this;
										num = 2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setMembershipConditiongetHandlerLength.setMembershipConditiongetHandlerLength_0);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_0213:
														byte b = *ptr2;
														while (true)
														{
															IL_0203:
															ptr2++;
															while (true)
															{
																IL_01f3:
																if (b >= 1)
																{
																	while (b <= 5)
																	{
																		while (true)
																		{
																			IL_01d3:
																			if (3 >= b)
																			{
																				while (true)
																				{
																					IL_01c6:
																					if (3 > b)
																					{
																						while (true)
																						{
																							IL_01b6:
																							if (1 < b)
																							{
																								while (2 >= b)
																								{
																									while (2 <= b)
																									{
																										while (true)
																										{
																											IL_017b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(int*)(ptr2 + num3);
																											while (true)
																											{
																												IL_016b:
																												array[num5] = 0;
																												while (true)
																												{
																													IL_015b:
																													num5++;
																													while (true)
																													{
																														IL_0142:
																														ptr2 += 8;
																														num = 72;
																														while (num != 72)
																														{
																															if (num != 1053)
																															{
																																goto end_IL_0196;
																															}
																															switch (num)
																															{
																															case 61:
																																goto IL_0142;
																															case 16:
																																goto IL_015b;
																															case 57:
																																goto IL_016b;
																															case 13:
																															case 49:
																																goto IL_017b;
																															case 51:
																																goto IL_0196;
																															case 11:
																															case 22:
																																goto IL_01a6;
																															case 58:
																																goto IL_01b6;
																															case 12:
																																goto IL_01c6;
																															case 20:
																																goto IL_01d3;
																															case 35:
																																goto IL_01e3;
																															case 1:
																																goto IL_01f3;
																															case 0:
																																goto IL_0203;
																															case 25:
																															case 64:
																																goto IL_0213;
																															case 30:
																															case 43:
																																goto IL_021e;
																															case 45:
																																goto IL_025e;
																															case 24:
																																goto IL_0272;
																															case 31:
																																goto IL_0285;
																															case 33:
																															case 65:
																																goto IL_0298;
																															case 32:
																																goto IL_02a3;
																															case 39:
																															case 47:
																																goto IL_02ae;
																															case 15:
																																goto IL_02dc;
																															case 38:
																																goto IL_02ef;
																															case 26:
																																goto IL_02fa;
																															case 34:
																															case 37:
																																goto IL_030e;
																															case 3:
																															case 17:
																															case 19:
																															case 29:
																															case 36:
																															case 42:
																															case 46:
																															case 50:
																															case 52:
																															case 53:
																															case 54:
																															case 59:
																															case 62:
																																goto end_IL_0196;
																															case 23:
																																goto IL_033f;
																															case 56:
																																goto IL_034d;
																															case 18:
																																goto IL_035b;
																															case 5:
																															case 6:
																															case 27:
																															case 40:
																															case 41:
																															case 60:
																																goto end_IL_012f;
																															case 21:
																																goto end_IL_0372;
																															case 2:
																																goto end_IL_0385;
																															case 44:
																																goto end_IL_038f;
																															case 55:
																																goto end_IL_039a;
																															case 4:
																															case 14:
																																goto end_IL_03b3;
																															case 63:
																																goto end_IL_03cc;
																															case 10:
																															case 28:
																																goto end_IL_03dc;
																															case 7:
																																goto end_IL_03ec;
																															case 8:
																																goto end_IL_03fc;
																															case 9:
																															case 48:
																																return;
																															}
																															continue;
																															end_IL_012f:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto end_IL_01f3;
																										continue;
																										end_IL_0196:
																										break;
																										IL_0196:;
																									}
																									break;
																									IL_01a6:;
																								}
																								break;
																							}
																							goto IL_0285;
																							IL_0285:
																							if (1 <= b)
																							{
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_021e;
																					IL_0272:
																					num5--;
																					goto end_IL_01f3;
																					IL_021e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																					goto IL_025e;
																					IL_025e:
																					array[num5 - 2] = 0;
																					goto IL_0272;
																				}
																				break;
																			}
																			goto IL_0298;
																			IL_030e:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_01f3;
																			IL_0298:
																			if (4 >= b)
																			{
																				goto IL_02a3;
																			}
																			goto IL_02ef;
																			IL_02a3:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_02ae;
																			IL_02ae:
																			((_003CDelayedDestroy_003Ed__1)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																			goto IL_02dc;
																			IL_02dc:
																			num5 -= 2;
																			goto end_IL_01f3;
																			IL_02ef:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_02fa;
																			IL_02fa:
																			if (5 > b)
																			{
																				break;
																			}
																			num = 37;
																			goto IL_030e;
																		}
																		break;
																		IL_01e3:;
																	}
																}
																array2[num5] = array4[*(int*)(ptr2 + num3)];
																goto IL_033f;
																IL_035b:
																ptr2 += 8;
																num = 60;
																break;
																IL_034d:
																num5++;
																goto IL_035b;
																IL_033f:
																array[num5] = 5;
																goto IL_034d;
																continue;
																end_IL_01f3:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_0372:
													break;
												}
												continue;
												end_IL_0385:
												break;
											}
											continue;
											end_IL_038f:
											break;
										}
										continue;
										end_IL_039a:
										break;
									}
									continue;
									end_IL_03b3:
									break;
								}
								continue;
								end_IL_03cc:
								break;
							}
							continue;
							end_IL_03dc:
							break;
						}
						continue;
						end_IL_03ec:
						break;
					}
					continue;
					end_IL_03fc:
					break;
				}
			}
		}

		private unsafe bool MoveNext()
		{
			int num = 120;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							num = 94;
							while (true)
							{
								int[] array3 = new int[1];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										object[] array5 = new object[2];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref wCodesetAsyncResult.CustomAttributeTypegetSectionName);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_030c:
																		if (b >= 1)
																		{
																			while (b <= 16)
																			{
																				while (true)
																				{
																					IL_02ec:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_02dc:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_02cf:
																									if (4 < b)
																									{
																										while (true)
																										{
																											IL_02bf:
																											if (6 < b)
																											{
																												while (7 >= b)
																												{
																													while (7 <= b)
																													{
																														num = 155;
																														while (true)
																														{
																															if (num != 155)
																															{
																																if (num != 1136)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 52:
																																	goto IL_029c;
																																case 92:
																																	goto IL_02af;
																																case 130:
																																	goto IL_02bf;
																																case 74:
																																	goto IL_02cf;
																																case 78:
																																	goto IL_02dc;
																																case 100:
																																	goto IL_02ec;
																																case 128:
																																	goto IL_02fc;
																																case 107:
																																	goto IL_030c;
																																case 47:
																																	goto end_IL_030c;
																																case 13:
																																case 63:
																																	goto end_IL_031c;
																																case 43:
																																	goto IL_0337;
																																case 34:
																																	goto IL_0342;
																																case 49:
																																	goto IL_034d;
																																case 66:
																																	goto IL_0360;
																																case 95:
																																	goto IL_036e;
																																case 29:
																																case 44:
																																	goto IL_037c;
																																case 30:
																																	goto IL_03a5;
																																case 61:
																																case 98:
																																	goto IL_03b8;
																																case 40:
																																	goto IL_03f0;
																																case 69:
																																	goto IL_0404;
																																case 104:
																																	goto IL_0417;
																																case 4:
																																	goto IL_0425;
																																case 36:
																																case 124:
																																	goto IL_0441;
																																case 110:
																																	goto IL_045a;
																																case 106:
																																	goto IL_0468;
																																case 12:
																																	goto IL_0476;
																																case 137:
																																	goto end_IL_0289;
																																case 138:
																																	goto IL_049c;
																																case 112:
																																	goto IL_04a7;
																																case 39:
																																	goto IL_04b5;
																																case 57:
																																case 134:
																																	goto IL_04c3;
																																case 22:
																																case 114:
																																	goto IL_04e6;
																																case 11:
																																	goto IL_04fd;
																																case 1:
																																case 139:
																																	goto IL_0522;
																																case 90:
																																	goto IL_0560;
																																case 7:
																																	goto IL_0574;
																																case 141:
																																	goto IL_0587;
																																case 122:
																																	goto IL_0591;
																																case 97:
																																	goto IL_05a8;
																																case 144:
																																	goto IL_05bb;
																																case 59:
																																	goto IL_05c9;
																																case 68:
																																	goto IL_05dc;
																																case 133:
																																	goto IL_062e;
																																case 37:
																																	goto IL_0641;
																																case 0:
																																	goto IL_064f;
																																case 8:
																																case 123:
																																	goto IL_065a;
																																case 146:
																																	goto IL_0674;
																																case 96:
																																	goto IL_0682;
																																case 73:
																																	goto IL_0690;
																																case 58:
																																	goto IL_06a3;
																																case 3:
																																	goto IL_06b1;
																																case 72:
																																case 86:
																																	goto IL_06bc;
																																case 19:
																																	goto IL_06d8;
																																case 15:
																																	goto IL_06e6;
																																case 23:
																																case 82:
																																	goto IL_06f4;
																																case 60:
																																	goto IL_0756;
																																case 9:
																																	goto IL_0769;
																																case 56:
																																	goto IL_0777;
																																case 93:
																																case 109:
																																	goto IL_0785;
																																case 80:
																																	goto IL_07b3;
																																case 115:
																																	goto IL_07c6;
																																case 31:
																																	goto IL_07dd;
																																case 21:
																																case 135:
																																	goto IL_07e8;
																																case 32:
																																	goto IL_0815;
																																case 136:
																																	goto IL_0828;
																																case 38:
																																	goto IL_083f;
																																case 2:
																																case 70:
																																	goto IL_084d;
																																case 89:
																																	goto IL_0861;
																																case 41:
																																	goto IL_089a;
																																case 140:
																																	goto IL_08ad;
																																case 54:
																																	goto IL_08b8;
																																case 51:
																																case 88:
																																	goto IL_08c6;
																																case 26:
																																	goto IL_08d4;
																																case 121:
																																	goto IL_08ec;
																																case 85:
																																	goto IL_08fa;
																																case 64:
																																	goto IL_0916;
																																case 101:
																																	goto IL_0921;
																																case 48:
																																case 91:
																																	goto IL_092c;
																																case 67:
																																	goto IL_0955;
																																case 83:
																																	goto IL_0963;
																																case 18:
																																case 20:
																																case 25:
																																case 27:
																																case 28:
																																case 35:
																																case 55:
																																case 62:
																																case 65:
																																case 71:
																																case 79:
																																case 81:
																																case 87:
																																case 111:
																																case 126:
																																case 129:
																																case 142:
																																case 143:
																																case 148:
																																	goto end_IL_029c;
																																case 77:
																																	goto IL_098b;
																																case 132:
																																	goto IL_09a2;
																																case 10:
																																	goto IL_09b0;
																																case 5:
																																case 16:
																																case 24:
																																case 33:
																																case 46:
																																case 50:
																																case 53:
																																case 76:
																																case 99:
																																case 102:
																																case 103:
																																case 113:
																																case 116:
																																case 117:
																																case 118:
																																case 127:
																																case 145:
																																case 147:
																																	goto end_IL_032c;
																																case 105:
																																	goto end_IL_09be;
																																case 84:
																																	goto end_IL_09d1;
																																case 45:
																																	goto end_IL_09db;
																																case 108:
																																	goto end_IL_09e6;
																																case 125:
																																	goto end_IL_09f6;
																																case 94:
																																case 131:
																																	goto end_IL_0a06;
																																case 17:
																																	goto end_IL_0a16;
																																case 14:
																																case 42:
																																	goto end_IL_0a26;
																																case 119:
																																	goto end_IL_0a3f;
																																case 120:
																																	goto end_IL_0a4f;
																																case 6:
																																case 75:
																																	goto IL_0a6a;
																																}
																																continue;
																															}
																															goto IL_05dc;
																															IL_05dc:
																															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															goto IL_062e;
																															IL_062e:
																															num5--;
																															goto end_IL_032c;
																															continue;
																															end_IL_0289:
																															break;
																														}
																														goto IL_0489;
																														continue;
																														end_IL_029c:
																														break;
																														IL_029c:;
																													}
																													break;
																													IL_02af:;
																												}
																												break;
																											}
																											goto IL_049c;
																											IL_05a8:
																											ptr2 += 8;
																											goto end_IL_032c;
																											IL_049c:
																											if (6 > b)
																											{
																												goto IL_04a7;
																											}
																											goto IL_04e6;
																											IL_04a7:
																											if (5 < b)
																											{
																												break;
																											}
																											goto IL_04b5;
																											IL_04b5:
																											if (5 > b)
																											{
																												break;
																											}
																											goto IL_04c3;
																											IL_04c3:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_05bb;
																											IL_05bb:
																											ptr2 += 8;
																											goto IL_05c9;
																											IL_05c9:
																											num5--;
																											goto end_IL_032c;
																											IL_04e6:
																											array[num5] = 0;
																											num = 11;
																											goto IL_04fd;
																											IL_04fd:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0587;
																											IL_0587:
																											array2[num5] = null;
																											goto IL_0591;
																											IL_0591:
																											num5++;
																											num = 97;
																											goto IL_05a8;
																										}
																										break;
																									}
																									goto IL_0337;
																									IL_03f0:
																									array[num5 - 1] = 5;
																									goto IL_0404;
																									IL_0337:
																									if (4 > b)
																									{
																										goto IL_0342;
																									}
																									goto IL_03b8;
																									IL_0342:
																									if (2 >= b)
																									{
																										goto IL_034d;
																									}
																									goto IL_0360;
																									IL_034d:
																									if (2 > b)
																									{
																										goto IL_0417;
																									}
																									goto IL_0522;
																									IL_0522:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CDelayedDestroy_003Ed__1, int>)CngSignatureIDUnmarshal[*(int*)(ptr2 + num3)])((_003CDelayedDestroy_003Ed__1)array2[num5 - 1]);
																									goto IL_0560;
																									IL_0560:
																									array[num5 - 1] = 0;
																									goto IL_0574;
																									IL_0574:
																									ptr2 += 8;
																									goto end_IL_032c;
																									IL_0417:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_0425;
																									IL_0425:
																									if (1 <= b)
																									{
																										num = 129;
																									}
																									break;
																									IL_0404:
																									ptr2 += 8;
																									goto end_IL_032c;
																									IL_0360:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_036e;
																									IL_036e:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_037c;
																									IL_037c:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03a5;
																									IL_03a5:
																									ptr2 += 8;
																									goto IL_0489;
																									IL_0489:
																									num5--;
																									goto end_IL_032c;
																									IL_03b8:
																									array2[num5 - 1] = ((delegate*<_003CDelayedDestroy_003Ed__1, Class137>)CngSignatureIDUnmarshal[*(int*)(ptr2 + num3)])((_003CDelayedDestroy_003Ed__1)array2[num5 - 1]);
																									goto IL_03f0;
																								}
																								break;
																							}
																							goto IL_0441;
																							IL_0476:
																							ptr2 += 8;
																							goto end_IL_032c;
																							IL_0441:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_045a;
																							IL_045a:
																							array[num5] = 0;
																							goto IL_0468;
																							IL_0468:
																							num5++;
																							goto IL_0476;
																						}
																						break;
																					}
																					goto IL_0641;
																					IL_092c:
																					((delegate*<UnityEngine.Object, void>)CngSignatureIDUnmarshal[*(int*)(ptr2 + num3)])((Class137)array2[num5 - 1]);
																					goto IL_0955;
																					IL_0641:
																					if (12 >= b)
																					{
																						goto IL_064f;
																					}
																					goto IL_07c6;
																					IL_064f:
																					if (12 <= b)
																					{
																						goto IL_065a;
																					}
																					goto IL_06a3;
																					IL_065a:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																					goto IL_0674;
																					IL_0674:
																					array[num5] = 3;
																					goto IL_0682;
																					IL_0682:
																					num5++;
																					goto IL_0690;
																					IL_0690:
																					ptr2 += 8;
																					goto end_IL_032c;
																					IL_06a3:
																					if (10 >= b)
																					{
																						goto IL_06b1;
																					}
																					goto IL_0769;
																					IL_06b1:
																					if (10 <= b)
																					{
																						goto IL_06bc;
																					}
																					goto IL_06d8;
																					IL_06bc:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_032c;
																					IL_06d8:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_06e6;
																					IL_06e6:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_06f4;
																					IL_06f4:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0756;
																					IL_0756:
																					num5 -= 2;
																					goto end_IL_032c;
																					IL_0769:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0777;
																					IL_0777:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0785;
																					IL_0785:
																					((_003CDelayedDestroy_003Ed__1)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_07b3;
																					IL_07b3:
																					num5 -= 2;
																					goto end_IL_032c;
																					IL_07c6:
																					if (14 >= b)
																					{
																						num = 31;
																						goto IL_07dd;
																					}
																					goto IL_08ad;
																					IL_0955:
																					num5--;
																					goto IL_0963;
																					IL_07dd:
																					if (14 <= b)
																					{
																						goto IL_07e8;
																					}
																					goto IL_0828;
																					IL_07e8:
																					((_003CDelayedDestroy_003Ed__1)array2[num5 - 2]).waitForSeconds_0 = (WaitForSeconds)array2[num5 - 1];
																					goto IL_0815;
																					IL_0815:
																					num5 -= 2;
																					goto end_IL_032c;
																					IL_0828:
																					if (13 < b)
																					{
																						break;
																					}
																					num = 38;
																					goto IL_083f;
																					IL_0963:
																					ptr2 += 8;
																					goto end_IL_032c;
																					IL_083f:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_084d;
																					IL_084d:
																					array[num5 - 1] = 5;
																					goto IL_0861;
																					IL_0861:
																					array2[num5 - 1] = ((delegate*<float, WaitForSeconds>)CngSignatureIDUnmarshal[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])));
																					goto IL_089a;
																					IL_089a:
																					ptr2 += 8;
																					goto end_IL_032c;
																					IL_08ad:
																					if (15 >= b)
																					{
																						goto IL_08b8;
																					}
																					goto IL_0916;
																					IL_08b8:
																					if (15 > b)
																					{
																						break;
																					}
																					goto IL_08c6;
																					IL_08c6:
																					array[num5] = 5;
																					goto IL_08d4;
																					IL_08d4:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_08ec;
																					IL_08ec:
																					num5++;
																					goto IL_08fa;
																					IL_08fa:
																					ptr2 += 8;
																					num = 117;
																					goto end_IL_032c;
																					IL_0916:
																					if (16 < b)
																					{
																						break;
																					}
																					goto IL_0921;
																					IL_0921:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_092c;
																				}
																				break;
																				IL_02fc:;
																			}
																		}
																		array2[num5] = array5[*(int*)(ptr2 + num3)];
																		goto IL_098b;
																		IL_09b0:
																		ptr2 += 8;
																		goto end_IL_032c;
																		IL_09a2:
																		num5++;
																		goto IL_09b0;
																		IL_098b:
																		array[num5] = 5;
																		num = 132;
																		goto IL_09a2;
																		continue;
																		end_IL_030c:
																		break;
																	}
																	continue;
																	end_IL_031c:
																	break;
																}
																continue;
																end_IL_032c:
																break;
															}
															continue;
														}
														goto IL_0a6a;
														IL_0a6a:
														return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
														continue;
														end_IL_09be:
														break;
													}
													continue;
													end_IL_09d1:
													break;
												}
												continue;
												end_IL_09db:
												break;
											}
											continue;
											end_IL_09e6:
											break;
										}
										continue;
										end_IL_09f6:
										break;
									}
									continue;
									end_IL_0a06:
									break;
								}
								continue;
								end_IL_0a16:
								break;
							}
							continue;
							end_IL_0a26:
							break;
						}
						continue;
						end_IL_0a3f:
						break;
					}
					continue;
					end_IL_0a4f:
					break;
				}
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		unsafe void IEnumerator.Reset()
		{
			int num = 18;
			int num4 = default(int);
			byte b = default(byte);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[1];
						while (true)
						{
							object[] array2 = new object[1];
							while (true)
							{
								byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getConcurrentSchedulerTokenRestrictedDeviceGroups.IBindableIterableOrIIterableMobilePhone);
								while (true)
								{
									byte* ptr2 = ptr;
									while (true)
									{
										if (num4 == 1)
										{
											return;
										}
										while (true)
										{
											num = 40;
											while (true)
											{
												if (num != 40)
												{
													if (num != 1021)
													{
														goto IL_01d0;
													}
													switch (num)
													{
													case 24:
														goto end_IL_00af;
													case 23:
														goto IL_00d3;
													case 32:
														goto IL_00e1;
													case 29:
														goto IL_00ec;
													case 33:
														goto IL_00f7;
													case 4:
														goto IL_0102;
													case 11:
														goto IL_010f;
													case 14:
														goto IL_011a;
													case 9:
													case 13:
													case 20:
													case 22:
													case 26:
													case 28:
													case 30:
														goto IL_0128;
													case 3:
														goto IL_0136;
													case 8:
														goto IL_0154;
													case 2:
														goto IL_0162;
													case 6:
													case 21:
													case 31:
														goto end_IL_00bf;
													case 27:
														goto end_IL_0170;
													case 1:
													case 15:
													case 25:
														goto end_IL_0180;
													case 10:
														goto end_IL_018a;
													case 5:
													case 16:
														goto end_IL_0195;
													case 17:
														goto end_IL_01a5;
													case 18:
														goto end_IL_01b5;
													case 0:
													case 19:
														goto IL_01d0;
													case 7:
													case 12:
														return;
													}
													continue;
												}
												b = *ptr2;
												goto IL_00d3;
												IL_0136:
												array2[num5] = ((delegate*<NotSupportedException>)SortVersionVTBLOB[*(int*)(ptr2 + num3)])();
												goto IL_0154;
												IL_0162:
												ptr2 += 8;
												goto end_IL_00bf;
												IL_0154:
												num5++;
												goto IL_0162;
												IL_00d3:
												ptr2++;
												goto IL_00e1;
												IL_00e1:
												if (b >= 1)
												{
													goto IL_00ec;
												}
												goto IL_0128;
												IL_00ec:
												if (b <= 2)
												{
													goto IL_00f7;
												}
												goto IL_0128;
												IL_00f7:
												if (1 >= b)
												{
													goto IL_0102;
												}
												goto IL_010f;
												IL_0102:
												if (1 > b)
												{
												}
												goto IL_0128;
												IL_010f:
												if (2 >= b)
												{
													goto IL_011a;
												}
												goto IL_0128;
												IL_011a:
												if (2 > b)
												{
													goto IL_0128;
												}
												goto IL_01d0;
												IL_01d0:
												throw (Exception)array2[num5 - 1];
												IL_0128:
												array[num5] = 5;
												goto IL_0136;
												continue;
												end_IL_00af:
												break;
											}
											continue;
											end_IL_00bf:
											break;
										}
										continue;
										end_IL_0170:
										break;
									}
									continue;
									end_IL_0180:
									break;
								}
								continue;
								end_IL_018a:
								break;
							}
							continue;
							end_IL_0195:
							break;
						}
						continue;
						end_IL_01a5:
						break;
					}
					continue;
					end_IL_01b5:
					break;
				}
			}
		}

		static _003CDelayedDestroy_003Ed__1()
		{
			int num = 5;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					while (true)
					{
						num = 13;
						while (true)
						{
							if (num != 13)
							{
								if (num != 994)
								{
									break;
								}
								switch (num)
								{
								case 0:
								case 2:
									goto end_IL_003d;
								case 4:
									goto end_IL_004a;
								case 5:
									goto end_IL_0059;
								case 1:
									return;
								case 3:
									return;
								case 6:
									return;
								}
								continue;
							}
							return;
							continue;
							end_IL_003d:
							break;
						}
						continue;
						end_IL_004a:
						break;
					}
					continue;
					end_IL_0059:
					break;
				}
			}
		}
	}

	private static int int_0;

	private static double double_0;

	private static float float_0;

	private static bool bool_0;

	private static IntPtr[] GetSrcItfTypeLazy;

	private static IntPtr[] RtFieldInfoTimeZoneKeyName;

	private static IntPtr[] ApplicationUrlIBindableIterable;

	private static IntPtr[] DefineConstructorRemotePropertyHolderAttribute;

	private static IntPtr[] SecurityRegistryPermissionRemoveAll;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001e, IL_0523, IL_0536, IL_054f, IL_0564, IL_0592, IL_05a2, IL_05b2, IL_05c2, IL_05d2, IL_05e2, IL_05f2, IL_0602, IL_0612, IL_0622, IL_063b, IL_0646, IL_0654, IL_0662, IL_0670, IL_067b, IL_068e, IL_069c, IL_06a7, IL_06b5, IL_06f5, IL_0709, IL_071c, IL_072a, IL_0738, IL_0752, IL_0765, IL_07aa, IL_07b8, IL_07cb, IL_07d6, IL_07e1, IL_07ec, IL_07ff, IL_0812, IL_081b, IL_082e, IL_0839, IL_0847, IL_0855, IL_086d, IL_087b, IL_088e, IL_08a7, IL_08bb, IL_0907, IL_0915, IL_0928, IL_0933, IL_0941, IL_094f, IL_0962, IL_0970, IL_097b, IL_0989, IL_0997, IL_09bb, IL_09c9, IL_09d7, IL_09ea, IL_09fd, IL_0a08, IL_0a33, IL_0a4c, IL_0a5a, IL_0a68, IL_0a92, IL_0aab, IL_0af0, IL_0b0e, IL_0b25, IL_0b3c, IL_0b4f, IL_0b5d, IL_0b70, IL_0b84, IL_0b97, IL_0ba5, IL_0bc1, IL_0bf9, IL_0c0c, IL_0c4c, IL_0c60, IL_0c73, IL_0c86, IL_0c94, IL_0ca7, IL_0ce5, IL_0cf8, IL_0d0c, IL_0d44, IL_0d57, IL_0d65, IL_0d73, IL_0d9c, IL_0daa, IL_0dbd, IL_0dc8, IL_0dd3, IL_0de1, IL_0e0a, IL_0e18, IL_0e2b, IL_0e39, IL_0e47, IL_0e5b, IL_0eb0, IL_0ebe, IL_0ed1, IL_0f11, IL_0f25, IL_0f41, IL_0f5a, IL_0f6f, IL_0f82, IL_0f90, IL_0f9b, IL_0fd4, IL_0fe8, IL_0ffb, IL_1009, IL_101c, IL_102f, IL_1042, IL_1050, IL_105e, IL_106c, IL_107a, IL_1092, IL_10b0, IL_10d4, IL_10ec, IL_1108, IL_1116, IL_1121, IL_114a, IL_1163, IL_1171, IL_117f, IL_119d, IL_11ab, IL_11c7, IL_11d5, IL_11de, IL_11ec, IL_11f7, IL_1259, IL_126c, IL_127a, IL_1288, IL_12c8, IL_12dc, IL_12ef, IL_12fd, IL_130b, IL_1319, IL_1336, IL_1385, IL_138f, IL_13bc, IL_13d0, IL_13de, IL_13fa, IL_1411, IL_1429, IL_1437, IL_1447, IL_1460, IL_1477, IL_1485, IL_1493, IL_14a6, IL_14b9, IL_14c4, IL_14dd, IL_14ed, IL_14fd, IL_150d, IL_151d, IL_152d, IL_153d, IL_154d are reachable both inside and outside the pinned region starting at IL_1562. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 248;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef54 = default(int);
			ref int reference = ref __rxRef54;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_154d:
					num2 = 1;
					while (true)
					{
						IL_153d:
						num3 = num2 * 4;
						while (true)
						{
							IL_152d:
							array2 = new byte[4];
							while (true)
							{
								IL_151d:
								array3 = new object[4];
								while (true)
								{
									IL_150d:
									array4 = new int[4];
									while (true)
									{
										IL_14fd:
										array5 = new int[6];
										while (true)
										{
											IL_14ed:
											array6 = new long[4];
											while (true)
											{
												IL_14dd:
												array7 = new object[16];
												while (true)
												{
													IL_14c4:
													array7[0] = this;
													num = 246;
													while (true)
													{
														IL_14b9:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ApplicationExceptionsetNumberNegativePattern.MapAssemblyTokenSandBoxInert);
														while (true)
														{
															IL_14a6:
															ptr2 = ptr;
															num = 37;
															while (true)
															{
																IL_1493:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_063b:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0622:
																		ptr2++;
																		num = 120;
																		while (true)
																		{
																			IL_0612:
																			if (b >= 1)
																			{
																				while (b <= 32)
																				{
																					while (true)
																					{
																						IL_05f2:
																						if (16 >= b)
																						{
																							while (true)
																							{
																								IL_05e2:
																								if (16 > b)
																								{
																									while (true)
																									{
																										IL_05d2:
																										if (8 >= b)
																										{
																											while (true)
																											{
																												IL_05c2:
																												if (8 > b)
																												{
																													while (true)
																													{
																														IL_05b2:
																														if (4 >= b)
																														{
																															while (true)
																															{
																																IL_05a2:
																																if (4 <= b)
																																{
																																	while (true)
																																	{
																																		IL_0592:
																																		array2[num5] = 0;
																																		while (true)
																																		{
																																			IL_0564:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																																			num = 170;
																																			while (true)
																																			{
																																				IL_054f:
																																				array3[num5] = null;
																																				num = 6;
																																				while (true)
																																				{
																																					IL_0536:
																																					num5++;
																																					num = 325;
																																					while (true)
																																					{
																																						if (num != 325)
																																						{
																																							if (num != 1306)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 248:
																																								break;
																																							default:
																																								continue;
																																							case 6:
																																								goto IL_0536;
																																							case 170:
																																								goto IL_054f;
																																							case 63:
																																								goto IL_0564;
																																							case 111:
																																							case 113:
																																								goto IL_0592;
																																							case 5:
																																								goto IL_05a2;
																																							case 245:
																																							case 260:
																																								goto IL_05b2;
																																							case 78:
																																								goto IL_05c2;
																																							case 48:
																																							case 163:
																																								goto IL_05d2;
																																							case 275:
																																								goto IL_05e2;
																																							case 95:
																																								goto IL_05f2;
																																							case 3:
																																								goto IL_0602;
																																							case 120:
																																								goto IL_0612;
																																							case 76:
																																								goto IL_0622;
																																							case 178:
																																							case 297:
																																								goto IL_063b;
																																							case 68:
																																								goto IL_0646;
																																							case 72:
																																								goto IL_0654;
																																							case 29:
																																							case 73:
																																								goto IL_0670;
																																							case 20:
																																								goto IL_067b;
																																							case 84:
																																								goto IL_068e;
																																							case 117:
																																								goto IL_069c;
																																							case 50:
																																							case 115:
																																								goto IL_06b5;
																																							case 103:
																																								goto IL_06f5;
																																							case 8:
																																								goto IL_0709;
																																							case 22:
																																							case 121:
																																								goto IL_071c;
																																							case 43:
																																								goto IL_072a;
																																							case 77:
																																							case 137:
																																								goto IL_0738;
																																							case 69:
																																								goto IL_0752;
																																							case 127:
																																							case 140:
																																								goto IL_0765;
																																							case 205:
																																							case 206:
																																								goto IL_07aa;
																																							case 171:
																																								goto IL_07b8;
																																							case 221:
																																								goto IL_07cb;
																																							case 36:
																																								goto IL_07d6;
																																							case 38:
																																								goto IL_07e1;
																																							case 169:
																																								goto IL_07ec;
																																							case 31:
																																								goto IL_07ff;
																																							case 60:
																																								goto IL_081b;
																																							case 233:
																																								goto IL_082e;
																																							case 56:
																																							case 149:
																																								goto IL_0839;
																																							case 17:
																																								goto IL_0847;
																																							case 55:
																																							case 124:
																																								goto IL_0855;
																																							case 195:
																																								goto IL_086d;
																																							case 131:
																																								goto IL_087b;
																																							case 94:
																																							case 96:
																																								goto IL_088e;
																																							case 189:
																																							case 241:
																																								goto IL_08a7;
																																							case 128:
																																								goto IL_08bb;
																																							case 74:
																																								goto IL_0907;
																																							case 98:
																																								goto IL_0915;
																																							case 249:
																																								goto IL_0928;
																																							case 193:
																																							case 223:
																																								goto IL_0933;
																																							case 177:
																																								goto IL_0941;
																																							case 64:
																																								goto IL_094f;
																																							case 66:
																																								goto IL_0962;
																																							case 93:
																																								goto IL_0970;
																																							case 86:
																																							case 237:
																																								goto IL_097b;
																																							case 104:
																																								goto IL_0989;
																																							case 183:
																																							case 242:
																																								goto IL_0997;
																																							case 135:
																																								goto IL_09bb;
																																							case 97:
																																								goto IL_09c9;
																																							case 108:
																																								goto IL_09d7;
																																							case 71:
																																								goto IL_09ea;
																																							case 256:
																																								goto IL_09fd;
																																							case 57:
																																							case 157:
																																								goto IL_0a08;
																																							case 118:
																																								goto IL_0a33;
																																							case 231:
																																								goto IL_0a4c;
																																							case 125:
																																								goto IL_0a5a;
																																							case 54:
																																							case 216:
																																								goto IL_0a68;
																																							case 209:
																																								goto IL_0a92;
																																							case 201:
																																							case 268:
																																								goto IL_0aab;
																																							case 236:
																																							case 269:
																																								goto IL_0af0;
																																							case 165:
																																								goto IL_0b0e;
																																							case 190:
																																								goto IL_0b25;
																																							case 18:
																																								goto IL_0b3c;
																																							case 271:
																																							case 274:
																																								goto IL_0b4f;
																																							case 161:
																																								goto IL_0b5d;
																																							case 276:
																																								goto IL_0b70;
																																							case 267:
																																								goto IL_0b84;
																																							case 277:
																																								goto IL_0b97;
																																							case 34:
																																							case 129:
																																								goto IL_0ba5;
																																							case 278:
																																								goto IL_0bc1;
																																							case 119:
																																								goto IL_0bf9;
																																							case 159:
																																							case 282:
																																								goto IL_0c0c;
																																							case 182:
																																								goto IL_0c4c;
																																							case 132:
																																								goto IL_0c60;
																																							case 287:
																																								goto IL_0c73;
																																							case 202:
																																							case 291:
																																								goto IL_0c86;
																																							case 181:
																																								goto IL_0c94;
																																							case 270:
																																							case 292:
																																								goto IL_0ca7;
																																							case 1:
																																								goto IL_0ce5;
																																							case 162:
																																							case 296:
																																								goto IL_0cf8;
																																							case 39:
																																								goto IL_0d0c;
																																							case 136:
																																								goto IL_0d44;
																																							case 114:
																																							case 299:
																																								goto IL_0d57;
																																							case 30:
																																								goto IL_0d65;
																																							case 35:
																																							case 235:
																																								goto IL_0d73;
																																							case 19:
																																								goto IL_0d9c;
																																							case 4:
																																								goto IL_0daa;
																																							case 300:
																																								goto IL_0dbd;
																																							case 145:
																																							case 168:
																																								goto IL_0dc8;
																																							case 116:
																																								goto IL_0dd3;
																																							case 27:
																																							case 273:
																																								goto IL_0de1;
																																							case 238:
																																								goto IL_0e0a;
																																							case 281:
																																								goto IL_0e18;
																																							case 227:
																																								goto IL_0e39;
																																							case 62:
																																							case 204:
																																								goto IL_0e47;
																																							case 234:
																																								goto IL_0e5b;
																																							case 196:
																																								goto IL_0eb0;
																																							case 184:
																																								goto IL_0ebe;
																																							case 0:
																																							case 307:
																																								goto IL_0ed1;
																																							case 203:
																																								goto IL_0f11;
																																							case 83:
																																								goto IL_0f25;
																																							case 308:
																																								goto IL_0f41;
																																							case 239:
																																							case 310:
																																								goto IL_0f5a;
																																							case 212:
																																								goto IL_0f6f;
																																							case 7:
																																							case 315:
																																								goto IL_0f82;
																																							case 92:
																																								goto IL_0f90;
																																							case 21:
																																							case 263:
																																								goto IL_0f9b;
																																							case 40:
																																								goto IL_0fd4;
																																							case 130:
																																								goto IL_0fe8;
																																							case 316:
																																								goto IL_1009;
																																							case 151:
																																							case 251:
																																								goto IL_102f;
																																							case 49:
																																								goto IL_1042;
																																							case 213:
																																							case 222:
																																								goto IL_1050;
																																							case 13:
																																							case 192:
																																								goto IL_105e;
																																							case 42:
																																								goto IL_106c;
																																							case 194:
																																							case 318:
																																								goto IL_107a;
																																							case 123:
																																								goto IL_1092;
																																							case 301:
																																								goto IL_10b0;
																																							case 144:
																																								goto IL_10d4;
																																							case 253:
																																								goto IL_10ec;
																																							case 207:
																																								goto IL_1116;
																																							case 12:
																																							case 102:
																																								goto IL_1121;
																																							case 138:
																																								goto IL_114a;
																																							case 152:
																																								goto IL_1163;
																																							case 148:
																																								goto IL_1171;
																																							case 280:
																																							case 317:
																																								goto IL_117f;
																																							case 279:
																																								goto IL_119d;
																																							case 306:
																																								goto IL_11ab;
																																							case 230:
																																								goto IL_11c7;
																																							case 302:
																																							case 305:
																																								goto IL_11de;
																																							case 53:
																																								goto IL_11ec;
																																							case 164:
																																							case 259:
																																								goto IL_11f7;
																																							case 101:
																																								goto IL_1259;
																																							case 158:
																																								goto IL_126c;
																																							case 293:
																																								goto IL_127a;
																																							case 191:
																																							case 314:
																																								goto IL_1288;
																																							case 59:
																																								goto IL_12c8;
																																							case 126:
																																								goto IL_12dc;
																																							case 23:
																																								goto IL_12ef;
																																							case 133:
																																								goto IL_12fd;
																																							case 174:
																																							case 252:
																																								goto IL_1319;
																																							case 146:
																																								goto IL_13d0;
																																							case 229:
																																								goto IL_13de;
																																							case 112:
																																							case 141:
																																								goto IL_13fa;
																																							case 26:
																																								goto IL_1411;
																																							case 109:
																																								goto IL_1429;
																																							case 134:
																																								goto IL_1437;
																																							case 10:
																																							case 14:
																																							case 15:
																																							case 16:
																																							case 25:
																																							case 28:
																																							case 32:
																																							case 41:
																																							case 45:
																																							case 46:
																																							case 51:
																																							case 58:
																																							case 61:
																																							case 70:
																																							case 75:
																																							case 79:
																																							case 80:
																																							case 85:
																																							case 87:
																																							case 88:
																																							case 91:
																																							case 99:
																																							case 105:
																																							case 110:
																																							case 122:
																																							case 143:
																																							case 147:
																																							case 150:
																																							case 154:
																																							case 155:
																																							case 160:
																																							case 166:
																																							case 173:
																																							case 175:
																																							case 180:
																																							case 185:
																																							case 187:
																																							case 188:
																																							case 197:
																																							case 199:
																																							case 200:
																																							case 208:
																																							case 210:
																																							case 211:
																																							case 214:
																																							case 217:
																																							case 219:
																																							case 224:
																																							case 228:
																																							case 244:
																																							case 250:
																																							case 255:
																																							case 257:
																																							case 258:
																																							case 261:
																																							case 262:
																																							case 264:
																																							case 265:
																																							case 272:
																																							case 283:
																																							case 288:
																																							case 303:
																																							case 312:
																																								goto end_IL_0523;
																																							case 313:
																																								goto IL_1460;
																																							case 285:
																																								goto IL_1477;
																																							case 295:
																																								goto IL_1485;
																																							case 2:
																																							case 9:
																																							case 11:
																																							case 24:
																																							case 33:
																																							case 37:
																																							case 44:
																																							case 52:
																																							case 82:
																																							case 89:
																																							case 90:
																																							case 139:
																																							case 142:
																																							case 153:
																																							case 156:
																																							case 167:
																																							case 176:
																																							case 179:
																																							case 186:
																																							case 198:
																																							case 218:
																																							case 220:
																																							case 225:
																																							case 226:
																																							case 232:
																																							case 240:
																																							case 243:
																																							case 254:
																																							case 266:
																																							case 284:
																																							case 289:
																																							case 290:
																																							case 294:
																																							case 304:
																																							case 311:
																																								goto IL_1493;
																																							case 81:
																																								goto IL_14a6;
																																							case 246:
																																								goto IL_14b9;
																																							case 65:
																																								goto IL_14c4;
																																							case 309:
																																								goto IL_14dd;
																																							case 47:
																																								goto IL_14ed;
																																							case 215:
																																								goto IL_14fd;
																																							case 67:
																																								goto IL_150d;
																																							case 298:
																																								goto IL_151d;
																																							case 107:
																																							case 286:
																																								goto IL_152d;
																																							case 172:
																																								goto IL_153d;
																																							case 247:
																																								goto IL_154d;
																																							case 100:
																																							case 106:
																																								return;
																																							}
																																							goto end_IL_0612;
																																						}
																																						ptr2 += 8;
																																						goto IL_1493;
																																						continue;
																																						end_IL_0523:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0646;
																																IL_0d9c:
																																ptr2 += 8;
																																goto IL_0daa;
																																IL_0646:
																																if (2 >= b)
																																{
																																	goto IL_0654;
																																}
																																goto IL_0d57;
																																IL_0654:
																																if (2 > b)
																																{
																																	num = 206;
																																	goto IL_07aa;
																																}
																																goto IL_0c0c;
																																IL_0daa:
																																num5--;
																																goto IL_1493;
																																IL_07aa:
																																if (1 < b)
																																{
																																	break;
																																}
																																goto IL_07b8;
																																IL_07b8:
																																if (1 <= b)
																																{
																																}
																																break;
																																IL_0c0c:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																goto IL_0c4c;
																																IL_0c4c:
																																array2[num5 - 2] = 0;
																																goto IL_0c60;
																																IL_0c60:
																																num5--;
																																goto IL_1493;
																																IL_0d57:
																																if (3 < b)
																																{
																																	break;
																																}
																																goto IL_0d65;
																																IL_0d65:
																																if (3 > b)
																																{
																																	break;
																																}
																																goto IL_0d73;
																																IL_0d73:
																																reference = ref array5[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																goto IL_0d9c;
																															}
																															break;
																														}
																														goto IL_0670;
																														IL_06f5:
																														array2[num5 - 2] = 0;
																														goto IL_0709;
																														IL_0670:
																														if (6 >= b)
																														{
																															goto IL_067b;
																														}
																														goto IL_068e;
																														IL_067b:
																														if (6 <= b)
																														{
																															goto IL_0765;
																														}
																														goto IL_0c86;
																														IL_0c86:
																														if (5 < b)
																														{
																															break;
																														}
																														goto IL_0c94;
																														IL_0c94:
																														if (5 > b)
																														{
																															break;
																														}
																														goto IL_0ed1;
																														IL_0ed1:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_0f11;
																														IL_0f11:
																														array2[num5 - 2] = 0;
																														goto IL_0f25;
																														IL_0f25:
																														num5--;
																														num = 2;
																														goto IL_1493;
																														IL_0765:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_0f41;
																														IL_0f41:
																														array2[num5 - 2] = 0;
																														goto IL_1009;
																														IL_1009:
																														num5--;
																														goto IL_1493;
																														IL_068e:
																														if (7 < b)
																														{
																															break;
																														}
																														goto IL_069c;
																														IL_069c:
																														if (7 > b)
																														{
																															num = 217;
																															break;
																														}
																														goto IL_06b5;
																														IL_0709:
																														num5--;
																														goto IL_1493;
																														IL_06b5:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_06f5;
																													}
																													break;
																												}
																												goto IL_102f;
																												IL_102f:
																												num5--;
																												goto IL_1493;
																											}
																											break;
																										}
																										goto IL_1042;
																										IL_13d0:
																										array2[num5] = 5;
																										goto IL_13de;
																										IL_1042:
																										if (12 < b)
																										{
																											goto IL_1050;
																										}
																										goto IL_11c7;
																										IL_1050:
																										if (14 < b)
																										{
																											goto IL_105e;
																										}
																										goto IL_1116;
																										IL_105e:
																										if (15 < b)
																										{
																											num = 80;
																											break;
																										}
																										goto IL_106c;
																										IL_106c:
																										if (15 > b)
																										{
																											break;
																										}
																										goto IL_107a;
																										IL_107a:
																										array2[num5] = array2[num5 - 1];
																										goto IL_1092;
																										IL_1092:
																										array4[num5 - 0] = array4[num5 - 1];
																										goto IL_10b0;
																										IL_10b0:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_10d4;
																										IL_10d4:
																										array3[num5] = array3[num5 - 1];
																										goto IL_10ec;
																										IL_10ec:
																										num5++;
																										num = 186;
																										goto IL_1493;
																										IL_1319:
																										array8 = array3;
																										num6 = num5;
																										if (array == null)
																										{
																											goto IL_1328;
																										}
																										num7 = ptr2;
																										byte b2 = *num7;
																										ptr2 = num7 + 4;
																										int num8 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num8;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_13d0;
																										IL_1116:
																										if (14 <= b)
																										{
																											goto IL_1121;
																										}
																										goto IL_1163;
																										IL_1121:
																										array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																										goto IL_114a;
																										IL_114a:
																										array2[num5 - 1] = 5;
																										goto IL_1493;
																										IL_1163:
																										if (13 < b)
																										{
																											break;
																										}
																										goto IL_1171;
																										IL_1171:
																										if (13 > b)
																										{
																											break;
																										}
																										goto IL_117f;
																										IL_117f:
																										array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																										goto IL_119d;
																										IL_119d:
																										ptr2 += 8;
																										goto IL_11ab;
																										IL_11ab:
																										num5--;
																										num = 290;
																										goto IL_1493;
																										IL_11c7:
																										if (12 > b)
																										{
																											num = 302;
																											goto IL_11de;
																										}
																										goto IL_1319;
																										IL_13de:
																										num5++;
																										num = 225;
																										goto IL_1493;
																										IL_11de:
																										if (10 >= b)
																										{
																											goto IL_11ec;
																										}
																										goto IL_12ef;
																										IL_11ec:
																										if (10 <= b)
																										{
																											goto IL_11f7;
																										}
																										goto IL_126c;
																										IL_11f7:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_1259;
																										IL_1259:
																										num5 -= 2;
																										goto IL_1493;
																										IL_126c:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_127a;
																										IL_127a:
																										if (9 > b)
																										{
																											break;
																										}
																										goto IL_1288;
																										IL_1288:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_12c8;
																										IL_12c8:
																										array2[num5 - 2] = 0;
																										goto IL_12dc;
																										IL_12dc:
																										num5--;
																										goto IL_1493;
																										IL_12ef:
																										if (11 < b)
																										{
																											break;
																										}
																										goto IL_12fd;
																										IL_12fd:
																										if (11 > b)
																										{
																											num = 200;
																											break;
																										}
																										goto IL_1493;
																									}
																									break;
																								}
																								goto IL_13fa;
																								IL_1437:
																								ptr2 += 8;
																								goto IL_1493;
																								IL_13fa:
																								array2[num5] = 5;
																								num = 26;
																								goto IL_1411;
																								IL_1411:
																								array3[num5] = array7[*(int*)(ptr2 + num3)];
																								goto IL_1429;
																								IL_1429:
																								num5++;
																								goto IL_1437;
																							}
																							break;
																						}
																						goto IL_071c;
																						IL_0f9b:
																						array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_0fd4;
																						IL_071c:
																						if (24 >= b)
																						{
																							goto IL_072a;
																						}
																						goto IL_07cb;
																						IL_072a:
																						if (24 <= b)
																						{
																							goto IL_0738;
																						}
																						goto IL_0928;
																						IL_0738:
																						Class9.int_2 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0752;
																						IL_0752:
																						num5--;
																						goto IL_1493;
																						IL_0928:
																						if (20 < b)
																						{
																							goto IL_0933;
																						}
																						goto IL_0962;
																						IL_0933:
																						if (22 < b)
																						{
																							goto IL_0941;
																						}
																						goto IL_09fd;
																						IL_0941:
																						if (23 < b)
																						{
																							break;
																						}
																						goto IL_094f;
																						IL_094f:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_0aab;
																						IL_0aab:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0b70;
																						IL_0b70:
																						array2[num5 - 2] = 0;
																						goto IL_0b84;
																						IL_0b84:
																						num5--;
																						goto IL_1493;
																						IL_09fd:
																						if (22 <= b)
																						{
																							goto IL_0a08;
																						}
																						goto IL_0a4c;
																						IL_0a08:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_0a33;
																						IL_0a33:
																						array2[num5 - 1] = 0;
																						goto IL_1493;
																						IL_0a4c:
																						if (21 < b)
																						{
																							break;
																						}
																						goto IL_0a5a;
																						IL_0a5a:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_0a68;
																						IL_0a68:
																						*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
																						goto IL_0a92;
																						IL_0a92:
																						array2[num5 - 1] = 2;
																						goto IL_1493;
																						IL_0962:
																						if (20 > b)
																						{
																							goto IL_0970;
																						}
																						goto IL_0af0;
																						IL_0970:
																						if (18 < b)
																						{
																							goto IL_097b;
																						}
																						goto IL_09ea;
																						IL_097b:
																						if (19 < b)
																						{
																							break;
																						}
																						goto IL_0989;
																						IL_0989:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_0997;
																						IL_0997:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])();
																						goto IL_09bb;
																						IL_09bb:
																						array2[num5] = 0;
																						goto IL_09c9;
																						IL_09c9:
																						num5++;
																						goto IL_09d7;
																						IL_09d7:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_09ea:
																						if (18 > b)
																						{
																							goto IL_0b4f;
																						}
																						goto IL_0cf8;
																						IL_0b4f:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0b5d;
																						IL_0b5d:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0ca7;
																						IL_0ca7:
																						((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																						goto IL_0ce5;
																						IL_0ce5:
																						num5 -= 3;
																						goto IL_1493;
																						IL_0cf8:
																						array2[num5 - 1] = 5;
																						goto IL_0d0c;
																						IL_0d0c:
																						array3[num5 - 1] = ((delegate*<string[], string>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																						goto IL_0d44;
																						IL_0d44:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_0af0:
																						array3[num5] = ((delegate*<string[]>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])();
																						goto IL_0b0e;
																						IL_0b0e:
																						array2[num5] = 5;
																						num = 190;
																						goto IL_0b25;
																						IL_0b25:
																						num5++;
																						num = 18;
																						goto IL_0b3c;
																						IL_0b3c:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_07cb:
																						if (28 < b)
																						{
																							goto IL_07d6;
																						}
																						num = 60;
																						goto IL_081b;
																						IL_07d6:
																						if (30 < b)
																						{
																							goto IL_07e1;
																						}
																						goto IL_082e;
																						IL_07e1:
																						if (31 >= b)
																						{
																							goto IL_07ec;
																						}
																						goto IL_07ff;
																						IL_07ec:
																						if (31 > b)
																						{
																							break;
																						}
																						goto IL_08a7;
																						IL_08a7:
																						array2[num5 - 2] = 5;
																						goto IL_08bb;
																						IL_08bb:
																						array3[num5 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((Class137)array3[num5 - 2], (IEnumerator)array3[num5 - 1]);
																						goto IL_0907;
																						IL_0907:
																						num5--;
																						goto IL_0915;
																						IL_0915:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_07ff:
																						if (32 < b)
																						{
																							break;
																						}
																						goto IL_0b97;
																						IL_0b97:
																						if (32 > b)
																						{
																							break;
																						}
																						goto IL_0ba5;
																						IL_0ba5:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						goto IL_1493;
																						IL_082e:
																						if (30 > b)
																						{
																							goto IL_0839;
																						}
																						goto IL_088e;
																						IL_0839:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_0847;
																						IL_0847:
																						if (29 > b)
																						{
																							break;
																						}
																						goto IL_0855;
																						IL_0855:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_086d;
																						IL_086d:
																						array2[num5] = 5;
																						goto IL_087b;
																						IL_087b:
																						num5++;
																						goto IL_0c73;
																						IL_0c73:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_088e:
																						array2[num5 - 1] = 5;
																						goto IL_0bc1;
																						IL_0bc1:
																						array3[num5 - 1] = ((delegate*<Class137, IEnumerator>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((Class137)array3[num5 - 1]);
																						goto IL_0bf9;
																						IL_0bf9:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_0fd4:
																						array2[num5 - 2] = 5;
																						goto IL_0fe8;
																						IL_081b:
																						if (28 > b)
																						{
																							goto IL_0dbd;
																						}
																						goto IL_0f5a;
																						IL_0f5a:
																						((delegate*<void>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])();
																						goto IL_0f6f;
																						IL_0f6f:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_0dbd:
																						if (26 < b)
																						{
																							goto IL_0dc8;
																						}
																						goto IL_0e39;
																						IL_0dc8:
																						if (27 < b)
																						{
																							num = 70;
																							break;
																						}
																						goto IL_0dd3;
																						IL_0dd3:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_0de1;
																						IL_0de1:
																						((delegate*<string, void>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																						goto IL_0e0a;
																						IL_0e0a:
																						num5--;
																						goto IL_0e18;
																						IL_0e18:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_0fe8:
																						num5--;
																						goto IL_1493;
																						IL_0e39:
																						if (26 <= b)
																						{
																							goto IL_0e47;
																						}
																						goto IL_0f82;
																						IL_0e47:
																						array2[num5 - 2] = 5;
																						goto IL_0e5b;
																						IL_0e5b:
																						array3[num5 - 2] = ((delegate*<string, string, string>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																						num = 196;
																						goto IL_0eb0;
																						IL_0eb0:
																						num5--;
																						goto IL_0ebe;
																						IL_0ebe:
																						ptr2 += 8;
																						goto IL_1493;
																						IL_0f82:
																						if (25 < b)
																						{
																							break;
																						}
																						goto IL_0f90;
																						IL_0f90:
																						if (25 > b)
																						{
																							num = 228;
																							break;
																						}
																						goto IL_0f9b;
																					}
																					break;
																					IL_0602:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_1460;
																			IL_1485:
																			ptr2 += 8;
																			goto IL_1493;
																			IL_1477:
																			num5++;
																			goto IL_1485;
																			IL_1460:
																			array2[num5] = 0;
																			num = 285;
																			goto IL_1477;
																			continue;
																			end_IL_0612:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1328:
			while (true)
			{
				IL_1328_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_13d0_2:
						array2[num5] = 5;
						while (true)
						{
							IL_13de_2:
							num5++;
							num = 225;
							while (true)
							{
								IL_1493_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										num = 120;
										while (true)
										{
											IL_0612_2:
											if (b >= 1)
											{
												while (b <= 32)
												{
													while (true)
													{
														IL_05f2_2:
														if (16 >= b)
														{
															while (true)
															{
																IL_05e2_2:
																if (16 > b)
																{
																	while (true)
																	{
																		IL_05d2_2:
																		if (8 >= b)
																		{
																			while (true)
																			{
																				IL_05c2_2:
																				if (8 > b)
																				{
																					while (true)
																					{
																						IL_05b2_2:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_05a2_2:
																								if (4 <= b)
																								{
																									while (true)
																									{
																										IL_0592_2:
																										array2[num5] = 0;
																										while (true)
																										{
																											IL_0564_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																											num = 170;
																											while (true)
																											{
																												IL_054f_2:
																												array3[num5] = null;
																												num = 6;
																												while (true)
																												{
																													IL_0536_2:
																													num5++;
																													num = 325;
																													while (true)
																													{
																														if (num != 325)
																														{
																															if (num != 1306)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 6:
																																goto IL_0536_2;
																															case 170:
																																goto IL_054f_2;
																															case 63:
																																goto IL_0564_2;
																															case 111:
																															case 113:
																																goto IL_0592_2;
																															case 5:
																																goto IL_05a2_2;
																															case 245:
																															case 260:
																																goto IL_05b2_2;
																															case 78:
																																goto IL_05c2_2;
																															case 48:
																															case 163:
																																goto IL_05d2_2;
																															case 275:
																																goto IL_05e2_2;
																															case 95:
																																goto IL_05f2_2;
																															case 3:
																																goto IL_0602_2;
																															case 120:
																																goto IL_0612_2;
																															case 76:
																																goto end_IL_0612_2;
																															case 178:
																															case 297:
																																goto end_IL_0622;
																															case 68:
																																goto IL_0646_2;
																															case 72:
																																goto IL_0654_2;
																															case 29:
																															case 73:
																																goto IL_0670_2;
																															case 20:
																																goto IL_067b_2;
																															case 84:
																																goto IL_068e_2;
																															case 117:
																																goto IL_069c_2;
																															case 50:
																															case 115:
																																goto IL_06b5_2;
																															case 103:
																																goto IL_06f5_2;
																															case 8:
																																goto IL_0709_2;
																															case 22:
																															case 121:
																																goto IL_071c_2;
																															case 43:
																																goto IL_072a_2;
																															case 77:
																															case 137:
																																goto IL_0738_2;
																															case 69:
																																goto IL_0752_2;
																															case 127:
																															case 140:
																																goto IL_0765_2;
																															case 205:
																															case 206:
																																goto IL_07aa_2;
																															case 171:
																																goto IL_07b8_2;
																															case 221:
																																goto IL_07cb_2;
																															case 36:
																																goto IL_07d6_2;
																															case 38:
																																goto IL_07e1_2;
																															case 169:
																																goto IL_07ec_2;
																															case 31:
																																goto IL_07ff_2;
																															case 60:
																																goto IL_081b_2;
																															case 233:
																																goto IL_082e_2;
																															case 56:
																															case 149:
																																goto IL_0839_2;
																															case 17:
																																goto IL_0847_2;
																															case 55:
																															case 124:
																																goto IL_0855_2;
																															case 195:
																																goto IL_086d_2;
																															case 131:
																																goto IL_087b_2;
																															case 94:
																															case 96:
																																goto IL_088e_2;
																															case 189:
																															case 241:
																																goto IL_08a7_2;
																															case 128:
																																goto IL_08bb_2;
																															case 74:
																																goto IL_0907_2;
																															case 98:
																																goto IL_0915_2;
																															case 249:
																																goto IL_0928_2;
																															case 193:
																															case 223:
																																goto IL_0933_2;
																															case 177:
																																goto IL_0941_2;
																															case 64:
																																goto IL_094f_2;
																															case 66:
																																goto IL_0962_2;
																															case 93:
																																goto IL_0970_2;
																															case 86:
																															case 237:
																																goto IL_097b_2;
																															case 104:
																																goto IL_0989_2;
																															case 183:
																															case 242:
																																goto IL_0997_2;
																															case 135:
																																goto IL_09bb_2;
																															case 97:
																																goto IL_09c9_2;
																															case 108:
																																goto IL_09d7_2;
																															case 71:
																																goto IL_09ea_2;
																															case 256:
																																goto IL_09fd_2;
																															case 57:
																															case 157:
																																goto IL_0a08_2;
																															case 118:
																																goto IL_0a33_2;
																															case 231:
																																goto IL_0a4c_2;
																															case 125:
																																goto IL_0a5a_2;
																															case 54:
																															case 216:
																																goto IL_0a68_2;
																															case 209:
																																goto IL_0a92_2;
																															case 201:
																															case 268:
																																goto IL_0aab_2;
																															case 236:
																															case 269:
																																goto IL_0af0_2;
																															case 165:
																																goto IL_0b0e_2;
																															case 190:
																																goto IL_0b25_2;
																															case 18:
																																goto IL_0b3c_2;
																															case 271:
																															case 274:
																																goto IL_0b4f_2;
																															case 161:
																																goto IL_0b5d_2;
																															case 276:
																																goto IL_0b70_2;
																															case 267:
																																goto IL_0b84_2;
																															case 277:
																																goto IL_0b97_2;
																															case 34:
																															case 129:
																																goto IL_0ba5_2;
																															case 278:
																																goto IL_0bc1_2;
																															case 119:
																																goto IL_0bf9_2;
																															case 159:
																															case 282:
																																goto IL_0c0c_2;
																															case 182:
																																goto IL_0c4c_2;
																															case 132:
																																goto IL_0c60_2;
																															case 287:
																																goto IL_0c73_2;
																															case 202:
																															case 291:
																																goto IL_0c86_2;
																															case 181:
																																goto IL_0c94_2;
																															case 270:
																															case 292:
																																goto IL_0ca7_2;
																															case 1:
																																goto IL_0ce5_2;
																															case 162:
																															case 296:
																																goto IL_0cf8_2;
																															case 39:
																																goto IL_0d0c_2;
																															case 136:
																																goto IL_0d44_2;
																															case 114:
																															case 299:
																																goto IL_0d57_2;
																															case 30:
																																goto IL_0d65_2;
																															case 35:
																															case 235:
																																goto IL_0d73_2;
																															case 19:
																																goto IL_0d9c_2;
																															case 4:
																																goto IL_0daa_2;
																															case 300:
																																goto IL_0dbd_2;
																															case 145:
																															case 168:
																																goto IL_0dc8_2;
																															case 116:
																																goto IL_0dd3_2;
																															case 27:
																															case 273:
																																goto IL_0de1_2;
																															case 238:
																																goto IL_0e0a_2;
																															case 281:
																																goto IL_0e18_2;
																															case 227:
																																goto IL_0e39_2;
																															case 62:
																															case 204:
																																goto IL_0e47_2;
																															case 234:
																																goto IL_0e5b_2;
																															case 196:
																																goto IL_0eb0_2;
																															case 184:
																																goto IL_0ebe_2;
																															case 0:
																															case 307:
																																goto IL_0ed1_2;
																															case 203:
																																goto IL_0f11_2;
																															case 83:
																																goto IL_0f25_2;
																															case 308:
																																goto IL_0f41_2;
																															case 239:
																															case 310:
																																goto IL_0f5a_2;
																															case 212:
																																goto IL_0f6f_2;
																															case 7:
																															case 315:
																																goto IL_0f82_2;
																															case 92:
																																goto IL_0f90_2;
																															case 21:
																															case 263:
																																goto IL_0f9b_2;
																															case 40:
																																goto IL_0fd4_2;
																															case 130:
																																goto IL_0fe8_2;
																															case 316:
																																goto IL_1009_2;
																															case 151:
																															case 251:
																																goto IL_102f_2;
																															case 49:
																																goto IL_1042_2;
																															case 213:
																															case 222:
																																goto IL_1050_2;
																															case 13:
																															case 192:
																																goto IL_105e_2;
																															case 42:
																																goto IL_106c_2;
																															case 194:
																															case 318:
																																goto IL_107a_2;
																															case 123:
																																goto IL_1092_2;
																															case 301:
																																goto IL_10b0_2;
																															case 144:
																																goto IL_10d4_2;
																															case 253:
																																goto IL_10ec_2;
																															case 207:
																																goto IL_1116_2;
																															case 12:
																															case 102:
																																goto IL_1121_2;
																															case 138:
																																goto IL_114a_2;
																															case 152:
																																goto IL_1163_2;
																															case 148:
																																goto IL_1171_2;
																															case 280:
																															case 317:
																																goto IL_117f_2;
																															case 279:
																																goto IL_119d_2;
																															case 306:
																																goto IL_11ab_2;
																															case 230:
																																goto IL_11c7_2;
																															case 302:
																															case 305:
																																goto IL_11de_2;
																															case 53:
																																goto IL_11ec_2;
																															case 164:
																															case 259:
																																goto IL_11f7_2;
																															case 101:
																																goto IL_1259_2;
																															case 158:
																																goto IL_126c_2;
																															case 293:
																																goto IL_127a_2;
																															case 191:
																															case 314:
																																goto IL_1288_2;
																															case 59:
																																goto IL_12c8_2;
																															case 126:
																																goto IL_12dc_2;
																															case 23:
																																goto IL_12ef_2;
																															case 133:
																																goto IL_12fd_2;
																															case 174:
																															case 252:
																																goto end_IL_063b;
																															case 146:
																																goto IL_13d0_2;
																															case 229:
																																goto IL_13de_2;
																															case 112:
																															case 141:
																																goto IL_13fa_2;
																															case 26:
																																goto IL_1411_2;
																															case 109:
																																goto IL_1429_2;
																															case 134:
																																goto IL_1437_2;
																															case 10:
																															case 14:
																															case 15:
																															case 16:
																															case 25:
																															case 28:
																															case 32:
																															case 41:
																															case 45:
																															case 46:
																															case 51:
																															case 58:
																															case 61:
																															case 70:
																															case 75:
																															case 79:
																															case 80:
																															case 85:
																															case 87:
																															case 88:
																															case 91:
																															case 99:
																															case 105:
																															case 110:
																															case 122:
																															case 143:
																															case 147:
																															case 150:
																															case 154:
																															case 155:
																															case 160:
																															case 166:
																															case 173:
																															case 175:
																															case 180:
																															case 185:
																															case 187:
																															case 188:
																															case 197:
																															case 199:
																															case 200:
																															case 208:
																															case 210:
																															case 211:
																															case 214:
																															case 217:
																															case 219:
																															case 224:
																															case 228:
																															case 244:
																															case 250:
																															case 255:
																															case 257:
																															case 258:
																															case 261:
																															case 262:
																															case 264:
																															case 265:
																															case 272:
																															case 283:
																															case 288:
																															case 303:
																															case 312:
																																goto end_IL_0523_2;
																															case 313:
																																goto IL_1460_2;
																															case 285:
																																goto IL_1477_2;
																															case 295:
																																goto IL_1485_2;
																															case 2:
																															case 9:
																															case 11:
																															case 24:
																															case 33:
																															case 37:
																															case 44:
																															case 52:
																															case 82:
																															case 89:
																															case 90:
																															case 139:
																															case 142:
																															case 153:
																															case 156:
																															case 167:
																															case 176:
																															case 179:
																															case 186:
																															case 198:
																															case 218:
																															case 220:
																															case 225:
																															case 226:
																															case 232:
																															case 240:
																															case 243:
																															case 254:
																															case 266:
																															case 284:
																															case 289:
																															case 290:
																															case 294:
																															case 304:
																															case 311:
																																goto IL_1493_2;
																															case 81:
																																ptr2 = ptr;
																																num = 37;
																																goto IL_1493_2;
																															case 246:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ApplicationExceptionsetNumberNegativePattern.MapAssemblyTokenSandBoxInert);
																																goto case 81;
																															case 65:
																																array7[0] = this;
																																num = 246;
																																goto case 246;
																															case 309:
																																array7 = new object[16];
																																goto case 65;
																															case 47:
																																array6 = new long[4];
																																goto case 309;
																															case 215:
																																array5 = new int[6];
																																goto case 47;
																															case 67:
																																array4 = new int[4];
																																goto case 215;
																															case 298:
																																array3 = new object[4];
																																goto case 67;
																															case 107:
																															case 286:
																																array2 = new byte[4];
																																goto case 298;
																															case 172:
																																num3 = num2 * 4;
																																goto case 107;
																															case 247:
																																num2 = 1;
																																goto case 172;
																															case 248:
																																goto end_IL_1336;
																															case 100:
																															case 106:
																																return;
																															}
																															continue;
																														}
																														ptr2 += 8;
																														goto IL_1493_2;
																														continue;
																														end_IL_0523_2:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0646_2;
																								IL_0d9c_2:
																								ptr2 += 8;
																								goto IL_0daa_2;
																								IL_0646_2:
																								if (2 >= b)
																								{
																									goto IL_0654_2;
																								}
																								goto IL_0d57_2;
																								IL_0654_2:
																								if (2 > b)
																								{
																									num = 206;
																									goto IL_07aa_2;
																								}
																								goto IL_0c0c_2;
																								IL_0daa_2:
																								num5--;
																								goto IL_1493_2;
																								IL_07aa_2:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_07b8_2;
																								IL_07b8_2:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0c0c_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_0c4c_2;
																								IL_0c4c_2:
																								array2[num5 - 2] = 0;
																								goto IL_0c60_2;
																								IL_0c60_2:
																								num5--;
																								goto IL_1493_2;
																								IL_0d57_2:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0d65_2;
																								IL_0d65_2:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0d73_2;
																								IL_0d73_2:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_0d9c_2;
																							}
																							break;
																						}
																						goto IL_0670_2;
																						IL_06f5_2:
																						array2[num5 - 2] = 0;
																						goto IL_0709_2;
																						IL_0670_2:
																						if (6 >= b)
																						{
																							goto IL_067b_2;
																						}
																						goto IL_068e_2;
																						IL_067b_2:
																						if (6 <= b)
																						{
																							goto IL_0765_2;
																						}
																						goto IL_0c86_2;
																						IL_0c86_2:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_0c94_2;
																						IL_0c94_2:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0ed1_2;
																						IL_0ed1_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0f11_2;
																						IL_0f11_2:
																						array2[num5 - 2] = 0;
																						goto IL_0f25_2;
																						IL_0f25_2:
																						num5--;
																						num = 2;
																						goto IL_1493_2;
																						IL_0765_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0f41_2;
																						IL_0f41_2:
																						array2[num5 - 2] = 0;
																						goto IL_1009_2;
																						IL_1009_2:
																						num5--;
																						goto IL_1493_2;
																						IL_068e_2:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_069c_2;
																						IL_069c_2:
																						if (7 > b)
																						{
																							num = 217;
																							break;
																						}
																						goto IL_06b5_2;
																						IL_0709_2:
																						num5--;
																						goto IL_1493_2;
																						IL_06b5_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_06f5_2;
																					}
																					break;
																				}
																				goto IL_102f_2;
																				IL_102f_2:
																				num5--;
																				goto IL_1493_2;
																			}
																			break;
																		}
																		goto IL_1042_2;
																		IL_12dc_2:
																		num5--;
																		goto IL_1493_2;
																		IL_1042_2:
																		if (12 < b)
																		{
																			goto IL_1050_2;
																		}
																		goto IL_11c7_2;
																		IL_1050_2:
																		if (14 < b)
																		{
																			goto IL_105e_2;
																		}
																		goto IL_1116_2;
																		IL_105e_2:
																		if (15 < b)
																		{
																			num = 80;
																			break;
																		}
																		goto IL_106c_2;
																		IL_106c_2:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_107a_2;
																		IL_107a_2:
																		array2[num5] = array2[num5 - 1];
																		goto IL_1092_2;
																		IL_1092_2:
																		array4[num5 - 0] = array4[num5 - 1];
																		goto IL_10b0_2;
																		IL_10b0_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_10d4_2;
																		IL_10d4_2:
																		array3[num5] = array3[num5 - 1];
																		goto IL_10ec_2;
																		IL_10ec_2:
																		num5++;
																		num = 186;
																		goto IL_1493_2;
																		IL_12ef_2:
																		if (11 < b)
																		{
																			break;
																		}
																		goto IL_12fd_2;
																		IL_1116_2:
																		if (14 <= b)
																		{
																			goto IL_1121_2;
																		}
																		goto IL_1163_2;
																		IL_1121_2:
																		array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																		goto IL_114a_2;
																		IL_114a_2:
																		array2[num5 - 1] = 5;
																		goto IL_1493_2;
																		IL_1163_2:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_1171_2;
																		IL_1171_2:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_117f_2;
																		IL_117f_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																		goto IL_119d_2;
																		IL_119d_2:
																		ptr2 += 8;
																		goto IL_11ab_2;
																		IL_11ab_2:
																		num5--;
																		num = 290;
																		goto IL_1493_2;
																		IL_11c7_2:
																		if (12 <= b)
																		{
																			goto end_IL_063b;
																		}
																		num = 302;
																		goto IL_11de_2;
																		IL_12fd_2:
																		if (11 > b)
																		{
																			num = 200;
																			break;
																		}
																		goto IL_1493_2;
																		IL_11de_2:
																		if (10 >= b)
																		{
																			goto IL_11ec_2;
																		}
																		goto IL_12ef_2;
																		IL_11ec_2:
																		if (10 <= b)
																		{
																			goto IL_11f7_2;
																		}
																		goto IL_126c_2;
																		IL_11f7_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_1259_2;
																		IL_1259_2:
																		num5 -= 2;
																		goto IL_1493_2;
																		IL_126c_2:
																		if (9 < b)
																		{
																			break;
																		}
																		goto IL_127a_2;
																		IL_127a_2:
																		if (9 > b)
																		{
																			break;
																		}
																		goto IL_1288_2;
																		IL_1288_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_12c8_2;
																		IL_12c8_2:
																		array2[num5 - 2] = 0;
																		goto IL_12dc_2;
																	}
																	break;
																}
																goto IL_13fa_2;
																IL_1437_2:
																ptr2 += 8;
																goto IL_1493_2;
																IL_13fa_2:
																array2[num5] = 5;
																num = 26;
																goto IL_1411_2;
																IL_1411_2:
																array3[num5] = array7[*(int*)(ptr2 + num3)];
																goto IL_1429_2;
																IL_1429_2:
																num5++;
																goto IL_1437_2;
															}
															break;
														}
														goto IL_071c_2;
														IL_0f9b_2:
														array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_0fd4_2;
														IL_071c_2:
														if (24 >= b)
														{
															goto IL_072a_2;
														}
														goto IL_07cb_2;
														IL_072a_2:
														if (24 <= b)
														{
															goto IL_0738_2;
														}
														goto IL_0928_2;
														IL_0738_2:
														Class9.int_2 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0752_2;
														IL_0752_2:
														num5--;
														goto IL_1493_2;
														IL_0928_2:
														if (20 < b)
														{
															goto IL_0933_2;
														}
														goto IL_0962_2;
														IL_0933_2:
														if (22 < b)
														{
															goto IL_0941_2;
														}
														goto IL_09fd_2;
														IL_0941_2:
														if (23 < b)
														{
															break;
														}
														goto IL_094f_2;
														IL_094f_2:
														if (23 > b)
														{
															break;
														}
														goto IL_0aab_2;
														IL_0aab_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0b70_2;
														IL_0b70_2:
														array2[num5 - 2] = 0;
														goto IL_0b84_2;
														IL_0b84_2:
														num5--;
														goto IL_1493_2;
														IL_09fd_2:
														if (22 <= b)
														{
															goto IL_0a08_2;
														}
														goto IL_0a4c_2;
														IL_0a08_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_0a33_2;
														IL_0a33_2:
														array2[num5 - 1] = 0;
														goto IL_1493_2;
														IL_0a4c_2:
														if (21 < b)
														{
															break;
														}
														goto IL_0a5a_2;
														IL_0a5a_2:
														if (21 > b)
														{
															break;
														}
														goto IL_0a68_2;
														IL_0a68_2:
														*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
														goto IL_0a92_2;
														IL_0a92_2:
														array2[num5 - 1] = 2;
														goto IL_1493_2;
														IL_0962_2:
														if (20 > b)
														{
															goto IL_0970_2;
														}
														goto IL_0af0_2;
														IL_0970_2:
														if (18 < b)
														{
															goto IL_097b_2;
														}
														goto IL_09ea_2;
														IL_097b_2:
														if (19 < b)
														{
															break;
														}
														goto IL_0989_2;
														IL_0989_2:
														if (19 > b)
														{
															break;
														}
														goto IL_0997_2;
														IL_0997_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])();
														goto IL_09bb_2;
														IL_09bb_2:
														array2[num5] = 0;
														goto IL_09c9_2;
														IL_09c9_2:
														num5++;
														goto IL_09d7_2;
														IL_09d7_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_09ea_2:
														if (18 > b)
														{
															goto IL_0b4f_2;
														}
														goto IL_0cf8_2;
														IL_0b4f_2:
														if (17 < b)
														{
															break;
														}
														goto IL_0b5d_2;
														IL_0b5d_2:
														if (17 > b)
														{
															break;
														}
														goto IL_0ca7_2;
														IL_0ca7_2:
														((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
														goto IL_0ce5_2;
														IL_0ce5_2:
														num5 -= 3;
														goto IL_1493_2;
														IL_0cf8_2:
														array2[num5 - 1] = 5;
														goto IL_0d0c_2;
														IL_0d0c_2:
														array3[num5 - 1] = ((delegate*<string[], string>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
														goto IL_0d44_2;
														IL_0d44_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_0af0_2:
														array3[num5] = ((delegate*<string[]>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])();
														goto IL_0b0e_2;
														IL_0b0e_2:
														array2[num5] = 5;
														num = 190;
														goto IL_0b25_2;
														IL_0b25_2:
														num5++;
														num = 18;
														goto IL_0b3c_2;
														IL_0b3c_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_07cb_2:
														if (28 < b)
														{
															goto IL_07d6_2;
														}
														num = 60;
														goto IL_081b_2;
														IL_07d6_2:
														if (30 < b)
														{
															goto IL_07e1_2;
														}
														goto IL_082e_2;
														IL_07e1_2:
														if (31 >= b)
														{
															goto IL_07ec_2;
														}
														goto IL_07ff_2;
														IL_07ec_2:
														if (31 > b)
														{
															break;
														}
														goto IL_08a7_2;
														IL_08a7_2:
														array2[num5 - 2] = 5;
														goto IL_08bb_2;
														IL_08bb_2:
														array3[num5 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((Class137)array3[num5 - 2], (IEnumerator)array3[num5 - 1]);
														goto IL_0907_2;
														IL_0907_2:
														num5--;
														goto IL_0915_2;
														IL_0915_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_07ff_2:
														if (32 < b)
														{
															break;
														}
														goto IL_0b97_2;
														IL_0b97_2:
														if (32 > b)
														{
															break;
														}
														goto IL_0ba5_2;
														IL_0ba5_2:
														num9 = ptr2;
														num10 = -200;
														num4 = 1;
														ptr2 = num9 + num10;
														goto IL_1493_2;
														IL_082e_2:
														if (30 > b)
														{
															goto IL_0839_2;
														}
														goto IL_088e_2;
														IL_0839_2:
														if (29 < b)
														{
															break;
														}
														goto IL_0847_2;
														IL_0847_2:
														if (29 > b)
														{
															break;
														}
														goto IL_0855_2;
														IL_0855_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_086d_2;
														IL_086d_2:
														array2[num5] = 5;
														goto IL_087b_2;
														IL_087b_2:
														num5++;
														goto IL_0c73_2;
														IL_0c73_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_088e_2:
														array2[num5 - 1] = 5;
														goto IL_0bc1_2;
														IL_0bc1_2:
														array3[num5 - 1] = ((delegate*<Class137, IEnumerator>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((Class137)array3[num5 - 1]);
														goto IL_0bf9_2;
														IL_0bf9_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_0fd4_2:
														array2[num5 - 2] = 5;
														goto IL_0fe8_2;
														IL_081b_2:
														if (28 > b)
														{
															goto IL_0dbd_2;
														}
														goto IL_0f5a_2;
														IL_0f5a_2:
														((delegate*<void>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])();
														goto IL_0f6f_2;
														IL_0f6f_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_0dbd_2:
														if (26 < b)
														{
															goto IL_0dc8_2;
														}
														goto IL_0e39_2;
														IL_0dc8_2:
														if (27 < b)
														{
															num = 70;
															break;
														}
														goto IL_0dd3_2;
														IL_0dd3_2:
														if (27 > b)
														{
															break;
														}
														goto IL_0de1_2;
														IL_0de1_2:
														((delegate*<string, void>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
														goto IL_0e0a_2;
														IL_0e0a_2:
														num5--;
														goto IL_0e18_2;
														IL_0e18_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_0fe8_2:
														num5--;
														goto IL_1493_2;
														IL_0e39_2:
														if (26 <= b)
														{
															goto IL_0e47_2;
														}
														goto IL_0f82_2;
														IL_0e47_2:
														array2[num5 - 2] = 5;
														goto IL_0e5b_2;
														IL_0e5b_2:
														array3[num5 - 2] = ((delegate*<string, string, string>)GetSrcItfTypeLazy[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
														num = 196;
														goto IL_0eb0_2;
														IL_0eb0_2:
														num5--;
														goto IL_0ebe_2;
														IL_0ebe_2:
														ptr2 += 8;
														goto IL_1493_2;
														IL_0f82_2:
														if (25 < b)
														{
															break;
														}
														goto IL_0f90_2;
														IL_0f90_2:
														if (25 > b)
														{
															num = 228;
															break;
														}
														goto IL_0f9b_2;
													}
													break;
													IL_0602_2:;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_1460_2;
											IL_1485_2:
											ptr2 += 8;
											goto IL_1493_2;
											IL_1477_2:
											num5++;
											goto IL_1485_2;
											IL_1460_2:
											array2[num5] = 0;
											num = 285;
											goto IL_1477_2;
											continue;
											end_IL_0612_2:
											break;
										}
										continue;
										end_IL_0622:
										break;
									}
									continue;
									end_IL_063b:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_1328_2;
					}
					continue;
					end_IL_1336:
					break;
				}
				break;
			}
		}
	}

	private unsafe IEnumerator method_0()
	{
		int num = 3;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										num = 121;
										while (true)
										{
											object[] array6 = new object[1];
											while (true)
											{
												array6[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InternalHighSecurityRuleSet.ArgumentCountNotSerialized);
													while (true)
													{
														byte* ptr2 = ptr;
														num = 156;
														while (true)
														{
															if (num5 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_0414:
																			if (b >= 1)
																			{
																				while (true)
																				{
																					IL_0404:
																					if (b <= 22)
																					{
																						while (true)
																						{
																							IL_03f7:
																							if (11 < b)
																							{
																								while (true)
																								{
																									IL_03e7:
																									if (17 >= b)
																									{
																										while (true)
																										{
																											IL_03d7:
																											if (17 > b)
																											{
																												while (true)
																												{
																													IL_03c7:
																													if (14 < b)
																													{
																														while (true)
																														{
																															IL_03b7:
																															if (15 < b)
																															{
																																while (16 >= b)
																																{
																																	while (16 <= b)
																																	{
																																		num = 217;
																																		while (true)
																																		{
																																			if (num != 217)
																																			{
																																				if (num != 1198)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 112:
																																					goto IL_0394;
																																				case 153:
																																					goto IL_03a7;
																																				case 65:
																																				case 101:
																																					goto IL_03b7;
																																				case 194:
																																					goto IL_03c7;
																																				case 103:
																																					goto IL_03d7;
																																				case 185:
																																					goto IL_03e7;
																																				case 21:
																																					goto IL_03f7;
																																				case 178:
																																					goto IL_0404;
																																				case 202:
																																					goto IL_0414;
																																				case 23:
																																					goto end_IL_0414;
																																				case 5:
																																				case 91:
																																					goto end_IL_0424;
																																				case 37:
																																					goto IL_043f;
																																				case 76:
																																					goto IL_044d;
																																				case 69:
																																					goto IL_045b;
																																				case 129:
																																					goto IL_0469;
																																				case 95:
																																					goto IL_0474;
																																				case 56:
																																					goto IL_0499;
																																				case 25:
																																					goto IL_04a7;
																																				case 57:
																																					goto IL_04b5;
																																				case 133:
																																					goto IL_04d1;
																																				case 142:
																																				case 149:
																																					goto IL_04e4;
																																				case 26:
																																					goto IL_04f2;
																																				case 10:
																																					goto IL_0500;
																																				case 35:
																																					goto IL_050e;
																																				case 130:
																																				case 151:
																																					goto IL_051c;
																																				case 17:
																																					goto IL_0534;
																																				case 96:
																																					goto IL_0552;
																																				case 86:
																																					goto IL_0576;
																																				case 41:
																																					goto IL_058e;
																																				case 6:
																																				case 161:
																																					goto IL_05a1;
																																				case 164:
																																					goto IL_05ba;
																																				case 88:
																																					goto IL_05c5;
																																				case 144:
																																					goto IL_05d8;
																																				case 146:
																																					goto IL_05e6;
																																				case 39:
																																				case 170:
																																					goto IL_05f9;
																																				case 167:
																																					goto IL_062f;
																																				case 159:
																																				case 171:
																																					goto IL_0642;
																																				case 58:
																																					goto IL_065b;
																																				case 160:
																																					goto IL_0669;
																																				case 111:
																																					goto IL_0677;
																																				case 4:
																																				case 173:
																																					goto IL_068a;
																																				case 125:
																																				case 174:
																																					goto IL_06cd;
																																				case 135:
																																					goto IL_070d;
																																				case 24:
																																					goto IL_0721;
																																				case 177:
																																					goto IL_0734;
																																				case 92:
																																					goto IL_0748;
																																				case 38:
																																				case 179:
																																					goto IL_075b;
																																				case 0:
																																					goto IL_079b;
																																				case 7:
																																					goto IL_07af;
																																				case 16:
																																				case 183:
																																					goto IL_07c2;
																																				case 1:
																																					goto IL_07d6;
																																				case 11:
																																					goto IL_080f;
																																				case 70:
																																				case 190:
																																					goto IL_0822;
																																				case 13:
																																					goto IL_0830;
																																				case 124:
																																				case 152:
																																					goto IL_083e;
																																				case 77:
																																					goto IL_084c;
																																				case 196:
																																					goto IL_0874;
																																				case 20:
																																				case 123:
																																					goto IL_0882;
																																				case 199:
																																					goto IL_08ad;
																																				case 105:
																																					goto IL_0901;
																																				case 137:
																																					goto IL_090f;
																																				case 203:
																																					goto IL_092b;
																																				case 87:
																																					goto IL_0939;
																																				case 118:
																																				case 204:
																																					goto IL_094c;
																																				case 143:
																																					goto IL_095a;
																																				case 73:
																																				case 107:
																																					goto IL_0965;
																																				case 119:
																																					goto IL_0978;
																																				case 31:
																																				case 84:
																																					goto IL_0983;
																																				case 182:
																																					goto IL_099f;
																																				case 9:
																																				case 28:
																																					goto IL_09ad;
																																				case 32:
																																					goto IL_09ed;
																																				case 145:
																																					goto IL_0a01;
																																				case 114:
																																					goto IL_0a14;
																																				case 40:
																																					goto IL_0a1f;
																																				case 94:
																																				case 131:
																																					goto IL_0a2d;
																																				case 68:
																																					goto IL_0a6d;
																																				case 193:
																																					goto IL_0a81;
																																				case 172:
																																					goto IL_0a94;
																																				case 158:
																																					goto IL_0aa2;
																																				case 49:
																																				case 80:
																																					goto IL_0aad;
																																				case 44:
																																					goto IL_0b0f;
																																				case 15:
																																				case 205:
																																					goto IL_0b30;
																																				case 116:
																																					goto IL_0b3e;
																																				case 104:
																																				case 181:
																																					goto IL_0b4c;
																																				case 74:
																																					goto IL_0b64;
																																				case 186:
																																					goto IL_0b72;
																																				case 90:
																																					goto IL_0b80;
																																				case 206:
																																					goto IL_0b93;
																																				case 155:
																																					goto IL_0b9d;
																																				case 34:
																																					goto IL_0bab;
																																				case 208:
																																					goto IL_0bbe;
																																				case 53:
																																				case 66:
																																					goto IL_0bcc;
																																				case 154:
																																					goto IL_0c0c;
																																				case 55:
																																					goto IL_0c20;
																																				case 192:
																																				case 210:
																																					goto IL_0c33;
																																				case 166:
																																					goto IL_0c4f;
																																				case 176:
																																					goto IL_0caa;
																																				case 198:
																																					goto IL_0cbd;
																																				case 14:
																																				case 97:
																																					goto IL_0cc8;
																																				case 18:
																																				case 78:
																																					goto IL_0cd3;
																																				case 150:
																																					goto IL_0cde;
																																				case 59:
																																				case 200:
																																					goto IL_0ce9;
																																				case 51:
																																					goto IL_0d02;
																																				case 132:
																																					goto IL_0d10;
																																				case 42:
																																					goto IL_0d1e;
																																				case 165:
																																					goto IL_0d2e;
																																				case 19:
																																				case 128:
																																					goto IL_0d3b;
																																				case 8:
																																				case 27:
																																				case 30:
																																				case 33:
																																				case 36:
																																				case 43:
																																				case 52:
																																				case 54:
																																				case 62:
																																				case 64:
																																				case 71:
																																				case 72:
																																				case 79:
																																				case 82:
																																				case 83:
																																				case 85:
																																				case 93:
																																				case 99:
																																				case 100:
																																				case 102:
																																				case 109:
																																				case 110:
																																				case 113:
																																				case 120:
																																				case 122:
																																				case 126:
																																				case 138:
																																				case 139:
																																				case 147:
																																				case 148:
																																				case 168:
																																				case 169:
																																				case 175:
																																				case 188:
																																				case 197:
																																				case 201:
																																				case 209:
																																					goto end_IL_0381;
																																				case 12:
																																				case 46:
																																				case 48:
																																				case 50:
																																				case 60:
																																				case 61:
																																				case 67:
																																				case 89:
																																				case 98:
																																				case 108:
																																				case 115:
																																				case 117:
																																				case 134:
																																				case 136:
																																				case 140:
																																				case 141:
																																				case 156:
																																				case 157:
																																				case 162:
																																				case 163:
																																				case 184:
																																				case 187:
																																				case 189:
																																				case 191:
																																				case 207:
																																					goto end_IL_0434;
																																				case 180:
																																					goto end_IL_0d6c;
																																				case 195:
																																					goto end_IL_0d7f;
																																				case 127:
																																					goto end_IL_0d92;
																																				case 121:
																																					goto end_IL_0d9d;
																																				case 106:
																																					goto end_IL_0dad;
																																				case 75:
																																					goto end_IL_0dbd;
																																				case 22:
																																					goto end_IL_0dd6;
																																				case 47:
																																					goto end_IL_0de6;
																																				case 29:
																																					goto end_IL_0df6;
																																				case 81:
																																					goto end_IL_0e06;
																																				case 2:
																																					goto end_IL_0e16;
																																				case 3:
																																					goto end_IL_0e26;
																																				case 45:
																																				case 63:
																																					goto IL_0e41;
																																				}
																																				continue;
																																			}
																																			goto IL_0c4f;
																																			IL_0c4f:
																																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																			num = 176;
																																			goto IL_0caa;
																																			IL_0caa:
																																			num6--;
																																			goto end_IL_0434;
																																			continue;
																																			end_IL_0381:
																																			break;
																																		}
																																		break;
																																		IL_0394:;
																																	}
																																	break;
																																	IL_03a7:;
																																}
																																break;
																															}
																															goto IL_04d1;
																															IL_0748:
																															num6--;
																															goto end_IL_0434;
																															IL_04d1:
																															if (15 > b)
																															{
																																break;
																															}
																															goto IL_068a;
																															IL_068a:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																															goto IL_0734;
																															IL_0734:
																															array[num6 - 2] = 0;
																															goto IL_0748;
																														}
																														break;
																													}
																													goto IL_0cbd;
																													IL_0d3b:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													goto end_IL_0434;
																													IL_0cbd:
																													if (14 > b)
																													{
																														goto IL_0cc8;
																													}
																													goto IL_0d3b;
																													IL_0cc8:
																													if (12 < b)
																													{
																														goto IL_0cd3;
																													}
																													goto IL_0d2e;
																													IL_0cd3:
																													if (13 < b)
																													{
																														break;
																													}
																													goto IL_0cde;
																													IL_0cde:
																													if (13 > b)
																													{
																														break;
																													}
																													goto IL_0ce9;
																													IL_0ce9:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																													goto IL_0d02;
																													IL_0d02:
																													array[num6] = 1;
																													goto IL_0d10;
																													IL_0d10:
																													num6++;
																													goto IL_0d1e;
																													IL_0d1e:
																													ptr2 += 16;
																													goto end_IL_0434;
																													IL_0d2e:
																													if (12 <= b)
																													{
																														goto end_IL_0434;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_07c2;
																											IL_080f:
																											ptr2 += 8;
																											goto end_IL_0434;
																											IL_07c2:
																											array[num6 - 1] = 5;
																											goto IL_07d6;
																											IL_07d6:
																											array2[num6 - 1] = ((delegate*<int, _003CDelayedDestroy_003Ed__1>)RtFieldInfoTimeZoneKeyName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																											goto IL_080f;
																										}
																										break;
																									}
																									goto IL_04e4;
																									IL_05e6:
																									if (22 <= b)
																									{
																									}
																									break;
																									IL_04e4:
																									if (20 >= b)
																									{
																										goto IL_04f2;
																									}
																									goto IL_05ba;
																									IL_04f2:
																									if (20 > b)
																									{
																										goto IL_0500;
																									}
																									goto IL_05f9;
																									IL_0500:
																									if (18 >= b)
																									{
																										goto IL_050e;
																									}
																									goto IL_0b30;
																									IL_050e:
																									if (18 > b)
																									{
																										break;
																									}
																									goto IL_051c;
																									IL_051c:
																									array[num6] = array[num6 - 1];
																									goto IL_0534;
																									IL_0534:
																									array3[num6 - 0] = array3[num6 - 1];
																									goto IL_0552;
																									IL_0552:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_0576;
																									IL_0576:
																									array2[num6] = array2[num6 - 1];
																									goto IL_058e;
																									IL_058e:
																									num6++;
																									goto end_IL_0434;
																									IL_0b30:
																									if (19 < b)
																									{
																										break;
																									}
																									goto IL_0b3e;
																									IL_0b3e:
																									if (19 > b)
																									{
																										break;
																									}
																									goto IL_0b4c;
																									IL_0b4c:
																									array2[num6] = array6[*(int*)(ptr2 + num3)];
																									goto IL_0b64;
																									IL_0b64:
																									array[num6] = 5;
																									goto IL_0b72;
																									IL_0b72:
																									num6++;
																									goto IL_0b80;
																									IL_0b80:
																									ptr2 += 8;
																									goto end_IL_0434;
																									IL_05f9:
																									((_003CDelayedDestroy_003Ed__1)array2[num6 - 2]).class137_0 = (Class137)array2[num6 - 1];
																									num = 167;
																									goto IL_062f;
																									IL_062f:
																									num6 -= 2;
																									goto end_IL_0434;
																									IL_05ba:
																									if (21 >= b)
																									{
																										goto IL_05c5;
																									}
																									goto IL_05d8;
																									IL_05c5:
																									if (21 > b)
																									{
																										break;
																									}
																									goto IL_0c33;
																									IL_0c33:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									goto end_IL_0434;
																									IL_05d8:
																									if (22 < b)
																									{
																										break;
																									}
																									goto IL_05e6;
																								}
																								break;
																							}
																							goto IL_043f;
																							IL_0b0f:
																							num6 -= 2;
																							goto end_IL_0434;
																							IL_043f:
																							if (11 > b)
																							{
																								goto IL_044d;
																							}
																							goto IL_05a1;
																							IL_044d:
																							if (5 >= b)
																							{
																								goto IL_045b;
																							}
																							goto IL_094c;
																							IL_045b:
																							if (5 > b)
																							{
																								goto IL_0469;
																							}
																							goto IL_075b;
																							IL_0469:
																							if (2 < b)
																							{
																								goto IL_0474;
																							}
																							num = 56;
																							goto IL_0499;
																							IL_0474:
																							if (3 < b)
																							{
																								num = 70;
																								goto IL_0822;
																							}
																							goto IL_0874;
																							IL_05a1:
																							array[num6 - 2] = 0;
																							goto IL_08ad;
																							IL_0822:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0830;
																							IL_0830:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_083e;
																							IL_083e:
																							array[num6] = 0;
																							goto IL_084c;
																							IL_084c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																							goto IL_0b93;
																							IL_0b93:
																							array2[num6] = null;
																							goto IL_0b9d;
																							IL_0b9d:
																							num6++;
																							goto IL_0bab;
																							IL_0bab:
																							ptr2 += 8;
																							goto end_IL_0434;
																							IL_0874:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0882;
																							IL_0882:
																							ref int reference = ref array4[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_092b;
																							IL_092b:
																							ptr2 += 8;
																							goto IL_0939;
																							IL_0939:
																							num6--;
																							goto end_IL_0434;
																							IL_090f:
																							ptr2 += 8;
																							num = 117;
																							goto end_IL_0434;
																							IL_0499:
																							if (2 > b)
																							{
																								goto IL_04a7;
																							}
																							goto IL_06cd;
																							IL_04a7:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_04b5;
																							IL_04b5:
																							if (1 > b)
																							{
																								break;
																							}
																							num = 171;
																							goto IL_0642;
																							IL_08ad:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<int, int, int>)RtFieldInfoTimeZoneKeyName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_0901;
																							IL_0642:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																							goto IL_065b;
																							IL_065b:
																							array[num6] = 0;
																							goto IL_0669;
																							IL_0669:
																							num6++;
																							goto IL_0677;
																							IL_0677:
																							ptr2 += 8;
																							goto end_IL_0434;
																							IL_06cd:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_070d;
																							IL_070d:
																							array[num6 - 2] = 0;
																							goto IL_0721;
																							IL_0721:
																							num6--;
																							goto end_IL_0434;
																							IL_075b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_079b;
																							IL_079b:
																							array[num6 - 2] = 0;
																							goto IL_07af;
																							IL_07af:
																							num6--;
																							goto end_IL_0434;
																							IL_094c:
																							if (8 >= b)
																							{
																								goto IL_095a;
																							}
																							goto IL_0a14;
																							IL_095a:
																							if (8 <= b)
																							{
																								goto IL_0965;
																							}
																							goto IL_0978;
																							IL_0965:
																							num6--;
																							goto end_IL_0434;
																							IL_0978:
																							if (6 < b)
																							{
																								goto IL_0983;
																							}
																							goto IL_099f;
																							IL_0983:
																							if (7 < b)
																							{
																								break;
																							}
																							num = 208;
																							goto IL_0bbe;
																							IL_0901:
																							num6--;
																							goto IL_090f;
																							IL_0bbe:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0bcc;
																							IL_0bcc:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0c0c;
																							IL_0c0c:
																							array[num6 - 2] = 0;
																							goto IL_0c20;
																							IL_0c20:
																							num6--;
																							goto end_IL_0434;
																							IL_099f:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_09ad;
																							IL_09ad:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_09ed;
																							IL_09ed:
																							array[num6 - 2] = 0;
																							goto IL_0a01;
																							IL_0a01:
																							num6--;
																							goto end_IL_0434;
																							IL_0a14:
																							if (9 >= b)
																							{
																								goto IL_0a1f;
																							}
																							goto IL_0a94;
																							IL_0a1f:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0a2d;
																							IL_0a2d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0a6d;
																							IL_0a6d:
																							array[num6 - 2] = 0;
																							goto IL_0a81;
																							IL_0a81:
																							num6--;
																							goto end_IL_0434;
																							IL_0a94:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0aa2;
																							IL_0aa2:
																							if (10 > b)
																							{
																								num = 138;
																								break;
																							}
																							goto IL_0aad;
																							IL_0aad:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0b0f;
																						}
																					}
																					else
																					{
																						num = 71;
																					}
																					break;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0434;
																			continue;
																			end_IL_0414:
																			break;
																		}
																		continue;
																		end_IL_0424:
																		break;
																	}
																	continue;
																	end_IL_0434:
																	break;
																}
																continue;
															}
															goto IL_0e41;
															IL_0e41:
															return (IEnumerator)array2[num6 - 1];
															continue;
															end_IL_0d6c:
															break;
														}
														continue;
														end_IL_0d7f:
														break;
													}
													continue;
													end_IL_0d92:
													break;
												}
												continue;
												end_IL_0d9d:
												break;
											}
											continue;
											end_IL_0dad:
											break;
										}
										continue;
										end_IL_0dbd:
										break;
									}
									continue;
									end_IL_0dd6:
									break;
								}
								continue;
								end_IL_0de6:
								break;
							}
							continue;
							end_IL_0df6:
							break;
						}
						continue;
						end_IL_0e06:
						break;
					}
					continue;
					end_IL_0e16:
					break;
				}
				continue;
				end_IL_0e26:
				break;
			}
		}
	}

	public Class137()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 55;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 43;
					while (true)
					{
						byte[] array = new byte[3];
						num = 49;
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HandlerOffsetsetAsUnknown.PopiClassName);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02b0:
															byte b = *ptr2;
															while (true)
															{
																IL_02a0:
																ptr2++;
																while (true)
																{
																	IL_0290:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0270:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0263:
																						if (6 <= b)
																						{
																							while (true)
																							{
																								IL_0221:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								while (true)
																								{
																									IL_020b:
																									array[num5 - 2] = 0;
																									while (true)
																									{
																										IL_01f2:
																										num5--;
																										num = 116;
																										while (num != 116)
																										{
																											if (num != 1097)
																											{
																												goto IL_02d4;
																											}
																											switch (num)
																											{
																											case 58:
																												goto IL_01f2;
																											case 82:
																												goto IL_020b;
																											case 72:
																											case 79:
																												goto IL_0221;
																											case 61:
																												goto IL_0263;
																											case 76:
																												goto IL_0270;
																											case 21:
																												goto IL_0280;
																											case 94:
																												goto IL_0290;
																											case 95:
																												goto IL_02a0;
																											case 36:
																											case 56:
																												goto IL_02b0;
																											case 3:
																												goto IL_02bb;
																											case 92:
																												goto IL_02c9;
																											case 87:
																											case 96:
																												goto IL_02d4;
																											case 100:
																												goto IL_02ec;
																											case 28:
																											case 78:
																												goto IL_02f7;
																											case 27:
																												goto IL_0305;
																											case 17:
																											case 34:
																												goto IL_0313;
																											case 2:
																												goto IL_033c;
																											case 105:
																												goto IL_034a;
																											case 67:
																												goto IL_035d;
																											case 84:
																											case 97:
																												goto IL_036b;
																											case 37:
																												goto IL_0384;
																											case 83:
																												goto IL_0392;
																											case 109:
																												goto IL_03a0;
																											case 14:
																												goto IL_03b3;
																											case 29:
																												goto IL_03be;
																											case 51:
																												goto IL_03cc;
																											case 38:
																											case 73:
																												goto IL_03da;
																											case 98:
																												goto IL_03e8;
																											case 33:
																												goto IL_040b;
																											case 65:
																												goto IL_0415;
																											case 75:
																												goto IL_0423;
																											case 103:
																												goto IL_0436;
																											case 70:
																												goto IL_0449;
																											case 63:
																											case 77:
																												goto IL_0454;
																											case 30:
																												goto IL_045f;
																											case 8:
																												goto IL_046d;
																											case 106:
																												goto IL_0480;
																											case 41:
																											case 66:
																												goto IL_048e;
																											case 47:
																												goto IL_04aa;
																											case 16:
																											case 24:
																												goto IL_04b8;
																											case 11:
																												goto IL_04cc;
																											case 42:
																											case 108:
																												goto IL_04da;
																											case 69:
																												goto IL_051a;
																											case 32:
																												goto IL_052e;
																											case 71:
																												goto IL_0541;
																											case 1:
																												goto IL_054f;
																											case 40:
																											case 107:
																												goto IL_055d;
																											case 45:
																												goto IL_0580;
																											case 104:
																												goto IL_058e;
																											case 59:
																												goto IL_059c;
																											case 52:
																											case 88:
																												goto IL_05af;
																											case 26:
																												goto IL_0611;
																											case 6:
																											case 7:
																											case 9:
																											case 10:
																											case 15:
																											case 19:
																											case 20:
																											case 25:
																											case 31:
																											case 46:
																											case 48:
																											case 57:
																											case 62:
																											case 80:
																											case 81:
																											case 85:
																											case 89:
																											case 91:
																											case 99:
																												goto end_IL_0280;
																											case 5:
																											case 13:
																											case 18:
																											case 22:
																											case 23:
																											case 35:
																											case 39:
																											case 50:
																											case 86:
																											case 90:
																											case 93:
																											case 101:
																											case 102:
																												goto end_IL_01df;
																											case 60:
																												goto end_IL_0634;
																											case 0:
																												goto end_IL_0647;
																											case 4:
																												goto end_IL_0651;
																											case 12:
																												goto end_IL_065c;
																											case 44:
																											case 53:
																												goto end_IL_0671;
																											case 49:
																												goto end_IL_0681;
																											case 43:
																												goto end_IL_0691;
																											case 64:
																												goto end_IL_06a1;
																											case 54:
																												goto end_IL_06ba;
																											case 55:
																												goto end_IL_06c5;
																											case 68:
																											case 74:
																												goto IL_06e0;
																											}
																											continue;
																											end_IL_01df:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_02bb;
																						IL_0436:
																						if (4 > b)
																						{
																							goto end_IL_0280;
																						}
																						break;
																						IL_02bb:
																						if (3 >= b)
																						{
																							goto IL_02c9;
																						}
																						goto IL_03b3;
																						IL_02c9:
																						if (3 <= b)
																						{
																							goto IL_02d4;
																						}
																						goto IL_02ec;
																						IL_02d4:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_02ec:
																						if (1 < b)
																						{
																							goto IL_02f7;
																						}
																						goto IL_035d;
																						IL_02f7:
																						if (2 < b)
																						{
																							goto end_IL_0280;
																						}
																						goto IL_0305;
																						IL_0305:
																						if (2 > b)
																						{
																							goto end_IL_0280;
																						}
																						goto IL_0313;
																						IL_0313:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_033c;
																						IL_033c:
																						ptr2 += 8;
																						goto IL_034a;
																						IL_034a:
																						num5--;
																						break;
																						IL_035d:
																						if (1 > b)
																						{
																							goto end_IL_0280;
																						}
																						goto IL_036b;
																						IL_036b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0384;
																						IL_0384:
																						array[num5] = 0;
																						goto IL_0392;
																						IL_0392:
																						num5++;
																						goto IL_03a0;
																						IL_03a0:
																						ptr2 += 8;
																						break;
																						IL_03b3:
																						if (4 < b)
																						{
																							goto IL_03be;
																						}
																						goto IL_0436;
																						IL_03be:
																						if (5 < b)
																						{
																							goto end_IL_0280;
																						}
																						goto IL_03cc;
																						IL_03cc:
																						if (5 > b)
																						{
																							goto end_IL_0280;
																						}
																						goto IL_03da;
																						IL_03da:
																						array[num5] = 0;
																						goto IL_03e8;
																						IL_03e8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_040b;
																						IL_040b:
																						array2[num5] = null;
																						goto IL_0415;
																						IL_0415:
																						num5++;
																						goto IL_0423;
																						IL_0423:
																						ptr2 += 8;
																						break;
																					}
																					break;
																				}
																				goto IL_0449;
																				IL_05af:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0611;
																				IL_0449:
																				if (9 < b)
																				{
																					goto IL_0454;
																				}
																				goto IL_04aa;
																				IL_0454:
																				if (10 < b)
																				{
																					goto IL_045f;
																				}
																				goto IL_0480;
																				IL_045f:
																				if (11 < b)
																				{
																					goto end_IL_0280;
																				}
																				goto IL_046d;
																				IL_046d:
																				if (11 <= b)
																				{
																				}
																				goto end_IL_0280;
																				IL_0480:
																				if (10 > b)
																				{
																					goto end_IL_0280;
																				}
																				goto IL_048e;
																				IL_048e:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_04aa:
																				if (9 > b)
																				{
																					goto IL_04b8;
																				}
																				goto IL_05af;
																				IL_04b8:
																				if (7 >= b)
																				{
																					num = 11;
																					goto IL_04cc;
																				}
																				goto IL_0541;
																				IL_0611:
																				num5 -= 2;
																				break;
																				IL_04cc:
																				if (7 > b)
																				{
																					goto end_IL_0280;
																				}
																				goto IL_04da;
																				IL_04da:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_051a;
																				IL_051a:
																				array[num5 - 2] = 0;
																				goto IL_052e;
																				IL_052e:
																				num5--;
																				break;
																				IL_0541:
																				if (8 < b)
																				{
																					goto end_IL_0280;
																				}
																				goto IL_054f;
																				IL_054f:
																				if (8 > b)
																				{
																					goto end_IL_0280;
																				}
																				goto IL_055d;
																				IL_055d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0580;
																				IL_0580:
																				array[num5] = 0;
																				goto IL_058e;
																				IL_058e:
																				num5++;
																				goto IL_059c;
																				IL_059c:
																				ptr2 += 8;
																				break;
																			}
																			goto end_IL_0290;
																			continue;
																			end_IL_0280:
																			break;
																			IL_0280:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0290:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06e0;
													IL_06e0:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0634:
													break;
												}
												continue;
												end_IL_0647:
												break;
											}
											continue;
											end_IL_0651:
											break;
										}
										continue;
										end_IL_065c:
										break;
									}
									continue;
									end_IL_0671:
									break;
								}
								continue;
								end_IL_0681:
								break;
							}
							continue;
							end_IL_0691:
							break;
						}
						continue;
						end_IL_06a1:
						break;
					}
					continue;
					end_IL_06ba:
					break;
				}
				continue;
				end_IL_06c5:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1, int int_2)
	{
		int num = 50;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IDeserializationCallbackSerializationMonkey.getIsInitOnlyNestedFamily);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0319:
															byte b = *ptr2;
															while (true)
															{
																IL_0309:
																ptr2++;
																while (true)
																{
																	IL_02f9:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02d9:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02c9:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_02b9:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_02ac:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_028c:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0267:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_025b:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_024b:
																																num5++;
																																while (true)
																																{
																																	IL_0232:
																																	ptr2 += 8;
																																	num = 132;
																																	while (num != 132)
																																	{
																																		if (num != 1113)
																																		{
																																			goto end_IL_029c;
																																		}
																																		switch (num)
																																		{
																																		case 13:
																																			goto IL_0232;
																																		case 96:
																																			goto IL_024b;
																																		case 21:
																																			goto IL_025b;
																																		case 53:
																																			goto IL_0267;
																																		case 7:
																																		case 78:
																																			goto IL_028c;
																																		case 94:
																																			goto IL_029c;
																																		case 9:
																																		case 52:
																																			goto IL_02ac;
																																		case 48:
																																			goto IL_02b9;
																																		case 26:
																																		case 97:
																																			goto IL_02c9;
																																		case 91:
																																			goto IL_02d9;
																																		case 10:
																																			goto IL_02e9;
																																		case 104:
																																			goto IL_02f9;
																																		case 31:
																																			goto IL_0309;
																																		case 58:
																																		case 64:
																																			goto IL_0319;
																																		case 87:
																																			goto IL_0324;
																																		case 18:
																																			goto IL_0332;
																																		case 35:
																																		case 38:
																																			goto IL_0340;
																																		case 66:
																																			goto IL_0359;
																																		case 61:
																																			goto IL_0367;
																																		case 3:
																																			goto IL_0375;
																																		case 43:
																																		case 75:
																																			goto IL_0388;
																																		case 118:
																																			goto IL_03c8;
																																		case 46:
																																			goto IL_03e5;
																																		case 90:
																																		case 105:
																																			goto IL_03f8;
																																		case 76:
																																			goto IL_0406;
																																		case 14:
																																		case 98:
																																			goto IL_0411;
																																		case 68:
																																			goto IL_0424;
																																		case 124:
																																			goto IL_043d;
																																		case 36:
																																		case 39:
																																			goto IL_044b;
																																		case 56:
																																			goto IL_045f;
																																		case 54:
																																			goto IL_049e;
																																		case 41:
																																			goto IL_04b1;
																																		case 74:
																																			goto IL_04bf;
																																		case 82:
																																		case 114:
																																			goto IL_04cd;
																																		case 109:
																																			goto IL_04e9;
																																		case 44:
																																			goto IL_04f7;
																																		case 81:
																																		case 83:
																																			goto IL_0505;
																																		case 34:
																																		case 60:
																																			goto IL_0510;
																																		case 123:
																																			goto IL_051e;
																																		case 113:
																																		case 115:
																																			goto IL_052c;
																																		case 62:
																																			goto IL_0544;
																																		case 84:
																																		case 111:
																																			goto IL_0552;
																																		case 19:
																																			goto IL_057b;
																																		case 67:
																																			goto IL_0589;
																																		case 12:
																																			goto IL_059c;
																																		case 29:
																																		case 92:
																																			goto IL_05aa;
																																		case 80:
																																		case 117:
																																			goto IL_05b8;
																																		case 20:
																																			goto IL_05c6;
																																		case 79:
																																		case 102:
																																			goto IL_05d4;
																																		case 122:
																																			goto IL_0642;
																																		case 93:
																																			goto IL_0660;
																																		case 5:
																																		case 85:
																																			goto IL_066d;
																																		case 70:
																																			goto IL_06ad;
																																		case 15:
																																			goto IL_06c1;
																																		case 1:
																																		case 8:
																																		case 16:
																																		case 22:
																																		case 25:
																																		case 28:
																																		case 33:
																																		case 37:
																																		case 40:
																																		case 42:
																																		case 47:
																																		case 55:
																																		case 59:
																																		case 71:
																																		case 72:
																																		case 73:
																																		case 77:
																																		case 88:
																																		case 89:
																																		case 101:
																																		case 103:
																																		case 108:
																																		case 121:
																																			goto end_IL_029c;
																																		case 57:
																																			goto IL_06f4;
																																		case 116:
																																			goto IL_0702;
																																		case 125:
																																			goto IL_0710;
																																		case 0:
																																		case 6:
																																		case 11:
																																		case 17:
																																		case 23:
																																		case 27:
																																		case 51:
																																		case 65:
																																		case 69:
																																		case 95:
																																		case 99:
																																		case 100:
																																		case 107:
																																		case 120:
																																			goto end_IL_021f;
																																		case 63:
																																			goto end_IL_071e;
																																		case 106:
																																			goto end_IL_0731;
																																		case 110:
																																			goto end_IL_073b;
																																		case 4:
																																			goto end_IL_0746;
																																		case 30:
																																			goto end_IL_075b;
																																		case 45:
																																		case 119:
																																			goto end_IL_0770;
																																		case 2:
																																			goto end_IL_0780;
																																		case 24:
																																		case 112:
																																			goto end_IL_0790;
																																		case 49:
																																			goto end_IL_07a0;
																																		case 50:
																																			goto end_IL_07b0;
																																		case 32:
																																		case 86:
																																			goto IL_07cb;
																																		}
																																		continue;
																																		end_IL_021f:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02f9;
																												continue;
																												end_IL_029c:
																												break;
																												IL_029c:;
																											}
																											break;
																										}
																										goto IL_0324;
																										IL_0375:
																										ptr2 += 8;
																										goto end_IL_02f9;
																										IL_0324:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_0332;
																										IL_0332:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_0340;
																										IL_0340:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_0359;
																										IL_0359:
																										array[num5] = 0;
																										goto IL_0367;
																										IL_0367:
																										num5++;
																										goto IL_0375;
																									}
																									break;
																								}
																								goto IL_0388;
																								IL_03e5:
																								num5--;
																								goto end_IL_02f9;
																								IL_0388:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03c8;
																								IL_03c8:
																								array[num5 - 2] = 0;
																								num = 46;
																								goto IL_03e5;
																							}
																							break;
																						}
																						goto IL_03f8;
																						IL_04bf:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_04cd;
																						IL_03f8:
																						if (11 >= b)
																						{
																							goto IL_0406;
																						}
																						goto IL_04b1;
																						IL_0406:
																						if (11 <= b)
																						{
																							goto IL_0411;
																						}
																						goto IL_0424;
																						IL_0411:
																						num5--;
																						goto end_IL_02f9;
																						IL_0424:
																						if (10 < b)
																						{
																							num = 121;
																							break;
																						}
																						goto IL_043d;
																						IL_04cd:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02f9;
																						IL_043d:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_044b;
																						IL_044b:
																						array[num5 - 1] = 0;
																						goto IL_045f;
																						IL_045f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ApplicationUrlIBindableIterable[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_049e;
																						IL_049e:
																						ptr2 += 8;
																						goto end_IL_02f9;
																						IL_04b1:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_04bf;
																					}
																					break;
																				}
																				goto IL_04e9;
																				IL_06ad:
																				array[num5 - 2] = 0;
																				goto IL_06c1;
																				IL_04e9:
																				if (6 <= b)
																				{
																					goto end_IL_02f9;
																				}
																				goto IL_04f7;
																				IL_04f7:
																				if (3 < b)
																				{
																					goto IL_0505;
																				}
																				goto IL_059c;
																				IL_0505:
																				if (4 < b)
																				{
																					goto IL_0510;
																				}
																				goto IL_0544;
																				IL_0510:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_051e;
																				IL_051e:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_052c;
																				IL_052c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02f9;
																				IL_0544:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0552;
																				IL_0552:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_057b;
																				IL_057b:
																				ptr2 += 8;
																				goto IL_0589;
																				IL_0589:
																				num5--;
																				goto end_IL_02f9;
																				IL_059c:
																				if (3 > b)
																				{
																					goto IL_05aa;
																				}
																				goto IL_066d;
																				IL_05aa:
																				if (1 < b)
																				{
																					goto IL_05b8;
																				}
																				goto IL_0660;
																				IL_05b8:
																				if (2 < b)
																				{
																					num = 72;
																					break;
																				}
																				goto IL_05c6;
																				IL_05c6:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_05d4;
																				IL_05d4:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0642;
																				IL_0642:
																				num5 -= 2;
																				goto end_IL_02f9;
																				IL_06c1:
																				num5--;
																				goto end_IL_02f9;
																				IL_0660:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_066d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06ad;
																			}
																			break;
																			IL_02e9:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06f4;
																	IL_0710:
																	ptr2 += 8;
																	break;
																	IL_0702:
																	num5++;
																	goto IL_0710;
																	IL_06f4:
																	array[num5] = 0;
																	goto IL_0702;
																	continue;
																	end_IL_02f9:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07cb;
													IL_07cb:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_071e:
													break;
												}
												continue;
												end_IL_0731:
												break;
											}
											continue;
											end_IL_073b:
											break;
										}
										continue;
										end_IL_0746:
										break;
									}
									continue;
									end_IL_075b:
									break;
								}
								continue;
								end_IL_0770:
								break;
							}
							continue;
							end_IL_0780:
							break;
						}
						continue;
						end_IL_0790:
						break;
					}
					continue;
					end_IL_07a0:
					break;
				}
				continue;
				end_IL_07b0:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 83;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											num = 21;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setDigitSubstitutionMuiResourceTypeIdIntEntryFieldId.AccountCertAdminsSidGetSignerCertificate);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 32;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_01f0:
																			if (b >= 1)
																			{
																				while (b <= 8)
																				{
																					while (true)
																					{
																						IL_01d3:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_01c3:
																								if (6 < b)
																								{
																									while (true)
																									{
																										IL_01b0:
																										if (7 >= b)
																										{
																											num = 96;
																											while (true)
																											{
																												if (num != 96)
																												{
																													if (num != 1077)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 50:
																													case 61:
																														goto IL_01b0;
																													case 70:
																														goto IL_01c3;
																													case 55:
																														goto IL_01d3;
																													case 6:
																														goto end_IL_01d3;
																													case 17:
																														goto IL_01f0;
																													case 5:
																														goto end_IL_01f0;
																													case 37:
																													case 46:
																														goto end_IL_0200;
																													case 81:
																														goto IL_021b;
																													case 3:
																													case 44:
																														goto IL_0226;
																													case 27:
																														goto IL_024f;
																													case 34:
																														goto end_IL_019d;
																													case 7:
																														goto IL_0270;
																													case 16:
																													case 42:
																														goto IL_027b;
																													case 30:
																														goto IL_0289;
																													case 35:
																													case 80:
																														goto IL_0297;
																													case 15:
																														goto IL_02dc;
																													case 26:
																													case 28:
																														goto IL_02ea;
																													case 23:
																														goto IL_0358;
																													case 24:
																														goto IL_036b;
																													case 74:
																														goto IL_0379;
																													case 82:
																														goto IL_038c;
																													case 51:
																														goto IL_03a0;
																													case 2:
																													case 4:
																														goto IL_03c1;
																													case 65:
																														goto IL_03cf;
																													case 8:
																														goto IL_03f2;
																													case 22:
																														goto IL_03fc;
																													case 14:
																														goto IL_040a;
																													case 76:
																														goto IL_041d;
																													case 10:
																														goto IL_0428;
																													case 9:
																													case 59:
																														goto IL_0433;
																													case 78:
																														goto IL_044f;
																													case 18:
																														goto IL_045a;
																													case 11:
																														goto IL_0465;
																													case 47:
																													case 49:
																														goto IL_0470;
																													case 0:
																													case 12:
																													case 20:
																													case 40:
																													case 41:
																													case 45:
																													case 52:
																													case 56:
																													case 60:
																													case 62:
																													case 66:
																													case 68:
																													case 72:
																													case 73:
																													case 77:
																													case 79:
																													case 86:
																													case 87:
																													case 89:
																														goto end_IL_01e0;
																													case 67:
																														goto IL_04a8;
																													case 31:
																														goto IL_04b6;
																													case 54:
																														goto IL_04c4;
																													case 25:
																													case 32:
																													case 33:
																													case 48:
																													case 53:
																													case 57:
																													case 64:
																													case 69:
																													case 84:
																													case 85:
																														goto end_IL_0210;
																													case 88:
																														goto end_IL_04d2;
																													case 29:
																														goto end_IL_04e5;
																													case 21:
																														goto end_IL_04f0;
																													case 71:
																														goto end_IL_04fa;
																													case 36:
																														goto end_IL_0505;
																													case 1:
																														goto end_IL_0523;
																													case 19:
																													case 63:
																														goto end_IL_0538;
																													case 58:
																														goto end_IL_0548;
																													case 83:
																														goto end_IL_0558;
																													case 43:
																														goto end_IL_0568;
																													case 38:
																														goto end_IL_0578;
																													case 39:
																														goto end_IL_0583;
																													case 13:
																													case 75:
																														goto IL_059e;
																													}
																													continue;
																												}
																												if (7 > b)
																												{
																													goto end_IL_01e0;
																												}
																												goto IL_03c1;
																												IL_03f2:
																												array2[num5] = null;
																												goto IL_03fc;
																												IL_040a:
																												ptr2 += 8;
																												goto end_IL_0210;
																												IL_03fc:
																												num5++;
																												goto IL_040a;
																												IL_03c1:
																												array[num5] = 0;
																												goto IL_03cf;
																												IL_03cf:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_03f2;
																												continue;
																												end_IL_019d:
																												break;
																											}
																											break;
																										}
																										goto IL_041d;
																										IL_0428:
																										if (8 > b)
																										{
																											goto end_IL_01e0;
																										}
																										goto IL_0433;
																										IL_0433:
																										byte* num6 = ptr2;
																										num4 = 1;
																										ptr2 = num6 + -200;
																										goto end_IL_0210;
																										IL_041d:
																										if (8 < b)
																										{
																											goto end_IL_01e0;
																										}
																										goto IL_0428;
																									}
																									break;
																								}
																								goto IL_044f;
																								IL_0470:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0210;
																								IL_044f:
																								if (6 <= b)
																								{
																									goto end_IL_0210;
																								}
																								goto IL_045a;
																								IL_045a:
																								if (5 < b)
																								{
																									goto end_IL_01e0;
																								}
																								goto IL_0465;
																								IL_0465:
																								if (5 > b)
																								{
																									goto end_IL_01e0;
																								}
																								goto IL_0470;
																							}
																							goto IL_025d;
																						}
																						goto IL_021b;
																						IL_0379:
																						if (1 <= b)
																						{
																						}
																						goto end_IL_01e0;
																						IL_021b:
																						if (4 <= b)
																						{
																							goto IL_0226;
																						}
																						goto IL_0270;
																						IL_0226:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_024f;
																						IL_024f:
																						ptr2 += 8;
																						goto IL_025d;
																						IL_025d:
																						num5--;
																						goto end_IL_0210;
																						IL_0270:
																						if (2 < b)
																						{
																							goto IL_027b;
																						}
																						goto IL_02dc;
																						IL_027b:
																						if (3 < b)
																						{
																							goto end_IL_01e0;
																						}
																						goto IL_0289;
																						IL_0289:
																						if (3 > b)
																						{
																							goto end_IL_01e0;
																						}
																						goto IL_0297;
																						IL_0297:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_038c;
																						IL_038c:
																						array[num5 - 2] = 0;
																						goto IL_03a0;
																						IL_03a0:
																						num5--;
																						goto end_IL_0210;
																						IL_02dc:
																						if (2 <= b)
																						{
																							goto IL_02ea;
																						}
																						goto IL_036b;
																						IL_02ea:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0358;
																						IL_0358:
																						num5 -= 2;
																						goto end_IL_0210;
																						IL_036b:
																						if (1 < b)
																						{
																							goto end_IL_01e0;
																						}
																						goto IL_0379;
																						continue;
																						end_IL_01d3:
																						break;
																					}
																					continue;
																					end_IL_01e0:
																					break;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04a8;
																			IL_04c4:
																			ptr2 += 8;
																			goto end_IL_0210;
																			IL_04b6:
																			num5++;
																			goto IL_04c4;
																			IL_04a8:
																			array[num5] = 0;
																			goto IL_04b6;
																			continue;
																			end_IL_01f0:
																			break;
																		}
																		continue;
																		end_IL_0200:
																		break;
																	}
																	continue;
																	end_IL_0210:
																	break;
																}
																continue;
															}
															goto IL_059e;
															IL_059e:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															continue;
															end_IL_04d2:
															break;
														}
														continue;
														end_IL_04e5:
														break;
													}
													continue;
													end_IL_04f0:
													break;
												}
												continue;
												end_IL_04fa:
												break;
											}
											continue;
											end_IL_0505:
											break;
										}
										continue;
										end_IL_0523:
										break;
									}
									continue;
									end_IL_0538:
									break;
								}
								continue;
								end_IL_0548:
								break;
							}
							continue;
							end_IL_0558:
							break;
						}
						continue;
						end_IL_0568:
						break;
					}
					continue;
					end_IL_0578:
					break;
				}
				continue;
				end_IL_0583:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1, int int_2)
	{
		int num = 38;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MarshalDirectiveExceptionAssemblyVersionCompatibility.ManagedMaskgetEscapedCodeBase);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_024d:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 >= b)
																				{
																					while (true)
																					{
																						if (5 <= b)
																						{
																							while (true)
																							{
																								array[num5] = 0;
																								while (true)
																								{
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									num = 112;
																									while (true)
																									{
																										if (num != 112)
																										{
																											if (num == 1093)
																											{
																												switch (num)
																												{
																												case 31:
																													goto end_IL_01cf;
																												case 29:
																												case 81:
																													goto end_IL_01e2;
																												case 84:
																													goto end_IL_0210;
																												case 78:
																													goto end_IL_0220;
																												case 12:
																													goto end_IL_022d;
																												case 63:
																													goto IL_024d;
																												case 53:
																													goto end_IL_024d;
																												case 40:
																												case 93:
																													goto end_IL_025d;
																												case 47:
																													goto IL_0278;
																												case 61:
																													goto IL_028e;
																												case 54:
																													goto IL_0299;
																												case 16:
																												case 23:
																													goto IL_02ac;
																												case 39:
																													goto IL_02ba;
																												case 83:
																													goto IL_02d3;
																												case 41:
																												case 64:
																													goto IL_02e1;
																												case 36:
																													goto IL_032a;
																												case 62:
																													goto IL_033e;
																												case 77:
																												case 87:
																													goto IL_0351;
																												case 34:
																													goto IL_0391;
																												case 79:
																													goto IL_03a5;
																												case 58:
																												case 95:
																													goto IL_03c1;
																												case 101:
																													goto IL_03ea;
																												case 5:
																													goto IL_03f8;
																												case 28:
																												case 102:
																													goto IL_040b;
																												case 11:
																												case 92:
																													goto IL_0419;
																												case 18:
																													goto IL_0424;
																												case 4:
																													goto IL_0432;
																												case 6:
																												case 68:
																													goto IL_0440;
																												case 27:
																													goto IL_045c;
																												case 50:
																												case 69:
																													goto IL_0475;
																												case 24:
																													goto IL_04b5;
																												case 21:
																													goto IL_04d2;
																												case 90:
																													goto IL_04e5;
																												case 60:
																												case 67:
																													goto IL_04f3;
																												case 13:
																													goto IL_0501;
																												case 35:
																												case 56:
																													goto IL_050f;
																												case 9:
																													goto IL_054f;
																												case 57:
																													goto IL_0563;
																												case 33:
																												case 49:
																													goto IL_0576;
																												case 88:
																													goto IL_058f;
																												case 76:
																													goto IL_059d;
																												case 73:
																													goto IL_05ab;
																												case 25:
																												case 105:
																													goto IL_05be;
																												case 46:
																													goto IL_05c9;
																												case 52:
																													goto IL_05e0;
																												case 91:
																													goto IL_05ee;
																												case 1:
																												case 2:
																												case 10:
																												case 15:
																												case 17:
																												case 30:
																												case 55:
																												case 59:
																												case 66:
																												case 72:
																												case 74:
																												case 80:
																												case 82:
																												case 89:
																												case 97:
																												case 98:
																												case 103:
																												case 104:
																													goto end_IL_023d;
																												case 19:
																													goto IL_0621;
																												case 8:
																													goto IL_062f;
																												case 7:
																													goto IL_063d;
																												case 0:
																												case 3:
																												case 20:
																												case 22:
																												case 26:
																												case 32:
																												case 42:
																												case 44:
																												case 71:
																												case 85:
																												case 96:
																													goto end_IL_026d;
																												case 48:
																													goto end_IL_064b;
																												case 45:
																													goto end_IL_065e;
																												case 70:
																													goto end_IL_0668;
																												case 14:
																													goto end_IL_0673;
																												case 65:
																													goto end_IL_0688;
																												case 43:
																												case 51:
																													goto end_IL_069d;
																												case 99:
																													goto end_IL_06ad;
																												case 86:
																												case 94:
																													goto end_IL_06bd;
																												case 37:
																													goto end_IL_06cd;
																												case 38:
																													goto end_IL_06dd;
																												case 75:
																												case 100:
																													goto IL_06f8;
																												}
																												continue;
																											}
																										}
																										else
																										{
																											array2[num5] = null;
																										}
																										goto IL_05e0;
																										IL_05e0:
																										num5++;
																										goto IL_05ee;
																										IL_05ee:
																										ptr2 += 8;
																										goto end_IL_026d;
																										continue;
																										end_IL_01cf:
																										break;
																									}
																									continue;
																									end_IL_01e2:
																									break;
																								}
																								continue;
																								end_IL_0210:
																								break;
																							}
																							continue;
																						}
																						goto IL_0278;
																						IL_0351:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0391;
																						IL_0278:
																						if (2 < b)
																						{
																							goto IL_028e;
																						}
																						num = 83;
																						goto IL_02d3;
																						IL_0391:
																						array[num5 - 2] = 0;
																						goto IL_03a5;
																						IL_02d3:
																						if (2 <= b)
																						{
																							goto IL_02e1;
																						}
																						goto IL_05be;
																						IL_02e1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 36;
																						goto IL_032a;
																						IL_032a:
																						array[num5 - 2] = 0;
																						goto IL_033e;
																						IL_033e:
																						num5--;
																						goto end_IL_026d;
																						IL_05be:
																						if (1 < b)
																						{
																							goto end_IL_023d;
																						}
																						goto IL_05c9;
																						IL_05c9:
																						if (1 <= b)
																						{
																						}
																						goto end_IL_023d;
																						IL_028e:
																						if (3 >= b)
																						{
																							goto IL_0299;
																						}
																						goto IL_02ac;
																						IL_0299:
																						if (3 > b)
																						{
																							goto end_IL_023d;
																						}
																						goto IL_03c1;
																						IL_03c1:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03ea;
																						IL_03ea:
																						ptr2 += 8;
																						goto IL_03f8;
																						IL_03f8:
																						num5--;
																						goto end_IL_026d;
																						IL_02ac:
																						if (4 < b)
																						{
																							goto end_IL_023d;
																						}
																						goto IL_02ba;
																						IL_02ba:
																						if (4 > b)
																						{
																							goto end_IL_023d;
																						}
																						num = 87;
																						goto IL_0351;
																						IL_03a5:
																						num5--;
																						num = 20;
																						goto end_IL_026d;
																						continue;
																						end_IL_0220:
																						break;
																					}
																					continue;
																				}
																				goto IL_040b;
																				IL_059d:
																				num5++;
																				goto IL_05ab;
																				IL_040b:
																				if (7 < b)
																				{
																					goto IL_0419;
																				}
																				goto IL_04e5;
																				IL_0419:
																				if (8 < b)
																				{
																					goto IL_0424;
																				}
																				goto IL_045c;
																				IL_0424:
																				if (9 < b)
																				{
																					goto end_IL_023d;
																				}
																				goto IL_0432;
																				IL_0432:
																				if (9 > b)
																				{
																					goto end_IL_023d;
																				}
																				goto IL_0440;
																				IL_0440:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_026d;
																				IL_045c:
																				if (8 > b)
																				{
																					num = 30;
																					goto end_IL_023d;
																				}
																				goto IL_0475;
																				IL_05ab:
																				ptr2 += 8;
																				goto end_IL_026d;
																				IL_0475:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04b5;
																				IL_04b5:
																				array[num5 - 2] = 0;
																				num = 21;
																				goto IL_04d2;
																				IL_04d2:
																				num5--;
																				goto end_IL_026d;
																				IL_04e5:
																				if (7 > b)
																				{
																					goto IL_04f3;
																				}
																				goto IL_0576;
																				IL_04f3:
																				if (6 < b)
																				{
																					goto end_IL_023d;
																				}
																				goto IL_0501;
																				IL_0501:
																				if (6 > b)
																				{
																					goto end_IL_023d;
																				}
																				goto IL_050f;
																				IL_050f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_054f;
																				IL_054f:
																				array[num5 - 2] = 0;
																				goto IL_0563;
																				IL_0563:
																				num5--;
																				goto end_IL_026d;
																				IL_0576:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_058f;
																				IL_058f:
																				array[num5] = 0;
																				goto IL_059d;
																				continue;
																				end_IL_022d:
																				break;
																			}
																			continue;
																			end_IL_023d:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0621;
																	IL_063d:
																	ptr2 += 8;
																	goto end_IL_026d;
																	IL_062f:
																	num5++;
																	goto IL_063d;
																	IL_0621:
																	array[num5] = 0;
																	goto IL_062f;
																	continue;
																	end_IL_024d:
																	break;
																}
																continue;
																end_IL_025d:
																break;
															}
															continue;
															end_IL_026d:
															break;
														}
														continue;
													}
													goto IL_06f8;
													IL_06f8:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_064b:
													break;
												}
												continue;
												end_IL_065e:
												break;
											}
											continue;
											end_IL_0668:
											break;
										}
										continue;
										end_IL_0673:
										break;
									}
									continue;
									end_IL_0688:
									break;
								}
								continue;
								end_IL_069d:
								break;
							}
							continue;
							end_IL_06ad:
							break;
						}
						continue;
						end_IL_06bd:
						break;
					}
					continue;
					end_IL_06cd:
					break;
				}
				continue;
				end_IL_06dd:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 63;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 58;
							while (true)
							{
								int[] array3 = new int[3];
								num = 109;
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_1;
										num = 95;
										while (true)
										{
											array3[1] = int_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BatchSidResourceAttributes.ServicePackMinorgetLevel);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0274:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_0254:
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_0244:
																							if (9 < b)
																							{
																								num = 133;
																								while (true)
																								{
																									if (num != 133)
																									{
																										if (num != 1114)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 52:
																											goto IL_0244;
																										case 60:
																											goto IL_0254;
																										case 40:
																											goto IL_0264;
																										case 21:
																											goto IL_0274;
																										case 36:
																											goto end_IL_0274;
																										case 13:
																										case 117:
																											goto end_IL_0284;
																										case 20:
																											goto IL_029f;
																										case 27:
																										case 67:
																											goto IL_02aa;
																										case 72:
																											goto IL_02ef;
																										case 6:
																											goto IL_02fa;
																										case 55:
																										case 84:
																											goto IL_030a;
																										case 33:
																											goto IL_0318;
																										case 47:
																										case 94:
																											goto IL_0326;
																										case 76:
																											goto IL_033f;
																										case 5:
																										case 106:
																											goto IL_0358;
																										case 104:
																											goto IL_036f;
																										case 111:
																											goto IL_0394;
																										case 12:
																											goto IL_03a2;
																										case 114:
																											goto IL_03b5;
																										case 120:
																											goto IL_03c4;
																										case 66:
																											goto IL_03d8;
																										case 121:
																											goto IL_03eb;
																										case 108:
																											goto IL_03f9;
																										case 81:
																											goto IL_0407;
																										case 53:
																										case 70:
																											goto IL_0415;
																										case 22:
																										case 46:
																											goto IL_0423;
																										case 9:
																											goto IL_0431;
																										case 15:
																										case 89:
																											goto IL_043f;
																										case 0:
																											goto IL_04ad;
																										case 37:
																											goto IL_04c0;
																										case 16:
																										case 103:
																											goto IL_04d3;
																										case 73:
																											goto IL_0513;
																										case 79:
																											goto IL_0527;
																										case 123:
																											goto IL_0543;
																										case 38:
																											goto IL_0551;
																										case 80:
																										case 126:
																											goto IL_056d;
																										case 32:
																										case 42:
																											goto IL_0578;
																										case 113:
																											goto IL_058f;
																										case 24:
																										case 124:
																											goto IL_05a6;
																										case 19:
																											goto IL_05be;
																										case 112:
																										case 118:
																											goto IL_05cc;
																										case 43:
																											goto IL_05f5;
																										case 49:
																											goto IL_0603;
																										case 31:
																											goto IL_0616;
																										case 125:
																											goto IL_0624;
																										case 25:
																										case 59:
																											goto IL_062f;
																										case 30:
																										case 50:
																											goto IL_064b;
																										case 92:
																											goto IL_0659;
																										case 86:
																										case 88:
																											goto IL_0667;
																										case 62:
																											goto IL_067b;
																										case 18:
																											goto IL_06cf;
																										case 101:
																											goto IL_06dd;
																										case 96:
																										case 116:
																											goto IL_06f9;
																										case 83:
																											goto IL_0704;
																										case 10:
																										case 69:
																											goto IL_070f;
																										case 2:
																										case 17:
																										case 23:
																										case 26:
																										case 28:
																										case 29:
																										case 35:
																										case 41:
																										case 51:
																										case 68:
																										case 71:
																										case 82:
																										case 85:
																										case 90:
																										case 93:
																										case 98:
																										case 105:
																										case 107:
																										case 110:
																										case 115:
																										case 119:
																										case 122:
																											goto end_IL_0231;
																										case 100:
																											goto IL_074b;
																										case 61:
																											goto IL_0759;
																										case 44:
																											goto IL_0767;
																										case 3:
																										case 14:
																										case 34:
																										case 39:
																										case 45:
																										case 54:
																										case 56:
																										case 74:
																										case 77:
																										case 78:
																										case 87:
																										case 91:
																										case 97:
																										case 99:
																										case 102:
																											goto end_IL_0294;
																										case 11:
																											goto end_IL_0775;
																										case 65:
																											goto end_IL_0788;
																										case 95:
																											goto end_IL_0792;
																										case 7:
																											goto end_IL_079d;
																										case 109:
																											goto end_IL_07b2;
																										case 58:
																											goto end_IL_07d0;
																										case 48:
																											goto end_IL_07e0;
																										case 8:
																											goto end_IL_07f9;
																										case 1:
																										case 75:
																											goto end_IL_0804;
																										case 63:
																											goto end_IL_0814;
																										case 64:
																											goto end_IL_0824;
																										case 4:
																										case 57:
																											goto IL_0851;
																										}
																										continue;
																									}
																									goto IL_0616;
																									IL_0704:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_070f;
																									IL_06f9:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_0704;
																									IL_0616:
																									if (11 >= b)
																									{
																										goto IL_0624;
																									}
																									num = 96;
																									goto IL_06f9;
																									IL_0624:
																									if (11 <= b)
																									{
																										goto IL_062f;
																									}
																									num = 50;
																									goto IL_064b;
																									IL_062f:
																									num5--;
																									goto end_IL_0294;
																									IL_070f:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0294;
																									IL_064b:
																									if (10 < b)
																									{
																										break;
																									}
																									goto IL_0659;
																									IL_0659:
																									if (10 > b)
																									{
																										break;
																									}
																									goto IL_0667;
																									IL_0667:
																									array[num5 - 2] = 0;
																									goto IL_067b;
																									IL_067b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)DefineConstructorRemotePropertyHolderAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																									goto IL_06cf;
																									IL_06cf:
																									num5--;
																									goto IL_06dd;
																									IL_06dd:
																									ptr2 += 8;
																									goto end_IL_0294;
																									continue;
																									end_IL_0231:
																									break;
																								}
																								break;
																							}
																							goto IL_029f;
																							IL_0394:
																							num5++;
																							goto IL_03a2;
																							IL_03a2:
																							ptr2 += 8;
																							goto end_IL_0294;
																							IL_029f:
																							if (9 <= b)
																							{
																								goto IL_02aa;
																							}
																							goto IL_02ef;
																							IL_02aa:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03c4;
																							IL_03c4:
																							array[num5 - 2] = 0;
																							goto IL_03d8;
																							IL_03d8:
																							num5--;
																							goto end_IL_0294;
																							IL_02ef:
																							if (7 >= b)
																							{
																								goto IL_02fa;
																							}
																							goto IL_030a;
																							IL_02fa:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0358;
																							IL_0358:
																							array[num5] = 0;
																							num = 104;
																							goto IL_036f;
																							IL_036f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_03b5;
																							IL_03b5:
																							array2[num5] = null;
																							goto IL_0543;
																							IL_0543:
																							num5++;
																							goto IL_0551;
																							IL_0551:
																							ptr2 += 8;
																							num = 3;
																							goto end_IL_0294;
																							IL_030a:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_0318;
																							IL_0318:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0326;
																							IL_0326:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_033f;
																							IL_033f:
																							array[num5] = 0;
																							num = 111;
																							goto IL_0394;
																						}
																						break;
																					}
																					goto IL_03eb;
																					IL_05cc:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05f5;
																					IL_03eb:
																					if (6 <= b)
																					{
																						goto end_IL_0294;
																					}
																					goto IL_03f9;
																					IL_03f9:
																					if (3 >= b)
																					{
																						goto IL_0407;
																					}
																					goto IL_056d;
																					IL_0407:
																					if (3 > b)
																					{
																						goto IL_0415;
																					}
																					goto IL_04d3;
																					IL_0415:
																					if (1 < b)
																					{
																						goto IL_0423;
																					}
																					goto IL_04c0;
																					IL_0423:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_0431;
																					IL_0431:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_043f;
																					IL_043f:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_04ad;
																					IL_04ad:
																					num5 -= 2;
																					goto end_IL_0294;
																					IL_04c0:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_04d3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0513;
																					IL_0513:
																					array[num5 - 2] = 0;
																					goto IL_0527;
																					IL_0527:
																					num5--;
																					num = 99;
																					goto end_IL_0294;
																					IL_056d:
																					if (4 < b)
																					{
																						goto IL_0578;
																					}
																					goto IL_05be;
																					IL_0578:
																					if (5 < b)
																					{
																						break;
																					}
																					num = 113;
																					goto IL_058f;
																					IL_05f5:
																					ptr2 += 8;
																					goto IL_0603;
																					IL_058f:
																					if (5 > b)
																					{
																						break;
																					}
																					num = 24;
																					goto IL_05a6;
																					IL_0603:
																					num5--;
																					goto end_IL_0294;
																					IL_05a6:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0294;
																					IL_05be:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_05cc;
																				}
																				break;
																				IL_0264:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_074b;
																		IL_0767:
																		ptr2 += 8;
																		goto end_IL_0294;
																		IL_0759:
																		num5++;
																		goto IL_0767;
																		IL_074b:
																		array[num5] = 0;
																		goto IL_0759;
																		continue;
																		end_IL_0274:
																		break;
																	}
																	continue;
																	end_IL_0284:
																	break;
																}
																continue;
																end_IL_0294:
																break;
															}
															continue;
														}
														num = 57;
														goto IL_0851;
														IL_0851:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0775:
														break;
													}
													continue;
													end_IL_0788:
													break;
												}
												continue;
												end_IL_0792:
												break;
											}
											continue;
											end_IL_079d:
											break;
										}
										continue;
										end_IL_07b2:
										break;
									}
									continue;
									end_IL_07d0:
									break;
								}
								continue;
								end_IL_07e0:
								break;
							}
							continue;
							end_IL_07f9:
							break;
						}
						continue;
						end_IL_0804:
						break;
					}
					continue;
					end_IL_0814:
					break;
				}
				continue;
				end_IL_0824:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1)
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsDSMemberName.RemotingConfigInfoISerializable);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_030f:
														byte b = *ptr2;
														while (true)
														{
															IL_02f6:
															ptr2++;
															num = 59;
															while (true)
															{
																IL_02e6:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02c9:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_02b9:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_02a9:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0299:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_0269:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0244:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_022f:
																															array2[num5] = null;
																															num = 68;
																															while (true)
																															{
																																IL_021f:
																																num5++;
																																while (true)
																																{
																																	IL_0206:
																																	ptr2 += 8;
																																	num = 121;
																																	while (num != 121)
																																	{
																																		if (num != 1102)
																																		{
																																			goto IL_031a;
																																		}
																																		switch (num)
																																		{
																																		case 92:
																																			goto IL_0206;
																																		case 68:
																																			goto IL_021f;
																																		case 71:
																																			goto IL_022f;
																																		case 20:
																																			goto IL_0244;
																																		case 30:
																																		case 101:
																																			goto IL_0269;
																																		case 23:
																																			goto IL_0279;
																																		case 12:
																																		case 25:
																																			goto IL_0289;
																																		case 75:
																																			goto IL_0299;
																																		case 14:
																																			goto IL_02a9;
																																		case 96:
																																			goto IL_02b9;
																																		case 105:
																																			goto IL_02c9;
																																		case 57:
																																			goto IL_02d6;
																																		case 59:
																																			goto IL_02e6;
																																		case 114:
																																			goto IL_02f6;
																																		case 38:
																																		case 103:
																																			goto IL_030f;
																																		case 18:
																																		case 56:
																																			goto IL_031a;
																																		case 10:
																																			goto IL_032e;
																																		case 35:
																																			goto IL_0347;
																																		case 22:
																																			goto IL_0355;
																																		case 15:
																																		case 60:
																																			goto IL_0368;
																																		case 61:
																																			goto IL_03cc;
																																		case 37:
																																			goto IL_03d7;
																																		case 11:
																																			goto IL_03e2;
																																		case 5:
																																		case 32:
																																			goto IL_0403;
																																		case 81:
																																			goto IL_041b;
																																		case 53:
																																		case 83:
																																			goto IL_042e;
																																		case 88:
																																			goto IL_044a;
																																		case 36:
																																			goto IL_0455;
																																		case 9:
																																			goto IL_0468;
																																		case 42:
																																			goto IL_0476;
																																		case 97:
																																			goto IL_0486;
																																		case 79:
																																		case 82:
																																			goto IL_0494;
																																		case 40:
																																			goto IL_04b6;
																																		case 69:
																																			goto IL_04c4;
																																		case 72:
																																			goto IL_04d2;
																																		case 84:
																																		case 100:
																																			goto IL_04ee;
																																		case 49:
																																			goto IL_0511;
																																		case 95:
																																			goto IL_051f;
																																		case 80:
																																		case 102:
																																			goto IL_0532;
																																		case 43:
																																			goto IL_0572;
																																		case 26:
																																			goto IL_0586;
																																		case 98:
																																		case 106:
																																			goto IL_0599;
																																		case 46:
																																			goto IL_05d9;
																																		case 45:
																																			goto IL_05ed;
																																		case 108:
																																			goto IL_0600;
																																		case 13:
																																		case 64:
																																			goto IL_060e;
																																		case 28:
																																			goto IL_0637;
																																		case 1:
																																			goto IL_0645;
																																		case 66:
																																		case 111:
																																			goto IL_0655;
																																		case 21:
																																			goto IL_0660;
																																		case 113:
																																			goto IL_066d;
																																		case 58:
																																			goto IL_067d;
																																		case 0:
																																		case 4:
																																		case 6:
																																		case 8:
																																		case 19:
																																		case 27:
																																		case 39:
																																		case 41:
																																		case 47:
																																		case 50:
																																		case 62:
																																		case 63:
																																		case 65:
																																		case 67:
																																		case 76:
																																		case 86:
																																		case 87:
																																		case 89:
																																		case 91:
																																		case 93:
																																		case 104:
																																		case 107:
																																		case 109:
																																		case 110:
																																			goto end_IL_0279;
																																		case 2:
																																		case 7:
																																		case 16:
																																		case 17:
																																		case 24:
																																		case 31:
																																		case 34:
																																		case 54:
																																		case 73:
																																		case 85:
																																		case 94:
																																		case 99:
																																		case 112:
																																			goto end_IL_01f3;
																																		case 52:
																																			goto end_IL_06a6;
																																		case 3:
																																			goto end_IL_06b9;
																																		case 44:
																																			goto end_IL_06c3;
																																		case 33:
																																			goto end_IL_06ce;
																																		case 29:
																																		case 55:
																																			goto end_IL_06e3;
																																		case 51:
																																			goto end_IL_06f3;
																																		case 74:
																																		case 90:
																																			goto end_IL_0703;
																																		case 77:
																																			goto end_IL_0713;
																																		case 78:
																																			goto end_IL_0723;
																																		case 48:
																																		case 70:
																																			goto IL_073e;
																																		}
																																		continue;
																																		end_IL_01f3:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02e6;
																												continue;
																												end_IL_0279:
																												break;
																												IL_0279:;
																											}
																											break;
																											IL_0289:;
																										}
																										break;
																									}
																									goto IL_067d;
																									IL_067d:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02e6;
																								}
																								break;
																							}
																							goto IL_03cc;
																							IL_04d2:
																							ptr2 += 8;
																							num = 94;
																							goto end_IL_02e6;
																							IL_03cc:
																							if (3 > b)
																							{
																								goto IL_03d7;
																							}
																							goto IL_0403;
																							IL_03d7:
																							if (1 < b)
																							{
																								goto IL_03e2;
																							}
																							num = 97;
																							goto IL_0486;
																							IL_03e2:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0600;
																							IL_0600:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_060e;
																							IL_060e:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0637;
																							IL_0637:
																							ptr2 += 8;
																							goto IL_0645;
																							IL_0645:
																							num5--;
																							goto end_IL_02e6;
																							IL_0403:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02e6;
																							IL_0486:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0494;
																							IL_0494:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							num = 40;
																							goto IL_04b6;
																							IL_04b6:
																							array[num5] = 0;
																							goto IL_04c4;
																							IL_04c4:
																							num5++;
																							goto IL_04d2;
																						}
																						break;
																					}
																					goto IL_0532;
																					IL_0586:
																					num5--;
																					goto end_IL_02e6;
																					IL_0532:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0572;
																					IL_0572:
																					array[num5 - 2] = 0;
																					goto IL_0586;
																				}
																				break;
																			}
																			goto IL_031a;
																			IL_042e:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02e6;
																			IL_031a:
																			if (9 >= b)
																			{
																				num = 10;
																				goto IL_032e;
																			}
																			goto IL_0347;
																			IL_0655:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0660;
																			IL_032e:
																			if (9 <= b)
																			{
																				num = 15;
																				goto IL_0368;
																			}
																			goto IL_044a;
																			IL_0660:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_0368:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_041b;
																			IL_041b:
																			num5 -= 2;
																			goto end_IL_02e6;
																			IL_044a:
																			if (7 >= b)
																			{
																				goto IL_0455;
																			}
																			goto IL_0468;
																			IL_0455:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0599;
																			IL_0599:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05d9;
																			IL_05d9:
																			array[num5 - 2] = 0;
																			goto IL_05ed;
																			IL_05ed:
																			num5--;
																			goto end_IL_02e6;
																			IL_0468:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0476;
																			IL_0476:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_04ee;
																			IL_04ee:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0511;
																			IL_0511:
																			array[num5] = 0;
																			goto IL_051f;
																			IL_051f:
																			num5++;
																			goto IL_066d;
																			IL_066d:
																			ptr2 += 8;
																			goto end_IL_02e6;
																			IL_0347:
																			if (10 >= b)
																			{
																				goto IL_0355;
																			}
																			goto IL_0655;
																			IL_0355:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_042e;
																		}
																		break;
																		IL_02d6:;
																	}
																}
																else
																{
																	num = 109;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02e6:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_073e;
												IL_073e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06a6:
												break;
											}
											continue;
											end_IL_06b9:
											break;
										}
										continue;
										end_IL_06c3:
										break;
									}
									continue;
									end_IL_06ce:
									break;
								}
								continue;
								end_IL_06e3:
								break;
							}
							continue;
							end_IL_06f3:
							break;
						}
						continue;
						end_IL_0703:
						break;
					}
					continue;
					end_IL_0713:
					break;
				}
				continue;
				end_IL_0723:
				break;
			}
		}
	}

	private static int smethod_6(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		num += num2;
		int num3 = num;
		num = int_1;
		num2 = int_2;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 355;
		num2 = 71;
		num += 71;
		num2 = 120;
		num2 = 24;
		int num6 = smethod_0(24);
		num2 = num6;
		return num;
	}

	private unsafe static int smethod_7()
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 44;
								while (true)
								{
									object[] array5 = new object[1];
									num = 24;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IUnknownConstantAttributegetBlockSizeValue.setAsRSoapAnyUri);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_037f:
														num = 66;
														while (true)
														{
															IL_0374:
															byte b = *ptr2;
															while (true)
															{
																IL_0364:
																ptr2++;
																while (true)
																{
																	IL_0354:
																	if (b >= 1)
																	{
																		while (b <= 17)
																		{
																			while (true)
																			{
																				IL_0334:
																				if (9 >= b)
																				{
																					while (9 > b)
																					{
																						while (true)
																						{
																							IL_0314:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_0304:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_02f1:
																											if (6 > b)
																											{
																												num = 79;
																												while (true)
																												{
																													IL_02de:
																													if (5 < b)
																													{
																														num = 168;
																														while (num != 168)
																														{
																															if (num != 1149)
																															{
																																goto end_IL_0324;
																															}
																															switch (num)
																															{
																															case 53:
																															case 79:
																																goto IL_02de;
																															case 80:
																																goto IL_02f1;
																															case 155:
																																goto IL_0304;
																															case 57:
																																goto IL_0314;
																															case 77:
																																goto IL_0324;
																															case 9:
																																goto IL_0334;
																															case 7:
																																goto IL_0344;
																															case 0:
																																goto IL_0354;
																															case 65:
																																goto IL_0364;
																															case 66:
																																goto IL_0374;
																															case 106:
																																goto IL_037f;
																															case 18:
																																goto IL_038a;
																															case 88:
																															case 128:
																																goto IL_039d;
																															case 12:
																																goto IL_03dc;
																															case 141:
																																goto IL_03ef;
																															case 59:
																															case 72:
																																goto IL_03fa;
																															case 131:
																																goto IL_0418;
																															case 87:
																																goto IL_0426;
																															case 112:
																															case 152:
																																goto IL_0442;
																															case 127:
																																goto IL_0450;
																															case 46:
																															case 147:
																																goto IL_045b;
																															case 62:
																																goto IL_0469;
																															case 19:
																															case 43:
																																goto IL_0477;
																															case 41:
																																goto IL_0490;
																															case 116:
																																goto IL_049e;
																															case 68:
																																goto IL_04ac;
																															case 99:
																															case 140:
																																goto IL_04bf;
																															case 52:
																																goto IL_04ff;
																															case 136:
																																goto IL_0513;
																															case 145:
																																goto IL_0526;
																															case 94:
																																goto IL_0534;
																															case 113:
																															case 130:
																																goto IL_0542;
																															case 31:
																																goto IL_056b;
																															case 47:
																															case 157:
																																goto IL_0584;
																															case 54:
																																goto IL_0592;
																															case 37:
																																goto IL_05aa;
																															case 93:
																																goto IL_05c1;
																															case 67:
																															case 92:
																																goto IL_05dd;
																															case 1:
																															case 135:
																																goto IL_05e8;
																															case 22:
																																goto IL_05f6;
																															case 39:
																															case 110:
																																goto IL_0604;
																															case 97:
																																goto IL_061c;
																															case 33:
																															case 119:
																																goto IL_062a;
																															case 28:
																																goto IL_065c;
																															case 11:
																																goto IL_066a;
																															case 55:
																																goto IL_067d;
																															case 50:
																															case 103:
																																goto IL_068b;
																															case 71:
																																goto IL_0699;
																															case 108:
																																goto IL_06a7;
																															case 122:
																																goto IL_06b5;
																															case 85:
																															case 150:
																																goto IL_06c3;
																															case 40:
																																goto IL_06d7;
																															case 2:
																																goto IL_0716;
																															case 38:
																															case 64:
																																goto IL_0729;
																															case 69:
																															case 111:
																																goto IL_0745;
																															case 125:
																																goto IL_0759;
																															case 20:
																															case 151:
																																goto IL_0767;
																															case 49:
																																goto IL_0783;
																															case 134:
																																goto IL_0791;
																															case 149:
																																goto IL_07ad;
																															case 27:
																															case 95:
																																goto IL_07b8;
																															case 78:
																																goto IL_081a;
																															case 81:
																																goto IL_082d;
																															case 61:
																																goto IL_083b;
																															case 26:
																															case 91:
																																goto IL_0846;
																															case 104:
																																goto IL_088a;
																															case 48:
																																goto IL_089e;
																															case 156:
																																goto IL_08b1;
																															case 34:
																																goto IL_08bf;
																															case 75:
																															case 105:
																																goto IL_08cd;
																															case 120:
																																goto IL_08db;
																															case 76:
																																goto IL_08fe;
																															case 58:
																																goto IL_0908;
																															case 17:
																																goto IL_0916;
																															case 36:
																																goto IL_0929;
																															case 35:
																																goto IL_0934;
																															case 107:
																															case 159:
																																goto IL_093f;
																															case 70:
																																goto IL_097f;
																															case 143:
																																goto IL_0993;
																															case 8:
																															case 13:
																															case 14:
																															case 15:
																															case 21:
																															case 29:
																															case 30:
																															case 42:
																															case 56:
																															case 63:
																															case 82:
																															case 86:
																															case 90:
																															case 101:
																															case 102:
																															case 117:
																															case 124:
																															case 126:
																															case 132:
																															case 133:
																															case 137:
																															case 138:
																															case 144:
																															case 153:
																															case 154:
																															case 158:
																															case 160:
																															case 161:
																																goto end_IL_02cb;
																															case 5:
																															case 6:
																															case 10:
																															case 16:
																															case 23:
																															case 32:
																															case 73:
																															case 74:
																															case 83:
																															case 84:
																															case 89:
																															case 96:
																															case 100:
																															case 109:
																															case 115:
																															case 121:
																															case 123:
																															case 129:
																															case 139:
																															case 142:
																																goto end_IL_0324;
																															case 60:
																																goto end_IL_09bf;
																															case 24:
																																goto end_IL_09d2;
																															case 44:
																																goto end_IL_09dc;
																															case 118:
																																goto end_IL_09e7;
																															case 45:
																															case 51:
																																goto end_IL_0a00;
																															case 148:
																																goto end_IL_0a19;
																															case 25:
																															case 146:
																																goto end_IL_0a29;
																															case 3:
																																goto end_IL_0a39;
																															case 4:
																																goto end_IL_0a49;
																															case 98:
																															case 114:
																																goto IL_0a64;
																															}
																															continue;
																															end_IL_02cb:
																															break;
																														}
																														break;
																													}
																													goto IL_038a;
																													IL_05aa:
																													num5++;
																													num = 93;
																													goto IL_05c1;
																													IL_05c1:
																													ptr2 += 8;
																													goto end_IL_0324;
																													IL_038a:
																													if (5 > b)
																													{
																														break;
																													}
																													goto IL_0584;
																													IL_0584:
																													array[num5] = 5;
																													goto IL_0592;
																													IL_0592:
																													array2[num5] = array5[*(int*)(ptr2 + num3)];
																													goto IL_05aa;
																												}
																												break;
																											}
																											goto IL_039d;
																											IL_039d:
																											((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_03dc;
																											IL_03dc:
																											num5 -= 3;
																											goto end_IL_0324;
																										}
																										break;
																									}
																									num = 67;
																									goto IL_05dd;
																									IL_065c:
																									ptr2 += 8;
																									goto IL_066a;
																									IL_066a:
																									num5--;
																									goto end_IL_0324;
																									IL_05dd:
																									if (7 < b)
																									{
																										goto IL_05e8;
																									}
																									goto IL_061c;
																									IL_05e8:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_05f6;
																									IL_05f6:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_0604;
																									IL_0604:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0324;
																									IL_061c:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_062a;
																									IL_062a:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 28;
																									goto IL_065c;
																								}
																								break;
																							}
																							goto IL_03ef;
																							IL_0542:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_056b;
																							IL_03ef:
																							if (4 <= b)
																							{
																								goto IL_03fa;
																							}
																							num = 152;
																							goto IL_0442;
																							IL_03fa:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_0418;
																							IL_0418:
																							ptr2 += 8;
																							goto IL_0426;
																							IL_0426:
																							num5--;
																							goto end_IL_0324;
																							IL_056b:
																							array[num5 - 1] = 5;
																							goto end_IL_0324;
																							IL_0442:
																							if (2 >= b)
																							{
																								goto IL_0450;
																							}
																							goto IL_0526;
																							IL_0450:
																							if (2 > b)
																							{
																								goto IL_045b;
																							}
																							goto IL_04bf;
																							IL_045b:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0469;
																							IL_0469:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0477;
																							IL_0477:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0490;
																							IL_0490:
																							array[num5] = 0;
																							goto IL_049e;
																							IL_049e:
																							num5++;
																							goto IL_04ac;
																							IL_04ac:
																							ptr2 += 8;
																							goto end_IL_0324;
																							IL_04bf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04ff;
																							IL_04ff:
																							array[num5 - 2] = 0;
																							goto IL_0513;
																							IL_0513:
																							num5--;
																							goto end_IL_0324;
																							IL_0526:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0534;
																							IL_0534:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0542;
																						}
																						goto end_IL_0344;
																						continue;
																						end_IL_0324:
																						break;
																						IL_0324:;
																					}
																					break;
																				}
																				goto IL_067d;
																				IL_0934:
																				if (12 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_093f;
																				IL_067d:
																				if (13 < b)
																				{
																					goto IL_068b;
																				}
																				goto IL_07ad;
																				IL_068b:
																				if (15 >= b)
																				{
																					goto IL_0699;
																				}
																				num = 69;
																				goto IL_0745;
																				IL_0699:
																				if (15 > b)
																				{
																					goto IL_06a7;
																				}
																				goto IL_0729;
																				IL_06a7:
																				if (14 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_06b5;
																				IL_06b5:
																				if (14 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_06c3;
																				IL_06c3:
																				array[num5 - 1] = 0;
																				goto IL_06d7;
																				IL_06d7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SecurityRegistryPermissionRemoveAll[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0716;
																				IL_0716:
																				ptr2 += 8;
																				break;
																				IL_0729:
																				num5--;
																				break;
																				IL_093f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_097f;
																				IL_0745:
																				if (16 >= b)
																				{
																					num = 125;
																					goto IL_0759;
																				}
																				goto IL_0783;
																				IL_097f:
																				array[num5 - 2] = 0;
																				goto IL_0993;
																				IL_0759:
																				if (16 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_0767;
																				IL_0767:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0783:
																				if (17 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_0791;
																				IL_0791:
																				if (17 <= b)
																				{
																					num = 133;
																				}
																				goto end_IL_0344;
																				IL_0993:
																				num5--;
																				num = 74;
																				break;
																				IL_07ad:
																				if (13 <= b)
																				{
																					goto IL_07b8;
																				}
																				goto IL_082d;
																				IL_07b8:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_081a;
																				IL_081a:
																				num5 -= 2;
																				break;
																				IL_082d:
																				if (11 >= b)
																				{
																					goto IL_083b;
																				}
																				goto IL_0929;
																				IL_083b:
																				if (11 <= b)
																				{
																					goto IL_0846;
																				}
																				goto IL_08b1;
																				IL_0846:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_088a;
																				IL_088a:
																				array[num5 - 2] = 0;
																				goto IL_089e;
																				IL_089e:
																				num5--;
																				break;
																				IL_08b1:
																				if (10 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_08bf;
																				IL_08bf:
																				if (10 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_08cd;
																				IL_08cd:
																				array[num5] = 0;
																				goto IL_08db;
																				IL_08db:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_08fe;
																				IL_08fe:
																				array2[num5] = null;
																				goto IL_0908;
																				IL_0908:
																				num5++;
																				goto IL_0916;
																				IL_0916:
																				ptr2 += 8;
																				break;
																				IL_0929:
																				if (12 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_0934;
																			}
																			goto end_IL_0354;
																			continue;
																			end_IL_0344:
																			break;
																			IL_0344:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0354:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a64;
												IL_0a64:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09bf:
												break;
											}
											continue;
											end_IL_09d2:
											break;
										}
										continue;
										end_IL_09dc:
										break;
									}
									continue;
									end_IL_09e7:
									break;
								}
								continue;
								end_IL_0a00:
								break;
							}
							continue;
							end_IL_0a19:
							break;
						}
						continue;
						end_IL_0a29:
						break;
					}
					continue;
					end_IL_0a39:
					break;
				}
				continue;
				end_IL_0a49:
				break;
			}
		}
	}

	static Class137()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 6;
					while (true)
					{
						num = 3;
						while (true)
						{
							IL_0055:
							num = 15;
							while (true)
							{
								if (num != 15)
								{
									if (num != 996)
									{
										break;
									}
									switch (num)
									{
									case 3:
										goto IL_0055;
									case 4:
									case 6:
										goto end_IL_0048;
									case 2:
									case 5:
									case 7:
									case 8:
										goto end_IL_0061;
									case 0:
										goto end_IL_0070;
									case 1:
										goto end_IL_0085;
									}
									continue;
								}
								return;
								continue;
								end_IL_0048:
								break;
							}
							break;
						}
						continue;
						end_IL_0061:
						break;
					}
					continue;
					end_IL_0070:
					break;
				}
				continue;
				end_IL_0085:
				break;
			}
		}
	}
}
