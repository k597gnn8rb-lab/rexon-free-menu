using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gadget Sphere Medium", "Super Infection/Casual [MASTERCLIENT]", "Spawns medium gadget sphere.", true, 23, ModType.const_1, false)]
internal class Class119 : MonoBehaviour
{
	private static float float_0;

	private static bool bool_0;

	private static int int_0;

	private static bool bool_1;

	private static float float_1;

	private static Vector3 ClipboardGetReference;

	private static Quaternion ForAllMemberType;

	private static GameEntityCreateData getNamedPermissionSetsFieldInfo;

	private static IntPtr[] CurrencyNegativePatternCallerFilePathAttribute;

	private static IntPtr[] DelegateSealed;

	private static IntPtr[] intptr_0;

	private unsafe void OnEnable()
	{
		int num = 228;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								int[] array4 = new int[9];
								while (true)
								{
									long[] array5 = new long[3];
									while (true)
									{
										object[] array6 = new object[9];
										while (true)
										{
											array6[0] = this;
											while (true)
											{
												array6[1] = ClipboardGetReference;
												while (true)
												{
													array6[5] = ClipboardGetReference;
													while (true)
													{
														array6[6] = ForAllMemberType;
														while (true)
														{
															array6[7] = ClipboardGetReference;
															while (true)
															{
																array6[8] = getNamedPermissionSetsFieldInfo;
																while (true)
																{
																	byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getInvocationListCreateCustomTimeZone.NoDefineVersionResourceSingleArrayTypeInfo);
																	while (true)
																	{
																		byte* ptr2 = ptr;
																		while (true)
																		{
																			if (num4 == 1)
																			{
																				return;
																			}
																			while (true)
																			{
																				IL_0a34:
																				byte b = *ptr2;
																				while (true)
																				{
																					IL_0a24:
																					ptr2++;
																					while (true)
																					{
																						IL_0a14:
																						if (b >= 1)
																						{
																							while (b <= 66)
																							{
																								while (true)
																								{
																									IL_09f4:
																									if (33 >= b)
																									{
																										while (true)
																										{
																											IL_09e4:
																											if (33 > b)
																											{
																												while (true)
																												{
																													IL_09d4:
																													if (16 >= b)
																													{
																														while (true)
																														{
																															IL_09c4:
																															if (16 > b)
																															{
																																while (true)
																																{
																																	IL_09b7:
																																	if (8 < b)
																																	{
																																		while (true)
																																		{
																																			IL_09a7:
																																			if (12 >= b)
																																			{
																																				while (true)
																																				{
																																					IL_0997:
																																					if (12 > b)
																																					{
																																						while (true)
																																						{
																																							IL_0987:
																																							if (10 >= b)
																																							{
																																								while (true)
																																								{
																																									IL_0977:
																																									if (10 <= b)
																																									{
																																										while (true)
																																										{
																																											IL_0913:
																																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																											while (true)
																																											{
																																												IL_08fa:
																																												num5 -= 2;
																																												num = 566;
																																												while (num != 566)
																																												{
																																													if (num != 1547)
																																													{
																																														goto IL_22c8;
																																													}
																																													switch (num)
																																													{
																																													case 175:
																																														goto IL_08fa;
																																													case 31:
																																													case 507:
																																														goto IL_0913;
																																													case 118:
																																														goto IL_0977;
																																													case 524:
																																														goto IL_0987;
																																													case 220:
																																														goto IL_0997;
																																													case 239:
																																														goto IL_09a7;
																																													case 458:
																																														goto IL_09b7;
																																													case 197:
																																														goto IL_09c4;
																																													case 386:
																																														goto IL_09d4;
																																													case 469:
																																														goto IL_09e4;
																																													case 498:
																																														goto IL_09f4;
																																													case 217:
																																														goto IL_0a04;
																																													case 65:
																																														goto IL_0a14;
																																													case 22:
																																														goto IL_0a24;
																																													case 212:
																																													case 482:
																																														goto IL_0a34;
																																													case 219:
																																														goto IL_0a3f;
																																													case 44:
																																														goto IL_0a4a;
																																													case 157:
																																														goto IL_0a55;
																																													case 195:
																																														goto IL_0a63;
																																													case 47:
																																														goto IL_0a71;
																																													case 13:
																																													case 46:
																																														goto IL_0a84;
																																													case 258:
																																														goto IL_0a97;
																																													case 366:
																																														goto IL_0aa5;
																																													case 199:
																																														goto IL_0ab0;
																																													case 2:
																																														goto IL_0acc;
																																													case 16:
																																													case 150:
																																														goto IL_0ad7;
																																													case 162:
																																														goto IL_0b17;
																																													case 273:
																																														goto IL_0b2b;
																																													case 382:
																																														goto IL_0b3e;
																																													case 152:
																																														goto IL_0b4c;
																																													case 441:
																																														goto IL_0b5f;
																																													case 64:
																																													case 168:
																																														goto IL_0b6a;
																																													case 391:
																																														goto IL_0baa;
																																													case 78:
																																														goto IL_0bbe;
																																													case 286:
																																														goto IL_0bd1;
																																													case 67:
																																														goto IL_0bdf;
																																													case 48:
																																													case 414:
																																														goto IL_0bed;
																																													case 8:
																																														goto IL_0c2d;
																																													case 297:
																																														goto IL_0c41;
																																													case 410:
																																													case 442:
																																														goto IL_0c54;
																																													case 173:
																																														goto IL_0c9d;
																																													case 353:
																																														goto IL_0cb1;
																																													case 479:
																																														goto IL_0cc4;
																																													case 21:
																																													case 292:
																																														goto IL_0cd2;
																																													case 316:
																																														goto IL_0cfb;
																																													case 129:
																																														goto IL_0d09;
																																													case 110:
																																													case 494:
																																														goto IL_0d1c;
																																													case 120:
																																													case 496:
																																														goto IL_0d7f;
																																													case 513:
																																														goto IL_0d98;
																																													case 433:
																																														goto IL_0da6;
																																													case 380:
																																														goto IL_0db4;
																																													case 400:
																																													case 548:
																																														goto IL_0dd0;
																																													case 337:
																																														goto IL_0dde;
																																													case 176:
																																														goto IL_0e01;
																																													case 244:
																																														goto IL_0e0b;
																																													case 315:
																																														goto IL_0e22;
																																													case 550:
																																														goto IL_0e35;
																																													case 302:
																																														goto IL_0e48;
																																													case 37:
																																														goto IL_0e56;
																																													case 66:
																																													case 473:
																																														goto IL_0e64;
																																													case 81:
																																														goto IL_0ea4;
																																													case 517:
																																														goto IL_0eb8;
																																													case 24:
																																														goto IL_0ecb;
																																													case 248:
																																														goto IL_0ed9;
																																													case 207:
																																													case 334:
																																														goto IL_0eec;
																																													case 436:
																																														goto IL_0f03;
																																													case 522:
																																														goto IL_0f27;
																																													case 559:
																																														goto IL_0f35;
																																													case 105:
																																														goto IL_0f48;
																																													case 288:
																																														goto IL_0f56;
																																													case 369:
																																														goto IL_0f64;
																																													case 234:
																																														goto IL_0f72;
																																													case 102:
																																													case 306:
																																														goto IL_0f80;
																																													case 493:
																																														goto IL_0fdb;
																																													case 325:
																																													case 545:
																																														goto IL_0fee;
																																													case 374:
																																														goto IL_0ffc;
																																													case 224:
																																														goto IL_1020;
																																													case 229:
																																														goto IL_102e;
																																													case 12:
																																														goto IL_1041;
																																													case 411:
																																														goto IL_104f;
																																													case 39:
																																													case 453:
																																														goto IL_105d;
																																													case 415:
																																														goto IL_106b;
																																													case 408:
																																														goto IL_108f;
																																													case 423:
																																														goto IL_109d;
																																													case 139:
																																														goto IL_10b0;
																																													case 179:
																																														goto IL_10be;
																																													case 72:
																																													case 76:
																																														goto IL_10c9;
																																													case 166:
																																														goto IL_10dd;
																																													case 225:
																																														goto IL_111a;
																																													case 495:
																																														goto IL_112d;
																																													case 467:
																																														goto IL_113b;
																																													case 135:
																																													case 377:
																																														goto IL_1146;
																																													case 5:
																																														goto IL_115b;
																																													case 407:
																																														goto IL_116e;
																																													case 149:
																																														goto IL_117c;
																																													case 90:
																																													case 117:
																																														goto IL_1187;
																																													case 510:
																																														goto IL_11b0;
																																													case 492:
																																														goto IL_11be;
																																													case 259:
																																														goto IL_11d1;
																																													case 536:
																																														goto IL_11df;
																																													case 180:
																																													case 451:
																																														goto IL_11ed;
																																													case 406:
																																														goto IL_120e;
																																													case 389:
																																														goto IL_121c;
																																													case 181:
																																														goto IL_122a;
																																													case 271:
																																														goto IL_123d;
																																													case 125:
																																														goto IL_124b;
																																													case 7:
																																													case 189:
																																														goto IL_1259;
																																													case 109:
																																														goto IL_127e;
																																													case 409:
																																														goto IL_128c;
																																													case 255:
																																													case 394:
																																														goto IL_1297;
																																													case 348:
																																														goto IL_12cf;
																																													case 335:
																																														goto IL_12e3;
																																													case 218:
																																														goto IL_12f6;
																																													case 551:
																																														goto IL_130d;
																																													case 9:
																																													case 184:
																																														goto IL_131b;
																																													case 267:
																																														goto IL_1332;
																																													case 113:
																																														goto IL_1350;
																																													case 295:
																																														goto IL_135e;
																																													case 518:
																																														goto IL_1371;
																																													case 211:
																																														goto IL_137f;
																																													case 84:
																																													case 198:
																																														goto IL_138d;
																																													case 461:
																																														goto IL_13a1;
																																													case 338:
																																														goto IL_13d9;
																																													case 17:
																																														goto IL_13f5;
																																													case 379:
																																														goto IL_1403;
																																													case 371:
																																														goto IL_1411;
																																													case 71:
																																														goto IL_141f;
																																													case 250:
																																													case 460:
																																														goto IL_142a;
																																													case 205:
																																														goto IL_143e;
																																													case 361:
																																														goto IL_1476;
																																													case 399:
																																														goto IL_1489;
																																													case 238:
																																														goto IL_1497;
																																													case 362:
																																													case 471:
																																														goto IL_14a5;
																																													case 245:
																																														goto IL_14b3;
																																													case 221:
																																														goto IL_14d1;
																																													case 324:
																																														goto IL_14df;
																																													case 265:
																																														goto IL_14f2;
																																													case 470:
																																														goto IL_1509;
																																													case 177:
																																													case 323:
																																														goto IL_1517;
																																													case 553:
																																														goto IL_1534;
																																													case 252:
																																														goto IL_1571;
																																													case 213:
																																													case 269:
																																														goto IL_1584;
																																													case 341:
																																														goto IL_15a7;
																																													case 321:
																																														goto IL_15b5;
																																													case 318:
																																														goto IL_15c3;
																																													case 25:
																																														goto IL_15d6;
																																													case 358:
																																														goto IL_15e4;
																																													case 276:
																																													case 438:
																																														goto IL_15f2;
																																													case 527:
																																														goto IL_1606;
																																													case 308:
																																														goto IL_1657;
																																													case 88:
																																														goto IL_1665;
																																													case 312:
																																														goto IL_1678;
																																													case 342:
																																														goto IL_1686;
																																													case 140:
																																													case 226:
																																														goto IL_1694;
																																													case 254:
																																														goto IL_16a8;
																																													case 392:
																																														goto IL_16fa;
																																													case 446:
																																														goto IL_1708;
																																													case 104:
																																														goto IL_171b;
																																													case 558:
																																														goto IL_1726;
																																													case 132:
																																													case 444:
																																														goto IL_1734;
																																													case 489:
																																														goto IL_175c;
																																													case 290:
																																														goto IL_176a;
																																													case 27:
																																														goto IL_177d;
																																													case 108:
																																														goto IL_178b;
																																													case 209:
																																													case 497:
																																														goto IL_1799;
																																													case 182:
																																														goto IL_17a7;
																																													case 98:
																																														goto IL_17c5;
																																													case 440:
																																														goto IL_17d3;
																																													case 291:
																																													case 464:
																																														goto IL_17ef;
																																													case 68:
																																														goto IL_180d;
																																													case 305:
																																														goto IL_181b;
																																													case 204:
																																														goto IL_182e;
																																													case 477:
																																														goto IL_183c;
																																													case 339:
																																													case 468:
																																														goto IL_1847;
																																													case 187:
																																														goto IL_186f;
																																													case 174:
																																														goto IL_187d;
																																													case 285:
																																														goto IL_1890;
																																													case 304:
																																														goto IL_189e;
																																													case 106:
																																													case 537:
																																														goto IL_18a9;
																																													case 243:
																																														goto IL_18b7;
																																													case 32:
																																														goto IL_18cf;
																																													case 260:
																																														goto IL_18dd;
																																													case 421:
																																														goto IL_18f0;
																																													case 311:
																																														goto IL_18fe;
																																													case 52:
																																													case 365:
																																														goto IL_1912;
																																													case 490:
																																														goto IL_1920;
																																													case 284:
																																														goto IL_1938;
																																													case 151:
																																														goto IL_1946;
																																													case 546:
																																														goto IL_1959;
																																													case 516:
																																														goto IL_1967;
																																													case 196:
																																													case 298:
																																														goto IL_1972;
																																													case 160:
																																														goto IL_1990;
																																													case 203:
																																														goto IL_199e;
																																													case 262:
																																														goto IL_19b1;
																																													case 246:
																																														goto IL_19bf;
																																													case 193:
																																													case 261:
																																														goto IL_19cd;
																																													case 515:
																																														goto IL_19eb;
																																													case 55:
																																														goto IL_19f9;
																																													case 462:
																																														goto IL_1a10;
																																													case 396:
																																														goto IL_1a23;
																																													case 450:
																																														goto IL_1a31;
																																													case 188:
																																													case 351:
																																														goto IL_1a3f;
																																													case 425:
																																														goto IL_1a57;
																																													case 83:
																																														goto IL_1a65;
																																													case 350:
																																														goto IL_1a70;
																																													case 61:
																																														goto IL_1a7e;
																																													case 327:
																																													case 476:
																																														goto IL_1a8c;
																																													case 326:
																																														goto IL_1ac5;
																																													case 0:
																																														goto IL_1ad9;
																																													case 57:
																																													case 520:
																																														goto IL_1aec;
																																													case 475:
																																														goto IL_1b0a;
																																													case 62:
																																														goto IL_1b18;
																																													case 277:
																																														goto IL_1b34;
																																													case 241:
																																														goto IL_1b4b;
																																													case 215:
																																													case 480:
																																														goto IL_1b59;
																																													case 155:
																																														goto IL_1b77;
																																													case 223:
																																														goto IL_1b85;
																																													case 34:
																																														goto IL_1b93;
																																													case 111:
																																														goto IL_1ba6;
																																													case 14:
																																														goto IL_1bb4;
																																													case 249:
																																													case 402:
																																														goto IL_1bbf;
																																													case 138:
																																														goto IL_1bcd;
																																													case 101:
																																														goto IL_1bf0;
																																													case 487:
																																														goto IL_1bfe;
																																													case 232:
																																														goto IL_1c11;
																																													case 307:
																																														goto IL_1c1f;
																																													case 231:
																																													case 413:
																																														goto IL_1c2d;
																																													case 26:
																																														goto IL_1c41;
																																													case 170:
																																														goto IL_1c93;
																																													case 35:
																																														goto IL_1ca1;
																																													case 161:
																																														goto IL_1cb4;
																																													case 169:
																																														goto IL_1cc2;
																																													case 75:
																																													case 164:
																																														goto IL_1cd0;
																																													case 356:
																																														goto IL_1ce4;
																																													case 509:
																																														goto IL_1d36;
																																													case 502:
																																														goto IL_1d44;
																																													case 280:
																																														goto IL_1d57;
																																													case 521:
																																														goto IL_1d65;
																																													case 424:
																																													case 465:
																																														goto IL_1d7c;
																																													case 319:
																																														goto IL_1d8a;
																																													case 281:
																																														goto IL_1dac;
																																													case 235:
																																														goto IL_1dba;
																																													case 128:
																																														goto IL_1dcd;
																																													case 549:
																																														goto IL_1ddb;
																																													case 300:
																																														goto IL_1de9;
																																													case 253:
																																													case 322:
																																														goto IL_1df7;
																																													case 11:
																																														goto IL_1e14;
																																													case 378:
																																														goto IL_1e83;
																																													case 145:
																																														goto IL_1e96;
																																													case 508:
																																														goto IL_1ea4;
																																													case 383:
																																													case 431:
																																														goto IL_1eb2;
																																													case 49:
																																														goto IL_1ec6;
																																													case 346:
																																														goto IL_1f03;
																																													case 79:
																																														goto IL_1f16;
																																													case 50:
																																													case 82:
																																														goto IL_1f21;
																																													case 115:
																																														goto IL_1f2f;
																																													case 171:
																																														goto IL_1f48;
																																													case 77:
																																														goto IL_1f67;
																																													case 103:
																																														goto IL_1f75;
																																													case 437:
																																														goto IL_1f88;
																																													case 449:
																																														goto IL_1f96;
																																													case 200:
																																													case 397:
																																														goto IL_1fa4;
																																													case 15:
																																														goto IL_1fc1;
																																													case 122:
																																														goto IL_2012;
																																													case 447:
																																														goto IL_2020;
																																													case 56:
																																														goto IL_203c;
																																													case 481:
																																														goto IL_204a;
																																													case 165:
																																														goto IL_2058;
																																													case 192:
																																													case 523:
																																														goto IL_2063;
																																													case 554:
																																														goto IL_208d;
																																													case 393:
																																														goto IL_20a6;
																																													case 134:
																																														goto IL_20b4;
																																													case 29:
																																													case 387:
																																														goto IL_20bf;
																																													case 172:
																																														goto IL_20cd;
																																													case 491:
																																														goto IL_20ef;
																																													case 528:
																																														goto IL_20fd;
																																													case 313:
																																														goto IL_2110;
																																													case 552:
																																														goto IL_211e;
																																													case 270:
																																													case 293:
																																														goto IL_212c;
																																													case 505:
																																														goto IL_218c;
																																													case 222:
																																														goto IL_219f;
																																													case 158:
																																														goto IL_21ad;
																																													case 20:
																																													case 474:
																																														goto IL_21bb;
																																													case 466:
																																														goto IL_21f8;
																																													case 340:
																																														goto IL_2206;
																																													case 329:
																																														goto IL_2219;
																																													case 344:
																																														goto IL_2227;
																																													case 349:
																																													case 352:
																																														goto IL_2232;
																																													case 123:
																																														goto IL_223c;
																																													case 287:
																																														goto IL_224a;
																																													case 443:
																																														goto IL_225d;
																																													case 384:
																																														goto IL_226b;
																																													case 94:
																																													case 434:
																																														goto IL_2279;
																																													case 485:
																																														goto IL_22a4;
																																													case 531:
																																														goto IL_22bd;
																																													case 296:
																																														goto IL_22c8;
																																													case 416:
																																													case 459:
																																														goto IL_22d6;
																																													case 303:
																																														goto IL_2323;
																																													case 501:
																																														goto IL_2331;
																																													case 210:
																																														goto IL_2344;
																																													case 539:
																																														goto IL_2352;
																																													case 33:
																																														goto IL_236e;
																																													case 183:
																																													case 367:
																																														goto IL_2379;
																																													case 282:
																																														goto IL_23a4;
																																													case 511:
																																														goto IL_23c6;
																																													case 214:
																																														goto IL_23d4;
																																													case 257:
																																														goto IL_23e2;
																																													case 230:
																																														goto IL_23f0;
																																													case 96:
																																														goto IL_23fb;
																																													case 3:
																																														goto IL_2409;
																																													case 40:
																																													case 159:
																																														goto IL_2420;
																																													case 328:
																																														goto IL_242e;
																																													case 147:
																																														goto IL_2446;
																																													case 381:
																																														goto IL_2454;
																																													case 368:
																																													case 375:
																																														goto IL_2470;
																																													case 289:
																																														goto IL_247e;
																																													case 266:
																																														goto IL_2497;
																																													case 404:
																																														goto IL_24b6;
																																													case 85:
																																														goto IL_24c4;
																																													case 370:
																																														goto IL_24d7;
																																													case 194:
																																														goto IL_24e5;
																																													case 59:
																																													case 136:
																																														goto IL_24f3;
																																													case 483:
																																														goto IL_253f;
																																													case 360:
																																													case 372:
																																														goto IL_2564;
																																													case 420:
																																														goto IL_25c4;
																																													case 488:
																																														goto IL_25e0;
																																													case 167:
																																														goto IL_25ee;
																																													case 418:
																																														goto IL_25fc;
																																													case 144:
																																													case 148:
																																														goto IL_260a;
																																													case 19:
																																														goto IL_2669;
																																													case 540:
																																														goto IL_267c;
																																													case 92:
																																													case 430:
																																														goto IL_2687;
																																													case 153:
																																														goto IL_2695;
																																													case 233:
																																														goto IL_26b7;
																																													case 439:
																																														goto IL_26ce;
																																													case 54:
																																														goto IL_26e1;
																																													case 237:
																																														goto IL_26f8;
																																													case 126:
																																													case 330:
																																														goto IL_270c;
																																													case 124:
																																														goto IL_276b;
																																													case 1:
																																													case 4:
																																													case 23:
																																													case 28:
																																													case 30:
																																													case 36:
																																													case 45:
																																													case 58:
																																													case 60:
																																													case 70:
																																													case 86:
																																													case 89:
																																													case 91:
																																													case 93:
																																													case 99:
																																													case 100:
																																													case 112:
																																													case 114:
																																													case 119:
																																													case 130:
																																													case 141:
																																													case 146:
																																													case 185:
																																													case 186:
																																													case 191:
																																													case 202:
																																													case 216:
																																													case 240:
																																													case 242:
																																													case 263:
																																													case 264:
																																													case 268:
																																													case 275:
																																													case 283:
																																													case 301:
																																													case 314:
																																													case 320:
																																													case 333:
																																													case 336:
																																													case 354:
																																													case 359:
																																													case 376:
																																													case 385:
																																													case 388:
																																													case 390:
																																													case 395:
																																													case 403:
																																													case 412:
																																													case 417:
																																													case 426:
																																													case 432:
																																													case 435:
																																													case 445:
																																													case 452:
																																													case 454:
																																													case 455:
																																													case 472:
																																													case 478:
																																													case 486:
																																													case 500:
																																													case 503:
																																													case 506:
																																													case 512:
																																													case 525:
																																													case 529:
																																													case 533:
																																													case 541:
																																													case 542:
																																													case 557:
																																														goto end_IL_0a04;
																																													case 6:
																																													case 18:
																																													case 41:
																																													case 43:
																																													case 51:
																																													case 53:
																																													case 63:
																																													case 69:
																																													case 73:
																																													case 80:
																																													case 87:
																																													case 97:
																																													case 107:
																																													case 121:
																																													case 127:
																																													case 131:
																																													case 133:
																																													case 137:
																																													case 143:
																																													case 154:
																																													case 156:
																																													case 178:
																																													case 190:
																																													case 201:
																																													case 206:
																																													case 208:
																																													case 236:
																																													case 247:
																																													case 251:
																																													case 256:
																																													case 272:
																																													case 274:
																																													case 278:
																																													case 279:
																																													case 294:
																																													case 299:
																																													case 309:
																																													case 310:
																																													case 317:
																																													case 331:
																																													case 332:
																																													case 343:
																																													case 345:
																																													case 347:
																																													case 355:
																																													case 357:
																																													case 364:
																																													case 373:
																																													case 398:
																																													case 401:
																																													case 428:
																																													case 448:
																																													case 456:
																																													case 457:
																																													case 463:
																																													case 484:
																																													case 499:
																																													case 504:
																																													case 514:
																																													case 519:
																																													case 526:
																																													case 530:
																																													case 534:
																																													case 535:
																																													case 538:
																																													case 543:
																																													case 555:
																																													case 556:
																																														goto end_IL_08e7;
																																													case 163:
																																														goto end_IL_278e;
																																													case 419:
																																														goto end_IL_27a1;
																																													case 116:
																																														goto end_IL_27ab;
																																													case 427:
																																														goto end_IL_27b6;
																																													case 38:
																																														goto end_IL_27cc;
																																													case 10:
																																														goto end_IL_27e2;
																																													case 547:
																																														goto end_IL_27f8;
																																													case 142:
																																														goto end_IL_280e;
																																													case 74:
																																														goto end_IL_2824;
																																													case 363:
																																														goto end_IL_2834;
																																													case 422:
																																														goto end_IL_2844;
																																													case 42:
																																														goto end_IL_2854;
																																													case 405:
																																														goto end_IL_2864;
																																													case 95:
																																													case 544:
																																														goto end_IL_2874;
																																													case 227:
																																														goto end_IL_2884;
																																													case 228:
																																														goto end_IL_2894;
																																													case 429:
																																													case 532:
																																														return;
																																													}
																																													continue;
																																													end_IL_08e7:
																																													break;
																																												}
																																												break;
																																											}
																																											break;
																																										}
																																										break;
																																									}
																																									goto IL_0e48;
																																									IL_0eb8:
																																									num5--;
																																									break;
																																									IL_0e48:
																																									if (9 < b)
																																									{
																																										goto end_IL_0a04;
																																									}
																																									goto IL_0e56;
																																									IL_0e56:
																																									if (9 > b)
																																									{
																																										goto end_IL_0a04;
																																									}
																																									goto IL_0e64;
																																									IL_0e64:
																																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																									goto IL_0ea4;
																																									IL_0ea4:
																																									array[num5 - 2] = 0;
																																									goto IL_0eb8;
																																								}
																																								break;
																																							}
																																							goto IL_0ecb;
																																							IL_0ed9:
																																							if (11 > b)
																																							{
																																								goto end_IL_0a04;
																																							}
																																							break;
																																							IL_0ecb:
																																							if (11 < b)
																																							{
																																								goto end_IL_0a04;
																																							}
																																							goto IL_0ed9;
																																						}
																																						break;
																																					}
																																					goto IL_0eec;
																																					IL_0f35:
																																					ptr2 += 8;
																																					break;
																																					IL_0eec:
																																					array[num5] = 0;
																																					num = 436;
																																					goto IL_0f03;
																																					IL_0f03:
																																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])() ? 1 : 0);
																																					goto IL_0f27;
																																					IL_0f27:
																																					num5++;
																																					goto IL_0f35;
																																				}
																																				break;
																																			}
																																			goto IL_0f48;
																																			IL_109d:
																																			ptr2 += 8;
																																			break;
																																			IL_0f48:
																																			if (14 >= b)
																																			{
																																				goto IL_0f56;
																																			}
																																			goto IL_1041;
																																			IL_0f56:
																																			if (14 > b)
																																			{
																																				goto IL_0f64;
																																			}
																																			goto IL_0fee;
																																			IL_0f64:
																																			if (13 < b)
																																			{
																																				goto end_IL_0a04;
																																			}
																																			goto IL_0f72;
																																			IL_0f72:
																																			if (13 > b)
																																			{
																																				goto end_IL_0a04;
																																			}
																																			goto IL_0f80;
																																			IL_0f80:
																																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																			num = 493;
																																			goto IL_0fdb;
																																			IL_0fdb:
																																			num5--;
																																			break;
																																			IL_0fee:
																																			array[num5] = 0;
																																			goto IL_0ffc;
																																			IL_0ffc:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])() ? 1 : 0);
																																			goto IL_1020;
																																			IL_1020:
																																			num5++;
																																			goto IL_102e;
																																			IL_102e:
																																			ptr2 += 8;
																																			break;
																																			IL_1041:
																																			if (15 < b)
																																			{
																																				goto end_IL_0a04;
																																			}
																																			goto IL_104f;
																																			IL_104f:
																																			if (15 > b)
																																			{
																																				goto end_IL_0a04;
																																			}
																																			goto IL_105d;
																																			IL_105d:
																																			array[num5] = 0;
																																			goto IL_106b;
																																			IL_106b:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])() ? 1 : 0);
																																			goto IL_108f;
																																			IL_108f:
																																			num5++;
																																			goto IL_109d;
																																		}
																																		break;
																																	}
																																	goto IL_0a3f;
																																	IL_0e22:
																																	ptr2 += 8;
																																	break;
																																	IL_0a3f:
																																	if (8 > b)
																																	{
																																		goto IL_0a4a;
																																	}
																																	goto IL_0a84;
																																	IL_0a4a:
																																	if (4 < b)
																																	{
																																		goto IL_0a55;
																																	}
																																	goto IL_0a97;
																																	IL_0a55:
																																	if (6 < b)
																																	{
																																		goto IL_0a63;
																																	}
																																	goto IL_0b5f;
																																	IL_0a63:
																																	if (7 < b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0a71;
																																	IL_0a71:
																																	if (7 > b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0c54;
																																	IL_0c54:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																	num = 173;
																																	goto IL_0c9d;
																																	IL_0c9d:
																																	array[num5 - 2] = 0;
																																	goto IL_0cb1;
																																	IL_0cb1:
																																	num5--;
																																	break;
																																	IL_0b5f:
																																	if (6 <= b)
																																	{
																																		goto IL_0b6a;
																																	}
																																	goto IL_0bd1;
																																	IL_0b6a:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																	goto IL_0baa;
																																	IL_0baa:
																																	array[num5 - 2] = 0;
																																	goto IL_0bbe;
																																	IL_0bbe:
																																	num5--;
																																	break;
																																	IL_0bd1:
																																	if (5 < b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0bdf;
																																	IL_0bdf:
																																	if (5 > b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0bed;
																																	IL_0bed:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																	goto IL_0c2d;
																																	IL_0c2d:
																																	array[num5 - 2] = 0;
																																	goto IL_0c41;
																																	IL_0c41:
																																	num5--;
																																	break;
																																	IL_0a97:
																																	if (4 > b)
																																	{
																																		goto IL_0aa5;
																																	}
																																	goto IL_0dd0;
																																	IL_0aa5:
																																	if (2 < b)
																																	{
																																		goto IL_0ab0;
																																	}
																																	num = 2;
																																	goto IL_0acc;
																																	IL_0ab0:
																																	if (3 < b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0cc4;
																																	IL_0cc4:
																																	if (3 > b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0cd2;
																																	IL_0cd2:
																																	ref int reference = ref array4[*(int*)(ptr2 + num3)];
																																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																	goto IL_0cfb;
																																	IL_0cfb:
																																	ptr2 += 8;
																																	goto IL_0d09;
																																	IL_0d09:
																																	num5--;
																																	break;
																																	IL_0a84:
																																	num5--;
																																	break;
																																	IL_0acc:
																																	if (2 <= b)
																																	{
																																		goto IL_0ad7;
																																	}
																																	goto IL_0b3e;
																																	IL_0ad7:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																	goto IL_0b17;
																																	IL_0b17:
																																	array[num5 - 2] = 0;
																																	goto IL_0b2b;
																																	IL_0b2b:
																																	num5--;
																																	break;
																																	IL_0b3e:
																																	if (1 < b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0b4c;
																																	IL_0b4c:
																																	if (1 > b)
																																	{
																																		goto end_IL_0a04;
																																	}
																																	goto IL_0d7f;
																																	IL_0d7f:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																																	goto IL_0d98;
																																	IL_0d98:
																																	array[num5] = 0;
																																	goto IL_0da6;
																																	IL_0da6:
																																	num5++;
																																	goto IL_0db4;
																																	IL_0db4:
																																	ptr2 += 8;
																																	num = 41;
																																	break;
																																	IL_0dd0:
																																	array[num5] = 0;
																																	goto IL_0dde;
																																	IL_0dde:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = array4[*(int*)(ptr2 + num3)];
																																	goto IL_0e01;
																																	IL_0e01:
																																	array2[num5] = null;
																																	goto IL_0e0b;
																																	IL_0e0b:
																																	num5++;
																																	num = 315;
																																	goto IL_0e22;
																																}
																																break;
																															}
																															goto IL_0d1c;
																															IL_0e35:
																															num5--;
																															break;
																															IL_0d1c:
																															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															goto IL_0e35;
																														}
																														break;
																													}
																													goto IL_10b0;
																													IL_17a7:
																													array2[num5] = ((delegate*<List<GameEntityCreateData>>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])();
																													goto IL_17c5;
																													IL_10b0:
																													if (24 >= b)
																													{
																														goto IL_10be;
																													}
																													goto IL_13f5;
																													IL_10be:
																													if (24 <= b)
																													{
																														goto IL_10c9;
																													}
																													goto IL_112d;
																													IL_10c9:
																													array[num5 - 1] = 4;
																													goto IL_10dd;
																													IL_10dd:
																													array2[num5 - 1] = ((delegate*<Transform, Vector3>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																													goto IL_111a;
																													IL_111a:
																													ptr2 += 8;
																													break;
																													IL_112d:
																													if (20 >= b)
																													{
																														goto IL_113b;
																													}
																													goto IL_127e;
																													IL_113b:
																													if (20 <= b)
																													{
																														goto IL_1146;
																													}
																													goto IL_116e;
																													IL_1146:
																													((delegate*<void>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])();
																													goto IL_115b;
																													IL_115b:
																													ptr2 += 8;
																													break;
																													IL_116e:
																													if (18 >= b)
																													{
																														goto IL_117c;
																													}
																													goto IL_123d;
																													IL_117c:
																													if (18 <= b)
																													{
																														goto IL_1187;
																													}
																													goto IL_11d1;
																													IL_1187:
																													((delegate*<UnityEngine.Object, void>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Class119)array2[num5 - 1]);
																													goto IL_11b0;
																													IL_11b0:
																													num5--;
																													goto IL_11be;
																													IL_11be:
																													ptr2 += 8;
																													break;
																													IL_11d1:
																													if (17 < b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_11df;
																													IL_11df:
																													if (17 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_11ed;
																													IL_11ed:
																													array2[num5] = array6[*(int*)(ptr2 + num3)];
																													num = 406;
																													goto IL_120e;
																													IL_120e:
																													array[num5] = 5;
																													goto IL_121c;
																													IL_121c:
																													num5++;
																													goto IL_122a;
																													IL_122a:
																													ptr2 += 8;
																													break;
																													IL_123d:
																													if (19 < b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_124b;
																													IL_124b:
																													if (19 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_1259;
																													IL_1259:
																													byte* num6 = ptr2;
																													num4 = 1;
																													ptr2 = num6 + -200;
																													num = 236;
																													break;
																													IL_127e:
																													if (22 >= b)
																													{
																														goto IL_128c;
																													}
																													goto IL_1371;
																													IL_128c:
																													if (22 <= b)
																													{
																														goto IL_1297;
																													}
																													goto IL_12f6;
																													IL_1297:
																													array2[num5 - 1] = ((delegate*<GTPlayer, SphereCollider>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((GTPlayer)array2[num5 - 1]);
																													goto IL_12cf;
																													IL_12cf:
																													array[num5 - 1] = 5;
																													goto IL_12e3;
																													IL_12e3:
																													ptr2 += 8;
																													break;
																													IL_12f6:
																													if (21 < b)
																													{
																														goto end_IL_0a04;
																													}
																													num = 551;
																													goto IL_130d;
																													IL_17c5:
																													num5++;
																													goto IL_17d3;
																													IL_130d:
																													if (21 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_131b;
																													IL_131b:
																													array[num5] = 5;
																													num = 267;
																													goto IL_1332;
																													IL_1332:
																													array2[num5] = ((delegate*<GTPlayer>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])();
																													goto IL_1350;
																													IL_1350:
																													num5++;
																													goto IL_135e;
																													IL_135e:
																													ptr2 += 8;
																													break;
																													IL_1371:
																													if (23 < b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_137f;
																													IL_137f:
																													if (23 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_138d;
																													IL_138d:
																													array[num5 - 1] = 5;
																													goto IL_13a1;
																													IL_13a1:
																													array2[num5 - 1] = ((delegate*<Component, Transform>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																													goto IL_13d9;
																													IL_13d9:
																													ptr2 += 8;
																													num = 274;
																													break;
																													IL_13f5:
																													if (28 >= b)
																													{
																														goto IL_1403;
																													}
																													goto IL_15d6;
																													IL_1403:
																													if (28 > b)
																													{
																														goto IL_1411;
																													}
																													goto IL_1584;
																													IL_1411:
																													if (26 >= b)
																													{
																														goto IL_141f;
																													}
																													goto IL_14f2;
																													IL_141f:
																													if (26 <= b)
																													{
																														goto IL_142a;
																													}
																													goto IL_1489;
																													IL_142a:
																													array[num5 - 1] = 5;
																													goto IL_143e;
																													IL_143e:
																													array2[num5 - 1] = ((delegate*<Component, Transform>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																													goto IL_1476;
																													IL_1476:
																													ptr2 += 8;
																													break;
																													IL_1489:
																													if (25 < b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_1497;
																													IL_1497:
																													if (25 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_14a5;
																													IL_14a5:
																													array[num5] = 5;
																													goto IL_14b3;
																													IL_14b3:
																													array2[num5] = ((delegate*<GTPlayer>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])();
																													goto IL_14d1;
																													IL_14d1:
																													num5++;
																													goto IL_14df;
																													IL_14df:
																													ptr2 += 8;
																													break;
																													IL_14f2:
																													if (27 < b)
																													{
																														goto end_IL_0a04;
																													}
																													num = 470;
																													goto IL_1509;
																													IL_17d3:
																													ptr2 += 8;
																													break;
																													IL_1509:
																													if (27 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_1517;
																													IL_1517:
																													array[num5 - 1] = 4;
																													num = 553;
																													goto IL_1534;
																													IL_1534:
																													array2[num5 - 1] = ((delegate*<Transform, Vector3>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																													goto IL_1571;
																													IL_1571:
																													ptr2 += 8;
																													break;
																													IL_1584:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																													num = 341;
																													goto IL_15a7;
																													IL_15a7:
																													array[num5] = 3;
																													goto IL_15b5;
																													IL_15b5:
																													num5++;
																													goto IL_15c3;
																													IL_15c3:
																													ptr2 += 8;
																													break;
																													IL_15d6:
																													if (30 >= b)
																													{
																														goto IL_15e4;
																													}
																													goto IL_171b;
																													IL_15e4:
																													if (30 <= b)
																													{
																														goto IL_15f2;
																													}
																													goto IL_1678;
																													IL_15f2:
																													array[num5 - 2] = 4;
																													goto IL_1606;
																													IL_1606:
																													array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																													goto IL_1657;
																													IL_1657:
																													num5--;
																													goto IL_1665;
																													IL_1665:
																													ptr2 += 8;
																													break;
																													IL_1678:
																													if (29 < b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_1686;
																													IL_1686:
																													if (29 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_1694;
																													IL_1694:
																													array[num5 - 2] = 4;
																													goto IL_16a8;
																													IL_16a8:
																													array2[num5 - 2] = ((delegate*<Vector3, float, Vector3>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																													goto IL_16fa;
																													IL_16fa:
																													num5--;
																													goto IL_1708;
																													IL_1708:
																													ptr2 += 8;
																													break;
																													IL_171b:
																													if (31 >= b)
																													{
																														goto IL_1726;
																													}
																													goto IL_177d;
																													IL_1726:
																													if (31 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_1734;
																													IL_1734:
																													array6[*(int*)(ptr2 + num3)] = (Vector3)array2[num5 - 1];
																													goto IL_175c;
																													IL_175c:
																													ptr2 += 8;
																													goto IL_176a;
																													IL_176a:
																													num5--;
																													break;
																													IL_177d:
																													if (32 < b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_178b;
																													IL_178b:
																													if (32 > b)
																													{
																														goto end_IL_0a04;
																													}
																													goto IL_1799;
																													IL_1799:
																													array[num5] = 5;
																													goto IL_17a7;
																												}
																												break;
																											}
																											num = 464;
																											goto IL_17ef;
																											IL_180d:
																											ptr2 += 8;
																											goto IL_181b;
																											IL_181b:
																											num5--;
																											break;
																											IL_17ef:
																											array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_180d;
																										}
																										break;
																									}
																									goto IL_182e;
																									IL_2687:
																									array[num5] = 4;
																									goto IL_2695;
																									IL_182e:
																									if (50 >= b)
																									{
																										goto IL_183c;
																									}
																									goto IL_203c;
																									IL_183c:
																									if (50 <= b)
																									{
																										goto IL_1847;
																									}
																									goto IL_1890;
																									IL_1847:
																									array6[*(int*)(ptr2 + num3)] = (Quaternion)array2[num5 - 1];
																									goto IL_186f;
																									IL_186f:
																									ptr2 += 8;
																									goto IL_187d;
																									IL_187d:
																									num5--;
																									break;
																									IL_1890:
																									if (41 >= b)
																									{
																										goto IL_189e;
																									}
																									goto IL_1ba6;
																									IL_189e:
																									if (41 <= b)
																									{
																										goto IL_18a9;
																									}
																									goto IL_18f0;
																									IL_18a9:
																									array[num5] = 5;
																									goto IL_18b7;
																									IL_18b7:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_18cf;
																									IL_18cf:
																									num5++;
																									goto IL_18dd;
																									IL_18dd:
																									ptr2 += 8;
																									break;
																									IL_18f0:
																									if (37 >= b)
																									{
																										goto IL_18fe;
																									}
																									goto IL_1a57;
																									IL_18fe:
																									if (37 <= b)
																									{
																										num = 365;
																										goto IL_1912;
																									}
																									goto IL_1959;
																									IL_2695:
																									array2[num5] = (Quaternion)array6[*(int*)(ptr2 + num3)];
																									goto IL_26b7;
																									IL_1912:
																									array[num5] = 5;
																									goto IL_1920;
																									IL_1920:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_1938;
																									IL_1938:
																									num5++;
																									goto IL_1946;
																									IL_1946:
																									ptr2 += 8;
																									break;
																									IL_1959:
																									if (35 >= b)
																									{
																										goto IL_1967;
																									}
																									goto IL_1a23;
																									IL_1967:
																									if (35 <= b)
																									{
																										goto IL_1972;
																									}
																									goto IL_19b1;
																									IL_1972:
																									array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_1990;
																									IL_1990:
																									ptr2 += 8;
																									goto IL_199e;
																									IL_199e:
																									num5--;
																									break;
																									IL_19b1:
																									if (34 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_19bf;
																									IL_19bf:
																									if (34 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_19cd;
																									IL_19cd:
																									array2[num5] = ((delegate*<string[]>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])();
																									goto IL_19eb;
																									IL_19eb:
																									array[num5] = 5;
																									goto IL_19f9;
																									IL_19f9:
																									num5++;
																									num = 462;
																									goto IL_1a10;
																									IL_1a10:
																									ptr2 += 8;
																									break;
																									IL_1a23:
																									if (36 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1a31;
																									IL_1a31:
																									if (36 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1a3f;
																									IL_1a3f:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									break;
																									IL_1a57:
																									if (39 >= b)
																									{
																										goto IL_1a65;
																									}
																									goto IL_1b34;
																									IL_1a65:
																									if (39 > b)
																									{
																										goto IL_1a70;
																									}
																									goto IL_1aec;
																									IL_1a70:
																									if (38 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1a7e;
																									IL_1a7e:
																									if (38 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1a8c;
																									IL_1a8c:
																									array2[num5 - 2] = ((string[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																									goto IL_1ac5;
																									IL_1ac5:
																									array[num5 - 2] = 5;
																									goto IL_1ad9;
																									IL_1ad9:
																									num5--;
																									break;
																									IL_1aec:
																									array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_1b0a;
																									IL_1b0a:
																									ptr2 += 8;
																									goto IL_1b18;
																									IL_1b18:
																									num5--;
																									num = 63;
																									break;
																									IL_1b34:
																									if (40 < b)
																									{
																										goto end_IL_0a04;
																									}
																									num = 241;
																									goto IL_1b4b;
																									IL_26b7:
																									num5++;
																									num = 439;
																									goto IL_26ce;
																									IL_1b4b:
																									if (40 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1b59;
																									IL_1b59:
																									array2[num5] = ((delegate*<Dictionary<string, int>>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])();
																									goto IL_1b77;
																									IL_1b77:
																									array[num5] = 5;
																									goto IL_1b85;
																									IL_1b85:
																									num5++;
																									goto IL_1b93;
																									IL_1b93:
																									ptr2 += 8;
																									break;
																									IL_1ba6:
																									if (45 >= b)
																									{
																										goto IL_1bb4;
																									}
																									goto IL_1dcd;
																									IL_1bb4:
																									if (45 <= b)
																									{
																										goto IL_1bbf;
																									}
																									goto IL_1c11;
																									IL_1bbf:
																									array[num5] = 4;
																									goto IL_1bcd;
																									IL_1bcd:
																									array2[num5] = ((delegate*<Vector3>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])();
																									goto IL_1bf0;
																									IL_1bf0:
																									num5++;
																									goto IL_1bfe;
																									IL_1bfe:
																									ptr2 += 8;
																									break;
																									IL_1c11:
																									if (43 >= b)
																									{
																										goto IL_1c1f;
																									}
																									goto IL_1d57;
																									IL_1c1f:
																									if (43 <= b)
																									{
																										goto IL_1c2d;
																									}
																									goto IL_1cb4;
																									IL_1c2d:
																									array[num5 - 2] = 0;
																									goto IL_1c41;
																									IL_1c41:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]);
																									goto IL_1c93;
																									IL_1c93:
																									num5--;
																									goto IL_1ca1;
																									IL_1ca1:
																									ptr2 += 8;
																									break;
																									IL_1cb4:
																									if (42 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1cc2;
																									IL_1cc2:
																									if (42 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1cd0;
																									IL_1cd0:
																									array[num5 - 2] = 0;
																									goto IL_1ce4;
																									IL_1ce4:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]) ? 1 : 0);
																									goto IL_1d36;
																									IL_1d36:
																									num5--;
																									goto IL_1d44;
																									IL_1d44:
																									ptr2 += 8;
																									break;
																									IL_1d57:
																									if (44 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1d65;
																									IL_1d65:
																									if (44 > b)
																									{
																										goto end_IL_0a04;
																									}
																									num = 424;
																									goto IL_1d7c;
																									IL_26ce:
																									ptr2 += 8;
																									break;
																									IL_1d7c:
																									array[num5] = 4;
																									goto IL_1d8a;
																									IL_1d8a:
																									array2[num5] = (Vector3)array6[*(int*)(ptr2 + num3)];
																									goto IL_1dac;
																									IL_1dac:
																									num5++;
																									goto IL_1dba;
																									IL_1dba:
																									ptr2 += 8;
																									break;
																									IL_1dcd:
																									if (47 < b)
																									{
																										goto IL_1ddb;
																									}
																									goto IL_1f16;
																									IL_1ddb:
																									if (48 >= b)
																									{
																										goto IL_1de9;
																									}
																									goto IL_1e96;
																									IL_1de9:
																									if (48 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1df7;
																									IL_1df7:
																									array[num5 - 1] = 4;
																									num = 11;
																									goto IL_1e14;
																									IL_1e14:
																									array2[num5 - 1] = ((delegate*<ref Vector3, Vector3>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)CurrencyNegativePatternCallerFilePathAttribute[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4));
																									goto IL_1e83;
																									IL_1e83:
																									ptr2 += 8;
																									break;
																									IL_1e96:
																									if (49 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1ea4;
																									IL_1ea4:
																									if (49 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1eb2;
																									IL_1eb2:
																									array[num5 - 1] = 4;
																									goto IL_1ec6;
																									IL_1ec6:
																									array2[num5 - 1] = ((delegate*<Vector3, Quaternion>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																									goto IL_1f03;
																									IL_1f03:
																									ptr2 += 8;
																									break;
																									IL_1f16:
																									if (47 <= b)
																									{
																										goto IL_1f21;
																									}
																									goto IL_1f88;
																									IL_1f21:
																									array[num5] = 13;
																									goto IL_1f2f;
																									IL_1f2f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																									goto IL_1f48;
																									IL_1f48:
																									array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																									goto IL_1f67;
																									IL_1f67:
																									num5++;
																									goto IL_1f75;
																									IL_1f75:
																									ptr2 += 16;
																									break;
																									IL_1f88:
																									if (46 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1f96;
																									IL_1f96:
																									if (46 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_1fa4;
																									IL_1fa4:
																									array[num5 - 2] = 4;
																									num = 15;
																									goto IL_1fc1;
																									IL_1fc1:
																									array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																									goto IL_2012;
																									IL_2012:
																									num5--;
																									goto IL_2020;
																									IL_2020:
																									ptr2 += 8;
																									num = 137;
																									break;
																									IL_203c:
																									if (58 < b)
																									{
																										goto IL_204a;
																									}
																									num = 33;
																									goto IL_236e;
																									IL_204a:
																									if (62 >= b)
																									{
																										goto IL_2058;
																									}
																									goto IL_2219;
																									IL_2058:
																									if (62 <= b)
																									{
																										goto IL_2063;
																									}
																									goto IL_20a6;
																									IL_2063:
																									*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (nint)((string[])array2[num5 - 1]).LongLength;
																									goto IL_208d;
																									IL_208d:
																									array[num5 - 1] = 2;
																									break;
																									IL_20a6:
																									if (60 >= b)
																									{
																										goto IL_20b4;
																									}
																									goto IL_219f;
																									IL_20b4:
																									if (60 <= b)
																									{
																										goto IL_20bf;
																									}
																									goto IL_2110;
																									IL_20bf:
																									array[num5] = 4;
																									goto IL_20cd;
																									IL_20cd:
																									array2[num5] = (GameEntityCreateData)array6[*(int*)(ptr2 + num3)];
																									goto IL_20ef;
																									IL_20ef:
																									num5++;
																									goto IL_20fd;
																									IL_20fd:
																									ptr2 += 8;
																									break;
																									IL_2110:
																									if (59 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_211e;
																									IL_211e:
																									if (59 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_212c;
																									IL_212c:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)CurrencyNegativePatternCallerFilePathAttribute[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).createData = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_218c;
																									IL_218c:
																									num5 -= 2;
																									break;
																									IL_219f:
																									if (61 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_21ad;
																									IL_21ad:
																									if (61 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_21bb;
																									IL_21bb:
																									((delegate*<List<GameEntityCreateData>, GameEntityCreateData, void>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 2], (GameEntityCreateData)array2[num5 - 1]);
																									goto IL_21f8;
																									IL_21f8:
																									num5 -= 2;
																									goto IL_2206;
																									IL_2206:
																									ptr2 += 8;
																									break;
																									IL_2219:
																									if (64 >= b)
																									{
																										goto IL_2227;
																									}
																									goto IL_22bd;
																									IL_2227:
																									if (64 <= b)
																									{
																										goto IL_2232;
																									}
																									goto IL_225d;
																									IL_2232:
																									array2[num5] = null;
																									goto IL_223c;
																									IL_223c:
																									array[num5] = 5;
																									goto IL_224a;
																									IL_224a:
																									num5++;
																									break;
																									IL_225d:
																									if (63 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_226b;
																									IL_226b:
																									if (63 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_2279;
																									IL_2279:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																									goto IL_22a4;
																									IL_22a4:
																									array[num5 - 1] = 0;
																									break;
																									IL_22bd:
																									if (65 >= b)
																									{
																										goto IL_22c8;
																									}
																									goto IL_2344;
																									IL_22c8:
																									if (65 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_22d6;
																									IL_22d6:
																									((delegate*<List<GameEntityCreateData>, Player, bool, void>)CurrencyNegativePatternCallerFilePathAttribute[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 3], (Player)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0);
																									goto IL_2323;
																									IL_2323:
																									num5 -= 3;
																									goto IL_2331;
																									IL_2331:
																									ptr2 += 8;
																									break;
																									IL_2344:
																									if (66 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_2352;
																									IL_2352:
																									if (66 > b)
																									{
																									}
																									goto end_IL_0a04;
																									IL_26e1:
																									if (55 < b)
																									{
																										goto end_IL_0a04;
																									}
																									num = 237;
																									goto IL_26f8;
																									IL_236e:
																									if (58 <= b)
																									{
																										goto IL_2379;
																									}
																									goto IL_23c6;
																									IL_2379:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_23a4;
																									IL_23a4:
																									array[num5 - 1] = 1;
																									num = 279;
																									break;
																									IL_23c6:
																									if (54 >= b)
																									{
																										goto IL_23d4;
																									}
																									goto IL_25e0;
																									IL_23d4:
																									if (54 > b)
																									{
																										goto IL_23e2;
																									}
																									num = 372;
																									goto IL_2564;
																									IL_23e2:
																									if (52 >= b)
																									{
																										goto IL_23f0;
																									}
																									goto IL_24d7;
																									IL_23f0:
																									if (52 > b)
																									{
																										goto IL_23fb;
																									}
																									num = 368;
																									goto IL_2470;
																									IL_23fb:
																									if (51 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_2409;
																									IL_2409:
																									if (51 > b)
																									{
																										goto end_IL_0a04;
																									}
																									num = 159;
																									goto IL_2420;
																									IL_276b:
																									num5 -= 2;
																									break;
																									IL_2420:
																									array[num5] = 5;
																									goto IL_242e;
																									IL_242e:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_2446;
																									IL_2446:
																									num5++;
																									goto IL_2454;
																									IL_2454:
																									ptr2 += 8;
																									break;
																									IL_26f8:
																									if (55 > b)
																									{
																										goto end_IL_0a04;
																									}
																									num = 126;
																									goto IL_270c;
																									IL_2470:
																									array[num5] = 13;
																									goto IL_247e;
																									IL_247e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																									goto IL_2497;
																									IL_2497:
																									array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																									goto IL_24b6;
																									IL_24b6:
																									num5++;
																									goto IL_24c4;
																									IL_24c4:
																									ptr2 += 16;
																									break;
																									IL_24d7:
																									if (53 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_24e5;
																									IL_24e5:
																									if (53 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_24f3;
																									IL_24f3:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)CurrencyNegativePatternCallerFilePathAttribute[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4) = default(GameEntityCreateData);
																									goto IL_253f;
																									IL_253f:
																									num5--;
																									num = 80;
																									break;
																									IL_270c:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)CurrencyNegativePatternCallerFilePathAttribute[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).position = (Vector3)array2[num5 - 1];
																									goto IL_276b;
																									IL_2564:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)CurrencyNegativePatternCallerFilePathAttribute[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).entityTypeId = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_25c4;
																									IL_25c4:
																									num5 -= 2;
																									num = 448;
																									break;
																									IL_25e0:
																									if (56 < b)
																									{
																										goto IL_25ee;
																									}
																									goto IL_267c;
																									IL_25ee:
																									if (57 < b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_25fc;
																									IL_25fc:
																									if (57 > b)
																									{
																										goto end_IL_0a04;
																									}
																									goto IL_260a;
																									IL_260a:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)CurrencyNegativePatternCallerFilePathAttribute[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).rotation = (Quaternion)array2[num5 - 1];
																									goto IL_2669;
																									IL_2669:
																									num5 -= 2;
																									break;
																									IL_267c:
																									if (56 <= b)
																									{
																										goto IL_2687;
																									}
																									goto IL_26e1;
																								}
																								goto end_IL_0a14;
																								continue;
																								end_IL_0a04:
																								break;
																								IL_0a04:;
																							}
																						}
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						continue;
																						end_IL_0a14:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			continue;
																			end_IL_278e:
																			break;
																		}
																		continue;
																		end_IL_27a1:
																		break;
																	}
																	continue;
																	end_IL_27ab:
																	break;
																}
																continue;
																end_IL_27b6:
																break;
															}
															continue;
															end_IL_27cc:
															break;
														}
														continue;
														end_IL_27e2:
														break;
													}
													continue;
													end_IL_27f8:
													break;
												}
												continue;
												end_IL_280e:
												break;
											}
											continue;
											end_IL_2824:
											break;
										}
										continue;
										end_IL_2834:
										break;
									}
									continue;
									end_IL_2844:
									break;
								}
								continue;
								end_IL_2854:
								break;
							}
							continue;
							end_IL_2864:
							break;
						}
						continue;
						end_IL_2874:
						break;
					}
					continue;
					end_IL_2884:
					break;
				}
				continue;
				end_IL_2894:
				break;
			}
		}
	}

	public Class119()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 80;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetApplicationRunningStateHIJRI.TryGetValueConfigurationFile);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0244:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0224:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0214:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_0204:
																								if (8 < b)
																								{
																									num = 117;
																									while (true)
																									{
																										if (num != 117)
																										{
																											if (num != 1098)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 44:
																											case 103:
																												goto IL_0204;
																											case 21:
																											case 108:
																												goto IL_0214;
																											case 65:
																												goto IL_0224;
																											case 1:
																												goto IL_0234;
																											case 76:
																												goto IL_0244;
																											case 22:
																												goto end_IL_0244;
																											case 95:
																											case 107:
																												goto end_IL_0254;
																											case 50:
																												goto IL_026f;
																											case 35:
																											case 46:
																												goto IL_027d;
																											case 85:
																												goto IL_02bd;
																											case 47:
																												goto IL_02d1;
																											case 10:
																												goto IL_02e4;
																											case 23:
																												goto IL_02f2;
																											case 61:
																											case 88:
																												goto IL_0300;
																											case 59:
																												goto IL_031c;
																											case 48:
																											case 106:
																												goto IL_032a;
																											case 77:
																												goto IL_0338;
																											case 27:
																											case 32:
																												goto IL_0346;
																											case 92:
																												goto IL_0386;
																											case 53:
																												goto IL_039a;
																											case 30:
																											case 31:
																												goto IL_03ad;
																											case 8:
																												goto IL_03c6;
																											case 82:
																												goto IL_03d4;
																											case 68:
																												goto IL_03e2;
																											case 34:
																												goto IL_03f5;
																											case 41:
																											case 90:
																												goto IL_0403;
																											case 17:
																											case 87:
																												goto IL_0411;
																											case 74:
																												goto IL_041c;
																											case 58:
																											case 86:
																												goto IL_042a;
																											case 12:
																												goto IL_0453;
																											case 56:
																												goto IL_0461;
																											case 66:
																											case 69:
																												goto IL_047d;
																											case 2:
																												goto IL_0488;
																											case 15:
																											case 54:
																												goto IL_0496;
																											case 26:
																												goto IL_04d6;
																											case 7:
																												goto IL_04ea;
																											case 91:
																												goto IL_050b;
																											case 3:
																											case 72:
																												goto IL_0516;
																											case 16:
																												goto IL_0556;
																											case 84:
																												goto IL_056a;
																											case 71:
																												goto IL_057d;
																											case 60:
																												goto IL_0588;
																											case 75:
																											case 94:
																												goto IL_0595;
																											case 96:
																												goto IL_05ac;
																											case 6:
																												goto IL_05cf;
																											case 101:
																												goto IL_05d9;
																											case 18:
																												goto IL_05f0;
																											case 5:
																											case 9:
																											case 11:
																											case 13:
																											case 19:
																											case 25:
																											case 28:
																											case 29:
																											case 33:
																											case 37:
																											case 38:
																											case 40:
																											case 42:
																											case 45:
																											case 51:
																											case 52:
																											case 55:
																											case 64:
																											case 70:
																											case 83:
																											case 97:
																												goto end_IL_01f1;
																											case 104:
																												goto IL_0623;
																											case 109:
																												goto IL_0631;
																											case 49:
																												goto IL_063f;
																											case 14:
																											case 36:
																											case 57:
																											case 62:
																											case 63:
																											case 67:
																											case 78:
																											case 98:
																											case 99:
																											case 100:
																											case 110:
																												goto end_IL_0264;
																											case 102:
																												goto end_IL_064d;
																											case 105:
																												goto end_IL_0660;
																											case 73:
																												goto end_IL_066a;
																											case 20:
																												goto end_IL_0675;
																											case 39:
																												goto end_IL_068a;
																											case 4:
																											case 93:
																												goto end_IL_069f;
																											case 89:
																												goto end_IL_06af;
																											case 43:
																											case 81:
																												goto end_IL_06bf;
																											case 79:
																												goto end_IL_06cf;
																											case 80:
																												goto end_IL_06df;
																											case 0:
																											case 24:
																												goto IL_06fa;
																											}
																											continue;
																										}
																										goto IL_02e4;
																										IL_02f2:
																										if (9 > b)
																										{
																											break;
																										}
																										goto IL_0300;
																										IL_0300:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										goto end_IL_0264;
																										IL_02e4:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_02f2;
																										continue;
																										end_IL_01f1:
																										break;
																									}
																									break;
																								}
																								goto IL_026f;
																								IL_02bd:
																								array[num6 - 2] = 0;
																								goto IL_02d1;
																								IL_02d1:
																								num6--;
																								goto end_IL_0264;
																								IL_026f:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_027d;
																								IL_027d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_02bd;
																							}
																							break;
																						}
																						goto IL_031c;
																						IL_03e2:
																						ptr2 += 8;
																						goto end_IL_0264;
																						IL_031c:
																						if (7 > b)
																						{
																							goto IL_032a;
																						}
																						goto IL_03ad;
																						IL_032a:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_0338;
																						IL_0338:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0346;
																						IL_0346:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0386;
																						IL_0386:
																						array[num6 - 2] = 0;
																						goto IL_039a;
																						IL_039a:
																						num6--;
																						goto end_IL_0264;
																						IL_03ad:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_03c6;
																						IL_03c6:
																						array[num6] = 0;
																						goto IL_03d4;
																						IL_03d4:
																						num6++;
																						goto IL_03e2;
																					}
																					break;
																				}
																				goto IL_03f5;
																				IL_05cf:
																				array2[num6] = null;
																				goto IL_05d9;
																				IL_03f5:
																				if (5 > b)
																				{
																					goto IL_0403;
																				}
																				goto IL_0595;
																				IL_0403:
																				if (2 < b)
																				{
																					goto IL_0411;
																				}
																				goto IL_050b;
																				IL_0411:
																				if (3 >= b)
																				{
																					goto IL_041c;
																				}
																				num = 66;
																				goto IL_047d;
																				IL_041c:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_042a;
																				IL_042a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0453;
																				IL_0453:
																				ptr2 += 8;
																				goto IL_0461;
																				IL_0461:
																				num6--;
																				goto end_IL_0264;
																				IL_05d9:
																				num6++;
																				num = 18;
																				goto IL_05f0;
																				IL_047d:
																				if (4 < b)
																				{
																					num = 97;
																					break;
																				}
																				goto IL_0488;
																				IL_0488:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0496;
																				IL_0496:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04d6;
																				IL_04d6:
																				array[num6 - 2] = 0;
																				goto IL_04ea;
																				IL_04ea:
																				num6--;
																				goto end_IL_0264;
																				IL_05f0:
																				ptr2 += 8;
																				goto end_IL_0264;
																				IL_050b:
																				if (2 <= b)
																				{
																					goto IL_0516;
																				}
																				goto IL_057d;
																				IL_0516:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0556;
																				IL_0556:
																				array[num6 - 2] = 0;
																				goto IL_056a;
																				IL_056a:
																				num6--;
																				goto end_IL_0264;
																				IL_057d:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0588;
																				IL_0588:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0595:
																				array[num6] = 0;
																				num = 96;
																				goto IL_05ac;
																				IL_05ac:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05cf;
																			}
																			break;
																			IL_0234:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0623;
																	IL_063f:
																	ptr2 += 8;
																	goto end_IL_0264;
																	IL_0631:
																	num6++;
																	goto IL_063f;
																	IL_0623:
																	array[num6] = 0;
																	goto IL_0631;
																	continue;
																	end_IL_0244:
																	break;
																}
																continue;
																end_IL_0254:
																break;
															}
															continue;
															end_IL_0264:
															break;
														}
														continue;
													}
													goto IL_06fa;
													IL_06fa:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_064d:
													break;
												}
												continue;
												end_IL_0660:
												break;
											}
											continue;
											end_IL_066a:
											break;
										}
										continue;
										end_IL_0675:
										break;
									}
									continue;
									end_IL_068a:
									break;
								}
								continue;
								end_IL_069f:
								break;
							}
							continue;
							end_IL_06af:
							break;
						}
						continue;
						end_IL_06bf:
						break;
					}
					continue;
					end_IL_06cf:
					break;
				}
				continue;
				end_IL_06df:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InheritedSetNumberOfFrames.ReplaceAllLocation);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 44;
															while (true)
															{
																IL_029e:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_027e:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_026e:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_025b:
																							if (8 > b)
																							{
																								num = 27;
																								while (true)
																								{
																									IL_024b:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_01f0:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 112;
																												while (true)
																												{
																													if (num != 112)
																													{
																														if (num != 1093)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 61:
																														case 91:
																															goto IL_01f0;
																														case 48:
																															goto IL_023b;
																														case 27:
																														case 97:
																															goto IL_024b;
																														case 65:
																															goto IL_025b;
																														case 95:
																														case 96:
																															goto IL_026e;
																														case 56:
																															goto IL_027e;
																														case 80:
																															goto IL_028e;
																														case 44:
																															goto IL_029e;
																														case 14:
																															goto end_IL_029e;
																														case 22:
																														case 89:
																															goto end_IL_02ab;
																														case 29:
																															goto IL_02f1;
																														case 82:
																															goto IL_0304;
																														case 11:
																															goto IL_0312;
																														case 45:
																														case 51:
																															goto IL_0320;
																														case 67:
																															goto IL_0343;
																														case 37:
																															goto IL_0351;
																														case 105:
																															goto IL_035f;
																														case 23:
																														case 104:
																															goto IL_0372;
																														case 52:
																															goto IL_03d4;
																														case 60:
																														case 70:
																															goto IL_03f0;
																														case 32:
																															goto IL_03fb;
																														case 8:
																														case 16:
																															goto IL_0409;
																														case 90:
																															goto IL_0425;
																														case 43:
																															goto IL_0433;
																														case 38:
																															goto IL_0446;
																														case 30:
																														case 73:
																															goto IL_0451;
																														case 62:
																															goto IL_045f;
																														case 49:
																															goto IL_0482;
																														case 33:
																															goto IL_048c;
																														case 25:
																															goto IL_049a;
																														case 6:
																														case 7:
																															goto IL_04ad;
																														case 74:
																															goto IL_04bb;
																														case 10:
																														case 94:
																															goto IL_04c6;
																														case 26:
																															goto IL_04ef;
																														case 57:
																															goto IL_04fd;
																														case 84:
																															goto IL_0510;
																														case 19:
																															goto IL_051e;
																														case 1:
																														case 63:
																															goto IL_052c;
																														case 68:
																															goto IL_0545;
																														case 75:
																															goto IL_0553;
																														case 31:
																															goto IL_0561;
																														case 15:
																															goto IL_0571;
																														case 93:
																															goto IL_057c;
																														case 69:
																														case 92:
																															goto IL_0587;
																														case 86:
																															goto IL_059c;
																														case 85:
																															goto IL_05a7;
																														case 0:
																														case 3:
																														case 5:
																														case 9:
																														case 12:
																														case 13:
																														case 21:
																														case 28:
																														case 34:
																														case 36:
																														case 40:
																														case 41:
																														case 46:
																														case 50:
																														case 54:
																														case 58:
																														case 59:
																														case 64:
																														case 71:
																														case 99:
																														case 102:
																															goto end_IL_01dd;
																														case 2:
																														case 4:
																														case 17:
																														case 20:
																														case 24:
																														case 39:
																														case 42:
																														case 47:
																														case 66:
																														case 78:
																														case 81:
																														case 100:
																														case 103:
																															goto end_IL_02c4;
																														case 35:
																															goto end_IL_05c5;
																														case 87:
																															goto end_IL_05d8;
																														case 72:
																															goto end_IL_05e2;
																														case 98:
																															goto end_IL_05ed;
																														case 55:
																														case 101:
																															goto end_IL_0602;
																														case 88:
																															goto end_IL_0612;
																														case 79:
																														case 83:
																															goto end_IL_0622;
																														case 76:
																															goto end_IL_0632;
																														case 77:
																															goto end_IL_0642;
																														case 18:
																														case 53:
																															goto IL_065d;
																														}
																														continue;
																													}
																													array[num5 - 2] = 0;
																													goto IL_02f1;
																													IL_02f1:
																													num5--;
																													goto end_IL_02c4;
																													continue;
																													end_IL_01dd:
																													break;
																												}
																												break;
																											}
																											break;
																											IL_023b:;
																										}
																										break;
																									}
																									goto IL_0304;
																									IL_035f:
																									ptr2 += 8;
																									goto end_IL_02c4;
																									IL_0304:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_0312;
																									IL_0312:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0320;
																									IL_0320:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0343;
																									IL_0343:
																									array[num5] = 0;
																									goto IL_0351;
																									IL_0351:
																									num5++;
																									goto IL_035f;
																								}
																								break;
																							}
																							goto IL_0372;
																							IL_0372:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03d4;
																							IL_03d4:
																							num5 -= 2;
																							goto end_IL_02c4;
																						}
																						break;
																					}
																					num = 60;
																					goto IL_03f0;
																					IL_0425:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0433;
																					IL_0433:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_03f0:
																					if (9 >= b)
																					{
																						goto IL_03fb;
																					}
																					goto IL_0425;
																					IL_03fb:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0409;
																					IL_0409:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02c4;
																				}
																				break;
																			}
																			goto IL_0446;
																			IL_05a7:
																			if (4 <= b)
																			{
																				goto end_IL_02c4;
																			}
																			break;
																			IL_0446:
																			if (5 <= b)
																			{
																				goto IL_0451;
																			}
																			goto IL_04ad;
																			IL_0451:
																			array[num5] = 0;
																			goto IL_045f;
																			IL_045f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0482;
																			IL_0482:
																			array2[num5] = null;
																			goto IL_048c;
																			IL_048c:
																			num5++;
																			goto IL_049a;
																			IL_049a:
																			ptr2 += 8;
																			goto end_IL_02c4;
																			IL_04ad:
																			if (2 >= b)
																			{
																				goto IL_04bb;
																			}
																			goto IL_0571;
																			IL_04bb:
																			if (2 <= b)
																			{
																				goto IL_04c6;
																			}
																			goto IL_0510;
																			IL_04c6:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04ef;
																			IL_04ef:
																			ptr2 += 8;
																			goto IL_04fd;
																			IL_04fd:
																			num5--;
																			goto end_IL_02c4;
																			IL_0510:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_051e;
																			IL_051e:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_052c;
																			IL_052c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0545;
																			IL_0545:
																			array[num5] = 0;
																			goto IL_0553;
																			IL_0553:
																			num5++;
																			goto IL_0561;
																			IL_0561:
																			ptr2 += 8;
																			goto end_IL_02c4;
																			IL_0571:
																			if (3 >= b)
																			{
																				goto IL_057c;
																			}
																			goto IL_059c;
																			IL_057c:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0587;
																			IL_0587:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02c4;
																			IL_059c:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_05a7;
																		}
																		break;
																		IL_028e:;
																	}
																}
																else
																{
																	num = 59;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02c4;
																continue;
																end_IL_029e:
																break;
															}
															continue;
															end_IL_02ab:
															break;
														}
														continue;
														end_IL_02c4:
														break;
													}
													continue;
												}
												goto IL_065d;
												IL_065d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05c5:
												break;
											}
											continue;
											end_IL_05d8:
											break;
										}
										continue;
										end_IL_05e2:
										break;
									}
									continue;
									end_IL_05ed:
									break;
								}
								continue;
								end_IL_0602:
								break;
							}
							continue;
							end_IL_0612:
							break;
						}
						continue;
						end_IL_0622:
						break;
					}
					continue;
					end_IL_0632:
					break;
				}
				continue;
				end_IL_0642:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 80;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 41;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FullSystemTimeVTCARRAY.InfoSoapgetPreserveEventListnerObjectIdentity);
											num = 36;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0279:
															byte b = *ptr2;
															while (true)
															{
																IL_0269:
																ptr2++;
																while (true)
																{
																	IL_0259:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0239:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_022c:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_021c:
																								if (8 < b)
																								{
																									while (9 >= b)
																									{
																										while (9 <= b)
																										{
																											while (true)
																											{
																												IL_01da:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												num = 110;
																												while (num != 110 && num == 1091)
																												{
																													switch (num)
																													{
																													case 2:
																													case 66:
																														goto IL_01da;
																													case 70:
																														goto IL_01fc;
																													case 68:
																													case 103:
																														goto IL_020c;
																													case 67:
																														goto IL_021c;
																													case 19:
																													case 42:
																														goto IL_022c;
																													case 20:
																														goto IL_0239;
																													case 55:
																														goto IL_0249;
																													case 53:
																														goto IL_0259;
																													case 83:
																														goto IL_0269;
																													case 39:
																													case 92:
																														goto IL_0279;
																													case 38:
																														goto IL_0284;
																													case 73:
																														goto IL_0292;
																													case 18:
																														goto IL_02a0;
																													case 94:
																														goto IL_02b0;
																													case 25:
																													case 60:
																														goto IL_02be;
																													case 27:
																														goto IL_02fe;
																													case 63:
																														goto IL_0312;
																													case 54:
																													case 96:
																														goto IL_0325;
																													case 75:
																														goto IL_0365;
																													case 44:
																														goto IL_0379;
																													case 33:
																													case 102:
																														goto IL_038c;
																													case 13:
																														goto IL_03a5;
																													case 56:
																														goto IL_03b3;
																													case 85:
																														goto IL_03c1;
																													case 86:
																														goto IL_03d4;
																													case 89:
																														goto IL_03e2;
																													case 35:
																														goto IL_03f0;
																													case 11:
																													case 61:
																														goto IL_03fb;
																													case 88:
																														goto IL_0409;
																													case 47:
																													case 77:
																														goto IL_041c;
																													case 6:
																														goto IL_045c;
																													case 91:
																														goto IL_0470;
																													case 101:
																														goto IL_0483;
																													case 15:
																														goto IL_048e;
																													case 4:
																													case 22:
																														goto IL_049c;
																													case 1:
																														goto IL_04c5;
																													case 32:
																														goto IL_04d3;
																													case 0:
																														goto IL_04e6;
																													case 30:
																														goto IL_04f4;
																													case 12:
																													case 46:
																														goto IL_0502;
																													case 71:
																														goto IL_0542;
																													case 28:
																														goto IL_055f;
																													case 23:
																													case 48:
																														goto IL_0572;
																													case 87:
																														goto IL_0580;
																													case 57:
																														goto IL_05a3;
																													case 51:
																														goto IL_05ad;
																													case 52:
																														goto IL_05c4;
																													case 7:
																													case 9:
																													case 14:
																													case 21:
																													case 24:
																													case 29:
																													case 34:
																													case 43:
																													case 45:
																													case 58:
																													case 64:
																													case 69:
																													case 72:
																													case 74:
																													case 76:
																													case 90:
																													case 95:
																													case 99:
																														goto end_IL_01fc;
																													case 50:
																														goto IL_05f7;
																													case 16:
																														goto IL_0605;
																													case 37:
																														goto IL_0613;
																													case 3:
																													case 5:
																													case 17:
																													case 59:
																													case 62:
																													case 78:
																													case 82:
																													case 84:
																													case 93:
																													case 100:
																														goto end_IL_01c7;
																													case 36:
																														goto end_IL_0621;
																													case 97:
																														goto end_IL_0634;
																													case 10:
																														goto end_IL_063e;
																													case 41:
																														goto end_IL_0652;
																													case 8:
																														goto end_IL_0667;
																													case 26:
																													case 98:
																														goto end_IL_067c;
																													case 31:
																														goto end_IL_0695;
																													case 40:
																													case 65:
																														goto end_IL_06a5;
																													case 79:
																														goto end_IL_06b5;
																													case 80:
																														goto end_IL_06c5;
																													case 49:
																													case 81:
																														goto IL_06e0;
																													}
																													continue;
																													end_IL_01c7:
																													break;
																												}
																												break;
																											}
																											goto end_IL_0259;
																											continue;
																											end_IL_01fc:
																											break;
																											IL_01fc:;
																										}
																										break;
																										IL_020c:;
																									}
																									break;
																								}
																								goto IL_02b0;
																								IL_0312:
																								num6--;
																								goto end_IL_0259;
																								IL_02b0:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_02be;
																								IL_02be:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_02fe;
																								IL_02fe:
																								array[num6 - 2] = 0;
																								goto IL_0312;
																							}
																							break;
																						}
																						goto IL_0284;
																						IL_03c1:
																						ptr2 += 8;
																						goto end_IL_0259;
																						IL_0284:
																						if (7 > b)
																						{
																							goto IL_0292;
																						}
																						goto IL_038c;
																						IL_0292:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_02a0;
																						IL_02a0:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0325;
																						IL_0325:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0365;
																						IL_0365:
																						array[num6 - 2] = 0;
																						goto IL_0379;
																						IL_0379:
																						num6--;
																						goto end_IL_0259;
																						IL_038c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_03a5;
																						IL_03a5:
																						array[num6] = 0;
																						goto IL_03b3;
																						IL_03b3:
																						num6++;
																						goto IL_03c1;
																					}
																					break;
																				}
																				goto IL_03d4;
																				IL_05c4:
																				ptr2 += 8;
																				goto end_IL_0259;
																				IL_03d4:
																				if (5 > b)
																				{
																					goto IL_03e2;
																				}
																				goto IL_0572;
																				IL_03e2:
																				if (2 >= b)
																				{
																					goto IL_03f0;
																				}
																				goto IL_0483;
																				IL_03f0:
																				if (2 > b)
																				{
																					goto IL_03fb;
																				}
																				goto IL_041c;
																				IL_03fb:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0409;
																				IL_0409:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_041c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_045c;
																				IL_045c:
																				array[num6 - 2] = 0;
																				goto IL_0470;
																				IL_0470:
																				num6--;
																				goto end_IL_0259;
																				IL_0483:
																				if (3 >= b)
																				{
																					goto IL_048e;
																				}
																				goto IL_04e6;
																				IL_048e:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_049c;
																				IL_049c:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04c5;
																				IL_04c5:
																				ptr2 += 8;
																				goto IL_04d3;
																				IL_04d3:
																				num6--;
																				goto end_IL_0259;
																				IL_04e6:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_04f4;
																				IL_04f4:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0502;
																				IL_0502:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0542;
																				IL_0542:
																				array[num6 - 2] = 0;
																				num = 28;
																				goto IL_055f;
																				IL_055f:
																				num6--;
																				goto end_IL_0259;
																				IL_0572:
																				array[num6] = 0;
																				goto IL_0580;
																				IL_0580:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05a3;
																				IL_05a3:
																				array2[num6] = null;
																				goto IL_05ad;
																				IL_05ad:
																				num6++;
																				num = 52;
																				goto IL_05c4;
																			}
																			break;
																			IL_0249:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05f7;
																	IL_0613:
																	ptr2 += 8;
																	break;
																	IL_0605:
																	num6++;
																	goto IL_0613;
																	IL_05f7:
																	array[num6] = 0;
																	goto IL_0605;
																	continue;
																	end_IL_0259:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06e0;
													IL_06e0:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0621:
													break;
												}
												continue;
												end_IL_0634:
												break;
											}
											continue;
											end_IL_063e:
											break;
										}
										continue;
										end_IL_0652:
										break;
									}
									continue;
									end_IL_0667:
									break;
								}
								continue;
								end_IL_067c:
								break;
							}
							continue;
							end_IL_0695:
							break;
						}
						continue;
						end_IL_06a5:
						break;
					}
					continue;
					end_IL_06b5:
					break;
				}
				continue;
				end_IL_06c5:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 12;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllWindowsWindowsDeviceClaim.EventWaitHandleSecuritySourceValid);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02be:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02ae:
																		if (b <= 11)
																		{
																			while (true)
																			{
																				IL_02a1:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0294:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0284:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0274:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_0244:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_021f:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_020a:
																																array2[num5] = null;
																																num = 122;
																																while (true)
																																{
																																	if (num != 122)
																																	{
																																		if (num != 1103)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 40:
																																			goto IL_020a;
																																		case 71:
																																			goto IL_021f;
																																		case 33:
																																		case 115:
																																			goto IL_0244;
																																		case 70:
																																			goto IL_0254;
																																		case 26:
																																		case 62:
																																			goto IL_0264;
																																		case 23:
																																			goto IL_0274;
																																		case 101:
																																			goto IL_0284;
																																		case 45:
																																			goto IL_0294;
																																		case 60:
																																			goto IL_02a1;
																																		case 35:
																																			goto IL_02ae;
																																		case 52:
																																			goto IL_02be;
																																		case 77:
																																			goto end_IL_02be;
																																		case 8:
																																		case 21:
																																			goto end_IL_02ce;
																																		case 6:
																																		case 25:
																																			goto IL_02e9;
																																		case 13:
																																		case 29:
																																			goto IL_032b;
																																		case 59:
																																			goto IL_033b;
																																		case 18:
																																			goto IL_034f;
																																		case 64:
																																		case 68:
																																			goto IL_0362;
																																		case 31:
																																			goto IL_0370;
																																		case 84:
																																			goto IL_0389;
																																		case 10:
																																		case 86:
																																			goto IL_0399;
																																		case 87:
																																			goto IL_03b5;
																																		case 67:
																																			goto IL_03c0;
																																		case 5:
																																		case 28:
																																			goto IL_03ce;
																																		case 80:
																																			goto IL_03e7;
																																		case 55:
																																			goto IL_03f5;
																																		case 20:
																																			goto IL_040c;
																																		case 39:
																																		case 88:
																																			goto IL_041f;
																																		case 109:
																																			goto IL_0437;
																																		case 50:
																																			goto IL_0445;
																																		case 24:
																																		case 110:
																																			goto IL_0453;
																																		case 32:
																																			goto end_IL_01f7;
																																		case 99:
																																			goto IL_048a;
																																		case 111:
																																			goto IL_049d;
																																		case 0:
																																		case 107:
																																			goto IL_04b4;
																																		case 74:
																																			goto IL_04c2;
																																		case 66:
																																			goto IL_04d0;
																																		case 53:
																																		case 97:
																																			goto IL_04de;
																																		case 19:
																																			goto IL_0501;
																																		case 63:
																																			goto IL_050f;
																																		case 83:
																																			goto IL_0526;
																																		case 43:
																																		case 82:
																																			goto IL_0539;
																																		case 106:
																																			goto IL_059b;
																																		case 41:
																																		case 112:
																																			goto IL_05b7;
																																		case 108:
																																			goto IL_05c5;
																																		case 113:
																																			goto IL_05d8;
																																		case 47:
																																		case 114:
																																			goto IL_05e6;
																																		case 7:
																																			goto IL_0626;
																																		case 75:
																																			goto IL_063a;
																																		case 78:
																																			goto IL_0658;
																																		case 57:
																																			goto IL_0671;
																																		case 2:
																																		case 4:
																																		case 14:
																																		case 17:
																																		case 30:
																																		case 34:
																																		case 37:
																																		case 38:
																																		case 44:
																																		case 46:
																																		case 54:
																																		case 56:
																																		case 58:
																																		case 69:
																																		case 72:
																																		case 79:
																																		case 81:
																																		case 85:
																																		case 89:
																																		case 92:
																																		case 93:
																																		case 102:
																																		case 104:
																																			goto end_IL_0254;
																																		case 3:
																																		case 22:
																																		case 27:
																																		case 36:
																																		case 48:
																																		case 49:
																																		case 51:
																																		case 73:
																																		case 76:
																																		case 90:
																																		case 91:
																																		case 95:
																																		case 103:
																																		case 105:
																																			goto end_IL_02de;
																																		case 15:
																																			goto end_IL_069a;
																																		case 100:
																																			goto end_IL_06ad;
																																		case 9:
																																			goto end_IL_06b7;
																																		case 94:
																																			goto end_IL_06c2;
																																		case 42:
																																		case 96:
																																			goto end_IL_06d7;
																																		case 98:
																																			goto end_IL_06e7;
																																		case 16:
																																		case 65:
																																			goto end_IL_06f7;
																																		case 11:
																																			goto end_IL_0707;
																																		case 12:
																																			goto end_IL_0717;
																																		case 1:
																																		case 61:
																																			goto IL_0732;
																																		}
																																		continue;
																																	}
																																	num5++;
																																	goto IL_0658;
																																	IL_0658:
																																	ptr2 += 8;
																																	num = 49;
																																	goto end_IL_02de;
																																	continue;
																																	end_IL_01f7:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_047c;
																													continue;
																													end_IL_0254:
																													break;
																													IL_0254:;
																												}
																												break;
																												IL_0264:;
																											}
																											break;
																										}
																										goto IL_0671;
																										IL_0671:
																										if (4 > b)
																										{
																											break;
																										}
																										goto end_IL_02de;
																									}
																									break;
																								}
																								goto IL_0389;
																								IL_048a:
																								num5--;
																								goto end_IL_02de;
																								IL_0389:
																								if (3 > b)
																								{
																									goto IL_03b5;
																								}
																								goto IL_041f;
																								IL_041f:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02de;
																								IL_03b5:
																								if (1 >= b)
																								{
																									goto IL_03c0;
																								}
																								goto IL_0437;
																								IL_03c0:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_03ce;
																								IL_03ce:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_03e7;
																								IL_03e7:
																								array[num5] = 0;
																								goto IL_03f5;
																								IL_03f5:
																								num5++;
																								num = 20;
																								goto IL_040c;
																								IL_040c:
																								ptr2 += 8;
																								goto end_IL_02de;
																								IL_0437:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_0445;
																								IL_0445:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_0453;
																								IL_0453:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_047c;
																								IL_047c:
																								ptr2 += 8;
																								goto IL_048a;
																							}
																							break;
																						}
																						goto IL_02e9;
																						IL_034f:
																						num5--;
																						goto end_IL_02de;
																						IL_02e9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_033b;
																						IL_033b:
																						array[num5 - 2] = 0;
																						goto IL_034f;
																					}
																					break;
																				}
																				goto IL_032b;
																				IL_063a:
																				num5--;
																				goto end_IL_02de;
																				IL_032b:
																				if (9 < b)
																				{
																					goto IL_0362;
																				}
																				goto IL_049d;
																				IL_0362:
																				if (10 >= b)
																				{
																					goto IL_0370;
																				}
																				goto IL_05b7;
																				IL_0370:
																				if (10 > b)
																				{
																					break;
																				}
																				num = 86;
																				goto IL_0399;
																				IL_0539:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_059b;
																				IL_0399:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02de;
																				IL_05b7:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_05c5;
																				IL_05c5:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_049d:
																				if (9 > b)
																				{
																					num = 107;
																					goto IL_04b4;
																				}
																				goto IL_0539;
																				IL_059b:
																				num5 -= 2;
																				num = 73;
																				goto end_IL_02de;
																				IL_04b4:
																				if (7 < b)
																				{
																					goto IL_04c2;
																				}
																				goto IL_05d8;
																				IL_04c2:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_04d0;
																				IL_04d0:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04de;
																				IL_04de:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0501;
																				IL_0501:
																				array[num5] = 0;
																				goto IL_050f;
																				IL_050f:
																				num5++;
																				num = 83;
																				goto IL_0526;
																				IL_0526:
																				ptr2 += 8;
																				goto end_IL_02de;
																				IL_05d8:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05e6;
																				IL_05e6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0626;
																				IL_0626:
																				array[num5 - 2] = 0;
																				goto IL_063a;
																			}
																		}
																		else
																		{
																			num = 81;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02de;
																continue;
																end_IL_02be:
																break;
															}
															continue;
															end_IL_02ce:
															break;
														}
														continue;
														end_IL_02de:
														break;
													}
													continue;
												}
												goto IL_0732;
												IL_0732:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_069a:
												break;
											}
											continue;
											end_IL_06ad:
											break;
										}
										continue;
										end_IL_06b7:
										break;
									}
									continue;
									end_IL_06c2:
									break;
								}
								continue;
								end_IL_06d7:
								break;
							}
							continue;
							end_IL_06e7:
							break;
						}
						continue;
						end_IL_06f7:
						break;
					}
					continue;
					end_IL_0707:
					break;
				}
				continue;
				end_IL_0717:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getActualValueIConnectionPoint.CurrencyPositivePatternThrowOnUnmappableCharUseAssem);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 18;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02ae:
																		if (b >= 1)
																		{
																			while (b <= 10)
																			{
																				while (true)
																				{
																					IL_028e:
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_027e:
																							if (8 >= b)
																							{
																								while (true)
																								{
																									IL_0271:
																									if (8 > b)
																									{
																										while (true)
																										{
																											IL_0261:
																											if (6 < b)
																											{
																												while (7 >= b)
																												{
																													while (7 <= b)
																													{
																														while (true)
																														{
																															IL_0228:
																															array[num5] = 0;
																															num = 65;
																															while (true)
																															{
																																IL_0203:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																while (true)
																																{
																																	IL_01f7:
																																	array2[num5] = null;
																																	while (true)
																																	{
																																		IL_01de:
																																		num5++;
																																		num = 111;
																																		while (true)
																																		{
																																			if (num != 111)
																																			{
																																				if (num != 1092)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 68:
																																					goto IL_01de;
																																				case 38:
																																					goto IL_01f7;
																																				case 65:
																																					goto IL_0203;
																																				case 69:
																																				case 103:
																																					goto IL_0228;
																																				case 10:
																																					goto IL_0241;
																																				case 92:
																																					goto IL_0251;
																																				case 13:
																																					goto IL_0261;
																																				case 61:
																																					goto IL_0271;
																																				case 14:
																																				case 97:
																																					goto IL_027e;
																																				case 78:
																																					goto IL_028e;
																																				case 95:
																																					goto IL_029e;
																																				case 58:
																																					goto IL_02ae;
																																				case 20:
																																					goto end_IL_01cb;
																																				case 18:
																																					goto end_IL_02be;
																																				case 102:
																																					goto end_IL_02ce;
																																				case 15:
																																				case 34:
																																					goto IL_02e4;
																																				case 5:
																																					goto IL_02f2;
																																				case 36:
																																					goto IL_0316;
																																				case 8:
																																				case 48:
																																					goto IL_0326;
																																				case 46:
																																					goto IL_0331;
																																				case 9:
																																				case 27:
																																					goto IL_033f;
																																				case 21:
																																					goto IL_0352;
																																				case 49:
																																					goto IL_0360;
																																				case 12:
																																				case 37:
																																					goto IL_036e;
																																				case 84:
																																					goto IL_038a;
																																				case 85:
																																					goto IL_03b9;
																																				case 23:
																																					goto IL_03cc;
																																				case 50:
																																				case 73:
																																					goto IL_03da;
																																				case 22:
																																				case 53:
																																					goto IL_03e8;
																																				case 77:
																																					goto IL_03f3;
																																				case 39:
																																					goto IL_0401;
																																				case 25:
																																				case 76:
																																					goto IL_040f;
																																				case 31:
																																					goto IL_0438;
																																				case 29:
																																					goto IL_0446;
																																				case 101:
																																					goto IL_0459;
																																				case 80:
																																				case 86:
																																					goto IL_0467;
																																				case 45:
																																					goto IL_04b0;
																																				case 79:
																																					goto IL_04c4;
																																				case 75:
																																					goto IL_04d7;
																																				case 16:
																																				case 87:
																																					goto IL_04e5;
																																				case 74:
																																					goto IL_0553;
																																				case 35:
																																				case 47:
																																					goto IL_0566;
																																				case 96:
																																					goto IL_0571;
																																				case 88:
																																				case 91:
																																					goto IL_057e;
																																				case 0:
																																				case 3:
																																				case 11:
																																				case 19:
																																				case 24:
																																				case 30:
																																				case 32:
																																				case 33:
																																				case 44:
																																				case 59:
																																				case 60:
																																				case 62:
																																				case 72:
																																				case 82:
																																				case 89:
																																				case 93:
																																				case 99:
																																				case 104:
																																					goto end_IL_0241;
																																				case 40:
																																					goto IL_05b6;
																																				case 28:
																																					goto IL_05c4;
																																				case 83:
																																					goto IL_05d2;
																																				case 2:
																																				case 6:
																																				case 26:
																																				case 41:
																																				case 42:
																																				case 52:
																																				case 57:
																																				case 63:
																																				case 64:
																																				case 71:
																																				case 81:
																																				case 98:
																																				case 100:
																																					goto end_IL_02d9;
																																				case 4:
																																					goto end_IL_05e9;
																																				case 51:
																																					goto end_IL_05fc;
																																				case 94:
																																					goto end_IL_0606;
																																				case 1:
																																					goto end_IL_0611;
																																				case 67:
																																					goto end_IL_0626;
																																				case 43:
																																				case 90:
																																					goto end_IL_063b;
																																				case 66:
																																					goto end_IL_064b;
																																				case 7:
																																				case 70:
																																					goto end_IL_065b;
																																				case 55:
																																					goto end_IL_066b;
																																				case 56:
																																					goto end_IL_067b;
																																				case 17:
																																				case 54:
																																					goto IL_0696;
																																				}
																																				continue;
																																			}
																																			ptr2 += 8;
																																			num = 52;
																																			goto end_IL_02d9;
																																			continue;
																																			end_IL_01cb:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02ae;
																														continue;
																														end_IL_0241:
																														break;
																														IL_0241:;
																													}
																													break;
																													IL_0251:;
																												}
																												break;
																											}
																											goto IL_03b9;
																											IL_03b9:
																											if (6 > b)
																											{
																												break;
																											}
																											goto end_IL_02d9;
																										}
																										break;
																									}
																									goto IL_02e4;
																									IL_038a:
																									ptr2 += 8;
																									goto end_IL_02d9;
																									IL_02e4:
																									array[num5] = 0;
																									goto IL_02f2;
																									IL_02f2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)DelegateSealed[*(int*)(ptr2 + num3)])();
																									goto IL_0316;
																									IL_0316:
																									num5++;
																									goto IL_038a;
																								}
																								break;
																							}
																							goto IL_0326;
																							IL_036e:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_02d9;
																							IL_0326:
																							if (9 >= b)
																							{
																								goto IL_0331;
																							}
																							goto IL_0352;
																							IL_0331:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_033f;
																							IL_033f:
																							num5--;
																							goto end_IL_02d9;
																							IL_0352:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0360;
																							IL_0360:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_036e;
																						}
																						break;
																					}
																					goto IL_03cc;
																					IL_057e:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_02d9;
																					IL_03cc:
																					if (5 > b)
																					{
																						goto IL_03da;
																					}
																					goto IL_057e;
																					IL_03da:
																					if (2 < b)
																					{
																						goto IL_03e8;
																					}
																					goto IL_04d7;
																					IL_03e8:
																					if (3 < b)
																					{
																						goto IL_03f3;
																					}
																					goto IL_0459;
																					IL_03f3:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_0401;
																					IL_0401:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_040f;
																					IL_040f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0438;
																					IL_0438:
																					ptr2 += 8;
																					goto IL_0446;
																					IL_0446:
																					num5--;
																					goto end_IL_02d9;
																					IL_0459:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0467;
																					IL_0467:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 45;
																					goto IL_04b0;
																					IL_04b0:
																					array[num5 - 2] = 0;
																					goto IL_04c4;
																					IL_04c4:
																					num5--;
																					goto end_IL_02d9;
																					IL_04d7:
																					if (2 <= b)
																					{
																						goto IL_04e5;
																					}
																					goto IL_0566;
																					IL_04e5:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0553;
																					IL_0553:
																					num5 -= 2;
																					goto end_IL_02d9;
																					IL_0566:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0571;
																					IL_0571:
																					if (1 <= b)
																					{
																					}
																					break;
																				}
																				break;
																				IL_029e:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05b6;
																		IL_05d2:
																		ptr2 += 8;
																		num = 26;
																		goto end_IL_02d9;
																		IL_05c4:
																		num5++;
																		goto IL_05d2;
																		IL_05b6:
																		array[num5] = 0;
																		goto IL_05c4;
																		continue;
																		end_IL_02ae:
																		break;
																	}
																	continue;
																	end_IL_02be:
																	break;
																}
																continue;
																end_IL_02ce:
																break;
															}
															continue;
															end_IL_02d9:
															break;
														}
														continue;
													}
													goto IL_0696;
													IL_0696:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05e9:
													break;
												}
												continue;
												end_IL_05fc:
												break;
											}
											continue;
											end_IL_0606:
											break;
										}
										continue;
										end_IL_0611:
										break;
									}
									continue;
									end_IL_0626:
									break;
								}
								continue;
								end_IL_063b:
								break;
							}
							continue;
							end_IL_064b:
							break;
						}
						continue;
						end_IL_065b:
						break;
					}
					continue;
					end_IL_066b:
					break;
				}
				continue;
				end_IL_067b:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 120;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 137;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct73.getImportPathgetUnmappedIdentities);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 136;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 118;
															while (true)
															{
																IL_0376:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0359:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_0349:
																					if (13 >= b)
																					{
																						while (true)
																						{
																							IL_0339:
																							if (13 > b)
																							{
																								while (true)
																								{
																									IL_0329:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_0319:
																											if (11 <= b)
																											{
																												while (true)
																												{
																													IL_02ca:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													num = 170;
																													while (true)
																													{
																														if (num != 170)
																														{
																															if (num != 1151)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 86:
																															case 91:
																																goto IL_02ca;
																															case 92:
																																goto IL_0319;
																															case 21:
																															case 148:
																																goto IL_0329;
																															case 4:
																																goto IL_0339;
																															case 68:
																																goto IL_0349;
																															case 116:
																																goto IL_0359;
																															case 9:
																																goto end_IL_0359;
																															case 118:
																																goto IL_0376;
																															case 83:
																																goto end_IL_0376;
																															case 46:
																															case 96:
																																goto end_IL_0386;
																															case 40:
																																goto IL_03aa;
																															case 49:
																																goto IL_03ba;
																															case 0:
																															case 63:
																																goto IL_03cd;
																															case 36:
																															case 80:
																																goto IL_0434;
																															case 110:
																																goto IL_043f;
																															case 31:
																																goto IL_044a;
																															case 109:
																																goto IL_0458;
																															case 112:
																															case 124:
																																goto IL_0474;
																															case 97:
																															case 125:
																																goto IL_0494;
																															case 11:
																															case 25:
																																goto IL_049f;
																															case 130:
																																goto IL_04af;
																															case 131:
																																goto IL_04c2;
																															case 138:
																																goto IL_04d5;
																															case 50:
																															case 70:
																																goto IL_04e0;
																															case 10:
																																goto IL_0528;
																															case 113:
																																goto IL_053b;
																															case 64:
																																goto IL_0549;
																															case 140:
																																goto IL_055c;
																															case 55:
																															case 129:
																																goto IL_056a;
																															case 127:
																																goto IL_0578;
																															case 87:
																																goto IL_059b;
																															case 35:
																																goto IL_05a5;
																															case 15:
																																goto IL_05b3;
																															case 142:
																																goto IL_05c6;
																															case 41:
																															case 101:
																																goto IL_05d1;
																															case 77:
																																goto IL_05df;
																															case 14:
																															case 52:
																																goto IL_05f2;
																															case 48:
																																goto IL_0632;
																															case 6:
																															case 144:
																																goto IL_064b;
																															case 114:
																																goto IL_0662;
																															case 65:
																																goto IL_067a;
																															case 102:
																																goto IL_0688;
																															case 67:
																															case 146:
																																goto end_IL_02b7;
																															case 57:
																																goto IL_06c4;
																															case 75:
																																goto IL_06d2;
																															case 151:
																																goto IL_06ee;
																															case 155:
																																goto IL_0701;
																															case 156:
																																goto IL_0714;
																															case 158:
																																goto IL_0727;
																															case 123:
																															case 139:
																																goto IL_0735;
																															case 72:
																																goto IL_075e;
																															case 152:
																															case 160:
																																goto IL_0777;
																															case 54:
																																goto IL_0790;
																															case 5:
																																goto IL_079e;
																															case 159:
																																goto IL_07ac;
																															case 163:
																																goto IL_07bf;
																															case 8:
																																goto IL_07ca;
																															case 81:
																															case 153:
																																goto IL_07d8;
																															case 7:
																																goto IL_0812;
																															case 90:
																																goto IL_0825;
																															case 121:
																																goto IL_0833;
																															case 29:
																															case 59:
																																goto IL_083e;
																															case 122:
																																goto IL_087e;
																															case 24:
																																goto IL_0892;
																															case 98:
																																goto IL_08b3;
																															case 28:
																																goto IL_08c1;
																															case 74:
																																goto IL_08cc;
																															case 30:
																																goto IL_08da;
																															case 27:
																															case 53:
																																goto IL_08e8;
																															case 45:
																																goto IL_08f6;
																															case 17:
																																goto IL_091a;
																															case 106:
																																goto IL_0928;
																															case 18:
																															case 111:
																																goto IL_0941;
																															case 66:
																																goto IL_0951;
																															case 32:
																															case 44:
																																goto IL_095c;
																															case 42:
																																goto IL_0967;
																															case 16:
																																goto IL_0974;
																															case 76:
																															case 134:
																																goto IL_097f;
																															case 1:
																															case 3:
																															case 12:
																															case 20:
																															case 23:
																															case 26:
																															case 34:
																															case 37:
																															case 38:
																															case 39:
																															case 43:
																															case 60:
																															case 62:
																															case 69:
																															case 71:
																															case 73:
																															case 79:
																															case 84:
																															case 93:
																															case 107:
																															case 108:
																															case 115:
																															case 117:
																															case 128:
																															case 133:
																															case 141:
																															case 145:
																															case 147:
																															case 150:
																															case 154:
																															case 161:
																																goto end_IL_0366;
																															case 2:
																															case 13:
																															case 33:
																															case 47:
																															case 51:
																															case 56:
																															case 58:
																															case 78:
																															case 82:
																															case 94:
																															case 99:
																															case 103:
																															case 104:
																															case 105:
																															case 126:
																															case 132:
																															case 135:
																															case 136:
																															case 143:
																															case 157:
																																goto end_IL_039f;
																															case 89:
																																goto end_IL_09b4;
																															case 137:
																																goto end_IL_09c7;
																															case 85:
																																goto end_IL_09da;
																															case 61:
																																goto end_IL_09e5;
																															case 22:
																															case 149:
																																goto end_IL_09fe;
																															case 19:
																																goto end_IL_0a0e;
																															case 95:
																															case 100:
																																goto end_IL_0a1e;
																															case 119:
																																goto end_IL_0a2e;
																															case 120:
																																goto end_IL_0a3e;
																															case 88:
																															case 162:
																																goto IL_0a59;
																															}
																															continue;
																														}
																														array[num5 - 2] = 0;
																														goto IL_0812;
																														IL_0812:
																														num5--;
																														goto end_IL_039f;
																														continue;
																														end_IL_02b7:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_03ba;
																											IL_05b3:
																											ptr2 += 8;
																											goto end_IL_039f;
																											IL_03ba:
																											if (10 < b)
																											{
																												goto end_IL_0366;
																											}
																											goto IL_055c;
																											IL_055c:
																											if (10 > b)
																											{
																												goto end_IL_0366;
																											}
																											goto IL_056a;
																											IL_056a:
																											array[num5] = 0;
																											goto IL_0578;
																											IL_0578:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_059b;
																											IL_059b:
																											array2[num5] = null;
																											goto IL_05a5;
																											IL_05a5:
																											num5++;
																											goto IL_05b3;
																										}
																										break;
																									}
																									goto IL_0825;
																									IL_0892:
																									num5--;
																									goto end_IL_039f;
																									IL_0825:
																									if (12 < b)
																									{
																										goto end_IL_0366;
																									}
																									goto IL_0833;
																									IL_0833:
																									if (12 > b)
																									{
																										num = 69;
																										goto end_IL_0366;
																									}
																									goto IL_083e;
																									IL_083e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_087e;
																									IL_087e:
																									array[num5 - 2] = 0;
																									goto IL_0892;
																								}
																								break;
																							}
																							goto IL_03cd;
																							IL_0701:
																							num5 -= 2;
																							goto end_IL_039f;
																							IL_03cd:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0701;
																						}
																						break;
																					}
																					goto IL_08b3;
																					IL_0974:
																					if (16 > b)
																					{
																						goto end_IL_0366;
																					}
																					goto IL_097f;
																					IL_08b3:
																					if (15 >= b)
																					{
																						goto IL_08c1;
																					}
																					goto IL_0951;
																					IL_08c1:
																					if (15 > b)
																					{
																						goto IL_08cc;
																					}
																					num = 18;
																					goto IL_0941;
																					IL_08cc:
																					if (14 < b)
																					{
																						goto end_IL_0366;
																					}
																					goto IL_08da;
																					IL_08da:
																					if (14 > b)
																					{
																						goto end_IL_0366;
																					}
																					goto IL_08e8;
																					IL_08e8:
																					array[num5] = 0;
																					goto IL_08f6;
																					IL_08f6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)intptr_0[*(int*)(ptr2 + num3)])();
																					goto IL_091a;
																					IL_091a:
																					num5++;
																					goto IL_0928;
																					IL_0928:
																					ptr2 += 8;
																					goto end_IL_039f;
																					IL_097f:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_039f;
																					IL_0941:
																					num5--;
																					goto end_IL_039f;
																					IL_0951:
																					if (16 < b)
																					{
																						goto IL_095c;
																					}
																					goto IL_0974;
																					IL_095c:
																					if (17 < b)
																					{
																						goto end_IL_0366;
																					}
																					goto IL_0967;
																					IL_0967:
																					if (17 <= b)
																					{
																					}
																					goto end_IL_0366;
																				}
																				goto IL_069b;
																			}
																			goto IL_03aa;
																			IL_0662:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_067a;
																			IL_03aa:
																			if (9 <= b)
																			{
																				goto end_IL_039f;
																			}
																			goto IL_0434;
																			IL_0434:
																			if (4 >= b)
																			{
																				goto IL_043f;
																			}
																			goto IL_0494;
																			IL_043f:
																			if (4 > b)
																			{
																				goto IL_044a;
																			}
																			goto IL_0474;
																			IL_044a:
																			if (2 < b)
																			{
																				goto IL_0458;
																			}
																			goto IL_05c6;
																			IL_0458:
																			if (3 < b)
																			{
																				num = 115;
																				goto end_IL_0366;
																			}
																			goto IL_0727;
																			IL_067a:
																			num5++;
																			goto IL_0688;
																			IL_0727:
																			if (3 > b)
																			{
																				goto end_IL_0366;
																			}
																			goto IL_0735;
																			IL_0735:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_075e;
																			IL_075e:
																			array[num5 - 1] = 5;
																			goto end_IL_039f;
																			IL_05c6:
																			if (2 > b)
																			{
																				goto IL_05d1;
																			}
																			goto IL_05f2;
																			IL_05d1:
																			if (1 < b)
																			{
																				goto end_IL_0366;
																			}
																			goto IL_05df;
																			IL_05df:
																			if (1 > b)
																			{
																				goto end_IL_0366;
																			}
																			goto IL_0777;
																			IL_0777:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0790;
																			IL_0790:
																			array[num5] = 0;
																			goto IL_079e;
																			IL_079e:
																			num5++;
																			goto IL_07ac;
																			IL_07ac:
																			ptr2 += 8;
																			goto end_IL_039f;
																			IL_05f2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0632;
																			IL_0632:
																			array[num5 - 2] = 0;
																			goto IL_0714;
																			IL_0714:
																			num5--;
																			goto end_IL_039f;
																			IL_0474:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_04af;
																			IL_04af:
																			ptr2 += 8;
																			goto IL_06ee;
																			IL_06ee:
																			num5--;
																			goto end_IL_039f;
																			IL_0494:
																			if (6 < b)
																			{
																				goto IL_049f;
																			}
																			goto IL_04d5;
																			IL_049f:
																			if (7 >= b)
																			{
																				goto IL_04c2;
																			}
																			goto IL_07bf;
																			IL_04c2:
																			if (7 > b)
																			{
																				goto end_IL_0366;
																			}
																			goto IL_069b;
																			IL_069b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06c4;
																			IL_06c4:
																			ptr2 += 8;
																			goto IL_06d2;
																			IL_06d2:
																			num5--;
																			num = 105;
																			goto end_IL_039f;
																			IL_07bf:
																			if (8 < b)
																			{
																				num = 38;
																				goto end_IL_0366;
																			}
																			goto IL_07ca;
																			IL_07ca:
																			if (8 > b)
																			{
																				goto end_IL_0366;
																			}
																			goto IL_07d8;
																			IL_07d8:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_039f;
																			IL_0688:
																			ptr2 += 8;
																			goto end_IL_039f;
																			IL_04d5:
																			if (6 <= b)
																			{
																				goto IL_04e0;
																			}
																			goto IL_053b;
																			IL_04e0:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 10;
																			goto IL_0528;
																			IL_0528:
																			num5 -= 3;
																			goto end_IL_039f;
																			IL_053b:
																			if (5 < b)
																			{
																				goto end_IL_0366;
																			}
																			goto IL_0549;
																			IL_0549:
																			if (5 > b)
																			{
																				goto end_IL_0366;
																			}
																			goto IL_064b;
																			IL_064b:
																			array[num5] = 5;
																			num = 114;
																			goto IL_0662;
																			continue;
																			end_IL_0359:
																			break;
																		}
																		continue;
																		end_IL_0366:
																		break;
																	}
																}
																else
																{
																	num = 34;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_039f;
																continue;
																end_IL_0376:
																break;
															}
															continue;
															end_IL_0386:
															break;
														}
														continue;
														end_IL_039f:
														break;
													}
													continue;
												}
												goto IL_0a59;
												IL_0a59:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09b4:
												break;
											}
											continue;
											end_IL_09c7:
											break;
										}
										continue;
										end_IL_09da:
										break;
									}
									continue;
									end_IL_09e5:
									break;
								}
								continue;
								end_IL_09fe:
								break;
							}
							continue;
							end_IL_0a0e:
							break;
						}
						continue;
						end_IL_0a1e:
						break;
					}
					continue;
					end_IL_0a2e:
					break;
				}
				continue;
				end_IL_0a3e:
				break;
			}
		}
	}

	private static int smethod_6(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			return num - num2;
		}
		num = int_1;
		num2 = int_2;
		return num - num2;
	}

	private static int smethod_7()
	{
		int num = 39;
		int num2 = 13;
		num = 3;
		object obj = new int[3];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 126;
		num3 = 18;
		((int[])obj)[0] = 18;
		obj = obj2;
		num2 = 1;
		num3 = 245;
		num3 = 49;
		((int[])obj)[1] = 49;
		obj = obj2;
		num2 = 4;
		num3 = 2;
		num2 = 2;
		num3 = 72;
		num3 = 36;
		((int[])obj)[2] = 36;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 9;
			num3 = 3;
			num2 = 3;
			if (num >= 3)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	static Class119()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num == 12 || num != 993)
						{
							return;
						}
						switch (num)
						{
						case 3:
							goto end_IL_0039;
						case 1:
							goto end_IL_0046;
						case 2:
							goto end_IL_0052;
						case 0:
							return;
						case 4:
							return;
						case 5:
							return;
						}
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_0052:
				break;
			}
		}
	}
}
