using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using HarmonyLib;

[HarmonyPatch]
internal class Class2
{
	private static bool bool_0;

	private static bool bool_1;

	private static float float_0;

	private static float float_1;

	private static bool bool_2;

	private static IntPtr[] addResourceResolveFilterNameIgnoreCase;

	private static IntPtr[] intptr_0;

	private static IntPtr[] EnumerablePartitionerOptionsProgressNotification;

	private unsafe static MethodBase TargetMethod()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0499, IL_04ac, IL_04ca, IL_04da, IL_04ea, IL_04fa, IL_050a, IL_051a, IL_052a, IL_0537, IL_0547, IL_0557, IL_0567, IL_0572, IL_057d, IL_058b, IL_059b, IL_05ab, IL_05b9, IL_05cc, IL_05da, IL_05ea, IL_05fd, IL_060b, IL_0616, IL_0626, IL_0666, IL_067a, IL_068d, IL_06a0, IL_06ce, IL_0714, IL_071f, IL_072d, IL_0745, IL_0753, IL_075c, IL_076f, IL_077d, IL_078b, IL_0799, IL_07b2, IL_07c0, IL_07ce, IL_07e1, IL_07ec, IL_07fa, IL_080d, IL_0818, IL_0826, IL_0839, IL_0855, IL_0868, IL_0891, IL_089f, IL_08b2, IL_0900, IL_090e, IL_091c, IL_0935, IL_0949, IL_09b3, IL_09c1, IL_09d4, IL_09e2, IL_09f0, IL_09fa, IL_0a08, IL_0a24, IL_0a32, IL_0a3d, IL_0a4b, IL_0a5e, IL_0a7b, IL_0aca, IL_0ad4, IL_0b01, IL_0b15, IL_0b23, IL_0b36, IL_0b44, IL_0b6c, IL_0b7a, IL_0b88, IL_0ba6, IL_0bb9, IL_0bcd, IL_0be0, IL_0bee, IL_0bf9, IL_0c07, IL_0c15, IL_0c28, IL_0c68, IL_0c85, IL_0ca1, IL_0caa, IL_0cbd, IL_0cfb, IL_0d0e, IL_0d21, IL_0d3a, IL_0d48, IL_0d56, IL_0d6e, IL_0d85, IL_0d98, IL_0dd7, IL_0dea, IL_0e07, IL_0e1a, IL_0e2d, IL_0e3b, IL_0e9d, IL_0eb0, IL_0eba, IL_0ec8, IL_0edb, IL_0ee9, IL_0f29, IL_0f3d, IL_0f50, IL_0f68, IL_0f86, IL_0faa, IL_0fc2, IL_0fd5, IL_0fe3, IL_0ff6, IL_1004, IL_1012, IL_1052, IL_1066, IL_1082, IL_1096, IL_10d7, IL_10ea, IL_10f8, IL_1106, IL_1158, IL_116b, IL_1179, IL_1187, IL_1195, IL_11a9, IL_11e1, IL_11fa, IL_121c, IL_122a, IL_1238, IL_1248, IL_125b, IL_126e, IL_1278, IL_1283, IL_1293, IL_12a3, IL_12b3, IL_12c3, IL_12d3, IL_12e3, IL_12f3, IL_1303, IL_131e are reachable both inside and outside the pinned region starting at IL_1318. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 173;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			object[] array8;
			int num9;
			byte* num10;
			int __rxRef93 = default(int);
			ref int reference = ref __rxRef93;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1303:
					num2 = 1;
					while (true)
					{
						IL_12f3:
						num3 = num2 * 4;
						while (true)
						{
							IL_12e3:
							num4 = num2 * 8;
							while (true)
							{
								IL_12d3:
								array2 = new byte[4];
								while (true)
								{
									IL_12c3:
									array3 = new object[4];
									while (true)
									{
										IL_12b3:
										array4 = new int[4];
										while (true)
										{
											IL_12a3:
											array5 = new int[7];
											while (true)
											{
												IL_1293:
												array6 = new long[4];
												while (true)
												{
													IL_1283:
													array7 = new object[13];
													while (true)
													{
														IL_1278:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ToLongDateStringsetLastAccessTime.ContainedInManifestFileConsoleModifiers);
														while (true)
														{
															IL_126e:
															ptr2 = ptr;
															while (true)
															{
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_0567:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0557:
																			ptr2++;
																			while (true)
																			{
																				IL_0547:
																				if (b >= 1)
																				{
																					while (b <= 29)
																					{
																						while (true)
																						{
																							IL_052a:
																							if (15 < b)
																							{
																								while (true)
																								{
																									IL_051a:
																									if (22 >= b)
																									{
																										num = 80;
																										while (true)
																										{
																											IL_050a:
																											if (22 > b)
																											{
																												while (true)
																												{
																													IL_04fa:
																													if (18 < b)
																													{
																														while (true)
																														{
																															IL_04ea:
																															if (20 < b)
																															{
																																while (21 >= b)
																																{
																																	while (21 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_04ac:
																																			ptr2 = ptr + *(int*)(ptr2 + num3);
																																			num = 287;
																																			while (num != 287)
																																			{
																																				if (num != 1268)
																																				{
																																					goto end_IL_04ca;
																																				}
																																				switch (num)
																																				{
																																				case 173:
																																					break;
																																				default:
																																					continue;
																																				case 89:
																																				case 176:
																																					goto IL_04ac;
																																				case 190:
																																					goto IL_04ca;
																																				case 10:
																																				case 21:
																																					goto IL_04da;
																																				case 187:
																																					goto IL_04ea;
																																				case 2:
																																					goto IL_04fa;
																																				case 80:
																																					goto IL_050a;
																																				case 197:
																																				case 228:
																																					goto IL_051a;
																																				case 149:
																																					goto IL_052a;
																																				case 198:
																																					goto IL_0537;
																																				case 47:
																																					goto IL_0547;
																																				case 50:
																																					goto IL_0557;
																																				case 75:
																																				case 166:
																																					goto IL_0567;
																																				case 34:
																																					goto IL_0572;
																																				case 77:
																																					goto IL_058b;
																																				case 97:
																																					goto IL_059b;
																																				case 101:
																																					goto IL_05ab;
																																				case 0:
																																				case 28:
																																					goto IL_05b9;
																																				case 131:
																																					goto IL_05cc;
																																				case 52:
																																				case 108:
																																					goto IL_05da;
																																				case 137:
																																					goto IL_05ea;
																																				case 168:
																																					goto IL_05fd;
																																				case 126:
																																					goto IL_060b;
																																				case 27:
																																				case 116:
																																					goto IL_0616;
																																				case 51:
																																				case 85:
																																					goto IL_0626;
																																				case 144:
																																					goto IL_0666;
																																				case 68:
																																					goto IL_067a;
																																				case 188:
																																					goto IL_068d;
																																				case 24:
																																				case 189:
																																					goto IL_06a0;
																																				case 48:
																																				case 195:
																																					goto IL_06ce;
																																				case 146:
																																				case 205:
																																					goto IL_0714;
																																				case 109:
																																					goto IL_071f;
																																				case 155:
																																				case 174:
																																					goto IL_072d;
																																				case 67:
																																					goto IL_0745;
																																				case 121:
																																					goto IL_075c;
																																				case 206:
																																					goto IL_076f;
																																				case 135:
																																				case 153:
																																					goto IL_077d;
																																				case 177:
																																					goto IL_078b;
																																				case 96:
																																				case 207:
																																					goto IL_0799;
																																				case 159:
																																					goto IL_07b2;
																																				case 158:
																																					goto IL_07c0;
																																				case 171:
																																					goto IL_07ce;
																																				case 212:
																																					goto IL_07e1;
																																				case 19:
																																				case 186:
																																					goto IL_07ec;
																																				case 145:
																																					goto IL_07fa;
																																				case 201:
																																					goto IL_080d;
																																				case 15:
																																					goto IL_0818;
																																				case 20:
																																					goto IL_0826;
																																				case 154:
																																				case 196:
																																					goto IL_0839;
																																				case 60:
																																				case 216:
																																					goto IL_0855;
																																				case 164:
																																				case 229:
																																					goto IL_0868;
																																				case 221:
																																					goto IL_0891;
																																				case 87:
																																					goto IL_089f;
																																				case 165:
																																				case 231:
																																					goto IL_08b2;
																																				case 209:
																																				case 233:
																																					goto IL_0900;
																																				case 202:
																																					goto IL_090e;
																																				case 150:
																																				case 225:
																																					goto IL_091c;
																																				case 55:
																																				case 234:
																																					goto IL_0935;
																																				case 30:
																																					goto IL_0949;
																																				case 26:
																																					goto IL_09b3;
																																				case 193:
																																					goto IL_09c1;
																																				case 239:
																																					goto IL_09d4;
																																				case 122:
																																				case 246:
																																					goto IL_09f0;
																																				case 133:
																																					goto IL_09fa;
																																				case 41:
																																					goto IL_0a08;
																																				case 249:
																																					goto IL_0a24;
																																				case 208:
																																					goto IL_0a32;
																																				case 46:
																																				case 49:
																																					goto IL_0a3d;
																																				case 194:
																																					goto IL_0a4b;
																																				case 63:
																																				case 69:
																																					goto IL_0a5e;
																																				case 32:
																																					goto IL_0b15;
																																				case 23:
																																					goto IL_0b23;
																																				case 132:
																																				case 250:
																																					goto IL_0b36;
																																				case 5:
																																					goto IL_0b44;
																																				case 252:
																																					goto IL_0b6c;
																																				case 141:
																																					goto IL_0b7a;
																																				case 54:
																																				case 138:
																																					goto IL_0b88;
																																				case 82:
																																					goto IL_0ba6;
																																				case 253:
																																					goto IL_0bb9;
																																				case 56:
																																					goto IL_0bcd;
																																				case 214:
																																				case 254:
																																					goto IL_0be0;
																																				case 226:
																																					goto IL_0bee;
																																				case 83:
																																				case 161:
																																					goto IL_0bf9;
																																				case 143:
																																					goto IL_0c07;
																																				case 90:
																																				case 112:
																																					goto IL_0c15;
																																				case 95:
																																				case 136:
																																					goto IL_0c28;
																																				case 123:
																																					goto IL_0c68;
																																				case 128:
																																					goto IL_0c85;
																																				case 102:
																																				case 180:
																																					goto IL_0caa;
																																				case 178:
																																				case 255:
																																					goto IL_0cbd;
																																				case 36:
																																					goto IL_0cfb;
																																				case 256:
																																					goto IL_0d0e;
																																				case 257:
																																					goto IL_0d21;
																																				case 261:
																																					goto IL_0d3a;
																																				case 84:
																																				case 140:
																																					goto IL_0d48;
																																				case 219:
																																					goto IL_0d56;
																																				case 181:
																																					goto IL_0d6e;
																																				case 243:
																																					goto IL_0d85;
																																				case 263:
																																					goto IL_0d98;
																																				case 42:
																																					goto IL_0dd7;
																																				case 264:
																																					goto IL_0dea;
																																				case 17:
																																					goto IL_0e07;
																																				case 266:
																																					goto IL_0e1a;
																																				case 269:
																																					goto IL_0e2d;
																																				case 45:
																																				case 162:
																																					goto IL_0e3b;
																																				case 167:
																																					goto IL_0e9d;
																																				case 270:
																																					goto IL_0eb0;
																																				case 267:
																																					goto IL_0eba;
																																				case 11:
																																					goto IL_0ec8;
																																				case 271:
																																					goto IL_0edb;
																																				case 103:
																																				case 215:
																																					goto IL_0ee9;
																																				case 125:
																																					goto IL_0f29;
																																				case 258:
																																					goto IL_0f3d;
																																				case 65:
																																				case 273:
																																					goto IL_0f50;
																																				case 62:
																																					goto IL_0f68;
																																				case 247:
																																					goto IL_0f86;
																																				case 217:
																																					goto IL_0faa;
																																				case 99:
																																					goto IL_0fc2;
																																				case 276:
																																					goto IL_0fd5;
																																				case 40:
																																					goto IL_0fe3;
																																				case 179:
																																				case 277:
																																					goto IL_0ff6;
																																				case 142:
																																					goto IL_1004;
																																				case 33:
																																				case 134:
																																					goto IL_1012;
																																				case 59:
																																					goto IL_1052;
																																				case 114:
																																					goto IL_1066;
																																				case 160:
																																				case 278:
																																					goto IL_1082;
																																				case 227:
																																					goto IL_1096;
																																				case 74:
																																					goto IL_10d7;
																																				case 118:
																																				case 280:
																																					goto IL_10ea;
																																				case 185:
																																					goto IL_10f8;
																																				case 120:
																																				case 220:
																																					goto IL_1106;
																																				case 200:
																																					goto IL_1158;
																																				case 272:
																																					goto IL_116b;
																																				case 71:
																																				case 251:
																																					goto IL_1179;
																																				case 129:
																																					goto IL_1187;
																																				case 16:
																																				case 222:
																																					goto IL_1195;
																																				case 64:
																																					goto IL_11a9;
																																				case 262:
																																					goto IL_11e1;
																																				case 4:
																																				case 260:
																																					goto IL_11fa;
																																				case 58:
																																					goto IL_121c;
																																				case 152:
																																					goto IL_122a;
																																				case 14:
																																					goto IL_1238;
																																				case 1:
																																				case 3:
																																				case 8:
																																				case 12:
																																				case 18:
																																				case 25:
																																				case 37:
																																				case 38:
																																				case 39:
																																				case 44:
																																				case 53:
																																				case 57:
																																				case 70:
																																				case 72:
																																				case 78:
																																				case 86:
																																				case 88:
																																				case 93:
																																				case 100:
																																				case 104:
																																				case 115:
																																				case 117:
																																				case 119:
																																				case 130:
																																				case 139:
																																				case 151:
																																				case 163:
																																				case 170:
																																				case 175:
																																				case 182:
																																				case 183:
																																				case 191:
																																				case 192:
																																				case 199:
																																				case 203:
																																				case 204:
																																				case 210:
																																				case 218:
																																				case 230:
																																				case 238:
																																				case 240:
																																				case 242:
																																				case 244:
																																				case 245:
																																				case 248:
																																				case 259:
																																				case 268:
																																				case 274:
																																				case 275:
																																				case 279:
																																					goto end_IL_04ca;
																																				case 6:
																																				case 7:
																																				case 9:
																																				case 13:
																																				case 22:
																																				case 29:
																																				case 31:
																																				case 35:
																																				case 43:
																																				case 66:
																																				case 73:
																																				case 76:
																																				case 79:
																																				case 81:
																																				case 91:
																																				case 94:
																																				case 98:
																																				case 105:
																																				case 107:
																																				case 113:
																																				case 127:
																																				case 147:
																																				case 148:
																																				case 157:
																																				case 169:
																																				case 213:
																																				case 223:
																																				case 236:
																																				case 237:
																																				case 241:
																																				case 265:
																																					goto end_IL_0499;
																																				case 61:
																																					goto IL_126e;
																																				case 156:
																																					goto IL_1278;
																																				case 211:
																																					goto IL_1283;
																																				case 92:
																																					goto IL_1293;
																																				case 235:
																																					goto IL_12a3;
																																				case 110:
																																					goto IL_12b3;
																																				case 111:
																																					goto IL_12c3;
																																				case 232:
																																					goto IL_12d3;
																																				case 106:
																																					goto IL_12e3;
																																				case 184:
																																					goto IL_12f3;
																																				case 172:
																																					goto IL_1303;
																																				case 124:
																																				case 224:
																																					goto IL_131e;
																																				}
																																				goto end_IL_125b;
																																				continue;
																																				end_IL_0499:
																																				break;
																																			}
																																			break;
																																		}
																																		goto end_IL_0547;
																																		continue;
																																		end_IL_04ca:
																																		break;
																																		IL_04ca:;
																																	}
																																	break;
																																	IL_04da:;
																																}
																																break;
																															}
																															goto IL_116b;
																															IL_1238:
																															ptr2 += 16;
																															goto end_IL_0547;
																															IL_116b:
																															if (20 > b)
																															{
																																goto IL_1179;
																															}
																															goto IL_11fa;
																															IL_1179:
																															if (19 < b)
																															{
																																break;
																															}
																															goto IL_1187;
																															IL_1187:
																															if (19 > b)
																															{
																																break;
																															}
																															goto IL_1195;
																															IL_1195:
																															array2[num6 - 1] = 5;
																															goto IL_11a9;
																															IL_11a9:
																															array3[num6 - 1] = ((delegate*<string[], string>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																															goto IL_11e1;
																															IL_11e1:
																															ptr2 += 8;
																															num = 265;
																															goto end_IL_0547;
																															IL_11fa:
																															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																															num = 58;
																															goto IL_121c;
																															IL_121c:
																															array2[num6] = 1;
																															goto IL_122a;
																															IL_122a:
																															num6++;
																															goto IL_1238;
																														}
																														break;
																													}
																													goto IL_05ab;
																													IL_0cbd:
																													((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																													goto IL_0cfb;
																													IL_05ab:
																													if (18 > b)
																													{
																														goto IL_05b9;
																													}
																													goto IL_0cbd;
																													IL_05b9:
																													if (16 < b)
																													{
																														goto IL_09d4;
																													}
																													goto IL_0d0e;
																													IL_0d0e:
																													if (16 > b)
																													{
																														break;
																													}
																													goto IL_0f50;
																													IL_0f50:
																													array2[num6] = array2[num6 - 1];
																													goto IL_0f68;
																													IL_0f68:
																													array4[num6 - 0] = array4[num6 - 1];
																													goto IL_0f86;
																													IL_0f86:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0faa;
																													IL_0faa:
																													array3[num6] = array3[num6 - 1];
																													goto IL_0fc2;
																													IL_0fc2:
																													num6++;
																													goto end_IL_0547;
																													IL_09d4:
																													if (17 < b)
																													{
																														num = 115;
																														break;
																													}
																													goto IL_0d3a;
																													IL_0cfb:
																													num6 -= 3;
																													goto end_IL_0547;
																													IL_0d3a:
																													if (17 > b)
																													{
																														break;
																													}
																													goto IL_0d48;
																													IL_0d48:
																													array2[num6] = 5;
																													goto IL_0d56;
																													IL_0d56:
																													array3[num6] = array7[*(int*)(ptr2 + num3)];
																													goto IL_0d6e;
																													IL_0d6e:
																													num6++;
																													num = 243;
																													goto IL_0d85;
																													IL_0d85:
																													ptr2 += 8;
																													goto end_IL_0547;
																												}
																												break;
																											}
																											goto IL_06ce;
																											IL_0e07:
																											num6--;
																											goto end_IL_0547;
																											IL_06ce:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																											goto IL_0dea;
																											IL_0dea:
																											array2[num6 - 2] = 0;
																											num = 17;
																											goto IL_0e07;
																										}
																										break;
																									}
																									goto IL_058b;
																									IL_09b3:
																									num6 -= 3;
																									goto IL_09c1;
																									IL_09c1:
																									ptr2 += 8;
																									goto end_IL_0547;
																									IL_058b:
																									if (26 >= b)
																									{
																										goto IL_05ea;
																									}
																									goto IL_07e1;
																									IL_05ea:
																									if (26 > b)
																									{
																										goto IL_0714;
																									}
																									goto IL_09f0;
																									IL_0714:
																									if (24 >= b)
																									{
																										goto IL_071f;
																									}
																									goto IL_0745;
																									IL_071f:
																									if (24 <= b)
																									{
																										goto IL_072d;
																									}
																									goto IL_10ea;
																									IL_072d:
																									array3[num6] = typeof(global::GorillaWrappedSerializer).TypeHandle;
																									goto IL_0fd5;
																									IL_0fd5:
																									array2[num6] = 4;
																									goto IL_0fe3;
																									IL_0fe3:
																									num6++;
																									goto end_IL_0547;
																									IL_10ea:
																									if (23 < b)
																									{
																										break;
																									}
																									goto IL_10f8;
																									IL_10f8:
																									if (23 > b)
																									{
																										break;
																									}
																									goto IL_1106;
																									IL_1106:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_1158;
																									IL_1158:
																									num6--;
																									goto end_IL_0547;
																									IL_0745:
																									if (25 < b)
																									{
																										break;
																									}
																									num = 121;
																									goto IL_075c;
																									IL_0839:
																									num7 = ptr2;
																									num8 = -200;
																									num5 = 1;
																									ptr2 = num7 + num8;
																									goto end_IL_0547;
																									IL_075c:
																									if (25 > b)
																									{
																										break;
																									}
																									goto IL_1082;
																									IL_1082:
																									array2[num6 - 1] = 5;
																									goto IL_1096;
																									IL_1096:
																									array3[num6 - 1] = ((delegate*<RuntimeTypeHandle, Type>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])((RuntimeTypeHandle)array3[num6 - 1]);
																									num = 74;
																									goto IL_10d7;
																									IL_10d7:
																									ptr2 += 8;
																									goto end_IL_0547;
																									IL_09f0:
																									array3[num6] = null;
																									goto IL_09fa;
																									IL_09fa:
																									array2[num6] = 5;
																									goto IL_0a08;
																									IL_0a08:
																									num6++;
																									num = 43;
																									goto end_IL_0547;
																									IL_07e1:
																									if (28 < b)
																									{
																										goto IL_07ec;
																									}
																									goto IL_080d;
																									IL_07ec:
																									if (29 < b)
																									{
																										break;
																									}
																									goto IL_07fa;
																									IL_07fa:
																									if (29 <= b)
																									{
																									}
																									break;
																									IL_080d:
																									if (28 > b)
																									{
																										goto IL_0818;
																									}
																									goto IL_0839;
																									IL_0818:
																									if (27 < b)
																									{
																										break;
																									}
																									goto IL_0826;
																									IL_0826:
																									if (27 > b)
																									{
																										break;
																									}
																									goto IL_0935;
																									IL_0935:
																									array2[num6 - 4] = 5;
																									goto IL_0949;
																									IL_0949:
																									array3[num6 - 4] = ((delegate*<Type, string, Type[], Type[], MethodInfo>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])((Type)array3[num6 - 4], (string)array3[num6 - 3], (Type[])array3[num6 - 2], (Type[])array3[num6 - 1]);
																									goto IL_09b3;
																								}
																								break;
																							}
																							goto IL_0572;
																							IL_0ee9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0f29;
																							IL_0572:
																							if (15 > b)
																							{
																								goto IL_059b;
																							}
																							num = 24;
																							goto IL_06a0;
																							IL_0f29:
																							array2[num6 - 2] = 0;
																							goto IL_0f3d;
																							IL_06a0:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_0d21;
																							IL_0d21:
																							array2[num6 - 1] = 5;
																							goto end_IL_0547;
																							IL_059b:
																							if (7 >= b)
																							{
																								goto IL_05cc;
																							}
																							goto IL_0900;
																							IL_0900:
																							if (11 >= b)
																							{
																								goto IL_090e;
																							}
																							goto IL_0a24;
																							IL_090e:
																							if (11 <= b)
																							{
																								goto IL_091c;
																							}
																							goto IL_0be0;
																							IL_091c:
																							array2[num6 - 1] = 0;
																							goto IL_0d98;
																							IL_0d98:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0dd7;
																							IL_0dd7:
																							ptr2 += 8;
																							goto end_IL_0547;
																							IL_0be0:
																							if (9 >= b)
																							{
																								goto IL_0bee;
																							}
																							num = 102;
																							goto IL_0caa;
																							IL_0bee:
																							if (9 > b)
																							{
																								goto IL_0bf9;
																							}
																							goto IL_0c28;
																							IL_0bf9:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_0c07;
																							IL_0c07:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0c15;
																							IL_0c15:
																							num6--;
																							goto end_IL_0547;
																							IL_0c28:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0c68;
																							IL_0c68:
																							array2[num6 - 2] = 0;
																							num = 128;
																							goto IL_0c85;
																							IL_0c85:
																							num6--;
																							num = 91;
																							goto end_IL_0547;
																							IL_0f3d:
																							num6--;
																							goto end_IL_0547;
																							IL_0caa:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0e2d;
																							IL_0e2d:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0e3b;
																							IL_0e3b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0e9d;
																							IL_0e9d:
																							num6 -= 2;
																							goto end_IL_0547;
																							IL_0a24:
																							if (13 >= b)
																							{
																								goto IL_0a32;
																							}
																							goto IL_0b6c;
																							IL_0a32:
																							if (13 > b)
																							{
																								goto IL_0a3d;
																							}
																							goto IL_0a5e;
																							IL_0a3d:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_0a4b;
																							IL_0a4b:
																							if (12 <= b)
																							{
																								goto end_IL_0547;
																							}
																							break;
																							IL_0a5e:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_0a6d;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_0b15;
																							IL_08b2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 253;
																							goto IL_0bb9;
																							IL_0bb9:
																							array2[num6 - 2] = 0;
																							goto IL_0bcd;
																							IL_0bcd:
																							num6--;
																							goto end_IL_0547;
																							IL_0b15:
																							array2[num6] = 5;
																							goto IL_0b23;
																							IL_0b23:
																							num6++;
																							goto end_IL_0547;
																							IL_0b6c:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_0b7a;
																							IL_0b7a:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_0b88;
																							IL_0b88:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_0ba6;
																							IL_0ba6:
																							ptr2 += 8;
																							goto IL_0e1a;
																							IL_0e1a:
																							num6--;
																							goto end_IL_0547;
																							IL_05cc:
																							if (7 > b)
																							{
																								goto IL_05da;
																							}
																							goto IL_08b2;
																							IL_05da:
																							if (3 < b)
																							{
																								goto IL_05fd;
																							}
																							goto IL_076f;
																							IL_076f:
																							if (3 > b)
																							{
																								goto IL_077d;
																							}
																							goto IL_0868;
																							IL_077d:
																							if (1 >= b)
																							{
																								goto IL_078b;
																							}
																							goto IL_0ff6;
																							IL_078b:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0799;
																							IL_0799:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_07b2;
																							IL_07b2:
																							array2[num6] = 0;
																							goto IL_07c0;
																							IL_07c0:
																							num6++;
																							goto IL_07ce;
																							IL_07ce:
																							ptr2 += 8;
																							goto end_IL_0547;
																							IL_0ff6:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_1004;
																							IL_1004:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_1012;
																							IL_1012:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1052;
																							IL_1052:
																							array2[num6 - 2] = 0;
																							goto IL_1066;
																							IL_1066:
																							num6--;
																							num = 7;
																							goto end_IL_0547;
																							IL_0868:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0891;
																							IL_0891:
																							ptr2 += 8;
																							goto IL_089f;
																							IL_089f:
																							num6--;
																							goto end_IL_0547;
																							IL_05fd:
																							if (5 >= b)
																							{
																								goto IL_060b;
																							}
																							goto IL_0855;
																							IL_060b:
																							if (5 > b)
																							{
																								goto IL_0616;
																							}
																							goto IL_0626;
																							IL_0616:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_068d;
																							IL_068d:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0b36;
																							IL_0b36:
																							array2[num6] = 0;
																							goto IL_0b44;
																							IL_0b44:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0eb0;
																							IL_0eb0:
																							array3[num6] = null;
																							goto IL_0eba;
																							IL_0eba:
																							num6++;
																							goto IL_0ec8;
																							IL_0ec8:
																							ptr2 += 8;
																							goto end_IL_0547;
																							IL_0626:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0666;
																							IL_0666:
																							array2[num6 - 2] = 0;
																							goto IL_067a;
																							IL_067a:
																							num6--;
																							goto end_IL_0547;
																							IL_0855:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0edb;
																							IL_0edb:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_0ee9;
																						}
																						break;
																						IL_0537:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				continue;
																				end_IL_0547:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																}
																goto IL_131e;
																IL_131e:
																return (MethodBase)array3[num6 - 1];
																continue;
																end_IL_125b:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0a6d:
			while (true)
			{
				IL_0a6d_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0b15_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0b23_2:
							num6++;
							while (true)
							{
								if (num5 != 1)
								{
									while (true)
									{
										IL_0567_2:
										byte b = *ptr2;
										while (true)
										{
											IL_0557_2:
											ptr2++;
											while (true)
											{
												IL_0547_2:
												if (b >= 1)
												{
													while (b <= 29)
													{
														while (true)
														{
															IL_052a_2:
															if (15 < b)
															{
																while (true)
																{
																	IL_051a_2:
																	if (22 >= b)
																	{
																		num = 80;
																		while (true)
																		{
																			IL_050a_2:
																			if (22 > b)
																			{
																				while (true)
																				{
																					IL_04fa_2:
																					if (18 < b)
																					{
																						while (true)
																						{
																							IL_04ea_2:
																							if (20 < b)
																							{
																								while (21 >= b)
																								{
																									while (21 <= b)
																									{
																										while (true)
																										{
																											IL_04ac_2:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											num = 287;
																											while (num != 287)
																											{
																												if (num != 1268)
																												{
																													goto end_IL_04ca_2;
																												}
																												switch (num)
																												{
																												case 89:
																												case 176:
																													goto IL_04ac_2;
																												case 190:
																													goto IL_04ca_2;
																												case 10:
																												case 21:
																													goto IL_04da_2;
																												case 187:
																													goto IL_04ea_2;
																												case 2:
																													goto IL_04fa_2;
																												case 80:
																													goto IL_050a_2;
																												case 197:
																												case 228:
																													goto IL_051a_2;
																												case 149:
																													goto IL_052a_2;
																												case 198:
																													goto IL_0537_2;
																												case 47:
																													goto IL_0547_2;
																												case 50:
																													goto IL_0557_2;
																												case 75:
																												case 166:
																													goto IL_0567_2;
																												case 34:
																													goto IL_0572_2;
																												case 77:
																													goto IL_058b_2;
																												case 97:
																													goto IL_059b_2;
																												case 101:
																													goto IL_05ab_2;
																												case 0:
																												case 28:
																													goto IL_05b9_2;
																												case 131:
																													goto IL_05cc_2;
																												case 52:
																												case 108:
																													goto IL_05da_2;
																												case 137:
																													goto IL_05ea_2;
																												case 168:
																													goto IL_05fd_2;
																												case 126:
																													goto IL_060b_2;
																												case 27:
																												case 116:
																													goto IL_0616_2;
																												case 51:
																												case 85:
																													goto IL_0626_2;
																												case 144:
																													goto IL_0666_2;
																												case 68:
																													goto IL_067a_2;
																												case 188:
																													goto IL_068d_2;
																												case 24:
																												case 189:
																													goto IL_06a0_2;
																												case 48:
																												case 195:
																													goto IL_06ce_2;
																												case 146:
																												case 205:
																													goto IL_0714_2;
																												case 109:
																													goto IL_071f_2;
																												case 155:
																												case 174:
																													goto IL_072d_2;
																												case 67:
																													goto IL_0745_2;
																												case 121:
																													goto IL_075c_2;
																												case 206:
																													goto IL_076f_2;
																												case 135:
																												case 153:
																													goto IL_077d_2;
																												case 177:
																													goto IL_078b_2;
																												case 96:
																												case 207:
																													goto IL_0799_2;
																												case 159:
																													goto IL_07b2_2;
																												case 158:
																													goto IL_07c0_2;
																												case 171:
																													goto IL_07ce_2;
																												case 212:
																													goto IL_07e1_2;
																												case 19:
																												case 186:
																													goto IL_07ec_2;
																												case 145:
																													goto IL_07fa_2;
																												case 201:
																													goto IL_080d_2;
																												case 15:
																													goto IL_0818_2;
																												case 20:
																													goto IL_0826_2;
																												case 154:
																												case 196:
																													goto IL_0839_2;
																												case 60:
																												case 216:
																													goto IL_0855_2;
																												case 164:
																												case 229:
																													goto IL_0868_2;
																												case 221:
																													goto IL_0891_2;
																												case 87:
																													goto IL_089f_2;
																												case 165:
																												case 231:
																													goto IL_08b2_2;
																												case 209:
																												case 233:
																													goto IL_0900_2;
																												case 202:
																													goto IL_090e_2;
																												case 150:
																												case 225:
																													goto IL_091c_2;
																												case 55:
																												case 234:
																													goto IL_0935_2;
																												case 30:
																													goto IL_0949_2;
																												case 26:
																													goto IL_09b3_2;
																												case 193:
																													goto IL_09c1_2;
																												case 239:
																													goto IL_09d4_2;
																												case 122:
																												case 246:
																													goto IL_09f0_2;
																												case 133:
																													goto IL_09fa_2;
																												case 41:
																													goto IL_0a08_2;
																												case 249:
																													goto IL_0a24_2;
																												case 208:
																													goto IL_0a32_2;
																												case 46:
																												case 49:
																													goto IL_0a3d_2;
																												case 194:
																													goto IL_0a4b_2;
																												case 63:
																												case 69:
																													goto end_IL_125b_2;
																												case 32:
																													goto IL_0b15_2;
																												case 23:
																													goto IL_0b23_2;
																												case 132:
																												case 250:
																													goto IL_0b36_2;
																												case 5:
																													goto IL_0b44_2;
																												case 252:
																													goto IL_0b6c_2;
																												case 141:
																													goto IL_0b7a_2;
																												case 54:
																												case 138:
																													goto IL_0b88_2;
																												case 82:
																													goto IL_0ba6_2;
																												case 253:
																													goto IL_0bb9_2;
																												case 56:
																													goto IL_0bcd_2;
																												case 214:
																												case 254:
																													goto IL_0be0_2;
																												case 226:
																													goto IL_0bee_2;
																												case 83:
																												case 161:
																													goto IL_0bf9_2;
																												case 143:
																													goto IL_0c07_2;
																												case 90:
																												case 112:
																													goto IL_0c15_2;
																												case 95:
																												case 136:
																													goto IL_0c28_2;
																												case 123:
																													goto IL_0c68_2;
																												case 128:
																													goto IL_0c85_2;
																												case 102:
																												case 180:
																													goto IL_0caa_2;
																												case 178:
																												case 255:
																													goto IL_0cbd_2;
																												case 36:
																													goto IL_0cfb_2;
																												case 256:
																													goto IL_0d0e_2;
																												case 257:
																													goto IL_0d21_2;
																												case 261:
																													goto IL_0d3a_2;
																												case 84:
																												case 140:
																													goto IL_0d48_2;
																												case 219:
																													goto IL_0d56_2;
																												case 181:
																													goto IL_0d6e_2;
																												case 243:
																													goto IL_0d85_2;
																												case 263:
																													goto IL_0d98_2;
																												case 42:
																													goto IL_0dd7_2;
																												case 264:
																													goto IL_0dea_2;
																												case 17:
																													goto IL_0e07_2;
																												case 266:
																													goto IL_0e1a_2;
																												case 269:
																													goto IL_0e2d_2;
																												case 45:
																												case 162:
																													goto IL_0e3b_2;
																												case 167:
																													goto IL_0e9d_2;
																												case 270:
																													goto IL_0eb0_2;
																												case 267:
																													goto IL_0eba_2;
																												case 11:
																													goto IL_0ec8_2;
																												case 271:
																													goto IL_0edb_2;
																												case 103:
																												case 215:
																													goto IL_0ee9_2;
																												case 125:
																													goto IL_0f29_2;
																												case 258:
																													goto IL_0f3d_2;
																												case 65:
																												case 273:
																													goto IL_0f50_2;
																												case 62:
																													goto IL_0f68_2;
																												case 247:
																													goto IL_0f86_2;
																												case 217:
																													goto IL_0faa_2;
																												case 99:
																													goto IL_0fc2_2;
																												case 276:
																													goto IL_0fd5_2;
																												case 40:
																													goto IL_0fe3_2;
																												case 179:
																												case 277:
																													goto IL_0ff6_2;
																												case 142:
																													goto IL_1004_2;
																												case 33:
																												case 134:
																													goto IL_1012_2;
																												case 59:
																													goto IL_1052_2;
																												case 114:
																													goto IL_1066_2;
																												case 160:
																												case 278:
																													goto IL_1082_2;
																												case 227:
																													goto IL_1096_2;
																												case 74:
																													goto IL_10d7_2;
																												case 118:
																												case 280:
																													goto IL_10ea_2;
																												case 185:
																													goto IL_10f8_2;
																												case 120:
																												case 220:
																													goto IL_1106_2;
																												case 200:
																													goto IL_1158_2;
																												case 272:
																													goto IL_116b_2;
																												case 71:
																												case 251:
																													goto IL_1179_2;
																												case 129:
																													goto IL_1187_2;
																												case 16:
																												case 222:
																													goto IL_1195_2;
																												case 64:
																													goto IL_11a9_2;
																												case 262:
																													goto IL_11e1_2;
																												case 4:
																												case 260:
																													goto IL_11fa_2;
																												case 58:
																													goto IL_121c_2;
																												case 152:
																													goto IL_122a_2;
																												case 14:
																													goto IL_1238_2;
																												case 1:
																												case 3:
																												case 8:
																												case 12:
																												case 18:
																												case 25:
																												case 37:
																												case 38:
																												case 39:
																												case 44:
																												case 53:
																												case 57:
																												case 70:
																												case 72:
																												case 78:
																												case 86:
																												case 88:
																												case 93:
																												case 100:
																												case 104:
																												case 115:
																												case 117:
																												case 119:
																												case 130:
																												case 139:
																												case 151:
																												case 163:
																												case 170:
																												case 175:
																												case 182:
																												case 183:
																												case 191:
																												case 192:
																												case 199:
																												case 203:
																												case 204:
																												case 210:
																												case 218:
																												case 230:
																												case 238:
																												case 240:
																												case 242:
																												case 244:
																												case 245:
																												case 248:
																												case 259:
																												case 268:
																												case 274:
																												case 275:
																												case 279:
																													goto end_IL_04ca_2;
																												case 6:
																												case 7:
																												case 9:
																												case 13:
																												case 22:
																												case 29:
																												case 31:
																												case 35:
																												case 43:
																												case 66:
																												case 73:
																												case 76:
																												case 79:
																												case 81:
																												case 91:
																												case 94:
																												case 98:
																												case 105:
																												case 107:
																												case 113:
																												case 127:
																												case 147:
																												case 148:
																												case 157:
																												case 169:
																												case 213:
																												case 223:
																												case 236:
																												case 237:
																												case 241:
																												case 265:
																													goto end_IL_0499_2;
																												case 61:
																													ptr2 = ptr;
																													goto end_IL_0499_2;
																												case 156:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ToLongDateStringsetLastAccessTime.ContainedInManifestFileConsoleModifiers);
																													goto case 61;
																												case 211:
																													array7 = new object[13];
																													goto case 156;
																												case 92:
																													array6 = new long[4];
																													goto case 211;
																												case 235:
																													array5 = new int[7];
																													goto case 92;
																												case 110:
																													array4 = new int[4];
																													goto case 235;
																												case 111:
																													array3 = new object[4];
																													goto case 110;
																												case 232:
																													array2 = new byte[4];
																													goto case 111;
																												case 106:
																													num4 = num2 * 8;
																													goto case 232;
																												case 184:
																													num3 = num2 * 4;
																													goto case 106;
																												case 172:
																													num2 = 1;
																													goto case 184;
																												case 173:
																													goto end_IL_0a7b;
																												case 124:
																												case 224:
																													goto IL_131e_2;
																												}
																												continue;
																												end_IL_0499_2:
																												break;
																											}
																											break;
																										}
																										goto end_IL_0547_2;
																										continue;
																										end_IL_04ca_2:
																										break;
																										IL_04ca_2:;
																									}
																									break;
																									IL_04da_2:;
																								}
																								break;
																							}
																							goto IL_116b_2;
																							IL_1238_2:
																							ptr2 += 16;
																							goto end_IL_0547_2;
																							IL_116b_2:
																							if (20 > b)
																							{
																								goto IL_1179_2;
																							}
																							goto IL_11fa_2;
																							IL_1179_2:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_1187_2;
																							IL_1187_2:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_1195_2;
																							IL_1195_2:
																							array2[num6 - 1] = 5;
																							goto IL_11a9_2;
																							IL_11a9_2:
																							array3[num6 - 1] = ((delegate*<string[], string>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_11e1_2;
																							IL_11e1_2:
																							ptr2 += 8;
																							num = 265;
																							goto end_IL_0547_2;
																							IL_11fa_2:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							num = 58;
																							goto IL_121c_2;
																							IL_121c_2:
																							array2[num6] = 1;
																							goto IL_122a_2;
																							IL_122a_2:
																							num6++;
																							goto IL_1238_2;
																						}
																						break;
																					}
																					goto IL_05ab_2;
																					IL_0cbd_2:
																					((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																					goto IL_0cfb_2;
																					IL_05ab_2:
																					if (18 > b)
																					{
																						goto IL_05b9_2;
																					}
																					goto IL_0cbd_2;
																					IL_05b9_2:
																					if (16 < b)
																					{
																						goto IL_09d4_2;
																					}
																					goto IL_0d0e_2;
																					IL_0d0e_2:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_0f50_2;
																					IL_0f50_2:
																					array2[num6] = array2[num6 - 1];
																					goto IL_0f68_2;
																					IL_0f68_2:
																					array4[num6 - 0] = array4[num6 - 1];
																					goto IL_0f86_2;
																					IL_0f86_2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0faa_2;
																					IL_0faa_2:
																					array3[num6] = array3[num6 - 1];
																					goto IL_0fc2_2;
																					IL_0fc2_2:
																					num6++;
																					goto end_IL_0547_2;
																					IL_09d4_2:
																					if (17 < b)
																					{
																						num = 115;
																						break;
																					}
																					goto IL_0d3a_2;
																					IL_0cfb_2:
																					num6 -= 3;
																					goto end_IL_0547_2;
																					IL_0d3a_2:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_0d48_2;
																					IL_0d48_2:
																					array2[num6] = 5;
																					goto IL_0d56_2;
																					IL_0d56_2:
																					array3[num6] = array7[*(int*)(ptr2 + num3)];
																					goto IL_0d6e_2;
																					IL_0d6e_2:
																					num6++;
																					num = 243;
																					goto IL_0d85_2;
																					IL_0d85_2:
																					ptr2 += 8;
																					goto end_IL_0547_2;
																				}
																				break;
																			}
																			goto IL_06ce_2;
																			IL_0e07_2:
																			num6--;
																			goto end_IL_0547_2;
																			IL_06ce_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																			goto IL_0dea_2;
																			IL_0dea_2:
																			array2[num6 - 2] = 0;
																			num = 17;
																			goto IL_0e07_2;
																		}
																		break;
																	}
																	goto IL_058b_2;
																	IL_09b3_2:
																	num6 -= 3;
																	goto IL_09c1_2;
																	IL_09c1_2:
																	ptr2 += 8;
																	goto end_IL_0547_2;
																	IL_058b_2:
																	if (26 >= b)
																	{
																		goto IL_05ea_2;
																	}
																	goto IL_07e1_2;
																	IL_05ea_2:
																	if (26 > b)
																	{
																		goto IL_0714_2;
																	}
																	goto IL_09f0_2;
																	IL_0714_2:
																	if (24 >= b)
																	{
																		goto IL_071f_2;
																	}
																	goto IL_0745_2;
																	IL_071f_2:
																	if (24 <= b)
																	{
																		goto IL_072d_2;
																	}
																	goto IL_10ea_2;
																	IL_072d_2:
																	array3[num6] = typeof(global::GorillaWrappedSerializer).TypeHandle;
																	goto IL_0fd5_2;
																	IL_0fd5_2:
																	array2[num6] = 4;
																	goto IL_0fe3_2;
																	IL_0fe3_2:
																	num6++;
																	goto end_IL_0547_2;
																	IL_10ea_2:
																	if (23 < b)
																	{
																		break;
																	}
																	goto IL_10f8_2;
																	IL_10f8_2:
																	if (23 > b)
																	{
																		break;
																	}
																	goto IL_1106_2;
																	IL_1106_2:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_1158_2;
																	IL_1158_2:
																	num6--;
																	goto end_IL_0547_2;
																	IL_0745_2:
																	if (25 < b)
																	{
																		break;
																	}
																	num = 121;
																	goto IL_075c_2;
																	IL_0839_2:
																	num7 = ptr2;
																	num8 = -200;
																	num5 = 1;
																	ptr2 = num7 + num8;
																	goto end_IL_0547_2;
																	IL_075c_2:
																	if (25 > b)
																	{
																		break;
																	}
																	goto IL_1082_2;
																	IL_1082_2:
																	array2[num6 - 1] = 5;
																	goto IL_1096_2;
																	IL_1096_2:
																	array3[num6 - 1] = ((delegate*<RuntimeTypeHandle, Type>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])((RuntimeTypeHandle)array3[num6 - 1]);
																	num = 74;
																	goto IL_10d7_2;
																	IL_10d7_2:
																	ptr2 += 8;
																	goto end_IL_0547_2;
																	IL_09f0_2:
																	array3[num6] = null;
																	goto IL_09fa_2;
																	IL_09fa_2:
																	array2[num6] = 5;
																	goto IL_0a08_2;
																	IL_0a08_2:
																	num6++;
																	num = 43;
																	goto end_IL_0547_2;
																	IL_07e1_2:
																	if (28 < b)
																	{
																		goto IL_07ec_2;
																	}
																	goto IL_080d_2;
																	IL_07ec_2:
																	if (29 < b)
																	{
																		break;
																	}
																	goto IL_07fa_2;
																	IL_07fa_2:
																	if (29 <= b)
																	{
																	}
																	break;
																	IL_080d_2:
																	if (28 > b)
																	{
																		goto IL_0818_2;
																	}
																	goto IL_0839_2;
																	IL_0818_2:
																	if (27 < b)
																	{
																		break;
																	}
																	goto IL_0826_2;
																	IL_0826_2:
																	if (27 > b)
																	{
																		break;
																	}
																	goto IL_0935_2;
																	IL_0935_2:
																	array2[num6 - 4] = 5;
																	goto IL_0949_2;
																	IL_0949_2:
																	array3[num6 - 4] = ((delegate*<Type, string, Type[], Type[], MethodInfo>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])((Type)array3[num6 - 4], (string)array3[num6 - 3], (Type[])array3[num6 - 2], (Type[])array3[num6 - 1]);
																	goto IL_09b3_2;
																}
																break;
															}
															goto IL_0572_2;
															IL_08b2_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															num = 253;
															goto IL_0bb9_2;
															IL_0572_2:
															if (15 > b)
															{
																goto IL_059b_2;
															}
															num = 24;
															goto IL_06a0_2;
															IL_0bb9_2:
															array2[num6 - 2] = 0;
															goto IL_0bcd_2;
															IL_06a0_2:
															array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_0d21_2;
															IL_0d21_2:
															array2[num6 - 1] = 5;
															goto end_IL_0547_2;
															IL_059b_2:
															if (7 >= b)
															{
																goto IL_05cc_2;
															}
															goto IL_0900_2;
															IL_0900_2:
															if (11 >= b)
															{
																goto IL_090e_2;
															}
															goto IL_0a24_2;
															IL_090e_2:
															if (11 <= b)
															{
																goto IL_091c_2;
															}
															goto IL_0be0_2;
															IL_091c_2:
															array2[num6 - 1] = 0;
															goto IL_0d98_2;
															IL_0d98_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)addResourceResolveFilterNameIgnoreCase[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_0dd7_2;
															IL_0dd7_2:
															ptr2 += 8;
															goto end_IL_0547_2;
															IL_0be0_2:
															if (9 >= b)
															{
																goto IL_0bee_2;
															}
															num = 102;
															goto IL_0caa_2;
															IL_0bee_2:
															if (9 > b)
															{
																goto IL_0bf9_2;
															}
															goto IL_0c28_2;
															IL_0bf9_2:
															if (8 < b)
															{
																break;
															}
															goto IL_0c07_2;
															IL_0c07_2:
															if (8 > b)
															{
																break;
															}
															goto IL_0c15_2;
															IL_0c15_2:
															num6--;
															goto end_IL_0547_2;
															IL_0c28_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0c68_2;
															IL_0c68_2:
															array2[num6 - 2] = 0;
															num = 128;
															goto IL_0c85_2;
															IL_0c85_2:
															num6--;
															num = 91;
															goto end_IL_0547_2;
															IL_0bcd_2:
															num6--;
															goto end_IL_0547_2;
															IL_0caa_2:
															if (10 < b)
															{
																break;
															}
															goto IL_0e2d_2;
															IL_0e2d_2:
															if (10 > b)
															{
																break;
															}
															goto IL_0e3b_2;
															IL_0e3b_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0e9d_2;
															IL_0e9d_2:
															num6 -= 2;
															goto end_IL_0547_2;
															IL_0a24_2:
															if (13 >= b)
															{
																goto IL_0a32_2;
															}
															goto IL_0b6c_2;
															IL_0a32_2:
															if (13 <= b)
															{
																goto end_IL_125b_2;
															}
															goto IL_0a3d_2;
															IL_0a3d_2:
															if (12 < b)
															{
																break;
															}
															goto IL_0a4b_2;
															IL_0a4b_2:
															if (12 <= b)
															{
																goto end_IL_0547_2;
															}
															break;
															IL_0b6c_2:
															if (14 < b)
															{
																break;
															}
															goto IL_0b7a_2;
															IL_0b7a_2:
															if (14 > b)
															{
																break;
															}
															goto IL_0b88_2;
															IL_0b88_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_0ba6_2;
															IL_0ba6_2:
															ptr2 += 8;
															goto IL_0e1a_2;
															IL_0e1a_2:
															num6--;
															goto end_IL_0547_2;
															IL_05cc_2:
															if (7 > b)
															{
																goto IL_05da_2;
															}
															goto IL_08b2_2;
															IL_05da_2:
															if (3 < b)
															{
																goto IL_05fd_2;
															}
															goto IL_076f_2;
															IL_076f_2:
															if (3 > b)
															{
																goto IL_077d_2;
															}
															goto IL_0868_2;
															IL_077d_2:
															if (1 >= b)
															{
																goto IL_078b_2;
															}
															goto IL_0ff6_2;
															IL_078b_2:
															if (1 > b)
															{
																break;
															}
															goto IL_0799_2;
															IL_0799_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_07b2_2;
															IL_07b2_2:
															array2[num6] = 0;
															goto IL_07c0_2;
															IL_07c0_2:
															num6++;
															goto IL_07ce_2;
															IL_07ce_2:
															ptr2 += 8;
															goto end_IL_0547_2;
															IL_0ff6_2:
															if (2 < b)
															{
																break;
															}
															goto IL_1004_2;
															IL_1004_2:
															if (2 > b)
															{
																break;
															}
															goto IL_1012_2;
															IL_1012_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1052_2;
															IL_1052_2:
															array2[num6 - 2] = 0;
															goto IL_1066_2;
															IL_1066_2:
															num6--;
															num = 7;
															goto end_IL_0547_2;
															IL_0868_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0891_2;
															IL_0891_2:
															ptr2 += 8;
															goto IL_089f_2;
															IL_089f_2:
															num6--;
															goto end_IL_0547_2;
															IL_05fd_2:
															if (5 >= b)
															{
																goto IL_060b_2;
															}
															goto IL_0855_2;
															IL_060b_2:
															if (5 > b)
															{
																goto IL_0616_2;
															}
															goto IL_0626_2;
															IL_0616_2:
															if (4 < b)
															{
																break;
															}
															goto IL_068d_2;
															IL_068d_2:
															if (4 > b)
															{
																break;
															}
															goto IL_0b36_2;
															IL_0b36_2:
															array2[num6] = 0;
															goto IL_0b44_2;
															IL_0b44_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0eb0_2;
															IL_0eb0_2:
															array3[num6] = null;
															goto IL_0eba_2;
															IL_0eba_2:
															num6++;
															goto IL_0ec8_2;
															IL_0ec8_2:
															ptr2 += 8;
															goto end_IL_0547_2;
															IL_0626_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0666_2;
															IL_0666_2:
															array2[num6 - 2] = 0;
															goto IL_067a_2;
															IL_067a_2:
															num6--;
															goto end_IL_0547_2;
															IL_0855_2:
															if (6 < b)
															{
																break;
															}
															goto IL_0edb_2;
															IL_0edb_2:
															if (6 > b)
															{
																break;
															}
															goto IL_0ee9_2;
															IL_0ee9_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0f29_2;
															IL_0f29_2:
															array2[num6 - 2] = 0;
															goto IL_0f3d_2;
															IL_0f3d_2:
															num6--;
															goto end_IL_0547_2;
														}
														break;
														IL_0537_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												break;
												continue;
												end_IL_0547_2:
												break;
											}
											break;
										}
										break;
									}
									continue;
								}
								goto IL_131e_2;
								IL_131e_2:
								return (MethodBase)array3[num6 - 1];
								continue;
								end_IL_125b_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_0a6d_2;
					}
					continue;
					end_IL_0a7b:
					break;
				}
				break;
			}
		}
	}

	private unsafe static bool Prefix()
	{
		int num = 7;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 9;
					while (true)
					{
						byte[] array = new byte[1];
						while (true)
						{
							long[] array2 = new long[1];
							while (true)
							{
								IL_01bb:
								byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PermissionSetNameCommonSecurityDescriptor.LeaseLifeTimeServicePropertyHashSize);
								while (true)
								{
									IL_01b1:
									byte* ptr2 = ptr;
									while (true)
									{
										IL_01a1:
										if (num4 != 1)
										{
											while (true)
											{
												IL_0124:
												byte b = *ptr2;
												while (true)
												{
													IL_010b:
													ptr2++;
													num = 8;
													while (true)
													{
														IL_00fe:
														if (b >= 1)
														{
															while (b <= 2)
															{
																while (true)
																{
																	IL_00e4:
																	if (1 >= b)
																	{
																		while (1 <= b)
																		{
																			num = 41;
																			while (num != 41)
																			{
																				if (num != 1022)
																				{
																					goto end_IL_00fe;
																				}
																				switch (num)
																				{
																				case 0:
																					goto IL_00d4;
																				case 27:
																					goto IL_00e4;
																				case 31:
																					goto IL_00f1;
																				case 8:
																					goto IL_00fe;
																				case 2:
																					goto IL_010b;
																				case 18:
																				case 26:
																					goto IL_0124;
																				case 12:
																					goto IL_012f;
																				case 3:
																					goto IL_013a;
																				case 10:
																				case 15:
																					goto IL_0145;
																				case 5:
																				case 11:
																				case 17:
																				case 24:
																				case 25:
																				case 32:
																					goto end_IL_00c1;
																				case 33:
																					goto IL_0177;
																				case 21:
																					goto IL_0185;
																				case 28:
																					goto IL_0193;
																				case 13:
																				case 16:
																				case 20:
																				case 22:
																					goto IL_01a1;
																				case 1:
																					goto IL_01b1;
																				case 4:
																					goto IL_01bb;
																				case 14:
																				case 19:
																				case 34:
																					goto end_IL_00fe;
																				case 9:
																					goto end_IL_01c6;
																				case 23:
																					goto end_IL_01d6;
																				case 6:
																					goto end_IL_01e6;
																				case 7:
																					goto end_IL_01f1;
																				case 29:
																				case 30:
																					goto IL_020c;
																				}
																				continue;
																				end_IL_00c1:
																				break;
																			}
																			break;
																			IL_00d4:;
																		}
																		break;
																	}
																	goto IL_012f;
																	IL_0145:
																	byte* num5 = ptr2;
																	num4 = 1;
																	ptr2 = num5 + -200;
																	goto IL_01a1;
																	IL_012f:
																	if (2 < b)
																	{
																		break;
																	}
																	goto IL_013a;
																	IL_013a:
																	if (2 > b)
																	{
																		break;
																	}
																	goto IL_0145;
																}
																break;
																IL_00f1:;
															}
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num6]) = *(int*)(ptr2 + num3);
														goto IL_0177;
														IL_0193:
														ptr2 += 8;
														goto IL_01a1;
														IL_0185:
														num6++;
														goto IL_0193;
														IL_0177:
														array[num6] = 0;
														goto IL_0185;
														continue;
														end_IL_00fe:
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										goto IL_020c;
										IL_020c:
										return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num6 - 1])) != 0;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_01c6:
							break;
						}
						continue;
						end_IL_01d6:
						break;
					}
					continue;
					end_IL_01e6:
					break;
				}
				continue;
				end_IL_01f1:
				break;
			}
		}
	}

	public Class2()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		if (num <= num2)
		{
			num = int_1;
			num2 = int_0;
			return num - num2;
		}
		num = int_0;
		num2 = int_1;
		return num - num2;
	}

	private unsafe static int smethod_1(int int_0, int int_1)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 102;
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FUNCKINDSqrt.FullTrustZoneUntrustedFUNCFLAGFDEFAULTCOLLELEM);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_027e:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0261:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0254:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_0244:
																								if (8 >= b)
																								{
																									while (true)
																									{
																										IL_0237:
																										if (8 <= b)
																										{
																											while (true)
																											{
																												IL_01f5:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01d6:
																													array[num5 - 2] = 0;
																													num = 109;
																													while (true)
																													{
																														if (num != 109)
																														{
																															if (num != 1090)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 92:
																																goto IL_01d6;
																															case 15:
																															case 78:
																																goto IL_01f5;
																															case 43:
																																goto IL_0237;
																															case 96:
																																goto IL_0244;
																															case 22:
																																goto IL_0254;
																															case 65:
																																goto IL_0261;
																															case 24:
																																goto IL_026e;
																															case 30:
																																goto IL_027e;
																															case 33:
																																goto end_IL_027e;
																															case 0:
																															case 21:
																																goto end_IL_028e;
																															case 3:
																																goto IL_02b7;
																															case 1:
																																goto IL_02c5;
																															case 26:
																																goto IL_02d5;
																															case 23:
																																goto IL_02e3;
																															case 28:
																																goto IL_02f3;
																															case 47:
																																goto IL_0303;
																															case 51:
																															case 61:
																																goto IL_0316;
																															case 60:
																															case 62:
																																goto IL_0329;
																															case 25:
																																goto IL_0369;
																															case 20:
																																goto IL_037d;
																															case 53:
																															case 64:
																																goto IL_0390;
																															case 2:
																																goto IL_03b2;
																															case 27:
																																goto IL_03c0;
																															case 9:
																																goto IL_03ce;
																															case 8:
																															case 66:
																																goto IL_03e1;
																															case 13:
																																goto IL_03ef;
																															case 63:
																																goto IL_0412;
																															case 57:
																																goto IL_041c;
																															case 36:
																																goto IL_042a;
																															case 73:
																																goto IL_043d;
																															case 50:
																															case 67:
																																goto IL_0454;
																															case 83:
																																goto IL_0470;
																															case 18:
																																goto IL_047e;
																															case 40:
																															case 88:
																																goto IL_0491;
																															case 44:
																															case 89:
																																goto IL_04d6;
																															case 49:
																															case 55:
																																goto IL_04e1;
																															case 4:
																																goto IL_04ef;
																															case 70:
																																goto IL_0502;
																															case 6:
																															case 48:
																																goto IL_0510;
																															case 87:
																																goto IL_0539;
																															case 19:
																																goto IL_0547;
																															case 94:
																																goto IL_055a;
																															case 82:
																																goto IL_056e;
																															case 72:
																															case 98:
																																goto IL_0581;
																															case 68:
																																goto IL_05ca;
																															case 5:
																																goto IL_05de;
																															case 12:
																															case 16:
																															case 29:
																															case 32:
																															case 38:
																															case 41:
																															case 42:
																															case 54:
																															case 56:
																															case 59:
																															case 76:
																															case 85:
																															case 86:
																															case 90:
																															case 97:
																															case 100:
																															case 101:
																																goto end_IL_01c3;
																															case 84:
																																goto IL_0621;
																															case 58:
																																goto IL_062f;
																															case 45:
																																goto IL_063d;
																															case 11:
																															case 17:
																															case 35:
																															case 37:
																															case 69:
																															case 71:
																															case 77:
																															case 79:
																															case 91:
																															case 95:
																															case 99:
																																goto end_IL_029e;
																															case 14:
																																goto end_IL_064b;
																															case 46:
																																goto end_IL_065e;
																															case 34:
																																goto end_IL_0668;
																															case 102:
																																goto end_IL_0673;
																															case 7:
																																goto end_IL_0688;
																															case 10:
																															case 31:
																																goto end_IL_069d;
																															case 80:
																																goto end_IL_06b6;
																															case 52:
																															case 93:
																																goto end_IL_06c6;
																															case 74:
																																goto end_IL_06d6;
																															case 75:
																																goto end_IL_06e6;
																															case 39:
																															case 81:
																																goto IL_0701;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_029e;
																														continue;
																														end_IL_01c3:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																										}
																										else
																										{
																											num = 56;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0316;
																								IL_0454:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_029e;
																								IL_0316:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_043d;
																								IL_043d:
																								if (9 > b)
																								{
																									break;
																								}
																								num = 50;
																								goto IL_0454;
																							}
																							break;
																						}
																						goto IL_02b7;
																						IL_03ce:
																						ptr2 += 8;
																						goto end_IL_029e;
																						IL_02b7:
																						if (7 > b)
																						{
																							goto IL_02c5;
																						}
																						goto IL_0390;
																						IL_02c5:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_02f3;
																						IL_02f3:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0329;
																						IL_0329:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0369;
																						IL_0369:
																						array[num5 - 2] = 0;
																						goto IL_037d;
																						IL_037d:
																						num5--;
																						goto end_IL_029e;
																						IL_0390:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						num = 2;
																						goto IL_03b2;
																						IL_03b2:
																						array[num5] = 0;
																						goto IL_03c0;
																						IL_03c0:
																						num5++;
																						goto IL_03ce;
																					}
																					break;
																				}
																				goto IL_02d5;
																				IL_042a:
																				ptr2 += 8;
																				goto end_IL_029e;
																				IL_02d5:
																				if (5 > b)
																				{
																					goto IL_02e3;
																				}
																				goto IL_03e1;
																				IL_02e3:
																				if (2 >= b)
																				{
																					goto IL_0303;
																				}
																				goto IL_04d6;
																				IL_0303:
																				if (2 > b)
																				{
																					goto IL_0470;
																				}
																				goto IL_0491;
																				IL_0491:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_055a;
																				IL_055a:
																				array[num5 - 2] = 0;
																				goto IL_056e;
																				IL_056e:
																				num5--;
																				goto end_IL_029e;
																				IL_0470:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_047e;
																				IL_047e:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_04d6:
																				if (3 < b)
																				{
																					goto IL_04e1;
																				}
																				goto IL_0502;
																				IL_04e1:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_04ef;
																				IL_04ef:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0581;
																				IL_0581:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 68;
																				goto IL_05ca;
																				IL_05ca:
																				array[num5 - 2] = 0;
																				goto IL_05de;
																				IL_05de:
																				num5--;
																				goto end_IL_029e;
																				IL_0502:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0510;
																				IL_0510:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0539;
																				IL_0539:
																				ptr2 += 8;
																				goto IL_0547;
																				IL_0547:
																				num5--;
																				goto end_IL_029e;
																				IL_03e1:
																				array[num5] = 0;
																				goto IL_03ef;
																				IL_03ef:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0412;
																				IL_0412:
																				array2[num5] = null;
																				goto IL_041c;
																				IL_041c:
																				num5++;
																				goto IL_042a;
																			}
																			break;
																			IL_026e:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0621;
																	IL_063d:
																	ptr2 += 8;
																	goto end_IL_029e;
																	IL_062f:
																	num5++;
																	goto IL_063d;
																	IL_0621:
																	array[num5] = 0;
																	goto IL_062f;
																	continue;
																	end_IL_027e:
																	break;
																}
																continue;
																end_IL_028e:
																break;
															}
															continue;
															end_IL_029e:
															break;
														}
														continue;
													}
													goto IL_0701;
													IL_0701:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_064b:
													break;
												}
												continue;
												end_IL_065e:
												break;
											}
											continue;
											end_IL_0668:
											break;
										}
										continue;
										end_IL_0673:
										break;
									}
									continue;
									end_IL_0688:
									break;
								}
								continue;
								end_IL_069d:
								break;
							}
							continue;
							end_IL_06b6:
							break;
						}
						continue;
						end_IL_06c6:
						break;
					}
					continue;
					end_IL_06d6:
					break;
				}
				continue;
				end_IL_06e6:
				break;
			}
		}
	}

	private static int smethod_2(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		if (num <= num2)
		{
			num = int_1;
			num2 = int_0;
			return num - num2;
		}
		num = int_0;
		num2 = int_1;
		return num - num2;
	}

	private unsafe static int smethod_3(int int_0, int int_1)
	{
		int num = 70;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 53;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ProviderDefinedgetBuild.getTypeInformationgetUseAttribute);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 92;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0335:
																	if (b >= 1)
																	{
																		goto IL_01ff;
																	}
																	goto IL_030d;
																	IL_030d:
																	while (true)
																	{
																		IL_030d_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_01ef:
																			array[num5] = 0;
																			while (true)
																			{
																				IL_01d6:
																				num5++;
																				num = 109;
																				while (true)
																				{
																					if (num != 109)
																					{
																						if (num != 1090)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 64:
																							goto IL_01d6;
																						case 67:
																							goto IL_01ef;
																						case 7:
																							goto IL_01ff;
																						case 33:
																							goto IL_020d;
																						case 23:
																							goto IL_0218;
																						case 16:
																						case 45:
																							goto IL_0226;
																						case 79:
																							goto IL_0234;
																						case 94:
																							goto IL_0242;
																						case 78:
																							goto IL_0250;
																						case 97:
																							goto IL_0263;
																						case 60:
																							goto IL_026e;
																						case 40:
																						case 46:
																							goto IL_0279;
																						case 63:
																							goto IL_0287;
																						case 77:
																							goto IL_0297;
																						case 72:
																							goto IL_02a7;
																						case 89:
																							goto IL_02b5;
																						case 20:
																							goto IL_02c9;
																						case 95:
																						case 102:
																							goto IL_02d9;
																						case 0:
																							goto IL_02e4;
																						case 6:
																							goto IL_02f4;
																						case 71:
																							goto IL_02ff;
																						case 1:
																						case 2:
																						case 24:
																						case 25:
																						case 30:
																						case 37:
																						case 41:
																						case 43:
																						case 52:
																						case 56:
																						case 65:
																						case 68:
																						case 74:
																						case 80:
																						case 82:
																						case 93:
																						case 101:
																							goto IL_030d_2;
																						case 75:
																							goto IL_0335;
																						case 96:
																							goto end_IL_0335;
																						case 9:
																						case 32:
																							goto end_IL_0345;
																						case 18:
																						case 44:
																							goto IL_0360;
																						case 66:
																							goto IL_03a0;
																						case 8:
																							goto IL_03b4;
																						case 31:
																						case 86:
																							goto IL_03c7;
																						case 73:
																							goto IL_03d5;
																						case 62:
																							goto IL_03f8;
																						case 88:
																							goto IL_0402;
																						case 87:
																							goto IL_0410;
																						case 22:
																						case 59:
																							goto IL_0423;
																						case 13:
																						case 14:
																							goto IL_043f;
																						case 21:
																							goto end_IL_01c3;
																						case 50:
																							goto IL_0493;
																						case 17:
																						case 90:
																							goto IL_04a6;
																						case 57:
																							goto IL_04bf;
																						case 10:
																							goto IL_04cd;
																						case 48:
																							goto IL_04db;
																						case 5:
																						case 91:
																							goto IL_04ee;
																						case 11:
																							goto IL_052e;
																						case 99:
																							goto IL_0542;
																						case 29:
																						case 55:
																							goto IL_0555;
																						case 98:
																							goto IL_057e;
																						case 81:
																							goto IL_058c;
																						case 12:
																						case 15:
																							goto IL_059c;
																						case 49:
																							goto IL_05dc;
																						case 26:
																							goto IL_05f0;
																						case 27:
																						case 28:
																						case 35:
																						case 39:
																						case 47:
																						case 51:
																						case 54:
																						case 83:
																						case 84:
																						case 92:
																						case 100:
																							goto end_IL_0355;
																						case 4:
																							goto end_IL_060e;
																						case 85:
																							goto end_IL_0621;
																						case 3:
																							goto end_IL_0634;
																						case 19:
																							goto end_IL_063f;
																						case 58:
																							goto end_IL_0654;
																						case 34:
																						case 42:
																							goto end_IL_0669;
																						case 76:
																							goto end_IL_0679;
																						case 36:
																						case 53:
																							goto end_IL_0689;
																						case 69:
																							goto end_IL_0699;
																						case 70:
																							goto end_IL_06a9;
																						case 38:
																						case 61:
																							goto IL_06d6;
																						}
																						continue;
																					}
																					ptr2 += 8;
																					goto end_IL_0355;
																					continue;
																					end_IL_01c3:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_047f;
																	IL_01ff:
																	if (b <= 9)
																	{
																		goto IL_020d;
																	}
																	goto IL_030d;
																	IL_020d:
																	if (5 >= b)
																	{
																		goto IL_0218;
																	}
																	goto IL_0263;
																	IL_0218:
																	if (5 > b)
																	{
																		goto IL_0226;
																	}
																	goto IL_03c7;
																	IL_0226:
																	if (2 >= b)
																	{
																		goto IL_0234;
																	}
																	goto IL_02d9;
																	IL_0234:
																	if (2 > b)
																	{
																		goto IL_0242;
																	}
																	goto IL_0360;
																	IL_0242:
																	if (1 >= b)
																	{
																		goto IL_0250;
																	}
																	goto IL_030d;
																	IL_0250:
																	if (1 > b)
																	{
																	}
																	goto IL_030d;
																	IL_0360:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_03a0;
																	IL_03a0:
																	array[num5 - 2] = 0;
																	goto IL_03b4;
																	IL_03b4:
																	num5--;
																	goto end_IL_0355;
																	IL_02d9:
																	if (3 >= b)
																	{
																		goto IL_02e4;
																	}
																	goto IL_02f4;
																	IL_02e4:
																	if (3 > b)
																	{
																		goto IL_030d;
																	}
																	goto IL_0555;
																	IL_0555:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_057e;
																	IL_057e:
																	ptr2 += 8;
																	goto IL_058c;
																	IL_058c:
																	num5--;
																	goto end_IL_0355;
																	IL_02f4:
																	if (4 >= b)
																	{
																		goto IL_02ff;
																	}
																	goto IL_030d;
																	IL_02ff:
																	if (4 > b)
																	{
																		goto IL_030d;
																	}
																	goto IL_059c;
																	IL_059c:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05dc;
																	IL_05dc:
																	array[num5 - 2] = 0;
																	goto IL_05f0;
																	IL_05f0:
																	num5--;
																	goto end_IL_0355;
																	IL_03c7:
																	array[num5] = 0;
																	goto IL_03d5;
																	IL_03d5:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_03f8;
																	IL_03f8:
																	array2[num5] = null;
																	goto IL_0402;
																	IL_0402:
																	num5++;
																	goto IL_0410;
																	IL_0410:
																	ptr2 += 8;
																	goto end_IL_0355;
																	IL_0263:
																	if (7 < b)
																	{
																		goto IL_026e;
																	}
																	goto IL_02a7;
																	IL_026e:
																	if (8 < b)
																	{
																		goto IL_0279;
																	}
																	goto IL_0297;
																	IL_0279:
																	if (9 >= b)
																	{
																		goto IL_0287;
																	}
																	goto IL_030d;
																	IL_0287:
																	if (9 > b)
																	{
																		goto IL_030d;
																	}
																	goto IL_0423;
																	IL_0423:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_0355;
																	IL_0297:
																	if (8 > b)
																	{
																		goto IL_030d;
																	}
																	goto IL_043f;
																	IL_043f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_047f;
																	IL_047f:
																	array[num5 - 2] = 0;
																	goto IL_0493;
																	IL_0493:
																	num5--;
																	goto end_IL_0355;
																	IL_02a7:
																	if (7 > b)
																	{
																		goto IL_02b5;
																	}
																	goto IL_04a6;
																	IL_02b5:
																	if (6 >= b)
																	{
																		num = 20;
																		goto IL_02c9;
																	}
																	goto IL_030d;
																	IL_04db:
																	ptr2 += 8;
																	goto end_IL_0355;
																	IL_02c9:
																	if (6 > b)
																	{
																		goto IL_030d;
																	}
																	goto IL_04ee;
																	IL_04ee:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_052e;
																	IL_052e:
																	array[num5 - 2] = 0;
																	goto IL_0542;
																	IL_0542:
																	num5--;
																	goto end_IL_0355;
																	IL_04a6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_04bf;
																	IL_04bf:
																	array[num5] = 0;
																	goto IL_04cd;
																	IL_04cd:
																	num5++;
																	goto IL_04db;
																	continue;
																	end_IL_0335:
																	break;
																}
																continue;
																end_IL_0345:
																break;
															}
															continue;
															end_IL_0355:
															break;
														}
														continue;
													}
													num = 61;
													goto IL_06d6;
													IL_06d6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_060e:
													break;
												}
												continue;
												end_IL_0621:
												break;
											}
											continue;
											end_IL_0634:
											break;
										}
										continue;
										end_IL_063f:
										break;
									}
									continue;
									end_IL_0654:
									break;
								}
								continue;
								end_IL_0669:
								break;
							}
							continue;
							end_IL_0679:
							break;
						}
						continue;
						end_IL_0689:
						break;
					}
					continue;
					end_IL_0699:
					break;
				}
				continue;
				end_IL_06a9:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 50;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 43;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 38;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnhandledExceptionEventHandlerIObservable.getLegalBlockSizesRegisterTypeForComClients);
											num = 21;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0216:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01f6:
																				if (4 >= b)
																				{
																					num = 39;
																					while (true)
																					{
																						IL_01e6:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01d9:
																								if (2 < b)
																								{
																									while (3 >= b)
																									{
																										while (3 <= b)
																										{
																											num = 94;
																											while (true)
																											{
																												if (num != 94)
																												{
																													if (num != 1075)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 61:
																														goto IL_01b6;
																													case 8:
																													case 81:
																														goto IL_01c9;
																													case 74:
																														goto end_IL_01a3;
																													case 39:
																														goto IL_01e6;
																													case 5:
																														goto IL_01f6;
																													case 6:
																														goto IL_0206;
																													case 86:
																														goto IL_0216;
																													case 41:
																														goto end_IL_0216;
																													case 62:
																													case 73:
																														goto end_IL_0226;
																													case 7:
																														goto IL_0241;
																													case 22:
																														goto IL_0251;
																													case 55:
																														goto IL_0264;
																													case 16:
																													case 27:
																														goto IL_0272;
																													case 42:
																														goto IL_0280;
																													case 36:
																													case 56:
																														goto IL_0293;
																													case 47:
																														goto IL_02bc;
																													case 30:
																														goto IL_02ca;
																													case 57:
																													case 65:
																														goto IL_02e6;
																													case 53:
																														goto IL_0354;
																													case 68:
																														goto IL_0367;
																													case 44:
																														goto IL_0375;
																													case 46:
																													case 69:
																														goto IL_0391;
																													case 33:
																													case 82:
																														goto IL_03a9;
																													case 59:
																														goto IL_03b4;
																													case 25:
																													case 40:
																														goto IL_03c2;
																													case 63:
																														goto IL_03d0;
																													case 37:
																														goto IL_03f3;
																													case 29:
																														goto IL_03fd;
																													case 54:
																														goto IL_040b;
																													case 19:
																													case 87:
																														goto IL_041e;
																													case 51:
																														goto IL_042c;
																													case 3:
																													case 71:
																														goto IL_043a;
																													case 80:
																														goto IL_0456;
																													case 31:
																														goto IL_0496;
																													case 79:
																														goto IL_04aa;
																													case 0:
																													case 10:
																													case 11:
																													case 15:
																													case 18:
																													case 20:
																													case 23:
																													case 24:
																													case 35:
																													case 48:
																													case 64:
																													case 66:
																													case 67:
																													case 84:
																													case 85:
																														goto end_IL_01b6;
																													case 32:
																														goto IL_04e6;
																													case 72:
																														goto IL_04f4;
																													case 12:
																														goto IL_0502;
																													case 1:
																													case 4:
																													case 13:
																													case 14:
																													case 17:
																													case 28:
																													case 45:
																													case 70:
																													case 75:
																													case 76:
																													case 83:
																														goto end_IL_0236;
																													case 21:
																														goto end_IL_0510;
																													case 60:
																														goto end_IL_0523;
																													case 77:
																														goto end_IL_052d;
																													case 52:
																														goto end_IL_0541;
																													case 38:
																														goto end_IL_0556;
																													case 2:
																													case 34:
																														goto end_IL_056b;
																													case 43:
																														goto end_IL_057b;
																													case 9:
																													case 58:
																														goto end_IL_0594;
																													case 49:
																														goto end_IL_05a4;
																													case 50:
																														goto end_IL_05bd;
																													case 26:
																													case 78:
																														goto IL_05d8;
																													}
																													continue;
																												}
																												goto IL_0456;
																												IL_0496:
																												array[num5 - 2] = 0;
																												goto IL_04aa;
																												IL_04aa:
																												num5--;
																												num = 17;
																												goto end_IL_0236;
																												IL_0456:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0496;
																												continue;
																												end_IL_01a3:
																												break;
																											}
																											goto IL_01d9;
																											continue;
																											end_IL_01b6:
																											break;
																											IL_01b6:;
																										}
																										break;
																										IL_01c9:;
																									}
																									break;
																								}
																								goto IL_0251;
																								IL_0375:
																								if (1 <= b)
																								{
																									num = 67;
																								}
																								break;
																								IL_0251:
																								if (2 <= b)
																								{
																									goto IL_02e6;
																								}
																								goto IL_0367;
																								IL_02e6:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0354;
																								IL_0354:
																								num5 -= 2;
																								goto end_IL_0236;
																								IL_0367:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0375;
																							}
																							break;
																						}
																						goto IL_0293;
																						IL_02ca:
																						num5--;
																						num = 76;
																						goto end_IL_0236;
																						IL_0293:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02bc;
																						IL_02bc:
																						ptr2 += 8;
																						goto IL_02ca;
																					}
																					break;
																				}
																				goto IL_0241;
																				IL_042c:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_043a;
																				IL_043a:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0236;
																				IL_0241:
																				if (6 >= b)
																				{
																					goto IL_0264;
																				}
																				goto IL_03a9;
																				IL_0264:
																				if (6 <= b)
																				{
																					goto end_IL_0236;
																				}
																				goto IL_0272;
																				IL_0272:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0280;
																				IL_0280:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0391;
																				IL_0391:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0236;
																				IL_03a9:
																				if (7 >= b)
																				{
																					goto IL_03b4;
																				}
																				goto IL_041e;
																				IL_03b4:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_03c2;
																				IL_03c2:
																				array[num5] = 0;
																				goto IL_03d0;
																				IL_03d0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03f3;
																				IL_03f3:
																				array2[num5] = null;
																				goto IL_03fd;
																				IL_03fd:
																				num5++;
																				goto IL_040b;
																				IL_040b:
																				ptr2 += 8;
																				goto end_IL_0236;
																				IL_041e:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_042c;
																			}
																			break;
																			IL_0206:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04e6;
																	IL_0502:
																	ptr2 += 8;
																	goto end_IL_0236;
																	IL_04f4:
																	num5++;
																	goto IL_0502;
																	IL_04e6:
																	array[num5] = 0;
																	goto IL_04f4;
																	continue;
																	end_IL_0216:
																	break;
																}
																continue;
																end_IL_0226:
																break;
															}
															continue;
															end_IL_0236:
															break;
														}
														continue;
													}
													goto IL_05d8;
													IL_05d8:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0510:
													break;
												}
												continue;
												end_IL_0523:
												break;
											}
											continue;
											end_IL_052d:
											break;
										}
										continue;
										end_IL_0541:
										break;
									}
									continue;
									end_IL_0556:
									break;
								}
								continue;
								end_IL_056b:
								break;
							}
							continue;
							end_IL_057b:
							break;
						}
						continue;
						end_IL_0594:
						break;
					}
					continue;
					end_IL_05a4:
					break;
				}
				continue;
				end_IL_05bd:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 32;
		object[] array2 = default(object[]);
		byte b = default(byte);
		int num4 = default(int);
		long[] array3 = default(long[]);
		byte* ptr = default(byte*);
		int[] array4 = default(int[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 83;
				while (true)
				{
					byte[] array = new byte[2];
					num = 109;
					while (true)
					{
						if (num != 109)
						{
							if (num != 1090)
							{
								goto IL_0267;
							}
							switch (num)
							{
							case 35:
							case 83:
								goto end_IL_01c3;
							case 31:
								goto end_IL_01d3;
							case 32:
								goto end_IL_01ec;
							case 51:
							case 69:
								goto IL_0227;
							case 4:
								goto IL_0235;
							case 21:
								goto IL_0243;
							case 60:
								goto IL_0256;
							case 5:
								goto IL_025f;
							case 26:
							case 57:
							case 62:
							case 66:
							case 67:
							case 74:
							case 78:
							case 84:
							case 89:
							case 96:
							case 97:
							case 99:
							case 100:
								goto IL_0267;
							case 8:
							case 77:
								goto IL_0277;
							case 38:
								goto IL_0289;
							case 95:
								goto IL_0297;
							case 56:
								goto IL_02a5;
							case 49:
								goto IL_02bc;
							case 6:
								goto IL_02ca;
							case 39:
								goto IL_02d8;
							case 0:
							case 36:
								goto IL_02e3;
							case 2:
								goto IL_0345;
							case 90:
								goto IL_0358;
							case 3:
							case 22:
								goto IL_0363;
							case 70:
								goto IL_0371;
							case 9:
							case 44:
								goto IL_037f;
							case 101:
								goto IL_03a2;
							case 50:
								goto IL_03b0;
							case 98:
								goto IL_03be;
							case 54:
								goto IL_03d1;
							case 17:
							case 94:
								goto IL_03df;
							case 12:
								goto IL_041f;
							case 80:
								goto IL_043c;
							case 47:
								goto IL_044f;
							case 10:
								goto IL_045a;
							case 58:
							case 79:
								goto IL_0468;
							case 71:
								goto IL_0484;
							case 75:
								goto IL_0492;
							case 53:
								goto IL_04a5;
							case 85:
							case 92:
								goto IL_04b0;
							case 43:
								goto IL_04be;
							case 42:
								goto IL_04e1;
							case 23:
								goto IL_04f4;
							case 29:
								goto IL_0502;
							case 25:
								goto IL_0515;
							case 27:
							case 40:
								goto IL_0529;
							case 55:
								goto IL_0534;
							case 48:
							case 63:
								goto IL_0542;
							case 72:
								goto IL_055a;
							case 37:
								goto IL_0568;
							case 28:
								goto IL_057b;
							case 30:
							case 81:
								goto IL_0586;
							case 82:
								goto IL_05b8;
							case 18:
								goto IL_05c6;
							case 87:
								goto IL_05d9;
							case 16:
								goto IL_05ed;
							case 93:
							case 102:
								goto IL_05f8;
							case 34:
								goto IL_0611;
							case 19:
								goto IL_061f;
							case 61:
								goto IL_062d;
							case 1:
							case 11:
							case 13:
							case 14:
							case 15:
							case 20:
							case 24:
							case 33:
							case 41:
							case 45:
							case 46:
							case 52:
							case 59:
							case 64:
							case 65:
							case 68:
							case 73:
							case 86:
							case 88:
							case 91:
								goto IL_0640;
							case 7:
							case 76:
								goto IL_0658;
							}
							continue;
						}
						array2 = new object[2];
						num = 69;
						goto IL_0227;
						IL_05ed:
						if (1 <= b)
						{
							goto IL_05f8;
						}
						goto IL_0640;
						IL_0611:
						array[num4] = 0;
						goto IL_061f;
						IL_05f8:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(int*)(ptr + num3);
						goto IL_0611;
						IL_0227:
						array4 = new int[3];
						goto IL_0235;
						IL_0235:
						array3 = new long[2];
						goto IL_0243;
						IL_0243:
						array4[0] = int_0;
						goto IL_0256;
						IL_0256:
						ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref cArgsgetResolver.LowLatencySelectNewObject);
						goto IL_025f;
						IL_025f:
						ptr = ptr2;
						goto IL_0267;
						IL_0267:
						if (num5 != 1)
						{
							goto IL_0277;
						}
						goto IL_0658;
						IL_0658:
						return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
						IL_0277:
						b = *ptr;
						num = 38;
						goto IL_0289;
						IL_0289:
						ptr++;
						goto IL_0297;
						IL_0297:
						if (b >= 1)
						{
							goto IL_02a5;
						}
						goto IL_0640;
						IL_02a5:
						if (b <= 10)
						{
							num = 49;
							goto IL_02bc;
						}
						goto IL_0640;
						IL_061f:
						num4++;
						goto IL_062d;
						IL_02bc:
						if (5 < b)
						{
							goto IL_02ca;
						}
						goto IL_04a5;
						IL_02ca:
						if (8 >= b)
						{
							goto IL_02d8;
						}
						goto IL_044f;
						IL_02d8:
						if (8 <= b)
						{
							goto IL_02e3;
						}
						goto IL_0358;
						IL_02e3:
						ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
						goto IL_0345;
						IL_0345:
						num4 -= 2;
						goto IL_0267;
						IL_0358:
						if (6 < b)
						{
							goto IL_0363;
						}
						goto IL_03d1;
						IL_0363:
						if (7 >= b)
						{
							goto IL_0371;
						}
						goto IL_0640;
						IL_0371:
						if (7 <= b)
						{
							goto IL_037f;
						}
						goto IL_0640;
						IL_037f:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
						goto IL_03a2;
						IL_03a2:
						array[num4] = 0;
						goto IL_03b0;
						IL_03b0:
						num4++;
						goto IL_03be;
						IL_03be:
						ptr += 8;
						goto IL_0267;
						IL_03d1:
						if (6 <= b)
						{
							goto IL_03df;
						}
						goto IL_0640;
						IL_03df:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
						goto IL_041f;
						IL_041f:
						array[num4 - 2] = 0;
						num = 80;
						goto IL_043c;
						IL_043c:
						num4--;
						goto IL_0267;
						IL_044f:
						if (9 >= b)
						{
							goto IL_045a;
						}
						goto IL_0484;
						IL_045a:
						if (9 <= b)
						{
							goto IL_0468;
						}
						goto IL_0640;
						IL_0468:
						byte* num6 = ptr;
						num5 = 1;
						ptr = num6 + -200;
						goto IL_0267;
						IL_0484:
						if (10 >= b)
						{
							goto IL_0492;
						}
						goto IL_0640;
						IL_0492:
						if (10 > b)
						{
						}
						goto IL_0640;
						IL_04a5:
						if (5 <= b)
						{
							goto IL_04b0;
						}
						goto IL_0515;
						IL_04b0:
						array[num4] = 0;
						goto IL_04be;
						IL_04be:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
						goto IL_04e1;
						IL_04e1:
						array2[num4] = null;
						num = 23;
						goto IL_04f4;
						IL_04f4:
						num4++;
						goto IL_0502;
						IL_0502:
						ptr += 8;
						goto IL_0267;
						IL_0515:
						if (2 < b)
						{
							num = 27;
							goto IL_0529;
						}
						goto IL_057b;
						IL_062d:
						ptr += 8;
						goto IL_0267;
						IL_0529:
						if (3 >= b)
						{
							goto IL_0534;
						}
						goto IL_055a;
						IL_0534:
						if (3 <= b)
						{
							goto IL_0542;
						}
						goto IL_0640;
						IL_0542:
						ptr = ptr2 + *(int*)(ptr + num3);
						goto IL_0267;
						IL_055a:
						if (4 >= b)
						{
							goto IL_0568;
						}
						goto IL_0640;
						IL_0568:
						if (4 <= b)
						{
							goto IL_0267;
						}
						goto IL_0640;
						IL_057b:
						if (2 <= b)
						{
							goto IL_0586;
						}
						goto IL_05d9;
						IL_0586:
						ref int reference = ref array4[*(int*)(ptr + num3)];
						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
						num = 82;
						goto IL_05b8;
						IL_05b8:
						ptr += 8;
						goto IL_05c6;
						IL_05c6:
						num4--;
						goto IL_0267;
						IL_05d9:
						if (1 >= b)
						{
							num = 16;
							goto IL_05ed;
						}
						goto IL_0640;
						IL_0640:
						ptr = ptr2 + *(int*)(ptr + num3);
						goto IL_0267;
						continue;
						end_IL_01c3:
						break;
					}
					continue;
					end_IL_01d3:
					break;
				}
				continue;
				end_IL_01ec:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_0, int int_1)
	{
		int num = 51;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_0;
									num = 82;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DoubleArrayTypeInfoSetType.ComponentGuaranteesOptionsgetCharCapacity);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02a6:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0289:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0279:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0269:
																								if (9 <= b)
																								{
																									while (true)
																									{
																										IL_021e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 127;
																										while (true)
																										{
																											if (num != 127)
																											{
																												if (num != 1108)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 6:
																												case 20:
																													goto IL_021e;
																												case 61:
																													goto IL_0269;
																												case 98:
																													goto IL_0279;
																												case 117:
																													goto IL_0289;
																												case 26:
																													goto end_IL_0289;
																												case 80:
																													goto IL_02a6;
																												case 52:
																													goto end_IL_02a6;
																												case 69:
																												case 100:
																													goto end_IL_02b6;
																												case 103:
																													goto IL_02d1;
																												case 59:
																												case 67:
																													goto IL_02e8;
																												case 0:
																													goto IL_02f6;
																												case 58:
																													goto IL_0304;
																												case 12:
																													goto IL_030f;
																												case 5:
																													goto IL_0322;
																												case 63:
																													goto IL_0330;
																												case 16:
																												case 46:
																													goto IL_0347;
																												case 7:
																													goto IL_03b5;
																												case 81:
																													goto end_IL_020b;
																												case 104:
																													goto IL_03d6;
																												case 41:
																												case 87:
																													goto IL_03e4;
																												case 49:
																													goto IL_040d;
																												case 66:
																													goto IL_041b;
																												case 37:
																												case 107:
																													goto IL_042e;
																												case 47:
																												case 112:
																													goto IL_0470;
																												case 25:
																													goto IL_0487;
																												case 73:
																												case 89:
																													goto IL_0495;
																												case 114:
																													goto IL_04b6;
																												case 9:
																													goto IL_04ca;
																												case 33:
																													goto IL_04f1;
																												case 8:
																													goto IL_0504;
																												case 54:
																													goto IL_050f;
																												case 72:
																												case 84:
																													goto IL_051d;
																												case 91:
																													goto IL_052b;
																												case 38:
																													goto IL_054e;
																												case 40:
																													goto IL_0558;
																												case 94:
																													goto IL_0566;
																												case 34:
																													goto IL_0579;
																												case 53:
																													goto IL_0587;
																												case 18:
																												case 28:
																													goto IL_0595;
																												case 36:
																													goto IL_05ae;
																												case 62:
																													goto IL_05bc;
																												case 70:
																													goto IL_05ca;
																												case 39:
																													goto IL_05dd;
																												case 108:
																													goto IL_05eb;
																												case 30:
																												case 90:
																													goto IL_05f9;
																												case 79:
																													goto IL_0607;
																												case 44:
																												case 95:
																													goto IL_0615;
																												case 57:
																													goto IL_0629;
																												case 3:
																													goto IL_067d;
																												case 76:
																													goto IL_068b;
																												case 22:
																												case 105:
																													goto IL_069e;
																												case 13:
																													goto IL_06b1;
																												case 110:
																													goto IL_06bc;
																												case 15:
																												case 23:
																												case 27:
																												case 29:
																												case 31:
																												case 32:
																												case 35:
																												case 42:
																												case 43:
																												case 64:
																												case 71:
																												case 78:
																												case 85:
																												case 88:
																												case 92:
																												case 97:
																												case 99:
																												case 101:
																												case 109:
																												case 115:
																												case 116:
																													goto end_IL_0296;
																												case 65:
																													goto IL_06ea;
																												case 1:
																													goto IL_06f8;
																												case 68:
																													goto IL_0706;
																												case 11:
																												case 48:
																													goto IL_071f;
																												case 14:
																												case 19:
																												case 24:
																												case 56:
																												case 60:
																												case 74:
																												case 75:
																												case 77:
																												case 83:
																												case 86:
																												case 93:
																												case 102:
																												case 106:
																												case 118:
																												case 120:
																													goto end_IL_02c6;
																												case 45:
																													goto end_IL_0736;
																												case 111:
																													goto end_IL_0749;
																												case 82:
																													goto end_IL_0753;
																												case 2:
																													goto end_IL_075e;
																												case 10:
																													goto end_IL_0773;
																												case 21:
																												case 119:
																													goto end_IL_0791;
																												case 17:
																													goto end_IL_07a1;
																												case 55:
																												case 113:
																													goto end_IL_07b1;
																												case 50:
																													goto end_IL_07c1;
																												case 51:
																													goto end_IL_07d1;
																												case 4:
																												case 96:
																													goto IL_07ec;
																												}
																												continue;
																											}
																											array[num5 - 2] = 0;
																											goto IL_04f1;
																											IL_04f1:
																											num5--;
																											goto end_IL_02c6;
																											continue;
																											end_IL_020b:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0504;
																								IL_05ca:
																								ptr2 += 8;
																								goto end_IL_02c6;
																								IL_0504:
																								if (7 >= b)
																								{
																									goto IL_050f;
																								}
																								goto IL_0579;
																								IL_050f:
																								if (7 > b)
																								{
																									goto end_IL_0296;
																								}
																								goto IL_051d;
																								IL_051d:
																								array[num5] = 0;
																								goto IL_052b;
																								IL_052b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_054e;
																								IL_054e:
																								array2[num5] = null;
																								goto IL_0558;
																								IL_0558:
																								num5++;
																								goto IL_0566;
																								IL_0566:
																								ptr2 += 8;
																								goto end_IL_02c6;
																								IL_0579:
																								if (8 < b)
																								{
																									goto end_IL_0296;
																								}
																								goto IL_0587;
																								IL_0587:
																								if (8 > b)
																								{
																									goto end_IL_0296;
																								}
																								goto IL_0595;
																								IL_0595:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_05ae;
																								IL_05ae:
																								array[num5] = 0;
																								goto IL_05bc;
																								IL_05bc:
																								num5++;
																								goto IL_05ca;
																							}
																							break;
																						}
																						goto IL_05dd;
																						IL_071f:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02c6;
																						IL_05dd:
																						if (11 >= b)
																						{
																							goto IL_05eb;
																						}
																						goto IL_06b1;
																						IL_05eb:
																						if (11 > b)
																						{
																							goto IL_05f9;
																						}
																						goto IL_069e;
																						IL_05f9:
																						if (10 < b)
																						{
																							goto end_IL_0296;
																						}
																						goto IL_0607;
																						IL_0607:
																						if (10 > b)
																						{
																							goto end_IL_0296;
																						}
																						goto IL_0615;
																						IL_0615:
																						array[num5 - 2] = 0;
																						goto IL_0629;
																						IL_0629:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)intptr_0[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_067d;
																						IL_067d:
																						num5--;
																						goto IL_068b;
																						IL_068b:
																						ptr2 += 8;
																						goto end_IL_02c6;
																						IL_069e:
																						num5--;
																						goto end_IL_02c6;
																						IL_06b1:
																						if (12 < b)
																						{
																							goto end_IL_0296;
																						}
																						goto IL_06bc;
																						IL_06bc:
																						if (12 > b)
																						{
																							goto end_IL_0296;
																						}
																						goto IL_071f;
																					}
																					goto IL_03c8;
																				}
																				goto IL_02d1;
																				IL_0470:
																				if (5 < b)
																				{
																					goto end_IL_0296;
																				}
																				num = 25;
																				goto IL_0487;
																				IL_02d1:
																				if (6 <= b)
																				{
																					goto end_IL_02c6;
																				}
																				num = 67;
																				goto IL_02e8;
																				IL_0495:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 120;
																				goto end_IL_02c6;
																				IL_02e8:
																				if (3 >= b)
																				{
																					goto IL_02f6;
																				}
																				goto IL_03c8;
																				IL_02f6:
																				if (3 > b)
																				{
																					goto IL_0304;
																				}
																				goto IL_042e;
																				IL_0304:
																				if (1 >= b)
																				{
																					goto IL_030f;
																				}
																				goto IL_0322;
																				IL_030f:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0296;
																				IL_0322:
																				if (2 < b)
																				{
																					goto end_IL_0296;
																				}
																				goto IL_0330;
																				IL_0330:
																				if (2 > b)
																				{
																					goto end_IL_0296;
																				}
																				num = 46;
																				goto IL_0347;
																				IL_0487:
																				if (5 > b)
																				{
																					goto end_IL_0296;
																				}
																				goto IL_0495;
																				IL_0347:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03b5;
																				IL_03b5:
																				num5 -= 2;
																				goto end_IL_02c6;
																				IL_042e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04b6;
																				IL_04b6:
																				array[num5 - 2] = 0;
																				goto IL_04ca;
																				IL_04ca:
																				num5--;
																				goto end_IL_02c6;
																				IL_03c8:
																				if (4 >= b)
																				{
																					goto IL_03d6;
																				}
																				goto IL_0470;
																				IL_03d6:
																				if (4 > b)
																				{
																					goto end_IL_0296;
																				}
																				goto IL_03e4;
																				IL_03e4:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_040d;
																				IL_040d:
																				ptr2 += 8;
																				goto IL_041b;
																				IL_041b:
																				num5--;
																				goto end_IL_02c6;
																				continue;
																				end_IL_0289:
																				break;
																			}
																			continue;
																			end_IL_0296:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06ea;
																	IL_0706:
																	ptr2 += 8;
																	num = 83;
																	goto end_IL_02c6;
																	IL_06f8:
																	num5++;
																	goto IL_0706;
																	IL_06ea:
																	array[num5] = 0;
																	goto IL_06f8;
																	continue;
																	end_IL_02a6:
																	break;
																}
																continue;
																end_IL_02b6:
																break;
															}
															continue;
															end_IL_02c6:
															break;
														}
														continue;
													}
													goto IL_07ec;
													IL_07ec:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0736:
													break;
												}
												continue;
												end_IL_0749:
												break;
											}
											continue;
											end_IL_0753:
											break;
										}
										continue;
										end_IL_075e:
										break;
									}
									continue;
									end_IL_0773:
									break;
								}
								continue;
								end_IL_0791:
								break;
							}
							continue;
							end_IL_07a1:
							break;
						}
						continue;
						end_IL_07b1:
						break;
					}
					continue;
					end_IL_07c1:
					break;
				}
				continue;
				end_IL_07d1:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0)
	{
		int num = 103;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_0;
									num = 26;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MutexSecurityRemoteOnly.UserNameWait);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0341:
														byte b = *ptr2;
														while (true)
														{
															IL_0331:
															ptr2++;
															while (true)
															{
																IL_0321:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0304:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02f4:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02e4:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_02d4:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_02c4:
																											if (1 < b)
																											{
																												num = 27;
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_0279:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_0269:
																																ptr2 += 8;
																																while (true)
																																{
																																	IL_0250:
																																	num5--;
																																	num = 136;
																																	while (num != 136)
																																	{
																																		if (num != 1117)
																																		{
																																			goto IL_06fb;
																																		}
																																		switch (num)
																																		{
																																		case 97:
																																			goto IL_0250;
																																		case 93:
																																			goto IL_0269;
																																		case 51:
																																		case 67:
																																			goto IL_0279;
																																		case 42:
																																			goto IL_02a4;
																																		case 27:
																																		case 61:
																																			goto IL_02b4;
																																		case 55:
																																		case 94:
																																			goto IL_02c4;
																																		case 9:
																																			goto IL_02d4;
																																		case 69:
																																			goto IL_02e4;
																																		case 110:
																																			goto IL_02f4;
																																		case 111:
																																			goto IL_0304;
																																		case 88:
																																			goto IL_0311;
																																		case 15:
																																			goto IL_0321;
																																		case 50:
																																			goto IL_0331;
																																		case 40:
																																		case 48:
																																			goto IL_0341;
																																		case 46:
																																			goto IL_034c;
																																		case 47:
																																		case 68:
																																			goto IL_035f;
																																		case 52:
																																		case 75:
																																			goto IL_036d;
																																		case 16:
																																			goto IL_037b;
																																		case 10:
																																			goto IL_0389;
																																		case 59:
																																		case 85:
																																			goto IL_039c;
																																		case 14:
																																			goto IL_03aa;
																																		case 78:
																																			goto IL_03b8;
																																		case 24:
																																		case 37:
																																			goto IL_03c6;
																																		case 34:
																																		case 95:
																																			goto IL_0408;
																																		case 70:
																																			goto IL_0421;
																																		case 98:
																																			goto IL_0431;
																																		case 23:
																																			goto IL_0445;
																																		case 99:
																																			goto IL_0458;
																																		case 64:
																																			goto IL_046f;
																																		case 105:
																																			goto IL_0482;
																																		case 18:
																																			goto IL_0490;
																																		case 76:
																																			goto IL_049e;
																																		case 89:
																																		case 107:
																																			goto IL_04b1;
																																		case 74:
																																		case 115:
																																			goto IL_04c9;
																																		case 116:
																																			goto IL_04ee;
																																		case 6:
																																		case 81:
																																			goto IL_04fc;
																																		case 117:
																																			goto IL_0518;
																																		case 119:
																																			goto IL_052b;
																																		case 39:
																																		case 54:
																																			goto IL_0536;
																																		case 84:
																																			goto IL_054a;
																																		case 21:
																																			goto IL_05a3;
																																		case 53:
																																			goto IL_05ae;
																																		case 43:
																																			goto IL_05bc;
																																		case 90:
																																			goto IL_05d8;
																																		case 19:
																																		case 82:
																																			goto IL_05e6;
																																		case 120:
																																			goto IL_064d;
																																		case 80:
																																		case 121:
																																			goto IL_0660;
																																		case 11:
																																			goto IL_06a0;
																																		case 57:
																																			goto IL_06b4;
																																		case 123:
																																			goto IL_06c7;
																																		case 109:
																																			goto IL_06d5;
																																		case 124:
																																			goto IL_06e8;
																																		case 71:
																																		case 125:
																																			goto IL_06fb;
																																		case 0:
																																			goto IL_0709;
																																		case 60:
																																		case 92:
																																			goto IL_0717;
																																		case 118:
																																		case 126:
																																			goto IL_072a;
																																		case 66:
																																			goto IL_0738;
																																		case 96:
																																			goto IL_075b;
																																		case 5:
																																			goto IL_0765;
																																		case 8:
																																			goto IL_0773;
																																		case 127:
																																			goto IL_0783;
																																		case 3:
																																		case 4:
																																		case 7:
																																		case 12:
																																		case 22:
																																		case 25:
																																		case 30:
																																		case 31:
																																		case 35:
																																		case 41:
																																		case 65:
																																		case 77:
																																		case 87:
																																		case 91:
																																		case 100:
																																		case 101:
																																		case 104:
																																		case 106:
																																		case 112:
																																		case 113:
																																		case 114:
																																		case 122:
																																		case 128:
																																			goto end_IL_02a4;
																																		case 2:
																																		case 13:
																																		case 17:
																																		case 20:
																																		case 32:
																																		case 33:
																																		case 38:
																																		case 44:
																																		case 45:
																																		case 49:
																																		case 72:
																																		case 79:
																																		case 83:
																																		case 86:
																																		case 108:
																																			goto end_IL_023d;
																																		case 1:
																																			goto end_IL_07b8;
																																		case 26:
																																			goto end_IL_07cb;
																																		case 56:
																																			goto end_IL_07d5;
																																		case 63:
																																			goto end_IL_07e0;
																																		case 36:
																																		case 73:
																																			goto end_IL_07fe;
																																		case 28:
																																			goto end_IL_080e;
																																		case 29:
																																		case 129:
																																			goto end_IL_081e;
																																		case 102:
																																			goto end_IL_082e;
																																		case 103:
																																			goto end_IL_083e;
																																		case 58:
																																		case 62:
																																			goto IL_0859;
																																		}
																																		continue;
																																		end_IL_023d:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_0321;
																														continue;
																														end_IL_02a4:
																														break;
																														IL_02a4:;
																													}
																													break;
																													IL_02b4:;
																												}
																												break;
																											}
																											goto IL_034c;
																											IL_0458:
																											num5++;
																											num = 64;
																											goto IL_046f;
																											IL_046f:
																											ptr2 += 8;
																											goto end_IL_0321;
																											IL_034c:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0408;
																											IL_0408:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0421;
																											IL_0421:
																											array[num5] = 0;
																											goto IL_0458;
																										}
																										break;
																									}
																									goto IL_04b1;
																									IL_04b1:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0321;
																								}
																								break;
																							}
																							goto IL_039c;
																							IL_0773:
																							ptr2 += 8;
																							goto end_IL_0321;
																							IL_039c:
																							if (5 < b)
																							{
																								goto IL_03aa;
																							}
																							goto IL_0482;
																							IL_03aa:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_03b8;
																							IL_03b8:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_03c6;
																							IL_03c6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0431;
																							IL_0431:
																							array[num5 - 2] = 0;
																							goto IL_0445;
																							IL_0445:
																							num5--;
																							goto end_IL_0321;
																							IL_0482:
																							if (5 > b)
																							{
																								goto IL_0490;
																							}
																							goto IL_072a;
																							IL_0490:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_049e;
																							IL_049e:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_0321;
																							IL_072a:
																							array[num5] = 0;
																							goto IL_0738;
																							IL_0738:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_075b;
																							IL_075b:
																							array2[num5] = null;
																							goto IL_0765;
																							IL_0765:
																							num5++;
																							goto IL_0773;
																						}
																						break;
																					}
																					goto IL_04c9;
																					IL_06e8:
																					ptr2 += 8;
																					goto end_IL_0321;
																					IL_04c9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0518;
																					IL_0518:
																					array[num5] = 0;
																					goto IL_064d;
																					IL_064d:
																					num5++;
																					goto IL_06e8;
																				}
																				break;
																			}
																			goto IL_035f;
																			IL_05e6:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0783;
																			IL_035f:
																			if (10 < b)
																			{
																				goto IL_036d;
																			}
																			goto IL_052b;
																			IL_036d:
																			if (12 < b)
																			{
																				goto IL_037b;
																			}
																			goto IL_04ee;
																			IL_037b:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0389;
																			IL_0389:
																			if (13 > b)
																			{
																			}
																			break;
																			IL_04ee:
																			if (12 <= b)
																			{
																				goto IL_04fc;
																			}
																			goto IL_06fb;
																			IL_04fc:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0321;
																			IL_06fb:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0709;
																			IL_0709:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0717;
																			IL_0717:
																			num5--;
																			goto end_IL_0321;
																			IL_052b:
																			if (10 <= b)
																			{
																				goto IL_0536;
																			}
																			goto IL_05a3;
																			IL_0536:
																			array[num5 - 2] = 0;
																			goto IL_054a;
																			IL_054a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)EnumerablePartitionerOptionsProgressNotification[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_06c7;
																			IL_06c7:
																			num5--;
																			goto IL_06d5;
																			IL_06d5:
																			ptr2 += 8;
																			goto end_IL_0321;
																			IL_05a3:
																			if (8 < b)
																			{
																				goto IL_05ae;
																			}
																			num = 90;
																			goto IL_05d8;
																			IL_05ae:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_05bc;
																			IL_05bc:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0660;
																			IL_0660:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06a0;
																			IL_06a0:
																			array[num5 - 2] = 0;
																			goto IL_06b4;
																			IL_06b4:
																			num5--;
																			goto end_IL_0321;
																			IL_0783:
																			num5 -= 2;
																			goto end_IL_0321;
																			IL_05d8:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_05e6;
																		}
																		break;
																		IL_0311:;
																	}
																}
																else
																{
																	num = 87;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 2;
																break;
																continue;
																end_IL_0321:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0859;
												IL_0859:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_07b8:
												break;
											}
											continue;
											end_IL_07cb:
											break;
										}
										continue;
										end_IL_07d5:
										break;
									}
									continue;
									end_IL_07e0:
									break;
								}
								continue;
								end_IL_07fe:
								break;
							}
							continue;
							end_IL_080e:
							break;
						}
						continue;
						end_IL_081e:
						break;
					}
					continue;
					end_IL_082e:
					break;
				}
				continue;
				end_IL_083e:
				break;
			}
		}
	}

	static Class2()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0055:
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 4:
								goto IL_0046;
							case 2:
								goto IL_0055;
							case 3:
								goto end_IL_0039;
							case 1:
								return;
							case 5:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
