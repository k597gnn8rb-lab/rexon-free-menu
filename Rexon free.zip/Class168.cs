using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Rejoin", "Room", "Rejoins the room you're in.", false, 1, ModType.const_1, false)]
internal class Class168 : MonoBehaviour
{
	internal sealed class _003CRejoinRoom_003Ed__1 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int int_0;

		private WaitForSeconds waitForSeconds_0;

		private string string_0;

		private static IntPtr[] ExpiredTrimFlush;

		private static IntPtr[] DefineSequencePointsGetFolderPath;

		object IEnumerator<object>.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		static _003CRejoinRoom_003Ed__1()
		{
			int num = 5;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					IL_0062:
					Class300.smethod_0();
					while (true)
					{
						IL_0056:
						num = 2;
						while (true)
						{
							IL_004a:
							num = 13;
							while (true)
							{
								if (num != 13)
								{
									if (num != 994)
									{
										break;
									}
									switch (num)
									{
									case 2:
										goto IL_004a;
									case 1:
										goto IL_0056;
									case 4:
										goto IL_0062;
									case 5:
										goto end_IL_003d;
									case 0:
										return;
									case 3:
										return;
									case 6:
										return;
									}
									continue;
								}
								return;
								continue;
								end_IL_003d:
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
		}

		unsafe void IEnumerator.Reset()
		{
			int num = 22;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[1];
						while (true)
						{
							object[] array2 = new object[1];
							while (true)
							{
								byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getActivationTypeNameNormalize.ShadowCopyDirectoriesGetGuidArray);
								while (true)
								{
									byte* ptr2 = ptr;
									while (true)
									{
										if (num4 == 1)
										{
											return;
										}
										while (true)
										{
											IL_0141:
											byte b = *ptr2;
											while (true)
											{
												IL_0131:
												ptr2++;
												while (true)
												{
													IL_0124:
													if (b >= 1)
													{
														goto IL_00c6;
													}
													goto IL_010b;
													IL_010b:
													while (true)
													{
														IL_010b_2:
														array[num5] = 5;
														num = 41;
														while (true)
														{
															if (num != 41)
															{
																if (num != 1022)
																{
																	break;
																}
																switch (num)
																{
																case 16:
																	goto IL_00c6;
																case 7:
																	goto IL_00d1;
																case 24:
																	goto IL_00dc;
																case 2:
																	goto IL_00f0;
																case 29:
																	goto IL_0100;
																case 5:
																case 10:
																case 12:
																case 26:
																case 27:
																case 28:
																case 30:
																case 33:
																	goto IL_010b_2;
																case 3:
																	goto IL_0124;
																case 6:
																	goto IL_0131;
																case 9:
																case 23:
																	goto IL_0141;
																case 1:
																	goto IL_016a;
																case 18:
																	goto IL_0178;
																case 15:
																case 20:
																case 31:
																	goto end_IL_00b3;
																case 8:
																	goto end_IL_0186;
																case 13:
																case 14:
																case 19:
																	goto end_IL_0193;
																case 34:
																	goto end_IL_019d;
																case 0:
																case 4:
																	goto end_IL_01a8;
																case 21:
																	goto end_IL_01b8;
																case 22:
																	goto end_IL_01c8;
																case 25:
																case 32:
																	goto IL_01e3;
																case 11:
																case 17:
																	return;
																}
																continue;
															}
															array2[num5] = ((delegate*<NotSupportedException>)DefineSequencePointsGetFolderPath[*(int*)(ptr2 + num3)])();
															goto IL_016a;
															IL_016a:
															num5++;
															goto IL_0178;
															IL_0178:
															ptr2 += 8;
															break;
															continue;
															end_IL_00b3:
															break;
														}
														break;
													}
													break;
													IL_00c6:
													if (b <= 2)
													{
														goto IL_00d1;
													}
													goto IL_010b;
													IL_00d1:
													if (1 < b)
													{
														goto IL_00dc;
													}
													goto IL_0100;
													IL_00dc:
													if (2 >= b)
													{
														num = 2;
														goto IL_00f0;
													}
													goto IL_010b;
													IL_0100:
													if (1 > b)
													{
													}
													goto IL_010b;
													IL_00f0:
													if (2 > b)
													{
														goto IL_010b;
													}
													goto IL_01e3;
													IL_01e3:
													throw (Exception)array2[num5 - 1];
												}
												break;
											}
											break;
										}
										continue;
										end_IL_0186:
										break;
									}
									continue;
									end_IL_0193:
									break;
								}
								continue;
								end_IL_019d:
								break;
							}
							continue;
							end_IL_01a8:
							break;
						}
						continue;
						end_IL_01b8:
						break;
					}
					continue;
					end_IL_01c8:
					break;
				}
			}
		}

		private static Room BltUnGetBaseException()
		{
			return PhotonNetwork.CurrentRoom;
		}

		private static string RethrowBaseOctet(Room room_0)
		{
			return room_0.Name;
		}

		private static string ResolvegetPersist(_003CRejoinRoom_003Ed__1 _003CRejoinRoom_003Ed__1_1)
		{
			return _003CRejoinRoom_003Ed__1_1.string_0;
		}

		private static PhotonNetworkController AllowBracesgetUseSalt()
		{
			return PhotonNetworkController.Instance;
		}

		private static void DivTraceLoggingEventTypes()
		{
			PhotonNetwork.Disconnect();
		}

		private static int LoadWithPartialNameCer(_003CRejoinRoom_003Ed__1 _003CRejoinRoom_003Ed__1_1)
		{
			return _003CRejoinRoom_003Ed__1_1.int_0;
		}

		private static void GetMethodImplementationFlagsFindFirst(PhotonNetworkController photonNetworkController_0, string string_1, JoinType joinType_0)
		{
			photonNetworkController_0.AttemptToJoinSpecificRoom(string_1, joinType_0);
		}

		private unsafe bool MoveNext()
		{
			int num = 3;
			bool result = default(bool);
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 0;
				while (true)
				{
					int num3 = 0;
					while (true)
					{
						num3 = 0;
						while (true)
						{
							if (num3 == 5)
							{
								num = 14;
								while (true)
								{
									if (num != 14)
									{
										if (num != 995)
										{
											break;
										}
										switch (num)
										{
										case 7:
											break;
										default:
											continue;
										case 0:
										case 4:
											goto end_IL_0066;
										case 1:
											goto end_IL_0073;
										case 2:
											goto end_IL_007a;
										case 3:
											goto end_IL_007f;
										case 5:
										case 6:
											goto IL_008c;
										}
										goto IL_000b;
									}
									num3 = 0;
									goto IL_008c;
									IL_008c:
									return result;
									continue;
									end_IL_0066:
									break;
								}
								continue;
							}
							goto IL_000b;
							IL_000b:
							result = ((delegate*<ref int, ref int, ref int, ref int, _003CRejoinRoom_003Ed__1, bool>)ExpiredTrimFlush[num2])(ref num2, ref num3, ref num4, ref num5, this);
							continue;
							end_IL_0073:
							break;
						}
						continue;
						end_IL_007a:
						break;
					}
					continue;
					end_IL_007f:
					break;
				}
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		public _003CRejoinRoom_003Ed__1(int _003C_003E1__state)
		{
			object obj = this;
			((_003CRejoinRoom_003Ed__1)obj).int_0 = _003C_003E1__state;
		}

		private static WaitForSeconds LocalVariablesGetConstantValue(float float_0)
		{
			return new WaitForSeconds(float_0);
		}

		unsafe void IDisposable.Dispose()
		{
			int num = 27;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[3];
						num = 63;
						while (true)
						{
							IL_04b8:
							object[] array2 = new object[3];
							while (true)
							{
								IL_04a8:
								long[] array3 = new long[3];
								while (true)
								{
									IL_0498:
									object[] array4 = new object[1];
									while (true)
									{
										IL_0488:
										array4[0] = this;
										while (true)
										{
											IL_047d:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TaskScheduledPeref.DefaultInvariantReadToEnd);
											while (true)
											{
												IL_0473:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0468:
													num = 22;
													while (true)
													{
														IL_0455:
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															IL_0220:
															byte b = *ptr2;
															while (true)
															{
																IL_0210:
																ptr2++;
																while (true)
																{
																	IL_0200:
																	if (b >= 1)
																	{
																		while (b <= 7)
																		{
																			while (true)
																			{
																				IL_01e0:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01d3:
																						if (4 <= b)
																						{
																							while (true)
																							{
																								IL_01af:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(int*)(ptr2 + num3);
																								num = 15;
																								while (true)
																								{
																									IL_019f:
																									array[num5] = 0;
																									while (true)
																									{
																										IL_0186:
																										num5++;
																										num = 89;
																										while (true)
																										{
																											if (num != 89)
																											{
																												if (num != 1070)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 36:
																													goto IL_0186;
																												case 15:
																													goto IL_019f;
																												case 2:
																												case 33:
																													goto IL_01af;
																												case 28:
																													goto IL_01d3;
																												case 50:
																													goto IL_01e0;
																												case 76:
																													goto IL_01f0;
																												case 65:
																													goto IL_0200;
																												case 38:
																													goto IL_0210;
																												case 17:
																												case 31:
																													goto IL_0220;
																												case 0:
																												case 37:
																													goto IL_022b;
																												case 32:
																													goto IL_0236;
																												case 25:
																													goto IL_0244;
																												case 41:
																													goto IL_0254;
																												case 23:
																													goto IL_025f;
																												case 20:
																												case 58:
																													goto IL_026f;
																												case 5:
																													goto IL_0279;
																												case 68:
																													goto IL_0287;
																												case 51:
																												case 73:
																													goto IL_029a;
																												case 52:
																													goto IL_02c2;
																												case 74:
																													goto IL_02d5;
																												case 66:
																												case 81:
																													goto IL_02e8;
																												case 39:
																												case 71:
																													goto IL_02f3;
																												case 47:
																													goto IL_0301;
																												case 11:
																												case 80:
																													goto IL_030f;
																												case 44:
																													goto IL_032b;
																												case 18:
																												case 64:
																													goto IL_0339;
																												case 54:
																													goto IL_0347;
																												case 35:
																												case 62:
																													goto IL_0355;
																												case 9:
																													goto IL_0395;
																												case 78:
																													goto IL_03a9;
																												case 43:
																												case 59:
																													goto IL_03bc;
																												case 4:
																													goto IL_03f3;
																												case 1:
																												case 6:
																												case 7:
																												case 8:
																												case 12:
																												case 13:
																												case 40:
																												case 42:
																												case 46:
																												case 48:
																												case 53:
																												case 55:
																												case 69:
																												case 75:
																												case 82:
																													goto end_IL_01f0;
																												case 29:
																													goto IL_042b;
																												case 60:
																													goto IL_0439;
																												case 49:
																													goto IL_0447;
																												case 10:
																												case 14:
																												case 16:
																												case 19:
																												case 21:
																												case 22:
																												case 57:
																												case 77:
																													goto IL_0455;
																												case 24:
																													goto IL_0468;
																												case 67:
																													goto IL_0473;
																												case 45:
																													goto IL_047d;
																												case 70:
																													goto IL_0488;
																												case 30:
																													goto IL_0498;
																												case 34:
																												case 56:
																													goto IL_04a8;
																												case 63:
																													goto IL_04b8;
																												case 61:
																												case 72:
																													goto end_IL_0173;
																												case 26:
																													goto end_IL_04c8;
																												case 27:
																													goto end_IL_04e1;
																												case 3:
																												case 79:
																													return;
																												}
																												continue;
																											}
																											ptr2 += 8;
																											goto IL_0455;
																											continue;
																											end_IL_0173:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_022b;
																						IL_0287:
																						num5++;
																						goto IL_0455;
																						IL_022b:
																						if (2 < b)
																						{
																							goto IL_0236;
																						}
																						goto IL_0254;
																						IL_0236:
																						if (3 < b)
																						{
																							goto end_IL_01f0;
																						}
																						goto IL_0244;
																						IL_0244:
																						if (3 > b)
																						{
																							goto end_IL_01f0;
																						}
																						goto IL_029a;
																						IL_029a:
																						((_003CRejoinRoom_003Ed__1)array2[num5 - 2]).string_0 = (string)array2[num5 - 1];
																						goto IL_02c2;
																						IL_02c2:
																						num5 -= 2;
																						goto IL_0455;
																						IL_0254:
																						if (2 > b)
																						{
																							goto IL_025f;
																						}
																						goto IL_026f;
																						IL_025f:
																						if (1 < b)
																						{
																							goto end_IL_01f0;
																						}
																						goto IL_02d5;
																						IL_02d5:
																						if (1 > b)
																						{
																						}
																						goto end_IL_01f0;
																						IL_026f:
																						array2[num5] = null;
																						goto IL_0279;
																						IL_0279:
																						array[num5] = 5;
																						goto IL_0287;
																					}
																					break;
																				}
																				goto IL_02e8;
																				IL_03f3:
																				num5 -= 2;
																				goto IL_0455;
																				IL_02e8:
																				if (6 < b)
																				{
																					goto IL_02f3;
																				}
																				goto IL_032b;
																				IL_02f3:
																				if (7 < b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_0301;
																				IL_0301:
																				if (7 > b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_030f;
																				IL_030f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_0455;
																				IL_032b:
																				if (6 > b)
																				{
																					goto IL_0339;
																				}
																				goto IL_03bc;
																				IL_0339:
																				if (5 < b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_0347;
																				IL_0347:
																				if (5 > b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_0355;
																				IL_0355:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																				goto IL_0395;
																				IL_0395:
																				array[num5 - 2] = 0;
																				goto IL_03a9;
																				IL_03a9:
																				num5--;
																				goto IL_0455;
																				IL_03bc:
																				((_003CRejoinRoom_003Ed__1)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																				num = 4;
																				goto IL_03f3;
																			}
																			goto end_IL_0200;
																			continue;
																			end_IL_01f0:
																			break;
																			IL_01f0:;
																		}
																	}
																	array2[num5] = array4[*(int*)(ptr2 + num3)];
																	goto IL_042b;
																	IL_0447:
																	ptr2 += 8;
																	goto IL_0455;
																	IL_0439:
																	num5++;
																	goto IL_0447;
																	IL_042b:
																	array[num5] = 5;
																	goto IL_0439;
																	continue;
																	end_IL_0200:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_04c8:
						break;
					}
					continue;
					end_IL_04e1:
					break;
				}
			}
		}
	}

	private static bool bool_0;

	private static int int_0;

	private static float float_0;

	private static int int_1;

	private static IntPtr[] EventRegistrationTokenListIsUnicodeClass;

	private static IntPtr[] getOriginalIssuerscale;

	private static IntPtr[] FormIdnaDisallowUnassignedTAIWANLUNISOLAR;

	private static IntPtr[] getOriginalIssuerGetSymAttribute;

	private unsafe void OnEnable()
	{
		int num = 11;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetCountSafesetPrimaryIdentitySelector.DependentOSMetadataBuildNumberRequireWaitNotification);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_03d8:
																if (b >= 1)
																{
																	while (b <= 20)
																	{
																		while (true)
																		{
																			IL_03b8:
																			if (10 < b)
																			{
																				while (true)
																				{
																					IL_03a8:
																					if (15 < b)
																					{
																						while (true)
																						{
																							IL_0398:
																							if (18 >= b)
																							{
																								while (true)
																								{
																									IL_038b:
																									if (18 > b)
																									{
																										while (true)
																										{
																											IL_037b:
																											if (16 < b)
																											{
																												while (17 >= b)
																												{
																													num = 206;
																													while (true)
																													{
																														if (num != 206)
																														{
																															if (num != 1187)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 94:
																															case 99:
																																goto IL_0368;
																															case 155:
																																goto IL_037b;
																															case 169:
																																goto IL_038b;
																															case 26:
																															case 125:
																																goto IL_0398;
																															case 83:
																															case 104:
																																goto IL_03a8;
																															case 90:
																																goto IL_03b8;
																															case 6:
																																goto IL_03c8;
																															case 33:
																																goto IL_03d8;
																															case 37:
																																goto end_IL_03d8;
																															case 27:
																															case 142:
																																goto end_IL_03e8;
																															case 82:
																															case 179:
																																goto IL_0403;
																															case 181:
																																goto IL_0417;
																															case 89:
																																goto IL_0463;
																															case 191:
																																goto IL_0471;
																															case 46:
																															case 141:
																																goto IL_0492;
																															case 57:
																																goto IL_04a6;
																															case 119:
																																goto IL_04de;
																															case 180:
																																goto IL_04f1;
																															case 91:
																															case 176:
																																goto IL_04ff;
																															case 165:
																																goto IL_0517;
																															case 166:
																																goto IL_0525;
																															case 147:
																																goto IL_0533;
																															case 88:
																															case 183:
																																goto IL_0546;
																															case 150:
																																goto IL_0551;
																															case 1:
																																goto IL_055f;
																															case 124:
																																goto IL_0572;
																															case 114:
																															case 156:
																																goto IL_0589;
																															case 149:
																																goto IL_05a5;
																															case 20:
																															case 108:
																																goto IL_05b3;
																															case 172:
																																goto IL_05c1;
																															case 45:
																																goto IL_05cc;
																															case 36:
																																goto IL_05da;
																															case 170:
																															case 192:
																																goto IL_05e8;
																															case 100:
																																goto IL_05f6;
																															case 118:
																																goto IL_061a;
																															case 28:
																																goto IL_0628;
																															case 12:
																																goto IL_0649;
																															case 95:
																															case 187:
																																goto IL_0657;
																															case 18:
																																goto IL_066e;
																															case 29:
																															case 178:
																																goto IL_067c;
																															case 194:
																																goto end_IL_0355;
																															case 133:
																																goto IL_06e1;
																															case 48:
																															case 76:
																																goto IL_06ef;
																															case 175:
																																goto IL_06fd;
																															case 17:
																																goto IL_0721;
																															case 185:
																																goto IL_0738;
																															case 35:
																															case 105:
																																goto IL_074b;
																															case 43:
																																goto IL_0759;
																															case 15:
																																goto IL_0777;
																															case 31:
																																goto IL_0785;
																															case 13:
																																goto IL_0798;
																															case 25:
																															case 126:
																																goto IL_07a6;
																															case 62:
																																goto IL_07b4;
																															case 159:
																																goto IL_07c2;
																															case 65:
																																goto IL_07d0;
																															case 136:
																																goto IL_07de;
																															case 81:
																															case 151:
																																goto IL_07ec;
																															case 135:
																																goto IL_082c;
																															case 188:
																																goto IL_0840;
																															case 8:
																															case 121:
																																goto IL_0853;
																															case 67:
																																goto IL_0893;
																															case 173:
																																goto IL_08a7;
																															case 55:
																															case 145:
																																goto IL_08c3;
																															case 153:
																																goto IL_08ce;
																															case 148:
																															case 167:
																																goto IL_08dc;
																															case 157:
																																goto IL_08f8;
																															case 189:
																																goto IL_0906;
																															case 143:
																															case 163:
																																goto IL_0914;
																															case 112:
																																goto IL_0954;
																															case 140:
																																goto IL_0968;
																															case 34:
																																goto IL_097b;
																															case 96:
																															case 110:
																																goto IL_0989;
																															case 19:
																																goto IL_0997;
																															case 53:
																															case 92:
																																goto IL_09a2;
																															case 127:
																																goto IL_09e2;
																															case 116:
																																goto IL_09f6;
																															case 111:
																																goto IL_0a09;
																															case 47:
																																goto IL_0a20;
																															case 61:
																															case 138:
																																goto IL_0a2e;
																															case 44:
																																goto IL_0a47;
																															case 71:
																																goto IL_0a55;
																															case 58:
																																goto IL_0a63;
																															case 3:
																																goto IL_0a76;
																															case 56:
																															case 97:
																																goto IL_0a84;
																															case 174:
																																goto IL_0a92;
																															case 75:
																															case 93:
																																goto IL_0aa9;
																															case 152:
																																goto IL_0ab7;
																															case 98:
																																goto IL_0ada;
																															case 5:
																																goto IL_0ae4;
																															case 7:
																																goto IL_0af2;
																															case 139:
																																goto IL_0b05;
																															case 2:
																															case 131:
																																goto IL_0b10;
																															case 60:
																																goto IL_0b39;
																															case 137:
																																goto IL_0b47;
																															case 22:
																															case 120:
																																goto IL_0b68;
																															case 50:
																																goto IL_0ba8;
																															case 63:
																																goto IL_0bbc;
																															case 9:
																															case 129:
																																goto IL_0bd8;
																															case 87:
																																goto IL_0c3a;
																															case 0:
																															case 4:
																															case 14:
																															case 16:
																															case 30:
																															case 39:
																															case 40:
																															case 41:
																															case 42:
																															case 51:
																															case 66:
																															case 69:
																															case 70:
																															case 73:
																															case 77:
																															case 86:
																															case 106:
																															case 107:
																															case 109:
																															case 117:
																															case 130:
																															case 144:
																															case 146:
																															case 158:
																															case 161:
																															case 164:
																															case 168:
																															case 177:
																															case 182:
																															case 186:
																															case 190:
																															case 195:
																															case 196:
																															case 197:
																															case 199:
																																goto end_IL_0368;
																															case 21:
																															case 23:
																															case 32:
																															case 38:
																															case 49:
																															case 52:
																															case 54:
																															case 59:
																															case 68:
																															case 72:
																															case 74:
																															case 78:
																															case 84:
																															case 85:
																															case 101:
																															case 102:
																															case 115:
																															case 134:
																															case 162:
																															case 171:
																															case 184:
																															case 193:
																															case 198:
																																goto end_IL_03f8;
																															case 103:
																																goto end_IL_0c5d;
																															case 132:
																																goto end_IL_0c70;
																															case 79:
																																goto end_IL_0c7a;
																															case 128:
																																goto end_IL_0c85;
																															case 123:
																																goto end_IL_0c95;
																															case 24:
																															case 154:
																																goto end_IL_0ca5;
																															case 64:
																																goto end_IL_0cb5;
																															case 80:
																															case 113:
																																goto end_IL_0cc5;
																															case 10:
																																goto end_IL_0cd5;
																															case 11:
																																goto end_IL_0ce5;
																															case 122:
																															case 160:
																																return;
																															}
																															continue;
																														}
																														if (17 > b)
																														{
																															goto end_IL_0368;
																														}
																														goto IL_0492;
																														IL_0492:
																														array[num5 - 1] = 5;
																														goto IL_04a6;
																														IL_04de:
																														ptr2 += 8;
																														goto end_IL_03f8;
																														IL_04a6:
																														array2[num5 - 1] = ((delegate*<Class168, IEnumerator>)EventRegistrationTokenListIsUnicodeClass[*(int*)(ptr2 + num3)])((Class168)array2[num5 - 1]);
																														goto IL_04de;
																														continue;
																														end_IL_0355:
																														break;
																													}
																													goto IL_06ce;
																													continue;
																													end_IL_0368:
																													break;
																													IL_0368:;
																												}
																												break;
																											}
																											goto IL_04f1;
																											IL_0533:
																											ptr2 += 8;
																											goto end_IL_03f8;
																											IL_04f1:
																											if (16 > b)
																											{
																												break;
																											}
																											goto IL_04ff;
																											IL_04ff:
																											array2[num5] = array5[*(int*)(ptr2 + num3)];
																											goto IL_0517;
																											IL_0517:
																											array[num5] = 5;
																											goto IL_0525;
																											IL_0525:
																											num5++;
																											goto IL_0533;
																										}
																										break;
																									}
																									goto IL_0403;
																									IL_0471:
																									ptr2 += 8;
																									goto end_IL_03f8;
																									IL_0403:
																									array[num5 - 2] = 5;
																									goto IL_0417;
																									IL_0417:
																									array2[num5 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)EventRegistrationTokenListIsUnicodeClass[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (IEnumerator)array2[num5 - 1]);
																									goto IL_0463;
																									IL_0463:
																									num5--;
																									goto IL_0471;
																								}
																								break;
																							}
																							goto IL_0546;
																							IL_0589:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_03f8;
																							IL_0546:
																							if (19 < b)
																							{
																								goto IL_0551;
																							}
																							goto IL_0572;
																							IL_0551:
																							if (20 < b)
																							{
																								break;
																							}
																							goto IL_055f;
																							IL_055f:
																							if (20 > b)
																							{
																							}
																							break;
																							IL_0572:
																							if (19 > b)
																							{
																								break;
																							}
																							num = 114;
																							goto IL_0589;
																						}
																						break;
																					}
																					goto IL_05a5;
																					IL_0759:
																					array2[num5] = ((delegate*<GorillaTagger>)EventRegistrationTokenListIsUnicodeClass[*(int*)(ptr2 + num3)])();
																					goto IL_0777;
																					IL_05a5:
																					if (15 > b)
																					{
																						goto IL_05b3;
																					}
																					goto IL_074b;
																					IL_05b3:
																					if (12 >= b)
																					{
																						goto IL_05c1;
																					}
																					goto IL_0649;
																					IL_05c1:
																					if (12 <= b)
																					{
																						num = 23;
																						goto end_IL_03f8;
																					}
																					goto IL_05cc;
																					IL_05cc:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_05da;
																					IL_05da:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_05e8;
																					IL_05e8:
																					array[num5] = 0;
																					goto IL_05f6;
																					IL_05f6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)EventRegistrationTokenListIsUnicodeClass[*(int*)(ptr2 + num3)])();
																					goto IL_061a;
																					IL_061a:
																					num5++;
																					goto IL_0628;
																					IL_0628:
																					ptr2 += 8;
																					goto end_IL_03f8;
																					IL_0777:
																					num5++;
																					goto IL_0785;
																					IL_0649:
																					if (13 < b)
																					{
																						goto IL_0657;
																					}
																					goto IL_06e1;
																					IL_0657:
																					if (14 < b)
																					{
																						break;
																					}
																					num = 18;
																					goto IL_066e;
																					IL_0785:
																					ptr2 += 8;
																					goto end_IL_03f8;
																					IL_066e:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_067c;
																					IL_067c:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_06ce;
																					IL_06ce:
																					num5--;
																					goto end_IL_03f8;
																					IL_06e1:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_06ef;
																					IL_06ef:
																					array[num5] = 0;
																					goto IL_06fd;
																					IL_06fd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)EventRegistrationTokenListIsUnicodeClass[*(int*)(ptr2 + num3)])() ? 1 : 0);
																					goto IL_0721;
																					IL_0721:
																					num5++;
																					num = 185;
																					goto IL_0738;
																					IL_0738:
																					ptr2 += 8;
																					goto end_IL_03f8;
																					IL_074b:
																					array[num5] = 5;
																					goto IL_0759;
																				}
																				break;
																			}
																			goto IL_0798;
																			IL_0ba8:
																			array[num5 - 2] = 0;
																			goto IL_0bbc;
																			IL_0798:
																			if (10 > b)
																			{
																				goto IL_07a6;
																			}
																			goto IL_0bd8;
																			IL_07a6:
																			if (5 < b)
																			{
																				goto IL_07b4;
																			}
																			goto IL_097b;
																			IL_07b4:
																			if (7 >= b)
																			{
																				goto IL_07c2;
																			}
																			goto IL_08c3;
																			IL_07c2:
																			if (7 > b)
																			{
																				goto IL_07d0;
																			}
																			goto IL_0853;
																			IL_07d0:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_07de;
																			IL_07de:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_07ec;
																			IL_07ec:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_082c;
																			IL_082c:
																			array[num5 - 2] = 0;
																			goto IL_0840;
																			IL_0840:
																			num5--;
																			goto end_IL_03f8;
																			IL_0853:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0893;
																			IL_0893:
																			array[num5 - 2] = 0;
																			goto IL_08a7;
																			IL_08a7:
																			num5--;
																			num = 184;
																			goto end_IL_03f8;
																			IL_08c3:
																			if (8 >= b)
																			{
																				goto IL_08ce;
																			}
																			goto IL_08f8;
																			IL_08ce:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_08dc;
																			IL_08dc:
																			num5--;
																			num = 101;
																			goto end_IL_03f8;
																			IL_08f8:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0906;
																			IL_0906:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0914;
																			IL_0914:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0954;
																			IL_0954:
																			array[num5 - 2] = 0;
																			goto IL_0968;
																			IL_0968:
																			num5--;
																			goto end_IL_03f8;
																			IL_097b:
																			if (5 > b)
																			{
																				goto IL_0989;
																			}
																			goto IL_0b68;
																			IL_0989:
																			if (2 >= b)
																			{
																				goto IL_0997;
																			}
																			goto IL_0a76;
																			IL_0997:
																			if (2 <= b)
																			{
																				goto IL_09a2;
																			}
																			goto IL_0a09;
																			IL_09a2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_09e2;
																			IL_09e2:
																			array[num5 - 2] = 0;
																			goto IL_09f6;
																			IL_09f6:
																			num5--;
																			goto end_IL_03f8;
																			IL_0a09:
																			if (1 < b)
																			{
																				break;
																			}
																			num = 47;
																			goto IL_0a20;
																			IL_0bbc:
																			num5--;
																			num = 52;
																			goto end_IL_03f8;
																			IL_0a20:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0a2e;
																			IL_0a2e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0a47;
																			IL_0a47:
																			array[num5] = 0;
																			goto IL_0a55;
																			IL_0a55:
																			num5++;
																			goto IL_0a63;
																			IL_0a63:
																			ptr2 += 8;
																			goto end_IL_03f8;
																			IL_0a76:
																			if (3 < b)
																			{
																				goto IL_0a84;
																			}
																			goto IL_0b05;
																			IL_0a84:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0a92;
																			IL_0a92:
																			if (4 > b)
																			{
																				break;
																			}
																			num = 93;
																			goto IL_0aa9;
																			IL_0bd8:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0c3a;
																			IL_0aa9:
																			array[num5] = 0;
																			goto IL_0ab7;
																			IL_0ab7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0ada;
																			IL_0ada:
																			array2[num5] = null;
																			goto IL_0ae4;
																			IL_0ae4:
																			num5++;
																			goto IL_0af2;
																			IL_0af2:
																			ptr2 += 8;
																			goto end_IL_03f8;
																			IL_0b05:
																			if (3 > b)
																			{
																				num = 73;
																				break;
																			}
																			goto IL_0b10;
																			IL_0b10:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0b39;
																			IL_0b39:
																			ptr2 += 8;
																			goto IL_0b47;
																			IL_0b47:
																			num5--;
																			goto end_IL_03f8;
																			IL_0c3a:
																			num5 -= 2;
																			goto end_IL_03f8;
																			IL_0b68:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0ba8;
																		}
																		break;
																		IL_03c8:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_03f8;
																continue;
																end_IL_03d8:
																break;
															}
															continue;
															end_IL_03e8:
															break;
														}
														continue;
														end_IL_03f8:
														break;
													}
													continue;
													end_IL_0c5d:
													break;
												}
												continue;
												end_IL_0c70:
												break;
											}
											continue;
											end_IL_0c7a:
											break;
										}
										continue;
										end_IL_0c85:
										break;
									}
									continue;
									end_IL_0c95:
									break;
								}
								continue;
								end_IL_0ca5:
								break;
							}
							continue;
							end_IL_0cb5:
							break;
						}
						continue;
						end_IL_0cc5:
						break;
					}
					continue;
					end_IL_0cd5:
					break;
				}
				continue;
				end_IL_0ce5:
				break;
			}
		}
	}

	private IEnumerator method_0()
	{
		_003CRejoinRoom_003Ed__1 _003CRejoinRoom_003Ed__ = new _003CRejoinRoom_003Ed__1(0);
		return _003CRejoinRoom_003Ed__;
	}

	public Class168()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 24;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 91;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setCurrentDirectoryMuiResourceTypeIdStringIntegerIdsSize.ByteTokenEncodingSoapBaseBinary);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0267:
																	if (b >= 1)
																	{
																		num = 15;
																		while (b <= 11)
																		{
																			num = 11;
																			while (true)
																			{
																				IL_0247:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0237:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0224:
																								if (3 >= b)
																								{
																									num = 118;
																									while (true)
																									{
																										if (num != 118)
																										{
																											if (num != 1099)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 2:
																												goto IL_0224;
																											case 70:
																												goto IL_0237;
																											case 11:
																												goto IL_0247;
																											case 15:
																												goto end_IL_0247;
																											case 99:
																												goto IL_0267;
																											case 77:
																												goto end_IL_0267;
																											case 29:
																											case 104:
																												goto end_IL_027a;
																											case 3:
																											case 5:
																												goto IL_029e;
																											case 12:
																											case 33:
																												goto IL_02ac;
																											case 7:
																												goto IL_02b7;
																											case 36:
																											case 45:
																												goto IL_02c7;
																											case 22:
																												goto IL_02d5;
																											case 42:
																											case 64:
																												goto IL_02e8;
																											case 69:
																												goto IL_0304;
																											case 25:
																												goto IL_030f;
																											case 92:
																												goto IL_0322;
																											case 98:
																												goto IL_0335;
																											case 17:
																												goto IL_0343;
																											case 31:
																												goto IL_034e;
																											case 19:
																											case 32:
																												goto IL_035c;
																											case 60:
																												goto IL_039c;
																											case 68:
																												goto IL_03b0;
																											case 26:
																												goto IL_03c3;
																											case 27:
																												goto IL_03d1;
																											case 84:
																											case 95:
																												goto IL_03dc;
																											case 0:
																												goto IL_03ff;
																											case 63:
																												goto IL_040d;
																											case 13:
																												goto IL_041b;
																											case 28:
																											case 93:
																												goto end_IL_0211;
																											case 105:
																												goto IL_04a7;
																											case 106:
																												goto IL_04ba;
																											case 30:
																											case 88:
																												goto IL_04c8;
																											case 102:
																												goto IL_04d6;
																											case 9:
																												goto IL_04f9;
																											case 81:
																												goto IL_050c;
																											case 85:
																												goto IL_051a;
																											case 52:
																												goto IL_053b;
																											case 79:
																												goto IL_0546;
																											case 37:
																											case 56:
																												goto IL_0554;
																											case 39:
																												goto IL_056d;
																											case 10:
																												goto IL_0584;
																											case 8:
																												goto IL_0592;
																											case 86:
																												goto IL_05a5;
																											case 55:
																												goto IL_05b3;
																											case 61:
																											case 100:
																												goto IL_05c1;
																											case 89:
																												goto IL_05ea;
																											case 34:
																												goto IL_05f8;
																											case 47:
																											case 58:
																												goto IL_0614;
																											case 62:
																											case 90:
																												goto IL_0629;
																											case 41:
																												goto IL_0669;
																											case 46:
																												goto IL_067d;
																											case 1:
																											case 6:
																											case 16:
																											case 21:
																											case 48:
																											case 49:
																											case 53:
																											case 59:
																											case 65:
																											case 66:
																											case 67:
																											case 71:
																											case 75:
																											case 76:
																											case 78:
																											case 83:
																											case 96:
																											case 101:
																											case 107:
																											case 108:
																											case 109:
																												goto end_IL_0254;
																											case 4:
																											case 14:
																											case 18:
																											case 20:
																											case 38:
																											case 40:
																											case 43:
																											case 50:
																											case 51:
																											case 72:
																											case 80:
																											case 82:
																											case 97:
																											case 110:
																												goto end_IL_028a;
																											case 111:
																												goto end_IL_06a0;
																											case 35:
																												goto end_IL_06b3;
																											case 54:
																												goto end_IL_06bd;
																											case 44:
																												goto end_IL_06c8;
																											case 57:
																											case 103:
																												goto end_IL_06dd;
																											case 87:
																												goto end_IL_06ed;
																											case 91:
																												goto end_IL_06fd;
																											case 73:
																												goto end_IL_070d;
																											case 23:
																												goto end_IL_071d;
																											case 24:
																												goto end_IL_0728;
																											case 74:
																											case 94:
																												goto IL_0743;
																											}
																											continue;
																										}
																										if (3 > b)
																										{
																											goto IL_053b;
																										}
																										num = 58;
																										goto IL_0614;
																										IL_05ea:
																										ptr2 += 8;
																										goto IL_05f8;
																										IL_0614:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_028a;
																										IL_05f8:
																										num5--;
																										goto end_IL_028a;
																										IL_053b:
																										if (1 >= b)
																										{
																											goto IL_0546;
																										}
																										goto IL_05a5;
																										IL_0546:
																										if (1 > b)
																										{
																											goto end_IL_0254;
																										}
																										goto IL_0554;
																										IL_0554:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_056d;
																										IL_056d:
																										array[num5] = 0;
																										num = 10;
																										goto IL_0584;
																										IL_0584:
																										num5++;
																										goto IL_0592;
																										IL_0592:
																										ptr2 += 8;
																										goto end_IL_028a;
																										IL_05a5:
																										if (2 < b)
																										{
																											goto end_IL_0254;
																										}
																										goto IL_05b3;
																										IL_05b3:
																										if (2 > b)
																										{
																											goto end_IL_0254;
																										}
																										goto IL_05c1;
																										IL_05c1:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_05ea;
																										continue;
																										end_IL_0211:
																										break;
																									}
																									break;
																								}
																								goto IL_0304;
																								IL_050c:
																								num5++;
																								goto IL_051a;
																								IL_051a:
																								ptr2 += 8;
																								goto end_IL_028a;
																								IL_0304:
																								if (4 >= b)
																								{
																									goto IL_030f;
																								}
																								goto IL_0322;
																								IL_030f:
																								if (4 > b)
																								{
																									goto end_IL_0254;
																								}
																								goto end_IL_028a;
																								IL_0322:
																								if (5 < b)
																								{
																									goto end_IL_0254;
																								}
																								goto IL_04ba;
																								IL_04ba:
																								if (5 > b)
																								{
																									goto end_IL_0254;
																								}
																								goto IL_04c8;
																								IL_04c8:
																								array[num5] = 0;
																								goto IL_04d6;
																								IL_04d6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_04f9;
																								IL_04f9:
																								array2[num5] = null;
																								num = 81;
																								goto IL_050c;
																							}
																							break;
																						}
																						goto IL_0629;
																						IL_067d:
																						num5--;
																						goto end_IL_028a;
																						IL_0629:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0669;
																						IL_0669:
																						array[num5 - 2] = 0;
																						goto IL_067d;
																					}
																					goto IL_043c;
																				}
																				num = 5;
																				goto IL_029e;
																				IL_04a7:
																				num5 -= 2;
																				goto end_IL_028a;
																				IL_043c:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 105;
																				goto IL_04a7;
																				IL_029e:
																				if (9 < b)
																				{
																					goto IL_02ac;
																				}
																				goto IL_0335;
																				IL_02ac:
																				if (10 >= b)
																				{
																					goto IL_02b7;
																				}
																				goto IL_02c7;
																				IL_02b7:
																				if (10 > b)
																				{
																					goto end_IL_0254;
																				}
																				goto IL_02e8;
																				IL_02e8:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_028a;
																				IL_02c7:
																				if (11 < b)
																				{
																					goto end_IL_0254;
																				}
																				goto IL_02d5;
																				IL_02d5:
																				if (11 > b)
																				{
																				}
																				goto end_IL_0254;
																				IL_0335:
																				if (9 > b)
																				{
																					goto IL_0343;
																				}
																				goto IL_043c;
																				IL_0343:
																				if (7 >= b)
																				{
																					goto IL_034e;
																				}
																				goto IL_03c3;
																				IL_034e:
																				if (7 > b)
																				{
																					goto end_IL_0254;
																				}
																				goto IL_035c;
																				IL_035c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_039c;
																				IL_039c:
																				array[num5 - 2] = 0;
																				goto IL_03b0;
																				IL_03b0:
																				num5--;
																				goto end_IL_028a;
																				IL_03c3:
																				if (8 < b)
																				{
																					goto end_IL_0254;
																				}
																				goto IL_03d1;
																				IL_03d1:
																				if (8 > b)
																				{
																					num = 108;
																					goto end_IL_0254;
																				}
																				goto IL_03dc;
																				IL_03dc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03ff;
																				IL_03ff:
																				array[num5] = 0;
																				goto IL_040d;
																				IL_040d:
																				num5++;
																				goto IL_041b;
																				IL_041b:
																				ptr2 += 8;
																				goto end_IL_028a;
																				continue;
																				end_IL_0247:
																				break;
																			}
																			continue;
																			end_IL_0254:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_028a;
																	continue;
																	end_IL_0267:
																	break;
																}
																continue;
																end_IL_027a:
																break;
															}
															continue;
															end_IL_028a:
															break;
														}
														continue;
													}
													goto IL_0743;
													IL_0743:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_06a0:
													break;
												}
												continue;
												end_IL_06b3:
												break;
											}
											continue;
											end_IL_06bd:
											break;
										}
										continue;
										end_IL_06c8:
										break;
									}
									continue;
									end_IL_06dd:
									break;
								}
								continue;
								end_IL_06ed:
								break;
							}
							continue;
							end_IL_06fd:
							break;
						}
						continue;
						end_IL_070d:
						break;
					}
					continue;
					end_IL_071d:
					break;
				}
				continue;
				end_IL_0728:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 11;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							num = 111;
							while (true)
							{
								long[] array4 = new long[4];
								num = 15;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AdapterMethodAccessException.EmptyStructIsThreadOwnerTrackingEnabled);
										num = 76;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d0:
														byte b = *ptr2;
														while (true)
														{
															IL_02c0:
															ptr2++;
															while (true)
															{
																IL_02b0:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0293:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_0283:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0273:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0263:
																									if (5 >= b)
																									{
																										while (true)
																										{
																											IL_0250:
																											if (5 <= b)
																											{
																												num = 136;
																												while (true)
																												{
																													if (num != 136)
																													{
																														if (num != 1117)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 69:
																															goto IL_0250;
																														case 34:
																														case 70:
																															goto IL_0263;
																														case 104:
																															goto IL_0273;
																														case 88:
																															goto IL_0283;
																														case 92:
																															goto IL_0293;
																														case 21:
																															goto IL_02a0;
																														case 98:
																															goto IL_02b0;
																														case 121:
																															goto IL_02c0;
																														case 30:
																														case 64:
																															goto IL_02d0;
																														case 27:
																															goto IL_02db;
																														case 45:
																															goto IL_02e9;
																														case 68:
																															goto IL_02f9;
																														case 18:
																															goto IL_0307;
																														case 47:
																														case 84:
																															goto IL_031a;
																														case 74:
																														case 86:
																															goto IL_0342;
																														case 39:
																															goto IL_0356;
																														case 33:
																															goto IL_03aa;
																														case 67:
																															goto IL_03b8;
																														case 49:
																														case 90:
																															goto IL_03cb;
																														case 1:
																															goto IL_03d9;
																														case 80:
																														case 89:
																															goto IL_03e7;
																														case 93:
																															goto IL_042c;
																														case 58:
																															goto IL_043a;
																														case 24:
																														case 71:
																															goto IL_0448;
																														case 9:
																															goto IL_04aa;
																														case 95:
																															goto IL_04bd;
																														case 23:
																															goto IL_04d1;
																														case 20:
																														case 116:
																															goto IL_04e4;
																														case 59:
																														case 73:
																															goto IL_04ef;
																														case 44:
																															goto IL_04fd;
																														case 81:
																															goto IL_0510;
																														case 2:
																															goto IL_051e;
																														case 17:
																															goto IL_052c;
																														case 40:
																														case 117:
																															goto IL_053f;
																														case 118:
																															goto IL_054d;
																														case 28:
																														case 38:
																															goto IL_055b;
																														case 32:
																															goto IL_05a4;
																														case 115:
																															goto IL_05b8;
																														case 125:
																															goto IL_05cb;
																														case 101:
																															goto IL_05d9;
																														case 12:
																															goto IL_05e7;
																														case 35:
																														case 127:
																															goto IL_05fa;
																														case 99:
																														case 129:
																															goto IL_060d;
																														case 110:
																															goto IL_0629;
																														case 26:
																															goto IL_0637;
																														case 63:
																															goto IL_065a;
																														case 107:
																															goto IL_0664;
																														case 78:
																															goto IL_067b;
																														case 66:
																															goto IL_068e;
																														case 37:
																														case 75:
																															goto IL_0699;
																														case 65:
																															goto IL_06b1;
																														case 52:
																															goto IL_06bc;
																														case 56:
																															goto IL_06ca;
																														case 57:
																														case 105:
																															goto IL_06d8;
																														case 53:
																															goto IL_0701;
																														case 96:
																															goto IL_070f;
																														case 91:
																															goto IL_0728;
																														case 0:
																														case 87:
																															goto IL_0733;
																														case 29:
																															goto IL_074c;
																														case 61:
																															goto IL_075a;
																														case 43:
																															goto IL_0768;
																														case 3:
																														case 4:
																														case 6:
																														case 22:
																														case 36:
																														case 46:
																														case 48:
																														case 50:
																														case 51:
																														case 55:
																														case 60:
																														case 62:
																														case 77:
																														case 79:
																														case 82:
																														case 83:
																														case 85:
																														case 97:
																														case 100:
																														case 106:
																														case 108:
																														case 109:
																														case 126:
																														case 128:
																															goto end_IL_02a0;
																														case 5:
																														case 7:
																														case 16:
																														case 19:
																														case 25:
																														case 31:
																														case 41:
																														case 42:
																														case 54:
																														case 72:
																														case 94:
																														case 102:
																														case 114:
																														case 119:
																														case 120:
																														case 122:
																															goto end_IL_023d;
																														case 76:
																															goto end_IL_0794;
																														case 14:
																															goto end_IL_07a7;
																														case 15:
																															goto end_IL_07b1;
																														case 111:
																															goto end_IL_07c5;
																														case 112:
																														case 123:
																															goto end_IL_07da;
																														case 103:
																															goto end_IL_07f3;
																														case 113:
																														case 124:
																															goto end_IL_080c;
																														case 10:
																															goto end_IL_081c;
																														case 11:
																															goto end_IL_082c;
																														case 8:
																														case 13:
																															goto IL_0847;
																														}
																														continue;
																													}
																													goto IL_0629;
																													IL_0664:
																													num5++;
																													num = 78;
																													goto IL_067b;
																													IL_067b:
																													ptr2 += 8;
																													break;
																													IL_0629:
																													array[num5] = 0;
																													goto IL_0637;
																													IL_0637:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_065a;
																													IL_065a:
																													array2[num5] = null;
																													goto IL_0664;
																													continue;
																													end_IL_023d:
																													break;
																												}
																												break;
																											}
																											goto IL_02f9;
																											IL_02f9:
																											if (4 < b)
																											{
																												goto end_IL_02a0;
																											}
																											goto IL_0307;
																											IL_0307:
																											if (4 > b)
																											{
																												goto end_IL_02a0;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_03cb;
																									IL_04d1:
																									num5--;
																									break;
																									IL_03cb:
																									if (6 < b)
																									{
																										goto end_IL_02a0;
																									}
																									goto IL_03d9;
																									IL_03d9:
																									if (6 > b)
																									{
																										goto end_IL_02a0;
																									}
																									goto IL_03e7;
																									IL_03e7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04bd;
																									IL_04bd:
																									array[num5 - 2] = 0;
																									goto IL_04d1;
																								}
																								break;
																							}
																							goto IL_068e;
																							IL_075a:
																							num5++;
																							goto IL_0768;
																							IL_068e:
																							if (3 <= b)
																							{
																								goto IL_0699;
																							}
																							goto IL_06b1;
																							IL_0699:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_06b1:
																							if (1 < b)
																							{
																								goto IL_06bc;
																							}
																							num = 91;
																							goto IL_0728;
																							IL_06bc:
																							if (2 < b)
																							{
																								goto end_IL_02a0;
																							}
																							goto IL_06ca;
																							IL_06ca:
																							if (2 > b)
																							{
																								goto end_IL_02a0;
																							}
																							goto IL_06d8;
																							IL_06d8:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0701;
																							IL_0701:
																							ptr2 += 8;
																							goto IL_070f;
																							IL_070f:
																							num5--;
																							break;
																							IL_0768:
																							ptr2 += 8;
																							break;
																							IL_0728:
																							if (1 > b)
																							{
																								goto end_IL_02a0;
																							}
																							goto IL_0733;
																							IL_0733:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_074c;
																							IL_074c:
																							array[num5] = 0;
																							goto IL_075a;
																						}
																						break;
																					}
																					goto IL_031a;
																					IL_05e7:
																					ptr2 += 8;
																					break;
																					IL_031a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05cb;
																					IL_05cb:
																					array[num5] = 0;
																					goto IL_05d9;
																					IL_05d9:
																					num5++;
																					goto IL_05e7;
																				}
																				break;
																			}
																			goto IL_02db;
																			IL_060d:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_02db:
																			if (10 >= b)
																			{
																				goto IL_02e9;
																			}
																			goto IL_04e4;
																			IL_02e9:
																			if (10 <= b)
																			{
																				goto IL_0342;
																			}
																			goto IL_042c;
																			IL_042c:
																			if (8 >= b)
																			{
																				goto IL_043a;
																			}
																			goto IL_053f;
																			IL_043a:
																			if (8 > b)
																			{
																				goto end_IL_02a0;
																			}
																			goto IL_0448;
																			IL_0448:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04aa;
																			IL_04aa:
																			num5 -= 2;
																			break;
																			IL_053f:
																			if (9 < b)
																			{
																				goto end_IL_02a0;
																			}
																			goto IL_054d;
																			IL_054d:
																			if (9 > b)
																			{
																				goto end_IL_02a0;
																			}
																			goto IL_055b;
																			IL_055b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 32;
																			goto IL_05a4;
																			IL_05a4:
																			array[num5 - 2] = 0;
																			goto IL_05b8;
																			IL_05b8:
																			num5--;
																			break;
																			IL_0342:
																			array[num5 - 2] = 0;
																			goto IL_0356;
																			IL_0356:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getOriginalIssuerscale[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_03aa;
																			IL_03aa:
																			num5--;
																			goto IL_03b8;
																			IL_03b8:
																			ptr2 += 8;
																			break;
																			IL_04e4:
																			if (12 < b)
																			{
																				goto IL_04ef;
																			}
																			goto IL_0510;
																			IL_04ef:
																			if (13 < b)
																			{
																				goto end_IL_02a0;
																			}
																			goto IL_04fd;
																			IL_04fd:
																			if (13 > b)
																			{
																			}
																			goto end_IL_02a0;
																			IL_0510:
																			if (12 > b)
																			{
																				goto IL_051e;
																			}
																			goto IL_060d;
																			IL_051e:
																			if (11 < b)
																			{
																				goto end_IL_02a0;
																			}
																			goto IL_052c;
																			IL_052c:
																			if (11 > b)
																			{
																				goto end_IL_02a0;
																			}
																			goto IL_05fa;
																			IL_05fa:
																			num5--;
																			break;
																		}
																		goto end_IL_02b0;
																		continue;
																		end_IL_02a0:
																		break;
																		IL_02a0:;
																	}
																}
																else
																{
																	num = 51;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02b0:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0847;
												IL_0847:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0794:
												break;
											}
											continue;
											end_IL_07a7:
											break;
										}
										continue;
										end_IL_07b1:
										break;
									}
									continue;
									end_IL_07c5:
									break;
								}
								continue;
								end_IL_07da:
								break;
							}
							continue;
							end_IL_07f3:
							break;
						}
						continue;
						end_IL_080c:
						break;
					}
					continue;
					end_IL_081c:
					break;
				}
				continue;
				end_IL_082c:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 60;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								num = 37;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ToXmlStringCulture.SEPHourSuffGetFullPath);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02a1:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0284:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0274:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_0267:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_0257:
																										if (11 > b)
																										{
																											while (10 >= b)
																											{
																												num = 133;
																												while (true)
																												{
																													if (num != 133)
																													{
																														if (num != 1114)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 17:
																															goto IL_0244;
																														case 25:
																															goto IL_0257;
																														case 14:
																														case 92:
																															goto IL_0267;
																														case 20:
																														case 82:
																															goto IL_0274;
																														case 125:
																															goto IL_0284;
																														case 33:
																															goto IL_0291;
																														case 34:
																															goto IL_02a1;
																														case 61:
																															goto end_IL_02a1;
																														case 1:
																														case 65:
																															goto end_IL_02b1;
																														case 2:
																														case 23:
																															goto IL_02cc;
																														case 13:
																															goto IL_02da;
																														case 47:
																														case 97:
																															goto IL_02e8;
																														case 104:
																															goto IL_0304;
																														case 71:
																															goto IL_0312;
																														case 72:
																															goto IL_0320;
																														case 49:
																														case 100:
																															goto IL_032e;
																														case 11:
																															goto IL_033c;
																														case 39:
																															goto IL_034a;
																														case 0:
																														case 58:
																															goto IL_0358;
																														case 4:
																														case 113:
																															goto IL_03cb;
																														case 83:
																															goto IL_040b;
																														case 51:
																															goto IL_041f;
																														case 114:
																															goto IL_0432;
																														case 45:
																															goto IL_043d;
																														case 55:
																														case 73:
																															goto IL_044b;
																														case 93:
																															goto IL_047d;
																														case 30:
																															goto IL_048b;
																														case 115:
																															goto IL_049e;
																														case 68:
																															goto IL_04ac;
																														case 6:
																														case 96:
																															goto IL_04ba;
																														case 119:
																															goto IL_04d2;
																														case 122:
																															goto IL_04e5;
																														case 44:
																														case 126:
																															goto IL_04f8;
																														case 62:
																														case 91:
																															goto IL_0519;
																														case 15:
																															goto IL_052d;
																														case 105:
																															goto IL_0581;
																														case 85:
																															goto IL_0598;
																														case 99:
																															goto end_IL_0231;
																														case 7:
																														case 66:
																															goto IL_05b9;
																														case 90:
																														case 111:
																															goto IL_05c4;
																														case 94:
																															goto IL_05cf;
																														case 48:
																														case 79:
																															goto IL_05dd;
																														case 9:
																															goto IL_05f6;
																														case 31:
																															goto IL_0604;
																														case 107:
																															goto IL_0612;
																														case 41:
																															goto IL_0633;
																														case 110:
																														case 120:
																															goto IL_064a;
																														case 22:
																															goto IL_0661;
																														case 86:
																															goto IL_0684;
																														case 10:
																															goto IL_068e;
																														case 46:
																															goto IL_069c;
																														case 19:
																														case 26:
																															goto IL_06af;
																														case 87:
																															goto IL_06ef;
																														case 76:
																															goto IL_0703;
																														case 3:
																														case 12:
																														case 16:
																														case 24:
																														case 28:
																														case 32:
																														case 40:
																														case 42:
																														case 56:
																														case 64:
																														case 69:
																														case 70:
																														case 75:
																														case 78:
																														case 80:
																														case 84:
																														case 88:
																														case 89:
																														case 95:
																														case 98:
																														case 102:
																														case 108:
																														case 121:
																														case 124:
																															goto end_IL_0244;
																														case 29:
																															goto IL_073f;
																														case 117:
																															goto IL_074d;
																														case 63:
																															goto IL_075b;
																														case 5:
																														case 8:
																														case 18:
																														case 21:
																														case 27:
																														case 36:
																														case 50:
																														case 53:
																														case 54:
																														case 57:
																														case 74:
																														case 77:
																														case 101:
																														case 109:
																														case 118:
																															goto end_IL_02c1;
																														case 116:
																															goto end_IL_0769;
																														case 35:
																															goto end_IL_077c;
																														case 52:
																															goto end_IL_0786;
																														case 37:
																															goto end_IL_0791;
																														case 123:
																															goto end_IL_07a6;
																														case 103:
																														case 106:
																															goto end_IL_07bb;
																														case 81:
																															goto end_IL_07d4;
																														case 38:
																														case 112:
																															goto end_IL_07e4;
																														case 59:
																															goto end_IL_07f4;
																														case 60:
																															goto end_IL_0804;
																														case 43:
																														case 67:
																															goto IL_0828;
																														}
																														continue;
																													}
																													if (10 > b)
																													{
																														goto end_IL_0244;
																													}
																													goto IL_0519;
																													IL_052d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)FormIdnaDisallowUnassignedTAIWANLUNISOLAR[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																													goto IL_0581;
																													IL_0598:
																													ptr2 += 8;
																													goto end_IL_02c1;
																													IL_0581:
																													num5--;
																													num = 85;
																													goto IL_0598;
																													IL_0519:
																													array[num5 - 2] = 0;
																													goto IL_052d;
																													continue;
																													end_IL_0231:
																													break;
																												}
																												goto IL_05ab;
																												continue;
																												end_IL_0244:
																												break;
																												IL_0244:;
																											}
																											break;
																										}
																										goto IL_04f8;
																										IL_04f8:
																										num5--;
																										goto end_IL_02c1;
																									}
																									break;
																								}
																								goto IL_02cc;
																								IL_02e8:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_02c1;
																								IL_02cc:
																								if (12 < b)
																								{
																									break;
																								}
																								goto IL_02da;
																								IL_02da:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_02e8;
																							}
																							break;
																						}
																						goto IL_05ab;
																						IL_06af:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_06ef;
																						IL_05ab:
																						if (9 > b)
																						{
																							goto IL_05b9;
																						}
																						goto IL_06af;
																						IL_05b9:
																						if (7 < b)
																						{
																							goto IL_05c4;
																						}
																						goto IL_0633;
																						IL_05c4:
																						if (8 < b)
																						{
																							num = 16;
																							break;
																						}
																						goto IL_05cf;
																						IL_05cf:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_05dd;
																						IL_05dd:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_05f6;
																						IL_05f6:
																						array[num5] = 0;
																						goto IL_0604;
																						IL_0604:
																						num5++;
																						goto IL_0612;
																						IL_0612:
																						ptr2 += 8;
																						goto end_IL_02c1;
																						IL_06ef:
																						array[num5 - 2] = 0;
																						goto IL_0703;
																						IL_0633:
																						if (7 > b)
																						{
																							break;
																						}
																						num = 110;
																						goto IL_064a;
																						IL_0703:
																						num5--;
																						goto end_IL_02c1;
																						IL_064a:
																						array[num5] = 0;
																						num = 22;
																						goto IL_0661;
																						IL_0661:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0684;
																						IL_0684:
																						array2[num5] = null;
																						goto IL_068e;
																						IL_068e:
																						num5++;
																						goto IL_069c;
																						IL_069c:
																						ptr2 += 8;
																						goto end_IL_02c1;
																					}
																					break;
																				}
																				goto IL_0304;
																				IL_04ba:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02c1;
																				IL_0304:
																				if (6 <= b)
																				{
																					goto end_IL_02c1;
																				}
																				goto IL_0312;
																				IL_0312:
																				if (3 >= b)
																				{
																					goto IL_0320;
																				}
																				goto IL_0432;
																				IL_0320:
																				if (3 > b)
																				{
																					goto IL_032e;
																				}
																				goto IL_03cb;
																				IL_032e:
																				if (1 < b)
																				{
																					goto IL_033c;
																				}
																				goto IL_04d2;
																				IL_033c:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_034a;
																				IL_034a:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0358;
																				IL_0358:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_04e5;
																				IL_04e5:
																				num5 -= 2;
																				goto end_IL_02c1;
																				IL_04d2:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_03cb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_040b;
																				IL_040b:
																				array[num5 - 2] = 0;
																				goto IL_041f;
																				IL_041f:
																				num5--;
																				goto end_IL_02c1;
																				IL_0432:
																				if (4 >= b)
																				{
																					goto IL_043d;
																				}
																				goto IL_049e;
																				IL_043d:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_044b;
																				IL_044b:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 93;
																				goto IL_047d;
																				IL_047d:
																				ptr2 += 8;
																				goto IL_048b;
																				IL_048b:
																				num5--;
																				goto end_IL_02c1;
																				IL_049e:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_04ac;
																				IL_04ac:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_04ba;
																			}
																			break;
																			IL_0291:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 29;
																	goto IL_073f;
																	IL_075b:
																	ptr2 += 8;
																	goto end_IL_02c1;
																	IL_074d:
																	num5++;
																	goto IL_075b;
																	IL_073f:
																	array[num5] = 0;
																	goto IL_074d;
																	continue;
																	end_IL_02a1:
																	break;
																}
																continue;
																end_IL_02b1:
																break;
															}
															continue;
															end_IL_02c1:
															break;
														}
														continue;
													}
													num = 67;
													goto IL_0828;
													IL_0828:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0769:
													break;
												}
												continue;
												end_IL_077c:
												break;
											}
											continue;
											end_IL_0786:
											break;
										}
										continue;
										end_IL_0791:
										break;
									}
									continue;
									end_IL_07a6:
									break;
								}
								continue;
								end_IL_07bb:
								break;
							}
							continue;
							end_IL_07d4:
							break;
						}
						continue;
						end_IL_07e4:
						break;
					}
					continue;
					end_IL_07f4:
					break;
				}
				continue;
				end_IL_0804:
				break;
			}
		}
	}

	private static int smethod_3(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		num += num2;
		int num3 = num;
		num = int_2;
		num2 = int_3;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 180;
		num2 = 90;
		num += 90;
		num2 = 252;
		num2 = 36;
		int num6 = smethod_0(36);
		num2 = num6;
		return num;
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSSECTIONIDWINDOWCLASSSECTIONExtendedNormalizationForms.SoapEntityFileLoadException);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_028d:
															byte b = *ptr2;
															while (true)
															{
																IL_027d:
																ptr2++;
																while (true)
																{
																	IL_0270:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0250:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_0240:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_0233:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0226:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_01b3:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												while (true)
																												{
																													IL_019a:
																													num5 -= 2;
																													num = 94;
																													while (num != 94)
																													{
																														if (num != 1075)
																														{
																															goto end_IL_0260;
																														}
																														switch (num)
																														{
																														case 12:
																															goto IL_019a;
																														case 39:
																														case 85:
																															goto IL_01b3;
																														case 66:
																															goto IL_0226;
																														case 55:
																															goto IL_0233;
																														case 54:
																															goto IL_0240;
																														case 20:
																															goto IL_0250;
																														case 51:
																															goto IL_0260;
																														case 5:
																															goto IL_0270;
																														case 79:
																															goto IL_027d;
																														case 22:
																														case 48:
																															goto IL_028d;
																														case 14:
																														case 44:
																															goto IL_02b1;
																														case 42:
																															goto IL_02bf;
																														case 9:
																														case 53:
																															goto IL_02d2;
																														case 4:
																															goto IL_02e0;
																														case 69:
																														case 71:
																															goto IL_02ee;
																														case 45:
																															goto IL_032e;
																														case 31:
																															goto IL_0342;
																														case 57:
																														case 77:
																															goto IL_0355;
																														case 70:
																															goto IL_037e;
																														case 8:
																															goto IL_0395;
																														case 82:
																															goto IL_03a8;
																														case 23:
																														case 32:
																															goto IL_03b6;
																														case 52:
																															goto IL_03c1;
																														case 60:
																														case 80:
																															goto IL_03cf;
																														case 35:
																															goto IL_03dd;
																														case 49:
																															goto IL_0400;
																														case 13:
																															goto IL_040a;
																														case 81:
																															goto IL_0418;
																														case 33:
																															goto IL_042b;
																														case 36:
																															goto IL_0436;
																														case 38:
																														case 74:
																															goto IL_0441;
																														case 72:
																															goto IL_0466;
																														case 30:
																															goto IL_0471;
																														case 34:
																															goto IL_047c;
																														case 40:
																														case 78:
																															goto IL_0487;
																														case 1:
																														case 2:
																														case 3:
																														case 6:
																														case 7:
																														case 10:
																														case 16:
																														case 19:
																														case 21:
																														case 41:
																														case 50:
																														case 56:
																														case 63:
																														case 67:
																														case 73:
																														case 75:
																															goto end_IL_0260;
																														case 65:
																															goto IL_04ca;
																														case 58:
																															goto IL_04d8;
																														case 87:
																															goto IL_04e6;
																														case 0:
																														case 17:
																														case 24:
																														case 26:
																														case 27:
																														case 29:
																														case 37:
																														case 59:
																														case 68:
																														case 84:
																															goto end_IL_0187;
																														case 76:
																															goto end_IL_04f4;
																														case 28:
																															goto end_IL_0507;
																														case 64:
																															goto end_IL_0511;
																														case 46:
																															goto end_IL_051c;
																														case 83:
																															goto end_IL_0531;
																														case 47:
																														case 86:
																															goto end_IL_0546;
																														case 25:
																															goto end_IL_0556;
																														case 11:
																														case 43:
																															goto end_IL_0566;
																														case 61:
																															goto end_IL_0576;
																														case 62:
																															goto end_IL_0586;
																														case 15:
																														case 18:
																															goto IL_05a1;
																														}
																														continue;
																														end_IL_0187:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02b1;
																										IL_02bf:
																										if (1 > b)
																										{
																										}
																										goto end_IL_0260;
																										IL_02b1:
																										if (1 < b)
																										{
																											goto end_IL_0260;
																										}
																										goto IL_02bf;
																									}
																									break;
																								}
																								num = 9;
																								goto IL_02d2;
																								IL_032e:
																								array[num5 - 2] = 0;
																								goto IL_0342;
																								IL_0342:
																								num5--;
																								break;
																								IL_02d2:
																								if (3 < b)
																								{
																									goto end_IL_0260;
																								}
																								goto IL_02e0;
																								IL_02e0:
																								if (3 > b)
																								{
																									goto end_IL_0260;
																								}
																								goto IL_02ee;
																								IL_02ee:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_032e;
																							}
																							break;
																						}
																						goto IL_0355;
																						IL_0395:
																						num5--;
																						break;
																						IL_0355:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_037e;
																						IL_037e:
																						ptr2 += 8;
																						num = 8;
																						goto IL_0395;
																					}
																					break;
																				}
																				goto IL_03a8;
																				IL_0487:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_03a8:
																				if (6 < b)
																				{
																					goto IL_03b6;
																				}
																				goto IL_0466;
																				IL_03b6:
																				if (7 >= b)
																				{
																					goto IL_03c1;
																				}
																				goto IL_042b;
																				IL_03c1:
																				if (7 > b)
																				{
																					goto end_IL_0260;
																				}
																				goto IL_03cf;
																				IL_03cf:
																				array[num5] = 0;
																				goto IL_03dd;
																				IL_03dd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0400;
																				IL_0400:
																				array2[num5] = null;
																				goto IL_040a;
																				IL_040a:
																				num5++;
																				goto IL_0418;
																				IL_0418:
																				ptr2 += 8;
																				break;
																				IL_042b:
																				if (8 < b)
																				{
																					goto end_IL_0260;
																				}
																				goto IL_0436;
																				IL_0436:
																				if (8 > b)
																				{
																					goto end_IL_0260;
																				}
																				goto IL_0441;
																				IL_0441:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 24;
																				break;
																				IL_0466:
																				if (6 <= b)
																				{
																					num = 26;
																					break;
																				}
																				goto IL_0471;
																				IL_0471:
																				if (5 < b)
																				{
																					goto end_IL_0260;
																				}
																				goto IL_047c;
																				IL_047c:
																				if (5 > b)
																				{
																					goto end_IL_0260;
																				}
																				goto IL_0487;
																			}
																			goto end_IL_0270;
																			continue;
																			end_IL_0260:
																			break;
																			IL_0260:;
																		}
																	}
																	else
																	{
																		num = 50;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04ca;
																	IL_04d8:
																	num5++;
																	goto IL_04e6;
																	IL_04e6:
																	ptr2 += 8;
																	break;
																	IL_04ca:
																	array[num5] = 0;
																	goto IL_04d8;
																	continue;
																	end_IL_0270:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a1;
													IL_05a1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f4:
													break;
												}
												continue;
												end_IL_0507:
												break;
											}
											continue;
											end_IL_0511:
											break;
										}
										continue;
										end_IL_051c:
										break;
									}
									continue;
									end_IL_0531:
									break;
								}
								continue;
								end_IL_0546:
								break;
							}
							continue;
							end_IL_0556:
							break;
						}
						continue;
						end_IL_0566:
						break;
					}
					continue;
					end_IL_0576:
					break;
				}
				continue;
				end_IL_0586:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 26;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 58;
						while (true)
						{
							num = 21;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										num = 80;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setExceptionRemoveAccessRuleSpecific.EventListenerTYPEFLAGFHIDDEN);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0261:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					if (5 >= b)
																					{
																						while (true)
																						{
																							if (5 <= b)
																							{
																								while (true)
																								{
																									array[num5] = 0;
																									while (true)
																									{
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										while (true)
																										{
																											array2[num5] = null;
																											while (true)
																											{
																												IL_01da:
																												num5++;
																												num = 110;
																												while (true)
																												{
																													if (num != 110)
																													{
																														if (num != 1091)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 49:
																															goto IL_01da;
																														case 89:
																															goto end_IL_01c7;
																														case 50:
																															goto end_IL_01f3;
																														case 40:
																														case 52:
																															goto end_IL_01ff;
																														case 69:
																															goto end_IL_0224;
																														case 85:
																															goto end_IL_0234;
																														case 38:
																															goto end_IL_0241;
																														case 10:
																															goto IL_0261;
																														case 16:
																															goto end_IL_0261;
																														case 11:
																														case 81:
																															goto end_IL_0271;
																														case 71:
																															goto IL_028c;
																														case 1:
																															goto IL_0297;
																														case 18:
																															goto IL_02a2;
																														case 35:
																															goto IL_02b0;
																														case 19:
																														case 34:
																															goto IL_02c3;
																														case 36:
																															goto IL_02d1;
																														case 12:
																														case 47:
																															goto IL_02df;
																														case 48:
																															goto IL_0308;
																														case 51:
																														case 86:
																															goto IL_031b;
																														case 70:
																															goto IL_035b;
																														case 37:
																															goto IL_036f;
																														case 42:
																														case 98:
																															goto IL_0382;
																														case 54:
																															goto IL_0390;
																														case 9:
																														case 15:
																															goto IL_039e;
																														case 75:
																															goto IL_03ac;
																														case 73:
																														case 84:
																															goto IL_03ba;
																														case 88:
																															goto IL_03fa;
																														case 5:
																															goto IL_040e;
																														case 63:
																														case 77:
																															goto IL_0421;
																														case 95:
																															goto IL_043a;
																														case 91:
																															goto IL_0448;
																														case 87:
																															goto IL_0456;
																														case 31:
																															goto IL_0469;
																														case 20:
																															goto IL_0474;
																														case 29:
																														case 72:
																															goto IL_0482;
																														case 39:
																															goto IL_04c2;
																														case 65:
																															goto IL_04d6;
																														case 46:
																															goto IL_04e9;
																														case 57:
																															goto IL_04f7;
																														case 14:
																														case 27:
																															goto IL_050e;
																														case 99:
																															goto IL_052a;
																														case 103:
																															goto IL_053d;
																														case 32:
																															goto IL_054b;
																														case 55:
																														case 74:
																															goto IL_0556;
																														case 23:
																															goto IL_0596;
																														case 0:
																															goto IL_05aa;
																														case 3:
																														case 4:
																														case 17:
																														case 22:
																														case 24:
																														case 43:
																														case 44:
																														case 53:
																														case 59:
																														case 60:
																														case 67:
																														case 78:
																														case 79:
																														case 90:
																														case 92:
																														case 94:
																														case 96:
																														case 100:
																															goto end_IL_0251;
																														case 97:
																															goto IL_05ff;
																														case 93:
																															goto IL_060d;
																														case 33:
																															goto IL_061b;
																														case 2:
																														case 6:
																														case 8:
																														case 30:
																														case 62:
																														case 64:
																														case 68:
																														case 76:
																														case 82:
																														case 101:
																														case 102:
																															goto end_IL_0281;
																														case 45:
																															goto end_IL_0629;
																														case 83:
																															goto end_IL_063c;
																														case 80:
																															goto end_IL_0646;
																														case 61:
																															goto end_IL_0651;
																														case 56:
																															goto end_IL_0666;
																														case 21:
																															goto end_IL_0684;
																														case 58:
																															goto end_IL_0694;
																														case 13:
																															goto end_IL_06a4;
																														case 7:
																														case 66:
																															goto end_IL_06af;
																														case 25:
																															goto end_IL_06c8;
																														case 26:
																															goto end_IL_06d8;
																														case 28:
																														case 41:
																															goto IL_06f3;
																														}
																														continue;
																													}
																													ptr2 += 8;
																													num = 101;
																													goto end_IL_0281;
																													continue;
																													end_IL_01c7:
																													break;
																												}
																												break;
																											}
																											continue;
																											end_IL_01f3:
																											break;
																										}
																										continue;
																										end_IL_01ff:
																										break;
																									}
																									continue;
																									end_IL_0224:
																									break;
																								}
																								continue;
																							}
																							goto IL_028c;
																							IL_05aa:
																							num5--;
																							goto end_IL_0281;
																							IL_028c:
																							if (2 >= b)
																							{
																								goto IL_0297;
																							}
																							goto IL_02c3;
																							IL_0297:
																							if (2 > b)
																							{
																								goto IL_02a2;
																							}
																							goto IL_031b;
																							IL_02a2:
																							if (1 < b)
																							{
																								goto end_IL_0251;
																							}
																							goto IL_02b0;
																							IL_02b0:
																							if (1 <= b)
																							{
																							}
																							goto end_IL_0251;
																							IL_031b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_035b;
																							IL_035b:
																							array[num5 - 2] = 0;
																							goto IL_036f;
																							IL_036f:
																							num5--;
																							goto end_IL_0281;
																							IL_02c3:
																							if (3 >= b)
																							{
																								goto IL_02d1;
																							}
																							goto IL_053d;
																							IL_02d1:
																							if (3 > b)
																							{
																								goto end_IL_0251;
																							}
																							goto IL_02df;
																							IL_02df:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0308;
																							IL_0308:
																							ptr2 += 8;
																							goto IL_052a;
																							IL_052a:
																							num5--;
																							goto end_IL_0281;
																							IL_053d:
																							if (4 < b)
																							{
																								goto end_IL_0251;
																							}
																							goto IL_054b;
																							IL_054b:
																							if (4 > b)
																							{
																								goto end_IL_0251;
																							}
																							goto IL_0556;
																							IL_0556:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0596;
																							IL_0596:
																							array[num5 - 2] = 0;
																							goto IL_05aa;
																							continue;
																							end_IL_0234:
																							break;
																						}
																						continue;
																					}
																					goto IL_0382;
																					IL_050e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0281;
																					IL_0382:
																					if (7 >= b)
																					{
																						goto IL_0390;
																					}
																					goto IL_0469;
																					IL_0390:
																					if (7 > b)
																					{
																						goto IL_039e;
																					}
																					goto IL_0421;
																					IL_039e:
																					if (6 < b)
																					{
																						goto end_IL_0251;
																					}
																					goto IL_03ac;
																					IL_03ac:
																					if (6 > b)
																					{
																						goto end_IL_0251;
																					}
																					goto IL_03ba;
																					IL_03ba:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03fa;
																					IL_03fa:
																					array[num5 - 2] = 0;
																					goto IL_040e;
																					IL_040e:
																					num5--;
																					goto end_IL_0281;
																					IL_0421:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_043a;
																					IL_043a:
																					array[num5] = 0;
																					goto IL_0448;
																					IL_0448:
																					num5++;
																					goto IL_0456;
																					IL_0456:
																					ptr2 += 8;
																					goto end_IL_0281;
																					IL_0469:
																					if (8 >= b)
																					{
																						goto IL_0474;
																					}
																					goto IL_04e9;
																					IL_0474:
																					if (8 > b)
																					{
																						goto end_IL_0251;
																					}
																					goto IL_0482;
																					IL_0482:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04c2;
																					IL_04c2:
																					array[num5 - 2] = 0;
																					goto IL_04d6;
																					IL_04d6:
																					num5--;
																					goto end_IL_0281;
																					IL_04e9:
																					if (9 < b)
																					{
																						goto end_IL_0251;
																					}
																					goto IL_04f7;
																					IL_04f7:
																					if (9 > b)
																					{
																						goto end_IL_0251;
																					}
																					num = 14;
																					goto IL_050e;
																					continue;
																					end_IL_0241:
																					break;
																				}
																				continue;
																				end_IL_0251:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 97;
																		goto IL_05ff;
																		IL_061b:
																		ptr2 += 8;
																		goto end_IL_0281;
																		IL_060d:
																		num5++;
																		goto IL_061b;
																		IL_05ff:
																		array[num5] = 0;
																		goto IL_060d;
																		continue;
																		end_IL_0261:
																		break;
																	}
																	continue;
																	end_IL_0271:
																	break;
																}
																continue;
																end_IL_0281:
																break;
															}
															continue;
														}
														goto IL_06f3;
														IL_06f3:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0629:
														break;
													}
													continue;
													end_IL_063c:
													break;
												}
												continue;
												end_IL_0646:
												break;
											}
											continue;
											end_IL_0651:
											break;
										}
										continue;
										end_IL_0666:
										break;
									}
									continue;
									end_IL_0684:
									break;
								}
								continue;
								end_IL_0694:
								break;
							}
							continue;
							end_IL_06a4:
							break;
						}
						continue;
						end_IL_06af:
						break;
					}
					continue;
					end_IL_06c8:
					break;
				}
				continue;
				end_IL_06d8:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 31;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 12;
							while (true)
							{
								int[] array3 = new int[5];
								num = 32;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											num = 86;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref bodyWithStategetHashValue.CallbackBatch);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 62;
													while (true)
													{
														num = 53;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_0288:
																			if (b >= 1)
																			{
																				while (b <= 11)
																				{
																					while (true)
																					{
																						IL_026b:
																						if (6 >= b)
																						{
																							while (true)
																							{
																								IL_025b:
																								if (6 > b)
																								{
																									while (true)
																									{
																										IL_024b:
																										if (3 < b)
																										{
																											while (true)
																											{
																												IL_023b:
																												if (4 < b)
																												{
																													while (5 >= b)
																													{
																														num = 126;
																														while (true)
																														{
																															if (num != 126)
																															{
																																if (num != 1107)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 71:
																																case 97:
																																	goto IL_0228;
																																case 66:
																																case 105:
																																	goto IL_023b;
																																case 58:
																																case 78:
																																	goto IL_024b;
																																case 98:
																																	goto IL_025b;
																																case 57:
																																	goto IL_026b;
																																case 111:
																																	goto IL_0278;
																																case 70:
																																	goto IL_0288;
																																case 74:
																																	goto end_IL_0288;
																																case 3:
																																case 89:
																																	goto end_IL_0298;
																																case 59:
																																case 72:
																																	goto IL_02b3;
																																case 29:
																																	goto IL_02be;
																																case 60:
																																	goto IL_02cc;
																																case 21:
																																case 36:
																																	goto IL_02da;
																																case 55:
																																	goto IL_02f3;
																																case 18:
																																case 52:
																																	goto IL_02fe;
																																case 80:
																																	goto IL_030e;
																																case 23:
																																case 79:
																																	goto IL_031c;
																																case 87:
																																	goto IL_032f;
																																case 16:
																																case 24:
																																	goto IL_033d;
																																case 90:
																																	goto IL_0359;
																																case 38:
																																case 94:
																																	goto IL_0369;
																																case 20:
																																	goto IL_037d;
																																case 41:
																																	goto IL_03bc;
																																case 91:
																																case 106:
																																	goto IL_03cf;
																																case 107:
																																	goto IL_0411;
																																case 10:
																																case 103:
																																	goto IL_041f;
																																case 108:
																																	goto IL_0438;
																																case 115:
																																	goto IL_0448;
																																case 25:
																																	goto IL_045c;
																																case 116:
																																	goto IL_046f;
																																case 99:
																																	goto IL_0486;
																																case 84:
																																case 104:
																																	goto IL_04a7;
																																case 2:
																																	goto IL_04b5;
																																case 34:
																																	goto IL_04d8;
																																case 109:
																																	goto IL_04e2;
																																case 114:
																																	goto IL_04f0;
																																case 117:
																																	goto IL_0503;
																																case 50:
																																case 61:
																																	goto IL_0511;
																																case 73:
																																	goto IL_0551;
																																case 35:
																																	goto IL_0565;
																																case 14:
																																	goto IL_0578;
																																case 8:
																																case 40:
																																	goto IL_0586;
																																case 85:
																																	goto IL_0591;
																																case 11:
																																	goto IL_05ad;
																																case 83:
																																	goto IL_05bb;
																																case 19:
																																case 49:
																																	goto IL_05c9;
																																case 54:
																																	goto IL_0609;
																																case 4:
																																	goto IL_061d;
																																case 69:
																																case 92:
																																	goto IL_0630;
																																case 64:
																																	goto IL_0659;
																																case 26:
																																	goto IL_0667;
																																case 43:
																																case 95:
																																	goto IL_067a;
																																case 45:
																																	goto IL_06ba;
																																case 63:
																																	goto IL_06ce;
																																case 0:
																																case 1:
																																case 7:
																																case 9:
																																case 13:
																																case 15:
																																case 22:
																																case 44:
																																case 47:
																																case 51:
																																case 56:
																																case 65:
																																case 67:
																																case 81:
																																case 88:
																																case 100:
																																case 101:
																																case 113:
																																	goto end_IL_0215;
																																case 33:
																																	goto IL_070a;
																																case 119:
																																	goto IL_0718;
																																case 46:
																																	goto IL_0726;
																																case 5:
																																case 17:
																																case 28:
																																case 39:
																																case 42:
																																case 48:
																																case 53:
																																case 68:
																																case 76:
																																case 77:
																																case 93:
																																case 118:
																																	goto end_IL_02a8;
																																case 62:
																																	goto end_IL_0734;
																																case 82:
																																	goto end_IL_0747;
																																case 86:
																																	goto end_IL_0752;
																																case 102:
																																	goto end_IL_0765;
																																case 96:
																																	goto end_IL_0770;
																																case 32:
																																	goto end_IL_078e;
																																case 12:
																																	goto end_IL_07a3;
																																case 37:
																																	goto end_IL_07b3;
																																case 27:
																																	goto end_IL_07cc;
																																case 110:
																																case 112:
																																	goto end_IL_07d7;
																																case 30:
																																	goto end_IL_07e7;
																																case 31:
																																	goto end_IL_07f7;
																																case 6:
																																case 75:
																																	goto IL_0812;
																																}
																																continue;
																															}
																															if (5 > b)
																															{
																																break;
																															}
																															goto IL_04a7;
																															IL_04d8:
																															array2[num5] = null;
																															goto IL_04e2;
																															IL_04f0:
																															ptr2 += 8;
																															goto end_IL_02a8;
																															IL_04e2:
																															num5++;
																															goto IL_04f0;
																															IL_04a7:
																															array[num5] = 0;
																															goto IL_04b5;
																															IL_04b5:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															goto IL_04d8;
																															continue;
																															end_IL_0215:
																															break;
																														}
																														break;
																														IL_0228:;
																													}
																													break;
																												}
																												goto IL_0503;
																												IL_0565:
																												num5--;
																												goto end_IL_02a8;
																												IL_0503:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_0511;
																												IL_0511:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0551;
																												IL_0551:
																												array[num5 - 2] = 0;
																												goto IL_0565;
																											}
																											break;
																										}
																										goto IL_0578;
																										IL_0659:
																										ptr2 += 8;
																										goto IL_0667;
																										IL_0578:
																										if (3 > b)
																										{
																											goto IL_0586;
																										}
																										goto IL_0630;
																										IL_0586:
																										if (1 >= b)
																										{
																											goto IL_0591;
																										}
																										goto IL_05ad;
																										IL_0591:
																										if (1 <= b)
																										{
																											num = 113;
																										}
																										break;
																										IL_0667:
																										num5--;
																										goto end_IL_02a8;
																										IL_05ad:
																										if (2 < b)
																										{
																											break;
																										}
																										goto IL_05bb;
																										IL_05bb:
																										if (2 > b)
																										{
																											break;
																										}
																										goto IL_05c9;
																										IL_05c9:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0609;
																										IL_0609:
																										array[num5 - 2] = 0;
																										goto IL_061d;
																										IL_061d:
																										num5--;
																										goto end_IL_02a8;
																										IL_0630:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0659;
																									}
																									break;
																								}
																								goto IL_067a;
																								IL_06ce:
																								num5--;
																								num = 68;
																								goto end_IL_02a8;
																								IL_067a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_06ba;
																								IL_06ba:
																								array[num5 - 2] = 0;
																								goto IL_06ce;
																							}
																							break;
																						}
																						goto IL_02b3;
																						IL_030e:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_031c;
																						IL_02b3:
																						if (9 >= b)
																						{
																							goto IL_02be;
																						}
																						goto IL_02f3;
																						IL_02be:
																						if (9 > b)
																						{
																							goto IL_02cc;
																						}
																						goto IL_0369;
																						IL_02cc:
																						if (7 < b)
																						{
																							goto IL_02da;
																						}
																						goto IL_0411;
																						IL_02da:
																						if (8 < b)
																						{
																							break;
																						}
																						num = 90;
																						goto IL_0359;
																						IL_031c:
																						num5--;
																						goto end_IL_02a8;
																						IL_0359:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_03cf;
																						IL_03cf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0448;
																						IL_0448:
																						array[num5 - 2] = 0;
																						goto IL_045c;
																						IL_045c:
																						num5--;
																						goto end_IL_02a8;
																						IL_0411:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_041f;
																						IL_041f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0438;
																						IL_0438:
																						array[num5] = 0;
																						goto IL_046f;
																						IL_046f:
																						num5++;
																						num = 99;
																						goto IL_0486;
																						IL_0486:
																						ptr2 += 8;
																						goto end_IL_02a8;
																						IL_0369:
																						array[num5 - 1] = 0;
																						goto IL_037d;
																						IL_037d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getOriginalIssuerGetSymAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_03bc;
																						IL_03bc:
																						ptr2 += 8;
																						goto end_IL_02a8;
																						IL_02f3:
																						if (10 < b)
																						{
																							goto IL_02fe;
																						}
																						goto IL_030e;
																						IL_02fe:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_032f;
																						IL_032f:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_033d;
																						IL_033d:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02a8;
																					}
																					break;
																					IL_0278:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_070a;
																			IL_0726:
																			ptr2 += 8;
																			goto end_IL_02a8;
																			IL_0718:
																			num5++;
																			goto IL_0726;
																			IL_070a:
																			array[num5] = 0;
																			goto IL_0718;
																			continue;
																			end_IL_0288:
																			break;
																		}
																		continue;
																		end_IL_0298:
																		break;
																	}
																	continue;
																	end_IL_02a8:
																	break;
																}
																continue;
															}
															goto IL_0812;
															IL_0812:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															continue;
															end_IL_0734:
															break;
														}
														continue;
														end_IL_0747:
														break;
													}
													continue;
													end_IL_0752:
													break;
												}
												continue;
												end_IL_0765:
												break;
											}
											continue;
											end_IL_0770:
											break;
										}
										continue;
										end_IL_078e:
										break;
									}
									continue;
									end_IL_07a3:
									break;
								}
								continue;
								end_IL_07b3:
								break;
							}
							continue;
							end_IL_07cc:
							break;
						}
						continue;
						end_IL_07d7:
						break;
					}
					continue;
					end_IL_07e7:
					break;
				}
				continue;
				end_IL_07f7:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 29;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 67;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PurgeGetPrimaryInteropAssembly.CompilationRelaxationsSpecialFolder);
										num = 61;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02d8:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02b8:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02ab:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_029b:
																							if (14 < b)
																							{
																								while (15 >= b)
																								{
																									num = 150;
																									while (true)
																									{
																										if (num != 150)
																										{
																											if (num != 1131)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 14:
																											case 84:
																												goto IL_0288;
																											case 113:
																												goto IL_029b;
																											case 34:
																											case 138:
																												goto IL_02ab;
																											case 63:
																												goto IL_02b8;
																											case 143:
																												goto IL_02c8;
																											case 126:
																												goto IL_02d8;
																											case 7:
																												goto end_IL_02d8;
																											case 21:
																											case 121:
																												goto end_IL_02e8;
																											case 130:
																												goto IL_0303;
																											case 35:
																												goto IL_0311;
																											case 3:
																												goto IL_031c;
																											case 6:
																											case 104:
																												goto IL_0327;
																											case 37:
																												goto IL_0335;
																											case 25:
																											case 58:
																												goto IL_0348;
																											case 45:
																												goto IL_0356;
																											case 65:
																												goto IL_037e;
																											case 79:
																												goto IL_038c;
																											case 30:
																											case 80:
																												goto IL_039a;
																											case 20:
																												goto IL_03de;
																											case 90:
																												goto IL_03f2;
																											case 66:
																											case 111:
																												goto IL_040e;
																											case 95:
																												goto IL_044e;
																											case 38:
																												goto IL_0462;
																											case 139:
																												goto IL_0475;
																											case 88:
																												goto IL_047f;
																											case 55:
																												goto IL_0496;
																											case 33:
																												goto IL_04bc;
																											case 142:
																												goto IL_04ca;
																											case 110:
																												goto IL_04d8;
																											case 0:
																											case 41:
																												goto IL_04e6;
																											case 73:
																												goto IL_0551;
																											case 72:
																											case 86:
																												goto IL_0564;
																											case 89:
																												goto IL_0580;
																											case 32:
																											case 132:
																												goto IL_058e;
																											case 5:
																											case 109:
																												goto IL_059c;
																											case 16:
																												goto IL_05aa;
																											case 18:
																											case 82:
																												goto IL_05b5;
																											case 75:
																												goto IL_05c3;
																											case 56:
																											case 59:
																												goto IL_05d1;
																											case 128:
																												goto IL_05df;
																											case 107:
																												goto IL_05f7;
																											case 140:
																												goto IL_0605;
																											case 93:
																											case 124:
																												goto IL_0618;
																											case 122:
																												goto IL_0657;
																											case 99:
																												goto IL_066a;
																											case 50:
																												goto IL_0678;
																											case 23:
																											case 49:
																												goto IL_0686;
																											case 36:
																												goto IL_06af;
																											case 119:
																												goto IL_06bd;
																											case 131:
																												goto IL_06d0;
																											case 40:
																											case 129:
																												goto IL_06db;
																											case 120:
																												goto IL_06f9;
																											case 4:
																												goto IL_0707;
																											case 85:
																												goto IL_071a;
																											case 135:
																												goto IL_0728;
																											case 26:
																											case 91:
																												goto IL_0733;
																											case 62:
																												goto IL_0773;
																											case 9:
																												goto IL_0787;
																											case 47:
																												goto IL_079a;
																											case 31:
																												goto IL_07a8;
																											case 48:
																											case 97:
																												goto IL_07b6;
																											case 44:
																												goto IL_07cf;
																											case 76:
																												goto IL_07dd;
																											case 108:
																												goto IL_07eb;
																											case 8:
																												goto IL_07fb;
																											case 78:
																												goto IL_0806;
																											case 77:
																											case 118:
																												goto IL_0811;
																											case 87:
																												goto IL_083a;
																											case 1:
																											case 12:
																											case 13:
																											case 15:
																											case 22:
																											case 24:
																											case 46:
																											case 53:
																											case 64:
																											case 68:
																											case 70:
																											case 71:
																											case 74:
																											case 83:
																											case 92:
																											case 98:
																											case 101:
																											case 106:
																											case 114:
																											case 115:
																											case 116:
																											case 133:
																											case 136:
																											case 137:
																												goto end_IL_0275;
																											case 100:
																											case 105:
																												goto IL_0865;
																											case 10:
																											case 11:
																											case 17:
																											case 19:
																											case 27:
																											case 39:
																											case 42:
																											case 51:
																											case 54:
																											case 60:
																											case 69:
																											case 81:
																											case 94:
																											case 102:
																											case 103:
																											case 123:
																											case 125:
																											case 141:
																												goto end_IL_02f8;
																											case 61:
																												goto end_IL_0878;
																											case 67:
																												goto end_IL_088b;
																											case 2:
																												goto end_IL_0895;
																											case 52:
																												goto end_IL_08a9;
																											case 112:
																											case 117:
																												goto end_IL_08c2;
																											case 134:
																												goto end_IL_08d2;
																											case 43:
																											case 57:
																												goto end_IL_08e2;
																											case 28:
																												goto end_IL_08f2;
																											case 29:
																												goto end_IL_0902;
																											case 96:
																											case 127:
																												goto IL_091d;
																											}
																											continue;
																										}
																										if (15 <= b)
																										{
																										}
																										break;
																										continue;
																										end_IL_0275:
																										break;
																									}
																									break;
																									IL_0288:;
																								}
																								break;
																							}
																							goto IL_04bc;
																							IL_0564:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_02f8;
																							IL_04bc:
																							if (14 > b)
																							{
																								goto IL_04ca;
																							}
																							goto IL_0564;
																							IL_04ca:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_04d8;
																							IL_04d8:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_04e6;
																							IL_04e6:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 73;
																							goto IL_0551;
																							IL_0551:
																							num6 -= 2;
																							goto end_IL_02f8;
																						}
																						break;
																					}
																					goto IL_0303;
																					IL_044e:
																					array[num6 - 2] = 0;
																					goto IL_0462;
																					IL_0303:
																					if (12 > b)
																					{
																						goto IL_0311;
																					}
																					num = 66;
																					goto IL_040e;
																					IL_0311:
																					if (10 >= b)
																					{
																						goto IL_031c;
																					}
																					goto IL_037e;
																					IL_031c:
																					if (10 > b)
																					{
																						goto IL_0327;
																					}
																					goto IL_0348;
																					IL_0327:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0335;
																					IL_0335:
																					if (9 > b)
																					{
																						break;
																					}
																					goto end_IL_02f8;
																					IL_0348:
																					array[num6] = 0;
																					goto IL_0356;
																					IL_0356:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0475;
																					IL_0475:
																					array2[num6] = null;
																					goto IL_047f;
																					IL_047f:
																					num6++;
																					num = 55;
																					goto IL_0496;
																					IL_0496:
																					ptr2 += 8;
																					goto end_IL_02f8;
																					IL_037e:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_038c;
																					IL_038c:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_039a;
																					IL_039a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((int[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_03de;
																					IL_03de:
																					array[num6 - 2] = 0;
																					goto IL_03f2;
																					IL_03f2:
																					num6--;
																					goto end_IL_02f8;
																					IL_0462:
																					num6--;
																					goto end_IL_02f8;
																					IL_040e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_044e;
																				}
																				break;
																			}
																			goto IL_0580;
																			IL_0865:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02f8;
																			IL_0580:
																			if (8 > b)
																			{
																				goto IL_058e;
																			}
																			goto IL_0865;
																			IL_058e:
																			if (4 < b)
																			{
																				goto IL_059c;
																			}
																			goto IL_06d0;
																			IL_059c:
																			if (6 >= b)
																			{
																				goto IL_05aa;
																			}
																			goto IL_066a;
																			IL_05aa:
																			if (6 > b)
																			{
																				goto IL_05b5;
																			}
																			goto IL_0618;
																			IL_05b5:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_05c3;
																			IL_05c3:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_05d1;
																			IL_05d1:
																			array[num6] = 5;
																			goto IL_05df;
																			IL_05df:
																			array2[num6] = array5[*(int*)(ptr2 + num3)];
																			goto IL_05f7;
																			IL_05f7:
																			num6++;
																			goto IL_0605;
																			IL_0605:
																			ptr2 += 8;
																			goto end_IL_02f8;
																			IL_0618:
																			((int[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0657;
																			IL_0657:
																			num6 -= 3;
																			goto end_IL_02f8;
																			IL_066a:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0678;
																			IL_0678:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0686;
																			IL_0686:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_06af;
																			IL_06af:
																			ptr2 += 8;
																			goto IL_06bd;
																			IL_06bd:
																			num6--;
																			goto end_IL_02f8;
																			IL_06d0:
																			if (4 <= b)
																			{
																				goto IL_06db;
																			}
																			goto IL_071a;
																			IL_06db:
																			array5[*(int*)(ptr2 + num3)] = array2[num6 - 1];
																			goto IL_06f9;
																			IL_06f9:
																			ptr2 += 8;
																			goto IL_0707;
																			IL_0707:
																			num6--;
																			goto end_IL_02f8;
																			IL_071a:
																			if (2 >= b)
																			{
																				goto IL_0728;
																			}
																			goto IL_07fb;
																			IL_0728:
																			if (2 <= b)
																			{
																				goto IL_0733;
																			}
																			goto IL_079a;
																			IL_0733:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0773;
																			IL_0773:
																			array[num6 - 2] = 0;
																			goto IL_0787;
																			IL_0787:
																			num6--;
																			goto end_IL_02f8;
																			IL_079a:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_07a8;
																			IL_07a8:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_07b6;
																			IL_07b6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_07cf;
																			IL_07cf:
																			array[num6] = 0;
																			goto IL_07dd;
																			IL_07dd:
																			num6++;
																			goto IL_07eb;
																			IL_07eb:
																			ptr2 += 8;
																			goto end_IL_02f8;
																			IL_07fb:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0806;
																			IL_0806:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0811;
																			IL_0811:
																			array2[num6 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																			goto IL_083a;
																			IL_083a:
																			array[num6 - 1] = 5;
																			goto end_IL_02f8;
																		}
																		break;
																		IL_02c8:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02f8;
																continue;
																end_IL_02d8:
																break;
															}
															continue;
															end_IL_02e8:
															break;
														}
														continue;
														end_IL_02f8:
														break;
													}
													continue;
												}
												goto IL_091d;
												IL_091d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0878:
												break;
											}
											continue;
											end_IL_088b:
											break;
										}
										continue;
										end_IL_0895:
										break;
									}
									continue;
									end_IL_08a9:
									break;
								}
								continue;
								end_IL_08c2:
								break;
							}
							continue;
							end_IL_08d2:
							break;
						}
						continue;
						end_IL_08e2:
						break;
					}
					continue;
					end_IL_08f2:
					break;
				}
				continue;
				end_IL_0902:
				break;
			}
		}
	}

	static Class168()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 15;
					while (true)
					{
						if (num != 15)
						{
							if (num != 996)
							{
								return;
							}
							switch (num)
							{
							case 2:
								goto end_IL_0045;
							case 3:
								goto end_IL_0052;
							case 4:
								goto end_IL_005e;
							case 0:
								goto IL_006d;
							case 1:
								return;
							case 5:
								return;
							case 6:
								return;
							case 7:
								return;
							case 8:
								return;
							}
							continue;
						}
						goto IL_006d;
						IL_006d:
						num = 8;
						return;
						continue;
						end_IL_0045:
						break;
					}
					continue;
					end_IL_0052:
					break;
				}
				continue;
				end_IL_005e:
				break;
			}
		}
	}
}
