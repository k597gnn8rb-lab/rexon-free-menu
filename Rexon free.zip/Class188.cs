using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("No Controller Vibrations", "Rig", "Disables controller vibrations.", false, 51, ModType.const_0, false)]
internal class Class188 : MonoBehaviour
{
	private float float_0;

	private float float_1;

	private bool bool_0;

	private static float float_2;

	private static double double_0;

	private static int int_0;

	private static bool bool_1;

	private static IntPtr[] ObjectHandleOnStackToByteArray;

	private static IntPtr[] LengthInTextElementsOpenMethod;

	private static IntPtr[] UseDllDirectoryForDependenciesInternalOptionsMask;

	private static IntPtr[] EncodingByteBufferUCOMIEnumerable;

	private static IntPtr[] DefineLPArrayINVOCATIONFLAGSRISKYMETHOD;

	private static IntPtr[] RelativePathToNotHebrewDigit;

	private unsafe void OnEnable()
	{
		int num = 123;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[2];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ConstructorCallUnauthorizedAccessException.DynamicILGeneratorAsync);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0475:
																if (b >= 1)
																{
																	num = 36;
																	while (b <= 28)
																	{
																		while (true)
																		{
																			IL_0455:
																			if (14 >= b)
																			{
																				while (true)
																				{
																					IL_0448:
																					if (14 <= b)
																					{
																						while (true)
																						{
																							IL_042f:
																							array[num5] = 5;
																							num = 173;
																							while (true)
																							{
																								IL_0415:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_03fc:
																									num5++;
																									num = 243;
																									while (true)
																									{
																										if (num != 243)
																										{
																											if (num != 1224)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 48:
																												goto IL_03fc;
																											case 173:
																												goto IL_0415;
																											case 20:
																											case 132:
																												goto IL_042f;
																											case 113:
																												goto IL_0448;
																											case 165:
																												goto IL_0455;
																											case 36:
																												goto IL_0465;
																											case 226:
																												goto IL_0475;
																											case 129:
																												goto end_IL_0475;
																											case 162:
																											case 231:
																												goto end_IL_0488;
																											case 89:
																												goto IL_04a3;
																											case 41:
																												goto IL_04b1;
																											case 119:
																												goto IL_04bc;
																											case 49:
																											case 136:
																												goto IL_04cf;
																											case 98:
																												goto IL_0518;
																											case 5:
																												goto IL_052c;
																											case 153:
																												goto IL_053f;
																											case 135:
																												goto IL_054d;
																											case 12:
																												goto IL_055b;
																											case 46:
																												goto IL_0569;
																											case 166:
																												goto IL_057c;
																											case 24:
																											case 124:
																												goto IL_0587;
																											case 127:
																												goto IL_05b0;
																											case 146:
																												goto IL_05be;
																											case 23:
																												goto IL_05d1;
																											case 43:
																												goto IL_05dc;
																											case 50:
																											case 103:
																												goto IL_05ea;
																											case 139:
																												goto IL_060c;
																											case 161:
																												goto IL_061f;
																											case 160:
																												goto IL_062d;
																											case 45:
																											case 95:
																												goto IL_063b;
																											case 205:
																												goto IL_067d;
																											case 130:
																											case 190:
																												goto IL_0688;
																											case 6:
																												goto IL_0696;
																											case 187:
																												goto IL_06b4;
																											case 51:
																												goto IL_06c7;
																											case 31:
																												goto IL_06d5;
																											case 212:
																												goto IL_06e8;
																											case 40:
																												goto IL_06fc;
																											case 217:
																												goto IL_070f;
																											case 191:
																												goto IL_071d;
																											case 81:
																											case 142:
																												goto IL_0728;
																											case 91:
																												goto IL_0768;
																											case 93:
																												goto IL_077c;
																											case 2:
																												goto IL_078f;
																											case 4:
																												goto IL_07a6;
																											case 7:
																											case 108:
																												goto IL_07b4;
																											case 198:
																												goto IL_07c2;
																											case 167:
																												goto IL_07ea;
																											case 52:
																												goto IL_07f8;
																											case 221:
																												goto IL_0808;
																											case 219:
																											case 222:
																												goto IL_0824;
																											case 215:
																												goto IL_0842;
																											case 172:
																												goto IL_0850;
																											case 152:
																											case 225:
																												goto IL_0863;
																											case 209:
																												goto IL_08a3;
																											case 155:
																												goto IL_08c0;
																											case 228:
																												goto IL_08d3;
																											case 126:
																												goto IL_08dd;
																											case 192:
																												goto IL_08eb;
																											case 234:
																												goto IL_08fe;
																											case 30:
																											case 176:
																												goto IL_0909;
																											case 37:
																												goto IL_096b;
																											case 169:
																												goto IL_097e;
																											case 183:
																												goto IL_0989;
																											case 56:
																											case 97:
																												goto IL_0997;
																											case 168:
																												goto IL_09aa;
																											case 202:
																												goto IL_09b8;
																											case 1:
																											case 223:
																												goto IL_09c6;
																											case 230:
																												goto IL_0a06;
																											case 13:
																												goto IL_0a1a;
																											case 236:
																												goto IL_0a2d;
																											case 174:
																												goto IL_0a3b;
																											case 163:
																												goto IL_0a61;
																											case 117:
																												goto IL_0a6f;
																											case 67:
																											case 101:
																												goto IL_0a7a;
																											case 78:
																												goto IL_0ab8;
																											case 151:
																												goto IL_0acc;
																											case 102:
																												goto IL_0adf;
																											case 99:
																												goto IL_0aed;
																											case 17:
																											case 92:
																												goto IL_0af8;
																											case 112:
																												goto IL_0b4a;
																											case 105:
																												goto IL_0b5d;
																											case 62:
																												goto IL_0b68;
																											case 9:
																											case 54:
																												goto IL_0b76;
																											case 158:
																												goto IL_0b80;
																											case 64:
																												goto IL_0b97;
																											case 181:
																												goto IL_0baa;
																											case 104:
																												goto IL_0bb8;
																											case 35:
																											case 55:
																												goto IL_0bc6;
																											case 189:
																												goto IL_0bda;
																											case 116:
																												goto IL_0c27;
																											case 66:
																												goto IL_0c35;
																											case 118:
																												goto IL_0c48;
																											case 79:
																												goto IL_0c56;
																											case 106:
																												goto IL_0c61;
																											case 70:
																												goto IL_0c6f;
																											case 61:
																											case 157:
																												goto IL_0c7d;
																											case 15:
																												goto IL_0c95;
																											case 27:
																												goto IL_0ca3;
																											case 34:
																												goto IL_0cb1;
																											case 29:
																											case 68:
																												goto IL_0ccd;
																											case 178:
																												goto IL_0d0b;
																											case 75:
																												goto IL_0d1f;
																											case 22:
																												goto IL_0d32;
																											case 204:
																												goto IL_0d40;
																											case 184:
																											case 213:
																												goto IL_0d4e;
																											case 140:
																												goto IL_0d7c;
																											case 0:
																												goto IL_0d98;
																											case 143:
																												goto IL_0da6;
																											case 156:
																												goto IL_0db4;
																											case 100:
																											case 148:
																												goto IL_0dbf;
																											case 63:
																												goto IL_0ddb;
																											case 188:
																												goto IL_0de9;
																											case 8:
																											case 71:
																												goto IL_0df7;
																											case 195:
																												goto IL_0e25;
																											case 233:
																												goto IL_0e38;
																											case 185:
																												goto IL_0e46;
																											case 203:
																												goto IL_0e59;
																											case 114:
																												goto IL_0e67;
																											case 144:
																												goto IL_0e75;
																											case 121:
																											case 206:
																												goto IL_0e80;
																											case 111:
																												goto IL_0eae;
																											case 96:
																												goto IL_0ec1;
																											case 21:
																												goto IL_0ecf;
																											case 120:
																											case 200:
																												goto IL_0ee6;
																											case 133:
																												goto IL_0f14;
																											case 19:
																												goto IL_0f27;
																											case 128:
																												goto IL_0f35;
																											case 83:
																											case 147:
																												goto IL_0f43;
																											case 72:
																												goto IL_0f5d;
																											case 194:
																												goto IL_0f6b;
																											case 38:
																												goto IL_0f79;
																											case 69:
																											case 94:
																												goto IL_0f92;
																											case 186:
																												goto IL_0fc0;
																											case 3:
																											case 11:
																											case 16:
																											case 18:
																											case 32:
																											case 39:
																											case 42:
																											case 53:
																											case 59:
																											case 60:
																											case 65:
																											case 74:
																											case 77:
																											case 85:
																											case 88:
																											case 90:
																											case 110:
																											case 134:
																											case 137:
																											case 138:
																											case 164:
																											case 171:
																											case 179:
																											case 197:
																											case 201:
																											case 207:
																											case 208:
																											case 210:
																											case 211:
																											case 218:
																											case 220:
																												goto end_IL_03e9;
																											case 10:
																											case 14:
																											case 25:
																											case 26:
																											case 44:
																											case 47:
																											case 57:
																											case 58:
																											case 73:
																											case 76:
																											case 80:
																											case 82:
																											case 84:
																											case 86:
																											case 107:
																											case 109:
																											case 115:
																											case 125:
																											case 131:
																											case 141:
																											case 154:
																											case 159:
																											case 175:
																											case 177:
																											case 180:
																											case 193:
																											case 196:
																											case 199:
																											case 214:
																											case 216:
																											case 229:
																												goto end_IL_0498;
																											case 28:
																												goto end_IL_0fe3;
																											case 145:
																												goto end_IL_0ff6;
																											case 150:
																												goto end_IL_1000;
																											case 227:
																												goto end_IL_100b;
																											case 170:
																												goto end_IL_101b;
																											case 33:
																											case 182:
																												goto end_IL_102b;
																											case 224:
																												goto end_IL_103b;
																											case 232:
																											case 235:
																												goto end_IL_104b;
																											case 122:
																												goto end_IL_105b;
																											case 123:
																												goto end_IL_106b;
																											case 87:
																											case 149:
																												return;
																											}
																											continue;
																										}
																										ptr2 += 8;
																										goto end_IL_0498;
																										continue;
																										end_IL_03e9:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_04a3;
																					IL_0a06:
																					array[num5 - 2] = 0;
																					goto IL_0a1a;
																					IL_04a3:
																					if (7 >= b)
																					{
																						goto IL_04b1;
																					}
																					goto IL_053f;
																					IL_04b1:
																					if (7 > b)
																					{
																						goto IL_04bc;
																					}
																					goto IL_04cf;
																					IL_04bc:
																					if (3 >= b)
																					{
																						goto IL_057c;
																					}
																					goto IL_070f;
																					IL_057c:
																					if (3 <= b)
																					{
																						goto IL_0587;
																					}
																					goto IL_05d1;
																					IL_0587:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05b0;
																					IL_05b0:
																					ptr2 += 8;
																					goto IL_05be;
																					IL_05be:
																					num5--;
																					goto end_IL_0498;
																					IL_05d1:
																					if (1 >= b)
																					{
																						goto IL_05dc;
																					}
																					goto IL_061f;
																					IL_05dc:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_05ea;
																					IL_05ea:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 139;
																					goto IL_060c;
																					IL_060c:
																					array[num5] = 0;
																					goto IL_0a2d;
																					IL_0a2d:
																					num5++;
																					goto IL_0a3b;
																					IL_0a3b:
																					ptr2 += 8;
																					goto end_IL_0498;
																					IL_061f:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_062d;
																					IL_062d:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_063b;
																					IL_063b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_06e8;
																					IL_06e8:
																					array[num5 - 2] = 0;
																					goto IL_06fc;
																					IL_06fc:
																					num5--;
																					goto end_IL_0498;
																					IL_070f:
																					if (5 >= b)
																					{
																						goto IL_071d;
																					}
																					goto IL_07ea;
																					IL_071d:
																					if (5 <= b)
																					{
																						goto IL_0728;
																					}
																					goto IL_078f;
																					IL_0728:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0768;
																					IL_0768:
																					array[num5 - 2] = 0;
																					goto IL_077c;
																					IL_077c:
																					num5--;
																					goto end_IL_0498;
																					IL_078f:
																					if (4 < b)
																					{
																						break;
																					}
																					num = 4;
																					goto IL_07a6;
																					IL_0a1a:
																					num5--;
																					goto end_IL_0498;
																					IL_07a6:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_07b4;
																					IL_07b4:
																					array[num5] = 0;
																					goto IL_07c2;
																					IL_07c2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_08d3;
																					IL_08d3:
																					array2[num5] = null;
																					goto IL_08dd;
																					IL_08dd:
																					num5++;
																					goto IL_08eb;
																					IL_08eb:
																					ptr2 += 8;
																					goto end_IL_0498;
																					IL_07ea:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_07f8;
																					IL_07f8:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0863;
																					IL_0863:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_08a3;
																					IL_08a3:
																					array[num5 - 2] = 0;
																					num = 155;
																					goto IL_08c0;
																					IL_08c0:
																					num5--;
																					goto end_IL_0498;
																					IL_04cf:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 98;
																					goto IL_0518;
																					IL_0518:
																					array[num5 - 2] = 0;
																					goto IL_052c;
																					IL_052c:
																					num5--;
																					goto end_IL_0498;
																					IL_053f:
																					if (10 < b)
																					{
																						goto IL_054d;
																					}
																					goto IL_08fe;
																					IL_054d:
																					if (12 < b)
																					{
																						goto IL_055b;
																					}
																					goto IL_067d;
																					IL_055b:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0569;
																					IL_0569:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0824;
																					IL_0824:
																					array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																					goto IL_0842;
																					IL_0842:
																					ptr2 += 8;
																					goto IL_0850;
																					IL_0850:
																					num5--;
																					goto end_IL_0498;
																					IL_067d:
																					if (12 <= b)
																					{
																						goto IL_0688;
																					}
																					goto IL_06c7;
																					IL_0688:
																					array[num5] = 5;
																					goto IL_0696;
																					IL_0696:
																					array2[num5] = ((delegate*<GorillaTagger>)ObjectHandleOnStackToByteArray[*(int*)(ptr2 + num3)])();
																					goto IL_06b4;
																					IL_06b4:
																					num5++;
																					goto IL_0808;
																					IL_0808:
																					ptr2 += 8;
																					num = 57;
																					goto end_IL_0498;
																					IL_06c7:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_06d5;
																					IL_06d5:
																					if (11 > b)
																					{
																						break;
																					}
																					goto end_IL_0498;
																					IL_08fe:
																					if (10 <= b)
																					{
																						goto IL_0909;
																					}
																					goto IL_097e;
																					IL_0909:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_096b;
																					IL_096b:
																					num5 -= 2;
																					goto end_IL_0498;
																					IL_097e:
																					if (8 >= b)
																					{
																						goto IL_0989;
																					}
																					goto IL_09aa;
																					IL_0989:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0997;
																					IL_0997:
																					num5--;
																					goto end_IL_0498;
																					IL_09aa:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_09b8;
																					IL_09b8:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_09c6;
																					IL_09c6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0a06;
																				}
																				break;
																			}
																			goto IL_0a61;
																			IL_0f79:
																			ptr2 += 8;
																			goto end_IL_0498;
																			IL_0a61:
																			if (21 >= b)
																			{
																				goto IL_0a6f;
																			}
																			goto IL_0d98;
																			IL_0a6f:
																			if (21 <= b)
																			{
																				goto IL_0a7a;
																			}
																			goto IL_0adf;
																			IL_0a7a:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<GorillaTagger, float>)ObjectHandleOnStackToByteArray[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																			goto IL_0ab8;
																			IL_0ab8:
																			array[num5 - 1] = 3;
																			goto IL_0acc;
																			IL_0acc:
																			ptr2 += 8;
																			goto end_IL_0498;
																			IL_0adf:
																			if (17 >= b)
																			{
																				goto IL_0aed;
																			}
																			goto IL_0c48;
																			IL_0aed:
																			if (17 <= b)
																			{
																				goto IL_0af8;
																			}
																			goto IL_0b5d;
																			IL_0af8:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0b4a;
																			IL_0b4a:
																			num5--;
																			goto end_IL_0498;
																			IL_0b5d:
																			if (15 >= b)
																			{
																				goto IL_0b68;
																			}
																			goto IL_0baa;
																			IL_0b68:
																			if (15 > b)
																			{
																				break;
																			}
																			goto IL_0b76;
																			IL_0b76:
																			array2[num5] = null;
																			goto IL_0b80;
																			IL_0b80:
																			array[num5] = 5;
																			num = 64;
																			goto IL_0b97;
																			IL_0b97:
																			num5++;
																			goto end_IL_0498;
																			IL_0baa:
																			if (16 < b)
																			{
																				break;
																			}
																			goto IL_0bb8;
																			IL_0bb8:
																			if (16 > b)
																			{
																				break;
																			}
																			goto IL_0bc6;
																			IL_0bc6:
																			array[num5 - 2] = 0;
																			goto IL_0bda;
																			IL_0bda:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ObjectHandleOnStackToByteArray[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																			goto IL_0c27;
																			IL_0c27:
																			num5--;
																			goto IL_0c35;
																			IL_0c35:
																			ptr2 += 8;
																			goto end_IL_0498;
																			IL_0c48:
																			if (19 >= b)
																			{
																				goto IL_0c56;
																			}
																			goto IL_0d32;
																			IL_0c56:
																			if (19 > b)
																			{
																				goto IL_0c61;
																			}
																			num = 68;
																			goto IL_0ccd;
																			IL_0c61:
																			if (18 < b)
																			{
																				break;
																			}
																			goto IL_0c6f;
																			IL_0c6f:
																			if (18 > b)
																			{
																				break;
																			}
																			goto IL_0c7d;
																			IL_0c7d:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0c95;
																			IL_0c95:
																			array[num5] = 5;
																			goto IL_0ca3;
																			IL_0ca3:
																			num5++;
																			goto IL_0cb1;
																			IL_0cb1:
																			ptr2 += 8;
																			goto end_IL_0498;
																			IL_0f92:
																			((GorillaTagger)array2[num5 - 2]).tapHapticStrength = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0fc0;
																			IL_0ccd:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<GorillaTagger, float>)ObjectHandleOnStackToByteArray[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																			goto IL_0d0b;
																			IL_0d0b:
																			array[num5 - 1] = 3;
																			goto IL_0d1f;
																			IL_0d1f:
																			ptr2 += 8;
																			goto end_IL_0498;
																			IL_0d32:
																			if (20 < b)
																			{
																				break;
																			}
																			goto IL_0d40;
																			IL_0d40:
																			if (20 > b)
																			{
																				break;
																			}
																			goto IL_0d4e;
																			IL_0d4e:
																			((Class188)array2[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0d7c;
																			IL_0d7c:
																			num5 -= 2;
																			num = 10;
																			goto end_IL_0498;
																			IL_0d98:
																			if (25 < b)
																			{
																				goto IL_0da6;
																			}
																			goto IL_0e59;
																			IL_0da6:
																			if (27 >= b)
																			{
																				goto IL_0db4;
																			}
																			goto IL_0e38;
																			IL_0db4:
																			if (27 <= b)
																			{
																				goto IL_0dbf;
																			}
																			goto IL_0ddb;
																			IL_0dbf:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0498;
																			IL_0ddb:
																			if (26 < b)
																			{
																				break;
																			}
																			goto IL_0de9;
																			IL_0de9:
																			if (26 > b)
																			{
																				break;
																			}
																			goto IL_0df7;
																			IL_0df7:
																			((GorillaTagger)array2[num5 - 2]).tapHapticDuration = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0e25;
																			IL_0e25:
																			num5 -= 2;
																			goto end_IL_0498;
																			IL_0e38:
																			if (28 < b)
																			{
																				break;
																			}
																			goto IL_0e46;
																			IL_0e46:
																			if (28 > b)
																			{
																			}
																			break;
																			IL_0e59:
																			if (25 > b)
																			{
																				goto IL_0e67;
																			}
																			num = 69;
																			goto IL_0f92;
																			IL_0e67:
																			if (23 >= b)
																			{
																				goto IL_0e75;
																			}
																			goto IL_0f27;
																			IL_0e75:
																			if (23 <= b)
																			{
																				goto IL_0e80;
																			}
																			goto IL_0ec1;
																			IL_0e80:
																			((Class188)array2[num5 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_0eae;
																			IL_0eae:
																			num5 -= 2;
																			goto end_IL_0498;
																			IL_0ec1:
																			if (22 < b)
																			{
																				break;
																			}
																			goto IL_0ecf;
																			IL_0ecf:
																			if (22 > b)
																			{
																				break;
																			}
																			num = 200;
																			goto IL_0ee6;
																			IL_0fc0:
																			num5 -= 2;
																			goto end_IL_0498;
																			IL_0ee6:
																			((Class188)array2[num5 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0f14;
																			IL_0f14:
																			num5 -= 2;
																			goto end_IL_0498;
																			IL_0f27:
																			if (24 < b)
																			{
																				break;
																			}
																			goto IL_0f35;
																			IL_0f35:
																			if (24 > b)
																			{
																				break;
																			}
																			goto IL_0f43;
																			IL_0f43:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																			goto IL_0f5d;
																			IL_0f5d:
																			array[num5] = 3;
																			goto IL_0f6b;
																			IL_0f6b:
																			num5++;
																			goto IL_0f79;
																		}
																		break;
																		IL_0465:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0498;
																continue;
																end_IL_0475:
																break;
															}
															continue;
															end_IL_0488:
															break;
														}
														continue;
														end_IL_0498:
														break;
													}
													continue;
													end_IL_0fe3:
													break;
												}
												continue;
												end_IL_0ff6:
												break;
											}
											continue;
											end_IL_1000:
											break;
										}
										continue;
										end_IL_100b:
										break;
									}
									continue;
									end_IL_101b:
									break;
								}
								continue;
								end_IL_102b:
								break;
							}
							continue;
							end_IL_103b:
							break;
						}
						continue;
						end_IL_104b:
						break;
					}
					continue;
					end_IL_105b:
					break;
				}
				continue;
				end_IL_106b:
				break;
			}
		}
	}

	private unsafe void Update()
	{
		int num = 52;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					num = 84;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getStackTraceGetTypes.SequenceControl);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														num = 178;
														while (true)
														{
															IL_059c:
															if (b >= 1)
															{
																while (b <= 37)
																{
																	while (true)
																	{
																		IL_057f:
																		if (19 < b)
																		{
																			while (true)
																			{
																				IL_056f:
																				if (28 >= b)
																				{
																					while (true)
																					{
																						IL_055f:
																						if (28 > b)
																						{
																							while (true)
																							{
																								IL_054f:
																								if (23 < b)
																								{
																									while (true)
																									{
																										IL_053f:
																										if (25 >= b)
																										{
																											while (true)
																											{
																												IL_052f:
																												if (25 > b)
																												{
																													while (24 >= b)
																													{
																														num = 315;
																														while (true)
																														{
																															if (num != 315)
																															{
																																if (num != 1296)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 236:
																																	goto IL_051c;
																																case 12:
																																	goto IL_052f;
																																case 287:
																																	goto IL_053f;
																																case 106:
																																	goto IL_054f;
																																case 38:
																																	goto IL_055f;
																																case 273:
																																	goto IL_056f;
																																case 129:
																																	goto IL_057f;
																																case 217:
																																	goto IL_058c;
																																case 178:
																																	goto IL_059c;
																																case 77:
																																	goto end_IL_059c;
																																case 14:
																																case 138:
																																	goto end_IL_05ac;
																																case 45:
																																	goto IL_05de;
																																case 22:
																																	goto IL_05e9;
																																case 79:
																																	goto IL_0604;
																																case 122:
																																	goto IL_060f;
																																case 92:
																																	goto IL_061d;
																																case 43:
																																case 186:
																																	goto IL_0630;
																																case 46:
																																	goto IL_0649;
																																case 187:
																																	goto IL_065c;
																																case 112:
																																	goto IL_0667;
																																case 185:
																																	goto IL_0675;
																																case 171:
																																	goto IL_0688;
																																case 154:
																																	goto IL_0693;
																																case 128:
																																case 165:
																																	goto IL_06a1;
																																case 63:
																																	goto IL_06af;
																																case 169:
																																	goto IL_06cd;
																																case 197:
																																	goto IL_06db;
																																case 224:
																																	goto IL_06ee;
																																case 66:
																																	goto IL_06fc;
																																case 227:
																																	goto IL_070f;
																																case 59:
																																case 177:
																																	goto IL_071d;
																																case 142:
																																	goto IL_075e;
																																case 206:
																																	goto IL_0772;
																																case 228:
																																	goto IL_0785;
																																case 30:
																																case 202:
																																	goto IL_0793;
																																case 102:
																																	goto IL_07d3;
																																case 148:
																																	goto IL_07f0;
																																case 164:
																																case 232:
																																	goto IL_0803;
																																case 152:
																																	goto IL_0843;
																																case 80:
																																	goto IL_0857;
																																case 233:
																																	goto IL_0873;
																																case 26:
																																	goto IL_087e;
																																case 6:
																																	goto IL_0891;
																																case 245:
																																	goto IL_089f;
																																case 114:
																																case 223:
																																	goto IL_08ad;
																																case 231:
																																case 248:
																																	goto IL_08cb;
																																case 71:
																																	goto IL_08ed;
																																case 68:
																																case 250:
																																	goto IL_0909;
																																case 161:
																																case 268:
																																	goto IL_0921;
																																case 1:
																																	goto IL_0935;
																																case 211:
																																	goto IL_0974;
																																case 274:
																																	goto IL_0987;
																																case 218:
																																	goto IL_0995;
																																case 121:
																																	goto IL_09a3;
																																case 34:
																																case 244:
																																	goto IL_09ae;
																																case 117:
																																	goto IL_09ee;
																																case 56:
																																	goto IL_0a02;
																																case 28:
																																	goto IL_0a15;
																																case 176:
																																	goto IL_0a28;
																																case 18:
																																	goto IL_0a33;
																																case 219:
																																	goto IL_0a41;
																																case 282:
																																	goto IL_0a51;
																																case 82:
																																case 235:
																																	goto IL_0a68;
																																case 119:
																																	goto IL_0aa8;
																																case 57:
																																	goto IL_0abc;
																																case 249:
																																case 284:
																																	goto IL_0acf;
																																case 289:
																																	goto IL_0ae2;
																																case 100:
																																	goto IL_0af0;
																																case 293:
																																	goto IL_0b0c;
																																case 73:
																																case 172:
																																	goto IL_0b1a;
																																case 125:
																																	goto IL_0b5a;
																																case 120:
																																	goto IL_0b6e;
																																case 163:
																																case 294:
																																	goto IL_0b81;
																																case 95:
																																	goto IL_0bd3;
																																case 296:
																																	goto IL_0be6;
																																case 98:
																																case 198:
																																	goto IL_0bf4;
																																case 205:
																																	goto IL_0c08;
																																case 81:
																																	goto IL_0c5c;
																																case 298:
																																	goto IL_0c6f;
																																case 297:
																																	goto IL_0c7d;
																																case 299:
																																	goto IL_0c90;
																																case 301:
																																	goto IL_0ca3;
																																case 277:
																																	goto IL_0cb1;
																																case 126:
																																case 181:
																																	goto IL_0cbf;
																																case 133:
																																	goto IL_0d21;
																																case 302:
																																	goto IL_0d34;
																																case 76:
																																case 222:
																																	goto IL_0d3f;
																																case 110:
																																	goto IL_0d93;
																																case 252:
																																	goto IL_0da1;
																																case 16:
																																	goto IL_0dbd;
																																case 139:
																																	goto IL_0dc8;
																																case 19:
																																	goto IL_0dd6;
																																case 36:
																																case 179:
																																	goto IL_0de4;
																																case 192:
																																	goto IL_0e07;
																																case 147:
																																	goto IL_0e15;
																																case 49:
																																	goto IL_0e23;
																																case 226:
																																	goto IL_0e3f;
																																case 0:
																																	goto IL_0e4d;
																																case 40:
																																	goto IL_0e5b;
																																case 54:
																																case 78:
																																	goto IL_0e69;
																																case 230:
																																	goto IL_0ea9;
																																case 130:
																																	goto IL_0ebd;
																																case 303:
																																	goto IL_0ed0;
																																case 281:
																																	goto IL_0ede;
																																case 200:
																																	goto IL_0eec;
																																case 2:
																																case 108:
																																	goto IL_0ef7;
																																case 140:
																																	goto IL_0f37;
																																case 263:
																																	goto IL_0f4b;
																																case 86:
																																	goto IL_0f5e;
																																case 156:
																																	goto IL_0f6c;
																																case 145:
																																case 254:
																																	goto IL_0f7a;
																																case 32:
																																	goto IL_0f93;
																																case 264:
																																	goto IL_0fa1;
																																case 144:
																																	goto IL_0faf;
																																case 239:
																																	goto IL_0fc2;
																																case 150:
																																	goto IL_0fd0;
																																case 53:
																																case 174:
																																	goto IL_0fde;
																																case 170:
																																	goto IL_1007;
																																case 278:
																																	goto IL_1015;
																																case 189:
																																case 213:
																																	goto IL_1031;
																																case 201:
																																	goto IL_103f;
																																case 141:
																																	goto IL_1062;
																																case 175:
																																	goto IL_106c;
																																case 151:
																																	goto IL_107a;
																																case 271:
																																case 305:
																																	goto IL_108d;
																																case 72:
																																	goto IL_10a1;
																																case 132:
																																	goto IL_10e0;
																																case 306:
																																	goto IL_10f3;
																																case 253:
																																case 276:
																																	goto IL_1114;
																																case 88:
																																	goto IL_1128;
																																case 180:
																																	goto IL_1167;
																																case 242:
																																	goto IL_117a;
																																case 99:
																																	goto IL_1185;
																																case 3:
																																case 31:
																																	goto IL_1193;
																																case 64:
																																	goto IL_11b1;
																																case 21:
																																	goto IL_11bf;
																																case 42:
																																	goto IL_11cd;
																																case 204:
																																	goto IL_11e9;
																																case 285:
																																	goto IL_11f7;
																																case 8:
																																case 272:
																																	goto IL_1205;
																																case 238:
																																	goto IL_1233;
																																case 257:
																																	goto IL_1246;
																																case 259:
																																	goto IL_1254;
																																case 25:
																																case 44:
																																	goto IL_125f;
																																case 229:
																																	goto IL_129f;
																																case 91:
																																	goto IL_12b3;
																																case 124:
																																	goto IL_12cf;
																																case 136:
																																	goto IL_12dd;
																																case 207:
																																	goto IL_12e8;
																																case 60:
																																	goto IL_12f6;
																																case 9:
																																case 196:
																																	goto IL_1304;
																																case 215:
																																	goto IL_130e;
																																case 109:
																																	goto IL_131c;
																																case 135:
																																case 195:
																																	goto IL_1338;
																																case 67:
																																	goto IL_134c;
																																case 246:
																																	goto IL_1399;
																																case 50:
																																	goto IL_13b0;
																																case 295:
																																	goto IL_13cc;
																																case 269:
																																	goto IL_13d7;
																																case 75:
																																	goto IL_13e5;
																																case 225:
																																case 307:
																																	goto IL_13f3;
																																case 183:
																																	goto IL_142a;
																																case 97:
																																	goto IL_1446;
																																case 83:
																																case 94:
																																	goto IL_145d;
																																case 55:
																																	goto IL_1471;
																																case 37:
																																	goto IL_14b0;
																																case 104:
																																	goto IL_14c3;
																																case 89:
																																	goto IL_14d1;
																																case 5:
																																case 214:
																																	goto IL_14dc;
																																case 155:
																																	goto IL_14f0;
																																case 243:
																																	goto IL_152f;
																																case 123:
																																	goto IL_1542;
																																case 153:
																																	goto IL_1550;
																																case 241:
																																case 261:
																																	goto IL_1567;
																																case 234:
																																	goto IL_157b;
																																case 216:
																																	goto IL_15ba;
																																case 85:
																																	goto IL_15ca;
																																case 255:
																																	goto IL_15d5;
																																case 93:
																																case 275:
																																	goto end_IL_0509;
																																case 137:
																																	goto IL_15f9;
																																case 167:
																																	goto IL_1604;
																																case 17:
																																case 20:
																																case 24:
																																case 27:
																																case 41:
																																case 58:
																																case 65:
																																case 70:
																																case 90:
																																case 101:
																																case 103:
																																case 113:
																																case 115:
																																case 116:
																																case 118:
																																case 131:
																																case 143:
																																case 149:
																																case 160:
																																case 162:
																																case 168:
																																case 173:
																																case 182:
																																case 184:
																																case 190:
																																case 193:
																																case 194:
																																case 199:
																																case 209:
																																case 240:
																																case 256:
																																case 266:
																																case 267:
																																case 280:
																																case 283:
																																case 286:
																																case 288:
																																case 290:
																																case 291:
																																case 292:
																																	goto end_IL_051c;
																																case 4:
																																case 7:
																																case 10:
																																case 13:
																																case 15:
																																case 23:
																																case 29:
																																case 33:
																																case 35:
																																case 39:
																																case 48:
																																case 61:
																																case 62:
																																case 69:
																																case 74:
																																case 87:
																																case 105:
																																case 107:
																																case 111:
																																case 127:
																																case 134:
																																case 146:
																																case 158:
																																case 159:
																																case 166:
																																case 188:
																																case 191:
																																case 203:
																																case 210:
																																case 212:
																																case 220:
																																case 221:
																																case 247:
																																case 251:
																																case 262:
																																case 265:
																																case 270:
																																case 300:
																																case 304:
																																case 308:
																																	goto end_IL_05c5;
																																case 157:
																																	goto end_IL_1622;
																																case 258:
																																	goto end_IL_1635;
																																case 11:
																																	goto end_IL_163f;
																																case 260:
																																case 279:
																																	goto end_IL_164a;
																																case 208:
																																	goto end_IL_165a;
																																case 84:
																																	goto end_IL_166a;
																																case 47:
																																	goto end_IL_167a;
																																case 51:
																																	goto end_IL_168a;
																																case 52:
																																	goto end_IL_16a3;
																																case 96:
																																case 237:
																																	return;
																																}
																																continue;
																															}
																															if (24 > b)
																															{
																																goto end_IL_051c;
																															}
																															goto IL_1114;
																															IL_1114:
																															array[num6 - 1] = 3;
																															goto IL_1128;
																															IL_1167:
																															ptr2 += 8;
																															goto end_IL_05c5;
																															IL_1128:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																															goto IL_1167;
																															continue;
																															end_IL_0509:
																															break;
																														}
																														goto IL_15e0;
																														continue;
																														end_IL_051c:
																														break;
																														IL_051c:;
																													}
																													break;
																												}
																												num = 164;
																												goto IL_0803;
																												IL_0843:
																												array[num6 - 2] = 3;
																												goto IL_0857;
																												IL_0857:
																												num6--;
																												num = 33;
																												goto end_IL_05c5;
																												IL_0803:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0843;
																											}
																											break;
																										}
																										goto IL_117a;
																										IL_1233:
																										num6 -= 2;
																										goto end_IL_05c5;
																										IL_117a:
																										if (26 >= b)
																										{
																											goto IL_1185;
																										}
																										goto IL_11e9;
																										IL_1185:
																										if (26 > b)
																										{
																											break;
																										}
																										goto IL_1193;
																										IL_1193:
																										array2[num6] = ((delegate*<GorillaTagger>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])();
																										goto IL_11b1;
																										IL_11b1:
																										array[num6] = 5;
																										goto IL_11bf;
																										IL_11bf:
																										num6++;
																										goto IL_11cd;
																										IL_11cd:
																										ptr2 += 8;
																										num = 191;
																										goto end_IL_05c5;
																										IL_11e9:
																										if (27 < b)
																										{
																											break;
																										}
																										goto IL_11f7;
																										IL_11f7:
																										if (27 > b)
																										{
																											break;
																										}
																										goto IL_1205;
																										IL_1205:
																										((GorillaTagger)array2[num6 - 2]).tapHapticStrength = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_1233;
																									}
																									break;
																								}
																								goto IL_0d34;
																								IL_10a1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_10e0;
																								IL_0d34:
																								if (23 <= b)
																								{
																									goto IL_0d3f;
																								}
																								goto IL_0dbd;
																								IL_0d3f:
																								((delegate*<float, float, OVRInput.Controller, void>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])), *(OVRInput.Controller*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_0d93;
																								IL_0d93:
																								num6 -= 3;
																								goto IL_0da1;
																								IL_0da1:
																								ptr2 += 8;
																								num = 304;
																								goto end_IL_05c5;
																								IL_0dbd:
																								if (21 < b)
																								{
																									goto IL_0dc8;
																								}
																								num = 226;
																								goto IL_0e3f;
																								IL_0dc8:
																								if (22 < b)
																								{
																									break;
																								}
																								goto IL_0dd6;
																								IL_0dd6:
																								if (22 > b)
																								{
																									break;
																								}
																								goto IL_0de4;
																								IL_0de4:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																								num = 192;
																								goto IL_0e07;
																								IL_0e07:
																								array[num6] = 3;
																								goto IL_0e15;
																								IL_0e15:
																								num6++;
																								goto IL_0e23;
																								IL_0e23:
																								ptr2 += 8;
																								goto end_IL_05c5;
																								IL_10e0:
																								ptr2 += 8;
																								goto end_IL_05c5;
																								IL_0e3f:
																								if (21 > b)
																								{
																									goto IL_0e4d;
																								}
																								goto IL_108d;
																								IL_0e4d:
																								if (20 < b)
																								{
																									break;
																								}
																								goto IL_0e5b;
																								IL_0e5b:
																								if (20 > b)
																								{
																									break;
																								}
																								goto IL_0e69;
																								IL_0e69:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0ea9;
																								IL_0ea9:
																								array[num6 - 2] = 3;
																								goto IL_0ebd;
																								IL_0ebd:
																								num6--;
																								goto end_IL_05c5;
																								IL_108d:
																								array[num6 - 1] = 0;
																								goto IL_10a1;
																							}
																							break;
																						}
																						goto IL_0921;
																						IL_0974:
																						ptr2 += 8;
																						goto end_IL_05c5;
																						IL_0921:
																						array[num6 - 1] = 3;
																						goto IL_0935;
																						IL_0935:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0974;
																					}
																					break;
																				}
																				goto IL_1246;
																				IL_15ca:
																				if (36 >= b)
																				{
																					goto IL_15d5;
																				}
																				goto IL_15f9;
																				IL_1246:
																				if (33 >= b)
																				{
																					goto IL_1254;
																				}
																				goto IL_14c3;
																				IL_1254:
																				if (33 <= b)
																				{
																					goto IL_125f;
																				}
																				goto IL_12cf;
																				IL_125f:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_129f;
																				IL_129f:
																				array[num6 - 2] = 3;
																				goto IL_12b3;
																				IL_12b3:
																				num6--;
																				num = 87;
																				goto end_IL_05c5;
																				IL_12cf:
																				if (30 >= b)
																				{
																					goto IL_12dd;
																				}
																				goto IL_13cc;
																				IL_12dd:
																				if (30 > b)
																				{
																					goto IL_12e8;
																				}
																				num = 195;
																				goto IL_1338;
																				IL_12e8:
																				if (29 < b)
																				{
																					break;
																				}
																				goto IL_12f6;
																				IL_12f6:
																				if (29 > b)
																				{
																					break;
																				}
																				goto IL_1304;
																				IL_1304:
																				array2[num6] = null;
																				goto IL_130e;
																				IL_130e:
																				array[num6] = 5;
																				goto IL_131c;
																				IL_131c:
																				num6++;
																				goto end_IL_05c5;
																				IL_15d5:
																				if (36 > b)
																				{
																					break;
																				}
																				goto IL_15e0;
																				IL_1338:
																				array[num6 - 2] = 0;
																				goto IL_134c;
																				IL_134c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_1399;
																				IL_1399:
																				num6--;
																				num = 50;
																				goto IL_13b0;
																				IL_13b0:
																				ptr2 += 8;
																				num = 188;
																				goto end_IL_05c5;
																				IL_13cc:
																				if (31 < b)
																				{
																					goto IL_13d7;
																				}
																				num = 97;
																				goto IL_1446;
																				IL_13d7:
																				if (32 < b)
																				{
																					break;
																				}
																				goto IL_13e5;
																				IL_13e5:
																				if (32 > b)
																				{
																					break;
																				}
																				goto IL_13f3;
																				IL_13f3:
																				((GorillaTagger)array2[num6 - 2]).tapHapticDuration = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				num = 183;
																				goto IL_142a;
																				IL_142a:
																				num6 -= 2;
																				goto end_IL_05c5;
																				IL_15e0:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_05c5;
																				IL_1446:
																				if (31 > b)
																				{
																					break;
																				}
																				num = 94;
																				goto IL_145d;
																				IL_15f9:
																				if (37 < b)
																				{
																					break;
																				}
																				goto IL_1604;
																				IL_145d:
																				array[num6 - 1] = 3;
																				goto IL_1471;
																				IL_1471:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_14b0;
																				IL_14b0:
																				ptr2 += 8;
																				goto end_IL_05c5;
																				IL_14c3:
																				if (35 >= b)
																				{
																					goto IL_14d1;
																				}
																				goto IL_15ca;
																				IL_14d1:
																				if (35 <= b)
																				{
																					goto IL_14dc;
																				}
																				goto IL_1542;
																				IL_14dc:
																				array[num6 - 1] = 0;
																				goto IL_14f0;
																				IL_14f0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_152f;
																				IL_152f:
																				ptr2 += 8;
																				goto end_IL_05c5;
																				IL_1542:
																				if (34 < b)
																				{
																					break;
																				}
																				goto IL_1550;
																				IL_1550:
																				if (34 > b)
																				{
																					break;
																				}
																				num = 241;
																				goto IL_1567;
																				IL_1604:
																				if (37 <= b)
																				{
																				}
																				break;
																				IL_1567:
																				array[num6 - 1] = 3;
																				goto IL_157b;
																				IL_157b:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_15ba;
																				IL_15ba:
																				ptr2 += 8;
																				goto end_IL_05c5;
																			}
																			break;
																		}
																		goto IL_05de;
																		IL_0630:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		goto IL_0649;
																		IL_05de:
																		if (19 > b)
																		{
																			goto IL_05e9;
																		}
																		num = 43;
																		goto IL_0630;
																		IL_05e9:
																		if (9 < b)
																		{
																			goto IL_0604;
																		}
																		goto IL_0785;
																		IL_0785:
																		if (9 <= b)
																		{
																			goto IL_0793;
																		}
																		goto IL_0987;
																		IL_0793:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_07d3;
																		IL_07d3:
																		array[num6 - 2] = 0;
																		num = 148;
																		goto IL_07f0;
																		IL_07f0:
																		num6--;
																		goto end_IL_05c5;
																		IL_0987:
																		if (4 < b)
																		{
																			goto IL_0995;
																		}
																		goto IL_0ed0;
																		IL_0995:
																		if (6 >= b)
																		{
																			goto IL_09a3;
																		}
																		goto IL_0a28;
																		IL_09a3:
																		if (6 <= b)
																		{
																			goto IL_09ae;
																		}
																		goto IL_0a15;
																		IL_09ae:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_09ee;
																		IL_09ee:
																		array[num6 - 2] = 0;
																		goto IL_0a02;
																		IL_0a02:
																		num6--;
																		goto end_IL_05c5;
																		IL_0a15:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_0b0c;
																		IL_0b0c:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_0b1a;
																		IL_0b1a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0b5a;
																		IL_0b5a:
																		array[num6 - 2] = 0;
																		goto IL_0b6e;
																		IL_0b6e:
																		num6--;
																		goto end_IL_05c5;
																		IL_0a28:
																		if (7 < b)
																		{
																			goto IL_0a33;
																		}
																		goto IL_0a51;
																		IL_0a33:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_0a41;
																		IL_0a41:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_0acf;
																		IL_0acf:
																		num6--;
																		goto end_IL_05c5;
																		IL_0a51:
																		if (7 > b)
																		{
																			break;
																		}
																		num = 235;
																		goto IL_0a68;
																		IL_0c6f:
																		num6++;
																		goto IL_0c7d;
																		IL_0a68:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0aa8;
																		IL_0aa8:
																		array[num6 - 2] = 0;
																		goto IL_0abc;
																		IL_0abc:
																		num6--;
																		goto end_IL_05c5;
																		IL_0ed0:
																		if (4 > b)
																		{
																			goto IL_0ede;
																		}
																		num = 189;
																		goto IL_1031;
																		IL_0ede:
																		if (2 >= b)
																		{
																			goto IL_0eec;
																		}
																		goto IL_0fc2;
																		IL_0eec:
																		if (2 <= b)
																		{
																			goto IL_0ef7;
																		}
																		goto IL_0f5e;
																		IL_0ef7:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0f37;
																		IL_0f37:
																		array[num6 - 2] = 0;
																		goto IL_0f4b;
																		IL_0f4b:
																		num6--;
																		goto end_IL_05c5;
																		IL_0f5e:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_0f6c;
																		IL_0f6c:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0f7a;
																		IL_0f7a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0f93;
																		IL_0f93:
																		array[num6] = 0;
																		goto IL_0fa1;
																		IL_0fa1:
																		num6++;
																		goto IL_0faf;
																		IL_0faf:
																		ptr2 += 8;
																		goto end_IL_05c5;
																		IL_0fc2:
																		if (3 < b)
																		{
																			break;
																		}
																		goto IL_0fd0;
																		IL_0fd0:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0fde;
																		IL_0fde:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_1007;
																		IL_1007:
																		ptr2 += 8;
																		goto IL_1015;
																		IL_1015:
																		num6--;
																		goto end_IL_05c5;
																		IL_0c7d:
																		ptr2 += 16;
																		goto end_IL_05c5;
																		IL_1031:
																		array[num6] = 0;
																		goto IL_103f;
																		IL_103f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_1062;
																		IL_1062:
																		array2[num6] = null;
																		goto IL_106c;
																		IL_106c:
																		num6++;
																		goto IL_107a;
																		IL_107a:
																		ptr2 += 8;
																		goto end_IL_05c5;
																		IL_0604:
																		if (14 >= b)
																		{
																			goto IL_060f;
																		}
																		goto IL_065c;
																		IL_060f:
																		if (14 > b)
																		{
																			goto IL_061d;
																		}
																		goto IL_0909;
																		IL_061d:
																		if (11 < b)
																		{
																			goto IL_0873;
																		}
																		goto IL_0be6;
																		IL_0be6:
																		if (11 <= b)
																		{
																			goto IL_0bf4;
																		}
																		goto IL_0ca3;
																		IL_0bf4:
																		array[num6 - 2] = 0;
																		goto IL_0c08;
																		IL_0c08:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0c5c;
																		IL_0c5c:
																		num6--;
																		goto IL_10f3;
																		IL_10f3:
																		ptr2 += 8;
																		goto end_IL_05c5;
																		IL_0ca3:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_0cb1;
																		IL_0cb1:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_0cbf;
																		IL_0cbf:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0d21;
																		IL_0d21:
																		num6 -= 2;
																		goto end_IL_05c5;
																		IL_0873:
																		if (12 >= b)
																		{
																			goto IL_087e;
																		}
																		goto IL_0891;
																		IL_087e:
																		if (12 > b)
																		{
																			break;
																		}
																		goto end_IL_05c5;
																		IL_0891:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_089f;
																		IL_089f:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_08ad;
																		IL_08ad:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0ae2;
																		IL_0ae2:
																		array[num6] = 1;
																		goto IL_0af0;
																		IL_0af0:
																		num6++;
																		num = 299;
																		goto IL_0c90;
																		IL_0c90:
																		ptr2 += 16;
																		goto end_IL_05c5;
																		IL_0909:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_05c5;
																		IL_065c:
																		if (16 >= b)
																		{
																			goto IL_0667;
																		}
																		goto IL_0688;
																		IL_0667:
																		if (16 > b)
																		{
																			goto IL_0675;
																		}
																		goto IL_0b81;
																		IL_0675:
																		if (15 < b)
																		{
																			break;
																		}
																		goto IL_070f;
																		IL_070f:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_071d;
																		IL_071d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																		goto IL_075e;
																		IL_075e:
																		array[num6 - 2] = 0;
																		goto IL_0772;
																		IL_0772:
																		num6--;
																		goto end_IL_05c5;
																		IL_0b81:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0bd3;
																		IL_0bd3:
																		num6--;
																		goto end_IL_05c5;
																		IL_0688:
																		if (17 >= b)
																		{
																			goto IL_0693;
																		}
																		goto IL_06ee;
																		IL_0693:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_06a1;
																		IL_06a1:
																		array[num6] = 5;
																		goto IL_06af;
																		IL_06af:
																		array2[num6] = ((delegate*<GorillaTagger>)LengthInTextElementsOpenMethod[*(int*)(ptr2 + num3)])();
																		goto IL_06cd;
																		IL_06cd:
																		num6++;
																		goto IL_06db;
																		IL_06db:
																		ptr2 += 8;
																		goto end_IL_05c5;
																		IL_06ee:
																		if (18 < b)
																		{
																			break;
																		}
																		goto IL_06fc;
																		IL_06fc:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_08cb;
																		IL_08cb:
																		global::_003CModule_003E.gorillaTagger_0 = (GorillaTagger)array2[num6 - 1];
																		num = 71;
																		goto IL_08ed;
																		IL_08ed:
																		num6--;
																		num = 247;
																		goto end_IL_05c5;
																		IL_0649:
																		array[num6] = 3;
																		goto IL_0c6f;
																	}
																	break;
																	IL_058c:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_05c5;
															continue;
															end_IL_059c:
															break;
														}
														continue;
														end_IL_05ac:
														break;
													}
													continue;
													end_IL_05c5:
													break;
												}
												continue;
												end_IL_1622:
												break;
											}
											continue;
											end_IL_1635:
											break;
										}
										continue;
										end_IL_163f:
										break;
									}
									continue;
									end_IL_164a:
									break;
								}
								continue;
								end_IL_165a:
								break;
							}
							continue;
							end_IL_166a:
							break;
						}
						continue;
						end_IL_167a:
						break;
					}
					continue;
					end_IL_168a:
					break;
				}
				continue;
				end_IL_16a3:
				break;
			}
		}
	}

	private void OnDisable()
	{
		TypedReferenceGetToken(this);
	}

	private void method_0()
	{
		CurrentThreadIsFixedDateRule(this);
	}

	private unsafe void method_1()
	{
		int num = 80;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									num = 212;
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MonthDatesepgetIsAppEarlierThanWindowsPhoneMango.NumberManagedMask);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 143;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_05d4:
															byte b = *ptr2;
															num = 11;
															while (true)
															{
																IL_05c4:
																ptr2++;
																while (true)
																{
																	IL_05b4:
																	if (b >= 1)
																	{
																		while (b <= 37)
																		{
																			while (true)
																			{
																				IL_0594:
																				if (19 < b)
																				{
																					while (true)
																					{
																						IL_0587:
																						if (28 < b)
																						{
																							while (true)
																							{
																								IL_0577:
																								if (33 >= b)
																								{
																									while (true)
																									{
																										IL_0567:
																										if (33 > b)
																										{
																											while (true)
																											{
																												IL_0557:
																												if (30 >= b)
																												{
																													while (true)
																													{
																														IL_0547:
																														if (30 > b)
																														{
																															while (29 >= b)
																															{
																																while (29 <= b)
																																{
																																	num = 317;
																																	while (true)
																																	{
																																		if (num != 317)
																																		{
																																			if (num != 1298)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 95:
																																				goto IL_0524;
																																			case 55:
																																				goto IL_0537;
																																			case 97:
																																				goto IL_0547;
																																			case 191:
																																				goto IL_0557;
																																			case 89:
																																				goto IL_0567;
																																			case 208:
																																				goto IL_0577;
																																			case 140:
																																				goto IL_0587;
																																			case 149:
																																				goto IL_0594;
																																			case 105:
																																				goto IL_05a4;
																																			case 66:
																																				goto IL_05b4;
																																			case 11:
																																				goto IL_05c4;
																																			case 35:
																																			case 217:
																																				goto IL_05d4;
																																			case 19:
																																				goto IL_05f6;
																																			case 23:
																																				goto IL_0601;
																																			case 53:
																																				goto IL_060f;
																																			case 6:
																																			case 65:
																																				goto IL_061f;
																																			case 137:
																																				goto IL_0652;
																																			case 152:
																																				goto IL_0665;
																																			case 81:
																																				goto IL_0670;
																																			case 135:
																																				goto IL_0683;
																																			case 36:
																																				goto IL_0691;
																																			case 161:
																																				goto IL_06a4;
																																			case 22:
																																				goto IL_06af;
																																			case 67:
																																				goto IL_06cb;
																																			case 132:
																																				goto IL_06d9;
																																			case 129:
																																				goto IL_06e7;
																																			case 56:
																																			case 153:
																																				goto IL_06f5;
																																			case 61:
																																				goto IL_0733;
																																			case 119:
																																				goto IL_0747;
																																			case 179:
																																				goto IL_075a;
																																			case 182:
																																				goto IL_076d;
																																			case 186:
																																				goto IL_0780;
																																			case 108:
																																			case 196:
																																				goto IL_0790;
																																			case 126:
																																				goto IL_079a;
																																			case 32:
																																				goto IL_07a8;
																																			case 201:
																																				goto IL_07bb;
																																			case 241:
																																				goto IL_07d7;
																																			case 27:
																																			case 85:
																																				goto IL_07e5;
																																			case 41:
																																				goto IL_07f9;
																																			case 24:
																																				goto IL_0838;
																																			case 17:
																																			case 248:
																																				goto IL_0854;
																																			case 45:
																																				goto IL_0894;
																																			case 155:
																																				goto IL_08a8;
																																			case 218:
																																			case 257:
																																				goto IL_08c4;
																																			case 265:
																																				goto IL_08dd;
																																			case 0:
																																				goto IL_08eb;
																																			case 46:
																																			case 54:
																																				goto IL_08f9;
																																			case 268:
																																				goto IL_0912;
																																			case 77:
																																				goto IL_0929;
																																			case 70:
																																			case 207:
																																				goto IL_0937;
																																			case 38:
																																				goto IL_0965;
																																			case 273:
																																				goto IL_0978;
																																			case 233:
																																				goto IL_09b7;
																																			case 29:
																																			case 274:
																																				goto IL_09ca;
																																			case 21:
																																				goto IL_0a08;
																																			case 146:
																																				goto IL_0a1c;
																																			case 4:
																																			case 277:
																																				goto IL_0a2f;
																																			case 123:
																																				goto IL_0a6f;
																																			case 30:
																																				goto IL_0a83;
																																			case 150:
																																			case 278:
																																				goto IL_0a96;
																																			case 171:
																																				goto IL_0aaf;
																																			case 242:
																																				goto IL_0abd;
																																			case 230:
																																				goto IL_0acb;
																																			case 280:
																																				goto IL_0ade;
																																			case 76:
																																				goto IL_0b1d;
																																			case 18:
																																			case 304:
																																				goto IL_0b30;
																																			case 110:
																																				goto IL_0b44;
																																			case 249:
																																				goto IL_0b91;
																																			case 52:
																																				goto IL_0b9f;
																																			case 288:
																																				goto IL_0bb2;
																																			case 303:
																																				goto IL_0bc6;
																																			case 128:
																																				goto IL_0c0e;
																																			case 3:
																																			case 170:
																																				goto IL_0c21;
																																			case 194:
																																				goto IL_0c2f;
																																			case 86:
																																				goto IL_0c4d;
																																			case 121:
																																				goto IL_0c5b;
																																			case 172:
																																				goto IL_0c6e;
																																			case 222:
																																				goto IL_0c7c;
																																			case 82:
																																			case 227:
																																				goto IL_0c87;
																																			case 68:
																																				goto IL_0cc7;
																																			case 306:
																																				goto IL_0cdb;
																																			case 264:
																																				goto IL_0cee;
																																			case 44:
																																				goto IL_0cfc;
																																			case 28:
																																			case 122:
																																				goto IL_0d0a;
																																			case 49:
																																				goto IL_0d23;
																																			case 9:
																																				goto IL_0d3f;
																																			case 310:
																																				goto IL_0d4a;
																																			case 12:
																																			case 58:
																																				goto IL_0d58;
																																			case 114:
																																				goto IL_0d74;
																																			case 43:
																																				goto IL_0d82;
																																			case 116:
																																				goto IL_0d95;
																																			case 259:
																																			case 282:
																																				goto IL_0da0;
																																			case 115:
																																				goto IL_0dde;
																																			case 33:
																																				goto IL_0df2;
																																			case 307:
																																				goto IL_0e05;
																																			case 1:
																																				goto IL_0e13;
																																			case 60:
																																			case 266:
																																				goto IL_0e1e;
																																			case 178:
																																				goto IL_0e5e;
																																			case 300:
																																				goto IL_0e72;
																																			case 258:
																																				goto IL_0e85;
																																			case 63:
																																				goto IL_0e93;
																																			case 236:
																																				goto IL_0ea1;
																																			case 130:
																																			case 164:
																																				goto IL_0eac;
																																			case 71:
																																				goto IL_0eec;
																																			case 173:
																																				goto IL_0f00;
																																			case 228:
																																				goto IL_0f13;
																																			case 26:
																																				goto IL_0f21;
																																			case 167:
																																			case 294:
																																				goto IL_0f2f;
																																			case 42:
																																				goto IL_0f6f;
																																			case 210:
																																				goto IL_0f83;
																																			case 165:
																																				goto IL_0f96;
																																			case 96:
																																				goto IL_0fa1;
																																			case 102:
																																			case 188:
																																				goto IL_0faf;
																																			case 158:
																																				goto IL_0fef;
																																			case 134:
																																				goto IL_1003;
																																			case 37:
																																				goto IL_1016;
																																			case 148:
																																				goto IL_1024;
																																			case 262:
																																			case 270:
																																				goto IL_1032;
																																			case 100:
																																				goto IL_104e;
																																			case 202:
																																			case 209:
																																				goto IL_1059;
																																			case 190:
																																				goto IL_1070;
																																			case 101:
																																				goto IL_1093;
																																			case 214:
																																				goto IL_109d;
																																			case 39:
																																				goto IL_10ab;
																																			case 83:
																																				goto IL_10be;
																																			case 246:
																																				goto IL_10cc;
																																			case 8:
																																			case 90:
																																				goto IL_10d7;
																																			case 267:
																																				goto IL_1117;
																																			case 295:
																																				goto IL_112b;
																																			case 160:
																																				goto IL_113e;
																																			case 238:
																																				goto IL_114c;
																																			case 283:
																																			case 292:
																																				goto IL_115a;
																																			case 72:
																																				goto IL_1173;
																																			case 192:
																																				goto IL_1181;
																																			case 14:
																																				goto IL_1198;
																																			case 213:
																																				goto IL_11ab;
																																			case 125:
																																				goto IL_11b9;
																																			case 142:
																																			case 220:
																																				goto IL_11c7;
																																			case 185:
																																				goto IL_11f9;
																																			case 180:
																																				goto IL_1207;
																																			case 174:
																																				goto IL_121a;
																																			case 92:
																																				goto IL_1228;
																																			case 157:
																																				goto IL_1236;
																																			case 10:
																																			case 216:
																																				goto IL_1241;
																																			case 144:
																																				goto IL_1293;
																																			case 87:
																																				goto IL_12a6;
																																			case 99:
																																				goto IL_12b4;
																																			case 224:
																																			case 275:
																																				goto IL_12c2;
																																			case 206:
																																				goto IL_1303;
																																			case 40:
																																				goto IL_1317;
																																			case 156:
																																				goto IL_132a;
																																			case 109:
																																				goto IL_1335;
																																			case 88:
																																			case 290:
																																				goto IL_1343;
																																			case 272:
																																				goto IL_1361;
																																			case 221:
																																				goto IL_136f;
																																			case 297:
																																				goto IL_1386;
																																			case 50:
																																				goto IL_1399;
																																			case 136:
																																				goto IL_13a7;
																																			case 117:
																																			case 269:
																																				goto IL_13b5;
																																			case 197:
																																				goto IL_13cd;
																																			case 73:
																																				goto IL_13db;
																																			case 48:
																																				goto IL_13e9;
																																			case 5:
																																				goto IL_1405;
																																			case 245:
																																			case 250:
																																				goto IL_1410;
																																			case 31:
																																				goto IL_1428;
																																			case 291:
																																				goto IL_1436;
																																			case 25:
																																			case 98:
																																				goto IL_1444;
																																			case 162:
																																				goto IL_1458;
																																			case 244:
																																				goto IL_14ac;
																																			case 20:
																																				goto IL_14ba;
																																			case 154:
																																				goto IL_14cd;
																																			case 204:
																																				goto IL_14db;
																																			case 247:
																																			case 281:
																																				goto IL_14e9;
																																			case 239:
																																				goto IL_154b;
																																			case 84:
																																				goto IL_155e;
																																			case 7:
																																				goto IL_1569;
																																			case 13:
																																				goto IL_1576;
																																			case 127:
																																				goto IL_1581;
																																			case 296:
																																			case 301:
																																				goto IL_158c;
																																			case 199:
																																				goto IL_15a5;
																																			case 198:
																																				goto IL_15b3;
																																			case 2:
																																				goto IL_15c1;
																																			case 15:
																																			case 51:
																																			case 57:
																																			case 64:
																																			case 94:
																																			case 104:
																																			case 107:
																																			case 111:
																																			case 112:
																																			case 113:
																																			case 131:
																																			case 133:
																																			case 139:
																																			case 141:
																																			case 145:
																																			case 147:
																																			case 151:
																																			case 163:
																																			case 166:
																																			case 168:
																																			case 175:
																																			case 181:
																																			case 183:
																																			case 184:
																																			case 195:
																																			case 200:
																																			case 205:
																																			case 215:
																																			case 223:
																																			case 225:
																																			case 226:
																																			case 251:
																																			case 255:
																																			case 271:
																																			case 279:
																																			case 293:
																																			case 298:
																																			case 302:
																																			case 305:
																																			case 308:
																																				goto end_IL_0524;
																																			case 16:
																																			case 34:
																																			case 47:
																																			case 59:
																																			case 62:
																																			case 69:
																																			case 74:
																																			case 75:
																																			case 78:
																																			case 91:
																																			case 103:
																																			case 106:
																																			case 118:
																																			case 120:
																																			case 124:
																																			case 138:
																																			case 143:
																																			case 159:
																																			case 169:
																																			case 176:
																																			case 187:
																																			case 189:
																																			case 193:
																																			case 211:
																																			case 229:
																																			case 232:
																																			case 234:
																																			case 235:
																																			case 237:
																																			case 240:
																																			case 243:
																																			case 252:
																																			case 254:
																																			case 256:
																																			case 284:
																																			case 285:
																																			case 286:
																																			case 289:
																																			case 299:
																																			case 309:
																																				goto end_IL_0511;
																																			case 253:
																																				goto end_IL_15ed;
																																			case 287:
																																				goto end_IL_1600;
																																			case 177:
																																				goto end_IL_1613;
																																			case 212:
																																				goto end_IL_161e;
																																			case 219:
																																				goto end_IL_162e;
																																			case 93:
																																			case 263:
																																				goto end_IL_163e;
																																			case 231:
																																				goto end_IL_1657;
																																			case 261:
																																				goto end_IL_1667;
																																			case 203:
																																				goto end_IL_1677;
																																			case 79:
																																				goto end_IL_1687;
																																			case 80:
																																				goto end_IL_1697;
																																			case 260:
																																			case 276:
																																				return;
																																			}
																																			continue;
																																		}
																																		goto IL_0bb2;
																																		IL_0bc6:
																																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																																		num = 128;
																																		goto IL_0c0e;
																																		IL_0c0e:
																																		ptr2 += 8;
																																		break;
																																		IL_0bb2:
																																		array[num6 - 1] = 3;
																																		goto IL_0bc6;
																																		continue;
																																		end_IL_0511:
																																		break;
																																	}
																																	goto end_IL_05b4;
																																	continue;
																																	end_IL_0524:
																																	break;
																																	IL_0524:;
																																}
																																break;
																																IL_0537:;
																															}
																															break;
																														}
																														num = 108;
																														goto IL_0790;
																														IL_079a:
																														array[num6] = 5;
																														goto IL_07a8;
																														IL_07a8:
																														num6++;
																														goto end_IL_05b4;
																														IL_0790:
																														array2[num6] = null;
																														goto IL_079a;
																													}
																													break;
																												}
																												goto IL_0665;
																												IL_09b7:
																												ptr2 += 8;
																												goto end_IL_05b4;
																												IL_0665:
																												if (31 >= b)
																												{
																													goto IL_0670;
																												}
																												goto IL_0683;
																												IL_0670:
																												if (31 > b)
																												{
																													break;
																												}
																												goto IL_0b30;
																												IL_0b30:
																												array[num6 - 2] = 0;
																												goto IL_0b44;
																												IL_0b44:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																												goto IL_0b91;
																												IL_0b91:
																												num6--;
																												goto IL_0b9f;
																												IL_0b9f:
																												ptr2 += 8;
																												goto end_IL_05b4;
																												IL_0683:
																												if (32 < b)
																												{
																													break;
																												}
																												goto IL_0691;
																												IL_0691:
																												if (32 > b)
																												{
																													break;
																												}
																												goto IL_08c4;
																												IL_08c4:
																												array[num6 - 1] = 3;
																												goto IL_0978;
																												IL_0978:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																												goto IL_09b7;
																											}
																											break;
																										}
																										goto IL_0c21;
																										IL_0c5b:
																										ptr2 += 8;
																										goto end_IL_05b4;
																										IL_0c21:
																										array[num6] = 5;
																										goto IL_0c2f;
																										IL_0c2f:
																										array2[num6] = ((delegate*<GorillaTagger>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])();
																										goto IL_0c4d;
																										IL_0c4d:
																										num6++;
																										goto IL_0c5b;
																									}
																									break;
																								}
																								goto IL_0c6e;
																								IL_0d82:
																								if (37 > b)
																								{
																								}
																								break;
																								IL_0c6e:
																								if (35 >= b)
																								{
																									goto IL_0c7c;
																								}
																								goto IL_0d3f;
																								IL_0c7c:
																								if (35 <= b)
																								{
																									goto IL_0c87;
																								}
																								goto IL_0cee;
																								IL_0c87:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0cc7;
																								IL_0cc7:
																								array[num6 - 2] = 3;
																								goto IL_0cdb;
																								IL_0cdb:
																								num6--;
																								goto end_IL_05b4;
																								IL_0cee:
																								if (34 < b)
																								{
																									break;
																								}
																								goto IL_0cfc;
																								IL_0cfc:
																								if (34 > b)
																								{
																									break;
																								}
																								goto IL_0d0a;
																								IL_0d0a:
																								global::_003CModule_003E.gorillaTagger_1 = (GorillaTagger)array2[num6 - 1];
																								goto IL_0d23;
																								IL_0d23:
																								num6--;
																								num = 118;
																								goto end_IL_05b4;
																								IL_0d3f:
																								if (36 >= b)
																								{
																									goto IL_0d4a;
																								}
																								goto IL_0d74;
																								IL_0d4a:
																								if (36 > b)
																								{
																									break;
																								}
																								goto IL_0d58;
																								IL_0d58:
																								byte* num7 = ptr2;
																								num5 = 1;
																								ptr2 = num7 + -200;
																								goto end_IL_05b4;
																								IL_0d74:
																								if (37 < b)
																								{
																									break;
																								}
																								goto IL_0d82;
																							}
																							break;
																						}
																						goto IL_05f6;
																						IL_0894:
																						array[num6 - 2] = 3;
																						goto IL_08a8;
																						IL_05f6:
																						if (28 > b)
																						{
																							goto IL_0601;
																						}
																						goto IL_061f;
																						IL_0601:
																						if (23 >= b)
																						{
																							goto IL_060f;
																						}
																						goto IL_06a4;
																						IL_060f:
																						if (23 > b)
																						{
																							goto IL_0652;
																						}
																						goto IL_0a2f;
																						IL_0a2f:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0a6f;
																						IL_0a6f:
																						array[num6 - 2] = 3;
																						goto IL_0a83;
																						IL_0a83:
																						num6--;
																						goto end_IL_05b4;
																						IL_0652:
																						if (21 >= b)
																						{
																							goto IL_07bb;
																						}
																						goto IL_08dd;
																						IL_07bb:
																						if (21 > b)
																						{
																							goto IL_0912;
																						}
																						num = 278;
																						goto IL_0a96;
																						IL_08a8:
																						num6--;
																						num = 69;
																						goto end_IL_05b4;
																						IL_0a96:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																						goto IL_0aaf;
																						IL_0aaf:
																						array[num6] = 3;
																						goto IL_0abd;
																						IL_0abd:
																						num6++;
																						goto IL_0acb;
																						IL_0acb:
																						ptr2 += 16;
																						goto end_IL_05b4;
																						IL_0912:
																						if (20 < b)
																						{
																							break;
																						}
																						num = 77;
																						goto IL_0929;
																						IL_061f:
																						((GorillaTagger)array2[num6 - 2]).tapHapticDuration = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_076d;
																						IL_0929:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_0937;
																						IL_0937:
																						((GorillaTagger)array2[num6 - 2]).tapHapticStrength = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0965;
																						IL_0965:
																						num6 -= 2;
																						goto end_IL_05b4;
																						IL_08dd:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_08eb;
																						IL_08eb:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_08f9;
																						IL_08f9:
																						array[num6 - 1] = 3;
																						goto IL_0ade;
																						IL_0ade:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0b1d;
																						IL_0b1d:
																						ptr2 += 8;
																						goto end_IL_05b4;
																						IL_06a4:
																						if (25 >= b)
																						{
																							goto IL_06af;
																						}
																						goto IL_06cb;
																						IL_06af:
																						if (25 > b)
																						{
																							goto IL_0780;
																						}
																						num = 29;
																						goto IL_09ca;
																						IL_076d:
																						num6 -= 2;
																						goto end_IL_05b4;
																						IL_09ca:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (((delegate*<Class188, bool>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])((Class188)array2[num6 - 1]) ? 1 : 0);
																						goto IL_0a08;
																						IL_0a08:
																						array[num6 - 1] = 0;
																						goto IL_0a1c;
																						IL_0a1c:
																						ptr2 += 8;
																						goto end_IL_05b4;
																						IL_0780:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_07d7;
																						IL_07d7:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_07e5;
																						IL_07e5:
																						array[num6 - 1] = 0;
																						goto IL_07f9;
																						IL_07f9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0838;
																						IL_0838:
																						ptr2 += 8;
																						num = 193;
																						goto end_IL_05b4;
																						IL_06cb:
																						if (26 < b)
																						{
																							goto IL_06d9;
																						}
																						goto IL_075a;
																						IL_06d9:
																						if (27 < b)
																						{
																							break;
																						}
																						goto IL_06e7;
																						IL_06e7:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_06f5;
																						IL_06f5:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Class188, float>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])((Class188)array2[num6 - 1]);
																						goto IL_0733;
																						IL_0733:
																						array[num6 - 1] = 3;
																						goto IL_0747;
																						IL_0747:
																						ptr2 += 8;
																						goto end_IL_05b4;
																						IL_075a:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_0854;
																						IL_0854:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0894;
																					}
																					break;
																				}
																				goto IL_0d95;
																				IL_15a5:
																				array[num6] = 1;
																				goto IL_15b3;
																				IL_0d95:
																				if (19 <= b)
																				{
																					goto IL_0da0;
																				}
																				goto IL_0e05;
																				IL_0da0:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Class188, float>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])((Class188)array2[num6 - 1]);
																				goto IL_0dde;
																				IL_0dde:
																				array[num6 - 1] = 3;
																				goto IL_0df2;
																				IL_0df2:
																				ptr2 += 8;
																				goto end_IL_05b4;
																				IL_0e05:
																				if (9 >= b)
																				{
																					goto IL_0e13;
																				}
																				goto IL_121a;
																				IL_0e13:
																				if (9 <= b)
																				{
																					goto IL_0e1e;
																				}
																				goto IL_0e85;
																				IL_0e1e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0e5e;
																				IL_0e5e:
																				array[num6 - 2] = 0;
																				goto IL_0e72;
																				IL_0e72:
																				num6--;
																				goto end_IL_05b4;
																				IL_0e85:
																				if (4 < b)
																				{
																					goto IL_0e93;
																				}
																				num = 100;
																				goto IL_104e;
																				IL_0e93:
																				if (6 >= b)
																				{
																					goto IL_0ea1;
																				}
																				goto IL_0f96;
																				IL_0ea1:
																				if (6 <= b)
																				{
																					goto IL_0eac;
																				}
																				goto IL_0f13;
																				IL_0eac:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0eec;
																				IL_0eec:
																				array[num6 - 2] = 0;
																				goto IL_0f00;
																				IL_0f00:
																				num6--;
																				goto end_IL_05b4;
																				IL_0f13:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0f21;
																				IL_0f21:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0f2f;
																				IL_0f2f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0f6f;
																				IL_0f6f:
																				array[num6 - 2] = 0;
																				goto IL_0f83;
																				IL_0f83:
																				num6--;
																				goto end_IL_05b4;
																				IL_0f96:
																				if (7 >= b)
																				{
																					goto IL_0fa1;
																				}
																				goto IL_1016;
																				IL_0fa1:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0faf;
																				IL_0faf:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0fef;
																				IL_0fef:
																				array[num6 - 2] = 0;
																				goto IL_1003;
																				IL_1003:
																				num6--;
																				goto end_IL_05b4;
																				IL_1016:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_1024;
																				IL_1024:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_1032;
																				IL_1032:
																				num6--;
																				goto end_IL_05b4;
																				IL_15b3:
																				num6++;
																				goto IL_15c1;
																				IL_104e:
																				if (4 <= b)
																				{
																					goto IL_1059;
																				}
																				goto IL_10be;
																				IL_1059:
																				array[num6] = 0;
																				num = 190;
																				goto IL_1070;
																				IL_1070:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_1093;
																				IL_1093:
																				array2[num6] = null;
																				goto IL_109d;
																				IL_109d:
																				num6++;
																				goto IL_10ab;
																				IL_10ab:
																				ptr2 += 8;
																				goto end_IL_05b4;
																				IL_10be:
																				if (2 >= b)
																				{
																					goto IL_10cc;
																				}
																				goto IL_11ab;
																				IL_10cc:
																				if (2 <= b)
																				{
																					goto IL_10d7;
																				}
																				goto IL_113e;
																				IL_10d7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1117;
																				IL_1117:
																				array[num6 - 2] = 0;
																				goto IL_112b;
																				IL_112b:
																				num6--;
																				goto end_IL_05b4;
																				IL_113e:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_114c;
																				IL_114c:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_115a;
																				IL_115a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_1173;
																				IL_1173:
																				array[num6] = 0;
																				goto IL_1181;
																				IL_1181:
																				num6++;
																				num = 14;
																				goto IL_1198;
																				IL_1198:
																				ptr2 += 8;
																				goto end_IL_05b4;
																				IL_11ab:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_11b9;
																				IL_11b9:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_11c7;
																				IL_11c7:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 185;
																				goto IL_11f9;
																				IL_11f9:
																				ptr2 += 8;
																				goto IL_1207;
																				IL_1207:
																				num6--;
																				goto end_IL_05b4;
																				IL_121a:
																				if (14 < b)
																				{
																					goto IL_1228;
																				}
																				num = 5;
																				goto IL_1405;
																				IL_1228:
																				if (16 >= b)
																				{
																					goto IL_1236;
																				}
																				goto IL_132a;
																				IL_1236:
																				if (16 <= b)
																				{
																					goto IL_1241;
																				}
																				goto IL_12a6;
																				IL_1241:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_1293;
																				IL_1293:
																				num6--;
																				goto end_IL_05b4;
																				IL_12a6:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_12b4;
																				IL_12b4:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_12c2;
																				IL_12c2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_1303;
																				IL_1303:
																				array[num6 - 2] = 0;
																				goto IL_1317;
																				IL_1317:
																				num6--;
																				goto end_IL_05b4;
																				IL_132a:
																				if (17 >= b)
																				{
																					goto IL_1335;
																				}
																				goto IL_1399;
																				IL_1335:
																				if (17 > b)
																				{
																					break;
																				}
																				goto IL_1343;
																				IL_1343:
																				array2[num6] = ((delegate*<GorillaTagger>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])();
																				goto IL_1361;
																				IL_1361:
																				array[num6] = 5;
																				goto IL_136f;
																				IL_136f:
																				num6++;
																				num = 297;
																				goto IL_1386;
																				IL_1386:
																				ptr2 += 8;
																				goto end_IL_05b4;
																				IL_1399:
																				if (18 < b)
																				{
																					break;
																				}
																				goto IL_13a7;
																				IL_13a7:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_13b5;
																				IL_13b5:
																				array2[num6] = array5[*(int*)(ptr2 + num3)];
																				goto IL_13cd;
																				IL_13cd:
																				array[num6] = 5;
																				goto IL_13db;
																				IL_13db:
																				num6++;
																				goto IL_13e9;
																				IL_13e9:
																				ptr2 += 8;
																				goto end_IL_05b4;
																				IL_15c1:
																				ptr2 += 16;
																				num = 138;
																				goto end_IL_05b4;
																				IL_1405:
																				if (14 <= b)
																				{
																					goto IL_1410;
																				}
																				goto IL_1428;
																				IL_1410:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_05b4;
																				IL_1428:
																				if (11 >= b)
																				{
																					goto IL_1436;
																				}
																				goto IL_155e;
																				IL_1436:
																				if (11 <= b)
																				{
																					goto IL_1444;
																				}
																				goto IL_14cd;
																				IL_1444:
																				array[num6 - 2] = 0;
																				goto IL_1458;
																				IL_1458:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)UseDllDirectoryForDependenciesInternalOptionsMask[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_14ac;
																				IL_14ac:
																				num6--;
																				goto IL_14ba;
																				IL_14ba:
																				ptr2 += 8;
																				goto end_IL_05b4;
																				IL_14cd:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_14db;
																				IL_14db:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_14e9;
																				IL_14e9:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_154b;
																				IL_154b:
																				num6 -= 2;
																				goto end_IL_05b4;
																				IL_155e:
																				if (12 >= b)
																				{
																					goto IL_1569;
																				}
																				goto IL_1576;
																				IL_1569:
																				if (12 > b)
																				{
																					break;
																				}
																				goto end_IL_05b4;
																				IL_1576:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_1581;
																				IL_1581:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_158c;
																				IL_158c:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_15a5;
																			}
																			break;
																			IL_05a4:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_05b4:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_15ed:
														break;
													}
													continue;
													end_IL_1600:
													break;
												}
												continue;
												end_IL_1613:
												break;
											}
											continue;
											end_IL_161e:
											break;
										}
										continue;
										end_IL_162e:
										break;
									}
									continue;
									end_IL_163e:
									break;
								}
								continue;
								end_IL_1657:
								break;
							}
							continue;
							end_IL_1667:
							break;
						}
						continue;
						end_IL_1677:
						break;
					}
					continue;
					end_IL_1687:
					break;
				}
				continue;
				end_IL_1697:
				break;
			}
		}
	}

	public Class188()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 6;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 53;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OriginalIssuerEqualsIssuerSerializationHeaderRecord.getStoreRsaKeyValue);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0246:
																byte b = *ptr2;
																while (true)
																{
																	IL_022d:
																	ptr2++;
																	num = 74;
																	while (true)
																	{
																		IL_021d:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_0200:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01f0:
																							if (6 >= b)
																							{
																								while (6 > b)
																								{
																									while (5 >= b)
																									{
																										while (5 <= b)
																										{
																											while (true)
																											{
																												IL_01a2:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												num = 96;
																												while (num != 96)
																												{
																													if (num != 1077)
																													{
																														goto IL_02e9;
																													}
																													switch (num)
																													{
																													case 69:
																													case 85:
																														goto IL_01a2;
																													case 30:
																														goto IL_01c0;
																													case 4:
																														goto IL_01d0;
																													case 9:
																														goto IL_01e0;
																													case 71:
																														goto IL_01f0;
																													case 16:
																														goto IL_0200;
																													case 39:
																														goto IL_020d;
																													case 74:
																														goto IL_021d;
																													case 2:
																														goto IL_022d;
																													case 7:
																													case 82:
																														goto IL_0246;
																													case 50:
																														goto IL_0251;
																													case 24:
																													case 38:
																														goto IL_025c;
																													case 11:
																														goto IL_0267;
																													case 44:
																														goto IL_0275;
																													case 35:
																														goto IL_0283;
																													case 15:
																													case 51:
																														goto IL_029f;
																													case 61:
																														goto IL_02c8;
																													case 19:
																													case 63:
																														goto IL_02db;
																													case 52:
																														goto IL_02e9;
																													case 12:
																													case 36:
																														goto IL_02f7;
																													case 28:
																														goto IL_0337;
																													case 18:
																														goto IL_034b;
																													case 72:
																														goto IL_035e;
																													case 31:
																													case 83:
																														goto IL_0371;
																													case 46:
																														goto IL_03df;
																													case 43:
																														goto IL_03f2;
																													case 3:
																														goto IL_03fd;
																													case 45:
																													case 80:
																														goto IL_040b;
																													case 47:
																														goto IL_0419;
																													case 81:
																														goto IL_043c;
																													case 88:
																														goto IL_0446;
																													case 41:
																														goto IL_0454;
																													case 86:
																														goto IL_0464;
																													case 23:
																														goto IL_046f;
																													case 8:
																													case 57:
																														goto IL_047a;
																													case 13:
																													case 14:
																													case 21:
																													case 22:
																													case 26:
																													case 33:
																													case 37:
																													case 42:
																													case 48:
																													case 55:
																													case 56:
																													case 58:
																													case 59:
																													case 67:
																													case 75:
																													case 77:
																													case 79:
																													case 84:
																													case 87:
																														goto end_IL_01c0;
																													case 1:
																														goto IL_04b6;
																													case 0:
																														goto IL_04c4;
																													case 89:
																														goto IL_04d2;
																													case 10:
																													case 25:
																													case 27:
																													case 32:
																													case 62:
																													case 64:
																													case 65:
																													case 66:
																													case 70:
																													case 73:
																														goto end_IL_018f;
																													case 68:
																														goto end_IL_04e0;
																													case 76:
																														goto end_IL_04f3;
																													case 34:
																														goto end_IL_04fd;
																													case 54:
																														goto end_IL_0508;
																													case 49:
																														goto end_IL_051d;
																													case 20:
																													case 60:
																														goto end_IL_0532;
																													case 29:
																														goto end_IL_0542;
																													case 53:
																														goto end_IL_0552;
																													case 17:
																														goto end_IL_0562;
																													case 5:
																														goto end_IL_0572;
																													case 6:
																														goto end_IL_057d;
																													case 40:
																													case 78:
																														goto IL_05a1;
																													}
																													continue;
																													end_IL_018f:
																													break;
																												}
																												break;
																											}
																											goto end_IL_01e0;
																											continue;
																											end_IL_01c0:
																											break;
																											IL_01c0:;
																										}
																										break;
																										IL_01d0:;
																									}
																									goto end_IL_020d;
																									continue;
																									end_IL_01e0:
																									break;
																									IL_01e0:;
																								}
																								break;
																							}
																							goto IL_03f2;
																							IL_047a:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							break;
																							IL_03f2:
																							if (7 >= b)
																							{
																								goto IL_03fd;
																							}
																							goto IL_0464;
																							IL_03fd:
																							if (7 > b)
																							{
																								goto end_IL_020d;
																							}
																							goto IL_040b;
																							IL_040b:
																							array[num6] = 0;
																							goto IL_0419;
																							IL_0419:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_043c;
																							IL_043c:
																							array2[num6] = null;
																							goto IL_0446;
																							IL_0446:
																							num6++;
																							goto IL_0454;
																							IL_0454:
																							ptr2 += 8;
																							break;
																							IL_0464:
																							if (8 < b)
																							{
																								goto end_IL_020d;
																							}
																							goto IL_046f;
																							IL_046f:
																							if (8 > b)
																							{
																								goto end_IL_020d;
																							}
																							goto IL_047a;
																						}
																						break;
																					}
																					goto IL_0251;
																					IL_02c8:
																					ptr2 += 8;
																					goto IL_035e;
																					IL_0251:
																					if (4 > b)
																					{
																						goto IL_025c;
																					}
																					goto IL_029f;
																					IL_025c:
																					if (2 >= b)
																					{
																						goto IL_0267;
																					}
																					goto IL_02db;
																					IL_0267:
																					if (2 > b)
																					{
																						goto IL_0275;
																					}
																					goto IL_0371;
																					IL_0275:
																					if (1 < b)
																					{
																						goto end_IL_020d;
																					}
																					goto IL_0283;
																					IL_0283:
																					if (1 > b)
																					{
																						num = 87;
																					}
																					goto end_IL_020d;
																					IL_035e:
																					num6--;
																					break;
																					IL_0371:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03df;
																					IL_03df:
																					num6 -= 2;
																					break;
																					IL_02db:
																					if (3 < b)
																					{
																						goto end_IL_020d;
																					}
																					goto IL_02e9;
																					IL_02e9:
																					if (3 > b)
																					{
																						goto end_IL_020d;
																					}
																					goto IL_02f7;
																					IL_02f7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0337;
																					IL_0337:
																					array[num6 - 2] = 0;
																					goto IL_034b;
																					IL_034b:
																					num6--;
																					break;
																					IL_029f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_02c8;
																				}
																				goto end_IL_021d;
																				continue;
																				end_IL_020d:
																				break;
																				IL_020d:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04b6;
																		IL_04d2:
																		ptr2 += 8;
																		break;
																		IL_04c4:
																		num6++;
																		goto IL_04d2;
																		IL_04b6:
																		array[num6] = 0;
																		goto IL_04c4;
																		continue;
																		end_IL_021d:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														num = 40;
														goto IL_05a1;
														IL_05a1:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														continue;
														end_IL_04e0:
														break;
													}
													continue;
													end_IL_04f3:
													break;
												}
												continue;
												end_IL_04fd:
												break;
											}
											continue;
											end_IL_0508:
											break;
										}
										continue;
										end_IL_051d:
										break;
									}
									continue;
									end_IL_0532:
									break;
								}
								continue;
								end_IL_0542:
								break;
							}
							continue;
							end_IL_0552:
							break;
						}
						continue;
						end_IL_0562:
						break;
					}
					continue;
					end_IL_0572:
					break;
				}
				continue;
				end_IL_057d:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 92;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RegisterWellKnownClientTypeOutAttribute.PreLoadgetMacCodePage);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 130;
												while (true)
												{
													if (num == 130)
													{
														goto IL_02ba;
													}
													if (num != 1111)
													{
														goto IL_06b6;
													}
													switch (num)
													{
													case 119:
														goto end_IL_0217;
													case 60:
														goto end_IL_022a;
													case 35:
														goto end_IL_0235;
													case 3:
														goto end_IL_023f;
													case 68:
														goto end_IL_024a;
													case 32:
													case 49:
														goto end_IL_025f;
													case 42:
														goto end_IL_026f;
													case 58:
													case 105:
														goto end_IL_027f;
													case 91:
														goto end_IL_028f;
													case 92:
														goto end_IL_029f;
													case 20:
													case 29:
													case 37:
													case 40:
													case 46:
													case 47:
													case 52:
													case 57:
													case 66:
													case 70:
													case 83:
													case 86:
													case 117:
														goto IL_02ba;
													case 84:
													case 89:
														goto IL_02ca;
													case 123:
														goto IL_02dc;
													case 116:
														goto IL_02ea;
													case 53:
														goto IL_02f8;
													case 80:
														goto IL_0306;
													case 8:
													case 27:
														goto IL_0314;
													case 36:
													case 112:
														goto IL_0322;
													case 0:
														goto IL_032d;
													case 10:
														goto IL_0338;
													case 55:
														goto IL_0346;
													case 7:
													case 90:
														goto IL_0354;
													case 33:
													case 63:
														goto IL_0370;
													case 108:
														goto IL_038c;
													case 69:
														goto IL_039a;
													case 12:
														goto IL_03ad;
													case 56:
													case 96:
														goto IL_03b8;
													case 16:
														goto IL_03c6;
													case 45:
														goto IL_03ea;
													case 72:
														goto IL_03f8;
													case 34:
														goto IL_040b;
													case 100:
														goto IL_0416;
													case 51:
													case 79:
														goto IL_0424;
													case 39:
														goto IL_0447;
													case 59:
														goto IL_045e;
													case 94:
														goto IL_0475;
													case 13:
													case 50:
														goto IL_0491;
													case 82:
														goto IL_049f;
													case 25:
													case 104:
														goto IL_04ad;
													case 99:
														goto IL_050f;
													case 44:
														goto IL_0522;
													case 95:
													case 103:
														goto IL_052d;
													case 122:
														goto IL_0576;
													case 77:
														goto IL_058a;
													case 38:
														goto IL_059d;
													case 107:
													case 120:
														goto IL_05ab;
													case 1:
														goto IL_05b6;
													case 9:
													case 31:
														goto IL_05d2;
													case 75:
														goto IL_05e0;
													case 22:
													case 115:
														goto IL_05ee;
													case 14:
														goto IL_05fc;
													case 21:
														goto IL_061f;
													case 43:
														goto IL_0629;
													case 98:
														goto IL_0637;
													case 114:
														goto IL_064a;
													case 11:
														goto IL_0658;
													case 28:
													case 118:
														goto IL_0663;
													case 54:
														goto IL_0671;
													case 87:
													case 109:
														goto IL_067f;
													case 73:
														goto IL_06a8;
													case 111:
														goto IL_06b6;
													case 102:
														goto IL_06d2;
													case 4:
													case 15:
														goto IL_06dd;
													case 93:
														goto IL_06f6;
													case 48:
														goto IL_0704;
													case 71:
														goto IL_0712;
													case 41:
													case 110:
														goto IL_0725;
													case 2:
													case 5:
													case 6:
													case 17:
													case 18:
													case 19:
													case 24:
													case 26:
													case 30:
													case 61:
													case 62:
													case 64:
													case 65:
													case 67:
													case 74:
													case 76:
													case 78:
													case 81:
													case 85:
													case 88:
													case 97:
													case 106:
													case 113:
													case 121:
														goto IL_0746;
													case 23:
													case 101:
														goto IL_075e;
													}
													continue;
													IL_06f6:
													array[num4] = 0;
													goto IL_0704;
													IL_0704:
													num4++;
													goto IL_0712;
													IL_02ba:
													if (num5 != 1)
													{
														goto IL_02ca;
													}
													goto IL_075e;
													IL_075e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_02ca:
													b = *ptr2;
													num = 123;
													goto IL_02dc;
													IL_02dc:
													ptr2++;
													goto IL_02ea;
													IL_02ea:
													if (b >= 1)
													{
														goto IL_02f8;
													}
													goto IL_0746;
													IL_02f8:
													if (b <= 12)
													{
														goto IL_0306;
													}
													goto IL_0746;
													IL_0306:
													if (6 < b)
													{
														goto IL_0314;
													}
													goto IL_0522;
													IL_0314:
													if (9 < b)
													{
														goto IL_0322;
													}
													goto IL_03ad;
													IL_0322:
													if (11 >= b)
													{
														goto IL_032d;
													}
													goto IL_038c;
													IL_032d:
													if (11 > b)
													{
														goto IL_0338;
													}
													num = 33;
													goto IL_0370;
													IL_0338:
													if (10 >= b)
													{
														goto IL_0346;
													}
													goto IL_0746;
													IL_0346:
													if (10 <= b)
													{
														goto IL_0354;
													}
													goto IL_0746;
													IL_0354:
													num4--;
													goto IL_02ba;
													IL_0712:
													ptr2 += 8;
													goto IL_02ba;
													IL_0370:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_02ba;
													IL_038c:
													if (12 >= b)
													{
														goto IL_039a;
													}
													goto IL_0746;
													IL_039a:
													if (12 > b)
													{
													}
													goto IL_0746;
													IL_03ad:
													if (9 <= b)
													{
														goto IL_03b8;
													}
													goto IL_040b;
													IL_03b8:
													array[num4] = 0;
													goto IL_03c6;
													IL_03c6:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = ((delegate*<int>)EncodingByteBufferUCOMIEnumerable[*(int*)(ptr2 + num3)])();
													goto IL_03ea;
													IL_03ea:
													num4++;
													goto IL_03f8;
													IL_03f8:
													ptr2 += 8;
													goto IL_02ba;
													IL_040b:
													if (7 >= b)
													{
														goto IL_0416;
													}
													num = 50;
													goto IL_0491;
													IL_0416:
													if (7 <= b)
													{
														goto IL_0424;
													}
													goto IL_0746;
													IL_0424:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0447;
													IL_0447:
													array[num4] = 0;
													num = 59;
													goto IL_045e;
													IL_045e:
													num4++;
													num = 94;
													goto IL_0475;
													IL_0475:
													ptr2 += 8;
													goto IL_02ba;
													IL_0725:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													num = 29;
													goto IL_02ba;
													IL_0491:
													if (8 >= b)
													{
														goto IL_049f;
													}
													goto IL_0746;
													IL_049f:
													if (8 <= b)
													{
														goto IL_04ad;
													}
													goto IL_0746;
													IL_04ad:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_050f;
													IL_050f:
													num4 -= 2;
													goto IL_02ba;
													IL_0522:
													if (6 <= b)
													{
														goto IL_052d;
													}
													goto IL_059d;
													IL_052d:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													num = 122;
													goto IL_0576;
													IL_0576:
													array[num4 - 2] = 0;
													goto IL_058a;
													IL_058a:
													num4--;
													goto IL_02ba;
													IL_059d:
													if (3 < b)
													{
														goto IL_05ab;
													}
													goto IL_064a;
													IL_05ab:
													if (4 >= b)
													{
														goto IL_05b6;
													}
													num = 9;
													goto IL_05d2;
													IL_05b6:
													if (4 <= b)
													{
														goto IL_02ba;
													}
													goto IL_0746;
													IL_0746:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_02ba;
													IL_05d2:
													if (5 >= b)
													{
														goto IL_05e0;
													}
													goto IL_0746;
													IL_05e0:
													if (5 <= b)
													{
														goto IL_05ee;
													}
													goto IL_0746;
													IL_05ee:
													array[num4] = 0;
													goto IL_05fc;
													IL_05fc:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_061f;
													IL_061f:
													array2[num4] = null;
													goto IL_0629;
													IL_0629:
													num4++;
													goto IL_0637;
													IL_0637:
													ptr2 += 8;
													goto IL_02ba;
													IL_064a:
													if (3 > b)
													{
														goto IL_0658;
													}
													goto IL_0725;
													IL_0658:
													if (1 < b)
													{
														goto IL_0663;
													}
													goto IL_06d2;
													IL_0663:
													if (2 >= b)
													{
														goto IL_0671;
													}
													goto IL_0746;
													IL_0671:
													if (2 <= b)
													{
														goto IL_067f;
													}
													goto IL_0746;
													IL_067f:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_06a8;
													IL_06a8:
													ptr2 += 8;
													goto IL_06b6;
													IL_06b6:
													num4--;
													num = 117;
													goto IL_02ba;
													IL_06d2:
													if (1 <= b)
													{
														goto IL_06dd;
													}
													goto IL_0746;
													IL_06dd:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
													goto IL_06f6;
													continue;
													end_IL_0217:
													break;
												}
												continue;
												end_IL_022a:
												break;
											}
											continue;
											end_IL_0235:
											break;
										}
										continue;
										end_IL_023f:
										break;
									}
									continue;
									end_IL_024a:
									break;
								}
								continue;
								end_IL_025f:
								break;
							}
							continue;
							end_IL_026f:
							break;
						}
						continue;
						end_IL_027f:
						break;
					}
					continue;
					end_IL_028f:
					break;
				}
				continue;
				end_IL_029f:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 79;
		long[] array3 = default(long[]);
		int num4 = default(int);
		int[] array4 = default(int[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 108;
						while (true)
						{
							if (num == 108)
							{
								goto IL_0213;
							}
							if (num != 1089)
							{
								goto IL_048d;
							}
							switch (num)
							{
							case 36:
								goto end_IL_01bf;
							case 1:
							case 73:
								goto end_IL_01cf;
							case 78:
								goto end_IL_01e8;
							case 79:
								goto end_IL_01f8;
							case 96:
								goto IL_0213;
							case 62:
								goto IL_0221;
							case 39:
								goto IL_022f;
							case 71:
								goto IL_0242;
							case 57:
								goto IL_0255;
							case 32:
								goto IL_025e;
							case 3:
							case 5:
							case 26:
							case 35:
							case 37:
							case 44:
							case 54:
							case 65:
							case 81:
							case 91:
							case 98:
								goto IL_0266;
							case 88:
								goto IL_0276;
							case 74:
								goto IL_027f;
							case 101:
								goto IL_0288;
							case 52:
								goto IL_029f;
							case 95:
								goto IL_02ad;
							case 67:
								goto IL_02bb;
							case 30:
							case 53:
								goto IL_02c9;
							case 2:
								goto IL_02d7;
							case 50:
								goto IL_02e5;
							case 18:
								goto IL_02f3;
							case 11:
							case 12:
								goto IL_0301;
							case 8:
								goto IL_0341;
							case 84:
								goto IL_0355;
							case 47:
							case 72:
								goto IL_0368;
							case 87:
								goto IL_0381;
							case 89:
								goto IL_038f;
							case 31:
								goto IL_039d;
							case 17:
								goto IL_03b0;
							case 7:
							case 27:
								goto IL_03bb;
							case 97:
								goto IL_03d2;
							case 9:
							case 20:
								goto IL_03e0;
							case 75:
								goto IL_03fc;
							case 16:
							case 92:
								goto IL_040a;
							case 33:
								goto IL_044a;
							case 43:
								goto IL_045e;
							case 90:
								goto IL_0471;
							case 28:
							case 85:
								goto IL_047f;
							case 41:
								goto IL_048d;
							case 48:
							case 100:
								goto IL_0498;
							case 93:
								goto IL_04af;
							case 4:
							case 34:
								goto IL_04c2;
							case 68:
								goto IL_0502;
							case 29:
								goto IL_0516;
							case 10:
								goto IL_0529;
							case 66:
								goto IL_0537;
							case 80:
								goto IL_0545;
							case 38:
							case 45:
								goto IL_0553;
							case 46:
								goto IL_0593;
							case 86:
								goto IL_05a7;
							case 15:
								goto IL_05ba;
							case 24:
							case 77:
								goto IL_05c8;
							case 13:
								goto IL_05f1;
							case 14:
								goto IL_05ff;
							case 23:
							case 58:
								goto IL_0612;
							case 19:
								goto IL_0620;
							case 51:
								goto IL_0643;
							case 64:
								goto IL_064d;
							case 60:
								goto IL_065b;
							case 49:
								goto IL_066e;
							case 82:
								goto IL_067c;
							case 61:
								goto IL_068a;
							case 0:
							case 6:
							case 21:
							case 22:
							case 25:
							case 40:
							case 42:
							case 55:
							case 56:
							case 59:
							case 63:
							case 69:
							case 70:
							case 83:
							case 99:
								goto IL_069d;
							case 76:
							case 94:
								goto IL_06c2;
							}
							continue;
							IL_069d:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
							goto IL_066e;
							IL_066e:
							array[num4] = 0;
							goto IL_067c;
							IL_0213:
							array4 = new int[5];
							goto IL_0221;
							IL_0221:
							array3 = new long[3];
							goto IL_022f;
							IL_022f:
							array4[0] = int_1;
							goto IL_0242;
							IL_0242:
							array4[1] = int_2;
							goto IL_0255;
							IL_0255:
							ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ERRORREFTOINVALIDTYPELIBTrue.removeUnobservedTaskExceptionsetRefusedSet);
							goto IL_025e;
							IL_025e:
							ptr = ptr2;
							goto IL_0266;
							IL_0266:
							if (num5 != 1)
							{
								goto IL_0276;
							}
							goto IL_06c2;
							IL_06c2:
							return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							IL_0276:
							num = 74;
							goto IL_027f;
							IL_027f:
							b = *ptr;
							goto IL_0288;
							IL_0288:
							ptr++;
							num = 52;
							goto IL_029f;
							IL_029f:
							if (b >= 1)
							{
								goto IL_02ad;
							}
							goto IL_069d;
							IL_02ad:
							if (b <= 9)
							{
								goto IL_02bb;
							}
							goto IL_069d;
							IL_02bb:
							if (5 < b)
							{
								goto IL_02c9;
							}
							goto IL_0471;
							IL_02c9:
							if (7 >= b)
							{
								goto IL_02d7;
							}
							goto IL_03b0;
							IL_02d7:
							if (7 > b)
							{
								goto IL_02e5;
							}
							goto IL_0368;
							IL_02e5:
							if (6 >= b)
							{
								goto IL_02f3;
							}
							goto IL_069d;
							IL_02f3:
							if (6 <= b)
							{
								goto IL_0301;
							}
							goto IL_069d;
							IL_0301:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_0341;
							IL_0341:
							array[num4 - 2] = 0;
							goto IL_0355;
							IL_0355:
							num4--;
							goto IL_0266;
							IL_0368:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(int*)(ptr + num3);
							goto IL_0381;
							IL_0381:
							array[num4] = 0;
							goto IL_038f;
							IL_038f:
							num4++;
							goto IL_039d;
							IL_039d:
							ptr += 8;
							goto IL_0266;
							IL_03b0:
							if (8 < b)
							{
								goto IL_03bb;
							}
							goto IL_03fc;
							IL_03bb:
							if (9 >= b)
							{
								num = 97;
								goto IL_03d2;
							}
							goto IL_069d;
							IL_067c:
							num4++;
							goto IL_068a;
							IL_03d2:
							if (9 <= b)
							{
								goto IL_03e0;
							}
							goto IL_069d;
							IL_03e0:
							byte* num6 = ptr;
							num5 = 1;
							ptr = num6 + -200;
							goto IL_0266;
							IL_03fc:
							if (8 <= b)
							{
								goto IL_040a;
							}
							goto IL_069d;
							IL_040a:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_044a;
							IL_044a:
							array[num4 - 2] = 0;
							goto IL_045e;
							IL_045e:
							num4--;
							goto IL_0266;
							IL_0471:
							if (5 > b)
							{
								goto IL_047f;
							}
							goto IL_0612;
							IL_047f:
							if (2 >= b)
							{
								goto IL_048d;
							}
							goto IL_0529;
							IL_048d:
							if (2 > b)
							{
								goto IL_0498;
							}
							goto IL_04c2;
							IL_0498:
							if (1 >= b)
							{
								num = 93;
								goto IL_04af;
							}
							goto IL_069d;
							IL_068a:
							ptr += 8;
							goto IL_0266;
							IL_04af:
							if (1 > b)
							{
							}
							goto IL_069d;
							IL_04c2:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_0502;
							IL_0502:
							array[num4 - 2] = 0;
							goto IL_0516;
							IL_0516:
							num4--;
							goto IL_0266;
							IL_0529:
							if (3 < b)
							{
								goto IL_0537;
							}
							goto IL_05ba;
							IL_0537:
							if (4 >= b)
							{
								goto IL_0545;
							}
							goto IL_069d;
							IL_0545:
							if (4 <= b)
							{
								goto IL_0553;
							}
							goto IL_069d;
							IL_0553:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_0593;
							IL_0593:
							array[num4 - 2] = 0;
							goto IL_05a7;
							IL_05a7:
							num4--;
							goto IL_0266;
							IL_05ba:
							if (3 <= b)
							{
								goto IL_05c8;
							}
							goto IL_069d;
							IL_05c8:
							ref int reference = ref array4[*(int*)(ptr + num3)];
							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_05f1;
							IL_05f1:
							ptr += 8;
							goto IL_05ff;
							IL_05ff:
							num4--;
							goto IL_0266;
							IL_0612:
							array[num4] = 0;
							goto IL_0620;
							IL_0620:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
							goto IL_0643;
							IL_0643:
							array2[num4] = null;
							goto IL_064d;
							IL_064d:
							num4++;
							goto IL_065b;
							IL_065b:
							ptr += 8;
							goto IL_0266;
							continue;
							end_IL_01bf:
							break;
						}
						continue;
						end_IL_01cf:
						break;
					}
					continue;
					end_IL_01e8:
					break;
				}
				continue;
				end_IL_01f8:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 52;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComObjectRegisterProvider.FDisplayBindgetExceptionType);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0334:
														byte b = *ptr2;
														while (true)
														{
															IL_0324:
															ptr2++;
															while (true)
															{
																IL_0314:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02f4:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02e7:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02d4:
																							if (4 < b)
																							{
																								num = 94;
																								while (true)
																								{
																									IL_02c4:
																									if (6 >= b)
																									{
																										num = 120;
																										while (true)
																										{
																											IL_02b4:
																											if (6 <= b)
																											{
																												num = 154;
																												while (true)
																												{
																													if (num != 154)
																													{
																														if (num != 1135)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 120:
																															goto IL_02b4;
																														case 94:
																														case 121:
																															goto IL_02c4;
																														case 39:
																															goto IL_02d4;
																														case 81:
																															goto IL_02e7;
																														case 147:
																															goto IL_02f4;
																														case 54:
																															goto IL_0304;
																														case 102:
																															goto IL_0314;
																														case 17:
																															goto IL_0324;
																														case 83:
																														case 130:
																															goto IL_0334;
																														case 29:
																															goto IL_033f;
																														case 75:
																															goto IL_0352;
																														case 6:
																														case 105:
																															goto IL_0362;
																														case 112:
																															goto IL_037a;
																														case 38:
																														case 106:
																															goto IL_0388;
																														case 123:
																															goto IL_03b1;
																														case 60:
																															goto IL_03bf;
																														case 128:
																															goto IL_03d2;
																														case 44:
																														case 79:
																															goto IL_03e0;
																														case 61:
																															goto IL_03ee;
																														case 124:
																															goto IL_0406;
																														case 64:
																															goto IL_0414;
																														case 146:
																															goto IL_0427;
																														case 59:
																														case 132:
																															goto IL_0435;
																														case 145:
																															goto IL_0443;
																														case 42:
																														case 50:
																															goto IL_044e;
																														case 28:
																															goto IL_045c;
																														case 116:
																														case 144:
																															goto IL_046a;
																														case 89:
																															goto IL_0483;
																														case 115:
																															goto IL_049a;
																														case 32:
																															goto IL_04a8;
																														case 36:
																														case 97:
																															goto IL_04bb;
																														case 93:
																															goto IL_04fb;
																														case 96:
																															goto IL_050f;
																														case 34:
																															goto IL_0522;
																														case 37:
																															goto IL_0530;
																														case 0:
																														case 43:
																															goto IL_053e;
																														case 99:
																															goto IL_0567;
																														case 88:
																														case 98:
																															goto IL_0580;
																														case 86:
																															goto IL_059e;
																														case 33:
																															goto IL_05ac;
																														case 71:
																															goto IL_05bf;
																														case 126:
																															goto IL_0607;
																														case 25:
																															goto IL_061a;
																														case 10:
																															goto IL_0628;
																														case 16:
																														case 136:
																															goto IL_0633;
																														case 92:
																															goto IL_0673;
																														case 35:
																															goto IL_0687;
																														case 138:
																															goto IL_069a;
																														case 142:
																															goto IL_06a8;
																														case 31:
																														case 72:
																															goto IL_06b3;
																														case 20:
																															goto IL_06c1;
																														case 113:
																														case 141:
																															goto IL_06d4;
																														case 85:
																															goto IL_06e2;
																														case 21:
																															goto IL_0705;
																														case 127:
																															goto IL_0718;
																														case 129:
																															goto IL_0726;
																														case 40:
																															goto IL_0739;
																														case 108:
																															goto IL_0747;
																														case 49:
																														case 101:
																															goto IL_0755;
																														case 18:
																															goto IL_0799;
																														case 104:
																															goto IL_07ad;
																														case 114:
																															goto IL_07c0;
																														case 24:
																														case 125:
																															goto IL_07cb;
																														case 135:
																															goto IL_07d9;
																														case 26:
																															goto IL_07ec;
																														case 27:
																														case 58:
																															goto IL_07f7;
																														case 143:
																															goto IL_0813;
																														case 23:
																															goto IL_081e;
																														case 30:
																														case 134:
																															goto IL_0829;
																														case 1:
																															goto IL_088b;
																														case 2:
																														case 5:
																														case 7:
																														case 8:
																														case 9:
																														case 13:
																														case 41:
																														case 45:
																														case 46:
																														case 53:
																														case 57:
																														case 63:
																														case 65:
																														case 67:
																														case 68:
																														case 69:
																														case 78:
																														case 80:
																														case 82:
																														case 84:
																														case 100:
																														case 103:
																														case 107:
																														case 109:
																														case 110:
																														case 111:
																														case 118:
																														case 131:
																														case 133:
																															goto end_IL_0304;
																														case 11:
																														case 15:
																														case 19:
																														case 22:
																														case 55:
																														case 62:
																														case 70:
																														case 73:
																														case 74:
																														case 76:
																														case 77:
																														case 90:
																														case 91:
																														case 119:
																														case 122:
																														case 137:
																														case 139:
																														case 140:
																															goto end_IL_02a1;
																														case 56:
																															goto end_IL_08ae;
																														case 12:
																															goto end_IL_08c1;
																														case 4:
																															goto end_IL_08cb;
																														case 117:
																															goto end_IL_08d6;
																														case 3:
																														case 87:
																															goto end_IL_08e6;
																														case 48:
																															goto end_IL_08f6;
																														case 14:
																														case 95:
																															goto end_IL_0906;
																														case 51:
																															goto end_IL_0916;
																														case 52:
																															goto end_IL_0926;
																														case 47:
																														case 66:
																															goto IL_0941;
																														}
																														continue;
																													}
																													goto IL_05bf;
																													IL_05bf:
																													((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 126;
																													goto IL_0607;
																													IL_0607:
																													num5 -= 3;
																													break;
																													continue;
																													end_IL_02a1:
																													break;
																												}
																												break;
																											}
																											goto IL_033f;
																											IL_0406:
																											num5++;
																											goto IL_0414;
																											IL_0414:
																											ptr2 += 8;
																											break;
																											IL_033f:
																											if (5 < b)
																											{
																												goto end_IL_0304;
																											}
																											goto IL_03d2;
																											IL_03d2:
																											if (5 > b)
																											{
																												goto end_IL_0304;
																											}
																											goto IL_03e0;
																											IL_03e0:
																											array[num5] = 5;
																											goto IL_03ee;
																											IL_03ee:
																											array2[num5] = array5[*(int*)(ptr2 + num3)];
																											goto IL_0406;
																										}
																										break;
																									}
																									goto IL_0352;
																									IL_03b1:
																									ptr2 += 8;
																									goto IL_03bf;
																									IL_03bf:
																									num5--;
																									break;
																									IL_0352:
																									if (7 < b)
																									{
																										goto end_IL_0304;
																									}
																									goto IL_037a;
																									IL_037a:
																									if (7 > b)
																									{
																										goto end_IL_0304;
																									}
																									goto IL_0388;
																									IL_0388:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03b1;
																								}
																								break;
																							}
																							goto IL_0427;
																							IL_059e:
																							ptr2 += 8;
																							goto IL_05ac;
																							IL_05ac:
																							num5--;
																							break;
																							IL_0427:
																							if (4 > b)
																							{
																								goto IL_0435;
																							}
																							goto IL_0580;
																							IL_0435:
																							if (2 >= b)
																							{
																								goto IL_0443;
																							}
																							goto IL_0522;
																							IL_0443:
																							if (2 > b)
																							{
																								goto IL_044e;
																							}
																							goto IL_04bb;
																							IL_044e:
																							if (1 < b)
																							{
																								goto end_IL_0304;
																							}
																							goto IL_045c;
																							IL_045c:
																							if (1 > b)
																							{
																								goto end_IL_0304;
																							}
																							goto IL_046a;
																							IL_046a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0483;
																							IL_0483:
																							array[num5] = 0;
																							num = 115;
																							goto IL_049a;
																							IL_049a:
																							num5++;
																							goto IL_04a8;
																							IL_04a8:
																							ptr2 += 8;
																							break;
																							IL_04bb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04fb;
																							IL_04fb:
																							array[num5 - 2] = 0;
																							goto IL_050f;
																							IL_050f:
																							num5--;
																							break;
																							IL_0522:
																							if (3 < b)
																							{
																								goto end_IL_0304;
																							}
																							goto IL_0530;
																							IL_0530:
																							if (3 > b)
																							{
																								goto end_IL_0304;
																							}
																							goto IL_053e;
																							IL_053e:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_0567;
																							IL_0567:
																							array[num5 - 1] = 5;
																							break;
																							IL_0580:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_059e;
																						}
																						break;
																					}
																					goto IL_0362;
																					IL_0362:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																				}
																				break;
																			}
																			goto IL_061a;
																			IL_088b:
																			num5 -= 2;
																			break;
																			IL_061a:
																			if (12 >= b)
																			{
																				goto IL_0628;
																			}
																			goto IL_07c0;
																			IL_0628:
																			if (12 <= b)
																			{
																				goto IL_0633;
																			}
																			goto IL_069a;
																			IL_0633:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0673;
																			IL_0673:
																			array[num5 - 2] = 0;
																			goto IL_0687;
																			IL_0687:
																			num5--;
																			break;
																			IL_069a:
																			if (10 >= b)
																			{
																				goto IL_06a8;
																			}
																			goto IL_0739;
																			IL_06a8:
																			if (10 > b)
																			{
																				goto IL_06b3;
																			}
																			goto IL_06d4;
																			IL_06b3:
																			if (9 < b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_06c1;
																			IL_06c1:
																			if (9 > b)
																			{
																				goto end_IL_0304;
																			}
																			break;
																			IL_06d4:
																			array[num5] = 0;
																			goto IL_06e2;
																			IL_06e2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0705;
																			IL_0705:
																			array2[num5] = null;
																			num = 127;
																			goto IL_0718;
																			IL_0718:
																			num5++;
																			goto IL_0726;
																			IL_0726:
																			ptr2 += 8;
																			break;
																			IL_0739:
																			if (11 < b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_0747;
																			IL_0747:
																			if (11 > b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_0755;
																			IL_0755:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0799;
																			IL_0799:
																			array[num5 - 2] = 0;
																			goto IL_07ad;
																			IL_07ad:
																			num5--;
																			break;
																			IL_07c0:
																			if (14 < b)
																			{
																				goto IL_07cb;
																			}
																			goto IL_07ec;
																			IL_07cb:
																			if (15 < b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_07d9;
																			IL_07d9:
																			if (15 <= b)
																			{
																			}
																			goto end_IL_0304;
																			IL_07ec:
																			if (14 <= b)
																			{
																				goto IL_07f7;
																			}
																			goto IL_0813;
																			IL_07f7:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0813:
																			if (13 < b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_081e;
																			IL_081e:
																			if (13 > b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_0829;
																			IL_0829:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_088b;
																		}
																		goto end_IL_0314;
																		continue;
																		end_IL_0304:
																		break;
																		IL_0304:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0314:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0941;
												IL_0941:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08ae:
												break;
											}
											continue;
											end_IL_08c1:
											break;
										}
										continue;
										end_IL_08cb:
										break;
									}
									continue;
									end_IL_08d6:
									break;
								}
								continue;
								end_IL_08e6:
								break;
							}
							continue;
							end_IL_08f6:
							break;
						}
						continue;
						end_IL_0906:
						break;
					}
					continue;
					end_IL_0916:
					break;
				}
				continue;
				end_IL_0926:
				break;
			}
		}
	}

	private static int smethod_4(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_1;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 11;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 10;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SwitchProperties.IsActivationAllowedMissingMethodException);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0318:
															byte b = *ptr2;
															while (true)
															{
																IL_0308:
																ptr2++;
																while (true)
																{
																	IL_02f8:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02d8:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_02c8:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_02b8:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_02ab:
																										if (4 >= b)
																										{
																											while (4 <= b)
																											{
																												while (true)
																												{
																													IL_0259:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_0243:
																														array[num5 - 2] = 0;
																														while (true)
																														{
																															IL_022a:
																															num5--;
																															num = 130;
																															while (num != 130)
																															{
																																if (num != 1111)
																																{
																																	goto IL_0695;
																																}
																																switch (num)
																																{
																																case 89:
																																	goto IL_022a;
																																case 18:
																																	goto IL_0243;
																																case 20:
																																case 77:
																																	goto IL_0259;
																																case 118:
																																	goto IL_029b;
																																case 48:
																																	goto IL_02ab;
																																case 29:
																																case 38:
																																	goto IL_02b8;
																																case 64:
																																	goto IL_02c8;
																																case 30:
																																	goto IL_02d8;
																																case 1:
																																	goto IL_02e8;
																																case 39:
																																	goto IL_02f8;
																																case 55:
																																	goto IL_0308;
																																case 7:
																																case 108:
																																	goto IL_0318;
																																case 40:
																																case 105:
																																	goto IL_0323;
																																case 80:
																																	goto IL_0331;
																																case 35:
																																case 59:
																																	goto IL_033f;
																																case 47:
																																	goto IL_034d;
																																case 111:
																																	goto IL_0370;
																																case 69:
																																	goto IL_037a;
																																case 51:
																																	goto IL_0391;
																																case 37:
																																	goto IL_03a4;
																																case 67:
																																case 90:
																																	goto IL_03af;
																																case 61:
																																	goto IL_03d8;
																																case 85:
																																	goto IL_03e6;
																																case 71:
																																	goto IL_03f9;
																																case 27:
																																case 110:
																																	goto IL_0407;
																																case 114:
																																	goto IL_0415;
																																case 3:
																																case 42:
																																	goto IL_0423;
																																case 49:
																																	goto IL_0463;
																																case 53:
																																	goto IL_0477;
																																case 0:
																																	goto IL_048a;
																																case 44:
																																case 91:
																																	goto IL_049d;
																																case 58:
																																	goto IL_04dd;
																																case 76:
																																	goto IL_04f1;
																																case 21:
																																case 107:
																																	goto IL_0504;
																																case 23:
																																	goto IL_0512;
																																case 34:
																																case 56:
																																	goto IL_0520;
																																case 15:
																																case 79:
																																	goto IL_0537;
																																case 54:
																																	goto IL_0545;
																																case 52:
																																case 63:
																																	goto IL_0553;
																																case 65:
																																	goto IL_0593;
																																case 82:
																																	goto IL_05a7;
																																case 16:
																																	goto IL_05ba;
																																case 12:
																																case 46:
																																	goto IL_05c8;
																																case 88:
																																	goto IL_05e1;
																																case 94:
																																	goto IL_05ef;
																																case 96:
																																	goto IL_05fd;
																																case 33:
																																case 87:
																																	goto IL_0610;
																																case 78:
																																	goto IL_0624;
																																case 113:
																																	goto IL_066c;
																																case 22:
																																	goto IL_067f;
																																case 17:
																																	goto IL_068a;
																																case 45:
																																case 72:
																																	goto IL_0695;
																																case 50:
																																	goto IL_06a8;
																																case 8:
																																	goto IL_06b3;
																																case 95:
																																case 123:
																																	goto IL_06c9;
																																case 13:
																																case 28:
																																case 31:
																																case 32:
																																case 36:
																																case 41:
																																case 57:
																																case 70:
																																case 74:
																																case 81:
																																case 84:
																																case 86:
																																case 92:
																																case 93:
																																case 97:
																																case 98:
																																case 100:
																																case 104:
																																case 109:
																																case 112:
																																case 115:
																																case 121:
																																case 122:
																																	goto end_IL_029b;
																																case 43:
																																	goto IL_0705;
																																case 24:
																																	goto IL_071c;
																																case 2:
																																	goto IL_072a;
																																case 4:
																																case 5:
																																case 14:
																																case 25:
																																case 66:
																																case 68:
																																case 73:
																																case 75:
																																case 83:
																																case 101:
																																case 117:
																																case 119:
																																	goto end_IL_0217;
																																case 9:
																																	goto end_IL_0738;
																																case 60:
																																	goto end_IL_074b;
																																case 19:
																																	goto end_IL_0755;
																																case 120:
																																	goto end_IL_0760;
																																case 116:
																																	goto end_IL_0775;
																																case 62:
																																case 102:
																																	goto end_IL_078a;
																																case 6:
																																	goto end_IL_079a;
																																case 103:
																																case 106:
																																	goto end_IL_07aa;
																																case 10:
																																	goto end_IL_07ba;
																																case 11:
																																	goto end_IL_07ca;
																																case 26:
																																case 99:
																																	goto IL_07ee;
																																}
																																continue;
																																end_IL_0217:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02f8;
																												continue;
																												end_IL_029b:
																												break;
																												IL_029b:;
																											}
																											break;
																										}
																										goto IL_0323;
																										IL_0391:
																										ptr2 += 8;
																										goto end_IL_02f8;
																										IL_0323:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_0331;
																										IL_0331:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_033f;
																										IL_033f:
																										array[num5] = 0;
																										goto IL_034d;
																										IL_034d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0370;
																										IL_0370:
																										array2[num5] = null;
																										goto IL_037a;
																										IL_037a:
																										num5++;
																										num = 51;
																										goto IL_0391;
																									}
																									break;
																								}
																								goto IL_03a4;
																								IL_048a:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_03a4:
																								if (3 <= b)
																								{
																									goto IL_03af;
																								}
																								goto IL_03f9;
																								IL_03af:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03d8;
																								IL_03d8:
																								ptr2 += 8;
																								goto IL_03e6;
																								IL_03e6:
																								num5--;
																								goto end_IL_02f8;
																								IL_03f9:
																								if (1 < b)
																								{
																									goto IL_0407;
																								}
																								goto IL_048a;
																								IL_0407:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_0415;
																								IL_0415:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_0423;
																								IL_0423:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0463;
																								IL_0463:
																								array[num5 - 2] = 0;
																								goto IL_0477;
																								IL_0477:
																								num5--;
																								goto end_IL_02f8;
																							}
																							break;
																						}
																						goto IL_049d;
																						IL_04f1:
																						num5--;
																						goto end_IL_02f8;
																						IL_049d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04dd;
																						IL_04dd:
																						array[num5 - 2] = 0;
																						goto IL_04f1;
																					}
																					break;
																				}
																				goto IL_0504;
																				IL_06b3:
																				if (11 > b)
																				{
																					num = 74;
																					break;
																				}
																				goto IL_06c9;
																				IL_0504:
																				if (9 >= b)
																				{
																					goto IL_0512;
																				}
																				goto IL_067f;
																				IL_0512:
																				if (9 > b)
																				{
																					goto IL_0520;
																				}
																				goto IL_0610;
																				IL_0520:
																				if (7 < b)
																				{
																					num = 15;
																					goto IL_0537;
																				}
																				goto IL_05ba;
																				IL_06c9:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02f8;
																				IL_0537:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0545;
																				IL_0545:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0553;
																				IL_0553:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0593;
																				IL_0593:
																				array[num5 - 2] = 0;
																				goto IL_05a7;
																				IL_05a7:
																				num5--;
																				goto end_IL_02f8;
																				IL_05ba:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05c8;
																				IL_05c8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_05e1;
																				IL_05e1:
																				array[num5] = 0;
																				goto IL_05ef;
																				IL_05ef:
																				num5++;
																				goto IL_05fd;
																				IL_05fd:
																				ptr2 += 8;
																				goto end_IL_02f8;
																				IL_0610:
																				array[num5 - 1] = 0;
																				goto IL_0624;
																				IL_0624:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)DefineLPArrayINVOCATIONFLAGSRISKYMETHOD[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				num = 113;
																				goto IL_066c;
																				IL_066c:
																				ptr2 += 8;
																				goto end_IL_02f8;
																				IL_067f:
																				if (10 >= b)
																				{
																					goto IL_068a;
																				}
																				goto IL_06a8;
																				IL_068a:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0695;
																				IL_0695:
																				num5--;
																				goto end_IL_02f8;
																				IL_06a8:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_06b3;
																			}
																			break;
																			IL_02e8:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0705;
																	IL_072a:
																	ptr2 += 8;
																	break;
																	IL_071c:
																	num5++;
																	goto IL_072a;
																	IL_0705:
																	array[num5] = 0;
																	num = 24;
																	goto IL_071c;
																	continue;
																	end_IL_02f8:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07ee;
													IL_07ee:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0738:
													break;
												}
												continue;
												end_IL_074b:
												break;
											}
											continue;
											end_IL_0755:
											break;
										}
										continue;
										end_IL_0760:
										break;
									}
									continue;
									end_IL_0775:
									break;
								}
								continue;
								end_IL_078a:
								break;
							}
							continue;
							end_IL_079a:
							break;
						}
						continue;
						end_IL_07aa:
						break;
					}
					continue;
					end_IL_07ba:
					break;
				}
				continue;
				end_IL_07ca:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 14;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TagSetByIndex.WindowsPrincipalIsHeldByCurrentThread);
											num = 29;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 8;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0251:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_0241:
																				if (b <= 9)
																				{
																					while (true)
																					{
																						IL_0234:
																						if (5 >= b)
																						{
																							while (true)
																							{
																								IL_0224:
																								if (5 <= b)
																								{
																									while (true)
																									{
																										IL_0214:
																										array[num5] = 0;
																										while (true)
																										{
																											IL_01ef:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											while (true)
																											{
																												IL_01da:
																												array2[num5] = null;
																												num = 110;
																												while (true)
																												{
																													if (num != 110)
																													{
																														if (num != 1091)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 40:
																															goto IL_01da;
																														case 39:
																															goto IL_01ef;
																														case 2:
																														case 19:
																															goto IL_0214;
																														case 75:
																															goto IL_0224;
																														case 77:
																															goto IL_0234;
																														case 90:
																															goto IL_0241;
																														case 89:
																															goto IL_0251;
																														case 51:
																															goto end_IL_0251;
																														case 8:
																															goto end_IL_0261;
																														case 63:
																															goto end_IL_0271;
																														case 36:
																														case 71:
																															goto IL_0287;
																														case 61:
																															goto IL_029b;
																														case 3:
																															goto IL_02a6;
																														case 17:
																															goto IL_02bd;
																														case 78:
																															goto IL_02db;
																														case 0:
																															goto IL_02e6;
																														case 18:
																															goto IL_02f9;
																														case 28:
																															goto IL_0307;
																														case 9:
																														case 81:
																															goto IL_0315;
																														case 58:
																														case 85:
																															goto IL_0331;
																														case 69:
																															goto IL_0371;
																														case 16:
																															goto IL_0385;
																														case 55:
																														case 99:
																															goto IL_0398;
																														case 42:
																															goto IL_03d8;
																														case 93:
																															goto IL_03ec;
																														case 33:
																														case 103:
																															goto IL_03ff;
																														case 62:
																															goto IL_0421;
																														case 67:
																															goto IL_042f;
																														case 21:
																															goto IL_043d;
																														case 34:
																															goto IL_0467;
																														case 95:
																															goto IL_047a;
																														case 15:
																														case 23:
																															goto IL_0488;
																														case 1:
																														case 87:
																															goto IL_0496;
																														case 47:
																															goto IL_04a4;
																														case 32:
																														case 46:
																															goto IL_04b2;
																														case 72:
																															goto IL_04f2;
																														case 22:
																															goto IL_0506;
																														case 25:
																															goto IL_0519;
																														case 12:
																														case 86:
																															goto IL_0527;
																														case 68:
																															goto IL_0550;
																														case 84:
																															goto IL_055e;
																														case 91:
																															goto IL_0571;
																														case 5:
																														case 11:
																															goto IL_057c;
																														case 27:
																															goto IL_058a;
																														case 26:
																														case 98:
																															goto IL_0597;
																														case 100:
																															goto IL_05e0;
																														case 6:
																															goto IL_05f4;
																														case 7:
																														case 35:
																														case 44:
																														case 45:
																														case 48:
																														case 49:
																														case 53:
																														case 56:
																														case 64:
																														case 66:
																														case 70:
																														case 74:
																														case 82:
																														case 88:
																														case 94:
																														case 96:
																														case 102:
																															goto end_IL_01c7;
																														case 50:
																															goto IL_0630;
																														case 79:
																															goto IL_063e;
																														case 97:
																															goto IL_064c;
																														case 20:
																														case 24:
																														case 38:
																														case 41:
																														case 54:
																														case 57:
																														case 59:
																														case 60:
																														case 65:
																														case 76:
																														case 92:
																															goto end_IL_027c;
																														case 29:
																															goto end_IL_065a;
																														case 31:
																															goto end_IL_066d;
																														case 73:
																															goto end_IL_0677;
																														case 4:
																															goto end_IL_068b;
																														case 52:
																															goto end_IL_06a0;
																														case 37:
																														case 80:
																															goto end_IL_06b5;
																														case 101:
																															goto end_IL_06c5;
																														case 10:
																														case 43:
																															goto end_IL_06d5;
																														case 13:
																															goto end_IL_06e5;
																														case 14:
																															goto end_IL_06f5;
																														case 30:
																														case 83:
																															goto IL_0710;
																														}
																														continue;
																													}
																													num5++;
																													goto IL_0467;
																													IL_0467:
																													ptr2 += 8;
																													goto end_IL_027c;
																													continue;
																													end_IL_01c7:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_047a;
																								IL_05f4:
																								num5--;
																								goto end_IL_027c;
																								IL_047a:
																								if (2 < b)
																								{
																									goto IL_0488;
																								}
																								goto IL_0571;
																								IL_0488:
																								if (3 < b)
																								{
																									goto IL_0496;
																								}
																								goto IL_0519;
																								IL_0496:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_04a4;
																								IL_04a4:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_04b2;
																								IL_04b2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04f2;
																								IL_04f2:
																								array[num5 - 2] = 0;
																								goto IL_0506;
																								IL_0506:
																								num5--;
																								goto end_IL_027c;
																								IL_0519:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0527;
																								IL_0527:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0550;
																								IL_0550:
																								ptr2 += 8;
																								goto IL_055e;
																								IL_055e:
																								num5--;
																								goto end_IL_027c;
																								IL_0571:
																								if (2 > b)
																								{
																									goto IL_057c;
																								}
																								goto IL_0597;
																								IL_057c:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_058a;
																								IL_058a:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0597:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 100;
																								goto IL_05e0;
																								IL_05e0:
																								array[num5 - 2] = 0;
																								goto IL_05f4;
																							}
																							break;
																						}
																						goto IL_0287;
																						IL_03ec:
																						num5--;
																						goto end_IL_027c;
																						IL_0287:
																						if (7 >= b)
																						{
																							num = 61;
																							goto IL_029b;
																						}
																						goto IL_02db;
																						IL_02f9:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0307;
																						IL_029b:
																						if (7 > b)
																						{
																							goto IL_02a6;
																						}
																						num = 33;
																						goto IL_03ff;
																						IL_02a6:
																						if (6 < b)
																						{
																							break;
																						}
																						num = 17;
																						goto IL_02bd;
																						IL_0315:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_027c;
																						IL_02bd:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0331;
																						IL_0331:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0371;
																						IL_0371:
																						array[num5 - 2] = 0;
																						goto IL_0385;
																						IL_0385:
																						num5--;
																						goto end_IL_027c;
																						IL_0307:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0315;
																						IL_03ff:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						num = 62;
																						goto IL_0421;
																						IL_0421:
																						array[num5] = 0;
																						goto IL_042f;
																						IL_042f:
																						num5++;
																						goto IL_043d;
																						IL_043d:
																						ptr2 += 8;
																						num = 24;
																						goto end_IL_027c;
																						IL_02db:
																						if (8 >= b)
																						{
																							goto IL_02e6;
																						}
																						goto IL_02f9;
																						IL_02e6:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0398;
																						IL_0398:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03d8;
																						IL_03d8:
																						array[num5 - 2] = 0;
																						goto IL_03ec;
																					}
																				}
																				else
																				{
																					num = 48;
																				}
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0630;
																		IL_064c:
																		ptr2 += 8;
																		goto end_IL_027c;
																		IL_063e:
																		num5++;
																		goto IL_064c;
																		IL_0630:
																		array[num5] = 0;
																		goto IL_063e;
																		continue;
																		end_IL_0251:
																		break;
																	}
																	continue;
																	end_IL_0261:
																	break;
																}
																continue;
																end_IL_0271:
																break;
															}
															continue;
															end_IL_027c:
															break;
														}
														continue;
													}
													goto IL_0710;
													IL_0710:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_065a:
													break;
												}
												continue;
												end_IL_066d:
												break;
											}
											continue;
											end_IL_0677:
											break;
										}
										continue;
										end_IL_068b:
										break;
									}
									continue;
									end_IL_06a0:
									break;
								}
								continue;
								end_IL_06b5:
								break;
							}
							continue;
							end_IL_06c5:
							break;
						}
						continue;
						end_IL_06d5:
						break;
					}
					continue;
					end_IL_06e5:
					break;
				}
				continue;
				end_IL_06f5:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 52;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetInvocationListGetDocumentation.DayOfWeekTokenInitialized);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02ee:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			if (7 >= b)
																			{
																				while (true)
																				{
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02ae:
																							if (3 >= b)
																							{
																								num = 124;
																								while (true)
																								{
																									IL_029b:
																									if (3 > b)
																									{
																										num = 20;
																										while (true)
																										{
																											IL_0288:
																											if (1 >= b)
																											{
																												num = 143;
																												while (true)
																												{
																													if (num != 143)
																													{
																														if (num != 1124)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 20:
																														case 70:
																															goto IL_0288;
																														case 124:
																															goto IL_029b;
																														case 6:
																															goto IL_02ae;
																														case 129:
																															goto end_IL_02ae;
																														case 26:
																															goto end_IL_02be;
																														case 74:
																															goto end_IL_02ce;
																														case 101:
																															goto IL_02ee;
																														case 50:
																															goto end_IL_02ee;
																														case 58:
																														case 61:
																															goto end_IL_02fe;
																														case 39:
																															goto IL_0319;
																														case 108:
																															goto IL_0332;
																														case 83:
																															goto IL_0340;
																														case 69:
																														case 107:
																															goto IL_034e;
																														case 8:
																															goto IL_038e;
																														case 29:
																															goto IL_03a2;
																														case 111:
																															goto IL_03b5;
																														case 18:
																														case 113:
																															goto IL_03c0;
																														case 57:
																															goto end_IL_0275;
																														case 104:
																														case 120:
																															goto IL_03e1;
																														case 31:
																															goto IL_03ef;
																														case 75:
																															goto IL_0412;
																														case 42:
																															goto IL_0425;
																														case 84:
																															goto IL_0433;
																														case 79:
																														case 135:
																															goto IL_0446;
																														case 2:
																															goto IL_0486;
																														case 72:
																															goto IL_049a;
																														case 0:
																														case 130:
																															goto IL_04bb;
																														case 123:
																															goto IL_04d4;
																														case 77:
																															goto IL_04e2;
																														case 80:
																															goto IL_04f0;
																														case 118:
																															goto IL_0503;
																														case 114:
																															goto IL_0511;
																														case 44:
																														case 62:
																															goto IL_051f;
																														case 82:
																															goto IL_0548;
																														case 12:
																															goto IL_0556;
																														case 67:
																														case 134:
																															goto IL_0569;
																														case 24:
																															goto IL_0581;
																														case 25:
																															goto IL_058f;
																														case 48:
																														case 88:
																															goto IL_059a;
																														case 53:
																															goto IL_05ae;
																														case 106:
																															goto IL_05ed;
																														case 37:
																															goto IL_0600;
																														case 30:
																															goto IL_060e;
																														case 7:
																														case 93:
																															goto IL_0619;
																														case 55:
																															goto IL_0627;
																														case 27:
																														case 65:
																															goto IL_0635;
																														case 90:
																															goto IL_0658;
																														case 126:
																															goto IL_0666;
																														case 98:
																															goto IL_0674;
																														case 95:
																														case 97:
																															goto IL_0687;
																														case 115:
																															goto IL_06e9;
																														case 71:
																														case 131:
																															goto IL_0705;
																														case 117:
																															goto IL_0713;
																														case 56:
																														case 125:
																															goto IL_0721;
																														case 119:
																															goto IL_0761;
																														case 15:
																															goto IL_0775;
																														case 85:
																															goto IL_078e;
																														case 11:
																															goto IL_0799;
																														case 5:
																														case 47:
																															goto IL_07a4;
																														case 32:
																															goto IL_07af;
																														case 33:
																														case 64:
																															goto IL_07ba;
																														case 22:
																														case 34:
																															goto IL_07ca;
																														case 133:
																															goto IL_07e3;
																														case 92:
																															goto IL_07ee;
																														case 13:
																														case 16:
																														case 19:
																														case 36:
																														case 40:
																														case 41:
																														case 45:
																														case 46:
																														case 54:
																														case 66:
																														case 68:
																														case 76:
																														case 78:
																														case 81:
																														case 86:
																														case 87:
																														case 91:
																														case 99:
																														case 102:
																														case 109:
																														case 116:
																														case 121:
																														case 122:
																														case 127:
																														case 132:
																															goto end_IL_02de;
																														case 1:
																														case 3:
																														case 9:
																														case 17:
																														case 23:
																														case 38:
																														case 43:
																														case 49:
																														case 63:
																														case 89:
																														case 94:
																														case 100:
																														case 103:
																														case 105:
																														case 112:
																														case 128:
																														case 136:
																															goto end_IL_030e;
																														case 14:
																															goto end_IL_080c;
																														case 110:
																															goto end_IL_081f;
																														case 4:
																															goto end_IL_0829;
																														case 10:
																															goto end_IL_0834;
																														case 21:
																														case 28:
																															goto end_IL_0849;
																														case 96:
																															goto end_IL_0859;
																														case 60:
																														case 73:
																															goto end_IL_0869;
																														case 51:
																															goto end_IL_0879;
																														case 52:
																															goto end_IL_0889;
																														case 35:
																														case 59:
																															goto IL_08a4;
																														}
																														continue;
																													}
																													if (1 > b)
																													{
																														goto end_IL_02de;
																													}
																													goto IL_04bb;
																													IL_04d4:
																													array[num5] = 0;
																													goto IL_04e2;
																													IL_04f0:
																													ptr2 += 8;
																													goto end_IL_030e;
																													IL_04e2:
																													num5++;
																													goto IL_04f0;
																													IL_04bb:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_04d4;
																													continue;
																													end_IL_0275:
																													break;
																												}
																												break;
																											}
																											goto IL_0503;
																											IL_0548:
																											ptr2 += 8;
																											goto IL_0556;
																											IL_0556:
																											num5--;
																											goto end_IL_030e;
																											IL_0503:
																											if (2 < b)
																											{
																												goto end_IL_02de;
																											}
																											goto IL_0511;
																											IL_0511:
																											if (2 > b)
																											{
																												goto end_IL_02de;
																											}
																											goto IL_051f;
																											IL_051f:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0548;
																										}
																										break;
																									}
																									goto IL_0569;
																									IL_0569:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_030e;
																								}
																								goto IL_03ce;
																							}
																							goto IL_0319;
																							IL_034e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_038e;
																							IL_038e:
																							array[num5 - 2] = 0;
																							goto IL_03a2;
																							IL_0319:
																							if (5 < b)
																							{
																								goto IL_0332;
																							}
																							num = 111;
																							goto IL_03b5;
																							IL_03a2:
																							num5--;
																							goto end_IL_030e;
																							IL_03b5:
																							if (5 > b)
																							{
																								goto IL_03c0;
																							}
																							goto IL_03e1;
																							IL_03c0:
																							if (4 < b)
																							{
																								goto end_IL_02de;
																							}
																							goto IL_03ce;
																							IL_03ce:
																							if (4 > b)
																							{
																								goto end_IL_02de;
																							}
																							goto end_IL_030e;
																							IL_03e1:
																							array[num5] = 0;
																							goto IL_03ef;
																							IL_03ef:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0412;
																							IL_0412:
																							array2[num5] = null;
																							num = 42;
																							goto IL_0425;
																							IL_0425:
																							num5++;
																							goto IL_0433;
																							IL_0433:
																							ptr2 += 8;
																							goto end_IL_030e;
																							IL_0332:
																							if (6 < b)
																							{
																								goto end_IL_02de;
																							}
																							goto IL_0340;
																							IL_0340:
																							if (6 > b)
																							{
																								goto end_IL_02de;
																							}
																							goto IL_034e;
																							continue;
																							end_IL_02ae:
																							break;
																						}
																						continue;
																					}
																					goto IL_0446;
																					IL_049a:
																					num5--;
																					goto end_IL_030e;
																					IL_0446:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0486;
																					IL_0486:
																					array[num5 - 2] = 0;
																					goto IL_049a;
																					continue;
																					end_IL_02be:
																					break;
																				}
																				continue;
																			}
																			goto IL_0581;
																			IL_07e3:
																			if (14 < b)
																			{
																				goto end_IL_02de;
																			}
																			goto IL_07ee;
																			IL_0581:
																			if (11 >= b)
																			{
																				goto IL_058f;
																			}
																			goto IL_078e;
																			IL_058f:
																			if (11 <= b)
																			{
																				goto IL_059a;
																			}
																			goto IL_0600;
																			IL_059a:
																			array[num5 - 1] = 0;
																			goto IL_05ae;
																			IL_05ae:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)RelativePathToNotHebrewDigit[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_05ed;
																			IL_05ed:
																			ptr2 += 8;
																			goto end_IL_030e;
																			IL_0600:
																			if (9 >= b)
																			{
																				goto IL_060e;
																			}
																			num = 131;
																			goto IL_0705;
																			IL_060e:
																			if (9 > b)
																			{
																				goto IL_0619;
																			}
																			goto IL_0687;
																			IL_0619:
																			if (8 < b)
																			{
																				goto end_IL_02de;
																			}
																			goto IL_0627;
																			IL_0627:
																			if (8 > b)
																			{
																				goto end_IL_02de;
																			}
																			goto IL_0635;
																			IL_0635:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0658;
																			IL_0658:
																			array[num5] = 0;
																			goto IL_0666;
																			IL_0666:
																			num5++;
																			goto IL_0674;
																			IL_0674:
																			ptr2 += 8;
																			goto end_IL_030e;
																			IL_0687:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06e9;
																			IL_06e9:
																			num5 -= 2;
																			goto end_IL_030e;
																			IL_07ee:
																			if (14 <= b)
																			{
																			}
																			goto end_IL_02de;
																			IL_0705:
																			if (10 < b)
																			{
																				goto end_IL_02de;
																			}
																			goto IL_0713;
																			IL_0713:
																			if (10 > b)
																			{
																				goto end_IL_02de;
																			}
																			goto IL_0721;
																			IL_0721:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0761;
																			IL_0761:
																			array[num5 - 2] = 0;
																			goto IL_0775;
																			IL_0775:
																			num5--;
																			num = 100;
																			goto end_IL_030e;
																			IL_078e:
																			if (13 >= b)
																			{
																				goto IL_0799;
																			}
																			goto IL_07e3;
																			IL_0799:
																			if (13 > b)
																			{
																				goto IL_07a4;
																			}
																			goto IL_07ca;
																			IL_07a4:
																			if (12 < b)
																			{
																				goto end_IL_02de;
																			}
																			goto IL_07af;
																			IL_07af:
																			if (12 > b)
																			{
																				goto end_IL_02de;
																			}
																			goto IL_07ba;
																			IL_07ba:
																			num5--;
																			goto end_IL_030e;
																			IL_07ca:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_030e;
																			continue;
																			end_IL_02ce:
																			break;
																		}
																		continue;
																		end_IL_02de:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_030e;
																continue;
																end_IL_02ee:
																break;
															}
															continue;
															end_IL_02fe:
															break;
														}
														continue;
														end_IL_030e:
														break;
													}
													continue;
												}
												goto IL_08a4;
												IL_08a4:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_080c:
												break;
											}
											continue;
											end_IL_081f:
											break;
										}
										continue;
										end_IL_0829:
										break;
									}
									continue;
									end_IL_0834:
									break;
								}
								continue;
								end_IL_0849:
								break;
							}
							continue;
							end_IL_0859:
							break;
						}
						continue;
						end_IL_0869:
						break;
					}
					continue;
					end_IL_0879:
					break;
				}
				continue;
				end_IL_0889:
				break;
			}
		}
	}

	static Class188()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 17;
					while (true)
					{
						if (num != 17)
						{
							if (num != 998)
							{
								break;
							}
							switch (num)
							{
							case 3:
							case 4:
							case 5:
							case 6:
							case 7:
							case 8:
							case 10:
								goto end_IL_0050;
							case 0:
								goto end_IL_005d;
							case 1:
								goto end_IL_007b;
							case 2:
								return;
							case 9:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0050:
						break;
					}
					continue;
					end_IL_005d:
					break;
				}
				continue;
				end_IL_007b:
				break;
			}
		}
	}

	private static void TypedReferenceGetToken(Class188 class188_1)
	{
		class188_1.method_1();
	}

	private static void CurrentThreadIsFixedDateRule(Class188 class188_1)
	{
		class188_1.method_1();
	}
}
