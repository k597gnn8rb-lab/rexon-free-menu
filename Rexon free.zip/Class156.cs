using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Show Reports", "Safety", "Shows report notifications when reports are sent.", false, 12, ModType.const_0, false)]
internal class Class156 : MonoBehaviour
{
	public static bool bool_0;

	private static double double_0;

	private static float float_0;

	private static double double_1;

	private static bool bool_1;

	private static int int_0;

	private static bool bool_2;

	private static double double_2;

	private static IntPtr[] EnumEventsTargetMethods;

	private static IntPtr[] getIsSynchronizedBinaryAssembly;

	private static IntPtr[] ResourceLocationOperation;

	private unsafe void OnEnable()
	{
		int num = 81;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 13;
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DefaultEncoderSHAManaged.ToBaseStringgetPriority);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												num = 108;
												while (true)
												{
													ptr2++;
													num = 39;
													while (true)
													{
														IL_02ec:
														if (b >= 1)
														{
															while (b <= 14)
															{
																while (true)
																{
																	IL_02cf:
																	if (7 < b)
																	{
																		while (true)
																		{
																			IL_02bf:
																			if (11 >= b)
																			{
																				while (true)
																				{
																					IL_02af:
																					if (11 > b)
																					{
																						while (true)
																						{
																							IL_029f:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_028f:
																									if (9 > b)
																									{
																										while (8 >= b)
																										{
																											while (8 <= b)
																											{
																												num = 143;
																												while (true)
																												{
																													if (num != 143)
																													{
																														if (num != 1124)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 22:
																															goto IL_026c;
																														case 46:
																														case 132:
																															goto IL_027f;
																														case 8:
																															goto IL_028f;
																														case 95:
																														case 111:
																															goto IL_029f;
																														case 69:
																															goto IL_02af;
																														case 44:
																															goto IL_02bf;
																														case 20:
																															goto IL_02cf;
																														case 88:
																															goto IL_02dc;
																														case 39:
																															goto IL_02ec;
																														case 108:
																															goto end_IL_02ec;
																														case 33:
																														case 123:
																															goto end_IL_02fc;
																														case 17:
																															goto IL_0329;
																														case 30:
																															goto IL_0337;
																														case 41:
																															goto IL_0342;
																														case 14:
																														case 55:
																															goto IL_0350;
																														case 60:
																															goto IL_0360;
																														case 61:
																															goto IL_0373;
																														case 12:
																														case 65:
																															goto IL_038f;
																														case 21:
																															goto IL_03cf;
																														case 0:
																														case 68:
																															goto IL_03e8;
																														case 47:
																															goto IL_0428;
																														case 35:
																														case 83:
																															goto IL_0441;
																														case 93:
																															goto IL_0458;
																														case 25:
																														case 54:
																															goto IL_0466;
																														case 66:
																															goto IL_04a6;
																														case 3:
																															goto IL_04ba;
																														case 99:
																															goto IL_04cd;
																														case 11:
																														case 53:
																															goto IL_04d8;
																														case 16:
																															goto IL_0518;
																														case 10:
																															goto IL_0535;
																														case 28:
																														case 89:
																															goto IL_0548;
																														case 42:
																															goto IL_0556;
																														case 106:
																															goto IL_0566;
																														case 56:
																														case 113:
																															goto IL_0579;
																														case 62:
																															goto IL_05a2;
																														case 5:
																															goto IL_05b0;
																														case 92:
																														case 118:
																															goto IL_05c3;
																														case 109:
																															goto end_IL_0259;
																														case 94:
																															goto IL_05f4;
																														case 119:
																															goto IL_0600;
																														case 131:
																															goto IL_0613;
																														case 73:
																															goto IL_062a;
																														case 134:
																															goto IL_063d;
																														case 23:
																															goto IL_064b;
																														case 59:
																														case 90:
																															goto IL_0659;
																														case 31:
																															goto IL_0699;
																														case 52:
																															goto IL_06ad;
																														case 85:
																															goto IL_06c0;
																														case 15:
																															goto IL_06d3;
																														case 26:
																															goto IL_06e1;
																														case 49:
																														case 117:
																															goto IL_06ef;
																														case 120:
																															goto IL_0751;
																														case 116:
																														case 121:
																															goto IL_0764;
																														case 2:
																															goto IL_0772;
																														case 103:
																															goto IL_0796;
																														case 127:
																															goto IL_07a4;
																														case 37:
																															goto IL_07b7;
																														case 19:
																															goto IL_07c2;
																														case 98:
																														case 135:
																															goto IL_07cd;
																														case 130:
																															goto IL_07d8;
																														case 74:
																														case 112:
																															goto IL_07e8;
																														case 67:
																															goto IL_0802;
																														case 38:
																															goto IL_0812;
																														case 71:
																															goto IL_081d;
																														case 18:
																														case 32:
																															goto IL_0828;
																														case 7:
																														case 9:
																														case 24:
																														case 29:
																														case 36:
																														case 40:
																														case 43:
																														case 45:
																														case 50:
																														case 51:
																														case 57:
																														case 63:
																														case 70:
																														case 72:
																														case 75:
																														case 87:
																														case 96:
																														case 101:
																														case 104:
																														case 115:
																														case 126:
																														case 129:
																															goto end_IL_026c;
																														case 114:
																															goto IL_085a;
																														case 124:
																															goto IL_0868;
																														case 58:
																															goto IL_087f;
																														case 1:
																														case 4:
																														case 6:
																														case 27:
																														case 77:
																														case 78:
																														case 82:
																														case 91:
																														case 97:
																														case 100:
																														case 105:
																														case 107:
																														case 110:
																														case 122:
																														case 128:
																														case 133:
																														case 136:
																															goto end_IL_0315;
																														case 102:
																															goto end_IL_088d;
																														case 125:
																															goto end_IL_089d;
																														case 84:
																															goto end_IL_08a7;
																														case 13:
																														case 34:
																															goto end_IL_08b2;
																														case 64:
																															goto end_IL_08c2;
																														case 79:
																														case 86:
																															goto end_IL_08d2;
																														case 80:
																															goto end_IL_08eb;
																														case 81:
																															goto end_IL_08fb;
																														case 48:
																														case 76:
																															return;
																														}
																														continue;
																													}
																													goto IL_06c0;
																													IL_06c0:
																													num5--;
																													goto end_IL_0315;
																													continue;
																													end_IL_0259:
																													break;
																												}
																												goto IL_05d1;
																												continue;
																												end_IL_026c:
																												break;
																												IL_026c:;
																											}
																											break;
																											IL_027f:;
																										}
																										break;
																									}
																									goto IL_038f;
																									IL_0600:
																									num5--;
																									goto end_IL_0315;
																									IL_038f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03cf;
																									IL_03cf:
																									array[num5 - 2] = 0;
																									goto IL_0600;
																								}
																								break;
																							}
																							goto IL_06d3;
																							IL_0751:
																							num5 -= 2;
																							goto end_IL_0315;
																							IL_06d3:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_06e1;
																							IL_06e1:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_06ef;
																							IL_06ef:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0751;
																						}
																						break;
																					}
																					goto IL_0764;
																					IL_07a4:
																					ptr2 += 8;
																					goto end_IL_0315;
																					IL_0764:
																					array[num5] = 0;
																					goto IL_0772;
																					IL_0772:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)EnumEventsTargetMethods[*(int*)(ptr2 + num3)])();
																					goto IL_0796;
																					IL_0796:
																					num5++;
																					goto IL_07a4;
																				}
																				break;
																			}
																			goto IL_07b7;
																			IL_0828:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0315;
																			IL_07b7:
																			if (13 >= b)
																			{
																				goto IL_07c2;
																			}
																			goto IL_0812;
																			IL_07c2:
																			if (13 > b)
																			{
																				goto IL_07cd;
																			}
																			goto IL_07e8;
																			IL_07cd:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_07d8;
																			IL_07d8:
																			if (12 <= b)
																			{
																				goto end_IL_0315;
																			}
																			break;
																			IL_07e8:
																			bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_0802;
																			IL_0802:
																			num5--;
																			goto end_IL_0315;
																			IL_0812:
																			if (14 < b)
																			{
																				break;
																			}
																			goto IL_081d;
																			IL_081d:
																			if (14 > b)
																			{
																				break;
																			}
																			goto IL_0828;
																		}
																		break;
																	}
																	goto IL_0329;
																	IL_03e8:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0428;
																	IL_0329:
																	if (7 > b)
																	{
																		goto IL_0337;
																	}
																	goto IL_03e8;
																	IL_0337:
																	if (3 >= b)
																	{
																		goto IL_0342;
																	}
																	goto IL_0360;
																	IL_0342:
																	if (3 > b)
																	{
																		goto IL_0350;
																	}
																	goto IL_0579;
																	IL_0350:
																	if (1 >= b)
																	{
																		goto IL_0373;
																	}
																	goto IL_063d;
																	IL_0373:
																	if (1 > b)
																	{
																		num = 96;
																	}
																	break;
																	IL_0428:
																	array[num5 - 2] = 0;
																	goto IL_0566;
																	IL_063d:
																	if (2 < b)
																	{
																		break;
																	}
																	goto IL_064b;
																	IL_064b:
																	if (2 > b)
																	{
																		break;
																	}
																	goto IL_0659;
																	IL_0659:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0699;
																	IL_0699:
																	array[num5 - 2] = 0;
																	goto IL_06ad;
																	IL_06ad:
																	num5--;
																	goto end_IL_0315;
																	IL_0579:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05a2;
																	IL_05a2:
																	ptr2 += 8;
																	goto IL_05b0;
																	IL_05b0:
																	num5--;
																	goto end_IL_0315;
																	IL_0360:
																	if (5 < b)
																	{
																		goto IL_0441;
																	}
																	goto IL_04cd;
																	IL_0441:
																	if (6 < b)
																	{
																		break;
																	}
																	num = 93;
																	goto IL_0458;
																	IL_0566:
																	num5--;
																	goto end_IL_0315;
																	IL_0458:
																	if (6 > b)
																	{
																		break;
																	}
																	goto IL_0466;
																	IL_0466:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04a6;
																	IL_04a6:
																	array[num5 - 2] = 0;
																	goto IL_04ba;
																	IL_04ba:
																	num5--;
																	goto end_IL_0315;
																	IL_04cd:
																	if (5 <= b)
																	{
																		goto IL_04d8;
																	}
																	goto IL_0548;
																	IL_04d8:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0518;
																	IL_0518:
																	array[num5 - 2] = 0;
																	num = 10;
																	goto IL_0535;
																	IL_0535:
																	num5--;
																	goto end_IL_0315;
																	IL_0548:
																	if (4 < b)
																	{
																		break;
																	}
																	goto IL_0556;
																	IL_0556:
																	if (4 > b)
																	{
																		break;
																	}
																	goto IL_05c3;
																	IL_05c3:
																	array[num5] = 0;
																	goto IL_05d1;
																	IL_05d1:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05f4;
																	IL_05f4:
																	array2[num5] = null;
																	goto IL_0613;
																	IL_0613:
																	num5++;
																	num = 73;
																	goto IL_062a;
																	IL_062a:
																	ptr2 += 8;
																	goto end_IL_0315;
																}
																break;
																IL_02dc:;
															}
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
														goto IL_085a;
														IL_087f:
														ptr2 += 8;
														goto end_IL_0315;
														IL_0868:
														num5++;
														num = 58;
														goto IL_087f;
														IL_085a:
														array[num5] = 0;
														goto IL_0868;
														continue;
														end_IL_02ec:
														break;
													}
													continue;
													end_IL_02fc:
													break;
												}
												continue;
												end_IL_0315:
												break;
											}
											continue;
											end_IL_088d:
											break;
										}
										continue;
										end_IL_089d:
										break;
									}
									continue;
									end_IL_08a7:
									break;
								}
								continue;
								end_IL_08b2:
								break;
							}
							continue;
							end_IL_08c2:
							break;
						}
						continue;
						end_IL_08d2:
						break;
					}
					continue;
					end_IL_08eb:
					break;
				}
				continue;
				end_IL_08fb:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 34;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DisableActivateAsActivatorgetKind.getCookieGenerateMask);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												IL_0305:
												byte b = *ptr2;
												num = 82;
												while (true)
												{
													IL_02f5:
													ptr2++;
													while (true)
													{
														IL_02e5:
														if (b >= 1)
														{
															while (b <= 14)
															{
																while (true)
																{
																	IL_02c5:
																	if (7 < b)
																	{
																		while (true)
																		{
																			IL_02b5:
																			if (11 < b)
																			{
																				while (true)
																				{
																					IL_02a8:
																					if (13 < b)
																					{
																						while (14 >= b)
																						{
																							while (14 <= b)
																							{
																								while (true)
																								{
																									IL_0266:
																									byte* num5 = ptr2;
																									num4 = 1;
																									ptr2 = num5 + -200;
																									num = 145;
																									while (num != 145)
																									{
																										if (num != 1126)
																										{
																											goto IL_0266;
																										}
																										switch (num)
																										{
																										case 92:
																										case 129:
																											goto IL_0266;
																										case 99:
																											goto IL_0288;
																										case 102:
																											goto IL_0298;
																										case 104:
																											goto IL_02a8;
																										case 44:
																											goto IL_02b5;
																										case 111:
																											goto IL_02c5;
																										case 30:
																											goto IL_02d5;
																										case 117:
																											goto IL_02e5;
																										case 82:
																											goto IL_02f5;
																										case 5:
																										case 116:
																											goto IL_0305;
																										case 31:
																											goto IL_0319;
																										case 28:
																										case 35:
																											goto IL_0324;
																										case 54:
																											goto IL_0332;
																										case 85:
																											goto IL_0345;
																										case 42:
																										case 123:
																											goto IL_0355;
																										case 8:
																											goto IL_036f;
																										case 127:
																											goto IL_0382;
																										case 36:
																											goto IL_0390;
																										case 114:
																											goto IL_039e;
																										case 25:
																										case 56:
																											goto IL_03ac;
																										case 74:
																											goto IL_040e;
																										case 128:
																											goto IL_042a;
																										case 95:
																										case 124:
																											goto IL_0435;
																										case 26:
																											goto IL_0475;
																										case 97:
																											goto IL_048e;
																										case 62:
																											goto IL_049c;
																										case 37:
																										case 49:
																											goto IL_04aa;
																										case 22:
																										case 135:
																											goto IL_04bd;
																										case 119:
																											goto IL_04da;
																										case 61:
																											goto IL_0537;
																										case 126:
																											goto IL_0545;
																										case 138:
																											goto IL_0558;
																										case 10:
																											goto IL_056b;
																										case 1:
																										case 21:
																											goto IL_0579;
																										case 121:
																											goto IL_0587;
																										case 20:
																										case 98:
																											goto IL_0592;
																										case 14:
																											goto IL_05bb;
																										case 9:
																											goto IL_05c9;
																										case 133:
																											goto IL_05dc;
																										case 53:
																										case 118:
																											goto IL_05ea;
																										case 80:
																											goto IL_05f8;
																										case 66:
																										case 71:
																											goto IL_0606;
																										case 48:
																											goto IL_0646;
																										case 43:
																											goto IL_065a;
																										case 45:
																											goto IL_066d;
																										case 69:
																											goto IL_0680;
																										case 4:
																											goto IL_068e;
																										case 24:
																											goto IL_0699;
																										case 91:
																											goto IL_06a7;
																										case 13:
																										case 115:
																											goto IL_06b5;
																										case 108:
																											goto IL_06c3;
																										case 38:
																											goto IL_06e6;
																										case 75:
																											goto IL_06f0;
																										case 3:
																											goto IL_06fe;
																										case 132:
																										case 134:
																											goto IL_0711;
																										case 96:
																											goto IL_0751;
																										case 100:
																											goto IL_076e;
																										case 27:
																										case 112:
																											goto IL_0781;
																										case 122:
																											goto IL_0798;
																										case 6:
																										case 11:
																											goto IL_07a3;
																										case 81:
																											goto IL_07e3;
																										case 18:
																											goto IL_0800;
																										case 12:
																										case 15:
																										case 16:
																										case 17:
																										case 41:
																										case 60:
																										case 64:
																										case 65:
																										case 67:
																										case 70:
																										case 73:
																										case 76:
																										case 77:
																										case 78:
																										case 79:
																										case 83:
																										case 84:
																										case 86:
																										case 87:
																										case 94:
																										case 106:
																										case 109:
																										case 120:
																										case 125:
																										case 130:
																										case 136:
																											goto end_IL_0288;
																										case 57:
																											goto IL_082c;
																										case 88:
																											goto IL_083a;
																										case 103:
																											goto IL_0848;
																										case 29:
																										case 101:
																											goto IL_0861;
																										case 47:
																											goto IL_08a1;
																										case 23:
																											goto IL_08b5;
																										case 0:
																										case 7:
																										case 19:
																										case 32:
																										case 39:
																										case 40:
																										case 50:
																										case 51:
																										case 55:
																										case 59:
																										case 63:
																										case 72:
																										case 93:
																										case 107:
																										case 113:
																										case 131:
																											goto end_IL_0253;
																										case 58:
																											goto end_IL_08c3;
																										case 90:
																											goto end_IL_08d3;
																										case 105:
																											goto end_IL_08dd;
																										case 52:
																										case 137:
																											goto end_IL_08e8;
																										case 2:
																											goto end_IL_08f8;
																										case 46:
																										case 68:
																											goto end_IL_0908;
																										case 33:
																											goto end_IL_0918;
																										case 34:
																											goto end_IL_0928;
																										case 89:
																										case 110:
																											return;
																										}
																										continue;
																										end_IL_0253:
																										break;
																									}
																									break;
																								}
																								goto end_IL_02e5;
																								continue;
																								end_IL_0288:
																								break;
																								IL_0288:;
																							}
																							break;
																							IL_0298:;
																						}
																						break;
																					}
																					goto IL_0319;
																					IL_036f:
																					num6--;
																					goto end_IL_02e5;
																					IL_0319:
																					if (13 > b)
																					{
																						goto IL_0324;
																					}
																					goto IL_0355;
																					IL_0324:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_0332;
																					IL_0332:
																					if (12 > b)
																					{
																						break;
																					}
																					goto end_IL_02e5;
																					IL_0355:
																					bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																					goto IL_036f;
																				}
																				break;
																			}
																			goto IL_0345;
																			IL_049c:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_04aa;
																			IL_0345:
																			if (11 > b)
																			{
																				goto IL_0382;
																			}
																			goto IL_04bd;
																			IL_04bd:
																			array[num6 - 2] = 0;
																			num = 119;
																			goto IL_04da;
																			IL_04da:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)getIsSynchronizedBinaryAssembly[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			num = 61;
																			goto IL_0537;
																			IL_0537:
																			num6--;
																			goto IL_0545;
																			IL_0545:
																			ptr2 += 8;
																			goto end_IL_02e5;
																			IL_0382:
																			if (9 < b)
																			{
																				goto IL_0390;
																			}
																			num = 128;
																			goto IL_042a;
																			IL_0390:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_039e;
																			IL_039e:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_03ac;
																			IL_03ac:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_040e;
																			IL_040e:
																			num6 -= 2;
																			goto end_IL_02e5;
																			IL_04aa:
																			num6--;
																			goto end_IL_02e5;
																			IL_042a:
																			if (9 <= b)
																			{
																				goto IL_0435;
																			}
																			goto IL_048e;
																			IL_0435:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0475;
																			IL_0475:
																			array[num6 - 2] = 0;
																			goto IL_0558;
																			IL_0558:
																			num6--;
																			goto end_IL_02e5;
																			IL_048e:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_049c;
																		}
																		break;
																	}
																	goto IL_056b;
																	IL_08a1:
																	array[num6 - 2] = 0;
																	goto IL_08b5;
																	IL_056b:
																	if (7 > b)
																	{
																		goto IL_0579;
																	}
																	goto IL_0861;
																	IL_0579:
																	if (3 >= b)
																	{
																		goto IL_0587;
																	}
																	goto IL_0680;
																	IL_0587:
																	if (3 <= b)
																	{
																		goto IL_0592;
																	}
																	goto IL_05dc;
																	IL_0592:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_05bb;
																	IL_05bb:
																	ptr2 += 8;
																	goto IL_05c9;
																	IL_05c9:
																	num6--;
																	goto end_IL_02e5;
																	IL_05dc:
																	if (1 < b)
																	{
																		goto IL_05ea;
																	}
																	goto IL_066d;
																	IL_05ea:
																	if (2 < b)
																	{
																		break;
																	}
																	goto IL_05f8;
																	IL_05f8:
																	if (2 > b)
																	{
																		break;
																	}
																	goto IL_0606;
																	IL_0606:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0646;
																	IL_0646:
																	array[num6 - 2] = 0;
																	goto IL_065a;
																	IL_065a:
																	num6--;
																	goto end_IL_02e5;
																	IL_066d:
																	if (1 <= b)
																	{
																	}
																	break;
																	IL_0680:
																	if (5 >= b)
																	{
																		goto IL_068e;
																	}
																	goto IL_0781;
																	IL_068e:
																	if (5 > b)
																	{
																		goto IL_0699;
																	}
																	goto IL_0711;
																	IL_0699:
																	if (4 < b)
																	{
																		break;
																	}
																	goto IL_06a7;
																	IL_06a7:
																	if (4 > b)
																	{
																		break;
																	}
																	goto IL_06b5;
																	IL_06b5:
																	array[num6] = 0;
																	goto IL_06c3;
																	IL_06c3:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e6;
																	IL_06e6:
																	array2[num6] = null;
																	goto IL_06f0;
																	IL_06f0:
																	num6++;
																	goto IL_06fe;
																	IL_06fe:
																	ptr2 += 8;
																	goto end_IL_02e5;
																	IL_0711:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0751;
																	IL_0751:
																	array[num6 - 2] = 0;
																	num = 100;
																	goto IL_076e;
																	IL_076e:
																	num6--;
																	goto end_IL_02e5;
																	IL_0781:
																	if (6 < b)
																	{
																		break;
																	}
																	num = 122;
																	goto IL_0798;
																	IL_08b5:
																	num6--;
																	goto end_IL_02e5;
																	IL_0798:
																	if (6 > b)
																	{
																		break;
																	}
																	goto IL_07a3;
																	IL_07a3:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_07e3;
																	IL_07e3:
																	array[num6 - 2] = 0;
																	num = 18;
																	goto IL_0800;
																	IL_0800:
																	num6--;
																	goto end_IL_02e5;
																	IL_0861:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_08a1;
																}
																break;
																IL_02d5:;
															}
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
														goto IL_082c;
														IL_0848:
														ptr2 += 8;
														num = 59;
														break;
														IL_083a:
														num6++;
														goto IL_0848;
														IL_082c:
														array[num6] = 0;
														goto IL_083a;
														continue;
														end_IL_02e5:
														break;
													}
													break;
												}
												break;
											}
											continue;
											end_IL_08c3:
											break;
										}
										continue;
										end_IL_08d3:
										break;
									}
									continue;
									end_IL_08dd:
									break;
								}
								continue;
								end_IL_08e8:
								break;
							}
							continue;
							end_IL_08f8:
							break;
						}
						continue;
						end_IL_0908:
						break;
					}
					continue;
					end_IL_0918:
					break;
				}
				continue;
				end_IL_0928:
				break;
			}
		}
	}

	public Class156()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 99;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref addReflectionOnlyNamespaceResolveResourceManagerFoundResourceSetInCacheUnexpected.RSAPKCSSignatureDeformatterGAC);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02e3:
															byte b = *ptr2;
															while (true)
															{
																IL_02d3:
																ptr2++;
																while (true)
																{
																	IL_02c3:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02a3:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0293:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0283:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0273:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0266:
																												if (1 >= b)
																												{
																													while (1 <= b)
																													{
																														while (true)
																														{
																															IL_023b:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_022b:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_021b:
																																	num5++;
																																	while (true)
																																	{
																																		IL_0202:
																																		ptr2 += 8;
																																		num = 120;
																																		while (num != 120)
																																		{
																																			if (num != 1101)
																																			{
																																				goto IL_061d;
																																			}
																																			switch (num)
																																			{
																																			case 58:
																																				goto IL_0202;
																																			case 104:
																																				goto IL_021b;
																																			case 42:
																																				goto IL_022b;
																																			case 69:
																																			case 82:
																																				goto IL_023b;
																																			case 60:
																																				goto IL_0256;
																																			case 56:
																																				goto IL_0266;
																																			case 21:
																																				goto IL_0273;
																																			case 37:
																																			case 88:
																																				goto IL_0283;
																																			case 27:
																																				goto IL_0293;
																																			case 44:
																																				goto IL_02a3;
																																			case 52:
																																				goto IL_02b3;
																																			case 79:
																																				goto IL_02c3;
																																			case 86:
																																				goto IL_02d3;
																																			case 15:
																																			case 85:
																																				goto IL_02e3;
																																			case 34:
																																				goto IL_02ee;
																																			case 14:
																																				goto IL_02fc;
																																			case 18:
																																			case 71:
																																				goto IL_030c;
																																			case 4:
																																			case 95:
																																				goto IL_0324;
																																			case 35:
																																			case 98:
																																				goto IL_0352;
																																			case 55:
																																				goto IL_035d;
																																			case 6:
																																			case 106:
																																				goto IL_0370;
																																			case 102:
																																				goto IL_037e;
																																			case 92:
																																			case 110:
																																				goto IL_038c;
																																			case 51:
																																				goto IL_039a;
																																			case 16:
																																				goto IL_03bd;
																																			case 0:
																																				goto IL_03c7;
																																			case 40:
																																				goto IL_03de;
																																			case 112:
																																				goto IL_03f1;
																																			case 94:
																																				goto IL_03ff;
																																			case 20:
																																			case 49:
																																				goto IL_0412;
																																			case 81:
																																				goto IL_045b;
																																			case 77:
																																				goto IL_046f;
																																			case 11:
																																				goto IL_0482;
																																			case 67:
																																				goto IL_0490;
																																			case 45:
																																			case 100:
																																				goto IL_049e;
																																			case 28:
																																			case 93:
																																				goto IL_04a9;
																																			case 17:
																																				goto IL_04b7;
																																			case 12:
																																			case 72:
																																				goto IL_04c5;
																																			case 26:
																																				goto IL_04e8;
																																			case 36:
																																				goto IL_04f6;
																																			case 64:
																																				goto IL_0504;
																																			case 48:
																																				goto IL_0517;
																																			case 78:
																																			case 103:
																																				goto IL_052e;
																																			case 96:
																																				goto IL_056e;
																																			case 90:
																																				goto IL_0582;
																																			case 32:
																																			case 76:
																																				goto IL_0595;
																																			case 3:
																																				goto IL_05f7;
																																			case 91:
																																				goto IL_0607;
																																			case 2:
																																			case 107:
																																				goto IL_0612;
																																			case 41:
																																				goto IL_061d;
																																			case 113:
																																				goto IL_062a;
																																			case 43:
																																			case 63:
																																				goto IL_0635;
																																			case 1:
																																			case 5:
																																			case 8:
																																			case 9:
																																			case 10:
																																			case 22:
																																			case 29:
																																			case 30:
																																			case 31:
																																			case 33:
																																			case 39:
																																			case 46:
																																			case 54:
																																			case 61:
																																			case 62:
																																			case 80:
																																			case 87:
																																			case 97:
																																			case 109:
																																			case 111:
																																				goto end_IL_0256;
																																			case 19:
																																			case 23:
																																			case 24:
																																			case 25:
																																			case 38:
																																			case 50:
																																			case 59:
																																			case 70:
																																			case 75:
																																			case 84:
																																			case 101:
																																			case 105:
																																			case 108:
																																				goto end_IL_01ef;
																																			case 7:
																																				goto end_IL_066a;
																																			case 83:
																																				goto end_IL_067d;
																																			case 47:
																																				goto end_IL_0687;
																																			case 57:
																																				goto end_IL_0692;
																																			case 99:
																																				goto end_IL_06a7;
																																			case 65:
																																				goto end_IL_06b7;
																																			case 66:
																																				goto end_IL_06c7;
																																			case 13:
																																			case 89:
																																				goto end_IL_06d2;
																																			case 73:
																																				goto end_IL_06e2;
																																			case 74:
																																				goto end_IL_06f2;
																																			case 53:
																																			case 68:
																																				goto IL_070d;
																																			}
																																			continue;
																																			end_IL_01ef:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02c3;
																														continue;
																														end_IL_0256:
																														break;
																														IL_0256:;
																													}
																													break;
																												}
																												goto IL_02ee;
																												IL_03ff:
																												num5--;
																												goto end_IL_02c3;
																												IL_02ee:
																												if (2 < b)
																												{
																													break;
																												}
																												goto IL_02fc;
																												IL_02fc:
																												if (2 > b)
																												{
																													break;
																												}
																												goto IL_0324;
																												IL_0324:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_03f1;
																												IL_03f1:
																												ptr2 += 8;
																												goto IL_03ff;
																											}
																											break;
																										}
																										goto IL_030c;
																										IL_030c:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02c3;
																									}
																									break;
																								}
																								goto IL_0352;
																								IL_03de:
																								ptr2 += 8;
																								goto end_IL_02c3;
																								IL_0352:
																								if (4 >= b)
																								{
																									goto IL_035d;
																								}
																								goto IL_0370;
																								IL_035d:
																								if (4 <= b)
																								{
																									goto end_IL_02c3;
																								}
																								break;
																								IL_0370:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_037e;
																								IL_037e:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_038c;
																								IL_038c:
																								array[num5] = 0;
																								goto IL_039a;
																								IL_039a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03bd;
																								IL_03bd:
																								array2[num5] = null;
																								goto IL_03c7;
																								IL_03c7:
																								num5++;
																								num = 40;
																								goto IL_03de;
																							}
																							break;
																						}
																						goto IL_0412;
																						IL_046f:
																						num5--;
																						goto end_IL_02c3;
																						IL_0412:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 81;
																						goto IL_045b;
																						IL_045b:
																						array[num5 - 2] = 0;
																						goto IL_046f;
																					}
																					break;
																				}
																				goto IL_0482;
																				IL_062a:
																				if (10 > b)
																				{
																					num = 46;
																					break;
																				}
																				goto IL_0635;
																				IL_0482:
																				if (9 >= b)
																				{
																					goto IL_0490;
																				}
																				goto IL_0607;
																				IL_0490:
																				if (9 > b)
																				{
																					goto IL_049e;
																				}
																				goto IL_0595;
																				IL_049e:
																				if (7 < b)
																				{
																					goto IL_04a9;
																				}
																				goto IL_0517;
																				IL_04a9:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_04b7;
																				IL_04b7:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04c5;
																				IL_04c5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04e8;
																				IL_04e8:
																				array[num5] = 0;
																				goto IL_04f6;
																				IL_04f6:
																				num5++;
																				goto IL_0504;
																				IL_0504:
																				ptr2 += 8;
																				goto end_IL_02c3;
																				IL_0517:
																				if (7 > b)
																				{
																					break;
																				}
																				num = 78;
																				goto IL_052e;
																				IL_0635:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02c3;
																				IL_052e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_056e;
																				IL_056e:
																				array[num5 - 2] = 0;
																				goto IL_0582;
																				IL_0582:
																				num5--;
																				goto end_IL_02c3;
																				IL_0595:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05f7;
																				IL_05f7:
																				num5 -= 2;
																				goto end_IL_02c3;
																				IL_0607:
																				if (10 < b)
																				{
																					goto IL_0612;
																				}
																				goto IL_062a;
																				IL_0612:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_061d;
																				IL_061d:
																				if (11 > b)
																				{
																				}
																				break;
																			}
																			break;
																			IL_02b3:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02c3:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_070d;
													IL_070d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_066a:
													break;
												}
												continue;
												end_IL_067d:
												break;
											}
											continue;
											end_IL_0687:
											break;
										}
										continue;
										end_IL_0692:
										break;
									}
									continue;
									end_IL_06a7:
									break;
								}
								continue;
								end_IL_06b7:
								break;
							}
							continue;
							end_IL_06c7:
							break;
						}
						continue;
						end_IL_06d2:
						break;
					}
					continue;
					end_IL_06e2:
					break;
				}
				continue;
				end_IL_06f2:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 73;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 22;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 84;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreateFileBasedResourceManagerAddSeconds.IsStateAvailablergdispidNamedArgs);
										while (true)
										{
											IL_06ad:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_069a:
												if (num4 != 1)
												{
													while (true)
													{
														IL_029c:
														byte b = *ptr2;
														num = 110;
														while (true)
														{
															IL_028c:
															ptr2++;
															while (true)
															{
																IL_027c:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_025c:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_024c:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_023c:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_022f:
																									if (4 < b)
																									{
																										while (true)
																										{
																											IL_021c:
																											if (5 < b)
																											{
																												num = 123;
																												while (num != 123)
																												{
																													if (num != 1104)
																													{
																														goto end_IL_027c;
																													}
																													switch (num)
																													{
																													case 24:
																														goto IL_021c;
																													case 102:
																														goto IL_022f;
																													case 85:
																														goto IL_023c;
																													case 29:
																														goto IL_024c;
																													case 100:
																														goto IL_025c;
																													case 14:
																														goto IL_026c;
																													case 49:
																														goto IL_027c;
																													case 110:
																														goto IL_028c;
																													case 7:
																													case 86:
																														goto IL_029c;
																													case 31:
																														goto IL_02b0;
																													case 32:
																														goto IL_02cc;
																													case 0:
																													case 37:
																														goto IL_02da;
																													case 16:
																													case 35:
																														goto IL_02e5;
																													case 10:
																														goto IL_02f5;
																													case 54:
																														goto IL_0305;
																													case 5:
																													case 55:
																														goto IL_0315;
																													case 3:
																														goto IL_032e;
																													case 13:
																													case 62:
																														goto IL_0341;
																													case 68:
																														goto IL_0354;
																													case 58:
																													case 63:
																														goto IL_0362;
																													case 52:
																													case 71:
																														goto IL_0390;
																													case 19:
																													case 67:
																														goto IL_039b;
																													case 60:
																														goto IL_03a9;
																													case 18:
																														goto IL_03bc;
																													case 42:
																													case 43:
																														goto IL_03ca;
																													case 66:
																														goto IL_042c;
																													case 92:
																													case 93:
																														goto IL_043f;
																													case 96:
																														goto IL_045b;
																													case 76:
																														goto IL_0469;
																													case 23:
																													case 98:
																														goto IL_047c;
																													case 8:
																														goto IL_048a;
																													case 103:
																														goto IL_049d;
																													case 78:
																													case 104:
																														goto IL_04ad;
																													case 109:
																														goto IL_04ce;
																													case 1:
																														goto IL_04f1;
																													case 34:
																														goto IL_04fb;
																													case 4:
																														goto IL_0509;
																													case 111:
																														goto IL_051c;
																													case 113:
																														goto IL_052f;
																													case 108:
																														goto IL_053a;
																													case 59:
																													case 94:
																														goto IL_0548;
																													case 105:
																														goto IL_0588;
																													case 99:
																														goto IL_059c;
																													case 25:
																														goto IL_05af;
																													case 11:
																														goto IL_05bd;
																													case 46:
																													case 79:
																														goto IL_05cb;
																													case 83:
																														goto IL_05f7;
																													case 39:
																														goto IL_0605;
																													case 107:
																														goto IL_0613;
																													case 12:
																													case 70:
																														goto IL_0623;
																													case 33:
																														goto IL_0663;
																													case 45:
																														goto IL_0677;
																													case 2:
																													case 6:
																													case 15:
																													case 20:
																													case 21:
																													case 30:
																													case 36:
																													case 38:
																													case 40:
																													case 41:
																													case 47:
																													case 51:
																													case 56:
																													case 57:
																													case 61:
																													case 64:
																													case 65:
																													case 74:
																													case 81:
																													case 82:
																													case 87:
																													case 88:
																													case 114:
																														goto end_IL_0209;
																													case 17:
																													case 26:
																													case 27:
																													case 28:
																													case 48:
																													case 50:
																													case 53:
																													case 75:
																													case 77:
																													case 80:
																													case 90:
																													case 95:
																													case 101:
																													case 116:
																														goto IL_069a;
																													case 9:
																														goto IL_06ad;
																													case 106:
																														goto end_IL_027c;
																													case 112:
																														goto end_IL_06b7;
																													case 115:
																														goto end_IL_06c2;
																													case 44:
																													case 84:
																														goto end_IL_06d7;
																													case 91:
																														goto end_IL_06e7;
																													case 22:
																													case 97:
																														goto end_IL_06f7;
																													case 72:
																														goto end_IL_0710;
																													case 73:
																														goto end_IL_0720;
																													case 69:
																													case 89:
																														goto IL_0744;
																													}
																													continue;
																													end_IL_0209:
																													break;
																												}
																												break;
																											}
																											goto IL_0305;
																											IL_04fb:
																											num5++;
																											goto IL_0509;
																											IL_0509:
																											ptr2 += 8;
																											goto IL_069a;
																											IL_0305:
																											if (5 > b)
																											{
																												break;
																											}
																											goto IL_0341;
																											IL_0341:
																											array[num5] = 0;
																											goto IL_04ce;
																											IL_04ce:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_04f1;
																											IL_04f1:
																											array2[num5] = null;
																											goto IL_04fb;
																										}
																										break;
																									}
																									goto IL_02b0;
																									IL_02b0:
																									if (4 > b)
																									{
																										num = 36;
																										break;
																									}
																									goto IL_069a;
																								}
																								break;
																							}
																							goto IL_02cc;
																							IL_04ad:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 101;
																							goto IL_069a;
																							IL_02cc:
																							if (3 > b)
																							{
																								goto IL_02da;
																							}
																							goto IL_04ad;
																							IL_02da:
																							if (1 < b)
																							{
																								goto IL_02e5;
																							}
																							goto IL_02f5;
																							IL_02e5:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0354;
																							IL_0354:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0362;
																							IL_0362:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_045b;
																							IL_045b:
																							ptr2 += 8;
																							goto IL_0469;
																							IL_0469:
																							num5--;
																							goto IL_069a;
																							IL_02f5:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0315;
																							IL_0315:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_032e;
																							IL_032e:
																							array[num5] = 0;
																							goto IL_049d;
																							IL_049d:
																							num5++;
																							goto IL_051c;
																							IL_051c:
																							ptr2 += 8;
																							goto IL_069a;
																						}
																						break;
																					}
																					goto IL_0623;
																					IL_0677:
																					num5--;
																					goto IL_069a;
																					IL_0623:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0663;
																					IL_0663:
																					array[num5 - 2] = 0;
																					goto IL_0677;
																				}
																				break;
																			}
																			goto IL_0390;
																			IL_0613:
																			ptr2 += 8;
																			goto IL_069a;
																			IL_0390:
																			if (9 < b)
																			{
																				goto IL_039b;
																			}
																			goto IL_03bc;
																			IL_039b:
																			if (10 >= b)
																			{
																				goto IL_03a9;
																			}
																			goto IL_047c;
																			IL_03a9:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_043f;
																			IL_043f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_069a;
																			IL_047c:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_048a;
																			IL_048a:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_03bc:
																			if (9 <= b)
																			{
																				goto IL_03ca;
																			}
																			goto IL_052f;
																			IL_03ca:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_042c;
																			IL_042c:
																			num5 -= 2;
																			goto IL_069a;
																			IL_052f:
																			if (7 >= b)
																			{
																				goto IL_053a;
																			}
																			goto IL_05af;
																			IL_053a:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0548;
																			IL_0548:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0588;
																			IL_0588:
																			array[num5 - 2] = 0;
																			goto IL_059c;
																			IL_059c:
																			num5--;
																			goto IL_069a;
																			IL_05af:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_05bd;
																			IL_05bd:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_05cb;
																			IL_05cb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 83;
																			goto IL_05f7;
																			IL_05f7:
																			array[num5] = 0;
																			goto IL_0605;
																			IL_0605:
																			num5++;
																			goto IL_0613;
																		}
																		break;
																		IL_026c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_069a;
																continue;
																end_IL_027c:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0744;
												IL_0744:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										continue;
										end_IL_06b7:
										break;
									}
									continue;
									end_IL_06c2:
									break;
								}
								continue;
								end_IL_06d7:
								break;
							}
							continue;
							end_IL_06e7:
							break;
						}
						continue;
						end_IL_06f7:
						break;
					}
					continue;
					end_IL_0710:
					break;
				}
				continue;
				end_IL_0720:
				break;
			}
		}
	}

	private static int smethod_2()
	{
		int num = 55;
		int num2 = 11;
		num = 5;
		object obj = new int[5];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 54;
		num3 = 27;
		((int[])obj)[0] = 27;
		obj = obj2;
		num2 = 1;
		num3 = 135;
		num3 = 27;
		((int[])obj)[1] = 27;
		obj = obj2;
		num2 = 26;
		num3 = 13;
		num2 = 2;
		num3 = 429;
		num3 = 33;
		((int[])obj)[2] = 33;
		obj = obj2;
		num2 = 6;
		num3 = 2;
		num2 = 3;
		num3 = 205;
		num3 = 41;
		((int[])obj)[3] = 41;
		obj = obj2;
		num2 = 8;
		num3 = 2;
		num2 = 4;
		num3 = 75;
		num3 = 25;
		((int[])obj)[4] = 25;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 65;
			num3 = 13;
			num2 = 5;
			if (num >= 5)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_3()
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PropertyAnalysisEnvironmentPermission.StoreAssemblyFileEnumerationIsBoxed);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_08a7:
												if (num4 != 1)
												{
													while (true)
													{
														IL_029f:
														byte b = *ptr2;
														num = 160;
														while (true)
														{
															if (num != 160)
															{
																if (num != 1141)
																{
																	break;
																}
																switch (num)
																{
																case 18:
																case 114:
																	goto IL_029f;
																case 84:
																	goto IL_02c1;
																case 73:
																	goto IL_02cf;
																case 64:
																	goto IL_02dd;
																case 74:
																	goto IL_02eb;
																case 78:
																case 92:
																	goto IL_02f9;
																case 22:
																	goto IL_0307;
																case 51:
																case 90:
																	goto IL_0315;
																case 52:
																case 71:
																	goto IL_0320;
																case 31:
																	goto IL_032e;
																case 6:
																case 132:
																	goto IL_033c;
																case 13:
																	goto IL_0365;
																case 87:
																	goto IL_037e;
																case 1:
																case 55:
																	goto IL_0389;
																case 108:
																	goto IL_0397;
																case 126:
																case 144:
																	goto IL_03a5;
																case 15:
																	goto IL_03be;
																case 20:
																	goto IL_03d5;
																case 70:
																	goto IL_03e3;
																case 79:
																case 129:
																	goto IL_03f6;
																case 23:
																	goto IL_0436;
																case 28:
																	goto IL_044a;
																case 76:
																case 149:
																	goto IL_0466;
																case 37:
																	goto IL_0484;
																case 142:
																	goto IL_0492;
																case 5:
																	goto IL_04a5;
																case 12:
																	goto IL_04b3;
																case 32:
																case 61:
																	goto IL_04be;
																case 118:
																	goto IL_04fd;
																case 46:
																	goto IL_0510;
																case 131:
																	goto IL_051e;
																case 24:
																case 75:
																	goto IL_052c;
																case 45:
																	goto IL_053a;
																case 110:
																	goto IL_0552;
																case 30:
																	goto IL_0569;
																case 48:
																case 89:
																	goto IL_057c;
																case 105:
																	goto IL_058a;
																case 115:
																case 139:
																	goto IL_0598;
																case 107:
																	goto IL_05c1;
																case 60:
																	goto IL_05cf;
																case 86:
																case 128:
																	goto IL_05e2;
																case 66:
																case 152:
																	goto IL_05fa;
																case 19:
																case 112:
																	goto IL_0608;
																case 77:
																	goto IL_0616;
																case 25:
																case 62:
																	goto IL_0621;
																case 88:
																	goto IL_063d;
																case 134:
																	goto IL_064b;
																case 117:
																case 124:
																	goto IL_0659;
																case 21:
																	goto IL_06bb;
																case 80:
																case 106:
																	goto IL_06d7;
																case 44:
																	goto IL_06e5;
																case 59:
																	goto IL_06f8;
																case 33:
																case 72:
																	goto IL_0703;
																case 50:
																	goto IL_0743;
																case 102:
																	goto IL_0757;
																case 116:
																case 140:
																	goto IL_0773;
																case 38:
																case 69:
																	goto IL_0781;
																case 57:
																	goto IL_078f;
																case 63:
																case 122:
																	goto IL_07a6;
																case 137:
																	goto IL_07ea;
																case 138:
																	goto IL_07fe;
																case 26:
																	goto IL_0811;
																case 29:
																case 53:
																	goto IL_081c;
																case 10:
																	goto IL_082a;
																case 2:
																	goto IL_084d;
																case 47:
																	goto IL_0857;
																case 56:
																	goto IL_0865;
																case 150:
																	goto IL_0875;
																case 4:
																	goto IL_0880;
																case 3:
																case 7:
																case 14:
																case 16:
																case 17:
																case 34:
																case 35:
																case 41:
																case 42:
																case 54:
																case 67:
																case 68:
																case 82:
																case 93:
																case 101:
																case 109:
																case 111:
																case 113:
																case 119:
																case 120:
																case 121:
																case 123:
																case 125:
																case 127:
																case 143:
																case 145:
																case 146:
																case 147:
																case 148:
																case 153:
																	goto IL_088b;
																case 0:
																case 27:
																case 39:
																case 40:
																case 49:
																case 58:
																case 85:
																case 94:
																case 97:
																case 98:
																case 100:
																case 103:
																case 130:
																case 133:
																case 135:
																case 136:
																case 141:
																case 151:
																	goto IL_08a7;
																case 8:
																	goto end_IL_028f;
																case 83:
																	goto end_IL_08ba;
																case 11:
																	goto end_IL_08c4;
																case 9:
																	goto end_IL_08cf;
																case 43:
																case 99:
																	goto end_IL_08df;
																case 36:
																	goto end_IL_08ef;
																case 65:
																case 91:
																	goto end_IL_08ff;
																case 95:
																	goto end_IL_090f;
																case 96:
																	goto end_IL_091f;
																case 81:
																case 104:
																	goto IL_093a;
																}
																continue;
															}
															ptr2++;
															goto IL_02c1;
															IL_084d:
															array2[num5] = null;
															goto IL_0857;
															IL_0865:
															ptr2 += 8;
															goto IL_08a7;
															IL_0857:
															num5++;
															goto IL_0865;
															IL_02c1:
															if (b >= 1)
															{
																goto IL_02cf;
															}
															goto IL_088b;
															IL_02cf:
															if (b <= 15)
															{
																goto IL_02dd;
															}
															goto IL_088b;
															IL_02dd:
															if (8 >= b)
															{
																goto IL_02eb;
															}
															goto IL_05fa;
															IL_02eb:
															if (8 > b)
															{
																goto IL_02f9;
															}
															goto IL_05e2;
															IL_02f9:
															if (4 >= b)
															{
																goto IL_0307;
															}
															goto IL_04a5;
															IL_0307:
															if (4 > b)
															{
																goto IL_0315;
															}
															goto IL_0466;
															IL_0315:
															if (2 < b)
															{
																goto IL_0320;
															}
															goto IL_037e;
															IL_0320:
															if (3 >= b)
															{
																goto IL_032e;
															}
															goto IL_088b;
															IL_032e:
															if (3 <= b)
															{
																goto IL_033c;
															}
															goto IL_088b;
															IL_033c:
															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
															goto IL_0365;
															IL_0365:
															array[num5 - 1] = 5;
															goto IL_08a7;
															IL_037e:
															if (2 > b)
															{
																goto IL_0389;
															}
															goto IL_03f6;
															IL_0389:
															if (1 >= b)
															{
																goto IL_0397;
															}
															goto IL_088b;
															IL_0397:
															if (1 <= b)
															{
																goto IL_03a5;
															}
															goto IL_088b;
															IL_03a5:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_03be;
															IL_03be:
															array[num5] = 0;
															num = 20;
															goto IL_03d5;
															IL_03d5:
															num5++;
															goto IL_03e3;
															IL_03e3:
															ptr2 += 8;
															goto IL_08a7;
															IL_03f6:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0436;
															IL_0436:
															array[num5 - 2] = 0;
															goto IL_044a;
															IL_044a:
															num5--;
															num = 58;
															goto IL_08a7;
															IL_0466:
															array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
															goto IL_0484;
															IL_0484:
															ptr2 += 8;
															goto IL_0492;
															IL_0492:
															num5--;
															goto IL_08a7;
															IL_04a5:
															if (6 >= b)
															{
																goto IL_04b3;
															}
															goto IL_057c;
															IL_04b3:
															if (6 <= b)
															{
																goto IL_04be;
															}
															goto IL_0510;
															IL_04be:
															((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_04fd;
															IL_04fd:
															num5 -= 3;
															goto IL_08a7;
															IL_0510:
															if (5 >= b)
															{
																goto IL_051e;
															}
															goto IL_088b;
															IL_051e:
															if (5 <= b)
															{
																goto IL_052c;
															}
															goto IL_088b;
															IL_052c:
															array[num5] = 5;
															goto IL_053a;
															IL_053a:
															array2[num5] = array5[*(int*)(ptr2 + num3)];
															goto IL_0552;
															IL_0552:
															num5++;
															num = 30;
															goto IL_0569;
															IL_0569:
															ptr2 += 8;
															goto IL_08a7;
															IL_057c:
															if (7 >= b)
															{
																goto IL_058a;
															}
															goto IL_088b;
															IL_058a:
															if (7 <= b)
															{
																goto IL_0598;
															}
															goto IL_088b;
															IL_0598:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_05c1;
															IL_05c1:
															ptr2 += 8;
															goto IL_05cf;
															IL_05cf:
															num5--;
															goto IL_08a7;
															IL_05e2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_08a7;
															IL_05fa:
															if (12 < b)
															{
																goto IL_0608;
															}
															goto IL_06f8;
															IL_0608:
															if (14 >= b)
															{
																goto IL_0616;
															}
															num = 80;
															goto IL_06d7;
															IL_0616:
															if (14 <= b)
															{
																goto IL_0621;
															}
															goto IL_063d;
															IL_0621:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto IL_08a7;
															IL_063d:
															if (13 >= b)
															{
																goto IL_064b;
															}
															goto IL_088b;
															IL_064b:
															if (13 <= b)
															{
																goto IL_0659;
															}
															goto IL_088b;
															IL_0659:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_06bb;
															IL_06bb:
															num5 -= 2;
															goto IL_08a7;
															IL_0875:
															if (9 >= b)
															{
																goto IL_0880;
															}
															goto IL_088b;
															IL_06d7:
															if (15 >= b)
															{
																goto IL_06e5;
															}
															goto IL_088b;
															IL_06e5:
															if (15 <= b)
															{
															}
															goto IL_088b;
															IL_06f8:
															if (12 <= b)
															{
																goto IL_0703;
															}
															num = 140;
															goto IL_0773;
															IL_0703:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0743;
															IL_0743:
															array[num5 - 2] = 0;
															goto IL_0757;
															IL_0757:
															num5--;
															goto IL_08a7;
															IL_0880:
															if (9 <= b)
															{
																goto IL_08a7;
															}
															goto IL_088b;
															IL_0773:
															if (10 < b)
															{
																goto IL_0781;
															}
															goto IL_0811;
															IL_0781:
															if (11 >= b)
															{
																goto IL_078f;
															}
															goto IL_088b;
															IL_078f:
															if (11 <= b)
															{
																num = 63;
																goto IL_07a6;
															}
															goto IL_088b;
															IL_088b:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															num = 133;
															goto IL_08a7;
															IL_07a6:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
															goto IL_07ea;
															IL_07ea:
															array[num5 - 2] = 0;
															goto IL_07fe;
															IL_07fe:
															num5--;
															goto IL_08a7;
															IL_0811:
															if (10 <= b)
															{
																goto IL_081c;
															}
															goto IL_0875;
															IL_081c:
															array[num5] = 0;
															goto IL_082a;
															IL_082a:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_084d;
															continue;
															end_IL_028f:
															break;
														}
														break;
													}
													break;
												}
												goto IL_093a;
												IL_093a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											continue;
											end_IL_08ba:
											break;
										}
										continue;
										end_IL_08c4:
										break;
									}
									continue;
									end_IL_08cf:
									break;
								}
								continue;
								end_IL_08df:
								break;
							}
							continue;
							end_IL_08ef:
							break;
						}
						continue;
						end_IL_08ff:
						break;
					}
					continue;
					end_IL_090f:
					break;
				}
				continue;
				end_IL_091f:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 107;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 30;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCurrentContextISerializationRootObject.AllowExponentsetEventHandle);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 152;
														while (true)
														{
															if (num != 152)
															{
																if (num != 1133)
																{
																	goto IL_0850;
																}
																switch (num)
																{
																case 83:
																case 115:
																	goto end_IL_026f;
																case 45:
																	goto IL_02a1;
																case 94:
																	goto IL_02af;
																case 113:
																	goto IL_02bd;
																case 117:
																	goto IL_02cb;
																case 22:
																case 72:
																	goto IL_02d6;
																case 97:
																	goto IL_02ee;
																case 36:
																case 74:
																	goto IL_02fc;
																case 81:
																	goto IL_030a;
																case 51:
																	goto IL_0315;
																case 4:
																	goto IL_0323;
																case 63:
																case 112:
																	goto IL_0331;
																case 12:
																	goto IL_033f;
																case 122:
																	goto IL_0357;
																case 20:
																	goto IL_0365;
																case 11:
																case 33:
																	goto IL_0378;
																case 57:
																	goto IL_03b7;
																case 39:
																case 82:
																	goto IL_03ca;
																case 15:
																	goto IL_03d8;
																case 103:
																case 135:
																	goto IL_03e6;
																case 53:
																	goto IL_040f;
																case 27:
																	goto IL_041d;
																case 108:
																	goto IL_0430;
																case 46:
																case 76:
																	goto IL_043e;
																case 56:
																	goto IL_044c;
																case 54:
																case 65:
																	goto IL_0457;
																case 60:
																	goto IL_0497;
																case 49:
																	goto IL_04ab;
																case 7:
																	goto IL_04be;
																case 78:
																	goto IL_04cc;
																case 125:
																case 142:
																	goto IL_04da;
																case 13:
																	goto IL_04f3;
																case 67:
																	goto IL_050a;
																case 91:
																	goto IL_0518;
																case 29:
																case 136:
																	goto IL_052b;
																case 73:
																	goto IL_0539;
																case 38:
																case 96:
																	goto IL_0547;
																case 9:
																	goto IL_0570;
																case 111:
																case 130:
																	goto IL_0589;
																case 44:
																	goto IL_05a7;
																case 124:
																	goto IL_05be;
																case 139:
																	goto IL_05d1;
																case 50:
																	goto IL_05df;
																case 35:
																case 120:
																	goto IL_05ea;
																case 101:
																	goto IL_062a;
																case 144:
																	goto IL_063e;
																case 64:
																	goto IL_0651;
																case 59:
																case 71:
																	goto IL_065f;
																case 16:
																	goto IL_066d;
																case 62:
																case 140:
																	goto IL_067b;
																case 19:
																	goto IL_06bf;
																case 24:
																	goto IL_06d3;
																case 31:
																	goto IL_06e6;
																case 3:
																	goto IL_06f1;
																case 43:
																	goto IL_06ff;
																case 28:
																case 102:
																	goto IL_071b;
																case 40:
																	goto IL_0729;
																case 86:
																	goto IL_074c;
																case 105:
																	goto IL_0756;
																case 95:
																	goto IL_0764;
																case 17:
																	goto IL_0777;
																case 47:
																	goto IL_0785;
																case 21:
																case 123:
																	goto IL_0793;
																case 143:
																	goto IL_07a1;
																case 42:
																case 66:
																	goto IL_07af;
																case 84:
																	goto IL_0811;
																case 2:
																case 127:
																	goto IL_0821;
																case 129:
																	goto IL_083a;
																case 41:
																	goto IL_0845;
																case 0:
																case 1:
																case 6:
																case 18:
																case 32:
																case 55:
																case 58:
																case 61:
																case 68:
																case 69:
																case 80:
																case 85:
																case 87:
																case 89:
																case 90:
																case 93:
																case 98:
																case 99:
																case 100:
																case 104:
																case 110:
																case 121:
																case 131:
																case 134:
																case 137:
																case 145:
																	goto IL_0850;
																case 5:
																case 8:
																case 10:
																case 26:
																case 34:
																case 75:
																case 77:
																case 88:
																case 92:
																case 109:
																case 114:
																case 116:
																case 118:
																case 119:
																case 128:
																case 132:
																case 138:
																case 141:
																	goto end_IL_027f;
																case 37:
																	goto end_IL_0863;
																case 14:
																	goto end_IL_0876;
																case 30:
																	goto end_IL_0880;
																case 70:
																	goto end_IL_088b;
																case 25:
																case 133:
																	goto end_IL_089b;
																case 23:
																	goto end_IL_08b4;
																case 52:
																case 79:
																	goto end_IL_08c4;
																case 106:
																	goto end_IL_08d4;
																case 107:
																	goto end_IL_08e4;
																case 48:
																case 126:
																	goto IL_0908;
																}
																continue;
															}
															ptr2++;
															goto IL_02a1;
															IL_0821:
															byte* num5 = ptr2;
															num4 = 1;
															ptr2 = num5 + -200;
															goto end_IL_027f;
															IL_0845:
															if (15 <= b)
															{
															}
															goto IL_0850;
															IL_083a:
															if (15 >= b)
															{
																goto IL_0845;
															}
															goto IL_0850;
															IL_02a1:
															if (b >= 1)
															{
																goto IL_02af;
															}
															goto IL_0850;
															IL_02af:
															if (b <= 15)
															{
																goto IL_02bd;
															}
															goto IL_0850;
															IL_02bd:
															if (8 >= b)
															{
																goto IL_02cb;
															}
															goto IL_05d1;
															IL_02cb:
															if (8 <= b)
															{
																goto IL_02d6;
															}
															goto IL_02ee;
															IL_02d6:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_027f;
															IL_02ee:
															if (4 < b)
															{
																goto IL_02fc;
															}
															goto IL_0430;
															IL_02fc:
															if (6 >= b)
															{
																goto IL_030a;
															}
															goto IL_03ca;
															IL_030a:
															if (6 > b)
															{
																goto IL_0315;
															}
															goto IL_0378;
															IL_0315:
															if (5 >= b)
															{
																goto IL_0323;
															}
															goto IL_0850;
															IL_0323:
															if (5 <= b)
															{
																goto IL_0331;
															}
															goto IL_0850;
															IL_0331:
															array[num6] = 5;
															goto IL_033f;
															IL_033f:
															array2[num6] = array5[*(int*)(ptr2 + num3)];
															goto IL_0357;
															IL_0357:
															num6++;
															goto IL_0365;
															IL_0365:
															ptr2 += 8;
															goto end_IL_027f;
															IL_0378:
															((int[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
															goto IL_03b7;
															IL_03b7:
															num6 -= 3;
															goto end_IL_027f;
															IL_03ca:
															if (7 >= b)
															{
																goto IL_03d8;
															}
															goto IL_0850;
															IL_03d8:
															if (7 <= b)
															{
																goto IL_03e6;
															}
															goto IL_0850;
															IL_03e6:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
															goto IL_040f;
															IL_040f:
															ptr2 += 8;
															goto IL_041d;
															IL_041d:
															num6--;
															goto end_IL_027f;
															IL_0430:
															if (4 > b)
															{
																goto IL_043e;
															}
															goto IL_0589;
															IL_043e:
															if (2 >= b)
															{
																goto IL_044c;
															}
															goto IL_052b;
															IL_044c:
															if (2 <= b)
															{
																goto IL_0457;
															}
															goto IL_04be;
															IL_0457:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
															goto IL_0497;
															IL_0497:
															array[num6 - 2] = 0;
															goto IL_04ab;
															IL_04ab:
															num6--;
															goto end_IL_027f;
															IL_04be:
															if (1 >= b)
															{
																goto IL_04cc;
															}
															goto IL_0850;
															IL_04cc:
															if (1 <= b)
															{
																goto IL_04da;
															}
															goto IL_0850;
															IL_04da:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
															goto IL_04f3;
															IL_04f3:
															array[num6] = 0;
															num = 67;
															goto IL_050a;
															IL_050a:
															num6++;
															goto IL_0518;
															IL_0518:
															ptr2 += 8;
															goto end_IL_027f;
															IL_052b:
															if (3 >= b)
															{
																goto IL_0539;
															}
															goto IL_0850;
															IL_0539:
															if (3 <= b)
															{
																goto IL_0547;
															}
															goto IL_0850;
															IL_0547:
															array2[num6 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
															goto IL_0570;
															IL_0570:
															array[num6 - 1] = 5;
															goto end_IL_027f;
															IL_0589:
															array5[*(int*)(ptr2 + num3)] = array2[num6 - 1];
															goto IL_05a7;
															IL_05a7:
															ptr2 += 8;
															num = 124;
															goto IL_05be;
															IL_05be:
															num6--;
															goto end_IL_027f;
															IL_05d1:
															if (12 >= b)
															{
																goto IL_05df;
															}
															goto IL_0777;
															IL_05df:
															if (12 <= b)
															{
																goto IL_05ea;
															}
															goto IL_0651;
															IL_05ea:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
															goto IL_062a;
															IL_062a:
															array[num6 - 2] = 0;
															goto IL_063e;
															IL_063e:
															num6--;
															goto end_IL_027f;
															IL_0651:
															if (10 < b)
															{
																goto IL_065f;
															}
															goto IL_06e6;
															IL_065f:
															if (11 >= b)
															{
																goto IL_066d;
															}
															goto IL_0850;
															IL_066d:
															if (11 <= b)
															{
																goto IL_067b;
															}
															goto IL_0850;
															IL_067b:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((int[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
															goto IL_06bf;
															IL_06bf:
															array[num6 - 2] = 0;
															goto IL_06d3;
															IL_06d3:
															num6--;
															goto end_IL_027f;
															IL_06e6:
															if (10 > b)
															{
																goto IL_06f1;
															}
															num = 28;
															goto IL_071b;
															IL_06f1:
															if (9 >= b)
															{
																goto IL_06ff;
															}
															goto IL_0850;
															IL_06ff:
															if (9 <= b)
															{
																goto end_IL_027f;
															}
															goto IL_0850;
															IL_0850:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_027f;
															IL_071b:
															array[num6] = 0;
															goto IL_0729;
															IL_0729:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
															goto IL_074c;
															IL_074c:
															array2[num6] = null;
															goto IL_0756;
															IL_0756:
															num6++;
															goto IL_0764;
															IL_0764:
															ptr2 += 8;
															goto end_IL_027f;
															IL_0777:
															if (14 >= b)
															{
																goto IL_0785;
															}
															goto IL_083a;
															IL_0785:
															if (14 > b)
															{
																goto IL_0793;
															}
															goto IL_0821;
															IL_0793:
															if (13 >= b)
															{
																goto IL_07a1;
															}
															goto IL_0850;
															IL_07a1:
															if (13 <= b)
															{
																goto IL_07af;
															}
															goto IL_0850;
															IL_07af:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0811;
															IL_0811:
															num6 -= 2;
															goto end_IL_027f;
															continue;
															end_IL_026f:
															break;
														}
														continue;
														end_IL_027f:
														break;
													}
													continue;
												}
												num = 126;
												goto IL_0908;
												IL_0908:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0863:
												break;
											}
											continue;
											end_IL_0876:
											break;
										}
										continue;
										end_IL_0880:
										break;
									}
									continue;
									end_IL_088b:
									break;
								}
								continue;
								end_IL_089b:
								break;
							}
							continue;
							end_IL_08b4:
							break;
						}
						continue;
						end_IL_08c4:
						break;
					}
					continue;
					end_IL_08d4:
					break;
				}
				continue;
				end_IL_08e4:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1)
	{
		int num = 16;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 107;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setDefaultGrantSetLoadContext.getRequestedExecutionLevelUIAccesssetMayLeakOnAbort);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_025e:
														byte b = *ptr2;
														while (true)
														{
															IL_0245:
															ptr2++;
															num = 84;
															while (true)
															{
																IL_0235:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0215:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0208:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_01f8:
																							if (9 >= b)
																							{
																								num = 114;
																								while (true)
																								{
																									if (num != 114)
																									{
																										if (num != 1095)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 96:
																											goto IL_01f8;
																										case 49:
																										case 79:
																											goto IL_0208;
																										case 13:
																											goto IL_0215;
																										case 28:
																											goto IL_0225;
																										case 84:
																											goto IL_0235;
																										case 25:
																											goto IL_0245;
																										case 38:
																										case 42:
																											goto IL_025e;
																										case 75:
																											goto IL_0269;
																										case 0:
																											goto IL_0277;
																										case 86:
																											goto IL_0293;
																										case 3:
																										case 35:
																											goto IL_029e;
																										case 29:
																										case 78:
																											goto IL_02ae;
																										case 73:
																											goto IL_0310;
																										case 67:
																										case 101:
																											goto IL_0323;
																										case 41:
																											goto IL_0331;
																										case 5:
																										case 60:
																											goto IL_033f;
																										case 46:
																											goto IL_0362;
																										case 39:
																											goto IL_0370;
																										case 27:
																											goto IL_037e;
																										case 105:
																											goto IL_0391;
																										case 26:
																										case 103:
																											goto IL_039f;
																										case 37:
																											goto IL_03e8;
																										case 98:
																											goto IL_03fc;
																										case 56:
																										case 92:
																											goto IL_0428;
																										case 93:
																											goto IL_0444;
																										case 36:
																										case 53:
																											goto IL_044f;
																										case 34:
																											goto IL_045d;
																										case 21:
																											goto IL_0480;
																										case 19:
																											goto IL_048a;
																										case 106:
																											goto IL_0498;
																										case 82:
																										case 97:
																											goto IL_04ab;
																										case 43:
																											goto IL_04b9;
																										case 20:
																										case 68:
																											goto IL_04c4;
																										case 87:
																											goto IL_04d2;
																										case 48:
																										case 58:
																											goto IL_04e0;
																										case 88:
																											goto IL_04f9;
																										case 47:
																											goto IL_0507;
																										case 23:
																											goto IL_0515;
																										case 55:
																										case 63:
																											goto IL_0528;
																										case 1:
																											goto IL_0551;
																										case 100:
																											goto IL_055f;
																										case 102:
																											goto IL_0578;
																										case 64:
																											goto IL_0583;
																										case 8:
																										case 12:
																											goto IL_058e;
																										case 54:
																											goto IL_05ac;
																										case 22:
																											goto IL_05b7;
																										case 4:
																										case 11:
																										case 14:
																										case 17:
																										case 18:
																										case 30:
																										case 31:
																										case 33:
																										case 45:
																										case 51:
																										case 57:
																										case 61:
																										case 62:
																										case 71:
																										case 72:
																										case 74:
																										case 83:
																										case 89:
																										case 90:
																										case 91:
																										case 95:
																										case 104:
																											goto end_IL_0225;
																										case 7:
																										case 10:
																										case 32:
																										case 40:
																										case 52:
																										case 66:
																										case 69:
																										case 70:
																										case 77:
																										case 80:
																										case 81:
																										case 85:
																										case 99:
																											goto end_IL_01e5;
																										case 6:
																											goto end_IL_05d5;
																										case 94:
																											goto end_IL_05e8;
																										case 2:
																											goto end_IL_05f2;
																										case 24:
																											goto end_IL_05fd;
																										case 9:
																										case 65:
																											goto end_IL_0612;
																										case 76:
																											goto end_IL_0622;
																										case 50:
																										case 107:
																											goto end_IL_0632;
																										case 15:
																											goto end_IL_0642;
																										case 16:
																											goto end_IL_0652;
																										case 44:
																										case 59:
																											goto IL_067f;
																										}
																										continue;
																									}
																									if (9 > b)
																									{
																										num = 71;
																										goto end_IL_0225;
																									}
																									goto IL_0428;
																									IL_0428:
																									byte* num5 = ptr2;
																									num4 = 1;
																									ptr2 = num5 + -200;
																									break;
																									continue;
																									end_IL_01e5:
																									break;
																								}
																								break;
																							}
																							goto IL_0269;
																							IL_0269:
																							if (10 < b)
																							{
																								goto end_IL_0225;
																							}
																							goto IL_0277;
																							IL_0277:
																							if (10 > b)
																							{
																								num = 31;
																							}
																							goto end_IL_0225;
																						}
																						break;
																					}
																					goto IL_0293;
																					IL_0310:
																					num6 -= 2;
																					break;
																					IL_0293:
																					if (8 > b)
																					{
																						goto IL_029e;
																					}
																					goto IL_02ae;
																					IL_029e:
																					if (6 < b)
																					{
																						goto IL_0323;
																					}
																					goto IL_0391;
																					IL_0323:
																					if (7 < b)
																					{
																						goto end_IL_0225;
																					}
																					goto IL_0331;
																					IL_0331:
																					if (7 > b)
																					{
																						goto end_IL_0225;
																					}
																					goto IL_033f;
																					IL_033f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0362;
																					IL_0362:
																					array[num6] = 0;
																					goto IL_0370;
																					IL_0370:
																					num6++;
																					goto IL_037e;
																					IL_037e:
																					ptr2 += 8;
																					break;
																					IL_0391:
																					if (6 > b)
																					{
																						goto end_IL_0225;
																					}
																					goto IL_039f;
																					IL_039f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 37;
																					goto IL_03e8;
																					IL_03e8:
																					array[num6 - 2] = 0;
																					goto IL_03fc;
																					IL_03fc:
																					num6--;
																					break;
																					IL_02ae:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0310;
																				}
																				break;
																			}
																			goto IL_0444;
																			IL_05b7:
																			if (4 <= b)
																			{
																				break;
																			}
																			goto end_IL_0225;
																			IL_0444:
																			if (5 <= b)
																			{
																				goto IL_044f;
																			}
																			goto IL_04ab;
																			IL_044f:
																			array[num6] = 0;
																			goto IL_045d;
																			IL_045d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0480;
																			IL_0480:
																			array2[num6] = null;
																			goto IL_048a;
																			IL_048a:
																			num6++;
																			goto IL_0498;
																			IL_0498:
																			ptr2 += 8;
																			break;
																			IL_04ab:
																			if (2 >= b)
																			{
																				goto IL_04b9;
																			}
																			goto IL_0578;
																			IL_04b9:
																			if (2 > b)
																			{
																				goto IL_04c4;
																			}
																			goto IL_0528;
																			IL_04c4:
																			if (1 < b)
																			{
																				goto end_IL_0225;
																			}
																			goto IL_04d2;
																			IL_04d2:
																			if (1 > b)
																			{
																				goto end_IL_0225;
																			}
																			goto IL_04e0;
																			IL_04e0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_04f9;
																			IL_04f9:
																			array[num6] = 0;
																			goto IL_0507;
																			IL_0507:
																			num6++;
																			goto IL_0515;
																			IL_0515:
																			ptr2 += 8;
																			break;
																			IL_0528:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0551;
																			IL_0551:
																			ptr2 += 8;
																			goto IL_055f;
																			IL_055f:
																			num6--;
																			num = 80;
																			break;
																			IL_0578:
																			if (3 >= b)
																			{
																				goto IL_0583;
																			}
																			goto IL_05ac;
																			IL_0583:
																			if (3 > b)
																			{
																				goto end_IL_0225;
																			}
																			goto IL_058e;
																			IL_058e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 85;
																			break;
																			IL_05ac:
																			if (4 < b)
																			{
																				goto end_IL_0225;
																			}
																			goto IL_05b7;
																		}
																		goto end_IL_0235;
																		continue;
																		end_IL_0225:
																		break;
																		IL_0225:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0235:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 59;
												goto IL_067f;
												IL_067f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05d5:
												break;
											}
											continue;
											end_IL_05e8:
											break;
										}
										continue;
										end_IL_05f2:
										break;
									}
									continue;
									end_IL_05fd:
									break;
								}
								continue;
								end_IL_0612:
								break;
							}
							continue;
							end_IL_0622:
							break;
						}
						continue;
						end_IL_0632:
						break;
					}
					continue;
					end_IL_0642:
					break;
				}
				continue;
				end_IL_0652:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 27;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LoaderInformationParallelFor.UnsafeOnCompletedObjectMode);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 152;
														while (true)
														{
															if (num != 152)
															{
																if (num != 1133)
																{
																	goto IL_0671;
																}
																switch (num)
																{
																case 88:
																	goto end_IL_026f;
																case 52:
																	goto IL_0293;
																case 133:
																	goto IL_02aa;
																case 4:
																	goto IL_02b8;
																case 33:
																	goto IL_02c6;
																case 112:
																	goto IL_02d4;
																case 1:
																	goto IL_02e2;
																case 78:
																case 118:
																	goto IL_02f0;
																case 72:
																case 128:
																	goto IL_02fb;
																case 42:
																	goto IL_0309;
																case 46:
																case 74:
																	goto IL_0317;
																case 85:
																	goto IL_0340;
																case 117:
																	goto IL_034e;
																case 7:
																	goto IL_0361;
																case 75:
																case 120:
																	goto IL_036c;
																case 71:
																	goto IL_037a;
																case 62:
																case 92:
																	goto IL_0388;
																case 39:
																	goto IL_039f;
																case 41:
																	goto IL_03b7;
																case 25:
																	goto IL_03c5;
																case 54:
																case 82:
																	goto IL_03d8;
																case 144:
																	goto IL_0420;
																case 141:
																	goto IL_0433;
																case 14:
																	goto IL_0441;
																case 12:
																case 65:
																	goto IL_044c;
																case 32:
																	goto IL_045a;
																case 31:
																case 44:
																	goto IL_0468;
																case 45:
																	goto IL_0491;
																case 102:
																	goto IL_04aa;
																case 77:
																	goto IL_04b5;
																case 131:
																	goto IL_04c3;
																case 55:
																case 63:
																	goto IL_04d1;
																case 29:
																	goto IL_04ea;
																case 70:
																	goto IL_04f8;
																case 126:
																	goto IL_0506;
																case 49:
																case 60:
																	goto IL_0522;
																case 16:
																	goto IL_0562;
																case 132:
																	goto IL_0576;
																case 47:
																case 105:
																	goto IL_0589;
																case 66:
																	goto IL_05a7;
																case 2:
																	goto IL_05b5;
																case 17:
																case 138:
																	goto IL_05c8;
																case 68:
																	goto IL_05e0;
																case 130:
																	goto IL_05ee;
																case 35:
																case 114:
																	goto IL_05fc;
																case 58:
																	goto IL_060a;
																case 95:
																case 123:
																	goto IL_0615;
																case 30:
																	goto IL_0623;
																case 145:
																	goto IL_0646;
																case 139:
																	goto IL_0650;
																case 110:
																	goto IL_065e;
																case 136:
																	goto IL_0671;
																case 11:
																	goto IL_067f;
																case 113:
																	goto IL_0692;
																case 116:
																	goto IL_06a0;
																case 124:
																case 125:
																	goto IL_06ae;
																case 3:
																	goto IL_06f2;
																case 83:
																	goto IL_0706;
																case 9:
																case 99:
																	goto IL_0719;
																case 100:
																	goto IL_0759;
																case 86:
																	goto IL_076d;
																case 90:
																case 140:
																	goto IL_0780;
																case 23:
																case 73:
																	goto IL_078b;
																case 109:
																	goto IL_0799;
																case 56:
																	goto IL_07ac;
																case 18:
																case 67:
																	goto IL_07b7;
																case 53:
																	goto IL_07d3;
																case 115:
																	goto IL_07de;
																case 64:
																case 111:
																	goto IL_07e9;
																case 37:
																	goto IL_084b;
																case 0:
																case 5:
																case 6:
																case 10:
																case 20:
																case 22:
																case 28:
																case 36:
																case 48:
																case 50:
																case 51:
																case 57:
																case 80:
																case 89:
																case 91:
																case 96:
																case 98:
																case 101:
																case 104:
																case 106:
																case 107:
																case 122:
																case 127:
																case 129:
																case 134:
																	goto IL_085b;
																case 8:
																case 15:
																case 24:
																case 34:
																case 43:
																case 59:
																case 61:
																case 69:
																case 81:
																case 94:
																case 97:
																case 108:
																case 119:
																case 121:
																case 135:
																case 137:
																case 142:
																case 143:
																	goto end_IL_027f;
																case 84:
																	goto end_IL_086e;
																case 76:
																	goto end_IL_0881;
																case 38:
																	goto end_IL_088b;
																case 13:
																	goto end_IL_0896;
																case 79:
																case 103:
																	goto end_IL_08a6;
																case 40:
																	goto end_IL_08b6;
																case 87:
																case 93:
																	goto end_IL_08c6;
																case 26:
																	goto end_IL_08d6;
																case 27:
																	goto end_IL_08e6;
																case 19:
																case 21:
																	goto IL_0901;
																}
																continue;
															}
															b = *ptr2;
															goto IL_0293;
															IL_07de:
															if (13 <= b)
															{
																goto IL_07e9;
															}
															goto IL_085b;
															IL_084b:
															num5 -= 2;
															goto end_IL_027f;
															IL_07e9:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_084b;
															IL_0293:
															ptr2++;
															num = 133;
															goto IL_02aa;
															IL_02aa:
															if (b >= 1)
															{
																goto IL_02b8;
															}
															goto IL_085b;
															IL_02b8:
															if (b <= 15)
															{
																goto IL_02c6;
															}
															goto IL_085b;
															IL_02c6:
															if (8 >= b)
															{
																goto IL_02d4;
															}
															goto IL_05e0;
															IL_02d4:
															if (8 > b)
															{
																goto IL_02e2;
															}
															goto IL_05c8;
															IL_02e2:
															if (4 < b)
															{
																goto IL_02f0;
															}
															goto IL_0433;
															IL_02f0:
															if (6 < b)
															{
																goto IL_02fb;
															}
															goto IL_0361;
															IL_02fb:
															if (7 >= b)
															{
																goto IL_0309;
															}
															goto IL_085b;
															IL_0309:
															if (7 <= b)
															{
																goto IL_0317;
															}
															goto IL_085b;
															IL_0317:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0340;
															IL_0340:
															ptr2 += 8;
															goto IL_034e;
															IL_034e:
															num5--;
															goto end_IL_027f;
															IL_0361:
															if (6 > b)
															{
																goto IL_036c;
															}
															goto IL_03d8;
															IL_036c:
															if (5 >= b)
															{
																goto IL_037a;
															}
															goto IL_085b;
															IL_037a:
															if (5 <= b)
															{
																goto IL_0388;
															}
															goto IL_085b;
															IL_0388:
															array[num5] = 5;
															num = 39;
															goto IL_039f;
															IL_039f:
															array2[num5] = array5[*(int*)(ptr2 + num3)];
															goto IL_03b7;
															IL_03b7:
															num5++;
															goto IL_03c5;
															IL_03c5:
															ptr2 += 8;
															goto end_IL_027f;
															IL_03d8:
															((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															num = 144;
															goto IL_0420;
															IL_0420:
															num5 -= 3;
															goto end_IL_027f;
															IL_0433:
															if (4 > b)
															{
																goto IL_0441;
															}
															goto IL_0589;
															IL_0441:
															if (2 < b)
															{
																goto IL_044c;
															}
															goto IL_04aa;
															IL_044c:
															if (3 >= b)
															{
																goto IL_045a;
															}
															goto IL_085b;
															IL_045a:
															if (3 <= b)
															{
																goto IL_0468;
															}
															goto IL_085b;
															IL_0468:
															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
															goto IL_0491;
															IL_0491:
															array[num5 - 1] = 5;
															goto end_IL_027f;
															IL_04aa:
															if (2 > b)
															{
																goto IL_04b5;
															}
															num = 49;
															goto IL_0522;
															IL_04b5:
															if (1 >= b)
															{
																goto IL_04c3;
															}
															goto IL_085b;
															IL_04c3:
															if (1 <= b)
															{
																goto IL_04d1;
															}
															goto IL_085b;
															IL_04d1:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_04ea;
															IL_04ea:
															array[num5] = 0;
															goto IL_04f8;
															IL_04f8:
															num5++;
															goto IL_0506;
															IL_0506:
															ptr2 += 8;
															goto end_IL_027f;
															IL_085b:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_027f;
															IL_0522:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0562;
															IL_0562:
															array[num5 - 2] = 0;
															goto IL_0576;
															IL_0576:
															num5--;
															goto end_IL_027f;
															IL_0589:
															array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
															goto IL_05a7;
															IL_05a7:
															ptr2 += 8;
															goto IL_05b5;
															IL_05b5:
															num5--;
															goto end_IL_027f;
															IL_05c8:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_027f;
															IL_05e0:
															if (12 >= b)
															{
																goto IL_05ee;
															}
															goto IL_0780;
															IL_05ee:
															if (12 > b)
															{
																goto IL_05fc;
															}
															goto IL_0719;
															IL_05fc:
															if (10 >= b)
															{
																goto IL_060a;
															}
															goto IL_0692;
															IL_060a:
															if (10 <= b)
															{
																goto IL_0615;
															}
															goto IL_0671;
															IL_0615:
															array[num5] = 0;
															goto IL_0623;
															IL_0623:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_0646;
															IL_0646:
															array2[num5] = null;
															goto IL_0650;
															IL_0650:
															num5++;
															goto IL_065e;
															IL_065e:
															ptr2 += 8;
															goto end_IL_027f;
															IL_0671:
															if (9 >= b)
															{
																goto IL_067f;
															}
															goto IL_085b;
															IL_067f:
															if (9 <= b)
															{
																goto end_IL_027f;
															}
															goto IL_085b;
															IL_0692:
															if (11 >= b)
															{
																goto IL_06a0;
															}
															goto IL_085b;
															IL_06a0:
															if (11 <= b)
															{
																goto IL_06ae;
															}
															goto IL_085b;
															IL_06ae:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
															goto IL_06f2;
															IL_06f2:
															array[num5 - 2] = 0;
															goto IL_0706;
															IL_0706:
															num5--;
															goto end_IL_027f;
															IL_0719:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0759;
															IL_0759:
															array[num5 - 2] = 0;
															goto IL_076d;
															IL_076d:
															num5--;
															goto end_IL_027f;
															IL_0780:
															if (14 < b)
															{
																goto IL_078b;
															}
															goto IL_07ac;
															IL_078b:
															if (15 >= b)
															{
																goto IL_0799;
															}
															goto IL_085b;
															IL_0799:
															if (15 > b)
															{
															}
															goto IL_085b;
															IL_07ac:
															if (14 <= b)
															{
																goto IL_07b7;
															}
															goto IL_07d3;
															IL_07b7:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto end_IL_027f;
															IL_07d3:
															if (13 >= b)
															{
																goto IL_07de;
															}
															goto IL_085b;
															continue;
															end_IL_026f:
															break;
														}
														continue;
														end_IL_027f:
														break;
													}
													continue;
												}
												goto IL_0901;
												IL_0901:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_086e:
												break;
											}
											continue;
											end_IL_0881:
											break;
										}
										continue;
										end_IL_088b:
										break;
									}
									continue;
									end_IL_0896:
									break;
								}
								continue;
								end_IL_08a6:
								break;
							}
							continue;
							end_IL_08b6:
							break;
						}
						continue;
						end_IL_08c6:
						break;
					}
					continue;
					end_IL_08d6:
					break;
				}
				continue;
				end_IL_08e6:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 19;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PeekCharOpCodes.IncreaseBasePrioritySByteEnumEqualityComparer);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02da:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02ba:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02aa:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_029a:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_028d:
																										if (7 < b)
																										{
																											while (8 >= b)
																											{
																												while (8 <= b)
																												{
																													while (true)
																													{
																														IL_0222:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														num = 128;
																														while (true)
																														{
																															if (num != 128)
																															{
																																if (num != 1109)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 76:
																																case 101:
																																	goto IL_0222;
																																case 117:
																																	goto IL_026d;
																																case 17:
																																	goto IL_027d;
																																case 110:
																																case 111:
																																	goto IL_028d;
																																case 26:
																																	goto IL_029a;
																																case 63:
																																case 70:
																																	goto IL_02aa;
																																case 37:
																																	goto IL_02ba;
																																case 64:
																																	goto IL_02ca;
																																case 62:
																																	goto IL_02da;
																																case 52:
																																	goto end_IL_02da;
																																case 18:
																																case 60:
																																	goto end_IL_02ea;
																																case 3:
																																	goto IL_0305;
																																case 46:
																																case 48:
																																	goto IL_0313;
																																case 90:
																																	goto IL_032c;
																																case 85:
																																	goto IL_033a;
																																case 99:
																																	goto IL_0348;
																																case 49:
																																case 100:
																																	goto IL_035b;
																																case 106:
																																	goto IL_0369;
																																case 88:
																																	goto IL_038d;
																																case 24:
																																	goto IL_039b;
																																case 81:
																																case 114:
																																	goto IL_03ae;
																																case 58:
																																	goto IL_03b9;
																																case 34:
																																case 105:
																																	goto IL_03c7;
																																case 25:
																																	goto IL_03da;
																																case 118:
																																	goto IL_03e8;
																																case 65:
																																case 71:
																																	goto end_IL_020f;
																																case 30:
																																	goto IL_0426;
																																case 57:
																																	goto IL_0439;
																																case 44:
																																case 92:
																																	goto IL_0447;
																																case 116:
																																	goto IL_0455;
																																case 119:
																																	goto IL_0460;
																																case 28:
																																case 89:
																																	goto IL_046e;
																																case 35:
																																	goto IL_04ae;
																																case 15:
																																	goto IL_04c2;
																																case 2:
																																case 103:
																																	goto IL_04d5;
																																case 120:
																																	goto IL_04e3;
																																case 0:
																																case 11:
																																	goto IL_04f1;
																																case 14:
																																	goto IL_04ff;
																																case 95:
																																	goto IL_0522;
																																case 22:
																																	goto IL_052c;
																																case 75:
																																	goto IL_053a;
																																case 4:
																																	goto IL_054d;
																																case 32:
																																	goto IL_055b;
																																case 83:
																																	goto IL_0566;
																																case 8:
																																	goto IL_0579;
																																case 121:
																																	goto IL_0587;
																																case 67:
																																case 96:
																																	goto IL_0595;
																																case 74:
																																	goto IL_05d5;
																																case 93:
																																	goto IL_05e9;
																																case 86:
																																case 113:
																																	goto IL_0605;
																																case 84:
																																	goto IL_062e;
																																case 80:
																																	goto IL_063c;
																																case 12:
																																case 27:
																																	goto IL_0658;
																																case 55:
																																	goto IL_0698;
																																case 108:
																																	goto IL_06ac;
																																case 5:
																																case 7:
																																case 9:
																																case 10:
																																case 16:
																																case 20:
																																case 39:
																																case 45:
																																case 50:
																																case 54:
																																case 56:
																																case 61:
																																case 66:
																																case 68:
																																case 72:
																																case 73:
																																case 78:
																																case 87:
																																case 91:
																																case 98:
																																case 109:
																																	goto end_IL_026d;
																																case 13:
																																	goto IL_06df;
																																case 29:
																																	goto IL_06ed;
																																case 51:
																																	goto IL_06fb;
																																case 21:
																																case 31:
																																case 33:
																																case 38:
																																case 42:
																																case 47:
																																case 53:
																																case 59:
																																case 94:
																																case 97:
																																case 102:
																																case 104:
																																case 107:
																																	goto end_IL_02fa;
																																case 69:
																																	goto end_IL_0709;
																																case 43:
																																	goto end_IL_071c;
																																case 77:
																																	goto end_IL_0726;
																																case 19:
																																	goto end_IL_0731;
																																case 79:
																																	goto end_IL_0746;
																																case 1:
																																case 23:
																																	goto end_IL_075b;
																																case 115:
																																	goto end_IL_0774;
																																case 6:
																																case 82:
																																	goto end_IL_0784;
																																case 40:
																																	goto end_IL_0794;
																																case 41:
																																	goto end_IL_07a4;
																																case 36:
																																case 112:
																																	goto IL_07bf;
																																}
																																continue;
																															}
																															array[num5 - 2] = 0;
																															goto IL_0426;
																															IL_0426:
																															num5--;
																															goto end_IL_02fa;
																															continue;
																															end_IL_020f:
																															break;
																														}
																														break;
																													}
																													goto IL_03f6;
																													continue;
																													end_IL_026d:
																													break;
																													IL_026d:;
																												}
																												break;
																												IL_027d:;
																											}
																											break;
																										}
																										goto IL_0305;
																										IL_0348:
																										ptr2 += 8;
																										goto end_IL_02fa;
																										IL_0305:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0313;
																										IL_0313:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_032c;
																										IL_032c:
																										array[num5] = 0;
																										goto IL_033a;
																										IL_033a:
																										num5++;
																										goto IL_0348;
																									}
																									break;
																								}
																								goto IL_035b;
																								IL_039b:
																								ptr2 += 8;
																								goto end_IL_02fa;
																								IL_035b:
																								array[num5] = 0;
																								goto IL_0369;
																								IL_0369:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)ResourceLocationOperation[*(int*)(ptr2 + num3)])();
																								goto IL_038d;
																								IL_038d:
																								num5++;
																								goto IL_039b;
																							}
																							break;
																						}
																						goto IL_03ae;
																						IL_03f6:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02fa;
																						IL_03ae:
																						if (10 >= b)
																						{
																							goto IL_03b9;
																						}
																						goto IL_03da;
																						IL_03b9:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_03c7;
																						IL_03c7:
																						num5--;
																						goto end_IL_02fa;
																						IL_03da:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_03e8;
																						IL_03e8:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_03f6;
																					}
																					break;
																				}
																				goto IL_0439;
																				IL_06ac:
																				num5--;
																				goto end_IL_02fa;
																				IL_0439:
																				if (6 > b)
																				{
																					goto IL_0447;
																				}
																				goto IL_0658;
																				IL_0447:
																				if (3 < b)
																				{
																					goto IL_0455;
																				}
																				goto IL_054d;
																				IL_0455:
																				if (4 >= b)
																				{
																					goto IL_0460;
																				}
																				goto IL_04d5;
																				IL_0460:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_046e;
																				IL_046e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04ae;
																				IL_04ae:
																				array[num5 - 2] = 0;
																				goto IL_04c2;
																				IL_04c2:
																				num5--;
																				goto end_IL_02fa;
																				IL_04d5:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_04e3;
																				IL_04e3:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_04f1;
																				IL_04f1:
																				array[num5] = 0;
																				goto IL_04ff;
																				IL_04ff:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0522;
																				IL_0522:
																				array2[num5] = null;
																				goto IL_052c;
																				IL_052c:
																				num5++;
																				goto IL_053a;
																				IL_053a:
																				ptr2 += 8;
																				goto end_IL_02fa;
																				IL_054d:
																				if (3 > b)
																				{
																					goto IL_055b;
																				}
																				goto IL_0605;
																				IL_055b:
																				if (1 >= b)
																				{
																					goto IL_0566;
																				}
																				goto IL_0579;
																				IL_0566:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0579:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0587;
																				IL_0587:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0595;
																				IL_0595:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05d5;
																				IL_05d5:
																				array[num5 - 2] = 0;
																				goto IL_05e9;
																				IL_05e9:
																				num5--;
																				num = 47;
																				goto end_IL_02fa;
																				IL_0605:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_062e;
																				IL_062e:
																				ptr2 += 8;
																				goto IL_063c;
																				IL_063c:
																				num5--;
																				num = 59;
																				goto end_IL_02fa;
																				IL_0658:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0698;
																				IL_0698:
																				array[num5 - 2] = 0;
																				goto IL_06ac;
																			}
																			break;
																			IL_02ca:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06df;
																	IL_06fb:
																	ptr2 += 8;
																	goto end_IL_02fa;
																	IL_06ed:
																	num5++;
																	goto IL_06fb;
																	IL_06df:
																	array[num5] = 0;
																	goto IL_06ed;
																	continue;
																	end_IL_02da:
																	break;
																}
																continue;
																end_IL_02ea:
																break;
															}
															continue;
															end_IL_02fa:
															break;
														}
														continue;
													}
													goto IL_07bf;
													IL_07bf:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0709:
													break;
												}
												continue;
												end_IL_071c:
												break;
											}
											continue;
											end_IL_0726:
											break;
										}
										continue;
										end_IL_0731:
										break;
									}
									continue;
									end_IL_0746:
									break;
								}
								continue;
								end_IL_075b:
								break;
							}
							continue;
							end_IL_0774:
							break;
						}
						continue;
						end_IL_0784:
						break;
					}
					continue;
					end_IL_0794:
					break;
				}
				continue;
				end_IL_07a4:
				break;
			}
		}
	}

	static Class156()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0052:
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 4:
								goto IL_0046;
							case 0:
								goto IL_0052;
							case 1:
								goto end_IL_0039;
							case 2:
								return;
							case 3:
								return;
							case 5:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
