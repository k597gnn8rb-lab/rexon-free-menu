using System;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Rexon_Menu.Core.Attributes;
using UnityEngine;
using UnityEngine.XR;

[Mod("Gravity: 0.0", "World", "VR: triggers to adjust. PC: click to cycle.", false, 31, ModType.const_0, false)]
internal class Class13 : MonoBehaviour
{
	public static float float_0;

	private float float_1;

	private static float[] float_2;

	private static int int_0;

	private static bool bool_0;

	private static float float_3;

	private static bool bool_1;

	private static double double_0;

	private static IntPtr[] TryPeekencoding;

	private static IntPtr[] RemotingExceptionComEventsSink;

	private static IntPtr[] PropertyAnalysisWinWindows;

	private static IntPtr[] MajorsetTag;

	private unsafe void OnEnable()
	{
		int num = 241;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 207;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							num = 227;
							while (true)
							{
								int[] array3 = new int[8];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										num = 39;
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref KnownAceEnqueue.FUNCFLAGFDISPLAYBINDSelfSid);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 195;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0482:
																	if (b >= 1)
																	{
																		num = 61;
																		while (b <= 30)
																		{
																			while (true)
																			{
																				IL_0462:
																				if (15 < b)
																				{
																					while (true)
																					{
																						IL_0452:
																						if (23 < b)
																						{
																							while (true)
																							{
																								IL_0442:
																								if (27 >= b)
																								{
																									num = 257;
																									while (true)
																									{
																										if (num != 257)
																										{
																											if (num != 1238)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 137:
																												goto IL_0442;
																											case 186:
																												goto IL_0452;
																											case 197:
																												goto IL_0462;
																											case 61:
																												goto IL_0472;
																											case 244:
																												goto IL_0482;
																											case 70:
																												goto end_IL_0482;
																											case 54:
																											case 214:
																												goto end_IL_0495;
																											case 103:
																												goto IL_04b0;
																											case 138:
																												goto IL_04bb;
																											case 153:
																												goto IL_04ce;
																											case 52:
																											case 83:
																												goto IL_04d9;
																											case 130:
																												goto IL_0507;
																											case 69:
																												goto IL_051a;
																											case 150:
																												goto IL_0528;
																											case 47:
																											case 110:
																												goto IL_0536;
																											case 174:
																												goto IL_0552;
																											case 183:
																												goto IL_0565;
																											case 13:
																												goto IL_0573;
																											case 20:
																												goto IL_057e;
																											case 75:
																												goto IL_058c;
																											case 134:
																												goto IL_059f;
																											case 49:
																												goto IL_05ad;
																											case 144:
																												goto IL_05bb;
																											case 46:
																												goto IL_05c9;
																											case 125:
																											case 152:
																												goto IL_05d7;
																											case 149:
																												goto IL_0635;
																											case 189:
																												goto IL_0656;
																											case 19:
																											case 188:
																												goto IL_0661;
																											case 53:
																												goto IL_068f;
																											case 141:
																												goto IL_069a;
																											case 74:
																											case 119:
																												goto IL_06a8;
																											case 92:
																												goto IL_06c1;
																											case 4:
																												goto IL_06d1;
																											case 192:
																												goto IL_06e4;
																											case 194:
																												goto IL_06f7;
																											case 50:
																											case 173:
																												goto IL_0702;
																											case 28:
																												goto IL_0742;
																											case 169:
																												goto IL_0756;
																											case 109:
																												goto IL_0769;
																											case 32:
																												goto IL_0777;
																											case 14:
																												goto IL_0785;
																											case 67:
																												goto IL_0793;
																											case 143:
																											case 165:
																												goto IL_07a1;
																											case 2:
																												goto IL_07e5;
																											case 7:
																												goto IL_07f9;
																											case 57:
																												goto IL_080c;
																											case 59:
																												goto IL_0817;
																											case 62:
																											case 121:
																												goto IL_0825;
																											case 94:
																												goto IL_0851;
																											case 82:
																												goto IL_085f;
																											case 196:
																												goto IL_086f;
																											case 139:
																											case 198:
																												goto IL_0888;
																											case 97:
																												goto IL_08b3;
																											case 200:
																												goto IL_08cc;
																											case 180:
																												goto IL_08da;
																											case 100:
																												goto IL_08e8;
																											case 176:
																												goto IL_08f6;
																											case 114:
																											case 167:
																												goto IL_0904;
																											case 123:
																												goto IL_0966;
																											case 205:
																												goto IL_0979;
																											case 193:
																												goto IL_0987;
																											case 185:
																												goto IL_0992;
																											case 155:
																												goto IL_09a0;
																											case 43:
																											case 202:
																												goto IL_09b3;
																											case 184:
																												goto IL_09f3;
																											case 8:
																												goto IL_0a07;
																											case 0:
																												goto IL_0a1a;
																											case 85:
																												goto IL_0a28;
																											case 9:
																											case 199:
																												goto IL_0a36;
																											case 66:
																												goto IL_0a76;
																											case 5:
																												goto IL_0a93;
																											case 206:
																												goto IL_0aa6;
																											case 3:
																												goto IL_0ab4;
																											case 108:
																											case 129:
																												goto IL_0ac2;
																											case 181:
																											case 208:
																												goto IL_0ae2;
																											case 68:
																												goto IL_0b22;
																											case 12:
																												goto IL_0b36;
																											case 213:
																												goto IL_0b49;
																											case 106:
																											case 215:
																												goto IL_0b5c;
																											case 41:
																											case 217:
																												goto IL_0b74;
																											case 26:
																												goto IL_0b88;
																											case 88:
																												goto IL_0bdc;
																											case 170:
																												goto IL_0bea;
																											case 221:
																												goto IL_0bfd;
																											case 204:
																												goto IL_0c0b;
																											case 226:
																												goto IL_0c1e;
																											case 35:
																												goto IL_0c2c;
																											case 78:
																											case 161:
																												goto IL_0c3a;
																											case 116:
																												goto IL_0c5e;
																											case 159:
																												goto IL_0c6c;
																											case 44:
																												goto IL_0c7a;
																											case 228:
																												goto IL_0c96;
																											case 38:
																											case 40:
																												goto IL_0ca4;
																											case 15:
																												goto IL_0ce4;
																											case 230:
																												goto IL_0cf8;
																											case 231:
																												goto IL_0d0b;
																											case 216:
																												goto IL_0d19;
																											case 234:
																												goto IL_0d2c;
																											case 51:
																												goto IL_0d3a;
																											case 60:
																											case 229:
																												goto IL_0d48;
																											case 160:
																												goto IL_0d9a;
																											case 236:
																												goto IL_0dad;
																											case 25:
																											case 99:
																												goto IL_0db8;
																											case 175:
																												goto IL_0dc6;
																											case 81:
																												goto IL_0dea;
																											case 30:
																												goto IL_0dfd;
																											case 235:
																												goto IL_0e0b;
																											case 238:
																												goto IL_0e1e;
																											case 122:
																											case 131:
																												goto IL_0e2c;
																											case 21:
																												goto IL_0e6c;
																											case 218:
																											case 239:
																												goto IL_0e85;
																											case 191:
																												goto IL_0e93;
																											case 171:
																												goto IL_0eb7;
																											case 37:
																												goto IL_0ec5;
																											case 242:
																												goto IL_0ed8;
																											case 6:
																											case 243:
																												goto IL_0eeb;
																											case 201:
																												goto IL_0ef9;
																											case 128:
																												goto IL_0f1c;
																											case 1:
																												goto IL_0f26;
																											case 73:
																												goto IL_0f3d;
																											case 247:
																												goto IL_0f50;
																											case 248:
																												goto IL_0f6c;
																											case 249:
																												goto IL_0f7f;
																											case 140:
																												goto IL_0f8d;
																											case 33:
																											case 177:
																												goto IL_0f9b;
																											case 42:
																											case 48:
																												goto IL_0fb9;
																											case 172:
																												goto IL_0fe2;
																											case 29:
																												goto IL_0ff0;
																											case 104:
																												goto IL_1003;
																											case 156:
																												goto IL_100e;
																											case 91:
																											case 158:
																												goto IL_1019;
																											case 151:
																												goto IL_102e;
																											case 182:
																												goto IL_1041;
																											case 220:
																												goto IL_104f;
																											case 23:
																											case 115:
																												goto IL_105d;
																											case 102:
																												goto IL_1077;
																											case 187:
																												goto IL_1087;
																											case 31:
																												goto IL_1092;
																											case 24:
																											case 27:
																												goto IL_109d;
																											case 76:
																												goto IL_10b5;
																											case 56:
																												goto IL_10c3;
																											case 135:
																												goto IL_10d1;
																											case 10:
																											case 16:
																											case 18:
																											case 34:
																											case 55:
																											case 64:
																											case 65:
																											case 77:
																											case 79:
																											case 89:
																											case 90:
																											case 101:
																											case 112:
																											case 113:
																											case 117:
																											case 118:
																											case 124:
																											case 126:
																											case 127:
																											case 132:
																											case 145:
																											case 148:
																											case 154:
																											case 168:
																											case 190:
																											case 203:
																											case 210:
																											case 211:
																											case 225:
																											case 232:
																											case 237:
																											case 245:
																											case 250:
																												goto end_IL_042f;
																											case 11:
																											case 17:
																											case 22:
																											case 45:
																											case 58:
																											case 71:
																											case 84:
																											case 86:
																											case 87:
																											case 93:
																											case 95:
																											case 96:
																											case 107:
																											case 111:
																											case 120:
																											case 133:
																											case 136:
																											case 142:
																											case 147:
																											case 157:
																											case 164:
																											case 166:
																											case 178:
																											case 179:
																											case 195:
																											case 209:
																											case 212:
																											case 219:
																											case 222:
																											case 223:
																											case 224:
																											case 233:
																											case 246:
																												goto end_IL_04a5;
																											case 98:
																												goto end_IL_10f4;
																											case 162:
																												goto end_IL_1107;
																											case 39:
																												goto end_IL_111a;
																											case 72:
																												goto end_IL_1125;
																											case 36:
																												goto end_IL_1135;
																											case 163:
																											case 227:
																												goto end_IL_114e;
																											case 146:
																												goto end_IL_115e;
																											case 207:
																												goto end_IL_116e;
																											case 105:
																												goto end_IL_1187;
																											case 240:
																												goto end_IL_1197;
																											case 241:
																												goto end_IL_11a2;
																											case 63:
																											case 80:
																												return;
																											}
																											continue;
																										}
																										if (27 <= b)
																										{
																											goto IL_0fb9;
																										}
																										goto IL_1003;
																										IL_10b5:
																										array[num5] = 5;
																										goto IL_10c3;
																										IL_10d1:
																										ptr2 += 8;
																										goto end_IL_04a5;
																										IL_10c3:
																										num5++;
																										goto IL_10d1;
																										IL_0fb9:
																										((delegate*<UnityEngine.Object, void>)TryPeekencoding[*(int*)(ptr2 + num3)])((Class13)array2[num5 - 1]);
																										goto IL_0fe2;
																										IL_0fe2:
																										num5--;
																										goto IL_0ff0;
																										IL_0ff0:
																										ptr2 += 8;
																										goto end_IL_04a5;
																										IL_1003:
																										if (25 >= b)
																										{
																											goto IL_100e;
																										}
																										goto IL_1087;
																										IL_100e:
																										if (25 <= b)
																										{
																											goto IL_1019;
																										}
																										goto IL_1041;
																										IL_1019:
																										((delegate*<void>)TryPeekencoding[*(int*)(ptr2 + num3)])();
																										goto IL_102e;
																										IL_102e:
																										ptr2 += 8;
																										goto end_IL_04a5;
																										IL_1041:
																										if (24 < b)
																										{
																											break;
																										}
																										goto IL_104f;
																										IL_104f:
																										if (24 > b)
																										{
																											break;
																										}
																										goto IL_105d;
																										IL_105d:
																										float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																										goto IL_1077;
																										IL_1077:
																										num5--;
																										goto end_IL_04a5;
																										IL_1087:
																										if (26 < b)
																										{
																											break;
																										}
																										goto IL_1092;
																										IL_1092:
																										if (26 > b)
																										{
																											break;
																										}
																										goto IL_109d;
																										IL_109d:
																										array2[num5] = array5[*(int*)(ptr2 + num3)];
																										goto IL_10b5;
																										continue;
																										end_IL_042f:
																										break;
																									}
																									break;
																								}
																								goto IL_04b0;
																								IL_0528:
																								if (28 > b)
																								{
																									break;
																								}
																								goto IL_0536;
																								IL_0536:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_04a5;
																								IL_04b0:
																								if (29 < b)
																								{
																									goto IL_04bb;
																								}
																								goto IL_04ce;
																								IL_04bb:
																								if (30 < b)
																								{
																									break;
																								}
																								goto IL_0552;
																								IL_0552:
																								if (30 > b)
																								{
																								}
																								break;
																								IL_04ce:
																								if (29 <= b)
																								{
																									goto IL_04d9;
																								}
																								goto IL_051a;
																								IL_04d9:
																								((Class13)array2[num5 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_0507;
																								IL_0507:
																								num5 -= 2;
																								goto end_IL_04a5;
																								IL_051a:
																								if (28 < b)
																								{
																									break;
																								}
																								goto IL_0528;
																							}
																							break;
																						}
																						goto IL_06f7;
																						IL_08b3:
																						array[num5 - 1] = 0;
																						goto end_IL_04a5;
																						IL_06f7:
																						if (23 <= b)
																						{
																							goto IL_0702;
																						}
																						goto IL_0769;
																						IL_0702:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0742;
																						IL_0742:
																						array[num5 - 2] = 0;
																						goto IL_0756;
																						IL_0756:
																						num5--;
																						goto end_IL_04a5;
																						IL_0769:
																						if (19 >= b)
																						{
																							goto IL_0777;
																						}
																						goto IL_080c;
																						IL_0777:
																						if (19 > b)
																						{
																							goto IL_0785;
																						}
																						goto IL_0b74;
																						IL_0785:
																						if (17 >= b)
																						{
																							goto IL_0793;
																						}
																						goto IL_0c1e;
																						IL_0793:
																						if (17 <= b)
																						{
																							goto IL_07a1;
																						}
																						goto IL_0aa6;
																						IL_07a1:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((float[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_07e5;
																						IL_07e5:
																						array[num5 - 2] = 3;
																						goto IL_07f9;
																						IL_07f9:
																						num5--;
																						goto end_IL_04a5;
																						IL_0aa6:
																						if (16 < b)
																						{
																							break;
																						}
																						goto IL_0ab4;
																						IL_0ab4:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_0ac2;
																						IL_0ac2:
																						array2[num5] = ((delegate*<float[]>)TryPeekencoding[*(int*)(ptr2 + num3)])();
																						goto IL_0b49;
																						IL_0b49:
																						array[num5] = 5;
																						goto IL_0bfd;
																						IL_0bfd:
																						num5++;
																						goto IL_0c0b;
																						IL_0c0b:
																						ptr2 += 8;
																						goto end_IL_04a5;
																						IL_0c1e:
																						if (18 < b)
																						{
																							break;
																						}
																						goto IL_0c2c;
																						IL_0c2c:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_0c3a;
																						IL_0c3a:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<float>)TryPeekencoding[*(int*)(ptr2 + num3)])();
																						goto IL_0c5e;
																						IL_0c5e:
																						array[num5] = 3;
																						goto IL_0c6c;
																						IL_0c6c:
																						num5++;
																						goto IL_0c7a;
																						IL_0c7a:
																						ptr2 += 8;
																						num = 133;
																						goto end_IL_04a5;
																						IL_0b74:
																						array[num5 - 2] = 0;
																						goto IL_0b88;
																						IL_0b88:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<float, float, bool>)TryPeekencoding[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]))) ? 1 : 0);
																						goto IL_0bdc;
																						IL_0bdc:
																						num5--;
																						goto IL_0bea;
																						IL_0bea:
																						ptr2 += 8;
																						goto end_IL_04a5;
																						IL_080c:
																						if (21 >= b)
																						{
																							goto IL_0817;
																						}
																						goto IL_0851;
																						IL_0817:
																						if (21 <= b)
																						{
																							goto IL_0825;
																						}
																						goto IL_0d2c;
																						IL_0825:
																						*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (nint)((float[])array2[num5 - 1]).LongLength;
																						goto IL_086f;
																						IL_086f:
																						array[num5 - 1] = 2;
																						goto end_IL_04a5;
																						IL_0d2c:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_0d3a;
																						IL_0d3a:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_0d48;
																						IL_0d48:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0d9a;
																						IL_0d9a:
																						num5--;
																						goto end_IL_04a5;
																						IL_0851:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_085f;
																						IL_085f:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_0888;
																						IL_0888:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_08b3;
																					}
																					break;
																				}
																				goto IL_0565;
																				IL_0b5c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_04a5;
																				IL_0565:
																				if (15 > b)
																				{
																					goto IL_0573;
																				}
																				num = 215;
																				goto IL_0b5c;
																				IL_0573:
																				if (7 >= b)
																				{
																					goto IL_057e;
																				}
																				goto IL_059f;
																				IL_057e:
																				if (7 > b)
																				{
																					goto IL_058c;
																				}
																				goto IL_0ae2;
																				IL_058c:
																				if (3 >= b)
																				{
																					goto IL_0656;
																				}
																				goto IL_0979;
																				IL_0656:
																				if (3 <= b)
																				{
																					goto IL_0661;
																				}
																				goto IL_068f;
																				IL_0661:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0d0b;
																				IL_0d0b:
																				ptr2 += 8;
																				goto IL_0d19;
																				IL_0d19:
																				num5--;
																				goto end_IL_04a5;
																				IL_068f:
																				if (1 >= b)
																				{
																					goto IL_069a;
																				}
																				goto IL_06d1;
																				IL_069a:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_06a8;
																				IL_06a8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_06c1;
																				IL_06c1:
																				array[num5] = 0;
																				goto IL_06e4;
																				IL_06e4:
																				num5++;
																				goto IL_0ed8;
																				IL_0ed8:
																				ptr2 += 8;
																				goto end_IL_04a5;
																				IL_06d1:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0e1e;
																				IL_0e1e:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0e2c;
																				IL_0e2c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0e6c;
																				IL_0e6c:
																				array[num5 - 2] = 0;
																				goto IL_0f50;
																				IL_0f50:
																				num5--;
																				num = 22;
																				goto end_IL_04a5;
																				IL_0979:
																				if (5 >= b)
																				{
																					goto IL_0987;
																				}
																				goto IL_0a1a;
																				IL_0987:
																				if (5 > b)
																				{
																					goto IL_0992;
																				}
																				goto IL_09b3;
																				IL_0992:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_09a0;
																				IL_09a0:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0eeb;
																				IL_0eeb:
																				array[num5] = 0;
																				goto IL_0ef9;
																				IL_0ef9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0f1c;
																				IL_0f1c:
																				array2[num5] = null;
																				goto IL_0f26;
																				IL_0f26:
																				num5++;
																				num = 73;
																				goto IL_0f3d;
																				IL_0f3d:
																				ptr2 += 8;
																				goto end_IL_04a5;
																				IL_09b3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_09f3;
																				IL_09f3:
																				array[num5 - 2] = 0;
																				goto IL_0a07;
																				IL_0a07:
																				num5--;
																				goto end_IL_04a5;
																				IL_0a1a:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0a28;
																				IL_0a28:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0a36;
																				IL_0a36:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0a76;
																				IL_0a76:
																				array[num5 - 2] = 0;
																				num = 5;
																				goto IL_0a93;
																				IL_0a93:
																				num5--;
																				goto end_IL_04a5;
																				IL_0ae2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0b22;
																				IL_0b22:
																				array[num5 - 2] = 0;
																				goto IL_0b36;
																				IL_0b36:
																				num5--;
																				goto end_IL_04a5;
																				IL_059f:
																				if (11 < b)
																				{
																					goto IL_05ad;
																				}
																				goto IL_08cc;
																				IL_05ad:
																				if (13 < b)
																				{
																					goto IL_05bb;
																				}
																				goto IL_0dad;
																				IL_05bb:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_05c9;
																				IL_05c9:
																				if (14 > b)
																				{
																					break;
																				}
																				goto IL_05d7;
																				IL_05d7:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0635;
																				IL_0635:
																				num5--;
																				goto end_IL_04a5;
																				IL_0dad:
																				if (13 <= b)
																				{
																					goto IL_0db8;
																				}
																				goto IL_0dfd;
																				IL_0db8:
																				array[num5] = 0;
																				goto IL_0dc6;
																				IL_0dc6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)TryPeekencoding[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_0dea;
																				IL_0dea:
																				num5++;
																				goto IL_0f6c;
																				IL_0f6c:
																				ptr2 += 8;
																				goto end_IL_04a5;
																				IL_0dfd:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_0e0b;
																				IL_0e0b:
																				if (12 > b)
																				{
																					break;
																				}
																				goto end_IL_04a5;
																				IL_08cc:
																				if (11 > b)
																				{
																					goto IL_08da;
																				}
																				goto IL_0e85;
																				IL_08da:
																				if (9 < b)
																				{
																					goto IL_08e8;
																				}
																				goto IL_0c96;
																				IL_08e8:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_08f6;
																				IL_08f6:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0904;
																				IL_0904:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0966;
																				IL_0966:
																				num5 -= 2;
																				goto end_IL_04a5;
																				IL_0c96:
																				if (9 <= b)
																				{
																					goto IL_0ca4;
																				}
																				goto IL_0f7f;
																				IL_0ca4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0ce4;
																				IL_0ce4:
																				array[num5 - 2] = 0;
																				goto IL_0cf8;
																				IL_0cf8:
																				num5--;
																				goto end_IL_04a5;
																				IL_0f7f:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0f8d;
																				IL_0f8d:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0f9b;
																				IL_0f9b:
																				num5--;
																				goto end_IL_04a5;
																				IL_0e85:
																				array[num5] = 0;
																				goto IL_0e93;
																				IL_0e93:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)TryPeekencoding[*(int*)(ptr2 + num3)])();
																				goto IL_0eb7;
																				IL_0eb7:
																				num5++;
																				goto IL_0ec5;
																				IL_0ec5:
																				ptr2 += 8;
																				goto end_IL_04a5;
																			}
																			break;
																			IL_0472:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_04a5;
																	continue;
																	end_IL_0482:
																	break;
																}
																continue;
																end_IL_0495:
																break;
															}
															continue;
															end_IL_04a5:
															break;
														}
														continue;
														end_IL_10f4:
														break;
													}
													continue;
													end_IL_1107:
													break;
												}
												continue;
												end_IL_111a:
												break;
											}
											continue;
											end_IL_1125:
											break;
										}
										continue;
										end_IL_1135:
										break;
									}
									continue;
									end_IL_114e:
									break;
								}
								continue;
								end_IL_115e:
								break;
							}
							continue;
							end_IL_116e:
							break;
						}
						continue;
						end_IL_1187:
						break;
					}
					continue;
					end_IL_1197:
					break;
				}
				continue;
				end_IL_11a2:
				break;
			}
		}
	}

	private unsafe void Update()
	{
		int num = 374;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 38;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 260;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											object[] array5 = new object[1];
											while (true)
											{
												array5[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FileLocationHashAlgorithm.HASHALGIDSafeArrayAsSystemArray);
													num = 403;
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_08af:
																		if (b >= 1)
																		{
																			while (b <= 61)
																			{
																				while (true)
																				{
																					if (31 >= b)
																					{
																						while (true)
																						{
																							if (31 > b)
																							{
																								while (true)
																								{
																									if (15 < b)
																									{
																										while (true)
																										{
																											IL_085f:
																											if (23 < b)
																											{
																												while (true)
																												{
																													IL_084f:
																													if (27 >= b)
																													{
																														while (true)
																														{
																															IL_083f:
																															if (27 > b)
																															{
																																while (true)
																																{
																																	IL_082c:
																																	if (25 >= b)
																																	{
																																		num = 511;
																																		while (true)
																																		{
																																			if (num != 511)
																																			{
																																				if (num != 1492)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 45:
																																					goto IL_082c;
																																				case 46:
																																					goto IL_083f;
																																				case 493:
																																					goto IL_084f;
																																				case 231:
																																					goto IL_085f;
																																				case 279:
																																					goto end_IL_085f;
																																				case 101:
																																					goto end_IL_086f;
																																				case 107:
																																					goto end_IL_087f;
																																				case 254:
																																					goto end_IL_088f;
																																				case 448:
																																					goto IL_08af;
																																				case 333:
																																					goto end_IL_08af;
																																				case 9:
																																				case 51:
																																					goto end_IL_08bf;
																																				case 120:
																																					goto IL_08da;
																																				case 180:
																																					goto IL_08e8;
																																				case 224:
																																				case 236:
																																					goto IL_08f6;
																																				case 96:
																																					goto IL_0904;
																																				case 233:
																																					goto IL_0927;
																																				case 381:
																																					goto IL_0935;
																																				case 389:
																																					goto IL_0948;
																																				case 242:
																																				case 359:
																																					goto IL_0956;
																																				case 212:
																																					goto IL_099f;
																																				case 108:
																																					goto IL_09b3;
																																				case 6:
																																				case 414:
																																					goto IL_09c6;
																																				case 75:
																																					goto IL_09d4;
																																				case 341:
																																					goto IL_09f2;
																																				case 57:
																																					goto IL_0a00;
																																				case 441:
																																					goto IL_0a13;
																																				case 127:
																																					goto IL_0a21;
																																				case 79:
																																					goto IL_0a38;
																																				case 370:
																																					goto IL_0a51;
																																				case 277:
																																					goto IL_0a68;
																																				case 172:
																																				case 237:
																																					goto IL_0a73;
																																				case 325:
																																					goto IL_0a9c;
																																				case 394:
																																					goto IL_0aaa;
																																				case 207:
																																					goto IL_0abd;
																																				case 433:
																																					goto IL_0ac8;
																																				case 20:
																																				case 24:
																																					goto IL_0ad6;
																																				case 87:
																																					goto IL_0aef;
																																				case 52:
																																					goto IL_0afd;
																																				case 396:
																																					goto IL_0b0b;
																																				case 295:
																																					goto IL_0b1e;
																																				case 322:
																																					goto IL_0b3a;
																																				case 227:
																																					goto IL_0b48;
																																				case 216:
																																				case 336:
																																					goto IL_0b56;
																																				case 291:
																																				case 458:
																																					goto IL_0b69;
																																				case 128:
																																					goto IL_0ba9;
																																				case 37:
																																					goto IL_0bbd;
																																				case 462:
																																					goto IL_0bd0;
																																				case 42:
																																				case 375:
																																					goto IL_0bde;
																																				case 360:
																																					goto IL_0c1e;
																																				case 195:
																																					goto IL_0c32;
																																				case 464:
																																					goto IL_0c45;
																																				case 337:
																																					goto IL_0c50;
																																				case 179:
																																					goto IL_0c5e;
																																				case 145:
																																				case 150:
																																					goto IL_0c6c;
																																				case 413:
																																				case 470:
																																					goto IL_0c84;
																																				case 485:
																																					goto IL_0cc7;
																																				case 272:
																																				case 386:
																																					goto IL_0cd2;
																																				case 142:
																																					goto IL_0ceb;
																																				case 41:
																																					goto IL_0cf9;
																																				case 292:
																																					goto IL_0d07;
																																				case 143:
																																					goto IL_0d1a;
																																				case 132:
																																					goto IL_0d28;
																																				case 487:
																																					goto IL_0d3b;
																																				case 438:
																																					goto IL_0d4f;
																																				case 489:
																																					goto IL_0d62;
																																				case 34:
																																					goto IL_0d70;
																																				case 104:
																																				case 442:
																																					goto IL_0d7b;
																																				case 412:
																																					goto IL_0dbb;
																																				case 123:
																																					goto IL_0dd4;
																																				case 55:
																																					goto IL_0de2;
																																				case 56:
																																				case 66:
																																					goto IL_0df0;
																																				case 419:
																																					goto IL_0dfe;
																																				case 248:
																																					goto IL_0e21;
																																				case 151:
																																					goto IL_0e39;
																																				case 18:
																																					goto IL_0e47;
																																				case 26:
																																				case 461:
																																					goto IL_0e55;
																																				case 454:
																																					goto IL_0e95;
																																				case 200:
																																					goto IL_0ea9;
																																				case 495:
																																					goto IL_0ebc;
																																				case 494:
																																					goto IL_0eca;
																																				case 164:
																																				case 167:
																																					goto IL_0ed5;
																																				case 121:
																																					goto IL_0f15;
																																				case 201:
																																					goto IL_0f29;
																																				case 405:
																																					goto IL_0f3c;
																																				case 93:
																																					goto IL_0f4a;
																																				case 122:
																																				case 213:
																																					goto IL_0f58;
																																				case 44:
																																					goto IL_0f6b;
																																				case 270:
																																					goto IL_0f79;
																																				case 226:
																																				case 427:
																																					goto IL_0f87;
																																				case 437:
																																					goto IL_0fe9;
																																				case 100:
																																				case 496:
																																					goto IL_0ffc;
																																				case 106:
																																					goto IL_1019;
																																				case 114:
																																					goto IL_106b;
																																				case 343:
																																					goto IL_1082;
																																				case 498:
																																					goto IL_1095;
																																				case 312:
																																					goto IL_10a3;
																																				case 469:
																																				case 475:
																																					goto IL_10ae;
																																				case 497:
																																					goto IL_10ee;
																																				case 421:
																																					goto IL_1102;
																																				case 77:
																																					goto IL_1115;
																																				case 447:
																																					goto end_IL_0819;
																																				case 174:
																																				case 444:
																																					goto IL_112e;
																																				case 258:
																																					goto IL_1152;
																																				case 111:
																																					goto IL_1160;
																																				case 411:
																																					goto IL_116e;
																																				case 275:
																																					goto IL_1181;
																																				case 286:
																																					goto IL_118f;
																																				case 296:
																																				case 439:
																																					goto IL_119d;
																																				case 28:
																																					goto IL_11ef;
																																				case 199:
																																					goto IL_120b;
																																				case 278:
																																					goto IL_1219;
																																				case 23:
																																				case 432:
																																					goto IL_1227;
																																				case 436:
																																					goto IL_1241;
																																				case 154:
																																					goto IL_124f;
																																				case 239:
																																					goto IL_125d;
																																				case 310:
																																					goto IL_1270;
																																				case 192:
																																					goto IL_127e;
																																				case 262:
																																				case 371:
																																					goto IL_1289;
																																				case 316:
																																					goto IL_12a2;
																																				case 459:
																																					goto IL_12b0;
																																				case 118:
																																					goto IL_12be;
																																				case 294:
																																					goto IL_12d1;
																																				case 62:
																																					goto IL_12df;
																																				case 97:
																																				case 183:
																																					goto IL_12ed;
																																				case 95:
																																					goto IL_1307;
																																				case 416:
																																					goto IL_131a;
																																				case 13:
																																					goto IL_1331;
																																				case 72:
																																				case 73:
																																					goto IL_133f;
																																				case 103:
																																					goto IL_1353;
																																				case 60:
																																					goto IL_1392;
																																				case 499:
																																					goto IL_13a5;
																																				case 491:
																																					goto IL_13c9;
																																				case 398:
																																					goto IL_13d7;
																																				case 501:
																																					goto IL_13ea;
																																				case 452:
																																					goto IL_13f8;
																																				case 503:
																																					goto IL_140b;
																																				case 251:
																																				case 490:
																																					goto IL_1429;
																																				case 102:
																																					goto IL_1447;
																																				case 205:
																																					goto IL_1455;
																																				case 244:
																																					goto IL_1463;
																																				case 368:
																																					goto IL_1476;
																																				case 232:
																																					goto IL_1484;
																																				case 423:
																																				case 474:
																																					goto IL_1492;
																																				case 380:
																																					goto IL_14a6;
																																				case 334:
																																					goto IL_14e5;
																																				case 379:
																																					goto IL_14f8;
																																				case 317:
																																					goto IL_1506;
																																				case 153:
																																				case 250:
																																					goto IL_1511;
																																				case 215:
																																					goto IL_1563;
																																				case 393:
																																					goto IL_1571;
																																				case 305:
																																					goto IL_1584;
																																				case 309:
																																					goto IL_1592;
																																				case 308:
																																				case 473:
																																					goto IL_15a0;
																																				case 230:
																																					goto IL_15b4;
																																				case 481:
																																					goto IL_15f2;
																																				case 347:
																																					goto IL_1605;
																																				case 243:
																																					goto IL_1613;
																																				case 238:
																																				case 463:
																																					goto IL_1621;
																																				case 129:
																																					goto IL_164c;
																																				case 267:
																																					goto IL_1665;
																																				case 187:
																																					goto IL_1673;
																																				case 158:
																																				case 366:
																																					goto IL_167e;
																																				case 84:
																																					goto IL_1692;
																																				case 53:
																																					goto IL_16d1;
																																				case 301:
																																					goto IL_16e4;
																																				case 160:
																																					goto IL_16f2;
																																				case 344:
																																					goto IL_1700;
																																				case 15:
																																					goto IL_170e;
																																				case 446:
																																					goto IL_171c;
																																				case 384:
																																					goto IL_1727;
																																				case 189:
																																				case 326:
																																					goto IL_1735;
																																				case 252:
																																					goto IL_1749;
																																				case 193:
																																					goto IL_1781;
																																				case 30:
																																					goto IL_1794;
																																				case 152:
																																					goto IL_17a2;
																																				case 140:
																																				case 361:
																																					goto IL_17b0;
																																				case 338:
																																					goto IL_17c9;
																																				case 148:
																																				case 276:
																																					goto IL_17dc;
																																				case 116:
																																					goto IL_17f9;
																																				case 385:
																																					goto IL_1838;
																																				case 5:
																																					goto IL_184b;
																																				case 424:
																																					goto IL_1859;
																																				case 163:
																																				case 255:
																																					goto IL_1864;
																																				case 135:
																																					goto IL_1885;
																																				case 284:
																																					goto IL_1893;
																																				case 318:
																																					goto IL_18a1;
																																				case 365:
																																					goto IL_18b4;
																																				case 249:
																																					goto IL_18c2;
																																				case 32:
																																				case 320:
																																					goto IL_18d0;
																																				case 257:
																																					goto IL_18ec;
																																				case 356:
																																					goto IL_18fa;
																																				case 170:
																																				case 367:
																																					goto IL_1908;
																																				case 299:
																																					goto IL_1946;
																																				case 91:
																																					goto IL_195a;
																																				case 76:
																																				case 117:
																																					goto IL_196d;
																																				case 161:
																																					goto IL_199a;
																																				case 168:
																																					goto IL_19a8;
																																				case 133:
																																					goto IL_19b6;
																																				case 202:
																																					goto IL_19c9;
																																				case 349:
																																					goto IL_19d7;
																																				case 327:
																																					goto IL_19e5;
																																				case 352:
																																					goto IL_19f3;
																																				case 222:
																																				case 407:
																																					goto IL_1a07;
																																				case 166:
																																					goto IL_1a65;
																																				case 471:
																																					goto IL_1a78;
																																				case 7:
																																					goto IL_1a86;
																																				case 298:
																																				case 402:
																																					goto IL_1a94;
																																				case 465:
																																					goto IL_1aa8;
																																				case 181:
																																					goto IL_1afc;
																																				case 182:
																																					goto IL_1b0a;
																																				case 342:
																																					goto IL_1b1d;
																																				case 186:
																																					goto IL_1b2b;
																																				case 377:
																																				case 390:
																																					goto IL_1b39;
																																				case 176:
																																					goto IL_1b4d;
																																				case 450:
																																					goto IL_1b95;
																																				case 48:
																																				case 303:
																																					goto IL_1ba8;
																																				case 486:
																																					goto IL_1bd6;
																																				case 388:
																																					goto IL_1be9;
																																				case 112:
																																					goto IL_1bf7;
																																				case 197:
																																					goto IL_1c05;
																																				case 81:
																																					goto IL_1c13;
																																				case 234:
																																				case 400:
																																					goto IL_1c21;
																																				case 159:
																																					goto IL_1c61;
																																				case 332:
																																					goto IL_1c75;
																																				case 119:
																																				case 440:
																																					goto IL_1c88;
																																				case 319:
																																					goto IL_1ccf;
																																				case 311:
																																					goto IL_1cdd;
																																				case 420:
																																					goto IL_1cf0;
																																				case 417:
																																					goto IL_1cfe;
																																				case 10:
																																				case 282:
																																					goto IL_1d0c;
																																				case 418:
																																					goto IL_1d20;
																																				case 500:
																																					goto IL_1d5f;
																																				case 362:
																																					goto IL_1d72;
																																				case 422:
																																					goto IL_1d80;
																																				case 131:
																																					goto IL_1d8e;
																																				case 467:
																																				case 472:
																																					goto IL_1d99;
																																				case 47:
																																					goto IL_1dad;
																																				case 253:
																																					goto IL_1dec;
																																				case 157:
																																					goto IL_1dff;
																																				case 12:
																																					goto IL_1e0d;
																																				case 204:
																																				case 492:
																																					goto IL_1e1b;
																																				case 468:
																																					goto IL_1e2f;
																																				case 35:
																																					goto IL_1e7c;
																																				case 357:
																																					goto IL_1e8a;
																																				case 261:
																																					goto IL_1e9d;
																																				case 54:
																																					goto IL_1eab;
																																				case 22:
																																				case 240:
																																					goto IL_1eb9;
																																				case 110:
																																					goto IL_1ec3;
																																				case 3:
																																					goto IL_1ed1;
																																				case 351:
																																					goto IL_1ee4;
																																				case 65:
																																					goto IL_1ef2;
																																				case 85:
																																				case 245:
																																					goto IL_1f00;
																																				case 196:
																																					goto IL_1f40;
																																				case 36:
																																					goto IL_1f54;
																																				case 480:
																																					goto IL_1f67;
																																				case 43:
																																					goto IL_1f75;
																																				case 17:
																																				case 141:
																																					goto IL_1f80;
																																				case 340:
																																					goto IL_1f94;
																																				case 185:
																																					goto IL_1fdc;
																																				case 214:
																																					goto IL_1fef;
																																				case 92:
																																					goto IL_1ffd;
																																				case 264:
																																				case 376:
																																					goto IL_200b;
																																				case 67:
																																					goto IL_202e;
																																				case 273:
																																					goto IL_2041;
																																				case 177:
																																					goto IL_204f;
																																				case 68:
																																					goto IL_206b;
																																				case 2:
																																				case 288:
																																					goto IL_2076;
																																				case 460:
																																					goto IL_208a;
																																				case 285:
																																					goto IL_20c9;
																																				case 80:
																																					goto IL_20dc;
																																				case 443:
																																					goto IL_20ea;
																																				case 358:
																																					goto IL_20f8;
																																				case 88:
																																					goto IL_2106;
																																				case 31:
																																					goto IL_2114;
																																				case 431:
																																				case 504:
																																					goto IL_2122;
																																				case 476:
																																					goto IL_2136;
																																				case 483:
																																					goto IL_2175;
																																				case 372:
																																					goto IL_2191;
																																				case 136:
																																				case 263:
																																					goto IL_219f;
																																				case 268:
																																					goto IL_220d;
																																				case 156:
																																					goto IL_2220;
																																				case 155:
																																					goto IL_222e;
																																				case 287:
																																				case 302:
																																					goto IL_223c;
																																				case 221:
																																					goto IL_2260;
																																				case 300:
																																					goto IL_226e;
																																				case 297:
																																					goto IL_2285;
																																				case 304:
																																				case 348:
																																					goto IL_2298;
																																				case 19:
																																					goto IL_22ac;
																																				case 171:
																																					goto IL_22f4;
																																				case 307:
																																					goto IL_2307;
																																				case 218:
																																					goto IL_2315;
																																				case 209:
																																				case 266:
																																					goto IL_2320;
																																				case 8:
																																					goto IL_2334;
																																				case 138:
																																					goto IL_2373;
																																				case 211:
																																					goto IL_2386;
																																				case 330:
																																					goto IL_2394;
																																				case 126:
																																				case 323:
																																					goto IL_23a2;
																																				case 345:
																																					goto IL_23b6;
																																				case 4:
																																					goto IL_23f5;
																																				case 69:
																																					goto IL_2405;
																																				case 269:
																																					goto IL_2410;
																																				case 147:
																																				case 451:
																																					goto IL_241b;
																																				case 339:
																																					goto IL_2435;
																																				case 0:
																																				case 1:
																																				case 11:
																																				case 14:
																																				case 29:
																																				case 33:
																																				case 49:
																																				case 50:
																																				case 59:
																																				case 71:
																																				case 74:
																																				case 78:
																																				case 83:
																																				case 86:
																																				case 98:
																																				case 105:
																																				case 113:
																																				case 125:
																																				case 137:
																																				case 144:
																																				case 146:
																																				case 162:
																																				case 173:
																																				case 175:
																																				case 178:
																																				case 191:
																																				case 203:
																																				case 217:
																																				case 219:
																																				case 223:
																																				case 228:
																																				case 241:
																																				case 247:
																																				case 256:
																																				case 271:
																																				case 280:
																																				case 289:
																																				case 293:
																																				case 306:
																																				case 313:
																																				case 315:
																																				case 321:
																																				case 324:
																																				case 329:
																																				case 335:
																																				case 346:
																																				case 350:
																																				case 354:
																																				case 355:
																																				case 369:
																																				case 387:
																																				case 391:
																																				case 395:
																																				case 399:
																																				case 408:
																																				case 409:
																																				case 410:
																																				case 425:
																																				case 426:
																																				case 428:
																																				case 429:
																																				case 435:
																																				case 449:
																																				case 488:
																																					goto end_IL_089f;
																																				case 16:
																																				case 21:
																																				case 25:
																																				case 27:
																																				case 39:
																																				case 40:
																																				case 58:
																																				case 61:
																																				case 63:
																																				case 64:
																																				case 70:
																																				case 82:
																																				case 89:
																																				case 90:
																																				case 99:
																																				case 109:
																																				case 115:
																																				case 124:
																																				case 134:
																																				case 139:
																																				case 149:
																																				case 165:
																																				case 169:
																																				case 184:
																																				case 188:
																																				case 190:
																																				case 194:
																																				case 198:
																																				case 206:
																																				case 208:
																																				case 210:
																																				case 220:
																																				case 225:
																																				case 229:
																																				case 235:
																																				case 246:
																																				case 259:
																																				case 265:
																																				case 281:
																																				case 290:
																																				case 328:
																																				case 331:
																																				case 363:
																																				case 364:
																																				case 378:
																																				case 382:
																																				case 392:
																																				case 397:
																																				case 401:
																																				case 404:
																																				case 406:
																																				case 415:
																																				case 430:
																																				case 434:
																																				case 445:
																																				case 453:
																																				case 456:
																																				case 466:
																																				case 477:
																																				case 478:
																																				case 479:
																																				case 482:
																																				case 484:
																																				case 502:
																																					goto end_IL_08cf;
																																				case 403:
																																					goto end_IL_2461;
																																				case 455:
																																					goto end_IL_2474;
																																				case 283:
																																					goto end_IL_247e;
																																				case 274:
																																					goto end_IL_2492;
																																				case 353:
																																					goto end_IL_24a2;
																																				case 260:
																																					goto end_IL_24b2;
																																				case 94:
																																					goto end_IL_24c2;
																																				case 457:
																																					goto end_IL_24d2;
																																				case 383:
																																					goto end_IL_24dd;
																																				case 38:
																																					goto end_IL_24ed;
																																				case 373:
																																					goto end_IL_24fd;
																																				case 374:
																																					goto end_IL_250d;
																																				case 130:
																																				case 314:
																																					return;
																																				}
																																				continue;
																																			}
																																			if (25 <= b)
																																			{
																																				goto IL_1429;
																																			}
																																			goto IL_1476;
																																			IL_1492:
																																			array[num6 - 1] = 0;
																																			goto IL_14a6;
																																			IL_14e5:
																																			ptr2 += 8;
																																			goto end_IL_08cf;
																																			IL_14a6:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																																			goto IL_14e5;
																																			IL_1429:
																																			array2[num6] = ((delegate*<Rigidbody>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])();
																																			goto IL_1447;
																																			IL_1447:
																																			array[num6] = 5;
																																			goto IL_1455;
																																			IL_1455:
																																			num6++;
																																			goto IL_1463;
																																			IL_1463:
																																			ptr2 += 8;
																																			goto end_IL_08cf;
																																			IL_1476:
																																			if (24 < b)
																																			{
																																				goto end_IL_089f;
																																			}
																																			goto IL_1484;
																																			IL_1484:
																																			if (24 > b)
																																			{
																																				goto end_IL_089f;
																																			}
																																			goto IL_1492;
																																			continue;
																																			end_IL_0819:
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_08da;
																																	IL_0927:
																																	num6++;
																																	goto IL_0935;
																																	IL_0935:
																																	ptr2 += 8;
																																	goto end_IL_08cf;
																																	IL_08da:
																																	if (26 < b)
																																	{
																																		goto end_IL_089f;
																																	}
																																	goto IL_08e8;
																																	IL_08e8:
																																	if (26 > b)
																																	{
																																		goto end_IL_089f;
																																	}
																																	goto IL_08f6;
																																	IL_08f6:
																																	array[num6] = 4;
																																	goto IL_0904;
																																	IL_0904:
																																	array2[num6] = ((delegate*<Vector3>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])();
																																	goto IL_0927;
																																}
																																break;
																															}
																															goto IL_0ffc;
																															IL_1082:
																															ptr2 += 8;
																															goto end_IL_08cf;
																															IL_0ffc:
																															array[num6 - 2] = 4;
																															num = 106;
																															goto IL_1019;
																															IL_1019:
																															array2[num6 - 2] = ((delegate*<Vector3, float, Vector3>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																															goto IL_106b;
																															IL_106b:
																															num6--;
																															num = 343;
																															goto IL_1082;
																														}
																														break;
																													}
																													goto IL_14f8;
																													IL_164c:
																													array[num6 - 1] = 0;
																													goto end_IL_08cf;
																													IL_14f8:
																													if (29 >= b)
																													{
																														goto IL_1506;
																													}
																													goto IL_1605;
																													IL_1506:
																													if (29 <= b)
																													{
																														goto IL_1511;
																													}
																													goto IL_1584;
																													IL_1511:
																													((delegate*<Rigidbody, Vector3, ForceMode, void>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 3], (Vector3)array2[num6 - 2], *(ForceMode*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																													goto IL_1563;
																													IL_1563:
																													num6 -= 3;
																													goto IL_1571;
																													IL_1571:
																													ptr2 += 8;
																													goto end_IL_08cf;
																													IL_1584:
																													if (28 < b)
																													{
																														goto end_IL_089f;
																													}
																													goto IL_1592;
																													IL_1592:
																													if (28 > b)
																													{
																														goto end_IL_089f;
																													}
																													goto IL_15a0;
																													IL_15a0:
																													array[num6 - 1] = 3;
																													goto IL_15b4;
																													IL_15b4:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Rigidbody, float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 1]);
																													goto IL_15f2;
																													IL_15f2:
																													ptr2 += 8;
																													goto end_IL_08cf;
																													IL_1605:
																													if (30 < b)
																													{
																														goto end_IL_089f;
																													}
																													goto IL_1613;
																													IL_1613:
																													if (30 > b)
																													{
																														goto end_IL_089f;
																													}
																													goto IL_1621;
																													IL_1621:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_164c;
																												}
																												goto IL_1123;
																											}
																											goto IL_0948;
																											IL_1353:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_1392;
																											IL_0948:
																											if (23 <= b)
																											{
																												goto IL_0956;
																											}
																											goto IL_1095;
																											IL_0956:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											num = 212;
																											goto IL_099f;
																											IL_099f:
																											array[num6 - 2] = 3;
																											goto IL_09b3;
																											IL_09b3:
																											num6--;
																											goto end_IL_08cf;
																											IL_1095:
																											if (19 >= b)
																											{
																												goto IL_10a3;
																											}
																											goto IL_1270;
																											IL_10a3:
																											if (19 <= b)
																											{
																												goto IL_10ae;
																											}
																											goto IL_1115;
																											IL_10ae:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_10ee;
																											IL_10ee:
																											array[num6 - 2] = 3;
																											goto IL_1102;
																											IL_1102:
																											num6--;
																											goto end_IL_08cf;
																											IL_1115:
																											if (17 >= b)
																											{
																												goto IL_1123;
																											}
																											goto IL_120b;
																											IL_1123:
																											if (17 <= b)
																											{
																												goto IL_112e;
																											}
																											goto IL_1181;
																											IL_112e:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])();
																											goto IL_1152;
																											IL_1152:
																											array[num6] = 3;
																											goto IL_1160;
																											IL_1160:
																											num6++;
																											goto IL_116e;
																											IL_116e:
																											ptr2 += 8;
																											goto end_IL_08cf;
																											IL_1181:
																											if (16 < b)
																											{
																												goto end_IL_089f;
																											}
																											goto IL_118f;
																											IL_118f:
																											if (16 > b)
																											{
																												goto end_IL_089f;
																											}
																											goto IL_119d;
																											IL_119d:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_11ef;
																											IL_11ef:
																											num6--;
																											num = 134;
																											goto end_IL_08cf;
																											IL_120b:
																											if (18 < b)
																											{
																												goto end_IL_089f;
																											}
																											goto IL_1219;
																											IL_1219:
																											if (18 > b)
																											{
																												goto end_IL_089f;
																											}
																											goto IL_1227;
																											IL_1227:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																											goto IL_1241;
																											IL_1241:
																											array[num6] = 3;
																											goto IL_124f;
																											IL_124f:
																											num6++;
																											goto IL_125d;
																											IL_125d:
																											ptr2 += 8;
																											goto end_IL_08cf;
																											IL_1270:
																											if (21 >= b)
																											{
																												goto IL_127e;
																											}
																											goto IL_131a;
																											IL_127e:
																											if (21 <= b)
																											{
																												goto IL_1289;
																											}
																											goto IL_12d1;
																											IL_1289:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																											goto IL_12a2;
																											IL_12a2:
																											array[num6] = 3;
																											goto IL_12b0;
																											IL_12b0:
																											num6++;
																											goto IL_12be;
																											IL_12be:
																											ptr2 += 16;
																											goto end_IL_08cf;
																											IL_12d1:
																											if (20 < b)
																											{
																												goto end_IL_089f;
																											}
																											goto IL_12df;
																											IL_12df:
																											if (20 > b)
																											{
																												goto end_IL_089f;
																											}
																											goto IL_12ed;
																											IL_12ed:
																											float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_1307;
																											IL_1307:
																											num6--;
																											goto end_IL_08cf;
																											IL_131a:
																											if (22 < b)
																											{
																												goto end_IL_089f;
																											}
																											num = 13;
																											goto IL_1331;
																											IL_1392:
																											ptr2 += 8;
																											goto end_IL_08cf;
																											IL_1331:
																											if (22 > b)
																											{
																												goto end_IL_089f;
																											}
																											goto IL_133f;
																											IL_133f:
																											array[num6 - 1] = 3;
																											goto IL_1353;
																											continue;
																											end_IL_085f:
																											break;
																										}
																										continue;
																									}
																									goto IL_0a13;
																									IL_0d1a:
																									if (12 < b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0d28;
																									IL_0a13:
																									if (15 > b)
																									{
																										goto IL_0a21;
																									}
																									goto IL_0c84;
																									IL_0a21:
																									if (7 >= b)
																									{
																										num = 79;
																										goto IL_0a38;
																									}
																									goto IL_0b3a;
																									IL_0d28:
																									if (12 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto end_IL_08cf;
																									IL_0a38:
																									if (7 > b)
																									{
																										goto IL_0a51;
																									}
																									num = 291;
																									goto IL_0b69;
																									IL_0c84:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																									goto IL_0d3b;
																									IL_0b69:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0ba9;
																									IL_0ba9:
																									array[num6 - 2] = 0;
																									goto IL_0bbd;
																									IL_0bbd:
																									num6--;
																									goto end_IL_08cf;
																									IL_0a51:
																									if (3 >= b)
																									{
																										num = 277;
																										goto IL_0a68;
																									}
																									goto IL_0d62;
																									IL_0d3b:
																									array[num6 - 2] = 0;
																									goto IL_0d4f;
																									IL_0a68:
																									if (3 <= b)
																									{
																										goto IL_0a73;
																									}
																									goto IL_0abd;
																									IL_0a73:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0a9c;
																									IL_0a9c:
																									ptr2 += 8;
																									goto IL_0aaa;
																									IL_0aaa:
																									num6--;
																									goto end_IL_08cf;
																									IL_0abd:
																									if (1 >= b)
																									{
																										goto IL_0ac8;
																									}
																									goto IL_0b1e;
																									IL_0ac8:
																									if (1 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0ad6;
																									IL_0ad6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																									goto IL_0aef;
																									IL_0aef:
																									array[num6] = 0;
																									goto IL_0afd;
																									IL_0afd:
																									num6++;
																									goto IL_0b0b;
																									IL_0b0b:
																									ptr2 += 8;
																									goto end_IL_08cf;
																									IL_0b1e:
																									if (2 < b)
																									{
																										goto end_IL_089f;
																									}
																									num = 462;
																									goto IL_0bd0;
																									IL_0d4f:
																									num6--;
																									goto end_IL_08cf;
																									IL_0bd0:
																									if (2 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0bde;
																									IL_0bde:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0c1e;
																									IL_0c1e:
																									array[num6 - 2] = 0;
																									goto IL_0c32;
																									IL_0c32:
																									num6--;
																									goto end_IL_08cf;
																									IL_0d62:
																									if (5 >= b)
																									{
																										goto IL_0d70;
																									}
																									goto IL_0e39;
																									IL_0d70:
																									if (5 <= b)
																									{
																										goto IL_0d7b;
																									}
																									goto IL_0dd4;
																									IL_0d7b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0dbb;
																									IL_0dbb:
																									array[num6 - 2] = 0;
																									goto IL_140b;
																									IL_140b:
																									num6--;
																									goto end_IL_08cf;
																									IL_0dd4:
																									if (4 < b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0de2;
																									IL_0de2:
																									if (4 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0df0;
																									IL_0df0:
																									array[num6] = 0;
																									goto IL_0dfe;
																									IL_0dfe:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0e21;
																									IL_0e21:
																									array2[num6] = null;
																									num = 501;
																									goto IL_13ea;
																									IL_13ea:
																									num6++;
																									goto IL_13f8;
																									IL_13f8:
																									ptr2 += 8;
																									goto end_IL_08cf;
																									IL_0e39:
																									if (6 < b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0e47;
																									IL_0e47:
																									if (6 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0e55;
																									IL_0e55:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0e95;
																									IL_0e95:
																									array[num6 - 2] = 0;
																									goto IL_0ea9;
																									IL_0ea9:
																									num6--;
																									goto end_IL_08cf;
																									IL_0b3a:
																									if (11 >= b)
																									{
																										goto IL_0b48;
																									}
																									goto IL_0c45;
																									IL_0b48:
																									if (11 <= b)
																									{
																										goto IL_0b56;
																									}
																									goto IL_0ebc;
																									IL_0b56:
																									array[num6] = 0;
																									goto IL_13a5;
																									IL_13a5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])();
																									goto IL_13c9;
																									IL_13c9:
																									num6++;
																									goto IL_13d7;
																									IL_13d7:
																									ptr2 += 8;
																									goto end_IL_08cf;
																									IL_0ebc:
																									if (9 >= b)
																									{
																										goto IL_0eca;
																									}
																									goto IL_0f6b;
																									IL_0eca:
																									if (9 <= b)
																									{
																										goto IL_0ed5;
																									}
																									goto IL_0f3c;
																									IL_0ed5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0f15;
																									IL_0f15:
																									array[num6 - 2] = 0;
																									goto IL_0f29;
																									IL_0f29:
																									num6--;
																									goto end_IL_08cf;
																									IL_0f3c:
																									if (8 < b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0f4a;
																									IL_0f4a:
																									if (8 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0f58;
																									IL_0f58:
																									num6--;
																									goto end_IL_08cf;
																									IL_0f6b:
																									if (10 < b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0f79;
																									IL_0f79:
																									if (10 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0f87;
																									IL_0f87:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0fe9;
																									IL_0fe9:
																									num6 -= 2;
																									goto end_IL_08cf;
																									IL_0c45:
																									if (13 < b)
																									{
																										goto IL_0c50;
																									}
																									goto IL_0cc7;
																									IL_0c50:
																									if (14 < b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0c5e;
																									IL_0c5e:
																									if (14 > b)
																									{
																										goto end_IL_089f;
																									}
																									goto IL_0c6c;
																									IL_0c6c:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_08cf;
																									IL_0cc7:
																									if (13 <= b)
																									{
																										goto IL_0cd2;
																									}
																									goto IL_0d1a;
																									IL_0cd2:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0ceb;
																									IL_0ceb:
																									array[num6] = 1;
																									goto IL_0cf9;
																									IL_0cf9:
																									num6++;
																									goto IL_0d07;
																									IL_0d07:
																									ptr2 += 16;
																									goto end_IL_08cf;
																									continue;
																									end_IL_086f:
																									break;
																								}
																								continue;
																							}
																							goto IL_09c6;
																							IL_0a00:
																							ptr2 += 8;
																							goto end_IL_08cf;
																							IL_09c6:
																							array[num6] = 5;
																							goto IL_09d4;
																							IL_09d4:
																							array2[num6] = ((delegate*<GTPlayer>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])();
																							goto IL_09f2;
																							IL_09f2:
																							num6++;
																							goto IL_0a00;
																							continue;
																							end_IL_087f:
																							break;
																						}
																						continue;
																					}
																					goto IL_1665;
																					IL_2405:
																					if (53 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_2410;
																					IL_1665:
																					if (46 >= b)
																					{
																						goto IL_1673;
																					}
																					goto IL_1d72;
																					IL_1673:
																					if (46 <= b)
																					{
																						goto IL_167e;
																					}
																					goto IL_16e4;
																					IL_167e:
																					array[num6 - 1] = 3;
																					goto IL_1692;
																					IL_1692:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_16d1;
																					IL_16d1:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_16e4:
																					if (38 >= b)
																					{
																						goto IL_16f2;
																					}
																					goto IL_19c9;
																					IL_16f2:
																					if (38 > b)
																					{
																						goto IL_1700;
																					}
																					goto IL_196d;
																					IL_1700:
																					if (34 >= b)
																					{
																						goto IL_170e;
																					}
																					goto IL_184b;
																					IL_170e:
																					if (34 > b)
																					{
																						goto IL_171c;
																					}
																					goto IL_17dc;
																					IL_171c:
																					if (32 >= b)
																					{
																						goto IL_1727;
																					}
																					goto IL_1794;
																					IL_1727:
																					if (32 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1735;
																					IL_1735:
																					array[num6 - 1] = 5;
																					goto IL_1749;
																					IL_1749:
																					array2[num6 - 1] = ((delegate*<Component, Rigidbody>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((GTPlayer)array2[num6 - 1]);
																					goto IL_1781;
																					IL_1781:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1794:
																					if (33 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_17a2;
																					IL_17a2:
																					if (33 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_17b0;
																					IL_17b0:
																					global::_003CModule_003E.rigidbody_1 = (Rigidbody)array2[num6 - 1];
																					goto IL_17c9;
																					IL_17c9:
																					num6--;
																					goto end_IL_08cf;
																					IL_17dc:
																					array[num6 - 1] = 3;
																					num = 116;
																					goto IL_17f9;
																					IL_17f9:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1838;
																					IL_1838:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_184b:
																					if (36 >= b)
																					{
																						goto IL_1859;
																					}
																					goto IL_18ec;
																					IL_1859:
																					if (36 <= b)
																					{
																						goto IL_1864;
																					}
																					goto IL_18b4;
																					IL_1864:
																					array2[num6] = array5[*(int*)(ptr2 + num3)];
																					num = 135;
																					goto IL_1885;
																					IL_1885:
																					array[num6] = 5;
																					goto IL_1893;
																					IL_1893:
																					num6++;
																					goto IL_18a1;
																					IL_18a1:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_18b4:
																					if (35 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_18c2;
																					IL_18c2:
																					if (35 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_18d0;
																					IL_18d0:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_08cf;
																					IL_18ec:
																					if (37 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_18fa;
																					IL_18fa:
																					if (37 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1908;
																					IL_1908:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Class13, float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((Class13)array2[num6 - 1]);
																					goto IL_1946;
																					IL_1946:
																					array[num6 - 1] = 3;
																					goto IL_195a;
																					IL_195a:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_196d:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])();
																					num = 161;
																					goto IL_199a;
																					IL_199a:
																					array[num6] = 3;
																					goto IL_19a8;
																					IL_19a8:
																					num6++;
																					goto IL_19b6;
																					IL_19b6:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_19c9:
																					if (42 >= b)
																					{
																						goto IL_19d7;
																					}
																					goto IL_1be9;
																					IL_19d7:
																					if (42 > b)
																					{
																						goto IL_19e5;
																					}
																					goto IL_1ba8;
																					IL_19e5:
																					if (40 >= b)
																					{
																						goto IL_19f3;
																					}
																					goto IL_1b1d;
																					IL_19f3:
																					if (40 <= b)
																					{
																						num = 222;
																						goto IL_1a07;
																					}
																					goto IL_1a78;
																					IL_2410:
																					if (53 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_241b;
																					IL_1a07:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_1a65;
																					IL_1a65:
																					num6--;
																					goto end_IL_08cf;
																					IL_1a78:
																					if (39 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1a86;
																					IL_1a86:
																					if (39 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1a94;
																					IL_1a94:
																					array[num6 - 2] = 0;
																					goto IL_1aa8;
																					IL_1aa8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<float, float, bool>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]))) ? 1 : 0);
																					goto IL_1afc;
																					IL_1afc:
																					num6--;
																					goto IL_1b0a;
																					IL_1b0a:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1b1d:
																					if (41 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1b2b;
																					IL_1b2b:
																					if (41 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1b39;
																					IL_1b39:
																					array[num6 - 1] = 3;
																					goto IL_1b4d;
																					IL_1b4d:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 450;
																					goto IL_1b95;
																					IL_1b95:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1ba8:
																					((Class13)array2[num6 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1bd6;
																					IL_1bd6:
																					num6 -= 2;
																					goto end_IL_08cf;
																					IL_1be9:
																					if (44 >= b)
																					{
																						goto IL_1bf7;
																					}
																					goto IL_1cf0;
																					IL_1bf7:
																					if (44 > b)
																					{
																						goto IL_1c05;
																					}
																					goto IL_1c88;
																					IL_1c05:
																					if (43 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1c13;
																					IL_1c13:
																					if (43 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1c21;
																					IL_1c21:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_1c61;
																					IL_1c61:
																					array[num6 - 2] = 3;
																					goto IL_1c75;
																					IL_1c75:
																					num6--;
																					goto end_IL_08cf;
																					IL_1c88:
																					((delegate*<Rigidbody, bool, void>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																					num = 319;
																					goto IL_1ccf;
																					IL_1ccf:
																					num6 -= 2;
																					goto IL_1cdd;
																					IL_1cdd:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1cf0:
																					if (45 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1cfe;
																					IL_1cfe:
																					if (45 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1d0c;
																					IL_1d0c:
																					array[num6 - 1] = 3;
																					goto IL_1d20;
																					IL_1d20:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1d5f;
																					IL_1d5f:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1d72:
																					if (54 < b)
																					{
																						goto IL_1d80;
																					}
																					num = 68;
																					goto IL_206b;
																					IL_1d80:
																					if (58 >= b)
																					{
																						goto IL_1d8e;
																					}
																					goto IL_1f67;
																					IL_1d8e:
																					if (58 <= b)
																					{
																						goto IL_1d99;
																					}
																					goto IL_1dff;
																					IL_1d99:
																					array[num6 - 1] = 3;
																					goto IL_1dad;
																					IL_1dad:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<float, float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																					goto IL_1dec;
																					IL_1dec:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1dff:
																					if (56 >= b)
																					{
																						goto IL_1e0d;
																					}
																					goto IL_1ee4;
																					IL_1e0d:
																					if (56 <= b)
																					{
																						goto IL_1e1b;
																					}
																					goto IL_1e9d;
																					IL_1e1b:
																					array[num6 - 2] = 0;
																					goto IL_1e2f;
																					IL_1e2f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])((GTPlayer)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																					goto IL_1e7c;
																					IL_1e7c:
																					num6--;
																					goto IL_1e8a;
																					IL_1e8a:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1e9d:
																					if (55 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1eab;
																					IL_1eab:
																					if (55 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1eb9;
																					IL_1eb9:
																					array2[num6] = null;
																					goto IL_1ec3;
																					IL_1ec3:
																					array[num6] = 5;
																					goto IL_1ed1;
																					IL_1ed1:
																					num6++;
																					goto end_IL_08cf;
																					IL_1ee4:
																					if (57 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1ef2;
																					IL_1ef2:
																					if (57 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1f00;
																					IL_1f00:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_1f40;
																					IL_1f40:
																					array[num6 - 2] = 3;
																					goto IL_1f54;
																					IL_1f54:
																					num6--;
																					goto end_IL_08cf;
																					IL_1f67:
																					if (60 >= b)
																					{
																						goto IL_1f75;
																					}
																					goto IL_2041;
																					IL_1f75:
																					if (60 <= b)
																					{
																						goto IL_1f80;
																					}
																					goto IL_1fef;
																					IL_1f80:
																					array[num6 - 1] = 3;
																					goto IL_1f94;
																					IL_1f94:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 185;
																					goto IL_1fdc;
																					IL_1fdc:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_1fef:
																					if (59 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_1ffd;
																					IL_1ffd:
																					if (59 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_200b;
																					IL_200b:
																					global::_003CModule_003E.float_36 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 67;
																					goto IL_202e;
																					IL_202e:
																					num6--;
																					goto end_IL_08cf;
																					IL_2041:
																					if (61 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_204f;
																					IL_204f:
																					if (61 > b)
																					{
																					}
																					goto end_IL_089f;
																					IL_241b:
																					global::_003CModule_003E.float_37 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_2435;
																					IL_206b:
																					if (54 <= b)
																					{
																						goto IL_2076;
																					}
																					goto IL_20dc;
																					IL_2076:
																					array[num6 - 1] = 3;
																					goto IL_208a;
																					IL_208a:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_20c9;
																					IL_20c9:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_20dc:
																					if (50 >= b)
																					{
																						goto IL_20ea;
																					}
																					goto IL_2307;
																					IL_20ea:
																					if (50 > b)
																					{
																						goto IL_20f8;
																					}
																					goto IL_2298;
																					IL_20f8:
																					if (48 < b)
																					{
																						goto IL_2106;
																					}
																					num = 372;
																					goto IL_2191;
																					IL_2106:
																					if (49 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_2114;
																					IL_2114:
																					if (49 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_2122;
																					IL_2122:
																					array[num6 - 1] = 3;
																					goto IL_2136;
																					IL_2136:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<XRNode, float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(XRNode*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_2175;
																					IL_2175:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_2435:
																					num6--;
																					goto end_IL_08cf;
																					IL_2191:
																					if (48 <= b)
																					{
																						goto IL_219f;
																					}
																					goto IL_2220;
																					IL_219f:
																					ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_220d;
																					IL_220d:
																					num6 -= 2;
																					goto end_IL_08cf;
																					IL_2220:
																					if (47 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_222e;
																					IL_222e:
																					if (47 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_223c;
																					IL_223c:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])();
																					goto IL_2260;
																					IL_2260:
																					array[num6] = 3;
																					goto IL_226e;
																					IL_226e:
																					num6++;
																					num = 297;
																					goto IL_2285;
																					IL_2285:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_2298:
																					array[num6 - 1] = 3;
																					goto IL_22ac;
																					IL_22ac:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 171;
																					goto IL_22f4;
																					IL_22f4:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_2307:
																					if (52 >= b)
																					{
																						goto IL_2315;
																					}
																					goto IL_2405;
																					IL_2315:
																					if (52 <= b)
																					{
																						goto IL_2320;
																					}
																					goto IL_2386;
																					IL_2320:
																					array[num6 - 1] = 3;
																					goto IL_2334;
																					IL_2334:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<XRNode, float>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(XRNode*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_2373;
																					IL_2373:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					IL_2386:
																					if (51 < b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_2394;
																					IL_2394:
																					if (51 > b)
																					{
																						goto end_IL_089f;
																					}
																					goto IL_23a2;
																					IL_23a2:
																					array[num6 - 1] = 0;
																					goto IL_23b6;
																					IL_23b6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)RemotingExceptionComEventsSink[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_23f5;
																					IL_23f5:
																					ptr2 += 8;
																					goto end_IL_08cf;
																					continue;
																					end_IL_088f:
																					break;
																				}
																				continue;
																				end_IL_089f:
																				break;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 63;
																		goto end_IL_08cf;
																		continue;
																		end_IL_08af:
																		break;
																	}
																	continue;
																	end_IL_08bf:
																	break;
																}
																continue;
																end_IL_08cf:
																break;
															}
															continue;
															end_IL_2461:
															break;
														}
														continue;
														end_IL_2474:
														break;
													}
													continue;
													end_IL_247e:
													break;
												}
												continue;
												end_IL_2492:
												break;
											}
											continue;
											end_IL_24a2:
											break;
										}
										continue;
										end_IL_24b2:
										break;
									}
									continue;
									end_IL_24c2:
									break;
								}
								continue;
								end_IL_24d2:
								break;
							}
							continue;
							end_IL_24dd:
							break;
						}
						continue;
						end_IL_24ed:
						break;
					}
					continue;
					end_IL_24fd:
					break;
				}
				continue;
				end_IL_250d:
				break;
			}
		}
	}

	private void OnDisable()
	{
		try
		{
			int num = 13;
			num = 473;
			num = 43;
			num = 13;
			num = 38;
			num = 47;
			num = 47;
			num = 594;
			num = 54;
			num = 60;
			num = 20;
			num = 54;
			num = 74;
			num = 1138;
			num = 1138;
			num = 1185;
			num = 1474;
			num = 134;
			GTPlayer instance = GTPlayer.Instance;
			object obj = instance;
			Rigidbody component = ((GTPlayer)obj).GetComponent<Rigidbody>();
			obj = component;
			object obj2 = obj;
			obj = obj2;
			object obj3 = null;
			if ((Rigidbody)obj != (UnityEngine.Object)obj3)
			{
				obj = obj2;
				((Rigidbody)obj).useGravity = true;
			}
		}
		catch
		{
		}
		Class10.smethod_6();
	}

	private void method_0()
	{
		int num = 168;
		num = 24;
		num = 88;
		num = 44;
		num = 24;
		num = 52;
		num = 60;
		num = 60;
		num = 66;
		num = 33;
		num = 252;
		num = 36;
		num = 33;
		num = 69;
		num = 1249;
		num = 1249;
		num = 1309;
		num = 1584;
		num = 144;
		try
		{
			GTPlayer instance = GTPlayer.Instance;
			object obj = instance;
			Rigidbody component = ((GTPlayer)obj).GetComponent<Rigidbody>();
			obj = component;
			global::_003CModule_003E.rigidbody_2 = (Rigidbody)obj;
			obj = global::_003CModule_003E.rigidbody_2;
			object obj2 = null;
			if ((Rigidbody)obj != (UnityEngine.Object)obj2)
			{
				obj = global::_003CModule_003E.rigidbody_2;
				((Rigidbody)obj).useGravity = true;
			}
		}
		catch
		{
		}
	}

	public Class13()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class13()
	{
		int num = 135;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 115;
				while (true)
				{
					num = 22;
					while (true)
					{
						int num2 = 1;
						while (true)
						{
							int num3 = num2 * 4;
							num = 96;
							while (true)
							{
								byte[] array = new byte[3];
								while (true)
								{
									object[] array2 = new object[3];
									while (true)
									{
										int[] array3 = new int[3];
										while (true)
										{
											long[] array4 = new long[3];
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetHashFromAssemblyFileFinalStringMapped.AnySchemegetCurrentInfo);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02e6:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			num = 124;
																			while (true)
																			{
																				IL_02c6:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02b9:
																						if (12 < b)
																						{
																							while (true)
																							{
																								IL_02a9:
																								if (14 >= b)
																								{
																									while (true)
																									{
																										IL_0299:
																										if (14 > b)
																										{
																											while (13 >= b)
																											{
																												while (13 <= b)
																												{
																													num = 142;
																													while (true)
																													{
																														if (num != 142)
																														{
																															if (num != 1123)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 10:
																																goto IL_0276;
																															case 7:
																																goto IL_0289;
																															case 122:
																																goto IL_0299;
																															case 72:
																																goto IL_02a9;
																															case 117:
																																goto IL_02b9;
																															case 124:
																																goto IL_02c6;
																															case 49:
																																goto IL_02d3;
																															case 30:
																																goto IL_02e6;
																															case 34:
																																goto end_IL_02e6;
																															case 21:
																															case 113:
																																goto end_IL_02f6;
																															case 47:
																																goto IL_0311;
																															case 32:
																															case 59:
																																goto IL_031f;
																															case 83:
																																goto IL_0343;
																															case 94:
																																goto IL_0353;
																															case 86:
																															case 98:
																																goto IL_0366;
																															case 41:
																																goto IL_037f;
																															case 81:
																															case 121:
																																goto IL_0392;
																															case 33:
																																goto IL_03a5;
																															case 12:
																																goto IL_03b3;
																															case 130:
																																goto IL_03c6;
																															case 68:
																																goto IL_03d4;
																															case 73:
																																goto IL_03e2;
																															case 105:
																																goto IL_03ed;
																															case 24:
																																goto IL_03f8;
																															case 40:
																																goto IL_0406;
																															case 36:
																															case 119:
																																goto IL_0419;
																															case 20:
																																goto IL_042e;
																															case 120:
																																goto IL_0441;
																															case 99:
																																goto IL_044f;
																															case 69:
																															case 127:
																																goto IL_045d;
																															case 15:
																																goto IL_0472;
																															case 65:
																															case 123:
																																goto IL_0485;
																															case 125:
																																goto IL_04a3;
																															case 74:
																																goto IL_04b6;
																															case 102:
																																goto IL_04c4;
																															case 16:
																															case 37:
																																goto end_IL_0263;
																															case 82:
																																goto IL_04e9;
																															case 44:
																																goto IL_04f7;
																															case 109:
																																goto IL_0505;
																															case 6:
																																goto IL_0521;
																															case 93:
																																goto IL_052f;
																															case 17:
																															case 111:
																																goto IL_053d;
																															case 75:
																																goto IL_0552;
																															case 67:
																																goto IL_0565;
																															case 97:
																																goto IL_0573;
																															case 43:
																															case 54:
																																goto IL_0581;
																															case 9:
																																goto IL_059b;
																															case 131:
																																goto IL_05ae;
																															case 58:
																																goto IL_05bc;
																															case 132:
																																goto IL_05d8;
																															case 23:
																																goto IL_05e6;
																															case 11:
																																goto IL_05f4;
																															case 87:
																																goto IL_0602;
																															case 51:
																															case 76:
																																goto IL_0610;
																															case 126:
																																goto IL_0650;
																															case 70:
																																goto IL_0664;
																															case 64:
																															case 100:
																																goto IL_0677;
																															case 88:
																																goto IL_06a0;
																															case 89:
																																goto IL_06b9;
																															case 90:
																																goto IL_06c7;
																															case 80:
																															case 103:
																																goto IL_06d5;
																															case 31:
																																goto IL_06ed;
																															case 46:
																																goto IL_070b;
																															case 26:
																																goto IL_072f;
																															case 25:
																																goto IL_0747;
																															case 53:
																																goto IL_075a;
																															case 106:
																																goto IL_0797;
																															case 1:
																																goto IL_07a5;
																															case 63:
																																goto IL_07b5;
																															case 101:
																																goto IL_07c0;
																															case 2:
																															case 55:
																																goto IL_07cb;
																															case 0:
																															case 8:
																															case 18:
																															case 27:
																															case 39:
																															case 42:
																															case 56:
																															case 60:
																															case 62:
																															case 66:
																															case 78:
																															case 85:
																															case 92:
																															case 110:
																															case 114:
																															case 128:
																															case 129:
																															case 133:
																																goto end_IL_0276;
																															case 57:
																																goto IL_0802;
																															case 3:
																															case 4:
																															case 5:
																															case 13:
																															case 14:
																															case 28:
																															case 35:
																															case 45:
																															case 61:
																															case 77:
																															case 79:
																															case 84:
																															case 91:
																															case 95:
																															case 112:
																															case 116:
																															case 118:
																																goto end_IL_0306;
																															case 52:
																																goto end_IL_0810;
																															case 19:
																																goto end_IL_0823;
																															case 38:
																																goto end_IL_082d;
																															case 48:
																																goto end_IL_0838;
																															case 107:
																																goto end_IL_0848;
																															case 96:
																															case 104:
																																goto end_IL_0858;
																															case 71:
																																goto end_IL_0868;
																															case 22:
																															case 50:
																																goto end_IL_0878;
																															case 115:
																																goto end_IL_0891;
																															case 134:
																																goto end_IL_089f;
																															case 135:
																																goto end_IL_08ab;
																															case 29:
																															case 108:
																																return;
																															}
																															continue;
																														}
																														goto IL_075a;
																														IL_0797:
																														num5 -= 2;
																														goto IL_07a5;
																														IL_07a5:
																														ptr2 += 8;
																														goto end_IL_0306;
																														IL_075a:
																														((delegate*<Array, RuntimeFieldHandle, void>)PropertyAnalysisWinWindows[*(int*)(ptr2 + num3)])((float[])array2[num5 - 2], (RuntimeFieldHandle)array2[num5 - 1]);
																														goto IL_0797;
																														continue;
																														end_IL_0263:
																														break;
																													}
																													goto IL_04cf;
																													continue;
																													end_IL_0276:
																													break;
																													IL_0276:;
																												}
																												break;
																												IL_0289:;
																											}
																											break;
																										}
																										goto IL_0366;
																										IL_037f:
																										num5--;
																										goto end_IL_0306;
																										IL_0366:
																										float_2 = (float[])array2[num5 - 1];
																										goto IL_037f;
																									}
																									break;
																								}
																								goto IL_07b5;
																								IL_07cb:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_0306;
																								IL_07b5:
																								if (15 < b)
																								{
																									break;
																								}
																								goto IL_07c0;
																								IL_07c0:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_07cb;
																							}
																							break;
																						}
																						goto IL_0343;
																						IL_0747:
																						num5++;
																						goto end_IL_0306;
																						IL_0343:
																						if (12 <= b)
																						{
																							goto IL_0392;
																						}
																						goto IL_05d8;
																						IL_0392:
																						array2[num5] = default(RuntimeFieldHandle);
																						goto IL_03a5;
																						IL_03a5:
																						array[num5] = 4;
																						goto IL_03b3;
																						IL_03b3:
																						num5++;
																						goto end_IL_0306;
																						IL_05d8:
																						if (10 >= b)
																						{
																							goto IL_05e6;
																						}
																						goto IL_06b9;
																						IL_05e6:
																						if (10 > b)
																						{
																							goto IL_05f4;
																						}
																						goto IL_0677;
																						IL_05f4:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0602;
																						IL_0602:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0610;
																						IL_0610:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0650;
																						IL_0650:
																						array[num5 - 2] = 0;
																						goto IL_0664;
																						IL_0664:
																						num5--;
																						goto end_IL_0306;
																						IL_0677:
																						array2[num5 - 1] = new float[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_06a0;
																						IL_06a0:
																						array[num5 - 1] = 5;
																						goto end_IL_0306;
																						IL_06b9:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_06c7;
																						IL_06c7:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_06d5;
																						IL_06d5:
																						array[num5] = array[num5 - 1];
																						goto IL_06ed;
																						IL_06ed:
																						array3[num5 - 0] = array3[num5 - 1];
																						goto IL_070b;
																						IL_070b:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_072f;
																						IL_072f:
																						array2[num5] = array2[num5 - 1];
																						goto IL_0747;
																					}
																					break;
																				}
																				goto IL_0311;
																				IL_059b:
																				num5--;
																				goto end_IL_0306;
																				IL_0311:
																				if (8 <= b)
																				{
																					goto IL_031f;
																				}
																				goto IL_03c6;
																				IL_031f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 94;
																				goto IL_0353;
																				IL_0353:
																				array[num5] = 0;
																				goto IL_05ae;
																				IL_05ae:
																				num5++;
																				goto IL_05bc;
																				IL_05bc:
																				ptr2 += 8;
																				num = 79;
																				goto end_IL_0306;
																				IL_03c6:
																				if (4 >= b)
																				{
																					goto IL_03d4;
																				}
																				goto IL_04b6;
																				IL_03d4:
																				if (4 > b)
																				{
																					goto IL_03e2;
																				}
																				goto IL_0485;
																				IL_03e2:
																				if (2 >= b)
																				{
																					goto IL_03ed;
																				}
																				goto IL_0441;
																				IL_03ed:
																				if (2 > b)
																				{
																					goto IL_03f8;
																				}
																				goto IL_0419;
																				IL_03f8:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0406;
																				IL_0406:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0419:
																				((delegate*<void>)PropertyAnalysisWinWindows[*(int*)(ptr2 + num3)])();
																				goto IL_042e;
																				IL_042e:
																				ptr2 += 8;
																				goto end_IL_0306;
																				IL_0441:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_044f;
																				IL_044f:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_045d;
																				IL_045d:
																				((delegate*<void>)PropertyAnalysisWinWindows[*(int*)(ptr2 + num3)])();
																				goto IL_0472;
																				IL_0472:
																				ptr2 += 8;
																				goto end_IL_0306;
																				IL_0485:
																				((delegate*<void>)PropertyAnalysisWinWindows[*(int*)(ptr2 + num3)])();
																				num = 125;
																				goto IL_04a3;
																				IL_04a3:
																				ptr2 += 8;
																				goto end_IL_0306;
																				IL_04b6:
																				if (6 >= b)
																				{
																					goto IL_04c4;
																				}
																				goto IL_0565;
																				IL_04c4:
																				if (6 <= b)
																				{
																					goto IL_04cf;
																				}
																				goto IL_0521;
																				IL_04cf:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																				goto IL_04e9;
																				IL_04e9:
																				array[num5] = 3;
																				goto IL_04f7;
																				IL_04f7:
																				num5++;
																				goto IL_0505;
																				IL_0505:
																				ptr2 += 8;
																				num = 45;
																				goto end_IL_0306;
																				IL_0521:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_052f;
																				IL_052f:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_053d;
																				IL_053d:
																				((delegate*<void>)PropertyAnalysisWinWindows[*(int*)(ptr2 + num3)])();
																				goto IL_0552;
																				IL_0552:
																				ptr2 += 8;
																				goto end_IL_0306;
																				IL_0565:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0573;
																				IL_0573:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0581;
																				IL_0581:
																				float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_059b;
																			}
																			break;
																			IL_02d3:;
																		}
																	}
																	((delegate*<void>)PropertyAnalysisWinWindows[*(int*)(ptr2 + num3)])();
																	num = 57;
																	goto IL_0802;
																	IL_0802:
																	ptr2 += 8;
																	goto end_IL_0306;
																	continue;
																	end_IL_02e6:
																	break;
																}
																continue;
																end_IL_02f6:
																break;
															}
															continue;
															end_IL_0306:
															break;
														}
														continue;
														end_IL_0810:
														break;
													}
													continue;
													end_IL_0823:
													break;
												}
												continue;
												end_IL_082d:
												break;
											}
											continue;
											end_IL_0838:
											break;
										}
										continue;
										end_IL_0848:
										break;
									}
									continue;
									end_IL_0858:
									break;
								}
								continue;
								end_IL_0868:
								break;
							}
							continue;
							end_IL_0878:
							break;
						}
						continue;
						end_IL_0891:
						break;
					}
					continue;
					end_IL_089f:
					break;
				}
				continue;
				end_IL_08ab:
				break;
			}
		}
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IClientChannelSinkStackTryGet.IEqualityComparerCalendarId);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 40;
																while (true)
																{
																	IL_029d:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0280:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_026d:
																						if (6 > b)
																						{
																							num = 11;
																							while (true)
																							{
																								IL_025a:
																								if (3 < b)
																								{
																									num = 135;
																									while (true)
																									{
																										if (num != 135)
																										{
																											if (num != 1116)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 11:
																											case 18:
																												goto IL_025a;
																											case 106:
																												goto IL_026d;
																											case 101:
																												goto IL_0280;
																											case 50:
																												goto end_IL_0280;
																											case 40:
																												goto IL_029d;
																											case 80:
																												goto end_IL_029d;
																											case 22:
																											case 118:
																												goto end_IL_02ad;
																											case 47:
																											case 119:
																												goto IL_02d1;
																											case 39:
																											case 93:
																												goto IL_02dc;
																											case 52:
																											case 83:
																												goto IL_02e7;
																											case 78:
																												goto IL_02f5;
																											case 70:
																											case 88:
																												goto IL_0303;
																											case 36:
																												goto IL_031f;
																											case 77:
																											case 102:
																												goto IL_032d;
																											case 34:
																												goto IL_0340;
																											case 12:
																											case 115:
																												goto IL_034b;
																											case 107:
																												goto IL_0356;
																											case 4:
																											case 67:
																												goto IL_0364;
																											case 55:
																												goto IL_037d;
																											case 46:
																												goto IL_0399;
																											case 114:
																											case 120:
																												goto IL_03ac;
																											case 19:
																												goto IL_03c0;
																											case 64:
																												goto IL_0414;
																											case 73:
																												goto IL_0422;
																											case 126:
																												goto IL_0435;
																											case 38:
																											case 49:
																												goto IL_0443;
																											case 29:
																												goto end_IL_0247;
																											case 84:
																												goto IL_0497;
																											case 127:
																												goto IL_04b3;
																											case 58:
																												goto IL_04c1;
																											case 14:
																												goto IL_04d4;
																											case 6:
																											case 21:
																												goto IL_04df;
																											case 2:
																												goto IL_04ed;
																											case 60:
																											case 122:
																												goto IL_04fb;
																											case 125:
																												goto IL_0509;
																											case 124:
																												goto IL_052c;
																											case 90:
																												goto IL_0536;
																											case 33:
																												goto IL_0544;
																											case 82:
																												goto IL_0557;
																											case 24:
																											case 91:
																												goto IL_0565;
																											case 92:
																												goto IL_05ae;
																											case 113:
																												goto IL_05cb;
																											case 26:
																												goto IL_05e7;
																											case 41:
																											case 111:
																												goto IL_05f5;
																											case 30:
																											case 65:
																												goto IL_0603;
																											case 109:
																												goto IL_060e;
																											case 5:
																											case 15:
																												goto IL_0619;
																											case 8:
																												goto IL_0659;
																											case 20:
																												goto IL_066d;
																											case 94:
																												goto IL_068b;
																											case 0:
																											case 3:
																											case 9:
																											case 10:
																											case 25:
																											case 31:
																											case 42:
																											case 43:
																											case 44:
																											case 45:
																											case 48:
																											case 53:
																											case 66:
																											case 85:
																											case 86:
																											case 87:
																											case 95:
																											case 97:
																											case 99:
																											case 100:
																											case 105:
																											case 110:
																											case 121:
																											case 128:
																												goto end_IL_028d;
																											case 37:
																												goto IL_06b9;
																											case 117:
																												goto IL_06c7;
																											case 123:
																												goto IL_06d5;
																											case 7:
																											case 17:
																												goto IL_06e8;
																											case 116:
																												goto IL_0711;
																											case 51:
																												goto IL_071f;
																											case 27:
																											case 89:
																												goto IL_072f;
																											case 61:
																												goto IL_076f;
																											case 108:
																												goto IL_0783;
																											case 16:
																											case 23:
																											case 32:
																											case 35:
																											case 56:
																											case 57:
																											case 59:
																											case 72:
																											case 74:
																											case 79:
																											case 96:
																											case 103:
																											case 104:
																												goto end_IL_02c6;
																											case 98:
																												goto end_IL_079a;
																											case 76:
																												goto end_IL_07ad;
																											case 54:
																												goto end_IL_07b7;
																											case 75:
																												goto end_IL_07c2;
																											case 1:
																												goto end_IL_07d7;
																											case 68:
																											case 112:
																												goto end_IL_07ec;
																											case 71:
																												goto end_IL_07fc;
																											case 28:
																											case 81:
																												goto end_IL_080c;
																											case 62:
																												goto end_IL_081c;
																											case 63:
																												goto end_IL_082c;
																											case 13:
																											case 69:
																												goto IL_0847;
																											}
																											continue;
																										}
																										goto IL_04d4;
																										IL_05ae:
																										array[num5 - 2] = 0;
																										num = 113;
																										goto IL_05cb;
																										IL_05cb:
																										num5--;
																										num = 23;
																										goto end_IL_02c6;
																										IL_04d4:
																										if (4 < b)
																										{
																											goto IL_04df;
																										}
																										goto IL_0557;
																										IL_04df:
																										if (5 < b)
																										{
																											goto end_IL_028d;
																										}
																										goto IL_04ed;
																										IL_04ed:
																										if (5 > b)
																										{
																											goto end_IL_028d;
																										}
																										goto IL_04fb;
																										IL_04fb:
																										array[num5] = 0;
																										goto IL_0509;
																										IL_0509:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_052c;
																										IL_052c:
																										array2[num5] = null;
																										goto IL_0536;
																										IL_0536:
																										num5++;
																										goto IL_0544;
																										IL_0544:
																										ptr2 += 8;
																										goto end_IL_02c6;
																										IL_0557:
																										if (4 > b)
																										{
																											goto end_IL_028d;
																										}
																										goto IL_0565;
																										IL_0565:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 92;
																										goto IL_05ae;
																										continue;
																										end_IL_0247:
																										break;
																									}
																									break;
																								}
																								goto IL_05e7;
																								IL_06e8:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0711;
																								IL_0711:
																								ptr2 += 8;
																								goto IL_071f;
																								IL_05e7:
																								if (3 > b)
																								{
																									goto IL_05f5;
																								}
																								goto IL_06e8;
																								IL_05f5:
																								if (1 < b)
																								{
																									goto IL_0603;
																								}
																								goto IL_068b;
																								IL_0603:
																								if (2 < b)
																								{
																									num = 85;
																									goto end_IL_028d;
																								}
																								goto IL_060e;
																								IL_060e:
																								if (2 > b)
																								{
																									goto end_IL_028d;
																								}
																								goto IL_0619;
																								IL_0619:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0659;
																								IL_0659:
																								array[num5 - 2] = 0;
																								goto IL_066d;
																								IL_066d:
																								num5--;
																								goto end_IL_02c6;
																								IL_071f:
																								num5--;
																								goto end_IL_02c6;
																								IL_068b:
																								if (1 > b)
																								{
																								}
																								goto end_IL_028d;
																							}
																							break;
																						}
																						goto IL_072f;
																						IL_076f:
																						array[num5 - 2] = 0;
																						goto IL_0783;
																						IL_0783:
																						num5--;
																						num = 16;
																						goto end_IL_02c6;
																						IL_072f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_076f;
																					}
																					goto IL_0483;
																				}
																				goto IL_02d1;
																				IL_0422:
																				ptr2 += 8;
																				goto end_IL_02c6;
																				IL_02d1:
																				if (9 < b)
																				{
																					goto IL_02dc;
																				}
																				goto IL_0340;
																				IL_02dc:
																				if (10 < b)
																				{
																					goto IL_02e7;
																				}
																				goto IL_031f;
																				IL_02e7:
																				if (11 < b)
																				{
																					goto end_IL_028d;
																				}
																				goto IL_02f5;
																				IL_02f5:
																				if (11 > b)
																				{
																					goto end_IL_028d;
																				}
																				goto IL_0303;
																				IL_0303:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02c6;
																				IL_031f:
																				if (10 > b)
																				{
																					goto end_IL_028d;
																				}
																				goto IL_032d;
																				IL_032d:
																				num5--;
																				goto end_IL_02c6;
																				IL_0340:
																				if (9 > b)
																				{
																					goto IL_034b;
																				}
																				goto IL_03ac;
																				IL_034b:
																				if (7 >= b)
																				{
																					goto IL_0356;
																				}
																				goto IL_0399;
																				IL_0356:
																				if (7 > b)
																				{
																					goto end_IL_028d;
																				}
																				goto IL_0364;
																				IL_0364:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_037d;
																				IL_037d:
																				array[num5] = 0;
																				num = 127;
																				goto IL_04b3;
																				IL_04b3:
																				num5++;
																				goto IL_04c1;
																				IL_04c1:
																				ptr2 += 8;
																				goto end_IL_02c6;
																				IL_0399:
																				if (8 < b)
																				{
																					goto end_IL_028d;
																				}
																				goto IL_0435;
																				IL_0435:
																				if (8 > b)
																				{
																					goto end_IL_028d;
																				}
																				goto IL_0443;
																				IL_0443:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0483;
																				IL_0483:
																				array[num5 - 2] = 0;
																				goto IL_0497;
																				IL_0497:
																				num5--;
																				num = 74;
																				goto end_IL_02c6;
																				IL_03ac:
																				array[num5 - 2] = 0;
																				goto IL_03c0;
																				IL_03c0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)MajorsetTag[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0414;
																				IL_0414:
																				num5--;
																				goto IL_0422;
																				continue;
																				end_IL_0280:
																				break;
																			}
																			continue;
																			end_IL_028d:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06b9;
																	IL_06d5:
																	ptr2 += 8;
																	goto end_IL_02c6;
																	IL_06c7:
																	num5++;
																	goto IL_06d5;
																	IL_06b9:
																	array[num5] = 0;
																	goto IL_06c7;
																	continue;
																	end_IL_029d:
																	break;
																}
																continue;
																end_IL_02ad:
																break;
															}
															continue;
															end_IL_02c6:
															break;
														}
														continue;
													}
													goto IL_0847;
													IL_0847:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_079a:
													break;
												}
												continue;
												end_IL_07ad:
												break;
											}
											continue;
											end_IL_07b7:
											break;
										}
										continue;
										end_IL_07c2:
										break;
									}
									continue;
									end_IL_07d7:
									break;
								}
								continue;
								end_IL_07ec:
								break;
							}
							continue;
							end_IL_07fc:
							break;
						}
						continue;
						end_IL_080c:
						break;
					}
					continue;
					end_IL_081c:
					break;
				}
				continue;
				end_IL_082c:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1, int int_2)
	{
		int num = 26;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 20;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ISectionWithReferenceIdentityKeyDefaultNameClaimType.isectionWithReferenceIdentityKeyDefaultNameClaimType_0);
											num = 103;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0229:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 < b)
																				{
																					while (true)
																					{
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_01ec:
																								if (7 <= b)
																								{
																									num = 111;
																									while (true)
																									{
																										if (num != 111)
																										{
																											if (num != 1092)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 65:
																												goto IL_01ec;
																											case 36:
																												goto end_IL_01d9;
																											case 16:
																												goto end_IL_01fc;
																											case 35:
																												goto end_IL_020c;
																											case 77:
																												goto IL_0229;
																											case 83:
																												goto end_IL_0229;
																											case 48:
																											case 100:
																												goto end_IL_0239;
																											case 53:
																												goto IL_0254;
																											case 13:
																												goto IL_0262;
																											case 69:
																												goto IL_0272;
																											case 46:
																											case 75:
																												goto IL_0282;
																											case 47:
																												goto IL_02c2;
																											case 63:
																												goto IL_02d6;
																											case 50:
																											case 82:
																												goto IL_02e9;
																											case 9:
																												goto IL_02f7;
																											case 94:
																												goto IL_031a;
																											case 52:
																												goto IL_0324;
																											case 3:
																												goto IL_0332;
																											case 51:
																											case 96:
																												goto IL_0345;
																											case 2:
																												goto IL_0350;
																											case 84:
																												goto IL_035e;
																											case 95:
																												goto IL_036c;
																											case 71:
																											case 97:
																												goto IL_037f;
																											case 30:
																											case 87:
																												goto IL_038a;
																											case 72:
																												goto IL_0398;
																											case 78:
																												goto IL_03ab;
																											case 22:
																											case 88:
																												goto IL_03b9;
																											case 10:
																												goto IL_03e2;
																											case 92:
																												goto IL_03f0;
																											case 6:
																											case 99:
																												goto IL_0403;
																											case 90:
																												goto IL_0443;
																											case 56:
																												goto IL_0457;
																											case 17:
																											case 102:
																												goto IL_046a;
																											case 1:
																												goto IL_04aa;
																											case 0:
																												goto IL_04be;
																											case 44:
																												goto IL_04d1;
																											case 19:
																												goto IL_04ea;
																											case 12:
																												goto IL_04f8;
																											case 41:
																												goto IL_0506;
																											case 34:
																												goto IL_0519;
																											case 45:
																												goto IL_0524;
																											case 76:
																												goto IL_0532;
																											case 8:
																											case 101:
																												goto IL_0540;
																											case 86:
																												goto IL_055c;
																											case 59:
																											case 89:
																												goto IL_0567;
																											case 24:
																												goto IL_05a7;
																											case 38:
																												goto IL_05bb;
																											case 4:
																											case 7:
																											case 11:
																											case 18:
																											case 27:
																											case 28:
																											case 31:
																											case 39:
																											case 43:
																											case 64:
																											case 67:
																											case 68:
																											case 70:
																											case 74:
																											case 80:
																											case 85:
																											case 93:
																											case 98:
																											case 104:
																												goto end_IL_0219;
																											case 21:
																												goto IL_05ee;
																											case 14:
																												goto IL_05fc;
																											case 79:
																												goto IL_060a;
																											case 5:
																											case 32:
																											case 37:
																											case 42:
																											case 49:
																											case 55:
																											case 57:
																											case 58:
																											case 61:
																											case 62:
																											case 91:
																												goto end_IL_0249;
																											case 103:
																												goto end_IL_0618;
																											case 54:
																												goto end_IL_062b;
																											case 60:
																												goto end_IL_0635;
																											case 20:
																												goto end_IL_0649;
																											case 73:
																												goto end_IL_065e;
																											case 23:
																											case 81:
																												goto end_IL_0673;
																											case 40:
																												goto end_IL_068c;
																											case 29:
																											case 66:
																												goto end_IL_069c;
																											case 25:
																												goto end_IL_06ac;
																											case 26:
																												goto end_IL_06bc;
																											case 15:
																											case 33:
																												goto IL_06d7;
																											}
																											continue;
																										}
																										goto IL_04d1;
																										IL_04f8:
																										num5++;
																										goto IL_0506;
																										IL_0506:
																										ptr2 += 8;
																										goto end_IL_0249;
																										IL_04d1:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_04ea;
																										IL_04ea:
																										array[num5] = 0;
																										goto IL_04f8;
																										continue;
																										end_IL_01d9:
																										break;
																									}
																									break;
																								}
																								goto IL_0254;
																								IL_02c2:
																								array[num5 - 2] = 0;
																								goto IL_02d6;
																								IL_02d6:
																								num5--;
																								goto end_IL_0249;
																								IL_0254:
																								if (6 < b)
																								{
																									goto end_IL_0219;
																								}
																								goto IL_0262;
																								IL_0262:
																								if (6 > b)
																								{
																									goto end_IL_0219;
																								}
																								goto IL_0282;
																								IL_0282:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02c2;
																							}
																							continue;
																						}
																						goto IL_0519;
																						IL_05bb:
																						num5--;
																						goto end_IL_0249;
																						IL_0519:
																						if (8 < b)
																						{
																							goto IL_0524;
																						}
																						goto IL_055c;
																						IL_0524:
																						if (9 < b)
																						{
																							goto end_IL_0219;
																						}
																						goto IL_0532;
																						IL_0532:
																						if (9 > b)
																						{
																							goto end_IL_0219;
																						}
																						goto IL_0540;
																						IL_0540:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0249;
																						IL_055c:
																						if (8 > b)
																						{
																							goto end_IL_0219;
																						}
																						goto IL_0567;
																						IL_0567:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05a7;
																						IL_05a7:
																						array[num5 - 2] = 0;
																						goto IL_05bb;
																						continue;
																						end_IL_01fc:
																						break;
																					}
																					continue;
																				}
																				goto IL_0272;
																				IL_0332:
																				ptr2 += 8;
																				goto end_IL_0249;
																				IL_0272:
																				if (5 <= b)
																				{
																					goto IL_02e9;
																				}
																				goto IL_0345;
																				IL_0345:
																				if (2 >= b)
																				{
																					goto IL_0350;
																				}
																				goto IL_037f;
																				IL_0350:
																				if (2 > b)
																				{
																					goto IL_035e;
																				}
																				goto IL_0403;
																				IL_035e:
																				if (1 < b)
																				{
																					goto end_IL_0219;
																				}
																				goto IL_036c;
																				IL_036c:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_0219;
																				IL_0403:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0443;
																				IL_0443:
																				array[num5 - 2] = 0;
																				goto IL_0457;
																				IL_0457:
																				num5--;
																				goto end_IL_0249;
																				IL_037f:
																				if (3 < b)
																				{
																					goto IL_038a;
																				}
																				goto IL_03ab;
																				IL_038a:
																				if (4 < b)
																				{
																					goto end_IL_0219;
																				}
																				goto IL_0398;
																				IL_0398:
																				if (4 > b)
																				{
																					goto end_IL_0219;
																				}
																				goto IL_046a;
																				IL_046a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04aa;
																				IL_04aa:
																				array[num5 - 2] = 0;
																				goto IL_04be;
																				IL_04be:
																				num5--;
																				goto end_IL_0249;
																				IL_03ab:
																				if (3 > b)
																				{
																					goto end_IL_0219;
																				}
																				goto IL_03b9;
																				IL_03b9:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03e2;
																				IL_03e2:
																				ptr2 += 8;
																				goto IL_03f0;
																				IL_03f0:
																				num5--;
																				goto end_IL_0249;
																				IL_02e9:
																				array[num5] = 0;
																				goto IL_02f7;
																				IL_02f7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_031a;
																				IL_031a:
																				array2[num5] = null;
																				goto IL_0324;
																				IL_0324:
																				num5++;
																				goto IL_0332;
																				continue;
																				end_IL_020c:
																				break;
																			}
																			continue;
																			end_IL_0219:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05ee;
																	IL_060a:
																	ptr2 += 8;
																	goto end_IL_0249;
																	IL_05fc:
																	num5++;
																	goto IL_060a;
																	IL_05ee:
																	array[num5] = 0;
																	goto IL_05fc;
																	continue;
																	end_IL_0229:
																	break;
																}
																continue;
																end_IL_0239:
																break;
															}
															continue;
															end_IL_0249:
															break;
														}
														continue;
													}
													goto IL_06d7;
													IL_06d7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0618:
													break;
												}
												continue;
												end_IL_062b:
												break;
											}
											continue;
											end_IL_0635:
											break;
										}
										continue;
										end_IL_0649:
										break;
									}
									continue;
									end_IL_065e:
									break;
								}
								continue;
								end_IL_0673:
								break;
							}
							continue;
							end_IL_068c:
							break;
						}
						continue;
						end_IL_069c:
						break;
					}
					continue;
					end_IL_06ac:
					break;
				}
				continue;
				end_IL_06bc:
				break;
			}
		}
	}

	private static int smethod_2(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_1;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_3()
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ToIntIReflect.EndOffsetGetSafeWaitHandle);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0345:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0325:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0315:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0308:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02f8:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02e5:
																											if (2 >= b)
																											{
																												num = 47;
																												while (true)
																												{
																													IL_02d5:
																													if (2 > b)
																													{
																														while (1 >= b)
																														{
																															while (true)
																															{
																																IL_02b2:
																																if (1 > b)
																																{
																																	num = 157;
																																	while (num != 157)
																																	{
																																		if (num != 1138)
																																		{
																																			goto IL_03fa;
																																		}
																																		switch (num)
																																		{
																																		case 84:
																																			goto IL_02b2;
																																		case 23:
																																			goto IL_02c5;
																																		case 47:
																																			goto IL_02d5;
																																		case 68:
																																		case 77:
																																			goto IL_02e5;
																																		case 64:
																																			goto IL_02f8;
																																		case 0:
																																			goto IL_0308;
																																		case 123:
																																			goto IL_0315;
																																		case 148:
																																			goto IL_0325;
																																		case 58:
																																			goto IL_0335;
																																		case 20:
																																			goto IL_0345;
																																		case 60:
																																			goto end_IL_0345;
																																		case 53:
																																		case 96:
																																			goto end_IL_0355;
																																		case 32:
																																		case 143:
																																			goto IL_0370;
																																		case 22:
																																		case 99:
																																			goto IL_037b;
																																		case 119:
																																			goto IL_0389;
																																		case 54:
																																		case 120:
																																			goto IL_0397;
																																		case 132:
																																			goto IL_03c0;
																																		case 131:
																																			goto IL_03ce;
																																		case 125:
																																			goto IL_03e1;
																																		case 74:
																																		case 140:
																																			goto IL_03ec;
																																		case 106:
																																			goto IL_03fa;
																																		case 19:
																																		case 50:
																																			goto IL_0408;
																																		case 62:
																																			goto IL_0416;
																																		case 126:
																																			goto IL_042e;
																																		case 75:
																																			goto IL_043c;
																																		case 89:
																																		case 136:
																																			goto IL_044f;
																																		case 147:
																																			goto IL_048e;
																																		case 41:
																																		case 103:
																																			goto IL_04aa;
																																		case 27:
																																			goto IL_04cc;
																																		case 144:
																																			goto IL_04da;
																																		case 82:
																																			goto IL_04e8;
																																		case 26:
																																		case 122:
																																			goto IL_04fb;
																																		case 94:
																																			goto IL_053b;
																																		case 88:
																																			goto IL_054f;
																																		case 57:
																																			goto IL_0562;
																																		case 80:
																																			goto IL_0570;
																																		case 13:
																																		case 91:
																																			goto IL_057e;
																																		case 63:
																																			goto IL_05a7;
																																		case 39:
																																		case 108:
																																			goto IL_05c0;
																																		case 110:
																																			goto IL_05de;
																																		case 100:
																																			goto IL_05ec;
																																		case 97:
																																		case 149:
																																			goto IL_05ff;
																																		case 1:
																																		case 21:
																																			goto IL_0617;
																																		case 114:
																																			goto IL_0625;
																																		case 3:
																																		case 112:
																																			goto IL_0630;
																																		case 81:
																																			goto IL_0670;
																																		case 37:
																																			goto IL_0684;
																																		case 92:
																																			goto IL_0697;
																																		case 93:
																																			goto IL_06a5;
																																		case 38:
																																			goto IL_06b0;
																																		case 135:
																																			goto IL_06be;
																																		case 28:
																																		case 78:
																																			goto IL_06d1;
																																		case 65:
																																			goto IL_06df;
																																		case 12:
																																			goto IL_0702;
																																		case 25:
																																			goto IL_070c;
																																		case 115:
																																			goto IL_071a;
																																		case 14:
																																			goto IL_0736;
																																		case 86:
																																			goto IL_0744;
																																		case 113:
																																		case 128:
																																			goto IL_0752;
																																		case 146:
																																			goto IL_0796;
																																		case 9:
																																			goto IL_07aa;
																																		case 5:
																																			goto IL_07c6;
																																		case 11:
																																			goto IL_07d4;
																																		case 104:
																																		case 139:
																																			goto IL_07e2;
																																		case 7:
																																			goto IL_07f0;
																																		case 116:
																																		case 118:
																																			goto IL_07fe;
																																		case 129:
																																			goto IL_0860;
																																		case 61:
																																		case 142:
																																			goto IL_0870;
																																		case 24:
																																			goto IL_0889;
																																		case 4:
																																			goto IL_0894;
																																		case 2:
																																		case 6:
																																		case 10:
																																		case 16:
																																		case 29:
																																		case 31:
																																		case 35:
																																		case 36:
																																		case 42:
																																		case 44:
																																		case 45:
																																		case 48:
																																		case 66:
																																		case 69:
																																		case 73:
																																		case 76:
																																		case 79:
																																		case 83:
																																		case 90:
																																		case 95:
																																		case 98:
																																		case 101:
																																		case 107:
																																		case 111:
																																		case 117:
																																		case 121:
																																		case 124:
																																		case 133:
																																		case 134:
																																		case 145:
																																			goto end_IL_029f;
																																		case 8:
																																		case 15:
																																		case 30:
																																		case 34:
																																		case 43:
																																		case 49:
																																		case 51:
																																		case 52:
																																		case 59:
																																		case 67:
																																		case 70:
																																		case 71:
																																		case 85:
																																		case 87:
																																		case 127:
																																		case 137:
																																		case 138:
																																		case 150:
																																			goto end_IL_0365;
																																		case 130:
																																			goto end_IL_08b2;
																																		case 72:
																																			goto end_IL_08c5;
																																		case 40:
																																			goto end_IL_08cf;
																																		case 109:
																																			goto end_IL_08da;
																																		case 55:
																																		case 141:
																																			goto end_IL_08ea;
																																		case 46:
																																			goto end_IL_08fa;
																																		case 33:
																																		case 102:
																																			goto end_IL_090a;
																																		case 17:
																																			goto end_IL_091a;
																																		case 18:
																																			goto end_IL_092a;
																																		case 56:
																																		case 105:
																																			goto IL_0945;
																																		}
																																		continue;
																																		end_IL_029f:
																																		break;
																																	}
																																	break;
																																}
																																goto IL_04aa;
																																IL_04da:
																																num5++;
																																goto IL_04e8;
																																IL_04e8:
																																ptr2 += 8;
																																goto end_IL_0365;
																																IL_04aa:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																num = 27;
																																goto IL_04cc;
																																IL_04cc:
																																array[num5] = 0;
																																goto IL_04da;
																															}
																															break;
																															IL_02c5:;
																														}
																														break;
																													}
																													goto IL_04fb;
																													IL_054f:
																													num5--;
																													goto end_IL_0365;
																													IL_04fb:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_053b;
																													IL_053b:
																													array[num5 - 2] = 0;
																													goto IL_054f;
																												}
																												break;
																											}
																											goto IL_0562;
																											IL_057e:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_05a7;
																											IL_05a7:
																											array[num5 - 1] = 5;
																											goto end_IL_0365;
																											IL_0562:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_0570;
																											IL_0570:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_057e;
																										}
																										break;
																									}
																									goto IL_05c0;
																									IL_05ec:
																									num5--;
																									goto end_IL_0365;
																									IL_05c0:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_05de;
																									IL_05de:
																									ptr2 += 8;
																									goto IL_05ec;
																								}
																								break;
																							}
																							goto IL_0370;
																							IL_048e:
																							num5 -= 3;
																							num = 15;
																							goto end_IL_0365;
																							IL_0370:
																							if (6 < b)
																							{
																								goto IL_037b;
																							}
																							goto IL_03e1;
																							IL_037b:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0389;
																							IL_0389:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0397;
																							IL_0397:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03c0;
																							IL_03c0:
																							ptr2 += 8;
																							goto IL_03ce;
																							IL_03ce:
																							num5--;
																							goto end_IL_0365;
																							IL_03e1:
																							if (6 > b)
																							{
																								goto IL_03ec;
																							}
																							goto IL_044f;
																							IL_03ec:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_03fa;
																							IL_03fa:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0408;
																							IL_0408:
																							array[num5] = 5;
																							goto IL_0416;
																							IL_0416:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_042e;
																							IL_042e:
																							num5++;
																							goto IL_043c;
																							IL_043c:
																							ptr2 += 8;
																							goto end_IL_0365;
																							IL_044f:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_048e;
																						}
																						break;
																					}
																					goto IL_05ff;
																					IL_05ff:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0365;
																				}
																				break;
																			}
																			goto IL_0617;
																			IL_0894:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_0617:
																			if (12 >= b)
																			{
																				goto IL_0625;
																			}
																			goto IL_07c6;
																			IL_0625:
																			if (12 <= b)
																			{
																				goto IL_0630;
																			}
																			goto IL_0697;
																			IL_0630:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0670;
																			IL_0670:
																			array[num5 - 2] = 0;
																			goto IL_0684;
																			IL_0684:
																			num5--;
																			goto end_IL_0365;
																			IL_0697:
																			if (10 >= b)
																			{
																				goto IL_06a5;
																			}
																			goto IL_0736;
																			IL_06a5:
																			if (10 > b)
																			{
																				goto IL_06b0;
																			}
																			goto IL_06d1;
																			IL_06b0:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06be;
																			IL_06be:
																			if (9 <= b)
																			{
																				goto end_IL_0365;
																			}
																			break;
																			IL_06d1:
																			array[num5] = 0;
																			goto IL_06df;
																			IL_06df:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0702;
																			IL_0702:
																			array2[num5] = null;
																			goto IL_070c;
																			IL_070c:
																			num5++;
																			goto IL_071a;
																			IL_071a:
																			ptr2 += 8;
																			num = 70;
																			goto end_IL_0365;
																			IL_0736:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0744;
																			IL_0744:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0752;
																			IL_0752:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0796;
																			IL_0796:
																			array[num5 - 2] = 0;
																			goto IL_07aa;
																			IL_07aa:
																			num5--;
																			num = 34;
																			goto end_IL_0365;
																			IL_07c6:
																			if (14 >= b)
																			{
																				goto IL_07d4;
																			}
																			goto IL_0889;
																			IL_07d4:
																			if (14 > b)
																			{
																				goto IL_07e2;
																			}
																			goto IL_0870;
																			IL_07e2:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_07f0;
																			IL_07f0:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_07fe;
																			IL_07fe:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0860;
																			IL_0860:
																			num5 -= 2;
																			goto end_IL_0365;
																			IL_0870:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0365;
																			IL_0889:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0894;
																		}
																		break;
																		IL_0335:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0365;
																continue;
																end_IL_0345:
																break;
															}
															continue;
															end_IL_0355:
															break;
														}
														continue;
														end_IL_0365:
														break;
													}
													continue;
												}
												goto IL_0945;
												IL_0945:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b2:
												break;
											}
											continue;
											end_IL_08c5:
											break;
										}
										continue;
										end_IL_08cf:
										break;
									}
									continue;
									end_IL_08da:
									break;
								}
								continue;
								end_IL_08ea:
								break;
							}
							continue;
							end_IL_08fa:
							break;
						}
						continue;
						end_IL_090a:
						break;
					}
					continue;
					end_IL_091a:
					break;
				}
				continue;
				end_IL_092a:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 104;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 71;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReserveProcessorParsingInfo.FileInfoResultHandlerTaskStops);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 145;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0305:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			num = 9;
																			while (true)
																			{
																				IL_02e2:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02d5:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02c5:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02b5:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_02a2:
																												if (6 <= b)
																												{
																													num = 153;
																													while (true)
																													{
																														if (num != 153)
																														{
																															if (num != 1134)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 137:
																																goto IL_02a2;
																															case 72:
																															case 92:
																																goto IL_02b5;
																															case 105:
																																goto IL_02c5;
																															case 6:
																																goto IL_02d5;
																															case 9:
																																goto IL_02e2;
																															case 136:
																																goto IL_02f2;
																															case 87:
																																goto IL_0305;
																															case 122:
																																goto end_IL_0305;
																															case 145:
																																goto end_IL_0315;
																															case 54:
																																goto end_IL_0325;
																															case 2:
																																goto IL_0346;
																															case 107:
																																goto IL_0354;
																															case 23:
																															case 36:
																																goto IL_0362;
																															case 60:
																																goto IL_0370;
																															case 93:
																																goto IL_0388;
																															case 57:
																															case 116:
																																goto IL_039b;
																															case 108:
																															case 130:
																																goto IL_03b3;
																															case 101:
																															case 109:
																																goto IL_03c1;
																															case 64:
																																goto IL_03cf;
																															case 37:
																															case 119:
																																goto IL_03da;
																															case 67:
																																goto IL_03f6;
																															case 112:
																																goto IL_0404;
																															case 59:
																															case 118:
																																goto IL_0412;
																															case 62:
																																goto IL_0474;
																															case 115:
																																goto IL_0487;
																															case 42:
																																goto IL_0495;
																															case 135:
																																goto IL_04a8;
																															case 138:
																																goto IL_04bb;
																															case 46:
																															case 94:
																																goto IL_04c6;
																															case 19:
																																goto IL_0506;
																															case 58:
																																goto IL_051a;
																															case 12:
																																goto IL_052d;
																															case 17:
																															case 84:
																																goto IL_0538;
																															case 95:
																																goto IL_0546;
																															case 99:
																																goto IL_0559;
																															case 77:
																															case 129:
																																goto IL_0564;
																															case 83:
																																goto IL_0572;
																															case 32:
																															case 50:
																																goto IL_0585;
																															case 76:
																																goto IL_0593;
																															case 28:
																																goto IL_05b6;
																															case 13:
																																goto IL_05c0;
																															case 110:
																																goto IL_05d7;
																															case 66:
																															case 140:
																																goto IL_05ea;
																															case 80:
																																goto IL_062e;
																															case 20:
																																goto IL_0642;
																															case 74:
																															case 144:
																																goto IL_0655;
																															case 3:
																																goto IL_0663;
																															case 16:
																															case 49:
																																goto IL_0671;
																															case 82:
																																goto IL_069a;
																															case 52:
																																goto IL_06a8;
																															case 27:
																																goto IL_06bb;
																															case 81:
																																goto IL_06fa;
																															case 120:
																																goto IL_070d;
																															case 25:
																															case 39:
																																goto IL_0718;
																															case 91:
																																goto IL_0736;
																															case 146:
																																goto IL_0744;
																															case 88:
																																goto IL_0757;
																															case 114:
																																goto IL_0762;
																															case 70:
																																goto IL_0770;
																															case 53:
																															case 68:
																																goto IL_0789;
																															case 30:
																																goto IL_07b2;
																															case 65:
																																goto IL_07d4;
																															case 35:
																															case 61:
																																goto IL_07df;
																															case 10:
																																goto IL_081f;
																															case 102:
																																goto IL_0833;
																															case 134:
																																goto IL_0843;
																															case 79:
																																goto IL_084e;
																															case 8:
																															case 142:
																																goto IL_0859;
																															case 117:
																																goto IL_0872;
																															case 141:
																																goto IL_0889;
																															case 48:
																																goto IL_0897;
																															case 0:
																															case 7:
																															case 21:
																															case 22:
																															case 34:
																															case 40:
																															case 44:
																															case 51:
																															case 69:
																															case 73:
																															case 75:
																															case 78:
																															case 85:
																															case 86:
																															case 90:
																															case 96:
																															case 98:
																															case 106:
																															case 111:
																															case 123:
																															case 124:
																															case 126:
																															case 127:
																															case 128:
																															case 131:
																															case 132:
																															case 139:
																																goto end_IL_028f;
																															case 5:
																															case 14:
																															case 15:
																															case 18:
																															case 24:
																															case 26:
																															case 29:
																															case 31:
																															case 33:
																															case 38:
																															case 43:
																															case 45:
																															case 63:
																															case 97:
																															case 100:
																															case 113:
																															case 121:
																															case 133:
																																goto end_IL_0330;
																															case 47:
																																goto end_IL_08ba;
																															case 1:
																																goto end_IL_08cd;
																															case 55:
																																goto end_IL_08d7;
																															case 4:
																																goto end_IL_08e2;
																															case 41:
																															case 71:
																																goto end_IL_08f2;
																															case 56:
																																goto end_IL_0902;
																															case 89:
																															case 143:
																																goto end_IL_0912;
																															case 103:
																																goto end_IL_092b;
																															case 104:
																																goto end_IL_093b;
																															case 11:
																															case 125:
																																goto IL_0956;
																															}
																															continue;
																														}
																														goto IL_06bb;
																														IL_06bb:
																														((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_06fa;
																														IL_06fa:
																														num5 -= 3;
																														goto end_IL_0330;
																														continue;
																														end_IL_028f:
																														break;
																													}
																													break;
																												}
																												goto IL_0346;
																												IL_0388:
																												num5++;
																												goto IL_04a8;
																												IL_04a8:
																												ptr2 += 8;
																												goto end_IL_0330;
																												IL_0346:
																												if (5 < b)
																												{
																													break;
																												}
																												goto IL_0354;
																												IL_0354:
																												if (5 > b)
																												{
																													break;
																												}
																												goto IL_0362;
																												IL_0362:
																												array[num5] = 5;
																												goto IL_0370;
																												IL_0370:
																												array2[num5] = array5[*(int*)(ptr2 + num3)];
																												goto IL_0388;
																											}
																											break;
																										}
																										goto IL_0655;
																										IL_06a8:
																										num5--;
																										goto end_IL_0330;
																										IL_0655:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0663;
																										IL_0663:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0671;
																										IL_0671:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_069a;
																										IL_069a:
																										ptr2 += 8;
																										goto IL_06a8;
																									}
																									break;
																								}
																								goto IL_070d;
																								IL_0889:
																								num5++;
																								goto IL_0897;
																								IL_070d:
																								if (4 <= b)
																								{
																									goto IL_0718;
																								}
																								goto IL_0757;
																								IL_0718:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_0736;
																								IL_0736:
																								ptr2 += 8;
																								goto IL_0744;
																								IL_0744:
																								num5--;
																								goto end_IL_0330;
																								IL_0757:
																								if (2 < b)
																								{
																									goto IL_0762;
																								}
																								goto IL_07d4;
																								IL_0762:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0770;
																								IL_0770:
																								if (3 > b)
																								{
																									num = 127;
																									break;
																								}
																								goto IL_0789;
																								IL_0897:
																								ptr2 += 8;
																								goto end_IL_0330;
																								IL_0789:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_07b2;
																								IL_07b2:
																								array[num5 - 1] = 5;
																								num = 33;
																								goto end_IL_0330;
																								IL_07d4:
																								if (2 <= b)
																								{
																									goto IL_07df;
																								}
																								goto IL_0843;
																								IL_07df:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_081f;
																								IL_081f:
																								array[num5 - 2] = 0;
																								goto IL_0833;
																								IL_0833:
																								num5--;
																								goto end_IL_0330;
																								IL_0843:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_084e;
																								IL_084e:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0859;
																								IL_0859:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0872;
																								IL_0872:
																								array[num5] = 0;
																								num = 141;
																								goto IL_0889;
																							}
																							break;
																						}
																						num = 57;
																						goto IL_039b;
																						IL_039b:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0330;
																					}
																					break;
																				}
																				goto IL_03b3;
																				IL_05d7:
																				ptr2 += 8;
																				goto end_IL_0330;
																				IL_03b3:
																				if (12 < b)
																				{
																					goto IL_03c1;
																				}
																				goto IL_04bb;
																				IL_03c1:
																				if (14 >= b)
																				{
																					goto IL_03cf;
																				}
																				goto IL_0487;
																				IL_03cf:
																				if (14 <= b)
																				{
																					goto IL_03da;
																				}
																				goto IL_03f6;
																				IL_03da:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0330;
																				IL_03f6:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_0404;
																				IL_0404:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0412;
																				IL_0412:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0474;
																				IL_0474:
																				num5 -= 2;
																				goto end_IL_0330;
																				IL_0487:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_0495;
																				IL_0495:
																				if (15 <= b)
																				{
																				}
																				break;
																				IL_04bb:
																				if (12 <= b)
																				{
																					goto IL_04c6;
																				}
																				goto IL_052d;
																				IL_04c6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0506;
																				IL_0506:
																				array[num5 - 2] = 0;
																				goto IL_051a;
																				IL_051a:
																				num5--;
																				goto end_IL_0330;
																				IL_052d:
																				if (10 < b)
																				{
																					goto IL_0538;
																				}
																				goto IL_0559;
																				IL_0538:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0546;
																				IL_0546:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_05ea;
																				IL_05ea:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_062e;
																				IL_062e:
																				array[num5 - 2] = 0;
																				goto IL_0642;
																				IL_0642:
																				num5--;
																				goto end_IL_0330;
																				IL_0559:
																				if (10 > b)
																				{
																					goto IL_0564;
																				}
																				goto IL_0585;
																				IL_0564:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0572;
																				IL_0572:
																				if (9 > b)
																				{
																					break;
																				}
																				goto end_IL_0330;
																				IL_0585:
																				array[num5] = 0;
																				goto IL_0593;
																				IL_0593:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05b6;
																				IL_05b6:
																				array2[num5] = null;
																				goto IL_05c0;
																				IL_05c0:
																				num5++;
																				num = 110;
																				goto IL_05d7;
																			}
																			break;
																			IL_02f2:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0330;
																	continue;
																	end_IL_0305:
																	break;
																}
																continue;
																end_IL_0315:
																break;
															}
															continue;
															end_IL_0325:
															break;
														}
														continue;
														end_IL_0330:
														break;
													}
													continue;
												}
												goto IL_0956;
												IL_0956:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08ba:
												break;
											}
											continue;
											end_IL_08cd:
											break;
										}
										continue;
										end_IL_08d7:
										break;
									}
									continue;
									end_IL_08e2:
									break;
								}
								continue;
								end_IL_08f2:
								break;
							}
							continue;
							end_IL_0902:
							break;
						}
						continue;
						end_IL_0912:
						break;
					}
					continue;
					end_IL_092b:
					break;
				}
				continue;
				end_IL_093b:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 43;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 23;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WindowsRuntimeDesignerContextResetConnectAccess.DeconstructIIDIManifestInformation);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_020c:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01ef:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01df:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01cf:
																								if (7 < b)
																								{
																									while (8 >= b)
																									{
																										while (true)
																										{
																											IL_01ac:
																											if (8 > b)
																											{
																												num = 95;
																												while (num != 95 && num == 1076)
																												{
																													switch (num)
																													{
																													case 55:
																														goto IL_01ac;
																													case 12:
																														goto IL_01bf;
																													case 48:
																														goto IL_01cf;
																													case 15:
																													case 50:
																														goto IL_01df;
																													case 24:
																														goto IL_01ef;
																													case 25:
																														goto IL_01fc;
																													case 51:
																														goto IL_020c;
																													case 61:
																														goto end_IL_020c;
																													case 20:
																													case 44:
																														goto end_IL_021c;
																													case 1:
																														goto IL_0237;
																													case 14:
																													case 37:
																														goto IL_0245;
																													case 39:
																														goto IL_0270;
																													case 57:
																														goto IL_0280;
																													case 67:
																														goto IL_028e;
																													case 34:
																													case 75:
																														goto IL_02a1;
																													case 58:
																														goto IL_02af;
																													case 5:
																													case 33:
																														goto IL_02bd;
																													case 22:
																													case 84:
																														goto IL_02d5;
																													case 40:
																														goto IL_02e3;
																													case 9:
																													case 70:
																														goto IL_02f1;
																													case 8:
																														goto IL_035f;
																													case 53:
																														goto IL_0372;
																													case 4:
																														goto IL_0380;
																													case 60:
																														goto IL_0393;
																													case 78:
																														goto IL_03a1;
																													case 38:
																													case 68:
																														goto IL_03b8;
																													case 49:
																														goto IL_03f8;
																													case 13:
																														goto IL_040c;
																													case 10:
																													case 80:
																														goto IL_041f;
																													case 83:
																														goto IL_043b;
																													case 74:
																													case 88:
																														goto IL_0446;
																													case 26:
																														goto IL_0454;
																													case 72:
																														goto IL_0477;
																													case 30:
																														goto IL_0481;
																													case 62:
																														goto IL_048f;
																													case 0:
																													case 2:
																													case 7:
																													case 16:
																													case 19:
																													case 21:
																													case 27:
																													case 29:
																													case 35:
																													case 41:
																													case 59:
																													case 65:
																													case 66:
																													case 71:
																													case 73:
																													case 77:
																														goto end_IL_0199;
																													case 32:
																														goto IL_04c2;
																													case 64:
																														goto IL_04d0;
																													case 52:
																														goto IL_04de;
																													case 3:
																													case 17:
																													case 18:
																													case 31:
																													case 36:
																													case 47:
																													case 79:
																													case 81:
																													case 85:
																													case 86:
																													case 87:
																														goto end_IL_022c;
																													case 11:
																														goto end_IL_04ec;
																													case 45:
																														goto end_IL_04ff;
																													case 63:
																														goto end_IL_0509;
																													case 6:
																														goto end_IL_0514;
																													case 46:
																														goto end_IL_0529;
																													case 56:
																													case 69:
																														goto end_IL_053e;
																													case 23:
																														goto end_IL_054e;
																													case 28:
																													case 76:
																														goto end_IL_055e;
																													case 42:
																														goto end_IL_056e;
																													case 43:
																														goto end_IL_0587;
																													case 54:
																													case 82:
																														goto IL_05a2;
																													}
																													continue;
																													end_IL_0199:
																													break;
																												}
																												break;
																											}
																											goto IL_041f;
																											IL_041f:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											goto end_IL_022c;
																										}
																										break;
																										IL_01bf:;
																									}
																									break;
																								}
																								goto IL_043b;
																								IL_048f:
																								ptr2 += 8;
																								goto end_IL_022c;
																								IL_043b:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0446;
																								IL_0446:
																								array[num6] = 0;
																								goto IL_0454;
																								IL_0454:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0477;
																								IL_0477:
																								array2[num6] = null;
																								goto IL_0481;
																								IL_0481:
																								num6++;
																								goto IL_048f;
																							}
																							break;
																						}
																						goto IL_0270;
																						IL_02bd:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_022c;
																						IL_0270:
																						if (6 <= b)
																						{
																							goto end_IL_022c;
																						}
																						goto IL_02a1;
																						IL_02a1:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_02af;
																						IL_02af:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_02bd;
																					}
																					break;
																				}
																				goto IL_0237;
																				IL_03f8:
																				array[num6 - 2] = 0;
																				goto IL_040c;
																				IL_0237:
																				if (4 <= b)
																				{
																					goto IL_0245;
																				}
																				goto IL_02d5;
																				IL_0245:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0280;
																				IL_0280:
																				ptr2 += 8;
																				goto IL_028e;
																				IL_028e:
																				num6--;
																				goto end_IL_022c;
																				IL_02d5:
																				if (2 >= b)
																				{
																					goto IL_02e3;
																				}
																				goto IL_0393;
																				IL_02e3:
																				if (2 <= b)
																				{
																					goto IL_02f1;
																				}
																				goto IL_0372;
																				IL_02f1:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_035f;
																				IL_035f:
																				num6 -= 2;
																				goto end_IL_022c;
																				IL_0372:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0380;
																				IL_0380:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0393:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_03a1;
																				IL_03a1:
																				if (3 > b)
																				{
																					break;
																				}
																				num = 68;
																				goto IL_03b8;
																				IL_040c:
																				num6--;
																				goto end_IL_022c;
																				IL_03b8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_03f8;
																			}
																			break;
																			IL_01fc:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c2;
																	IL_04de:
																	ptr2 += 8;
																	goto end_IL_022c;
																	IL_04d0:
																	num6++;
																	goto IL_04de;
																	IL_04c2:
																	array[num6] = 0;
																	goto IL_04d0;
																	continue;
																	end_IL_020c:
																	break;
																}
																continue;
																end_IL_021c:
																break;
															}
															continue;
															end_IL_022c:
															break;
														}
														continue;
													}
													goto IL_05a2;
													IL_05a2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04ec:
													break;
												}
												continue;
												end_IL_04ff:
												break;
											}
											continue;
											end_IL_0509:
											break;
										}
										continue;
										end_IL_0514:
										break;
									}
									continue;
									end_IL_0529:
									break;
								}
								continue;
								end_IL_053e:
								break;
							}
							continue;
							end_IL_054e:
							break;
						}
						continue;
						end_IL_055e:
						break;
					}
					continue;
					end_IL_056e:
					break;
				}
				continue;
				end_IL_0587:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 143;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 142;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 124;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 4;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnumEqualityComparerDayOfWeek.EVENTACTIVITYCTRLSETIDgetHost);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_037d:
														byte b = *ptr2;
														while (true)
														{
															IL_036d:
															ptr2++;
															while (true)
															{
																IL_035d:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		num = 69;
																		while (true)
																		{
																			IL_033a:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_032d:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0320:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_0310:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_0300:
																											if (2 >= b)
																											{
																												while (true)
																												{
																													IL_02f0:
																													if (2 > b)
																													{
																														while (1 >= b)
																														{
																															while (1 <= b)
																															{
																																while (true)
																																{
																																	IL_02b5:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																	while (true)
																																	{
																																		IL_029c:
																																		array[num5] = 0;
																																		num = 155;
																																		while (true)
																																		{
																																			if (num != 155)
																																			{
																																				if (num != 1136)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 110:
																																					goto IL_029c;
																																				case 13:
																																				case 34:
																																					goto IL_02b5;
																																				case 95:
																																					goto IL_02d0;
																																				case 77:
																																				case 88:
																																					goto IL_02e0;
																																				case 86:
																																					goto IL_02f0;
																																				case 23:
																																					goto IL_0300;
																																				case 42:
																																					goto IL_0310;
																																				case 136:
																																					goto IL_0320;
																																				case 130:
																																					goto IL_032d;
																																				case 69:
																																					goto IL_033a;
																																				case 147:
																																					goto IL_034a;
																																				case 131:
																																					goto IL_035d;
																																				case 15:
																																					goto IL_036d;
																																				case 70:
																																				case 74:
																																					goto IL_037d;
																																				case 11:
																																				case 57:
																																					goto IL_0388;
																																				case 80:
																																				case 81:
																																					goto IL_03a0;
																																				case 61:
																																				case 76:
																																					goto IL_03ab;
																																				case 48:
																																					goto IL_03c4;
																																				case 84:
																																					goto IL_03d4;
																																				case 31:
																																				case 105:
																																					goto IL_03e7;
																																				case 73:
																																					goto IL_03f5;
																																				case 93:
																																				case 97:
																																					goto IL_040c;
																																				case 45:
																																					goto IL_041a;
																																				case 68:
																																					goto IL_0432;
																																				case 7:
																																					goto IL_0440;
																																				case 0:
																																				case 115:
																																					goto IL_0453;
																																				case 43:
																																				case 116:
																																					goto IL_0497;
																																				case 33:
																																				case 117:
																																					goto IL_04b7;
																																				case 20:
																																					goto IL_04e0;
																																				case 14:
																																					goto IL_04ee;
																																				case 119:
																																					goto IL_0501;
																																				case 18:
																																					goto IL_050f;
																																				case 46:
																																				case 120:
																																					goto IL_0522;
																																				case 38:
																																					goto IL_0530;
																																				case 39:
																																				case 109:
																																					goto IL_053e;
																																				case 100:
																																					goto IL_0567;
																																				case 140:
																																					goto IL_0580;
																																				case 36:
																																					goto IL_05a1;
																																				case 54:
																																				case 75:
																																					goto IL_05b4;
																																				case 27:
																																					goto IL_05f4;
																																				case 103:
																																					goto IL_0608;
																																				case 41:
																																					goto IL_061b;
																																				case 129:
																																				case 132:
																																					goto IL_0629;
																																				case 108:
																																					goto IL_0637;
																																				case 30:
																																				case 89:
																																					goto IL_0642;
																																				case 1:
																																					goto IL_065e;
																																				case 82:
																																					goto IL_066c;
																																				case 60:
																																				case 72:
																																					goto IL_067a;
																																				case 6:
																																					goto IL_06dc;
																																				case 122:
																																					goto IL_06ef;
																																				case 98:
																																					goto IL_06fd;
																																				case 5:
																																					goto IL_0710;
																																				case 3:
																																				case 67:
																																					goto IL_071e;
																																				case 85:
																																					goto IL_072c;
																																				case 52:
																																				case 90:
																																					goto IL_0737;
																																				case 44:
																																					goto IL_0745;
																																				case 51:
																																				case 107:
																																					goto IL_0761;
																																				case 59:
																																					goto IL_076f;
																																				case 25:
																																					goto IL_0792;
																																				case 146:
																																					goto IL_079c;
																																				case 145:
																																					goto IL_07aa;
																																				case 104:
																																					goto IL_07bd;
																																				case 12:
																																					goto IL_07cb;
																																				case 9:
																																				case 121:
																																					goto IL_07d9;
																																				case 137:
																																					goto IL_081d;
																																				case 63:
																																					goto IL_0831;
																																				case 79:
																																				case 125:
																																					goto IL_0844;
																																				case 114:
																																					goto IL_0884;
																																				case 64:
																																					goto IL_0898;
																																				case 2:
																																				case 8:
																																				case 16:
																																				case 17:
																																				case 22:
																																				case 29:
																																				case 35:
																																				case 37:
																																				case 49:
																																				case 53:
																																				case 55:
																																				case 56:
																																				case 66:
																																				case 78:
																																				case 83:
																																				case 92:
																																				case 96:
																																				case 99:
																																				case 101:
																																				case 106:
																																				case 113:
																																				case 118:
																																				case 123:
																																				case 126:
																																				case 134:
																																				case 138:
																																				case 139:
																																					goto end_IL_02d0;
																																				case 10:
																																				case 19:
																																				case 21:
																																				case 24:
																																				case 28:
																																				case 32:
																																				case 40:
																																				case 50:
																																				case 58:
																																				case 62:
																																				case 87:
																																				case 94:
																																				case 111:
																																				case 112:
																																				case 133:
																																				case 135:
																																				case 141:
																																				case 144:
																																					goto end_IL_0289;
																																				case 102:
																																					goto end_IL_08c4;
																																				case 26:
																																					goto end_IL_08d7;
																																				case 4:
																																					goto end_IL_08e1;
																																				case 47:
																																					goto end_IL_08ec;
																																				case 71:
																																				case 148:
																																					goto end_IL_08fc;
																																				case 124:
																																					goto end_IL_0915;
																																				case 65:
																																				case 91:
																																					goto end_IL_0925;
																																				case 142:
																																					goto end_IL_0935;
																																				case 143:
																																					goto end_IL_094e;
																																				case 127:
																																				case 128:
																																					goto IL_0972;
																																				}
																																				continue;
																																			}
																																			num5++;
																																			goto IL_05a1;
																																			IL_05a1:
																																			ptr2 += 8;
																																			break;
																																			continue;
																																			end_IL_0289:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto end_IL_035d;
																																continue;
																																end_IL_02d0:
																																break;
																																IL_02d0:;
																															}
																															break;
																															IL_02e0:;
																														}
																														break;
																													}
																													goto IL_05b4;
																													IL_0608:
																													num5--;
																													goto end_IL_035d;
																													IL_05b4:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_05f4;
																													IL_05f4:
																													array[num5 - 2] = 0;
																													goto IL_0608;
																												}
																												break;
																											}
																											goto IL_0522;
																											IL_0567:
																											array[num5 - 1] = 5;
																											goto end_IL_035d;
																											IL_0522:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_0530;
																											IL_0530:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_053e;
																											IL_053e:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_0567;
																										}
																										break;
																									}
																									goto IL_0497;
																									IL_050f:
																									num5--;
																									goto end_IL_035d;
																									IL_0497:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_0501;
																									IL_0501:
																									ptr2 += 8;
																									goto IL_050f;
																								}
																								break;
																							}
																							goto IL_03a0;
																							IL_0440:
																							ptr2 += 8;
																							goto end_IL_035d;
																							IL_03a0:
																							if (6 < b)
																							{
																								goto IL_03ab;
																							}
																							goto IL_03c4;
																							IL_03ab:
																							if (7 < b)
																							{
																								break;
																							}
																							num = 84;
																							goto IL_03d4;
																							IL_0453:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0580;
																							IL_03d4:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_04b7;
																							IL_04b7:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04e0;
																							IL_04e0:
																							ptr2 += 8;
																							goto IL_04ee;
																							IL_04ee:
																							num5--;
																							goto end_IL_035d;
																							IL_03c4:
																							if (6 > b)
																							{
																								goto IL_03e7;
																							}
																							goto IL_0453;
																							IL_03e7:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_03f5;
																							IL_03f5:
																							if (5 > b)
																							{
																								break;
																							}
																							num = 93;
																							goto IL_040c;
																							IL_0580:
																							num5 -= 3;
																							goto end_IL_035d;
																							IL_040c:
																							array[num5] = 5;
																							goto IL_041a;
																							IL_041a:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0432;
																							IL_0432:
																							num5++;
																							goto IL_0440;
																						}
																						break;
																					}
																					goto IL_0388;
																					IL_0388:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_035d;
																				}
																				break;
																			}
																			goto IL_061b;
																			IL_0884:
																			array[num5 - 2] = 0;
																			goto IL_0898;
																			IL_061b:
																			if (12 < b)
																			{
																				goto IL_0629;
																			}
																			goto IL_0710;
																			IL_0629:
																			if (14 >= b)
																			{
																				goto IL_0637;
																			}
																			goto IL_06ef;
																			IL_0637:
																			if (14 <= b)
																			{
																				goto IL_0642;
																			}
																			goto IL_065e;
																			IL_0642:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_035d;
																			IL_065e:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_066c;
																			IL_066c:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_067a;
																			IL_067a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06dc;
																			IL_06dc:
																			num5 -= 2;
																			goto end_IL_035d;
																			IL_06ef:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_06fd;
																			IL_06fd:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_0710:
																			if (12 > b)
																			{
																				goto IL_071e;
																			}
																			goto IL_0844;
																			IL_071e:
																			if (10 >= b)
																			{
																				goto IL_072c;
																			}
																			goto IL_07bd;
																			IL_072c:
																			if (10 > b)
																			{
																				goto IL_0737;
																			}
																			goto IL_0761;
																			IL_0737:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0745;
																			IL_0745:
																			if (9 > b)
																			{
																				break;
																			}
																			num = 40;
																			goto end_IL_035d;
																			IL_0898:
																			num5--;
																			num = 10;
																			goto end_IL_035d;
																			IL_0761:
																			array[num5] = 0;
																			goto IL_076f;
																			IL_076f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0792;
																			IL_0792:
																			array2[num5] = null;
																			goto IL_079c;
																			IL_079c:
																			num5++;
																			goto IL_07aa;
																			IL_07aa:
																			ptr2 += 8;
																			goto end_IL_035d;
																			IL_07bd:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_07cb;
																			IL_07cb:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_07d9;
																			IL_07d9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_081d;
																			IL_081d:
																			array[num5 - 2] = 0;
																			goto IL_0831;
																			IL_0831:
																			num5--;
																			goto end_IL_035d;
																			IL_0844:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0884;
																		}
																		break;
																		IL_034a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_035d:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0972;
												IL_0972:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c4:
												break;
											}
											continue;
											end_IL_08d7:
											break;
										}
										continue;
										end_IL_08e1:
										break;
									}
									continue;
									end_IL_08ec:
									break;
								}
								continue;
								end_IL_08fc:
								break;
							}
							continue;
							end_IL_0915:
							break;
						}
						continue;
						end_IL_0925:
						break;
					}
					continue;
					end_IL_0935:
					break;
				}
				continue;
				end_IL_094e:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 84;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 83;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 55;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getParamValuesDefineNestedType.FileImportPathObjectMode);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0309:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02ec:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02dc:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02cc:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_02bf:
																										if (10 < b)
																										{
																											while (11 >= b)
																											{
																												while (11 <= b)
																												{
																													num = 155;
																													while (true)
																													{
																														if (num != 155)
																														{
																															if (num != 1136)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 1:
																																goto IL_029c;
																															case 21:
																															case 147:
																																goto IL_02af;
																															case 95:
																															case 129:
																																goto IL_02bf;
																															case 108:
																																goto IL_02cc;
																															case 109:
																																goto IL_02dc;
																															case 0:
																																goto IL_02ec;
																															case 101:
																																goto IL_02f9;
																															case 86:
																																goto IL_0309;
																															case 42:
																																goto end_IL_0309;
																															case 52:
																															case 113:
																																goto end_IL_0319;
																															case 22:
																																goto IL_0334;
																															case 56:
																																goto IL_0344;
																															case 11:
																															case 16:
																																goto IL_0352;
																															case 82:
																																goto IL_0360;
																															case 89:
																																goto IL_0373;
																															case 40:
																																goto IL_037e;
																															case 24:
																																goto IL_038c;
																															case 88:
																																goto IL_039f;
																															case 30:
																																goto IL_03ad;
																															case 47:
																															case 94:
																																goto IL_03c0;
																															case 28:
																																goto IL_03ce;
																															case 78:
																																goto IL_03dc;
																															case 57:
																															case 110:
																																goto end_IL_0289;
																															case 41:
																															case 121:
																																goto IL_0410;
																															case 117:
																																goto IL_041e;
																															case 105:
																																goto IL_0441;
																															case 35:
																																goto IL_044b;
																															case 77:
																																goto IL_0459;
																															case 29:
																															case 123:
																																goto IL_046c;
																															case 19:
																																goto IL_047a;
																															case 128:
																																goto IL_048d;
																															case 18:
																																goto IL_049b;
																															case 31:
																															case 120:
																																goto IL_04a9;
																															case 25:
																																goto IL_04d2;
																															case 60:
																															case 131:
																																goto IL_04eb;
																															case 116:
																																goto IL_0509;
																															case 70:
																																goto IL_0517;
																															case 54:
																															case 133:
																																goto IL_052a;
																															case 72:
																																goto IL_0553;
																															case 112:
																																goto IL_0561;
																															case 134:
																																goto IL_0574;
																															case 12:
																															case 58:
																																goto IL_057f;
																															case 99:
																															case 135:
																																goto IL_059b;
																															case 104:
																																goto IL_05b2;
																															case 27:
																															case 139:
																																goto IL_05c0;
																															case 102:
																																goto IL_0622;
																															case 65:
																															case 140:
																																goto IL_0635;
																															case 5:
																																goto IL_0674;
																															case 33:
																															case 141:
																																goto IL_0687;
																															case 14:
																																goto IL_069e;
																															case 8:
																															case 59:
																																goto IL_06ac;
																															case 115:
																																goto IL_06ba;
																															case 74:
																																goto IL_06d2;
																															case 92:
																																goto IL_06e0;
																															case 146:
																																goto IL_06f3;
																															case 20:
																																goto IL_06fe;
																															case 114:
																																goto IL_0709;
																															case 93:
																															case 96:
																																goto IL_0717;
																															case 130:
																																goto IL_0730;
																															case 37:
																																goto IL_073e;
																															case 125:
																																goto IL_074c;
																															case 66:
																															case 107:
																																goto IL_076d;
																															case 69:
																																goto IL_07ad;
																															case 118:
																																goto IL_07c1;
																															case 90:
																																goto IL_07d4;
																															case 145:
																																goto IL_0821;
																															case 79:
																																goto IL_0835;
																															case 61:
																															case 68:
																																goto IL_0845;
																															case 44:
																																goto IL_0885;
																															case 4:
																																goto IL_0899;
																															case 3:
																															case 9:
																															case 10:
																															case 13:
																															case 15:
																															case 23:
																															case 26:
																															case 32:
																															case 36:
																															case 38:
																															case 39:
																															case 43:
																															case 46:
																															case 49:
																															case 51:
																															case 62:
																															case 63:
																															case 64:
																															case 67:
																															case 75:
																															case 76:
																															case 97:
																															case 106:
																															case 127:
																															case 132:
																															case 136:
																															case 143:
																															case 148:
																																goto end_IL_029c;
																															case 2:
																															case 6:
																															case 17:
																															case 45:
																															case 48:
																															case 71:
																															case 81:
																															case 85:
																															case 91:
																															case 98:
																															case 103:
																															case 111:
																															case 119:
																															case 124:
																															case 137:
																															case 138:
																															case 142:
																															case 144:
																																goto end_IL_0329;
																															case 100:
																																goto end_IL_08bc;
																															case 87:
																																goto end_IL_08cf;
																															case 34:
																																goto end_IL_08d9;
																															case 126:
																																goto end_IL_08e4;
																															case 55:
																																goto end_IL_08f4;
																															case 53:
																																goto end_IL_0904;
																															case 50:
																																goto end_IL_0914;
																															case 80:
																															case 122:
																																goto end_IL_091f;
																															case 83:
																																goto end_IL_092f;
																															case 84:
																																goto end_IL_093f;
																															case 7:
																															case 73:
																																goto IL_0963;
																															}
																															continue;
																														}
																														goto IL_07d4;
																														IL_0821:
																														array[num5 - 2] = 0;
																														goto IL_0835;
																														IL_0835:
																														num5--;
																														goto end_IL_0329;
																														IL_07d4:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																														num = 145;
																														goto IL_0821;
																														continue;
																														end_IL_0289:
																														break;
																													}
																													goto IL_03f8;
																													continue;
																													end_IL_029c:
																													break;
																													IL_029c:;
																												}
																												break;
																												IL_02af:;
																											}
																											break;
																										}
																										goto IL_0344;
																										IL_0459:
																										ptr2 += 8;
																										goto end_IL_0329;
																										IL_0344:
																										if (10 > b)
																										{
																											goto IL_0352;
																										}
																										goto IL_0410;
																										IL_0352:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_0360;
																										IL_0360:
																										if (9 > b)
																										{
																											break;
																										}
																										goto end_IL_0329;
																										IL_0410:
																										array[num5] = 0;
																										goto IL_041e;
																										IL_041e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0441;
																										IL_0441:
																										array2[num5] = null;
																										goto IL_044b;
																										IL_044b:
																										num5++;
																										goto IL_0459;
																									}
																									break;
																								}
																								goto IL_0845;
																								IL_0899:
																								num5--;
																								goto end_IL_0329;
																								IL_0845:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0885;
																								IL_0885:
																								array[num5 - 2] = 0;
																								goto IL_0899;
																							}
																							break;
																						}
																						goto IL_03c0;
																						IL_05b2:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_05c0;
																						IL_03c0:
																						if (14 < b)
																						{
																							goto IL_03ce;
																						}
																						goto IL_0574;
																						IL_03ce:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_03dc;
																						IL_03dc:
																						if (15 > b)
																						{
																							num = 23;
																						}
																						break;
																						IL_05c0:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0622;
																						IL_0574:
																						if (14 <= b)
																						{
																							goto IL_057f;
																						}
																						goto IL_059b;
																						IL_057f:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0329;
																						IL_059b:
																						if (13 < b)
																						{
																							break;
																						}
																						num = 104;
																						goto IL_05b2;
																						IL_0622:
																						num5 -= 2;
																						goto end_IL_0329;
																					}
																					break;
																				}
																				goto IL_0334;
																				IL_052a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0553;
																				IL_0334:
																				if (8 > b)
																				{
																					goto IL_0373;
																				}
																				goto IL_03f8;
																				IL_03f8:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0329;
																				IL_0373:
																				if (4 >= b)
																				{
																					goto IL_037e;
																				}
																				goto IL_039f;
																				IL_037e:
																				if (4 > b)
																				{
																					goto IL_038c;
																				}
																				goto IL_04eb;
																				IL_038c:
																				if (2 < b)
																				{
																					goto IL_048d;
																				}
																				goto IL_06f3;
																				IL_06f3:
																				if (2 > b)
																				{
																					goto IL_06fe;
																				}
																				goto IL_076d;
																				IL_06fe:
																				if (1 < b)
																				{
																					num = 26;
																					break;
																				}
																				goto IL_0709;
																				IL_0709:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0717;
																				IL_0717:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0730;
																				IL_0730:
																				array[num5] = 0;
																				goto IL_073e;
																				IL_073e:
																				num5++;
																				goto IL_074c;
																				IL_074c:
																				ptr2 += 8;
																				goto end_IL_0329;
																				IL_0553:
																				ptr2 += 8;
																				goto IL_0561;
																				IL_076d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_07ad;
																				IL_07ad:
																				array[num5 - 2] = 0;
																				goto IL_07c1;
																				IL_07c1:
																				num5--;
																				goto end_IL_0329;
																				IL_048d:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_049b;
																				IL_049b:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_04a9;
																				IL_04a9:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_04d2;
																				IL_04d2:
																				array[num5 - 1] = 5;
																				goto end_IL_0329;
																				IL_04eb:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_0509;
																				IL_0509:
																				ptr2 += 8;
																				goto IL_0517;
																				IL_0517:
																				num5--;
																				goto end_IL_0329;
																				IL_039f:
																				if (6 >= b)
																				{
																					goto IL_03ad;
																				}
																				goto IL_046c;
																				IL_03ad:
																				if (6 <= b)
																				{
																					goto IL_0635;
																				}
																				goto IL_0687;
																				IL_0687:
																				if (5 < b)
																				{
																					break;
																				}
																				num = 14;
																				goto IL_069e;
																				IL_0561:
																				num5--;
																				goto end_IL_0329;
																				IL_069e:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_06ac;
																				IL_06ac:
																				array[num5] = 5;
																				goto IL_06ba;
																				IL_06ba:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_06d2;
																				IL_06d2:
																				num5++;
																				goto IL_06e0;
																				IL_06e0:
																				ptr2 += 8;
																				goto end_IL_0329;
																				IL_0635:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0674;
																				IL_0674:
																				num5 -= 3;
																				goto end_IL_0329;
																				IL_046c:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_047a;
																				IL_047a:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_052a;
																			}
																			break;
																			IL_02f9:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0329;
																	continue;
																	end_IL_0309:
																	break;
																}
																continue;
																end_IL_0319:
																break;
															}
															continue;
															end_IL_0329:
															break;
														}
														continue;
													}
													goto IL_0963;
													IL_0963:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08bc:
													break;
												}
												continue;
												end_IL_08cf:
												break;
											}
											continue;
											end_IL_08d9:
											break;
										}
										continue;
										end_IL_08e4:
										break;
									}
									continue;
									end_IL_08f4:
									break;
								}
								continue;
								end_IL_0904:
								break;
							}
							continue;
							end_IL_0914:
							break;
						}
						continue;
						end_IL_091f:
						break;
					}
					continue;
					end_IL_092f:
					break;
				}
				continue;
				end_IL_093f:
				break;
			}
		}
	}
}
