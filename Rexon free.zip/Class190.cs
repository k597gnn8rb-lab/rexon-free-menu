using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("No Finger Movements", "Rig", "Freezes finger tracking.", false, 52, ModType.const_0, false)]
internal class Class190 : MonoBehaviour
{
	private static bool bool_0;

	private static bool bool_1;

	private static double double_0;

	private static float float_0;

	private static IntPtr[] getCurrentlyExecutingTaskCountAccessDenied;

	public Class190()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_0)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_0;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_0;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_1(int int_0)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsolatedStorageExceptionStrongNameGetBlobFromImage.getConfigurationContractFailureKind);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0284:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0264:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0257:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_024a:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_023a:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (1 <= b)
																											{
																												while (true)
																												{
																													IL_01ff:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													while (true)
																													{
																														IL_01ef:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_01d6:
																															num5++;
																															num = 109;
																															while (true)
																															{
																																if (num != 109)
																																{
																																	if (num != 1090)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 8:
																																		goto IL_01d6;
																																	case 74:
																																		goto IL_01ef;
																																	case 11:
																																	case 85:
																																		goto IL_01ff;
																																	case 35:
																																		goto IL_021a;
																																	case 14:
																																	case 98:
																																		goto IL_022a;
																																	case 45:
																																		goto IL_023a;
																																	case 5:
																																	case 73:
																																		goto IL_024a;
																																	case 54:
																																		goto IL_0257;
																																	case 3:
																																		goto IL_0264;
																																	case 49:
																																		goto IL_0274;
																																	case 34:
																																		goto IL_0284;
																																	case 83:
																																		goto end_IL_0284;
																																	case 31:
																																	case 94:
																																		goto end_IL_0294;
																																	case 30:
																																	case 37:
																																		goto IL_02af;
																																	case 25:
																																	case 38:
																																		goto IL_02bf;
																																	case 39:
																																		goto IL_02cf;
																																	case 46:
																																		goto IL_02df;
																																	case 53:
																																		goto IL_0302;
																																	case 23:
																																		goto IL_030c;
																																	case 29:
																																		goto IL_031a;
																																	case 52:
																																	case 70:
																																		goto IL_032d;
																																	case 69:
																																	case 96:
																																		goto IL_0345;
																																	case 99:
																																		goto IL_0353;
																																	case 44:
																																	case 67:
																																		goto IL_0379;
																																	case 102:
																																		goto end_IL_01c3;
																																	case 66:
																																		goto IL_03b9;
																																	case 87:
																																		goto IL_03cc;
																																	case 33:
																																		goto IL_03da;
																																	case 89:
																																	case 101:
																																		goto IL_03e5;
																																	case 78:
																																		goto IL_0447;
																																	case 51:
																																		goto IL_045a;
																																	case 21:
																																		goto IL_0465;
																																	case 36:
																																	case 81:
																																		goto IL_0473;
																																	case 58:
																																		goto IL_04b3;
																																	case 97:
																																		goto IL_04d0;
																																	case 16:
																																		goto IL_04e3;
																																	case 93:
																																		goto IL_04f1;
																																	case 42:
																																	case 88:
																																		goto IL_04ff;
																																	case 64:
																																		goto IL_0522;
																																	case 41:
																																		goto IL_0530;
																																	case 77:
																																		goto IL_053e;
																																	case 84:
																																		goto IL_054e;
																																	case 55:
																																		goto IL_0562;
																																	case 50:
																																	case 59:
																																		goto IL_056d;
																																	case 6:
																																		goto IL_0586;
																																	case 91:
																																		goto IL_059a;
																																	case 2:
																																	case 4:
																																	case 9:
																																	case 12:
																																	case 15:
																																	case 22:
																																	case 26:
																																	case 32:
																																	case 47:
																																	case 57:
																																	case 60:
																																	case 71:
																																	case 72:
																																	case 75:
																																	case 80:
																																	case 82:
																																	case 90:
																																	case 100:
																																		goto end_IL_021a;
																																	case 0:
																																	case 1:
																																	case 7:
																																	case 17:
																																	case 19:
																																	case 20:
																																	case 24:
																																	case 28:
																																	case 43:
																																	case 65:
																																	case 68:
																																	case 79:
																																	case 92:
																																		goto end_IL_02a4;
																																	case 61:
																																		goto end_IL_05b8;
																																	case 86:
																																		goto end_IL_05cb;
																																	case 56:
																																		goto end_IL_05d5;
																																	case 10:
																																		goto end_IL_05e0;
																																	case 40:
																																	case 95:
																																		goto end_IL_05f5;
																																	case 27:
																																		goto end_IL_0605;
																																	case 13:
																																	case 18:
																																		goto end_IL_0615;
																																	case 62:
																																		goto end_IL_0625;
																																	case 63:
																																		goto end_IL_0635;
																																	case 48:
																																	case 76:
																																		goto IL_0650;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto end_IL_02a4;
																																continue;
																																end_IL_01c3:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_03a2;
																												continue;
																												end_IL_021a:
																												break;
																												IL_021a:;
																											}
																											break;
																											IL_022a:;
																										}
																										break;
																									}
																									goto IL_0379;
																									IL_03b9:
																									num5--;
																									goto end_IL_02a4;
																									IL_0379:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03a2;
																									IL_03a2:
																									ptr2 += 8;
																									num = 66;
																									goto IL_03b9;
																								}
																								break;
																							}
																							goto IL_02af;
																							IL_032d:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02a4;
																							IL_02af:
																							if (3 >= b)
																							{
																								goto IL_02cf;
																							}
																							goto IL_0345;
																							IL_0345:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0353;
																							IL_0353:
																							if (4 <= b)
																							{
																								goto end_IL_02a4;
																							}
																							break;
																							IL_02cf:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_032d;
																						}
																						break;
																					}
																					goto IL_02bf;
																					IL_031a:
																					ptr2 += 8;
																					goto end_IL_02a4;
																					IL_02bf:
																					array[num5] = 0;
																					goto IL_02df;
																					IL_02df:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0302;
																					IL_0302:
																					array2[num5] = null;
																					goto IL_030c;
																					IL_030c:
																					num5++;
																					goto IL_031a;
																				}
																				break;
																			}
																			goto IL_03cc;
																			IL_0586:
																			if (10 < b)
																			{
																				break;
																			}
																			num = 91;
																			goto IL_059a;
																			IL_03cc:
																			if (8 >= b)
																			{
																				goto IL_03da;
																			}
																			goto IL_054e;
																			IL_03da:
																			if (8 <= b)
																			{
																				goto IL_03e5;
																			}
																			goto IL_045a;
																			IL_03e5:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0447;
																			IL_0447:
																			num5 -= 2;
																			goto end_IL_02a4;
																			IL_045a:
																			if (6 >= b)
																			{
																				goto IL_0465;
																			}
																			goto IL_04e3;
																			IL_0465:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0473;
																			IL_0473:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b3;
																			IL_04b3:
																			array[num5 - 2] = 0;
																			num = 97;
																			goto IL_04d0;
																			IL_04d0:
																			num5--;
																			goto end_IL_02a4;
																			IL_04e3:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_04f1;
																			IL_04f1:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04ff;
																			IL_04ff:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0522;
																			IL_0522:
																			array[num5] = 0;
																			goto IL_0530;
																			IL_0530:
																			num5++;
																			goto IL_053e;
																			IL_053e:
																			ptr2 += 8;
																			goto end_IL_02a4;
																			IL_054e:
																			if (9 >= b)
																			{
																				num = 55;
																				goto IL_0562;
																			}
																			goto IL_0586;
																			IL_059a:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_0562:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_056d;
																			IL_056d:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02a4;
																		}
																		break;
																		IL_0274:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a4;
																continue;
																end_IL_0284:
																break;
															}
															continue;
															end_IL_0294:
															break;
														}
														continue;
														end_IL_02a4:
														break;
													}
													continue;
												}
												goto IL_0650;
												IL_0650:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b8:
												break;
											}
											continue;
											end_IL_05cb:
											break;
										}
										continue;
										end_IL_05d5:
										break;
									}
									continue;
									end_IL_05e0:
									break;
								}
								continue;
								end_IL_05f5:
								break;
							}
							continue;
							end_IL_0605:
							break;
						}
						continue;
						end_IL_0615:
						break;
					}
					continue;
					end_IL_0625:
					break;
				}
				continue;
				end_IL_0635:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 127;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setNegativeSignGetAnonymous.setInputEncodingScheduler);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_033a:
														byte b = *ptr2;
														while (true)
														{
															IL_032a:
															ptr2++;
															while (true)
															{
																IL_031a:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02fd:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02ed:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02dd:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02cd:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02c0:
																											if (10 <= b)
																											{
																												while (true)
																												{
																													IL_02b0:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0282:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 152;
																														while (true)
																														{
																															if (num != 152)
																															{
																																if (num != 1133)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 121:
																																	goto IL_0282;
																																case 19:
																																case 97:
																																	goto IL_02b0;
																																case 135:
																																	goto IL_02c0;
																																case 110:
																																case 145:
																																	goto IL_02cd;
																																case 3:
																																	goto IL_02dd;
																																case 79:
																																	goto IL_02ed;
																																case 143:
																																	goto IL_02fd;
																																case 88:
																																	goto IL_030a;
																																case 90:
																																	goto IL_031a;
																																case 42:
																																	goto IL_032a;
																																case 10:
																																case 17:
																																	goto IL_033a;
																																case 91:
																																case 109:
																																	goto IL_0345;
																																case 7:
																																	goto IL_0353;
																																case 119:
																																	goto IL_0366;
																																case 71:
																																case 77:
																																	goto IL_0371;
																																case 6:
																																	goto IL_037c;
																																case 1:
																																case 44:
																																	goto IL_0387;
																																case 16:
																																	goto IL_03a5;
																																case 39:
																																	goto IL_03b3;
																																case 25:
																																	goto IL_03c6;
																																case 59:
																																case 63:
																																	goto IL_03e1;
																																case 55:
																																case 128:
																																	goto IL_03f9;
																																case 43:
																																	goto IL_0407;
																																case 89:
																																case 136:
																																	goto IL_0415;
																																case 87:
																																	goto IL_043e;
																																case 34:
																																case 138:
																																	goto IL_0457;
																																case 50:
																																	goto IL_0465;
																																case 32:
																																case 124:
																																	goto IL_0479;
																																case 47:
																																	goto IL_0490;
																																case 21:
																																case 125:
																																	goto IL_049e;
																																case 30:
																																	goto IL_04ac;
																																case 74:
																																case 134:
																																	goto IL_04c9;
																																case 0:
																																	goto IL_0508;
																																case 70:
																																	goto IL_051b;
																																case 13:
																																	goto IL_0529;
																																case 56:
																																case 66:
																																	goto IL_0537;
																																case 4:
																																	goto IL_0560;
																																case 105:
																																	goto IL_056e;
																																case 140:
																																	goto IL_0581;
																																case 68:
																																case 133:
																																	goto IL_058c;
																																case 103:
																																	goto IL_0597;
																																case 106:
																																case 116:
																																	goto IL_05a5;
																																case 54:
																																	goto IL_05be;
																																case 49:
																																	goto IL_05cc;
																																case 61:
																																	goto IL_05da;
																																case 48:
																																case 73:
																																	goto IL_05fb;
																																case 111:
																																	goto IL_063b;
																																case 23:
																																	goto IL_064f;
																																case 144:
																																	goto IL_0662;
																																case 58:
																																	goto IL_0670;
																																case 83:
																																	goto IL_068d;
																																case 35:
																																	goto IL_069b;
																																case 86:
																																	goto IL_06ae;
																																case 104:
																																	goto IL_06b9;
																																case 12:
																																case 52:
																																	goto IL_06c7;
																																case 69:
																																	goto IL_070b;
																																case 41:
																																	goto IL_071f;
																																case 22:
																																case 84:
																																	goto IL_0740;
																																case 100:
																																	goto IL_0780;
																																case 78:
																																	goto IL_0794;
																																case 5:
																																	goto IL_07a7;
																																case 36:
																																	goto IL_07b5;
																																case 80:
																																	goto IL_07c3;
																																case 18:
																																	goto IL_07d1;
																																case 51:
																																case 141:
																																	goto IL_07df;
																																case 98:
																																	goto IL_0841;
																																case 15:
																																case 20:
																																	goto IL_085a;
																																case 38:
																																	goto IL_087c;
																																case 37:
																																	goto IL_0887;
																																case 8:
																																case 14:
																																case 24:
																																case 27:
																																case 29:
																																case 31:
																																case 64:
																																case 67:
																																case 75:
																																case 76:
																																case 85:
																																case 92:
																																case 93:
																																case 94:
																																case 96:
																																case 101:
																																case 102:
																																case 108:
																																case 117:
																																case 120:
																																case 129:
																																case 130:
																																case 131:
																																case 137:
																																case 142:
																																	goto end_IL_030a;
																																case 9:
																																case 11:
																																case 26:
																																case 28:
																																case 40:
																																case 45:
																																case 53:
																																case 57:
																																case 60:
																																case 72:
																																case 82:
																																case 99:
																																case 107:
																																case 112:
																																case 114:
																																case 118:
																																case 122:
																																case 132:
																																	goto end_IL_026f;
																																case 115:
																																	goto end_IL_08ae;
																																case 62:
																																	goto end_IL_08c1;
																																case 81:
																																	goto end_IL_08cb;
																																case 33:
																																	goto end_IL_08d6;
																																case 65:
																																case 113:
																																	goto end_IL_08e6;
																																case 95:
																																	goto end_IL_08f6;
																																case 46:
																																case 123:
																																	goto end_IL_0906;
																																case 126:
																																	goto end_IL_0916;
																																case 127:
																																	goto end_IL_0926;
																																case 2:
																																case 139:
																																	goto IL_0941;
																																}
																																continue;
																															}
																															array2[num5] = null;
																															goto IL_068d;
																															IL_068d:
																															num5++;
																															goto IL_069b;
																															IL_069b:
																															ptr2 += 8;
																															break;
																															continue;
																															end_IL_026f:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0345;
																											IL_0353:
																											if (9 > b)
																											{
																												goto end_IL_030a;
																											}
																											break;
																											IL_0345:
																											if (9 < b)
																											{
																												goto end_IL_030a;
																											}
																											goto IL_0353;
																										}
																										break;
																									}
																									goto IL_06ae;
																									IL_071f:
																									num5--;
																									break;
																									IL_06ae:
																									if (11 < b)
																									{
																										num = 117;
																										goto end_IL_030a;
																									}
																									goto IL_06b9;
																									IL_06b9:
																									if (11 > b)
																									{
																										goto end_IL_030a;
																									}
																									goto IL_06c7;
																									IL_06c7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_070b;
																									IL_070b:
																									array[num5 - 2] = 0;
																									goto IL_071f;
																								}
																								break;
																							}
																							goto IL_0740;
																							IL_0794:
																							num5--;
																							break;
																							IL_0740:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0780;
																							IL_0780:
																							array[num5 - 2] = 0;
																							goto IL_0794;
																						}
																						break;
																					}
																					goto IL_07a7;
																					IL_087c:
																					if (15 < b)
																					{
																						goto end_IL_030a;
																					}
																					goto IL_0887;
																					IL_07a7:
																					if (14 >= b)
																					{
																						goto IL_07b5;
																					}
																					goto IL_087c;
																					IL_07b5:
																					if (14 > b)
																					{
																						goto IL_07c3;
																					}
																					num = 15;
																					goto IL_085a;
																					IL_07c3:
																					if (13 < b)
																					{
																						goto end_IL_030a;
																					}
																					goto IL_07d1;
																					IL_07d1:
																					if (13 > b)
																					{
																						goto end_IL_030a;
																					}
																					goto IL_07df;
																					IL_07df:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0841;
																					IL_0841:
																					num5 -= 2;
																					break;
																					IL_0887:
																					if (15 <= b)
																					{
																						num = 129;
																					}
																					goto end_IL_030a;
																					IL_085a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 112;
																					break;
																				}
																				break;
																			}
																			goto IL_0366;
																			IL_0529:
																			if (7 > b)
																			{
																				goto end_IL_030a;
																			}
																			goto IL_0537;
																			IL_0366:
																			if (8 > b)
																			{
																				goto IL_0371;
																			}
																			goto IL_03e1;
																			IL_0371:
																			if (4 >= b)
																			{
																				goto IL_037c;
																			}
																			num = 138;
																			goto IL_0457;
																			IL_037c:
																			if (4 <= b)
																			{
																				goto IL_0387;
																			}
																			goto IL_03c6;
																			IL_0387:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_03a5;
																			IL_03a5:
																			ptr2 += 8;
																			goto IL_03b3;
																			IL_03b3:
																			num5--;
																			break;
																			IL_03c6:
																			if (2 < b)
																			{
																				goto IL_03f9;
																			}
																			goto IL_0581;
																			IL_03f9:
																			if (3 < b)
																			{
																				goto end_IL_030a;
																			}
																			goto IL_0407;
																			IL_0407:
																			if (3 > b)
																			{
																				goto end_IL_030a;
																			}
																			goto IL_0415;
																			IL_0415:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_043e;
																			IL_043e:
																			array[num5 - 1] = 5;
																			break;
																			IL_0581:
																			if (2 > b)
																			{
																				goto IL_058c;
																			}
																			goto IL_05fb;
																			IL_058c:
																			if (1 < b)
																			{
																				num = 142;
																				goto end_IL_030a;
																			}
																			goto IL_0597;
																			IL_0597:
																			if (1 > b)
																			{
																				goto end_IL_030a;
																			}
																			goto IL_05a5;
																			IL_05a5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_05be;
																			IL_05be:
																			array[num5] = 0;
																			goto IL_05cc;
																			IL_05cc:
																			num5++;
																			goto IL_05da;
																			IL_05da:
																			ptr2 += 8;
																			break;
																			IL_0560:
																			ptr2 += 8;
																			goto IL_056e;
																			IL_05fb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_063b;
																			IL_063b:
																			array[num5 - 2] = 0;
																			goto IL_064f;
																			IL_064f:
																			num5--;
																			break;
																			IL_0537:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0560;
																			IL_0457:
																			if (6 >= b)
																			{
																				goto IL_0465;
																			}
																			goto IL_051b;
																			IL_0465:
																			if (6 > b)
																			{
																				num = 32;
																				goto IL_0479;
																			}
																			goto IL_04c9;
																			IL_056e:
																			num5--;
																			break;
																			IL_0479:
																			if (5 < b)
																			{
																				goto end_IL_030a;
																			}
																			num = 47;
																			goto IL_0490;
																			IL_03e1:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0490:
																			if (5 > b)
																			{
																				goto end_IL_030a;
																			}
																			goto IL_049e;
																			IL_049e:
																			array[num5] = 5;
																			goto IL_04ac;
																			IL_04ac:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0662;
																			IL_0662:
																			num5++;
																			goto IL_0670;
																			IL_0670:
																			ptr2 += 8;
																			break;
																			IL_04c9:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0508;
																			IL_0508:
																			num5 -= 3;
																			break;
																			IL_051b:
																			if (7 < b)
																			{
																				goto end_IL_030a;
																			}
																			goto IL_0529;
																		}
																		goto end_IL_031a;
																		continue;
																		end_IL_030a:
																		break;
																		IL_030a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_031a:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0941;
												IL_0941:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08ae:
												break;
											}
											continue;
											end_IL_08c1:
											break;
										}
										continue;
										end_IL_08cb:
										break;
									}
									continue;
									end_IL_08d6:
									break;
								}
								continue;
								end_IL_08e6:
								break;
							}
							continue;
							end_IL_08f6:
							break;
						}
						continue;
						end_IL_0906:
						break;
					}
					continue;
					end_IL_0916:
					break;
				}
				continue;
				end_IL_0926:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 5;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 20;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										num = 121;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetGenericTypeDefinitionAssemblyNameProxy.SideBySidegetDoNotAddrOfCspParentWindowHandle);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02f9:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02dc:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02cf:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02bf:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02ac:
																										if (6 < b)
																										{
																											num = 159;
																											while (true)
																											{
																												if (num != 159)
																												{
																													if (num != 1140)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 84:
																													case 142:
																														goto IL_02ac;
																													case 137:
																														goto IL_02bf;
																													case 89:
																														goto IL_02cf;
																													case 31:
																														goto IL_02dc;
																													case 8:
																														goto end_IL_02dc;
																													case 54:
																														goto IL_02f9;
																													case 34:
																														goto end_IL_02f9;
																													case 50:
																													case 91:
																														goto end_IL_0309;
																													case 38:
																													case 52:
																														goto IL_0332;
																													case 41:
																													case 43:
																														goto IL_033d;
																													case 25:
																														goto IL_034b;
																													case 1:
																														goto IL_0359;
																													case 18:
																														goto IL_036c;
																													case 3:
																													case 63:
																														goto IL_037a;
																													case 60:
																														goto IL_0385;
																													case 35:
																														goto IL_03a1;
																													case 26:
																														goto IL_03ac;
																													case 24:
																														goto IL_03ba;
																													case 67:
																													case 76:
																														goto IL_03cd;
																													case 90:
																														goto IL_03e0;
																													case 0:
																													case 55:
																														goto end_IL_0299;
																													case 10:
																														goto IL_03f9;
																													case 42:
																													case 66:
																														goto IL_040c;
																													case 95:
																														goto IL_0428;
																													case 14:
																													case 27:
																														goto IL_0436;
																													case 80:
																														goto IL_047a;
																													case 51:
																														goto IL_048e;
																													case 99:
																														goto IL_04a1;
																													case 36:
																														goto IL_04c4;
																													case 69:
																														goto IL_04ce;
																													case 39:
																													case 108:
																														goto IL_04e1;
																													case 7:
																														goto IL_0543;
																													case 79:
																													case 109:
																														goto IL_0556;
																													case 120:
																														goto IL_0598;
																													case 29:
																													case 113:
																														goto IL_05a3;
																													case 85:
																														goto IL_05b1;
																													case 119:
																													case 125:
																														goto IL_05c1;
																													case 110:
																														goto IL_0600;
																													case 134:
																														goto IL_0613;
																													case 135:
																														goto IL_0627;
																													case 19:
																													case 136:
																														goto IL_063a;
																													case 139:
																														goto IL_064a;
																													case 118:
																													case 145:
																														goto IL_065d;
																													case 151:
																														goto IL_0675;
																													case 133:
																														goto IL_068d;
																													case 45:
																														goto IL_069b;
																													case 107:
																														goto IL_06ae;
																													case 33:
																														goto IL_06bc;
																													case 74:
																													case 75:
																														goto IL_06ca;
																													case 70:
																														goto IL_06f3;
																													case 82:
																														goto IL_070a;
																													case 132:
																														goto IL_071d;
																													case 47:
																													case 101:
																														goto IL_0728;
																													case 117:
																														goto IL_0746;
																													case 48:
																														goto IL_0754;
																													case 144:
																														goto IL_0767;
																													case 72:
																													case 96:
																														goto IL_0772;
																													case 102:
																														goto IL_0780;
																													case 56:
																													case 124:
																														goto IL_078e;
																													case 122:
																														goto IL_07b7;
																													case 23:
																														goto IL_07d0;
																													case 61:
																														goto IL_07db;
																													case 152:
																														goto IL_07e9;
																													case 22:
																													case 49:
																														goto IL_07f7;
																													case 9:
																														goto IL_0810;
																													case 111:
																														goto IL_081e;
																													case 88:
																														goto IL_082c;
																													case 28:
																													case 106:
																														goto IL_0848;
																													case 65:
																														goto IL_0888;
																													case 105:
																														goto IL_089c;
																													case 2:
																													case 13:
																													case 15:
																													case 17:
																													case 30:
																													case 32:
																													case 37:
																													case 44:
																													case 53:
																													case 57:
																													case 59:
																													case 62:
																													case 64:
																													case 78:
																													case 81:
																													case 83:
																													case 87:
																													case 92:
																													case 93:
																													case 97:
																													case 103:
																													case 104:
																													case 114:
																													case 115:
																													case 123:
																													case 127:
																													case 128:
																													case 129:
																													case 131:
																													case 141:
																													case 147:
																														goto end_IL_02e9;
																													case 11:
																													case 16:
																													case 21:
																													case 40:
																													case 68:
																													case 77:
																													case 86:
																													case 94:
																													case 100:
																													case 112:
																													case 126:
																													case 130:
																													case 138:
																													case 140:
																													case 143:
																													case 146:
																													case 148:
																													case 149:
																														goto end_IL_0319;
																													case 12:
																														goto end_IL_08bf;
																													case 121:
																														goto end_IL_08d2;
																													case 46:
																														goto end_IL_08dc;
																													case 116:
																														goto end_IL_08e7;
																													case 20:
																														goto end_IL_0900;
																													case 58:
																														goto end_IL_0910;
																													case 73:
																														goto end_IL_0920;
																													case 71:
																													case 150:
																														goto end_IL_092b;
																													case 4:
																														goto end_IL_093b;
																													case 5:
																														goto end_IL_094b;
																													case 6:
																													case 98:
																														goto IL_0966;
																													}
																													continue;
																												}
																												goto IL_06ae;
																												IL_06f3:
																												ptr2 += 8;
																												num = 82;
																												goto IL_070a;
																												IL_070a:
																												num5--;
																												goto end_IL_0319;
																												IL_06ae:
																												if (7 < b)
																												{
																													goto end_IL_02e9;
																												}
																												goto IL_06bc;
																												IL_06bc:
																												if (7 > b)
																												{
																													goto end_IL_02e9;
																												}
																												goto IL_06ca;
																												IL_06ca:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_06f3;
																												continue;
																												end_IL_0299:
																												break;
																											}
																											break;
																										}
																										goto IL_0598;
																										IL_05c1:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0600;
																										IL_0600:
																										num5 -= 3;
																										goto end_IL_0319;
																										IL_0598:
																										if (6 > b)
																										{
																											goto IL_05a3;
																										}
																										goto IL_05c1;
																										IL_05a3:
																										if (5 < b)
																										{
																											goto end_IL_02e9;
																										}
																										goto IL_05b1;
																										IL_05b1:
																										if (5 > b)
																										{
																											goto end_IL_02e9;
																										}
																										goto IL_063a;
																										IL_063a:
																										array[num5] = 5;
																										goto IL_0675;
																										IL_0675:
																										array2[num5] = array5[*(int*)(ptr2 + num3)];
																										goto IL_068d;
																										IL_068d:
																										num5++;
																										goto IL_069b;
																										IL_069b:
																										ptr2 += 8;
																										goto end_IL_0319;
																									}
																									break;
																								}
																								goto IL_071d;
																								IL_0888:
																								array[num5 - 2] = 0;
																								goto IL_089c;
																								IL_071d:
																								if (4 <= b)
																								{
																									goto IL_0728;
																								}
																								goto IL_0767;
																								IL_0728:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_0746;
																								IL_0746:
																								ptr2 += 8;
																								goto IL_0754;
																								IL_0754:
																								num5--;
																								goto end_IL_0319;
																								IL_0767:
																								if (2 < b)
																								{
																									goto IL_0772;
																								}
																								goto IL_07d0;
																								IL_0772:
																								if (3 < b)
																								{
																									goto end_IL_02e9;
																								}
																								goto IL_0780;
																								IL_0780:
																								if (3 > b)
																								{
																									goto end_IL_02e9;
																								}
																								goto IL_078e;
																								IL_078e:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_07b7;
																								IL_07b7:
																								array[num5 - 1] = 5;
																								goto end_IL_0319;
																								IL_07d0:
																								if (2 > b)
																								{
																									goto IL_07db;
																								}
																								num = 28;
																								goto IL_0848;
																								IL_07db:
																								if (1 < b)
																								{
																									goto end_IL_02e9;
																								}
																								goto IL_07e9;
																								IL_07e9:
																								if (1 > b)
																								{
																									goto end_IL_02e9;
																								}
																								goto IL_07f7;
																								IL_07f7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0810;
																								IL_0810:
																								array[num5] = 0;
																								goto IL_081e;
																								IL_081e:
																								num5++;
																								goto IL_082c;
																								IL_082c:
																								ptr2 += 8;
																								goto end_IL_0319;
																								IL_089c:
																								num5--;
																								goto end_IL_0319;
																								IL_0848:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0888;
																							}
																							break;
																						}
																						num = 118;
																						goto IL_065d;
																						IL_065d:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0319;
																					}
																					goto IL_03eb;
																				}
																				goto IL_0332;
																				IL_0613:
																				array[num5 - 2] = 0;
																				goto IL_0627;
																				IL_0332:
																				if (12 < b)
																				{
																					goto IL_033d;
																				}
																				goto IL_036c;
																				IL_033d:
																				if (14 < b)
																				{
																					goto IL_034b;
																				}
																				goto IL_03e0;
																				IL_034b:
																				if (15 < b)
																				{
																					goto end_IL_02e9;
																				}
																				goto IL_0359;
																				IL_0359:
																				if (15 <= b)
																				{
																				}
																				goto end_IL_02e9;
																				IL_03e0:
																				if (14 > b)
																				{
																					goto IL_03eb;
																				}
																				goto IL_040c;
																				IL_03eb:
																				if (13 < b)
																				{
																					goto end_IL_02e9;
																				}
																				goto IL_03f9;
																				IL_03f9:
																				if (13 > b)
																				{
																					goto end_IL_02e9;
																				}
																				goto IL_04e1;
																				IL_04e1:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0543;
																				IL_0543:
																				num5 -= 2;
																				goto end_IL_0319;
																				IL_040c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0319;
																				IL_036c:
																				if (12 > b)
																				{
																					goto IL_037a;
																				}
																				goto IL_0556;
																				IL_037a:
																				if (10 < b)
																				{
																					goto IL_0385;
																				}
																				num = 35;
																				goto IL_03a1;
																				IL_0385:
																				if (11 < b)
																				{
																					goto end_IL_02e9;
																				}
																				goto IL_0428;
																				IL_0428:
																				if (11 > b)
																				{
																					goto end_IL_02e9;
																				}
																				goto IL_0436;
																				IL_0436:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_047a;
																				IL_047a:
																				array[num5 - 2] = 0;
																				goto IL_048e;
																				IL_048e:
																				num5--;
																				goto end_IL_0319;
																				IL_0627:
																				num5--;
																				goto end_IL_0319;
																				IL_03a1:
																				if (10 > b)
																				{
																					goto IL_03ac;
																				}
																				goto IL_03cd;
																				IL_03ac:
																				if (9 < b)
																				{
																					goto end_IL_02e9;
																				}
																				goto IL_03ba;
																				IL_03ba:
																				if (9 <= b)
																				{
																					goto end_IL_0319;
																				}
																				goto end_IL_02e9;
																				IL_03cd:
																				array[num5] = 0;
																				goto IL_04a1;
																				IL_04a1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04c4;
																				IL_04c4:
																				array2[num5] = null;
																				goto IL_04ce;
																				IL_04ce:
																				num5++;
																				goto IL_064a;
																				IL_064a:
																				ptr2 += 8;
																				goto end_IL_0319;
																				IL_0556:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0613;
																				continue;
																				end_IL_02dc:
																				break;
																			}
																			continue;
																			end_IL_02e9:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0319;
																	continue;
																	end_IL_02f9:
																	break;
																}
																continue;
																end_IL_0309:
																break;
															}
															continue;
															end_IL_0319:
															break;
														}
														continue;
													}
													goto IL_0966;
													IL_0966:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08bf:
													break;
												}
												continue;
												end_IL_08d2:
												break;
											}
											continue;
											end_IL_08dc:
											break;
										}
										continue;
										end_IL_08e7:
										break;
									}
									continue;
									end_IL_0900:
									break;
								}
								continue;
								end_IL_0910:
								break;
							}
							continue;
							end_IL_0920:
							break;
						}
						continue;
						end_IL_092b:
						break;
					}
					continue;
					end_IL_093b:
					break;
				}
				continue;
				end_IL_094b:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0)
	{
		int num = 43;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreateFromUrlgetResponseXmlElementName.MarshalDirectiveExceptionSchemaVersion);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_028b:
														byte b = *ptr2;
														while (true)
														{
															IL_027b:
															ptr2++;
															while (true)
															{
																IL_026b:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_024b:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_023e:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_022e:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_021e:
																									if (2 <= b)
																									{
																										while (true)
																										{
																											IL_01ea:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 114;
																											while (true)
																											{
																												if (num != 114)
																												{
																													if (num != 1095)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 74:
																													case 81:
																														goto IL_01ea;
																													case 91:
																														goto IL_021e;
																													case 20:
																														goto IL_022e;
																													case 5:
																														goto IL_023e;
																													case 105:
																														goto IL_024b;
																													case 6:
																														goto IL_025b;
																													case 95:
																														goto IL_026b;
																													case 72:
																														goto IL_027b;
																													case 28:
																													case 33:
																														goto IL_028b;
																													case 14:
																													case 80:
																														goto IL_0296;
																													case 84:
																														goto IL_02a4;
																													case 25:
																														goto IL_02c7;
																													case 76:
																														goto IL_02d1;
																													case 54:
																														goto IL_02df;
																													case 49:
																													case 96:
																														goto IL_02f2;
																													case 88:
																														goto IL_02fd;
																													case 37:
																													case 75:
																														goto IL_030b;
																													case 58:
																														goto IL_0324;
																													case 27:
																														goto IL_0332;
																													case 90:
																														goto IL_0340;
																													case 29:
																														goto IL_0378;
																													case 89:
																														goto IL_038b;
																													case 10:
																													case 32:
																														goto IL_0396;
																													case 64:
																														goto IL_03a4;
																													case 82:
																														goto IL_03c0;
																													case 30:
																													case 31:
																														goto IL_03ce;
																													case 41:
																														goto IL_03e6;
																													case 3:
																														goto IL_03f1;
																													case 12:
																														goto IL_03fc;
																													case 7:
																													case 59:
																														goto IL_040a;
																													case 61:
																														goto IL_0426;
																													case 17:
																														goto IL_0434;
																													case 44:
																														goto IL_0450;
																													case 9:
																													case 97:
																														goto IL_045e;
																													case 86:
																														goto IL_046c;
																													case 8:
																													case 77:
																														goto IL_0477;
																													case 47:
																														goto IL_04b7;
																													case 16:
																														goto IL_04cb;
																													case 2:
																													case 69:
																														goto IL_04ec;
																													case 92:
																														goto IL_04fa;
																													case 106:
																													case 107:
																														goto IL_0508;
																													case 36:
																														goto IL_052b;
																													case 79:
																														goto IL_0539;
																													case 87:
																														goto IL_0547;
																													case 4:
																													case 63:
																														goto IL_0563;
																													case 51:
																														goto IL_05ce;
																													case 1:
																													case 11:
																													case 18:
																													case 22:
																													case 23:
																													case 26:
																													case 34:
																													case 38:
																													case 40:
																													case 46:
																													case 50:
																													case 53:
																													case 57:
																													case 65:
																													case 67:
																													case 83:
																													case 93:
																													case 94:
																													case 100:
																													case 101:
																													case 102:
																													case 103:
																													case 104:
																														goto end_IL_025b;
																													case 19:
																													case 39:
																													case 45:
																													case 48:
																													case 55:
																													case 60:
																													case 62:
																													case 66:
																													case 68:
																													case 70:
																													case 71:
																													case 73:
																													case 78:
																														goto end_IL_01d7;
																													case 13:
																														goto end_IL_05f1;
																													case 35:
																														goto end_IL_0604;
																													case 21:
																														goto end_IL_060e;
																													case 52:
																														goto end_IL_0619;
																													case 56:
																													case 98:
																														goto end_IL_062e;
																													case 0:
																														goto end_IL_063e;
																													case 15:
																													case 24:
																														goto end_IL_064e;
																													case 42:
																														goto end_IL_065e;
																													case 43:
																														goto end_IL_066e;
																													case 85:
																													case 99:
																														goto IL_0689;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												num = 29;
																												goto IL_0378;
																												IL_0378:
																												num5--;
																												break;
																												continue;
																												end_IL_01d7:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_02f2;
																									IL_0340:
																									ptr2 += 8;
																									break;
																									IL_02f2:
																									if (1 < b)
																									{
																										num = 50;
																										goto end_IL_025b;
																									}
																									goto IL_02fd;
																									IL_02fd:
																									if (1 > b)
																									{
																										goto end_IL_025b;
																									}
																									goto IL_030b;
																									IL_030b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0324;
																									IL_0324:
																									array[num5] = 0;
																									goto IL_0332;
																									IL_0332:
																									num5++;
																									goto IL_0340;
																								}
																								break;
																							}
																							goto IL_038b;
																							IL_03c0:
																							if (3 > b)
																							{
																								goto end_IL_025b;
																							}
																							goto IL_03ce;
																							IL_038b:
																							if (3 < b)
																							{
																								goto IL_0396;
																							}
																							goto IL_03c0;
																							IL_0396:
																							if (4 < b)
																							{
																								goto end_IL_025b;
																							}
																							goto IL_03a4;
																							IL_03a4:
																							if (4 <= b)
																							{
																								break;
																							}
																							num = 53;
																							goto end_IL_025b;
																							IL_03ce:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																						}
																						break;
																					}
																					goto IL_0296;
																					IL_02df:
																					ptr2 += 8;
																					break;
																					IL_0296:
																					array[num5] = 0;
																					goto IL_02a4;
																					IL_02a4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_02c7;
																					IL_02c7:
																					array2[num5] = null;
																					goto IL_02d1;
																					IL_02d1:
																					num5++;
																					goto IL_02df;
																				}
																				break;
																			}
																			goto IL_03e6;
																			IL_0547:
																			ptr2 += 8;
																			num = 66;
																			break;
																			IL_03e6:
																			if (8 < b)
																			{
																				goto IL_03f1;
																			}
																			num = 44;
																			goto IL_0450;
																			IL_03f1:
																			if (9 >= b)
																			{
																				goto IL_03fc;
																			}
																			goto IL_0426;
																			IL_03fc:
																			if (9 > b)
																			{
																				goto end_IL_025b;
																			}
																			goto IL_040a;
																			IL_040a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0426:
																			if (10 < b)
																			{
																				goto end_IL_025b;
																			}
																			goto IL_0434;
																			IL_0434:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_025b;
																			IL_0563:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 51;
																			goto IL_05ce;
																			IL_0450:
																			if (8 > b)
																			{
																				goto IL_045e;
																			}
																			goto IL_0563;
																			IL_045e:
																			if (6 >= b)
																			{
																				goto IL_046c;
																			}
																			goto IL_04ec;
																			IL_046c:
																			if (6 > b)
																			{
																				num = 38;
																				goto end_IL_025b;
																			}
																			goto IL_0477;
																			IL_0477:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b7;
																			IL_04b7:
																			array[num5 - 2] = 0;
																			goto IL_04cb;
																			IL_04cb:
																			num5--;
																			break;
																			IL_05ce:
																			num5 -= 2;
																			break;
																			IL_04ec:
																			if (7 < b)
																			{
																				goto end_IL_025b;
																			}
																			goto IL_04fa;
																			IL_04fa:
																			if (7 > b)
																			{
																				goto end_IL_025b;
																			}
																			goto IL_0508;
																			IL_0508:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_052b;
																			IL_052b:
																			array[num5] = 0;
																			goto IL_0539;
																			IL_0539:
																			num5++;
																			goto IL_0547;
																		}
																		goto end_IL_026b;
																		continue;
																		end_IL_025b:
																		break;
																		IL_025b:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_026b:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0689;
												IL_0689:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f1:
												break;
											}
											continue;
											end_IL_0604:
											break;
										}
										continue;
										end_IL_060e:
										break;
									}
									continue;
									end_IL_0619:
									break;
								}
								continue;
								end_IL_062e:
								break;
							}
							continue;
							end_IL_063e:
							break;
						}
						continue;
						end_IL_064e:
						break;
					}
					continue;
					end_IL_065e:
					break;
				}
				continue;
				end_IL_066e:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0, int int_1)
	{
		int num = 49;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 61;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetLocalValueUriMarshaler.ReceiveLanguage);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0291:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			if (b <= 9)
																			{
																				while (true)
																				{
																					if (5 >= b)
																					{
																						while (true)
																						{
																							if (5 > b)
																							{
																								while (true)
																								{
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_0247:
																											if (2 <= b)
																											{
																												while (true)
																												{
																													IL_0205:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_01e6:
																														array[num5 - 2] = 0;
																														num = 113;
																														while (true)
																														{
																															if (num != 113)
																															{
																																if (num != 1094)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 69:
																																	goto IL_01e6;
																																case 33:
																																case 73:
																																	goto IL_0205;
																																case 100:
																																	goto IL_0247;
																																case 50:
																																case 53:
																																	goto end_IL_01d3;
																																case 1:
																																	goto end_IL_0257;
																																case 85:
																																	goto end_IL_0267;
																																case 16:
																																	goto end_IL_0277;
																																case 51:
																																	goto IL_0291;
																																case 13:
																																	goto end_IL_0291;
																																case 10:
																																case 24:
																																	goto end_IL_02a1;
																																case 23:
																																case 29:
																																	goto IL_02ca;
																																case 28:
																																	goto IL_02d5;
																																case 40:
																																case 46:
																																	goto IL_02e5;
																																case 57:
																																	goto IL_02f2;
																																case 62:
																																	goto IL_0302;
																																case 65:
																																	goto IL_0315;
																																case 63:
																																	goto IL_0320;
																																case 36:
																																	goto IL_033c;
																																case 26:
																																case 66:
																																	goto IL_034f;
																																case 80:
																																	goto IL_0362;
																																case 37:
																																case 87:
																																	goto IL_0375;
																																case 74:
																																	goto IL_0383;
																																case 42:
																																case 88:
																																	goto IL_0396;
																																case 15:
																																	goto IL_03d6;
																																case 47:
																																	goto IL_03ea;
																																case 17:
																																case 92:
																																	goto IL_03fd;
																																case 83:
																																	goto IL_0416;
																																case 84:
																																	goto IL_0424;
																																case 27:
																																	goto IL_0432;
																																case 97:
																																	goto IL_0445;
																																case 12:
																																case 56:
																																	goto IL_0453;
																																case 78:
																																	goto IL_0493;
																																case 8:
																																	goto IL_04a7;
																																case 99:
																																	goto IL_04ba;
																																case 76:
																																case 81:
																																	goto IL_04d1;
																																case 70:
																																case 103:
																																	goto IL_04ed;
																																case 54:
																																	goto IL_0516;
																																case 2:
																																	goto IL_052d;
																																case 18:
																																case 104:
																																	goto IL_0540;
																																case 22:
																																	goto IL_0580;
																																case 60:
																																	goto IL_0594;
																																case 0:
																																case 3:
																																case 5:
																																case 9:
																																case 19:
																																case 20:
																																case 21:
																																case 35:
																																case 55:
																																case 58:
																																case 67:
																																case 72:
																																case 77:
																																case 82:
																																case 89:
																																case 93:
																																case 95:
																																case 96:
																																case 106:
																																	goto end_IL_0284;
																																case 6:
																																	goto IL_05ca;
																																case 31:
																																	goto IL_05d8;
																																case 4:
																																	goto IL_05e6;
																																case 30:
																																case 68:
																																	goto IL_0606;
																																case 34:
																																	goto IL_061d;
																																case 45:
																																	goto IL_0640;
																																case 39:
																																	goto IL_064a;
																																case 44:
																																	goto IL_0658;
																																case 7:
																																case 11:
																																case 14:
																																case 25:
																																case 59:
																																case 64:
																																case 71:
																																case 90:
																																case 91:
																																case 101:
																																case 102:
																																	goto end_IL_02b1;
																																case 32:
																																	goto end_IL_0666;
																																case 43:
																																	goto end_IL_0679;
																																case 98:
																																	goto end_IL_0683;
																																case 105:
																																	goto end_IL_068e;
																																case 41:
																																	goto end_IL_06a3;
																																case 38:
																																case 79:
																																	goto end_IL_06b8;
																																case 86:
																																	goto end_IL_06c8;
																																case 52:
																																case 61:
																																	goto end_IL_06d8;
																																case 48:
																																	goto end_IL_06e8;
																																case 49:
																																	goto end_IL_06f8;
																																case 75:
																																case 94:
																																	goto IL_071c;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_02b1;
																															continue;
																															end_IL_01d3:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0375;
																											IL_0383:
																											if (1 <= b)
																											{
																											}
																											goto end_IL_0284;
																											IL_0375:
																											if (1 < b)
																											{
																												goto end_IL_0284;
																											}
																											goto IL_0383;
																										}
																										continue;
																									}
																									goto IL_0315;
																									IL_0493:
																									array[num5 - 2] = 0;
																									goto IL_04a7;
																									IL_0315:
																									if (3 >= b)
																									{
																										goto IL_0320;
																									}
																									goto IL_033c;
																									IL_0320:
																									if (3 > b)
																									{
																										num = 95;
																										goto end_IL_0284;
																									}
																									goto IL_04ed;
																									IL_04a7:
																									num5--;
																									goto end_IL_02b1;
																									IL_04ed:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0516;
																									IL_0516:
																									ptr2 += 8;
																									num = 2;
																									goto IL_052d;
																									IL_052d:
																									num5--;
																									goto end_IL_02b1;
																									IL_033c:
																									if (4 < b)
																									{
																										goto end_IL_0284;
																									}
																									goto IL_0445;
																									IL_0445:
																									if (4 > b)
																									{
																										goto end_IL_0284;
																									}
																									goto IL_0453;
																									IL_0453:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0493;
																									continue;
																									end_IL_0257:
																									break;
																								}
																								continue;
																							}
																							goto IL_0606;
																							IL_0658:
																							ptr2 += 8;
																							goto end_IL_02b1;
																							IL_0606:
																							array[num5] = 0;
																							num = 34;
																							goto IL_061d;
																							IL_061d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0640;
																							IL_0640:
																							array2[num5] = null;
																							goto IL_064a;
																							IL_064a:
																							num5++;
																							goto IL_0658;
																							continue;
																							end_IL_0267:
																							break;
																						}
																						continue;
																					}
																					goto IL_02ca;
																					IL_03d6:
																					array[num5 - 2] = 0;
																					goto IL_03ea;
																					IL_02ca:
																					if (7 >= b)
																					{
																						goto IL_02d5;
																					}
																					goto IL_02e5;
																					IL_02d5:
																					if (7 > b)
																					{
																						goto IL_02f2;
																					}
																					goto IL_03fd;
																					IL_03fd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0416;
																					IL_0416:
																					array[num5] = 0;
																					goto IL_0424;
																					IL_0424:
																					num5++;
																					goto IL_0432;
																					IL_0432:
																					ptr2 += 8;
																					goto end_IL_02b1;
																					IL_02f2:
																					if (6 < b)
																					{
																						goto end_IL_0284;
																					}
																					goto IL_0362;
																					IL_0362:
																					if (6 > b)
																					{
																						goto end_IL_0284;
																					}
																					goto IL_0540;
																					IL_0540:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0580;
																					IL_0580:
																					array[num5 - 2] = 0;
																					goto IL_0594;
																					IL_0594:
																					num5--;
																					goto end_IL_02b1;
																					IL_02e5:
																					if (8 >= b)
																					{
																						goto IL_0302;
																					}
																					goto IL_034f;
																					IL_034f:
																					if (9 < b)
																					{
																						goto end_IL_0284;
																					}
																					goto IL_04ba;
																					IL_04ba:
																					if (9 > b)
																					{
																						goto end_IL_0284;
																					}
																					num = 81;
																					goto IL_04d1;
																					IL_03ea:
																					num5--;
																					goto end_IL_02b1;
																					IL_04d1:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02b1;
																					IL_0302:
																					if (8 > b)
																					{
																						goto end_IL_0284;
																					}
																					goto IL_0396;
																					IL_0396:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03d6;
																					continue;
																					end_IL_0277:
																					break;
																				}
																				continue;
																			}
																			num = 77;
																			break;
																			continue;
																			end_IL_0284:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05ca;
																	IL_05e6:
																	ptr2 += 8;
																	goto end_IL_02b1;
																	IL_05d8:
																	num5++;
																	goto IL_05e6;
																	IL_05ca:
																	array[num5] = 0;
																	goto IL_05d8;
																	continue;
																	end_IL_0291:
																	break;
																}
																continue;
																end_IL_02a1:
																break;
															}
															continue;
															end_IL_02b1:
															break;
														}
														continue;
													}
													goto IL_071c;
													IL_071c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0666:
													break;
												}
												continue;
												end_IL_0679:
												break;
											}
											continue;
											end_IL_0683:
											break;
										}
										continue;
										end_IL_068e:
										break;
									}
									continue;
									end_IL_06a3:
									break;
								}
								continue;
								end_IL_06b8:
								break;
							}
							continue;
							end_IL_06c8:
							break;
						}
						continue;
						end_IL_06d8:
						break;
					}
					continue;
					end_IL_06e8:
					break;
				}
				continue;
				end_IL_06f8:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 140;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VTCFgetHostExecutionContextManager.PrivateImplementationDetailsCreationTimeUtc);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0310:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02f0:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02e0:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02d0:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02c0:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_02b3:
																											if (6 > b)
																											{
																												while (5 >= b)
																												{
																													num = 156;
																													while (true)
																													{
																														if (num != 156)
																														{
																															if (num != 1137)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 124:
																																goto IL_02a0;
																															case 48:
																																goto IL_02b3;
																															case 102:
																															case 104:
																																goto IL_02c0;
																															case 42:
																															case 146:
																																goto IL_02d0;
																															case 3:
																																goto IL_02e0;
																															case 28:
																																goto IL_02f0;
																															case 121:
																																goto IL_0300;
																															case 1:
																																goto IL_0310;
																															case 33:
																																goto end_IL_0310;
																															case 8:
																															case 61:
																																goto end_IL_0320;
																															case 6:
																															case 109:
																																goto IL_033b;
																															case 14:
																																goto IL_037a;
																															case 10:
																															case 110:
																																goto IL_038d;
																															case 67:
																																goto IL_0398;
																															case 68:
																															case 101:
																																goto IL_03a3;
																															case 91:
																																goto IL_03e8;
																															case 127:
																																goto IL_03f8;
																															case 17:
																																goto IL_0403;
																															case 43:
																															case 64:
																																goto IL_040e;
																															case 119:
																																goto IL_041c;
																															case 60:
																															case 126:
																																goto IL_042f;
																															case 77:
																																goto IL_0454;
																															case 16:
																																goto IL_0462;
																															case 21:
																															case 131:
																																goto IL_0475;
																															case 108:
																																goto IL_0483;
																															case 139:
																																goto IL_0493;
																															case 100:
																															case 142:
																																goto IL_04a9;
																															case 137:
																																goto IL_04ed;
																															case 88:
																																goto IL_050a;
																															case 144:
																																goto IL_051d;
																															case 145:
																																goto IL_0530;
																															case 30:
																															case 41:
																																goto IL_053b;
																															case 96:
																																goto IL_0549;
																															case 25:
																															case 125:
																																goto IL_055c;
																															case 22:
																																goto IL_056a;
																															case 94:
																																goto IL_058d;
																															case 134:
																																goto IL_0597;
																															case 107:
																																goto IL_05a5;
																															case 128:
																															case 149:
																																goto IL_05c1;
																															case 98:
																																goto IL_0623;
																															case 50:
																															case 113:
																																goto IL_0644;
																															case 31:
																																goto IL_0652;
																															case 111:
																																goto IL_066a;
																															case 23:
																																goto IL_0678;
																															case 95:
																																goto IL_068b;
																															case 54:
																																goto IL_0699;
																															case 13:
																															case 90:
																																goto IL_06a7;
																															case 56:
																																goto IL_06d0;
																															case 63:
																																goto IL_06de;
																															case 65:
																																goto IL_06f1;
																															case 40:
																																goto IL_06ff;
																															case 20:
																																goto IL_070a;
																															case 76:
																																goto IL_0718;
																															case 81:
																															case 141:
																																goto IL_0726;
																															case 57:
																																goto IL_074f;
																															case 29:
																																goto IL_0768;
																															case 82:
																															case 118:
																																goto IL_0773;
																															case 72:
																																goto IL_0781;
																															case 5:
																															case 12:
																																goto IL_078f;
																															case 133:
																																goto IL_07a8;
																															case 58:
																																goto IL_07b6;
																															case 138:
																																goto IL_07c4;
																															case 51:
																															case 70:
																																goto IL_07d7;
																															case 36:
																																goto IL_0817;
																															case 132:
																																goto IL_082b;
																															case 83:
																															case 92:
																																goto IL_083b;
																															case 39:
																																goto IL_0859;
																															case 55:
																																goto IL_0870;
																															case 44:
																															case 123:
																																goto IL_0889;
																															case 0:
																															case 2:
																															case 7:
																															case 11:
																															case 18:
																															case 19:
																															case 32:
																															case 35:
																															case 37:
																															case 38:
																															case 47:
																															case 49:
																															case 52:
																															case 53:
																															case 59:
																															case 71:
																															case 80:
																															case 87:
																															case 89:
																															case 93:
																															case 97:
																															case 99:
																															case 114:
																															case 120:
																															case 129:
																															case 135:
																															case 136:
																															case 147:
																															case 148:
																																goto end_IL_028d;
																															case 4:
																															case 9:
																															case 24:
																															case 26:
																															case 27:
																															case 34:
																															case 45:
																															case 46:
																															case 62:
																															case 69:
																															case 79:
																															case 85:
																															case 86:
																															case 105:
																															case 112:
																															case 116:
																															case 117:
																															case 143:
																																goto end_IL_0330;
																															case 15:
																																goto end_IL_08b1;
																															case 140:
																																goto end_IL_08c4;
																															case 115:
																																goto end_IL_08ce;
																															case 130:
																																goto end_IL_08d9;
																															case 84:
																															case 106:
																																goto end_IL_08f2;
																															case 122:
																																goto end_IL_0902;
																															case 66:
																															case 73:
																																goto end_IL_0912;
																															case 74:
																																goto end_IL_0922;
																															case 75:
																																goto end_IL_0932;
																															case 78:
																															case 103:
																																goto IL_094d;
																															}
																															continue;
																														}
																														if (5 > b)
																														{
																															break;
																														}
																														goto IL_0644;
																														IL_0652:
																														array2[num5] = array5[*(int*)(ptr2 + num3)];
																														goto IL_066a;
																														IL_0678:
																														ptr2 += 8;
																														goto end_IL_0330;
																														IL_066a:
																														num5++;
																														goto IL_0678;
																														IL_0644:
																														array[num5] = 5;
																														goto IL_0652;
																														continue;
																														end_IL_028d:
																														break;
																													}
																													break;
																													IL_02a0:;
																												}
																												break;
																											}
																											goto IL_033b;
																											IL_037a:
																											num5 -= 3;
																											goto end_IL_0330;
																											IL_033b:
																											((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_037a;
																										}
																										break;
																									}
																									goto IL_068b;
																									IL_06de:
																									num5--;
																									goto end_IL_0330;
																									IL_068b:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_0699;
																									IL_0699:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_06a7;
																									IL_06a7:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_06d0;
																									IL_06d0:
																									ptr2 += 8;
																									goto IL_06de;
																								}
																								break;
																							}
																							goto IL_06f1;
																							IL_0870:
																							num5--;
																							num = 143;
																							goto end_IL_0330;
																							IL_06f1:
																							if (4 > b)
																							{
																								goto IL_06ff;
																							}
																							goto IL_083b;
																							IL_06ff:
																							if (2 < b)
																							{
																								goto IL_070a;
																							}
																							goto IL_0768;
																							IL_070a:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0718;
																							IL_0718:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0726;
																							IL_0726:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_074f;
																							IL_074f:
																							array[num5 - 1] = 5;
																							goto end_IL_0330;
																							IL_0768:
																							if (2 > b)
																							{
																								goto IL_0773;
																							}
																							goto IL_07d7;
																							IL_0773:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0781;
																							IL_0781:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_078f;
																							IL_078f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_07a8;
																							IL_07a8:
																							array[num5] = 0;
																							goto IL_07b6;
																							IL_07b6:
																							num5++;
																							goto IL_07c4;
																							IL_07c4:
																							ptr2 += 8;
																							goto end_IL_0330;
																							IL_07d7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0817;
																							IL_0817:
																							array[num5 - 2] = 0;
																							goto IL_082b;
																							IL_082b:
																							num5--;
																							goto end_IL_0330;
																							IL_083b:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_0859;
																							IL_0859:
																							ptr2 += 8;
																							num = 55;
																							goto IL_0870;
																						}
																						break;
																					}
																					goto IL_0889;
																					IL_0889:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0330;
																				}
																				break;
																			}
																			goto IL_038d;
																			IL_0462:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_038d:
																			if (12 >= b)
																			{
																				goto IL_0398;
																			}
																			goto IL_03f8;
																			IL_0398:
																			if (12 <= b)
																			{
																				goto IL_03a3;
																			}
																			goto IL_03e8;
																			IL_03a3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0493;
																			IL_0493:
																			array[num5 - 2] = 0;
																			goto IL_051d;
																			IL_051d:
																			num5--;
																			goto end_IL_0330;
																			IL_03e8:
																			if (10 < b)
																			{
																				goto IL_0475;
																			}
																			goto IL_0530;
																			IL_0475:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0483;
																			IL_0483:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_04a9;
																			IL_04a9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_04ed;
																			IL_04ed:
																			array[num5 - 2] = 0;
																			num = 88;
																			goto IL_050a;
																			IL_050a:
																			num5--;
																			goto end_IL_0330;
																			IL_0530:
																			if (10 > b)
																			{
																				goto IL_053b;
																			}
																			goto IL_055c;
																			IL_053b:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0549;
																			IL_0549:
																			if (9 <= b)
																			{
																				goto end_IL_0330;
																			}
																			break;
																			IL_055c:
																			array[num5] = 0;
																			goto IL_056a;
																			IL_056a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_058d;
																			IL_058d:
																			array2[num5] = null;
																			goto IL_0597;
																			IL_0597:
																			num5++;
																			goto IL_05a5;
																			IL_05a5:
																			ptr2 += 8;
																			num = 116;
																			goto end_IL_0330;
																			IL_03f8:
																			if (14 >= b)
																			{
																				goto IL_0403;
																			}
																			goto IL_0454;
																			IL_0403:
																			if (14 > b)
																			{
																				goto IL_040e;
																			}
																			goto IL_042f;
																			IL_040e:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_041c;
																			IL_041c:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_05c1;
																			IL_05c1:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0623;
																			IL_0623:
																			num5 -= 2;
																			goto end_IL_0330;
																			IL_042f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 34;
																			goto end_IL_0330;
																			IL_0454:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0462;
																		}
																		break;
																		IL_0300:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0330;
																continue;
																end_IL_0310:
																break;
															}
															continue;
															end_IL_0320:
															break;
														}
														continue;
														end_IL_0330:
														break;
													}
													continue;
												}
												goto IL_094d;
												IL_094d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b1:
												break;
											}
											continue;
											end_IL_08c4:
											break;
										}
										continue;
										end_IL_08ce:
										break;
									}
									continue;
									end_IL_08d9:
									break;
								}
								continue;
								end_IL_08f2:
								break;
							}
							continue;
							end_IL_0902:
							break;
						}
						continue;
						end_IL_0912:
						break;
					}
					continue;
					end_IL_0922:
					break;
				}
				continue;
				end_IL_0932:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 57;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 138;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetVarIndexOfMemIdOnStop.ToByteCustomAttributes);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0369:
														byte b = *ptr2;
														while (true)
														{
															IL_0359:
															ptr2++;
															while (true)
															{
																IL_0349:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0329:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_0309:
																						if (4 < b)
																						{
																							num = 144;
																							while (true)
																							{
																								IL_02f9:
																								if (6 >= b)
																								{
																									while (true)
																									{
																										IL_02e9:
																										if (6 > b)
																										{
																											while (5 >= b)
																											{
																												num = 166;
																												while (true)
																												{
																													if (num != 166)
																													{
																														if (num != 1147)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 53:
																															goto IL_02d6;
																														case 0:
																															goto IL_02e9;
																														case 104:
																														case 144:
																															goto IL_02f9;
																														case 2:
																															goto IL_0309;
																														case 37:
																															goto IL_0319;
																														case 89:
																															goto IL_0329;
																														case 64:
																															goto IL_0339;
																														case 82:
																															goto IL_0349;
																														case 126:
																															goto IL_0359;
																														case 23:
																														case 98:
																															goto IL_0369;
																														case 46:
																															goto IL_0374;
																														case 24:
																														case 25:
																															goto IL_037f;
																														case 33:
																															goto IL_039f;
																														case 14:
																															goto IL_03aa;
																														case 55:
																															goto IL_03c3;
																														case 63:
																															goto IL_03df;
																														case 84:
																															goto IL_03f2;
																														case 73:
																															goto IL_0400;
																														case 60:
																															goto IL_040e;
																														case 90:
																														case 94:
																															goto IL_0421;
																														case 38:
																															goto IL_0460;
																														case 128:
																															goto IL_0473;
																														case 86:
																														case 145:
																															goto IL_0486;
																														case 96:
																															goto IL_04af;
																														case 91:
																														case 152:
																															goto IL_04c8;
																														case 146:
																															goto IL_0508;
																														case 112:
																															goto IL_051c;
																														case 34:
																														case 157:
																															goto IL_052f;
																														case 54:
																															goto IL_0548;
																														case 61:
																															goto IL_0556;
																														case 16:
																															goto IL_056d;
																														case 142:
																														case 154:
																															goto IL_058e;
																														case 129:
																															goto IL_059c;
																														case 119:
																															goto IL_05b4;
																														case 47:
																															goto IL_05c2;
																														case 114:
																															goto IL_05d5;
																														case 141:
																															goto IL_05e0;
																														case 27:
																														case 29:
																															goto IL_05ee;
																														case 85:
																															goto IL_0617;
																														case 122:
																															goto IL_0625;
																														case 155:
																															goto IL_0638;
																														case 10:
																															goto IL_0646;
																														case 134:
																														case 150:
																															goto IL_0654;
																														case 36:
																															goto IL_066c;
																														case 93:
																														case 101:
																															goto IL_067a;
																														case 97:
																															goto IL_0688;
																														case 52:
																														case 100:
																															goto IL_0693;
																														case 92:
																														case 151:
																															goto IL_06a6;
																														case 159:
																															goto IL_06b4;
																														case 1:
																														case 109:
																															goto IL_06c2;
																														case 20:
																															goto IL_06d6;
																														case 137:
																															goto IL_0715;
																														case 88:
																														case 149:
																															goto end_IL_02c3;
																														case 120:
																															goto IL_073c;
																														case 80:
																														case 81:
																															goto IL_074a;
																														case 30:
																															goto IL_0766;
																														case 121:
																															goto IL_0774;
																														case 21:
																															goto IL_0787;
																														case 5:
																														case 95:
																															goto IL_0795;
																														case 115:
																															goto IL_07a3;
																														case 158:
																															goto IL_07b1;
																														case 133:
																														case 156:
																															goto IL_07bf;
																														case 87:
																															goto IL_07ff;
																														case 26:
																															goto IL_0813;
																														case 135:
																															goto IL_082f;
																														case 15:
																														case 67:
																															goto IL_083a;
																														case 18:
																															goto IL_087e;
																														case 13:
																															goto IL_0892;
																														case 110:
																															goto IL_08a5;
																														case 143:
																															goto IL_08b3;
																														case 3:
																														case 39:
																															goto IL_08c1;
																														case 108:
																															goto IL_08cf;
																														case 68:
																															goto IL_08f2;
																														case 65:
																															goto IL_08fc;
																														case 48:
																															goto IL_090a;
																														case 17:
																														case 140:
																															goto IL_091d;
																														case 147:
																															goto IL_097f;
																														case 7:
																														case 11:
																														case 19:
																														case 22:
																														case 31:
																														case 41:
																														case 43:
																														case 44:
																														case 45:
																														case 58:
																														case 59:
																														case 66:
																														case 69:
																														case 70:
																														case 71:
																														case 75:
																														case 77:
																														case 78:
																														case 83:
																														case 105:
																														case 106:
																														case 111:
																														case 113:
																														case 117:
																														case 118:
																														case 124:
																														case 130:
																														case 136:
																														case 139:
																															goto end_IL_02d6;
																														case 6:
																														case 8:
																														case 12:
																														case 28:
																														case 32:
																														case 35:
																														case 40:
																														case 42:
																														case 50:
																														case 74:
																														case 76:
																														case 79:
																														case 99:
																														case 103:
																														case 116:
																														case 123:
																														case 127:
																														case 131:
																														case 132:
																														case 153:
																															goto end_IL_0319;
																														case 72:
																															goto end_IL_09a2;
																														case 62:
																															goto end_IL_09b5;
																														case 51:
																															goto end_IL_09bf;
																														case 4:
																															goto end_IL_09ca;
																														case 49:
																														case 125:
																															goto end_IL_09da;
																														case 9:
																															goto end_IL_09ea;
																														case 138:
																														case 148:
																															goto end_IL_09fa;
																														case 56:
																															goto end_IL_0a0a;
																														case 57:
																															goto end_IL_0a1a;
																														case 102:
																														case 107:
																															goto IL_0a3e;
																														}
																														continue;
																													}
																													if (5 > b)
																													{
																														goto end_IL_02d6;
																													}
																													goto IL_058e;
																													IL_059c:
																													array2[num5] = array5[*(int*)(ptr2 + num3)];
																													goto IL_05b4;
																													IL_05c2:
																													ptr2 += 8;
																													goto end_IL_0319;
																													IL_05b4:
																													num5++;
																													goto IL_05c2;
																													IL_058e:
																													array[num5] = 5;
																													goto IL_059c;
																													continue;
																													end_IL_02c3:
																													break;
																												}
																												goto IL_0731;
																												continue;
																												end_IL_02d6:
																												break;
																												IL_02d6:;
																											}
																											break;
																										}
																										goto IL_0421;
																										IL_0460:
																										num5 -= 3;
																										goto end_IL_0319;
																										IL_0421:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0460;
																									}
																									break;
																								}
																								goto IL_05d5;
																								IL_0654:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0319;
																								IL_05d5:
																								if (7 >= b)
																								{
																									goto IL_05e0;
																								}
																								goto IL_0638;
																								IL_05e0:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_05ee;
																								IL_05ee:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0617;
																								IL_0617:
																								ptr2 += 8;
																								goto IL_0625;
																								IL_0625:
																								num5--;
																								goto end_IL_0319;
																								IL_0638:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_0646;
																								IL_0646:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_0654;
																							}
																							break;
																						}
																						goto IL_0374;
																						IL_056d:
																						ptr2 += 8;
																						goto end_IL_0319;
																						IL_04c8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0508;
																						IL_0374:
																						if (4 <= b)
																						{
																							goto IL_037f;
																						}
																						goto IL_039f;
																						IL_037f:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_03df;
																						IL_03df:
																						ptr2 += 8;
																						goto IL_0473;
																						IL_0473:
																						num5--;
																						goto end_IL_0319;
																						IL_039f:
																						if (2 < b)
																						{
																							goto IL_03aa;
																						}
																						goto IL_03f2;
																						IL_03aa:
																						if (3 < b)
																						{
																							num = 11;
																							break;
																						}
																						goto IL_03c3;
																						IL_0508:
																						array[num5 - 2] = 0;
																						goto IL_051c;
																						IL_03c3:
																						if (3 > b)
																						{
																							num = 113;
																							break;
																						}
																						goto IL_0486;
																						IL_051c:
																						num5--;
																						goto end_IL_0319;
																						IL_0486:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_04af;
																						IL_04af:
																						array[num5 - 1] = 5;
																						goto end_IL_0319;
																						IL_03f2:
																						if (2 > b)
																						{
																							goto IL_0400;
																						}
																						goto IL_04c8;
																						IL_0400:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_040e;
																						IL_040e:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_052f;
																						IL_052f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0548;
																						IL_0548:
																						array[num5] = 0;
																						goto IL_0556;
																						IL_0556:
																						num5++;
																						num = 16;
																						goto IL_056d;
																					}
																					goto end_IL_0339;
																					continue;
																					end_IL_0319:
																					break;
																					IL_0319:;
																				}
																				break;
																			}
																			goto IL_066c;
																			IL_091d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_097f;
																			IL_066c:
																			if (13 < b)
																			{
																				goto IL_067a;
																			}
																			goto IL_0787;
																			IL_067a:
																			if (15 >= b)
																			{
																				goto IL_0688;
																			}
																			goto IL_0731;
																			IL_0688:
																			if (15 <= b)
																			{
																				goto IL_0693;
																			}
																			goto IL_06a6;
																			IL_0693:
																			num5--;
																			break;
																			IL_06a6:
																			if (14 < b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_06b4;
																			IL_06b4:
																			if (14 > b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_06c2;
																			IL_06c2:
																			array[num5 - 1] = 0;
																			goto IL_06d6;
																			IL_06d6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getCurrentlyExecutingTaskCountAccessDenied[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0715;
																			IL_0715:
																			ptr2 += 8;
																			num = 50;
																			break;
																			IL_0731:
																			if (16 >= b)
																			{
																				goto IL_073c;
																			}
																			goto IL_0766;
																			IL_073c:
																			if (16 > b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_074a;
																			IL_074a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0766:
																			if (17 < b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_0774;
																			IL_0774:
																			if (17 > b)
																			{
																			}
																			goto end_IL_0339;
																			IL_0787:
																			if (13 > b)
																			{
																				goto IL_0795;
																			}
																			goto IL_091d;
																			IL_0795:
																			if (11 < b)
																			{
																				goto IL_07a3;
																			}
																			num = 135;
																			goto IL_082f;
																			IL_07a3:
																			if (12 < b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_07b1;
																			IL_07b1:
																			if (12 > b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_07bf;
																			IL_07bf:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07ff;
																			IL_07ff:
																			array[num5 - 2] = 0;
																			goto IL_0813;
																			IL_0813:
																			num5--;
																			break;
																			IL_097f:
																			num5 -= 2;
																			break;
																			IL_082f:
																			if (11 <= b)
																			{
																				goto IL_083a;
																			}
																			goto IL_08a5;
																			IL_083a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_087e;
																			IL_087e:
																			array[num5 - 2] = 0;
																			goto IL_0892;
																			IL_0892:
																			num5--;
																			break;
																			IL_08a5:
																			if (10 < b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_08b3;
																			IL_08b3:
																			if (10 > b)
																			{
																				goto end_IL_0339;
																			}
																			goto IL_08c1;
																			IL_08c1:
																			array[num5] = 0;
																			goto IL_08cf;
																			IL_08cf:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_08f2;
																			IL_08f2:
																			array2[num5] = null;
																			goto IL_08fc;
																			IL_08fc:
																			num5++;
																			goto IL_090a;
																			IL_090a:
																			ptr2 += 8;
																			break;
																		}
																		goto end_IL_0349;
																		continue;
																		end_IL_0339:
																		break;
																		IL_0339:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0349:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a3e;
												IL_0a3e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09a2:
												break;
											}
											continue;
											end_IL_09b5:
											break;
										}
										continue;
										end_IL_09bf:
										break;
									}
									continue;
									end_IL_09ca:
									break;
								}
								continue;
								end_IL_09da:
								break;
							}
							continue;
							end_IL_09ea:
							break;
						}
						continue;
						end_IL_09fa:
						break;
					}
					continue;
					end_IL_0a0a:
					break;
				}
				continue;
				end_IL_0a1a:
				break;
			}
		}
	}

	static Class190()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 10;
				while (true)
				{
					if (num == 10 || num != 991)
					{
						return;
					}
					switch (num)
					{
					case 0:
						goto end_IL_0031;
					case 1:
						goto end_IL_003e;
					case 2:
						return;
					case 3:
						return;
					}
					continue;
					end_IL_0031:
					break;
				}
				continue;
				end_IL_003e:
				break;
			}
		}
	}
}
